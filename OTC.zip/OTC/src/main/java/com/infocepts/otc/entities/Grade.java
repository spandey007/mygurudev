package com.infocepts.otc.entities;


import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.SqlResultSetMappings;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.infocepts.otc.utilities.LoadConstant;

@Entity
@Table(catalog=LoadConstant.infomaster, schema="[dbo]",name="grade")

@SqlResultSetMappings({    
    @SqlResultSetMapping(
            name = "get_grades",
            classes = {
                    @ConstructorResult(
                            targetClass = Grade.class,
                            columns = {
                            		@ColumnResult(name = "gradeId"),
                            		@ColumnResult(name = "bandId",type = String.class),
                            		@ColumnResult(name = "grade",type = String.class),
                            		@ColumnResult(name = "gradeNo",type = String.class),
                            		@ColumnResult(name = "designation",type = String.class),
                            		@ColumnResult(name = "status"),
                            		@ColumnResult(name = "hrmsId"),
                            		@ColumnResult(name = "createdBy"),
                            		@ColumnResult(name = "createdDate",type = Date.class),
                            		@ColumnResult(name = "modifiedBy"),
                            		@ColumnResult(name = "modifiedDate",type = Date.class),
                            		@ColumnResult(name = "band",type = String.class),
                            }
                    )
            }
    )
    
})
@NamedNativeQueries({ 
    @NamedNativeQuery(
            name    =   "getGradesWithBands",                
            query = "select g.*, b.band"+                		
            		" FROM " + LoadConstant.infomaster + ".[dbo].grade g"+
            		" Left join " + LoadConstant.infomaster + ".[dbo].band b on b.bandId = g.bandId",
				    resultClass=Grade.class, resultSetMapping = "get_grades"
	)
    
})
public class Grade {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer gradeId;
	private String bandId;
	private String grade;
	private String gradeNo;
	private String designation;
	private Boolean status;
	private Integer hrmsId;
	private Integer createdBy;
	private Date createdDate;
	private Integer modifiedBy;
	private Date modifiedDate;
	
	@Transient
	private String band;
	
	public Integer getGradeId() {
		return gradeId;
	}
	public void setGradeId(Integer gradeId) {
		this.gradeId = gradeId;
	}
	public String getBandId() {
		return bandId;
	}
	public void setBandId(String bandId) {
		this.bandId = bandId;
	}
	public String getGrade() {
		return grade;
	}	
	public String getGradeNo() {
		return gradeNo;
	}
	public void setGradeNo(String gradeNo) {
		this.gradeNo = gradeNo;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public Boolean getStatus() {
		return status;
	}
	public void setStatus(Boolean status) {
		this.status = status;
	}
	public Integer getHrmsId() {
		return hrmsId;
	}
	public void setHrmsId(Integer hrmsId) {
		this.hrmsId = hrmsId;
	}
	public Integer getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public Integer getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public Date getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	
	public String getBand() {
		return band;
	}
	public void setBand(String band) {
		this.band = band;
	}
	public Grade(){
		
	}
	public Grade(Integer gradeId, String bandId, String grade, String gradeNo, String designation, Boolean status,
			Integer hrmsId, Integer createdBy, Date createdDate, Integer modifiedBy, Date modifiedDate, String band) {
		super();
		this.gradeId = gradeId;
		this.bandId = bandId;
		this.grade = grade;
		this.gradeNo = gradeNo;
		this.designation = designation;
		this.status = status;
		this.hrmsId = hrmsId;
		this.createdBy = createdBy;
		this.createdDate = createdDate;
		this.modifiedBy = modifiedBy;
		this.modifiedDate = modifiedDate;
		this.band = band;
	}
	
	
}
