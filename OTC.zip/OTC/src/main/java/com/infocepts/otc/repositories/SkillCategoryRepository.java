package com.infocepts.otc.repositories;

import java.util.List;
import org.springframework.data.repository.CrudRepository;
import com.infocepts.otc.entities.SkillCategory;

public interface SkillCategoryRepository extends CrudRepository<SkillCategory,Integer>{

	@Override
	public List<SkillCategory> findAll();
}
