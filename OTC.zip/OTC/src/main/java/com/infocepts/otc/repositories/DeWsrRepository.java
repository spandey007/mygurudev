/**
* Filename: /src/main/java/com/infocepts/otc/repositories/DeWsrRepository.java
* @author  SHRI
* @version 1.0
* @since   2019-11-28 
*/
package com.infocepts.otc.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import com.infocepts.otc.entities.DEGovernanceNotes;
import com.infocepts.otc.entities.DeWsr;

public interface DeWsrRepository extends CrudRepository<DeWsr,Integer>{

	@Override
	public List<DeWsr> findAll();	
		
	@Query("from DeWsr where projectId = :projectId order by deWsrId asc")
	List<DeWsr> findByProjectId(@Param("projectId")Integer projectId);
	
	
}