package com.infocepts.otc.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.infocepts.otc.entities.AccountPlanning;

public interface AccountPlanningRepository extends CrudRepository<AccountPlanning,Integer> {

	@Override
	public List<AccountPlanning> findAll();
	

//	@Query("from accountPlanning ap where ap.accountId=:accountId")
//	public List<AccountPlanning> findByAccountId(@Param("accountId") Integer accountId);
	
}
