package com.infocepts.otc.controllers;

import com.infocepts.otc.entities.TaskCategory;
import com.infocepts.otc.repositories.TaskCategoryRepository;
import com.infocepts.otc.services.TimesheetService;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(value = "/taskcategory", headers = "referer")
public class TaskCategoryController {

    final Logger logger = Logger.getLogger(TaskCategoryController.class);

    @Autowired
    TaskCategoryRepository repository;

    @Autowired
    TimesheetService service;

    @RequestMapping(method = RequestMethod.POST)
    public TaskCategory addTaskCategory(@RequestBody TaskCategory taskCategory) {
        try {
            if (service.isPmo()) {
                taskCategory.setTaskCategoryId(null);
                repository.save(taskCategory);
            }
        } catch (Exception e) {
            logger.error(e);
        }
        return taskCategory;
    }

    @RequestMapping(method = RequestMethod.GET)
    public List<TaskCategory> getAllTaskCategories() {
        List<TaskCategory> taskCategories = null;
        try {
            taskCategories = repository.findAll();
        } catch (Exception e) {
            logger.error(e);
        }
        return taskCategories;
    }

    @RequestMapping(value = "/{taskCategoryId}", method = RequestMethod.GET)
    public TaskCategory getTaskCategory(@PathVariable Integer taskCategoryId) {
        TaskCategory taskCategory = null;
        try {
            taskCategory = repository.findOne(taskCategoryId);
        } catch (Exception e) {
            logger.error(e);
        }
        return taskCategory;
    }


    @RequestMapping(value = "/{taskCategoryId}", method = RequestMethod.PUT)
    public TaskCategory updateTaskCategory(@RequestBody TaskCategory taskCategory, @PathVariable Integer taskCategoryId) {
        try {
            if (service.isPmo()) {
                taskCategory.setTaskCategoryId(taskCategoryId);
                repository.save(taskCategory);
            }
        } catch (Exception e) {
            logger.error(e);
        }
        return taskCategory;
    }

    @RequestMapping(value = "/{taskCategoryId}", method = RequestMethod.DELETE)
    public void deleteTaskCategory(@PathVariable Integer taskCategoryId) {
        try {
            if (service.isPmo()) {
                repository.delete(taskCategoryId);
            }
        } catch (Exception e) {
            logger.error(e);
        }
    }

}
