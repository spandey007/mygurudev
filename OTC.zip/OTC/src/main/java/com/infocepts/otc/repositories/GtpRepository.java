package com.infocepts.otc.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;


import com.infocepts.otc.entities.Gtp;


public interface GtpRepository extends CrudRepository<Gtp,Integer>{

	@Override
	public List<Gtp> findAll();	
		
	@Query("from Gtp where uid = :uid")
	public Gtp findGtpByUid(@Param(value = "uid") Integer uid);
	
}
