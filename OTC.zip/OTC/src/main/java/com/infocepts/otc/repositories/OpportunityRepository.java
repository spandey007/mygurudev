package com.infocepts.otc.repositories;

import java.util.List;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import com.infocepts.otc.entities.Opportunity;
import java.lang.String;

public interface OpportunityRepository extends CrudRepository<Opportunity,Integer>{

	@Override
	public List<Opportunity> findAll();
	
	@Query("from Opportunity where opportunityName = :opportunityName")
	public Opportunity findByOpportunityName(@Param("opportunityName") String opportunityName);
	
	@Query("from Opportunity where countryId = :countryId")
	public List<Opportunity> findByCountryId(@Param("countryId") Integer countryId);

	@Query("from Opportunity where accountId = :accountId")
	public List<Opportunity> findByAccountId(@Param("accountId") Integer accountId);	
}
