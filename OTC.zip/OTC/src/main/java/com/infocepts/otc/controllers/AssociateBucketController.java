package com.infocepts.otc.controllers;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.infocepts.otc.entities.AssociateBucket;
import com.infocepts.otc.repositories.AssociateBucketRepository;
import com.infocepts.otc.services.TimesheetService;

@RestController
@RequestMapping(value="/associatebucket",headers="referer")
public class AssociateBucketController {

	@Autowired
	AssociateBucketRepository repository;
	
	@PersistenceContext
    private EntityManager manager;
	
	
	@Autowired
	TimesheetService service;
	
	final Logger logger = Logger.getLogger(AssociateBucketController.class);
	
	
	@RequestMapping(method=RequestMethod.POST)
	public AssociateBucket saveAssociateBucket(@RequestBody AssociateBucket associatebucket){
		try{
			if(service.isAValidAdminRole()){
				associatebucket.setAssociateBucketId(null);
				repository.save(associatebucket);
			}
		}
		catch(Exception e){
			logger.error(e);
		}
		return associatebucket;
	}
	
	@RequestMapping(method=RequestMethod.GET)
	public List<AssociateBucket> getAssociateBuckets(@RequestParam(value = "associateUid", defaultValue = "0")Integer associateUid,
		@RequestParam(value = "bucketId", defaultValue = "0")Integer bucketId,
		@RequestParam(value = "bucketCount", defaultValue = "0")Integer bucketCount){
		List<AssociateBucket> associatebucketList=null;
		try
		{
			if(associateUid != 0){
				associatebucketList = repository.findByAssociateUid(associateUid);
			}
			if(bucketId != 0){
				associatebucketList = repository.findByBucketId(bucketId);
			}
			if(bucketCount != 0){
				associatebucketList = manager.createNamedQuery("getAssociateBucketCount", AssociateBucket.class)
						 .getResultList();
			}
			else{
				associatebucketList = repository.findAll();
			}
		}
		catch(Exception e){
			logger.error(e);
		}
		return associatebucketList;
	}
	
	@RequestMapping(value="/{associateBucketId}",method=RequestMethod.PUT)
	public void updateAssociateBucket(@PathVariable Integer associateBucketId,@RequestBody AssociateBucket updatedassociatebucket){
		try{
			if(service.isAValidAdminRole()){
				updatedassociatebucket.setAssociateBucketId(associateBucketId);
				repository.save(updatedassociatebucket);
			}
		}
		catch(Exception e){
			logger.error(e);
		}
	}
	
	@RequestMapping(value="/{associateBucketId}",method=RequestMethod.DELETE)
	public void deleteAssociateBucket(@PathVariable Integer associateBucketId){
			try{
				if(service.isAValidAdminRole()){
					repository.delete(associateBucketId);
				}
			}
			catch(Exception e){
				logger.error(e);
			}
	}
}
