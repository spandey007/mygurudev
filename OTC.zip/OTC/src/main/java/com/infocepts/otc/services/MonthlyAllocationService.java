package com.infocepts.otc.services;

import org.springframework.stereotype.Service;

import com.infocepts.otc.entities.Allocation;

@Service
public interface MonthlyAllocationService {
	
	//To insert or update monthly allocation table
	public void InsertUpdateMonthlyAllocation(Allocation allocation);

	//To delete all monthly allocation rows for a particular allocation
	public void DeleteMonthlyAllocation(Integer alcId);
	
	

}
