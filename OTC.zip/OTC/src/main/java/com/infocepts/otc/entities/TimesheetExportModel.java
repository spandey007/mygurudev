package com.infocepts.otc.entities;

import java.util.List;

public class TimesheetExportModel {

	private Integer projectId;
	private String tsmonth;
	private String tsMonthStr;
	private List<Integer> associatePKList;
	
	public Integer getProjectId() {
		return projectId;
	}
	public void setProjectId(Integer projectId) {
		this.projectId = projectId;
	}
	public String getTsmonth() {
		return tsmonth;
	}
	public void setTsmonth(String tsmonth) {
		this.tsmonth = tsmonth;
	}
	public String getTsMonthStr() {
		return tsMonthStr;
	}
	public void setTsMonthStr(String tsMonthStr) {
		this.tsMonthStr = tsMonthStr;
	}
	public List<Integer> getAssociatePKList() {
		return associatePKList;
	}
	public void setAssociatePKList(List<Integer> associatePKList) {
		this.associatePKList = associatePKList;
	}
	
	
	
}
