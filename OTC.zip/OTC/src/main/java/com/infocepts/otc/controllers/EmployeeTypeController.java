package com.infocepts.otc.controllers;

import com.infocepts.otc.entities.EmployeeType;
import com.infocepts.otc.repositories.EmployeeTypeRepository;
import com.infocepts.otc.services.TimesheetService;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(value = "/employeeType", headers="referer")
public class EmployeeTypeController {

    static final Logger logger = Logger.getLogger(EmployeeTypeController.class);

    @Autowired
    EmployeeTypeRepository employeeTypeRepository;

    @Autowired
    TimesheetService timesheetService;

    @RequestMapping(method= RequestMethod.GET)
    private List<EmployeeType> getAllEmployeeType(){
        return this.employeeTypeRepository.findAll();
    }

    @RequestMapping(method=RequestMethod.POST)
    private EmployeeType addNewEmployeeType(@RequestBody EmployeeType employeeType) throws UnauthorizedException {

        if(this.timesheetService.isAdmin()) {
            return this.employeeTypeRepository.save(employeeType);
        }
        else{
            throw new UnauthorizedException("Access denied");
        }
    }

    @RequestMapping(value="/{empTypeId}",method=RequestMethod.PUT)
    private EmployeeType updateEmployeeType(@RequestBody EmployeeType employeeType) throws UnauthorizedException {
        if(this.timesheetService.isAdmin()) {
            return this.employeeTypeRepository.save(employeeType);
        }
        else{
            throw new UnauthorizedException("Access denied");
        }
    }

    @RequestMapping(value = "/{empTypeId}", method = RequestMethod.DELETE)
    private void deleteEmployeeType(@PathVariable Integer empTypeId) throws UnauthorizedException {
        if(this.timesheetService.isAdmin()) {
             this.employeeTypeRepository.delete(empTypeId);
        }
        else{
            throw new UnauthorizedException("Access denied");
        }
    }
}
