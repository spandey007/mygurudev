package com.infocepts.otc.controllers;


import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.mail.MessagingException;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.thymeleaf.context.Context;

import com.infocepts.otc.entities.Account;
import com.infocepts.otc.entities.Portfolio;
import com.infocepts.otc.entities.Project;
import com.infocepts.otc.entities.Resource;
import com.infocepts.otc.entities.TimesheetApproval;
import com.infocepts.otc.entities.TimesheetExportModel;
import com.infocepts.otc.entities.TimesheetHours;
import com.infocepts.otc.entities.TimesheetPeriods;
import com.infocepts.otc.notification.SmtpMailSender;
import com.infocepts.otc.repositories.AccountRepository;
import com.infocepts.otc.repositories.PortfolioRepository;
import com.infocepts.otc.repositories.ProjectRepository;
import com.infocepts.otc.repositories.TimesheetApprovalRepository;
import com.infocepts.otc.services.TimesheetService;
import com.infocepts.otc.utilities.AbstractTimesheetFileHandling;
import com.infocepts.otc.utilities.DateConverter;
import com.infocepts.otc.utilities.LoadConstant;


@RestController
@RequestMapping(value="/timesheetapproval",headers="referer")//JV: Added 'headers' param to validate the url.
public class TimesheetApprovalController {
	
	private final Logger logger = Logger.getLogger(TimesheetApprovalController.class.getName());
	//final Logger logger = Logger.getLogger(TimesheetApprovalController.class);
	
	@Autowired
	TimesheetApprovalRepository repository;
	
	@PersistenceContext(unitName="otc")
    private EntityManager manager;
	
	@Autowired
	private SmtpMailSender smtpMailSender;
	
	@Autowired
	ProjectController projectController;
	@Autowired
	ResourceController resourceController;
	
	@Autowired
	PortfolioRepository portfolioRepository;
	
	@Autowired
	AccountRepository accountRepository;	
	@Autowired
	AccountController accountController;
	
	@Autowired
	HttpSession session;
	
	@Autowired
	TimesheetService service;
	
	@Autowired
	private  ProjectRepository  projectRepository;
	
	@RequestMapping(method=RequestMethod.GET)
	public List<TimesheetApproval> getTimesheetApproval(@RequestParam(value = "tsmonth", defaultValue = "0") String tsmonth,
													@RequestParam(value = "tsMonthStr", defaultValue = "0") String tsMonthStr,
													@RequestParam(value = "uid", defaultValue = "0") Integer uid,	
													@RequestParam(value = "pmUid", defaultValue = "0") Integer pmUid,
													@RequestParam(value = "ahUid", defaultValue = "0") Integer ahUid,
													@RequestParam(value = "dmUid", defaultValue = "0") Integer dmUid,
													@RequestParam(value = "ppUid", defaultValue = "") String ppUid, 
													@RequestParam(value = "monthEndDate", defaultValue = "")String monthEndDate,
													@RequestParam(value = "monthstartDate", defaultValue = "")String monthstartDate,
													HttpServletRequest request) throws MessagingException {
		
		List<TimesheetApproval> tsApprovalItems = null;
		
		/* ------------------------- Authorization start ------------------------------------ */
		// Authorization for passed pmUid
		if(pmUid != 0 && pmUid != null){
			
			Integer loggedInUid = (Integer) session.getAttribute("loggedInUid");			
					
			if(loggedInUid != 0 && loggedInUid != null){
				if((!loggedInUid.equals(pmUid)) && (!service.isAdmin()))//do not check delegation, hence second param is false
				{
					service.sendTamperedMail("PM Approval View", pmUid, 0, request);
					return tsApprovalItems;
				}
			}
		}
		// Authorization for passed ahUid
				if(ahUid != 0 && ahUid != null){
					
					Integer loggedInUid = (Integer) session.getAttribute("loggedInUid");			
							
					if(loggedInUid != 0 && loggedInUid != null){
						if((!loggedInUid.equals(ahUid)) && (!service.isAdmin()))//do not check delegation, hence second param is false
						{
							service.sendTamperedMail("AH Approval View", ahUid, 0, request);
							return tsApprovalItems;
						}
					}
				}
		// Authorization for passed dmUid
		if(dmUid != 0 && dmUid != null){
			
			Integer loggedInUid = (Integer) session.getAttribute("loggedInUid");			
					
			if(loggedInUid != 0 && loggedInUid != null){
				if((!loggedInUid.equals(dmUid)) && (!service.isAdmin()))//do not check delegation, hence second param is false
				{
					service.sendTamperedMail("PH Approval View", dmUid, 0, request);
					return tsApprovalItems;
				}
			}
		}
		/* ------------------------- Authorization ends ------------------------------------ */
		try
		{	
			if(tsmonth != null)
			{
				Integer month=service.getMonth(tsmonth);
				Integer year=service.getYear(tsmonth);
				if(month != null && year != null)
				{	
					// If uid, (required for the timesheet report by associates on popup)
					if(uid != 0)
					{
						tsApprovalItems = manager.createNamedQuery("getProjectsReportByUidAndMonth", TimesheetApproval.class)
												.setParameter("uid", uid)							 
												.setParameter("year", year)
												.setParameter("month", month)
												.setParameter("monthStr", tsMonthStr)
									            .getResultList();
					}
					else // If pmUid and dmUid both are null, the call will retrieve all the projects (required for the timesheet report by projects)
					{
						tsApprovalItems = manager.createNamedQuery("getProjectsByMonth", TimesheetApproval.class)
								.setParameter("pmUid", pmUid) 
								.setParameter("ahUid", ahUid) 
								.setParameter("dmUid", dmUid)	
								.setParameter("ppUid", ppUid)
								.setParameter("year", year)
								.setParameter("month", month)
								.setParameter("monthStr", tsMonthStr)
								.setParameter("monthEndDate", monthEndDate)
								.setParameter("monthstartDate", monthstartDate)
					            .getResultList();	
					}
				}				
			}
			
		}
		catch(Exception e){
			logger.log(Level.SEVERE, "Error in while fetching Timesheet Approval Data ", e);
			//logger.error(e);
		}
		return tsApprovalItems;
	}
	
	@RequestMapping(method=RequestMethod.POST)
	public TimesheetApproval addTimesheetApproval(@RequestBody TimesheetApproval tsapproval,HttpServletRequest request) throws MessagingException {
		try{
			tsapproval.setTsapprovalId(null);
			repository.save(tsapproval);
			/* mail code start here */
			if(tsapproval.getPmApprovedBy() != null)
			{
				Account accnt = null;
				Resource resourceAh = null;
				String ahEmail = null;
				Project project = projectController.getProject(tsapproval.getProjectId());
				Resource resourcePm = resourceController.findResource(project.getProjectManagersId());
				Portfolio portfolio = portfolioRepository.findOne(project.getPortfolioId());
				Resource resourceDm = resourceController.findResource(portfolio.getOwnerId());
				String projectName = tsapproval.getProjectName();
				String month = DateConverter.theMonth(tsapproval.getMonth());
				Integer rejectCount = tsapproval.getRejectionCount();				
				Context context = new Context();
				String ccEmails = null;
				// Set your template context here
				context.setVariable("projectName",projectName);	
				context.setVariable("Date",DateConverter.changeDate(tsapproval.getPmApprovalDate()));	
				context.setVariable("months",month);											
				context.setVariable("pmName",project.getPmName());
				
				if(project.getAccountId() != null) {
					accnt = accountRepository.getOne(project.getAccountId());
					if(accnt != null) {
						if(accnt.getAhId() != null) {
						resourceAh = resourceController.findResource(accnt.getAhId());	
						if(resourceAh != null) {
							ahEmail = resourceAh.getEmail();
							context.setVariable("ahName",resourceAh.getTitle());
						}
						}
					}
				}							
				
				Integer loggedInUid = (Integer) session.getAttribute("loggedInUid");		
				//System.out.println("IN add==");
				//System.out.println("uid=="+loggedInUid);
				//System.out.println("PMid=="+project.getProjectManagersId());
				//System.out.println("AHid=="+project.getOwnersId());
				//System.out.println("DMid=="+portfolio.getOwnerId());
				
				if(tsapproval.getPmApprovalNotes() != null)
				{
					context.setVariable("comment",tsapproval.getPmApprovalNotes());					
				}else{
					context.setVariable("comment","");
				}
				
				String projectApproved;String projectRejected;
				if(loggedInUid.equals(accnt.getAhId())){//approve-reject by AH
					 projectApproved = projectName+" - "+month +" TS Approved by AH";
					 projectRejected = projectName+" - "+month +" TS Rejected by AH";
				}/*else if(loggedInUid.equals(portfolio.getOwnerId())){
					 projectApproved = projectName+" - "+month +" TS Approved by PH";
					 projectRejected = projectName+" - "+month +" TS Rejected by PH";
				}*/else{//approve-reject by PM
					 projectApproved = projectName+" - "+month +" TS Approved by PM";
					 projectRejected = projectName+" - "+month +" TS Rejected by PM (Reject Count -"+rejectCount+")";
				}
				
				String pmEmail = resourcePm.getEmail();
				String dmEmail = resourceDm.getEmail();
				String accountType = accnt.getStrategic();
				Integer accountId = project.getAccountId();

				if(accountType.equals("Internal")) // check for all internal accounts 
				{
					ccEmails = pmEmail;
					if(tsapproval.getPmApprovalStatus() == 0)
					{					
						smtpMailSender.send("",dmEmail,projectRejected,"mail/projectRejectByPm", context,ccEmails,request);					
					}else{	
						smtpMailSender.send("",dmEmail,projectApproved,"mail/projectApproveByPm", context,ccEmails,request);					
					}
				}
				else
				{
					if(pmEmail !=null) {						
						ccEmails = pmEmail;						
					}										
					
					if(dmEmail !=null) {						
						ccEmails = ccEmails.concat(","+dmEmail);
					}					
					
					if(ahEmail !=null) {						
						ccEmails = ccEmails.concat(","+ahEmail);						
					}

					if(tsapproval.getPmApprovalStatus() == 0)//reject
					{
						if(loggedInUid.equals(accnt.getAhId())){//by ah
							smtpMailSender.send("",LoadConstant.INVOICES,projectRejected,"mail/projectRejectByAh", context,ccEmails,request);
						}/*else if(loggedInUid.equals(portfolio.getOwnerId())){//by ph
							smtpMailSender.send("",LoadConstant.INVOICES,projectRejected,"mail/projectRejectByDm", context,ccEmails,request);
						}*/else{//by pm
							smtpMailSender.send("",LoadConstant.INVOICES,projectRejected,"mail/projectRejectByPm", context,ccEmails,request);
						}
											
					}else{//approve
						if(loggedInUid.equals(accnt.getAhId())){//by ah
							smtpMailSender.send("",LoadConstant.INVOICES,projectApproved,"mail/projectApproveByAh", context,ccEmails,request);		
						}/*else if(loggedInUid.equals(portfolio.getOwnerId())){//by ph
							smtpMailSender.send("",LoadConstant.INVOICES,projectApproved,"mail/projectApproveByDm", context,ccEmails,request);
						}*/else{//by pm
							smtpMailSender.send("",LoadConstant.INVOICES,projectApproved,"mail/projectApproveByPm", context,ccEmails,request);		
						}
									
					}
				}
			}
			/* mail code end  */			
		}catch(Exception e){
			logger.log(Level.SEVERE, "Error in Timesheet Approval Save ", e);
			//logger.error(e);
		}
		return tsapproval;
	}
	
	@RequestMapping(value="/{tsapprovalId}",method=RequestMethod.PUT)
	public TimesheetApproval updateTimesheetApproval(@PathVariable Integer tsapprovalId,@RequestBody TimesheetApproval utsapproval,HttpServletRequest request)  throws MessagingException {
		try{
			utsapproval.setTsapprovalId(tsapprovalId);
			repository.save(utsapproval);
			// check for PM approval
			if(utsapproval.getPmApprovedBy() != null)
			{
				Account accnt = null;
				Resource resourceAh = null;
				String ahEmail = null;
				Project project = projectController.getProject(utsapproval.getProjectId());
				Resource resourcePm = resourceController.findResource(project.getProjectManagersId());
				Portfolio portfolio = portfolioRepository.findOne(project.getPortfolioId());
				Resource resourceDm = resourceController.findResource(portfolio.getOwnerId());
				String projectName = utsapproval.getProjectName();
				String month = DateConverter.theMonth(utsapproval.getMonth());				
				Context context = new Context();
				Integer rejectCount = utsapproval.getRejectionCount();
				String ccEmails = null;
				// Set your template context here
				context.setVariable("projectName",projectName);	
				context.setVariable("Date",DateConverter.changeDate(utsapproval.getPmApprovalDate()));	
				context.setVariable("months",month);											
				context.setVariable("pmName",project.getPmName());
				
				if(project.getAccountId() != null) {
					accnt = accountRepository.getOne(project.getAccountId());
					if(accnt != null) {
						if(accnt.getAhId() != null) {
						resourceAh = resourceController.findResource(accnt.getAhId());	
						if(resourceAh != null) {
							ahEmail = resourceAh.getEmail();
							context.setVariable("ahName",resourceAh.getTitle());	
						}
						}
					}
				}							
				
				Integer loggedInUid = (Integer) session.getAttribute("loggedInUid");		
				//System.out.println("IN update==");
				//System.out.println("uid=="+loggedInUid);
				//System.out.println("PMid=="+project.getProjectManagersId());
				//System.out.println("AHid=="+project.getOwnersId());
				//System.out.println("DMid=="+portfolio.getOwnerId());
		
				if(utsapproval.getPmApprovalNotes() != null)
				{
					context.setVariable("comment",utsapproval.getPmApprovalNotes());					
				}else{
					context.setVariable("comment","");
				}
				
				String projectApproved;String projectRejected;
				if(loggedInUid.equals(accnt.getAhId())){//approve-reject by AH
					 projectApproved = projectName+" - "+month +" TS Approved by AH";
					 projectRejected = projectName+" - "+month +" TS Rejected by AH";
				}/*else if(loggedInUid.equals(portfolio.getOwnerId())){
					 projectApproved = projectName+" - "+month +" TS Approved by PH";
					 projectRejected = projectName+" - "+month +" TS Rejected by PH";
				}*/else{//approve-reject by PM
					 projectApproved = projectName+" - "+month +" TS Approved by PM";
					 projectRejected = projectName+" - "+month +" TS Rejected by PM (Reject Count -"+rejectCount+")";
				}
		
				
				String pmEmail = resourcePm.getEmail();
				String dmEmail = resourceDm.getEmail();
				String accountType = accnt.getStrategic();
				Integer accountId = project.getAccountId();
				
				if(accountType.equals("Internal")) // check for all internal accounts 
				{
					 ccEmails = pmEmail;
					if(utsapproval.getPmApprovalStatus() == 0)
					{
						smtpMailSender.send("",dmEmail,projectRejected,"mail/projectRejectByPm", context,ccEmails,request);					
					}else{
						smtpMailSender.send("",dmEmail,projectApproved,"mail/projectApproveByPm", context,ccEmails,request);					
					}
				}
				else
				{
				
					if(pmEmail !=null) {						
						ccEmails = pmEmail;						
					}										
					
					if(dmEmail !=null) {						
						ccEmails = ccEmails.concat(","+dmEmail);
					}					
					
					if(ahEmail !=null) {						
						ccEmails = ccEmails.concat(","+ahEmail);						
					}				
					
					if(utsapproval.getPmApprovalStatus() == 0)//reject
					{
						if(loggedInUid.equals(accnt.getAhId())){//by ah
							smtpMailSender.send("",LoadConstant.INVOICES,projectRejected,"mail/projectRejectByAh", context,ccEmails,request);
						}/*else if(loggedInUid.equals(portfolio.getOwnerId())){//by ph
							smtpMailSender.send("",LoadConstant.INVOICES,projectRejected,"mail/projectRejectByDm", context,ccEmails,request);
						}*/else{//by pm
							smtpMailSender.send("",LoadConstant.INVOICES,projectRejected,"mail/projectRejectByPm", context,ccEmails,request);
						}
											
					}else{//approve
						if(loggedInUid.equals(accnt.getAhId())){//by ah
							smtpMailSender.send("",LoadConstant.INVOICES,projectApproved,"mail/projectApproveByAh", context,ccEmails,request);		
						}/*else if(loggedInUid.equals(portfolio.getOwnerId())){//by ph
							smtpMailSender.send("",LoadConstant.INVOICES,projectApproved,"mail/projectApproveByDm", context,ccEmails,request);
						}*/else{//by pm
							smtpMailSender.send("",LoadConstant.INVOICES,projectApproved,"mail/projectApproveByPm", context,ccEmails,request);		
						}
									
					}	
				}
			}
			
//			// Check for DM approvel
//			if(utsapproval.getDmApprovedBy() != null)
//			{
//				if(utsapproval.getDmApprovalStatus() == 0)
//				{
//					Project project = projectController.getProject(utsapproval.getProjectId());
//					Resource resourcePm = resourceController.findResource(project.getProjectManagersId());
//					Resource resourceDm = resourceController.findResource(project.getOwnerId());
//
//					Context context = new Context();
					// Set your template context here

//					context.setVariable("projectName",utsapproval.getProjectName());	
//					context.setVariable("dmApprovalDate",DateConverter.changeDate(utsapproval.getDmApprovalDate()));	
//					context.setVariable("months",DateConverter.theMonth(utsapproval.getMonth()));											
////					context.setVariable("pmEmail",resourcePm.getEmail());
////					context.setVariable("dmEmail",resourceDm.getEmail());
//					context.setVariable("DmName",project.getOwnerText());
			
//					if(utsapproval.getPmApprovalNotes() != null)
//					{
//						context.setVariable("comment",utsapproval.getPmApprovalNotes());					
//					}else{
//						context.setVariable("comment","");
//					}
					//smtpMailSender.send("",resourcePm.getEmail(),"Project Rejected By DM","mail/projectRejectByDm", context,resourceDm.getEmail(),request);
					//smtpMailSender.send("","sshrikhande1@infocepts.com","Project Rejected By DM","mail/projectRejectByDm", context,"sshrikhande@infocepts.com",request);				
//				}else{
//					Project project = projectController.getProject(utsapproval.getProjectId());
//					Resource resourcePm = resourceController.findResource(project.getProjectManagersId());
//					Resource resourceDm = resourceController.findResource(project.getOwnerId());
//
//					Context context = new Context();
					// Set your template context here

//					context.setVariable("projectName",utsapproval.getProjectName());	
//					context.setVariable("dmApprovalDate",DateConverter.changeDate(utsapproval.getDmApprovalDate()));	
//					context.setVariable("months",DateConverter.theMonth(utsapproval.getMonth()));
////					context.setVariable("pmEmail",resourcePm.getEmail());
////					context.setVariable("dmEmail",resourceDm.getEmail());
//					context.setVariable("DmName",project.getOwnerText());
			
//					if(utsapproval.getPmApprovalNotes() != null)
//					{
//						context.setVariable("comment",utsapproval.getPmApprovalNotes());					
//					}else{
//						context.setVariable("comment","");
//					}
					//smtpMailSender.send("",resourcePm.getEmail(),"Project Approved By DM","mail/projectApproveByDm", context,resourceDm.getEmail(),request);					
					//smtpMailSender.send("","sshrikhande1@infocepts.com","Project Approved By DM","mail/projectApproveByDm", context,"sshrikhande@infocepts.com",request);			
//				}			
//			}
		}catch(Exception e){
			logger.log(Level.SEVERE, "Error in Timesheet Approval Update ", e);
		}
		return utsapproval;
	}
	
	@RequestMapping(value="/{tsapprovalId}",method=RequestMethod.DELETE)
	public void deleteTimesheetApproval(@PathVariable Integer tsapprovalId) {
		try{
			 repository.delete(tsapprovalId);
		 }
		 catch(Exception e){
			 logger.log(Level.SEVERE, "Error in Timesheet delete ", e);
			// logger.error(e);
		 }
		
	}
	
	
	@GetMapping("/getTSExportData")
	public Object getTSExportData(@ModelAttribute TimesheetExportModel timesheetExportModel, HttpServletRequest request) {

		String tsmonth = timesheetExportModel.getTsmonth();
		String tsMonthStr = timesheetExportModel.getTsMonthStr();
		Integer pid = timesheetExportModel.getProjectId();
		List<Integer> associatePKList = timesheetExportModel.getAssociatePKList();

		String projectTitle = projectRepository.getProjectTitleById(pid);

		System.out.println(tsmonth);
		System.out.println(tsMonthStr);
		System.out.println(pid);
		System.out.println(associatePKList);
		List<TimesheetPeriods> timesheetPeriodsList = new ArrayList<>();
		List<TimesheetHours> tshoursByMonth = new ArrayList<>();
		List<TimesheetHours> tshoursByUser = new ArrayList<>();
		boolean exported = true;
		
		try {

			if (!tsmonth.equals("")) {
				Integer month = service.getMonth(tsmonth);
				Integer year = service.getYear(tsmonth);
				if (month != null && year != null) {
					timesheetPeriodsList.addAll(manager.createNamedQuery("getPeriodsForMonth", TimesheetPeriods.class).setParameter("year", year)
							.setParameter("month", month).getResultList());
				}
			}

			if (pid != 0) {
				if (!tsmonth.equals("")) {
					Integer month = service.getMonth(tsmonth);
					Integer year = service.getYear(tsmonth);
					if (month != null && year != null) {
						tshoursByMonth.addAll(manager
								.createNamedQuery("getTsHrsByProjectAndMonth", TimesheetHours.class)
								.setParameter("year", year).setParameter("month", month)
								.setParameter("monthStr", tsMonthStr).setParameter("pid", pid).getResultList());
					}
				}
			}

			if (StringUtils.isNotBlank(tsmonth)) {
				Integer month = service.getMonth(tsmonth);
				Integer year = service.getYear(tsmonth);
				if (year != null && month != null) // for month
				{
					if (CollectionUtils.isNotEmpty(associatePKList)) {
						for (Integer uid : associatePKList) {
							tshoursByUser.addAll(manager
									.createNamedQuery("getWkTsHrsSummaryByUserAndMonth", TimesheetHours.class)
									.setParameter("uid", uid).setParameter("pid", pid).setParameter("year", year)
									.setParameter("month", month).setParameter("monthStr", tsMonthStr).getResultList());
						}
					}
				}
			}

		} catch (Exception e) {
			exported = false;
			if (timesheetPeriodsList.isEmpty()) {
				throw new RuntimeException("Something went wrong while fetching Timesheet period list!");
			} else if (tshoursByMonth.isEmpty()) {
				throw new RuntimeException("Something went wrong while fetching Timesheet hours by Month!");
			} else if (tshoursByUser.isEmpty()) {
				throw new RuntimeException("Something went wrong while fetching Timesheet hours by User!");
			}
		}
		String fileName = "TS_Export_" + projectTitle;
		
		File tsExportFile = AbstractTimesheetFileHandling.exportTimesheetToExcel(timesheetPeriodsList, tshoursByMonth, tshoursByUser, projectTitle, fileName);
		if (AbstractTimesheetFileHandling.FILE_CACHE.size() > 0) { 
			AbstractTimesheetFileHandling.FILE_CACHE.clear();
		} 
		AbstractTimesheetFileHandling.FILE_CACHE.add(tsExportFile);
		return exported;
	}
		
	@GetMapping("/customizedTSExcelExport")
	public void export(HttpServletRequest request, HttpServletResponse response) {
		File toExcel = null;
		try {
			if (AbstractTimesheetFileHandling.FILE_CACHE.size() == 1) {
				toExcel = AbstractTimesheetFileHandling.FILE_CACHE.get(0);
				Path path = Paths.get(toExcel.toString());
				response.addHeader(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + toExcel.getName() + ".xlsx");
				Files.copy(path, response.getOutputStream());
				response.getOutputStream().flush();
				Files.deleteIfExists(path);
			}
		} catch (Exception e) {
			logger.log(Level.SEVERE, "COULD NOT EXPORT EXCEL ", e);
		}
	}
}
