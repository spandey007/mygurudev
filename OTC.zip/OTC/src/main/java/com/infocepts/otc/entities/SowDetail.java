package com.infocepts.otc.entities;

import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.SqlResultSetMappings;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.infocepts.otc.utilities.LoadConstant;

@Entity
@Table(catalog=LoadConstant.otc, schema="[dbo]",name="sowDetail")
@SqlResultSetMappings({
	@SqlResultSetMapping(
		      name = "get_sowdetails",
		      classes = {
		          @ConstructorResult(
		              targetClass = SowDetail.class,
		              columns = {
		                  @ColumnResult(name = "sowDetailId"),
		                  @ColumnResult(name = "infoceptsRole", type=String.class),
		                  @ColumnResult(name = "clientRole", type=String.class),
		                  @ColumnResult(name = "sowRoleStartDate", type=Date.class),
		                  @ColumnResult(name = "sowRoleEndDate", type=Date.class),
		                  @ColumnResult(name = "reqStartDate", type=Date.class),
		                  @ColumnResult(name = "reqEndDate", type=Date.class),
		                  @ColumnResult(name = "treqId"),
		                  @ColumnResult(name = "treqStatus", type=String.class),
		                  @ColumnResult(name = "skillName", type=String.class),
		                  @ColumnResult(name = "priority", type=String.class),
		                  @ColumnResult(name = "billableRate", type=BigDecimal.class),	                  
		                  @ColumnResult(name = "expectedBillability", type=BigDecimal.class),            
		                  @ColumnResult(name = "expectedDays", type=BigDecimal.class),	
		                  @ColumnResult(name = "status", type=String.class),
		                  //@ColumnResult(name = "description", type=String.class),
		                  @ColumnResult(name = "comments", type=String.class),	                  
		                  @ColumnResult(name = "sowMilestoneId"),	                  
		                  @ColumnResult(name = "sowId"),
		                  @ColumnResult(name = "resourceName", type=String.class),
		                  @ColumnResult(name = "sharepointAccountId"),
		                  @ColumnResult(name = "createdDate", type=Date.class),
		                  @ColumnResult(name = "modifiedDate", type=Date.class),
		                  @ColumnResult(name = "createdBy"),
		                  @ColumnResult(name = "modifiedBy"),
		                  @ColumnResult(name = "cost", type=BigDecimal.class),
		                  @ColumnResult(name = "amount", type=BigDecimal.class),
		                  @ColumnResult(name = "isBillable", type=Boolean.class),
		                  @ColumnResult(name = "unitId", type=Integer.class),
		                  @ColumnResult(name = "countryId", type=Integer.class),
		                  @ColumnResult(name = "countryName", type=String.class),
		                  @ColumnResult(name = "unitName", type=String.class),
		                  @ColumnResult(name = "uomName", type=String.class),
		                  @ColumnResult(name = "currencySign", type=String.class),
		                  @ColumnResult(name = "associateLevelId"),
		                  @ColumnResult(name = "cityId"),
		                  @ColumnResult(name = "associateLevelName", type=String.class),
		                  @ColumnResult(name = "cityName", type=String.class),
		                  @ColumnResult(name = "roleId"),
		                  @ColumnResult(name = "reasonForCancellation"),
		                  @ColumnResult(name = "documentTypeId"),
		                  @ColumnResult(name = "probability", type=String.class),
		                  @ColumnResult(name = "existingAssociateName", type=String.class),
		                  @ColumnResult(name = "extension", type=Boolean.class)
		                }
		          )
		      }
	)
})
	@NamedNativeQueries({
	  @NamedNativeQuery(
	            name    =   "getSowDetailsForProject",
	            query   =   "select sd.*, c.countryName, u.name as unitName, uom.name as uomName, cur.sign as currencySign,"+
	            			" getDate() as reqStartDate, getDate() as reqEndDate, null as treqId, t.status as treqStatus, '' as priority," +
	            			" '' as skillName, s.documentTypeId"+ 
	            			",obj_amgRoles.amgRoleName as infoceptsRole"+
	            			", obj_city.cityName as cityName, g.grade as associateLevelName, '' as existingAssociateName, 0 as extension"+
	            		 	" FROM " + LoadConstant.otc + ".[dbo].sowDetail sd "+
	            		 	" left join " + LoadConstant.otc + ".[dbo].sow s on s.sowId = sd.sowId"+
	            		 	" left join " + LoadConstant.infomaster + ".[dbo].uom uom on uom.uomId = s.uomId"+
	            		 	" left join " + LoadConstant.infomaster + ".[dbo].currency cur on cur.currencyId = s.currencyId"+
	            		 	" left join " + LoadConstant.infomaster + ".[dbo].country c on c.countryId = sd.countryId"+
	            		 	" left join " + LoadConstant.infomaster + ".[dbo].unit u on u.unitId = sd.unitId"+
	            		 	" left join " + LoadConstant.infomaster + ".[dbo].city obj_city on obj_city.cityId = sd.cityId"+
	            		 	" left join " + LoadConstant.infomaster + ".[dbo].grade g on g.gradeId = sd.associateLevelId"+
	            		 	" left join " + LoadConstant.infomaster + ".[dbo].amgRoles obj_amgRoles on obj_amgRoles.amgRoleId=sd.roleId"+
	            		 	//" left join " + LoadConstant.infomaster + ".[dbo].associateLevel obj_associateLevel on obj_associateLevel.obj_associateLevelId = sd.obj_associateLevel"+ 
	                        " WHERE s.projectId= :projectId",
	                        resultClass=Sow.class, resultSetMapping = "get_sowdetails"                       		
	    ),
	   @NamedNativeQuery(
	            name    =   "getSowDetailsJoinedWithTreqsForProject",
	            query   =   "select sd.*, c.countryName, u.name as unitName, uom.name as uomName, cur.sign as currencySign,"+
	            			" t.reqStartDate as reqStartDate, t.reqEndDate as reqEndDate, t.treqId as treqId, t.status as treqStatus, t.priority," +
	            			" sk.skillName as skillName, s.documentTypeId"+ 
	            			",obj_amgRoles.amgRoleName as infoceptsRole"+
	            			", obj_city.cityName as cityName, g.grade as associateLevelName, rc.title as existingAssociateName, t.extension"+
	            		 	" FROM " + LoadConstant.otc + ".[dbo].sowDetail sd "+
	            		 	" left join " + LoadConstant.otc + ".[dbo].treq t on t.sowDetailId = sd.sowDetailId"+
	            		 	" left join " + LoadConstant.otc + ".[dbo].sow s on s.sowId = sd.sowId"+
	            		 	" left join " + LoadConstant.infomaster + ".[dbo].uom uom on uom.uomId = s.uomId"+
	            		 	" left join " + LoadConstant.infomaster + ".[dbo].currency cur on cur.currencyId = s.currencyId"+
	            		 	" left join " + LoadConstant.infomaster + ".[dbo].country c on c.countryId = sd.countryId"+
	            		 	" left join " + LoadConstant.infomaster + ".[dbo].unit u on u.unitId = sd.unitId"+
	            		 	" left join " + LoadConstant.infomaster + ".[dbo].skill sk on sk.skillId = t.skillId"+
	            		 	" left join " + LoadConstant.infomaster + ".[dbo].city obj_city on obj_city.cityId = sd.cityId"+
	            		 	" left join " + LoadConstant.infomaster + ".[dbo].grade g on g.gradeId = sd.associateLevelId"+
	            		 	" left join " + LoadConstant.infomaster + ".[dbo].amgRoles obj_amgRoles on obj_amgRoles.amgRoleId=sd.roleId"+
            				" left join " + LoadConstant.infomaster + ".[dbo].resource rc on rc.uid=t.existingAssociateId"+
	            		 	//" left join " + LoadConstant.infomaster + ".[dbo].associateLevel obj_associateLevel on obj_associateLevel.obj_associateLevelId = sd.obj_associateLevel"+ 
	                        " WHERE s.projectId= :projectId",
	                        resultClass=Sow.class, resultSetMapping = "get_sowdetails"                       		
	    ),
	   @NamedNativeQuery(
	            name    =   "getSowDetailsById",
	            query   =   "select sd.*, c.countryName, u.name as unitName, uom.name as uomName, cur.sign as currencySign,"+
	            			" getDate() as reqStartDate, getDate() as reqEndDate, null as treqId, '' as treqStatus, '' as priority," +
	            			" '' as skillName, s.documentTypeId"+ 
	            			",obj_amgRoles.amgRoleName as infoceptsRole"+
	            			", obj_city.cityName as cityName, g.grade as associateLevelName, '' as existingAssociateName, 0 as extension"+
	            		 	" FROM " + LoadConstant.otc + ".[dbo].sowDetail sd "+
	            		 	" left join " + LoadConstant.otc + ".[dbo].sow s on s.sowId = sd.sowId"+
	            		 	" left join " + LoadConstant.infomaster + ".[dbo].uom uom on uom.uomId = s.uomId"+
	            		 	" left join " + LoadConstant.infomaster + ".[dbo].currency cur on cur.currencyId = s.currencyId"+
	            		 	" left join " + LoadConstant.infomaster + ".[dbo].country c on c.countryId = sd.countryId"+
	            		 	" left join " + LoadConstant.infomaster + ".[dbo].unit u on u.unitId = sd.unitId"+
	            		 	" left join " + LoadConstant.infomaster + ".[dbo].city obj_city on obj_city.cityId = sd.cityId"+
	            		 	" left join " + LoadConstant.infomaster + ".[dbo].grade g on g.gradeId = sd.associateLevelId"+
	            		 	" left join " + LoadConstant.infomaster + ".[dbo].amgRoles obj_amgRoles on obj_amgRoles.amgRoleId=sd.roleId"+
	            		 	//" left join " + LoadConstant.infomaster + ".[dbo].associateLevel obj_associateLevel on obj_associateLevel.obj_associateLevelId = sd.obj_associateLevel"+ 
	                        " WHERE sd.sowDetailId= :sowDetailId",
	                        //" AND sd.status = :status"
	                        resultClass=Sow.class, resultSetMapping = "get_sowdetails"                       		
	    ),
	   @NamedNativeQuery(
	            name    =   "getSowDetailsBySowId",
	            query   =   "select sd.*, c.countryName, u.name as unitName, uom.name as uomName, cur.sign as currencySign,"+
	            			" getDate() as reqStartDate, getDate() as reqEndDate, null as treqId, '' as treqStatus, '' as priority," +
	            			" '' as skillName, s.documentTypeId"+ 
	            			",obj_amgRoles.amgRoleName as infoceptsRole"+
	            			", obj_city.cityName as cityName, g.grade as associateLevelName, '' as existingAssociateName, 0 as extension"+
	            		 	" FROM " + LoadConstant.otc + ".[dbo].sowDetail sd "+
	            		 	" left join " + LoadConstant.otc + ".[dbo].sow s on s.sowId = sd.sowId"+
	            		 	" left join " + LoadConstant.infomaster + ".[dbo].uom uom on uom.uomId = s.uomId"+
	            		 	" left join " + LoadConstant.infomaster + ".[dbo].currency cur on cur.currencyId = s.currencyId"+
	            		 	" left join " + LoadConstant.infomaster + ".[dbo].country c on c.countryId = sd.countryId"+
	            		 	" left join " + LoadConstant.infomaster + ".[dbo].unit u on u.unitId = sd.unitId"+
	            		 	" left join " + LoadConstant.infomaster + ".[dbo].city obj_city on obj_city.cityId = sd.cityId"+
	            		 	" left join " + LoadConstant.infomaster + ".[dbo].grade g on g.gradeId = sd.associateLevelId"+
	            		 	" left join " + LoadConstant.infomaster + ".[dbo].amgRoles obj_amgRoles on obj_amgRoles.amgRoleId=sd.roleId"+
	            		 	//" left join " + LoadConstant.infomaster + ".[dbo].associateLevel obj_associateLevel on obj_associateLevel.obj_associateLevelId = sd.obj_associateLevel"+ 
	                        " WHERE (:isRevenuePlanning = 0 and s.sowId= :sowId) or ( s.sowId= :sowId and :isRevenuePlanning = 1 and sd.sowRoleEndDate > getDate() and sd.isBillable = 1)",
	                        //" AND sd.status = :status"
	                        resultClass=Sow.class, resultSetMapping = "get_sowdetails"                       		
	    ),
	   @NamedNativeQuery(
	            name    =   "getSowDetailsForProjectWithMonthStartDateEndDate",
	            query   =   "select sd.*, c.countryName, u.name as unitName, uom.name as uomName, cur.sign as currencySign,"+
	            		" getDate() as reqStartDate, getDate() as reqEndDate, null as treqId, '' as treqStatus, '' as priority," +
	            		" '' as skillName, s.documentTypeId"+ 
	            		",obj_amgRoles.amgRoleName as infoceptsRole"+
	            		", obj_city.cityName as cityName, g.grade as associateLevelName, '' as existingAssociateName, 0 as extension"+
            		 	" FROM " + LoadConstant.otc + ".[dbo].sowDetail sd "+
            		 	" left join " + LoadConstant.otc + ".[dbo].sow s on s.sowId = sd.sowId"+
            		 	" left join " + LoadConstant.infomaster + ".[dbo].uom uom on uom.uomId = s.uomId"+
            		 	" left join " + LoadConstant.infomaster + ".[dbo].currency cur on cur.currencyId = s.currencyId"+
            		 	" left join " + LoadConstant.infomaster + ".[dbo].country c on c.countryId = sd.countryId"+
            		 	" left join " + LoadConstant.infomaster + ".[dbo].unit u on u.unitId = sd.unitId"+
            		 	" left join " + LoadConstant.infomaster + ".[dbo].city obj_city on obj_city.cityId = sd.cityId"+
            		 	" left join " + LoadConstant.infomaster + ".[dbo].grade g on g.gradeId = sd.associateLevelId"+
            		 	" left join " + LoadConstant.infomaster + ".[dbo].amgRoles obj_amgRoles on obj_amgRoles.amgRoleId=sd.roleId"+
            		 	//" left join " + LoadConstant.infomaster + ".[dbo].associateLevel obj_associateLevel on obj_associateLevel.obj_associateLevelId = sd.obj_associateLevel"+ 
                        " WHERE s.projectId= :projectId AND"+
            		 	//" (sowRoleStartDate between :firstmonth and :lastmonth)" +
            		 	" ( (sowRoleStartDate between :firstmonth and :lastmonth) or (sowRoleEndDate between :firstmonth and :lastmonth) or" +
            		 	"   (sowRoleStartDate >= :firstmonth AND sowRoleEndDate <= :lastmonth) or" +
            		 	"   (sowRoleStartDate < :firstmonth AND sowRoleEndDate > :lastmonth) )" +
                        " and sd.isBillable= :isBillable",
                        resultClass=Sow.class, resultSetMapping = "get_sowdetails"                      		
	    )
})
public class SowDetail {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer sowDetailId;
	
	@ManyToOne
	@JoinColumn(name="sowId")
	private Sow sow;
	
	@ManyToOne
	@JoinColumn(name="sowMilestoneId")
	private SowMilestone sowmilestone;
	
	@Transient
	private String infoceptsRole;//later this to be replaced by FK for roleId
	
	private Integer roleId;
	
	private Date sowRoleStartDate;
	private Date sowRoleEndDate;
	
	@Column(precision=12,scale=2)
	private BigDecimal billableRate;//for T&M 
	@Column(precision=6,scale=4)
	private BigDecimal expectedBillability;//for T&M 
	@Column(precision=6,scale=2)
	private BigDecimal expectedDays;
	
	private Integer countryId;
	private Integer unitId;
	
	private Integer associateLevelId;
	private Integer cityId;
	
	@Lob
	private String comments;	
	
	private Integer createdBy;
	private Integer modifiedBy;
	private Date createdDate;
	private Date modifiedDate;
	
	private String resourceName; // rkj - temp variables, delete after migration
	private Integer sharepointAccountId;  // rkj - temp variables, delete after migration
		
	@Column(precision=12,scale=2)
	private BigDecimal cost;
	
	@Column(precision=12,scale=2)
	private BigDecimal amount; 	
	
	private Boolean isBillable;
	
	private String status; // Proposed or Active
	
	// Different fields as compared to cmsDetails entity
	private String clientRole;
	
	@Transient
	private Integer accountId;
	
	@Transient
	private String countryName;
	
	@Transient
	private String unitName;
	
	@Transient
	private String uomName;
	
	@Transient
	private String currencySign;
	
	@Transient
	private Date reqStartDate;
	@Transient
	private Date reqEndDate;
	
	@Transient
	private Integer treqId;
	@Transient
	private String treqStatus;
	
	@Transient
	private String skillName;
	@Transient
	private String priority;
	
	@Transient
	private String associateLevelName;
	@Transient
	private String cityName;
	
	@Transient
	private Integer documentTypeId;
	
	private String reasonForCancellation;
	
	private String probability;
	
	@Transient
	private String existingAssociateName;
	
	@Transient
	private Boolean extension;
	
	//Getter and Setter
	//---------------------------------------------------------------------------------
	public Integer getSowDetailId() {
		return sowDetailId;
	}
	
	public void setSowDetailId(Integer sowDetailId) {
		this.sowDetailId = sowDetailId;
	}

	public String getClientRole() {
		return clientRole;
	}
	public void setClientRole(String clientRole) {
		this.clientRole = clientRole;
	}
	public Date getSowRoleStartDate() {
		return sowRoleStartDate;
	}
	public void setSowRoleStartDate(Date sowRoleStartDate) {
		this.sowRoleStartDate = sowRoleStartDate;
	}
	public Date getSowRoleEndDate() {
		return sowRoleEndDate;
	}
	public void setSowRoleEndDate(Date sowRoleEndDate) {
		this.sowRoleEndDate = sowRoleEndDate;
	}
	public BigDecimal getBillableRate() {
		return billableRate;
	}
	public void setBillableRate(BigDecimal billableRate) {
		this.billableRate = billableRate;
	}
	public BigDecimal getExpectedBillability() {
		return expectedBillability;
	}
	public void setExpectedBillability(BigDecimal expectedBillability) {
		this.expectedBillability = expectedBillability;
	}
	
	public BigDecimal getExpectedDays() {
		return expectedDays;
	}
	public void setExpectedDays(BigDecimal expectedDays) {
		this.expectedDays = expectedDays;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	public Integer getCountryId() {
		return countryId;
	}
	public void setCountryId(Integer countryId) {
		this.countryId = countryId;
	}
	
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public SowMilestone getSowmilestone() {
		return sowmilestone;
	}
	public void setSowmilestone(SowMilestone sowmilestone) {
		this.sowmilestone = sowmilestone;
	}
	public Sow getSow() {
		return sow;
	}
	public void setSow(Sow sow) {
		this.sow = sow;
	}
	public Integer getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}
	public Integer getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public Date getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	
	public String getResourceName() {
		return resourceName;
	}
	public void setResourceName(String resourceName) {
		this.resourceName = resourceName;
	}
	public Integer getSharepointAccountId() {
		return sharepointAccountId;
	}
	public void setSharepointAccountId(Integer sharepointAccountId) {
		this.sharepointAccountId = sharepointAccountId;
	}
	
	public String getSkillName() {
		return skillName;
	}

	public void setSkillName(String skillName) {
		this.skillName = skillName;
	}

	public String getPriority() {
		return priority;
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}

	public Integer getAccountId() {
		return accountId;
	}

	public void setAccountId(Integer accountId) {
		this.accountId = accountId;
	}

	public BigDecimal getAmount() {
		return amount;
	}
	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}	
	
	public BigDecimal getCost() {
		return cost;
	}
	public void setCost(BigDecimal cost) {
		this.cost = cost;
	}
	
	public Boolean getIsBillable() {
		return isBillable;
	}
	public void setIsBillable(Boolean isBillable) {
		this.isBillable = isBillable;
	}
	
	@Transient
	public String getUomName() {
		return uomName;
	}
	public void setUomName(String uomName) {
		this.uomName = uomName;
	}
	
	@Transient
	public String getCurrencySign() {
		return currencySign;
	}
	public void setCurrencySign(String currencySign) {
		this.currencySign = currencySign;
	}
	
	@Transient	
	public Date getReqStartDate() {
		return reqStartDate;
	}
	public void setReqStartDate(Date reqStartDate) {
		this.reqStartDate = reqStartDate;
	}
	@Transient
	public Date getReqEndDate() {
		return reqEndDate;
	}

	public void setReqEndDate(Date reqEndDate) {
		this.reqEndDate = reqEndDate;
	}
	@Transient
	public Integer getTreqId() {
		return treqId;
	}

	public void setTreqId(Integer treqId) {
		this.treqId = treqId;
	}
	@Transient
	public String getTreqStatus() {
		return treqStatus;
	}

	public void setTreqStatus(String treqStatus) {
		this.treqStatus = treqStatus;
	}

	public Integer getUnitId() {
		return unitId;
	}
	public void setUnitId(Integer unitId) {
		this.unitId = unitId;
	}
	
	public String getCountryName() {
		return countryName;
	}

	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}
	public String getUnitName() {
		return unitName;
	}

	public void setUnitName(String unitName) {
		this.unitName = unitName;
	}
	
	public Integer getAssociateLevelId() {
		return associateLevelId;
	}

	public void setAssociateLevelId(Integer associateLevelId) {
		this.associateLevelId = associateLevelId;
	}

	public Integer getCityId() {
		return cityId;
	}

	public void setCityId(Integer cityId) {
		this.cityId = cityId;
	}

	public String getAssociateLevelName() {
		return associateLevelName;
	}

	public void setAssociateLevelName(String associateLevelName) {
		this.associateLevelName = associateLevelName;
	}

	public String getCityName() {
		return cityName;
	}

	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
	
	public Integer getRoleId() {
		return roleId;
	}

	public void setRoleId(Integer roleId) {
		this.roleId = roleId;
	}
    //End of: Getter and Setter
	
	public String getInfoceptsRole() {
		return infoceptsRole;
	}

	public void setInfoceptsRole(String infoceptsRole) {
		this.infoceptsRole = infoceptsRole;
	}
	public String getReasonForCancellation() {
		return reasonForCancellation;
	}

	public void setReasonForCancellation(String reasonForCancellation) {
		this.reasonForCancellation = reasonForCancellation;
	}
	
	@Transient
	public Integer getDocumentTypeId() {
		return documentTypeId;
	}

	public void setDocumentTypeId(Integer documentTypeId) {
		this.documentTypeId = documentTypeId;
	}
	
	public String getProbability() {
		return probability;
	}

	public void setProbability(String probability) {
		this.probability = probability;
	}

	public String getExistingAssociateName() {
		return existingAssociateName;
	}

	public void setExistingAssociateName(String existingAssociateName) {
		this.existingAssociateName = existingAssociateName;
	}
	public Boolean getExtension() {
		return extension;
	}

	public void setExtension(Boolean extension) {
		this.extension = extension;
	}

	//Constructor(s)
	public SowDetail() {
	}	
	 
	public SowDetail(Integer sowDetailId, String infoceptsRole, String clientRole, Date sowRoleStartDate, Date sowRoleEndDate,
						Date reqStartDate, Date reqEndDate, Integer treqId, String treqStatus, String skillName, String priority,
						BigDecimal billableRate, BigDecimal expectedBillability, BigDecimal expectedDays,
						String status, String comments, Integer sowMilestoneId, Integer sowId,
						String resourceName, Integer sharepointAccountId,
						Date createdDate, Date modifiedDate, Integer createdBy, Integer modifiedBy,
						BigDecimal cost, BigDecimal amount, Boolean isBillable, Integer unitId, Integer countryId, 
						String countryName, String unitName, String uomName, String currencySign,
						Integer associateLevelId, Integer cityId, String associateLevelName, String cityName, Integer roleId,
						String reasonForCancellation, Integer documentTypeId, String probability, String existingAssociateName, Boolean extension
					)
	{
		this.sowDetailId = sowDetailId;
		this.infoceptsRole = infoceptsRole;
		this.clientRole = clientRole;
		this.sowRoleStartDate = sowRoleStartDate;
		this.sowRoleEndDate = sowRoleEndDate;
		this.reqStartDate = reqStartDate;
		this.reqEndDate = reqEndDate;
		this.billableRate = billableRate;
		this.expectedBillability = expectedBillability;
		this.expectedDays = expectedDays;
		this.status = status;
				
		this.comments = comments;
		
		if(sowMilestoneId != null)
		{
			this.sowmilestone = new SowMilestone();
			this.sowmilestone.setSowMilestoneId(sowMilestoneId);
		}
		if(sowId != null)
		{
			this.sow = new Sow();
			this.sow.setSowId(sowId);
		}
				
		this.createdDate = createdDate;
		this.modifiedDate = modifiedDate;
		this.createdBy = createdBy;		
		this.modifiedBy = modifiedBy;
		this.cost = cost;
		this.amount = amount;
		this.isBillable = isBillable;
		
		this.resourceName = resourceName;
		this.sharepointAccountId = sharepointAccountId;
		
		this.unitId = unitId;
		this.countryId = countryId;

		this.countryName = countryName;
		this.unitName = unitName;
		this.uomName = uomName;
		this.currencySign = currencySign;
		this.treqId = treqId;
		this.treqStatus = treqStatus;
		this.skillName = skillName;
		this.priority = priority;
		
		this.associateLevelId = associateLevelId;
		this.cityId = cityId;
		this.associateLevelName = associateLevelName;
		this.cityName = cityName;
		this.roleId = roleId;
		this.reasonForCancellation = reasonForCancellation;
		
		this.documentTypeId = documentTypeId;
		this.probability = probability;
		this.existingAssociateName = existingAssociateName;
		this.extension = extension;
	}
}
