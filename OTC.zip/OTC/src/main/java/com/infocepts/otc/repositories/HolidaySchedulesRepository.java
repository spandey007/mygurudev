package com.infocepts.otc.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.infocepts.otc.entities.HolidaySchedules;
import com.infocepts.otc.entities.InvoicesDetail;
import com.infocepts.otc.utilities.LoadConstant;


public interface HolidaySchedulesRepository extends JpaRepository<HolidaySchedules,Integer>{

	@Override
	public List<HolidaySchedules> findAll();
	
	@Query(value = "select * from "+LoadConstant.infomaster+".dbo.holidaySchedules hc where hc.countryId=(select countryId from "+LoadConstant.infomaster+".dbo.city where cityId = :cityId)", nativeQuery = true)
	public HolidaySchedules findByCityId(@Param("cityId") Integer cityId);
}
