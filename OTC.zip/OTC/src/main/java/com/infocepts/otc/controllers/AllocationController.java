package com.infocepts.otc.controllers;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.mail.MessagingException;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.thymeleaf.context.Context;

import com.infocepts.otc.entities.Account;
import com.infocepts.otc.entities.Allocation;
import com.infocepts.otc.entities.MonthlyAllocation;
import com.infocepts.otc.entities.Project;
import com.infocepts.otc.entities.Resource;
import com.infocepts.otc.entities.SowDetail;
import com.infocepts.otc.notification.SmtpMailSender;
import com.infocepts.otc.repositories.AccountRepository;
import com.infocepts.otc.repositories.AllocationRepository;
import com.infocepts.otc.repositories.ProjectRepository;
import com.infocepts.otc.repositories.SowDetailRepository;
import com.infocepts.otc.services.MonthlyAllocationService;
import com.infocepts.otc.services.StoredProcedureService;
import com.infocepts.otc.services.TimesheetService;



@RestController
@RequestMapping(value="/allocation",headers="referer")//JV: Added 'headers' param to validate the url.
public class AllocationController {
	
	final Logger logger = Logger.getLogger(AllocationController.class);

	@Autowired
	AllocationRepository repository;
	
	@Autowired
	ProjectRepository projectRepository;
	
	@Autowired
	AccountRepository accountRepository;
	
	@Autowired
	MonthlyAllocationService monthlyAllocationService;
	
	@Autowired
	TimesheetService service;
	
	@Autowired
	HttpSession session;
	
	@Autowired
	SmtpMailSender smtpMailSender;
	
	
	@Autowired 
	StoredProcedureService storedProcedureService;

	
	@PersistenceContext(unitName="otc")
    private EntityManager manager;
	
	@RequestMapping(method=RequestMethod.POST)
	public Allocation addAllocation(@RequestBody Allocation newallocation, HttpServletRequest request) throws MessagingException{
		try{
			if(service.isAMG()){
			newallocation.setAlcId(null);
			repository.save(newallocation);
			}
			//Populate Monthly Allocation 
			//monthlyAllocationService.InsertUpdateMonthlyAllocation(newallocation);
			
			//Populate Monthly Allocation
			storedProcedureService.GenerateMonthlyAllocation(newallocation.getAlcId());
			
			service.sendAllocationNotification(newallocation, "add", request); // Allocation add / update solution	
		}
		catch(Exception e){
			logger.error(e);
		}
		return newallocation;
	}

	@RequestMapping(method=RequestMethod.GET)
	 public List<Allocation> getAllAllocation(@RequestParam(value = "projectId", defaultValue = "0") Integer projectId,
			 								  @RequestParam(value = "accountId", defaultValue = "0") Integer accountId,
			 							      @RequestParam(value = "allocationType", defaultValue = "") String allocationType,
			 							      @RequestParam(value = "sowDetailId", defaultValue = "0") Integer sowDetailId,
			 							      @RequestParam(value = "treqId", defaultValue = "0") Integer treqId,
			 							      @RequestParam(value = "month", defaultValue = "0") Integer month,
			 							      @RequestParam(value = "year", defaultValue = "0") Integer year,
			 							      HttpServletRequest request) throws MessagingException {
		List<Allocation> allocationlist=null;
		
		/* ------------------------- Authorization start ------------------------------------ */
		Integer loggedInUid = (Integer) session.getAttribute("loggedInUid");
		// Authorization for passed projectId (project id)
		if(projectId != 0)
		{	
			Account accnt = null;
			Integer ahUid =0;
			Boolean isAValidCall = false;
			Project proj = projectRepository.getOne(projectId);
			
			if(proj.getAccountId() != null) {
				accnt = accountRepository.getOne(proj.getAccountId());
				if(accnt != null) {
					ahUid = accnt.getAhId();					
				}
			}
			if(proj != null)
			{
				String planners = proj.getPlannersId();
				List<String> strList = new ArrayList<String>(Arrays.asList(planners.split(",")));
				List<Integer> intList = new ArrayList<Integer>();
				for(String s : strList) intList.add(Integer.valueOf(s));
				
				Integer pmUid = proj.getProjectManagersId();
				if(loggedInUid.equals(pmUid)) // If the current logged in user is not the project manager of the passed project (pid)
				{
					isAValidCall = true;
				}
				else if(loggedInUid.equals(ahUid)) // If the current logged in user is not the account head of the passed project (pid)
				{
					isAValidCall = true;
				}
				else if(intList.contains(loggedInUid)){ //if the loggedInUser is a Project Planner he will also have access to allocations
			    	isAValidCall = true;
				}
				else if(service.isAValidAdminRole())
				{
					isAValidCall = true;
				}
				else if(service.isDE()) {
					isAValidCall = true;
				}
			
				if(isAValidCall == false)
				{	
					service.sendTamperedMail("Allocations By Project", 0, projectId, request);
					throw new IllegalArgumentException("Access Denied");					
				}
			}
		}
		// Authorization for passed accountId
		if(accountId != 0 && accountId != 1)
		{
			Boolean isAValidCall = false;
			if(service.isAMG() || service.isAdmin())
			{
				isAValidCall = true;
			}
			if(isAValidCall == false)
			{	
				service.sendTamperedMail("Soft Allocations By Account", 0, accountId, request);
				return allocationlist;
			}
		}
		
		try{
			Integer alcType = 0;
	 		if(allocationType.equals("billable")) alcType = 1; 
	 		if(allocationType.equals("billed-buffer")) alcType = 4;
	 		if(allocationType.equals("non-billable-buffer")) alcType = 2;
	 		if(allocationType.equals("non-billable-trainee")) alcType = 3;
	 		if(allocationType.equals("non-billable")) alcType = 20;// unreal alcType value to fetch all NB allocation types ie(2,3)

	 		
	 		if(accountId != 0 && accountId !=1) // added "accountId!=1" for break the condition for DE allocation list
		 	{
		 		if(accountId == -1) accountId = 0;// Fetch soft allocations for all accounts
		 		
		 		allocationlist = manager.createNamedQuery("getSoftAllocationsForAccount", Allocation.class)
						 .setParameter("accountId", accountId)
						 .setParameter("alcType", alcType)
						 .getResultList();
		 	}
	 		else if(projectId != 0 && month !=0 && year !=0)
		 	{		 		
		 		allocationlist = manager.createNamedQuery("getAllocationsWithAllocatedHrs", Allocation.class)
						 .setParameter("projectId", projectId)
						 .setParameter("month", month)
						 .setParameter("year", year)
						 .getResultList();
		 	}
	 		else if(projectId != 0)
		 	{		 		
		 		allocationlist = manager.createNamedQuery("getAllocationsForProject", Allocation.class)
						 .setParameter("projectId", projectId)
						 .setParameter("alcType", alcType)
						 .getResultList();
		 	}
	 		else if(sowDetailId != 0 && treqId != 0)
		 	{
	 			allocationlist = manager.createNamedQuery("getAllocationsBySowDetailId", Allocation.class)
						 .setParameter("sowDetailId", sowDetailId)
						 .setParameter("treqId", treqId)
						 .getResultList();
		 	}
		 	
	 }
	 catch(Exception e){
		 logger.error(e);
	 }
		return allocationlist;
	 }
	 
	 @RequestMapping(value="/{alcId}",method=RequestMethod.GET)
	 public Allocation getAllocation(@PathVariable Integer alcId){	
		 Allocation allocation = null;
		 try{
			 allocation = manager.createNamedQuery("getAllocationById", Allocation.class)
					 .setParameter("alcId", alcId)
	                 .getSingleResult();
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return allocation;
	 } 	
	 
	 @RequestMapping(value="/{alcId}",method=RequestMethod.PUT)
	 public Allocation updateAllocation(@RequestBody Allocation updatedAllocation,@PathVariable Integer alcId, HttpServletRequest request) throws MessagingException{
		 try{
			 if(service.isAMG()){
			 updatedAllocation.setAlcId(alcId);
			 repository.save(updatedAllocation);			 
			 }
			//Populate Monthly Allocation
			//if(updatedAllocation.getUpdateMonthlyAllocation())
				 //monthlyAllocationService.InsertUpdateMonthlyAllocation(updatedAllocation);
			 
			//Populate Monthly Allocation
			if(updatedAllocation.getUpdateMonthlyAllocation())
				storedProcedureService.GenerateMonthlyAllocation(alcId);
			 
			 service.sendAllocationNotification(updatedAllocation, "update", request); // Allocation add / update solution
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return updatedAllocation;
	 }
	 
	 @RequestMapping(value="/{alcId}",method=RequestMethod.DELETE)
	 public void deleteAllocation(@PathVariable Integer alcId){
		 try{
			 if(service.isAMG()){
				 //Delete all monthly allocation rows first
				 monthlyAllocationService.DeleteMonthlyAllocation(alcId);
				 
				 //Delete allocation
				 repository.delete(alcId);
			 }
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
	 }
}

