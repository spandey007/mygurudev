package com.infocepts.otc.controllers;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.infocepts.otc.entities.AccountInfo;
import com.infocepts.otc.repositories.AccountInfoRepository;
import com.infocepts.otc.services.TimesheetService;




@RestController
@RequestMapping(value="/accountInfo",headers="referer")//JV: Added 'headers' param to validate the url.
public class AccountInfoController {
	
	final Logger logger = Logger.getLogger(AccountInfoController.class);

	@Autowired
	AccountInfoRepository repository;
	
	@Autowired
	HttpSession session;
	
	@Autowired
	TimesheetService service;
	
	@PersistenceContext(unitName="otc")
    private EntityManager manager;
	
	@RequestMapping(method=RequestMethod.GET)
	public List<AccountInfo> findAccountInfo(@RequestParam(value = "uid", defaultValue = "0") Integer uid,
			@RequestParam(value = "accountId", defaultValue = "0") Integer accountId,
			HttpServletRequest request){
		List<AccountInfo> accountinfolist=null;
		try{
			/* ------------------------- Authorization start ------------------------------------ */
			// Authorization for admin role
			if(!service.isAMG())
			{
				service.sendTamperedMail("AccountInfo view all", 0, 0, request);
				return accountinfolist;
			}
			/* ------------------------- Authorization ends ------------------------------------ */
			
			if(uid != 0)
			 {
				accountinfolist = repository.findAccountInfoByUid(uid);
			 }
			 else if(accountId != 0){				 
				 accountinfolist = repository.findAccountInfoByAccount(accountId);
			 }
			 else
			 {
				 accountinfolist = manager.createNamedQuery("getAllAccountInfo", AccountInfo.class) 
	                        		.getResultList();
				 
			 }
		}
		catch(Exception e){
			logger.error(e);
		}
		return accountinfolist;
	}
	
	@RequestMapping(value="/{accountInfoId}",method=RequestMethod.GET)
	 public AccountInfo getAccountInfoById(@PathVariable Integer accountInfoId){
		 AccountInfo accountInfo=null;
		 if(service.isAMG())
		 {
			 try{
				 accountInfo = repository.findOne(accountInfoId);
			 }
			 catch(Exception e){
				 logger.error(e);
			 }
		 }
		 return accountInfo;
	}
	
	@RequestMapping(method=RequestMethod.POST)
	public AccountInfo saveAccountInfo(@RequestBody AccountInfo accountInfo,HttpServletRequest request){
		try{
			/* ------------------------- Authorization start ------------------------------------ */
			// Authorization for amg role
			if(service.isAMG())
			{
				accountInfo.setAccountInfoId(null);
				repository.save(accountInfo);
			}
			else
			{
				service.sendTamperedMail("Account Info Save", 0, 0, request);
			}
			/* ------------------------- Authorization ends ------------------------------------ */	
			
		}
		catch(Exception e){
			logger.error(e);
		}
		return accountInfo;
	}
	
	@RequestMapping(value="/{accountInfoId}",method=RequestMethod.PUT)
	 public AccountInfo updateAccountInfo(@RequestBody AccountInfo updatedAccountInfo,@PathVariable Integer accountInfoId){
		if(service.isAMG())
		{
			 try{
				 updatedAccountInfo.setAccountInfoId(accountInfoId);
				 repository.save(updatedAccountInfo);
			 }
			 catch(Exception e){
				 logger.error(e);
			 }
		}
		return updatedAccountInfo;
	 }
		
	 @RequestMapping(value="/{accountInfoId}",method=RequestMethod.DELETE)
	 public void deleteAccountInfo(@PathVariable Integer accountInfoId,
			 						HttpServletRequest request){
		 try{
			/* ------------------------- Authorization start ------------------------------------ */
			// Authorization for admin role
			if(service.isAMG())
			{
				repository.delete(accountInfoId);
			}
			else
			{
				service.sendTamperedMail("Account Info Delete", 0, 0, request);
			}
			/* ------------------------- Authorization ends ------------------------------------ */			
		 }
		 catch(Exception e){
			logger.error(e);
		 }
	}	 
}
