package com.infocepts.otc.controllers;


import java.util.List;
import java.util.logging.Logger;

import javax.mail.MessagingException;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.infocepts.otc.entities.Grade;
import com.infocepts.otc.repositories.GradeRepository;
import com.infocepts.otc.services.TimesheetService;


@RestController
@RequestMapping(value="/grade",headers="referer")
public class GradeController {

	final Logger logger = Logger.getLogger(GradeController.class.getName());
	
	@Autowired
	GradeRepository repository;
	
    @PersistenceContext(unitName = "otc") 
    private EntityManager manager;
    
	@Autowired
	TimesheetService service;
    
	@RequestMapping(method=RequestMethod.GET)
	public List<Grade> getAllBands(@RequestParam(value = "band", defaultValue = "false") Boolean band
			,@RequestParam(value = "uid", defaultValue = "0") Integer uid
			,HttpServletRequest request) throws MessagingException{
		 List<Grade> gradeList=null;
		 
		/* ------------------------- Authorization start ------------------------------------ */
		// Authorization for passed uid (user id)
		if(uid != 0)
		{
			Boolean isAValidCall = false;
			isAValidCall = service.isAValidUserCall(uid);	
			
			if((isAValidCall == false) && (!service.isAdmin()))
			{
				service.sendTamperedMail("Grade List", uid, 0, request);
				return gradeList;
			}
		}
		/* ------------------------- Authorization ends ------------------------------------ */
					
		 try{
			 if(band){
				 gradeList = manager.createNamedQuery("getGradesWithBands", Grade.class) 				
                 .getResultList();
			 }else{
				 gradeList = repository.findAll();
			 }
			 
		 }
		 catch(Exception e){
			 logger.info(String.format("exception - ", e.getMessage()));
		 }
		 return gradeList;
	 }
}
