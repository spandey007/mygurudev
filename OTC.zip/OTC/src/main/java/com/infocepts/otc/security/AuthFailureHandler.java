package com.infocepts.otc.security;

import java.io.IOException;
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.authentication.SimpleUrlAuthenticationFailureHandler;
import org.springframework.stereotype.Component;
import com.infocepts.otc.controllers.AccessLockController;
import com.infocepts.otc.entities.AccessLock;

@Component
public class AuthFailureHandler extends SimpleUrlAuthenticationFailureHandler{

	@Autowired
	AccessLockController accessLockController;
	
	AccessLock accesslock = null;String username=null;int count=0;
	
	private static final Logger log = LoggerFactory.getLogger(AuthFailureHandler.class);
	
	
    @Override
	public void onAuthenticationFailure(HttpServletRequest request, HttpServletResponse response,
			AuthenticationException exception) throws IOException, ServletException {
    	// Retrieve the username entered
		username=request.getParameter("username");
		try
		{	
			AccessLock loggedInUser = accessLockController.getAccessLock(username); 
			// If this is the first time the user has entered wrong username and password
			if(loggedInUser == null)
			{
				// Creating access lock object
				accesslock = new AccessLock();
				accesslock.setCount(1);
				accesslock.setUsername(username);
				accesslock.setLastAttemptDate(new Date());
				accessLockController.addAccessLock(accesslock);
				if(!response.isCommitted()){
					response.sendRedirect("/login?error");
					return;
					}
			}
			else // There is already an entry in the access table for incorrect username password
			{
				// If the user is not locked, set locked status true after 5 un-successful attempt
				if(loggedInUser.isLocked() == false)
				{
					count=loggedInUser.getCount();
					
					if(count < 5) // If the count is less than 5
					{
						count = count + 1; // increament the count
						loggedInUser.setCount(count);
						if(count == 5) // If the count becomes 5 set the lock
						{				
							loggedInUser.setLocked(true);
						}
						loggedInUser.setLastAttemptDate(new Date());
						accessLockController.updateAccessLock(loggedInUser, loggedInUser.getAccessLockId());					
					}
				}
				if(!response.isCommitted()){
					response.sendRedirect("/login?error");
					return;
					}
				
			}
		}
		catch(Exception e){
			logger.error(e);
		}
		
	}
}
