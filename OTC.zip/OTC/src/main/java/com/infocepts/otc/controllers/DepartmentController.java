package com.infocepts.otc.controllers;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.infocepts.otc.entities.Department;
import com.infocepts.otc.repositories.DepartmentRepository;

@RestController
@RequestMapping(value="/department",headers="referer")
public class DepartmentController {

	final Logger logger = Logger.getLogger(DepartmentController.class);
	
    @PersistenceContext(unitName = "otc") 
    private EntityManager manager;
	
	@Autowired
	DepartmentRepository repository;
	
	@RequestMapping(method=RequestMethod.GET)
	 public List<Department> getAllDepartment(@RequestParam(value = "allParent", defaultValue = "false") Boolean allParent
			 	,@RequestParam(value = "pid", defaultValue = "0") Integer pid
				,HttpServletRequest request){
		 List<Department> departmentlist=null;
		 try{		
			 if(allParent){
				 departmentlist = manager.createNamedQuery("getParentDepartment", Department.class)   
	                        .getResultList();
			 }
			 else if(pid != 0) {
				 departmentlist = manager.createNamedQuery("getSubepartment", Department.class)  
						 .setParameter("pid", pid)
	                        .getResultList();
			 }
			 else
			 {
				 departmentlist = repository.findAll();
			 }
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return departmentlist;
	 }

}
