/**
* Filename: /src/main/java/com/infocepts/otc/repositories/ReleaseManagementDetailRepository.java
* @author  Anjali S. Kalbande
* @version 1.0
* @since   2018-01-08 
*/

package com.infocepts.otc.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import com.infocepts.otc.entities.ReleaseManagementDetail;

public interface ReleaseManagementDetailRepository extends JpaRepository<ReleaseManagementDetail, Integer> {

	@Override
	public List<ReleaseManagementDetail> findAll();
	
	@Query("from ReleaseManagementDetail where releaseItemId = :releaseItemId")
	public ReleaseManagementDetail findReleaseManagementDetailByreleaseItemId(@Param(value = "releaseItemId") Integer releaseItemId);
	
}
