/**
* Filename: /src/main/java/com/infocepts/otc/controllers/DeComplaintController.java
* @author  SHRI
* @version 1.0
* @since   2018-11-28 
*/

package com.infocepts.otc.controllers;

import java.util.logging.Logger;
import com.infocepts.otc.entities.DeComplaint;
import com.infocepts.otc.repositories.DeComplaintRepository;
import com.infocepts.otc.utilities.DateConverter;
import com.infocepts.otc.utilities.ExportUtil;
import com.infocepts.otc.services.TimesheetService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.mail.MessagingException;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.io.File;
import java.io.FileNotFoundException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

@RestController
@RequestMapping(value="/decomplaint",headers="referer")
public class DeComplaintController {

    final Logger logger = Logger.getLogger(DeComplaintController.class.getName());

    @Autowired
    DeComplaintRepository deComplaintRepository;
    
    @Autowired
    HttpSession session;

    @PersistenceContext(unitName = "otc") 
    private EntityManager manager;
			
	@Autowired
	ExportUtil exportUtil;
	
	@Autowired
	TimesheetService service;
	String path=null;
	String filepath="";
	
    @RequestMapping(method = RequestMethod.GET)
    public List<DeComplaint> findAll(@RequestParam(value = "view", defaultValue = "0") String view ,HttpServletRequest request) throws MessagingException{
         List<DeComplaint> DeComplaintList = null;
         Integer loggedInUid = (Integer) session.getAttribute("loggedInUid");
		 boolean isDEMember = false;
		 boolean isPMOMember = false;
		 //Get the user roles
		 String userRoles = session.getAttribute("userRoles") != null ? session.getAttribute("userRoles").toString() : "";
		 int uid = session.getAttribute("loggedInUid") != null ? Integer.valueOf(session.getAttribute("loggedInUid").toString()) : 0;
		 if(userRoles.toLowerCase().contains("de")) isDEMember = true;
		 if(userRoles.toLowerCase().contains("pmo")) isPMOMember = true;
		 
        try {

	   		 if( (view.equals("de") && isDEMember) || (view.equals("pmo") && isPMOMember) || (view.equals("dh") && uid == 512)){
	    		
	   			DeComplaintList = manager.createNamedQuery("getAllDeComplaintData", DeComplaint.class)
		 				.setParameter("uid", uid)
	    				.setParameter("view", view)
		 				.getResultList();
	        }else if(view.equals("pm") || view.equals("ph") || view.equals("cep")){
	        		DeComplaintList = manager.createNamedQuery("getAllDeComplaintData", DeComplaint.class)
			 				.setParameter("uid", uid)
	        				.setParameter("view", view)
			 				.getResultList();
		 	}

         } 
		catch (Exception e){
			e.printStackTrace();
			 logger.info(String.format("exception - ", e));
        }
        
        return DeComplaintList;

    }
    
    

	   @RequestMapping(value = "/{complaintId}", method=RequestMethod.GET)
	    public DeComplaint findDeComplaintId(@PathVariable("complaintId") Integer complaintId){
	        return this.deComplaintRepository.findOne(complaintId);
	    }
    
    /**
     * This method is add row in moduleName entity
     * 
     */
    @RequestMapping(method=RequestMethod.POST)
	public DeComplaint addDeComplaint(@RequestBody DeComplaint deComplaint, HttpServletRequest request) {
		// Authorization for XYZ role
			try{
				deComplaint.setComplaintId(null);
				deComplaintRepository.save(deComplaint);
				service.sendComplaintNotification(deComplaint, "add", request);

			}
			catch(Exception e){
				 logger.info(String.format("exception - ", e));
			}
		
		return deComplaint;
	}
//    
    
	@RequestMapping(value="/upload/{complaintId}/{indexvalue}",method=RequestMethod.POST,consumes = {"multipart/form-data"})
    @ResponseBody
	public String uploadFile(@RequestPart("file") MultipartFile file,@PathVariable(value = "complaintId") Integer complaintId,@PathVariable(value = "indexvalue") Integer indexvalue,HttpServletRequest request)
	{	
		
		DeComplaint complaint = deComplaintRepository.findOne(complaintId);
		String type ="complaints";
		path=exportUtil.getDeFilePath(file,request,complaintId,type);				
		if(indexvalue == 1) {
			complaint.setActionFilepath(path);
		}
		if(indexvalue == 0) {
			complaint.setFilepath(path);
		}		
		deComplaintRepository.save(complaint);
		return path;
	}
	
	@RequestMapping(value="/download/{complaintId}/{type}",method=RequestMethod.GET)
	public void download(@PathVariable(value = "complaintId") Integer complaintId,@PathVariable(value = "type") String type,HttpServletRequest request,HttpServletResponse response) throws ServletException, Exception {
		String path=null;
		File home=exportUtil.checkPath(request);
		String separator=File.separator;
		String Filepath = "";
		path=home.getPath();
		
		DeComplaint deComplaint =deComplaintRepository.findOne(complaintId);

		if(type.equals("complaint")) {
			Filepath = deComplaint.getFilepath();
		}else if(type.equals("action")) {
			Filepath = deComplaint.getActionFilepath();
		}

		
		List<String> list = Arrays.asList(Filepath.split("\\s*,\\s*"));
	
		if(list.size() > 1){
		
			if (home.exists() && home.isDirectory()) {
				 logger.info("home is a directory");
				    if(path.equals(separator)){
					 	path="usr"+File.separator+"home"+File.separator+"Download";
					}
					else{
						path=File.separator+"usr"+File.separator+"home"+File.separator+"Download";
					}
				
					if (Files.isDirectory(Paths.get(home + path))) {
						if(path.equals(separator)){
							path="usr"+File.separator+"home"+File.separator+"Download"+File.separator+"infotravel";
						}
						else{
							path=File.separator+"usr"+File.separator+"home"+File.separator+"Download"+File.separator+"infotravel";
						}
						
						if (Files.isDirectory(Paths.get(home + path))) {
							if(path.equals(separator)){
								path="usr"+File.separator+"home"+File.separator+"Download"+File.separator+"infotravel"+File.separator;
							}
							else{
								path=File.separator+"usr"+File.separator+"home"+File.separator+"Download"+File.separator+"infotravel"+File.separator;
							}
							
						} 
					}
				
			}
			
			
		}
		else{
			try{
				File outputFile = new File(Filepath);
				Path file = Paths.get(outputFile+"");
			    response.addHeader("Content-Disposition", "attachment; filename="+file.getFileName());
			    Files.copy(file, response.getOutputStream());
			    response.getOutputStream().flush();
			}
			catch(FileNotFoundException fe){
				fe.printStackTrace();
			}
		}
	}
	
	
//    
    /**
     * This method is update row in moduleName entity
     * based on primaryKey Of Module Table 
     */
	
    @RequestMapping(value="/{complaintId}",method=RequestMethod.PUT)
	 public DeComplaint updateDeComplaint(@RequestBody DeComplaint DeComplaint,@PathVariable Integer complaintId,HttpServletRequest request){
	
			try{
				 DeComplaint.setComplaintId(complaintId);
				 deComplaintRepository.save(DeComplaint);
				 /** For now we no need to send notification on update
				 service.sendComplaintNotification(DeComplaint, "update", request);
				 */

			}
			catch(Exception e){
				 logger.info(String.format("exception - ", e));
			}
		 return DeComplaint;
	 }

    
    /**
     * This method is delete data for specific row in moduleName entity
     * based on primaryKey Of Module Table 
     */	 
		@RequestMapping(value= "/{complaintId}",method=RequestMethod.DELETE)
		public void deleteDeComplaint(@PathVariable Integer complaintId, HttpServletRequest request) {
				try{
					if(complaintId!=null) {
						DeComplaint deComplaint = deComplaintRepository.findOne(complaintId);
						service.sendComplaintNotification(deComplaint, "delete", request);
						deComplaintRepository.delete(complaintId);					
						
					}
				}
				catch(Exception e){
					 logger.info(String.format("exception - ", e));
				}
		}
	
  
   
}
