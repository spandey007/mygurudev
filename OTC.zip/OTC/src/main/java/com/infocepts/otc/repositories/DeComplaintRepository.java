/**
* Filename: /src/main/java/com/infocepts/otc/repositories/DePmoReviewRepository.java
* @author  SHRI
* @version 1.0
* @since   2019-11-28 
*/
package com.infocepts.otc.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import com.infocepts.otc.entities.DeAppreciation;
import com.infocepts.otc.entities.DeComplaint;

public interface DeComplaintRepository extends CrudRepository<DeComplaint,Integer>{

	@Override
	public List<DeComplaint> findAll();	
			
}