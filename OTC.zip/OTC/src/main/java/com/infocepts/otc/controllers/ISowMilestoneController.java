/**
* Filename: /src/main/java/com/infocepts/otc/controllers/ISowMilestoneController.java
* @author  JV
* @version 1.0
* @since   2018-10-31 
*/
package com.infocepts.otc.controllers;

import java.util.List;

import javax.mail.MessagingException;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.infocepts.otc.entities.ISowMilestone;
import com.infocepts.otc.repositories.ISowMilestoneRepository;
import com.infocepts.otc.services.TimesheetService;

@RestController
@RequestMapping(value="/isowmilestone",headers="referer")
public class ISowMilestoneController {

	final Logger logger = Logger.getLogger(ISowMilestoneController.class);
	
	@Autowired
	ISowMilestoneRepository repository;
	
	@Autowired
	TimesheetService service;
	
	@RequestMapping(method=RequestMethod.POST)
	public ISowMilestone addISowMilestone(@RequestBody ISowMilestone isowmilestone)
	{
		// Authorization for Admin, PMO
		if(service.isPmo() || service.isAdmin())
		{
			try{
				isowmilestone.setIsowMilestoneId(null);
				repository.save(isowmilestone);
			}catch(Exception e){
				logger.error(e);
			}
		}
		return isowmilestone;
	}	
 
	 @RequestMapping(method=RequestMethod.GET)
	 public List<ISowMilestone> getAllISowMilestone(@RequestParam(value = "isowId", defaultValue = "0") Integer isowId,
			 										HttpServletRequest request) throws MessagingException {
		 List<ISowMilestone> isowMilestoneList=null;
		 // Authorization for Admin, PMO and Legal
		 if(service.isPmo() || service.isAdmin() || service.isLegal())
			{	 
			 try{
				 if(isowId != 0)
				 {
					 isowMilestoneList = repository.findByISowId(isowId);
				 }
				 else
				 {
					 isowMilestoneList = repository.findAll();
				 }
			 }
			 catch(Exception e){
				 logger.error(e);
			 }
			}
		 return isowMilestoneList;
	 }

     @RequestMapping(value="/{isowId}",method=RequestMethod.GET)
	 public ISowMilestone getISowMilestone(@PathVariable Integer isowId){
		 ISowMilestone isowmilestone=null;
		// Authorization for Admin, PMO and Legal
		 if(service.isPmo() || service.isAdmin() || service.isLegal())
			{
			 try{
				 isowmilestone = repository.findOne(isowId);
			 }
			 catch(Exception e){
				 logger.error(e);
			 }
			}
		 return isowmilestone;
	 }
	 
	 @RequestMapping(value="/{sowMilestoneId}",method=RequestMethod.PUT)
	 public ISowMilestone updateISowMilestone(@RequestBody ISowMilestone updatedisowmilestone,@PathVariable Integer isowMilestoneId){
		// Authorization for Admin, PMO and Legal
		 if(service.isPmo() || service.isAdmin() || service.isLegal())
			{
			 try{
				 updatedisowmilestone.setIsowMilestoneId(isowMilestoneId);
				 repository.save(updatedisowmilestone);
			 }
			 catch(Exception e){
				 logger.error(e);
			 }
			}
		 return updatedisowmilestone;
	 }
	 	 
}

