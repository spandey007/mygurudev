/**
* Filename: /src/main/java/com/infocepts/otc/controllers/PmsIldpController.java
* @author  VVC
* @version 1.0
* @since   2019-01-29
*/

package com.infocepts.otc.controllers;

import java.util.List;

import javax.mail.MessagingException;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;

import java.util.logging.Level;
import java.util.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.infocepts.otc.services.PmsService;
import com.infocepts.otc.services.TimesheetService;
import com.infocepts.pms.entities.PmsCycle;
import com.infocepts.pms.entities.PmsIldp;
import com.infocepts.pms.repositories.PmsIldpRepository;

@RestController
@RequestMapping(value="/api/pms/ildp",headers="referer")
public class PmsIldpController {
	
	final Logger logger = Logger.getLogger(PmsIldpController.class.getName());
	
	@Autowired
	PmsIldpRepository pmsIldpRepository;
	
	@Autowired
	TimesheetService service;
	
	@Autowired
	PmsService pmsService;
	
	@PersistenceContext(unitName = "otc")
	private EntityManager manager;
	
	
	@RequestMapping(method=RequestMethod.GET)
	public List<PmsIldp> getPmsIldp(@RequestParam(value = "ildpId", defaultValue = "0") Integer ildpId
			,HttpServletRequest request){
		
		List<PmsIldp> list = null;
		
		if(ildpId !=0){	//edit
			
			list = (List<PmsIldp>) pmsIldpRepository.findOne(ildpId);
		}
		else
		{
			list = pmsIldpRepository.findAll();
		}
		return list;
	}
	
	
	@RequestMapping(method=RequestMethod.POST)
	public PmsIldp addPmsIldp(@RequestBody PmsIldp pmsIldp , HttpServletRequest request) throws MessagingException {
		pmsIldp.setIldpId(null);
		pmsIldpRepository.save(pmsIldp);
	    pmsService.sendIldpNotification(pmsIldp, "add", request);  
		return pmsIldp;
	
	}
	
	
	@RequestMapping(value="/{ildpId}",method=RequestMethod.GET)
	public PmsIldp getPmsIldp(@PathVariable Integer ildpId){
		PmsIldp pmsIldp = null;
		pmsIldp = pmsIldpRepository.findOne(ildpId);
		
		return pmsIldp;
	}
	
	@RequestMapping(value="/{ildpId}", method=RequestMethod.PUT)
	public PmsIldp updatePmsIldp(@PathVariable Integer ildpId,  @RequestBody PmsIldp updatedPmsIldp,  HttpServletRequest request) throws MessagingException{
		updatedPmsIldp.setIldpId(ildpId);
		pmsIldpRepository.save(updatedPmsIldp);
		pmsService.sendIldpNotification(updatedPmsIldp, "update", request);   
		return updatedPmsIldp;
	}
	
	@RequestMapping(value="/{ildpId}",method=RequestMethod.DELETE)
	public void deletePmsIldp(@PathVariable Integer ildpId){
		//pmsIldpRepository.delete(ildpId); Delete is not required
	}
}

