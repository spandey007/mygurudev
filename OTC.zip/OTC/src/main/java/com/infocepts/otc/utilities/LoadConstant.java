package com.infocepts.otc.utilities;

import org.springframework.stereotype.Component;

/*
 * This class creates all the constants used in the application
 */
@Component
public class LoadConstant {

	/* The constants below holds the value to be used on Local/Dev Env*/
	public static final String otc = "[otcdev]";
	public static final String infomaster = "[InfoMasters_Dev]";
	public static final String pms = "[InfoPms_Dev]";
	//Constants for urls environment
	public static final String LOCALHOST = "localhost";
	public static final String INFOBIZ_DEV = "infobizdev.infocepts.com";
	public static final String INFOBIZ_STAGE = "infobizstage.infocepts.com";
	public static final String INFOBIZ_STAGE2 = "infobizstage2.infocepts.com";
	public static final String INFOBIZ_STAGE1 = "infobizstage1.infocepts.com";
	public static final String INFOBIZ_FE2 = "infobiz-fe2.infocepts.com";
	public static final String INFOBIZ = "infobiz@infocepts.com";
	public static final String INFOBIZ_ADMIN = "infobizadmin@infocepts.com";
	//Constants for DLs
	public static final String AMG = "AMG@infocepts.com";
	public static final String PMO = "PMO@infocepts.com";
	public static final String PMS_INFO = "pms@infocepts.com";
	public static final String INFO_CABS = "infocabs@infocepts.com";
	public static final String TRAVEL_DESK = "traveldesk@infocepts.com";
	public static final String TALENT_ACQUISITION = "TalentAcquisition@infocepts.com";
	public static final String BPHR = "BPHR@infocepts.com";
	public static final String GLOBAL_MOBILITY = "GlobalMobility@infocepts.com";
	public static final String ACCOUNTS_PAYABLE = "accountspayable@infocepts.com";
	public static final String INVOICES = "invoices@infocepts.com";
	public static final String V_GOUR = "vgour@infocepts.com";
	public static final String G_TALATULE = "gtalatule@infocepts.com";
	public static final String DEG  = "DEG@infocepts.com";
	public static final String SV_GOLHER  = "svgolher@infocepts.com";
	public static final String IBS_TEAM  = "IBSTeam@infocepts.com";
	public static final String HR_OPERATIONS = "HROperations@infocepts.com";
	public static final String S_GARG = "sgarg@infocepts.com";
	public static final String L_NATHANI = "lnathani@infocepts.com";
	public static final String S_DIXIT = "sdixit@infocepts.com";
	public static final String A_JOSHI = "ajoshi@infocepts.com";
	
	//-----------------------------------------------------------------------------------------------------------
	// Added to define static variable for the submit cutoff period
	public static final Integer submitCutOffPeriodId = 279; // End of June 2017
	
	// Constants for Unit Names
	public static final Integer STPI_ITPL 	= 	1;
	public static final Integer CO_PTE 		= 	2;
	public static final Integer CO_LLC 		= 	3;
	public static final Integer MIHAN_ITPL 	= 	4;
	public static final Integer BANGALORE_ITPL 	= 	21;
	public static final Integer CHENNAI_ITPL 	= 	22;
	
	public static final int ALLOCATION_BILLABLE = 1;
	public static final int ALLOCATION_NON_BILLABLE = 2;
	public static final int ALLOCATION_NON_BILLABLE_TRAINEE = 3;
	public static final int ALLOCATION_BILLED_BUFFER = 4;
	

	public static final int EXPENSE_PURPOSE_ACTIVE = 1;
	public static final int EXPENSE_PURPOSE_DISABLED = 0;
	
	public static final int EXPENSE_CATEGORY_ACTIVE = 1;
	public static final int EXPENSE_CATEGORY_DISABLED = 0;
	
	
	public static final int EXPENSE_STATUS_DRAFT = 1;
	public static final int EXPENSE_STATUS_PENDING_APPROVAL = 2;
	public static final int EXPENSE_STATUS_APPROVED = 3;
	public static final int EXPENSE_STATUS_REJECTED = 4;
	public static final int EXPENSE_STATUS_CANCELLED = 5;
	public static final int EXPENSE_STATUS_SETTLED = 6;

	public static final int EXPENSE_PM_REJECTED = 1;
	public static final int EXPENSE_PM_APPROVED_TD_PENDING = 2;
	public static final int EXPENSE_PM_APPROVED_TD_REJECTED = 3;
	public static final int EXPENSE_PM_TD_APPROVED_FINANCE_PENDING = 4;
	public static final int EXPENSE_PM_APPROVED_FINANCE_PENDING = 5;
	public static final int EXPENSE_PM_APPROVED_FINANCE_REJECTED = 6;
	public static final int EXPENSE_PM_FINANCE_APPROVED_SETTLEMENT_PENDING = 7;
	public static final int EXPENSE_PM_TD_APPROVED_FINANCE_REJECTED = 8;
	public static final int EXPENSE_PM_TD_FINANCE_APPROVED_SETTLEMENT_PENDING = 9;
	public static final int EXPENSE_SETTLED_BY_FINANCE = 10;
	public static final int EXPENSE_PM_APPROVAL_PENDING = 11;
	
	public static final int EXPENSE_REIMBURSEMENT_BILLABLE_TO_CLIENT = 1;
	public static final int EXPENSE_REIMBURSEMENT_NON_BILLABLE_TO_CLIENT = 2;
	
	public static final int TS_FOUR_WEEKS = 4;
	public static final int TS_FIVE_WEEKS = 5;
}
