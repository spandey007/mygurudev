package com.infocepts.otc.controllers;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;

import java.util.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.infocepts.otc.entities.BusRouteTimings;
import com.infocepts.otc.repositories.BusRouteTimingsRepository;
import com.infocepts.otc.services.TimesheetService;

@RestController
@RequestMapping(value="/busroutetimings",headers="referer")
public class BusRouteTimingsController {

	@Autowired
	BusRouteTimingsRepository busRouteTimingsRepository;
	
	@PersistenceContext
    private EntityManager manager;
	
	@Autowired
	TimesheetService service;
	
	 final Logger logger = Logger.getLogger(BusRouteTimingsController.class.getName());
	
	@RequestMapping(method=RequestMethod.POST)
	public BusRouteTimings addBusRouteTimings(@RequestBody BusRouteTimings busRouteTimings){
		busRouteTimings.setBusRouteTimingsId(null);
		Boolean isAValidCall = false;
		if(service.isTravel())
		{
			isAValidCall = true;
		}
		if(isAValidCall) {
			
			busRouteTimingsRepository.save(busRouteTimings);
		}
		return busRouteTimings;
	}
	
	@RequestMapping(method=RequestMethod.GET)
		public List<BusRouteTimings> getBusRouteTimings(
				@RequestParam(value = "nodalpointid", defaultValue = "0") Integer nodalpointid
				,@RequestParam(value = "routeid", defaultValue = "0") Integer routeid				
				,HttpServletRequest request){
		List<BusRouteTimings> busRouteTimelist=null;
		 try{
			 if(nodalpointid != 0 && routeid != 0){
				 logger.info("here");
				busRouteTimelist = manager.createNamedQuery("getBusRouteTimings",BusRouteTimings.class)
							 .setParameter("nodalpointid", nodalpointid)
							 .setParameter("routeid", routeid)
							.getResultList();
			 }
			 else if(routeid != 0){				 
				 busRouteTimelist = busRouteTimingsRepository.findById(routeid);
			 }
			 else{
				 busRouteTimelist = manager.createNamedQuery("getTimingBusPass",BusRouteTimings.class)
							.getResultList();
			 }
			 
		 }
		 catch(Exception e){
			 logger.info(String.format("exception - ", e));
		 }
		 return busRouteTimelist;
	}
	
	@RequestMapping(value="/{busRouteTimingsId}",method=RequestMethod.GET)
	public BusRouteTimings getBusRouteTimings(@PathVariable Integer busRouteTimingsId){
		BusRouteTimings busRouteTimings = null;
		Boolean isAValidCall = false;
		if(service.isTravel())
		{
			isAValidCall = true;
		}
		if(isAValidCall) {
			
			busRouteTimings = busRouteTimingsRepository.findOne(busRouteTimingsId);
		}
		return busRouteTimings;
	}
	
	@RequestMapping(value="/{busRouteTimingsId}", method=RequestMethod.PUT)
	public BusRouteTimings updateBusRouteTimings(@PathVariable Integer busRouteTimingsId,  @RequestBody BusRouteTimings updatedBusRouteTimings){
		updatedBusRouteTimings.setBusRouteTimingsId(busRouteTimingsId);
		Boolean isAValidCall = false;
		if(service.isTravel())
		{
			isAValidCall = true;
		}
		if(isAValidCall) {
		busRouteTimingsRepository.save(updatedBusRouteTimings);
		}
		return updatedBusRouteTimings;
	}
	
	@RequestMapping(value="/{busRouteTimingsId}",method=RequestMethod.DELETE)
	public void deleteBusRouteTimings(@PathVariable Integer busRouteTimingsId){
		Boolean isAValidCall = false;
		if(service.isTravel())
		{
			isAValidCall = true;
		}
		if(isAValidCall) {
		busRouteTimingsRepository.delete(busRouteTimingsId);
		}
	}
}
