/* 
 * Country Repository to manage Countrys
 * -------------------------------------------------------------------------------------------------------------------------
 *20 Sep 2017 - EW creation of the file
 *
*/
package com.infocepts.otc.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.infocepts.otc.entities.Country;

public interface CountryRepository extends CrudRepository<Country,Integer>{

	@Override
	public List<Country> findAll();

	@Query("select y from Country y where y.status = 1")
	public List<Country> findAllActive();
	
	/*@Query("select y from Country y where y.status = :status")
	public List<Country> findByCountryStatus(@Param(value = "status") Boolean status);

	@Query("select y from Country y where y.countryId = :countryId")
	public List<Country> findByCountryId(@Param(value="countryId") Integer CountryId);

	@Query("select y from Country y where y.countryName = :countryName")
	public List<Country> findByCountryName(@Param(value="countryName") String countryName);*/
}
