/**
* Filename: /src/main/java/com/infocepts/otc/entities/ReleaseManagementDetail.java
* @author  Anjali S. Kalbande
* @version 1.0
* @since   2018-01-08 
*/

package com.infocepts.otc.entities;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.persistence.*;
import javax.validation.constraints.NotNull;

import com.infocepts.otc.utilities.LoadConstant;
@Entity
@Table(catalog=LoadConstant.otc, schema="[dbo]", name="releaseDetail")
@SqlResultSetMappings({
        @SqlResultSetMapping(
                name = "releaseItem_info",
                classes = {
                        @ConstructorResult(
                                targetClass = ReleaseManagementDetail.class,
                                columns = {
                                		@ColumnResult(name = "releaseItemId"),
                                		@ColumnResult(name = "releaseId"),
										@ColumnResult(name = "releaseItemName", type = String.class),
                                        @ColumnResult(name = "rdstatus", type = String.class),  
										@ColumnResult(name = "createdBy"),										
                                        @ColumnResult(name = "createdDate", type = Date.class),
										@ColumnResult(name = "modifiedBy"),
                                        @ColumnResult(name = "modifiedDate", type = Date.class),
                                        @ColumnResult(name = "stakeholder", type = String.class),
                                        @ColumnResult(name = "createdByName", type = String.class),
                                        @ColumnResult(name = "releaseName", type = String.class),
                                        @ColumnResult(name = "releaseDate", type = Date.class)
                                        
                                }
                        )
                }
        )
})
@NamedNativeQueries({
	@NamedNativeQuery(
            name    =   "getReleaseItemsByReleaseId",   
            query 	=   " Select tb.*, '' as createdByName, '' as releaseName, getdate() as releaseDate "+
            			" from " + LoadConstant.otc + ".[dbo].ReleaseDetail as tb "+
						" WHERE tb.releaseId = :releaseId",		 
						resultClass=ReleaseManagementDetail.class, resultSetMapping = "releaseItem_info"
    ),
    @NamedNativeQuery(
            name    =   "getAllReleaseItem",   
            query	=	"select  tb.* , rm.releaseName, rm.releaseDate, r.title as createdByName "+
						" from "+ LoadConstant.otc +".[dbo].[releaseDetail] tb "+ 
						"inner join " + LoadConstant.otc +".[dbo].[release] rm on rm.releaseId=tb.releaseId "+
						"inner join " + LoadConstant.infomaster +".[dbo].[resource] r on rm.createdBy = r.uid ",
//						" WHERE tb.releaseItemId = :releaseItemId",
						resultClass=ReleaseManagement.class, resultSetMapping = "releaseItem_info"
    ) 
})
public class ReleaseManagementDetail {

	// Entity Columns
    // --------------------------------------------------------------------------------
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Integer releaseItemId; 	
    
    @ManyToOne
    @JoinColumn(name="releaseId")
    private ReleaseManagement releaseManagement;
    
    private String releaseItemName;
    private String rdstatus; 
    
	private Integer createdBy;    
    private Date createdDate;
    private Integer modifiedBy;
    private Date modifiedDate;
    private String stakeholder;
    
    @Transient
    private String createdByName;
    
    @Transient
    private String releaseName;
    
    @Transient
    private Date releaseDate;
    
    // Getter setter
 	// --------------------------------------------------------------------------------
	public Integer getReleaseItemId() {
		return releaseItemId;
	}
	public void setReleaseItemId(Integer releaseItemId) {
		this.releaseItemId = releaseItemId;
	}
	
	public String getReleaseItemName() {
		return releaseItemName;
	}
	public void setReleaseItemName(String releaseItemName) {
		this.releaseItemName = releaseItemName;
	}
	public String getRdstatus() {
		return rdstatus;
	}
	public void setRdstatus(String rdstatus) {
		this.rdstatus = rdstatus;
	}
	public Integer getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public Integer getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public Date getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public String getStakeholder() {
		return stakeholder;
	}
	public void setStakeholder(String stakeholder) {
		this.stakeholder = stakeholder;
	}
	public ReleaseManagement getReleaseManagement() {
		return releaseManagement;
	}
	public void setReleaseManagement(ReleaseManagement releaseManagement) {
		this.releaseManagement = releaseManagement;
	}
	
	public Date getReleaseDate() {
		return releaseDate;
	}	
	public void setReleaseDate(Date releaseDate) {
		this.releaseDate = releaseDate;
	}
	
    public String getReleaseName() {
		return releaseName;
	}	
	public void setReleaseName(String releaseName) {
		this.releaseName = releaseName;
	}
	
	public String getCreatedByName() {
		return createdByName;
	}
	public void setCreatedByName(String createdByName) {
		this.createdByName = createdByName;
	}
	// Constructor
	// ---------------------------------------------------------------------------------
	public ReleaseManagementDetail(){
		//super();
		// TODO Auto-generated constructor stub
	}
	
	// Constructor using fields
	// ---------------------------------------------------------------------------------
	public ReleaseManagementDetail(Integer releaseItemId, 
									Integer releaseId, 
									String releaseItemName,
									String rdstatus, 
									Integer createdBy, 
									Date createdDate, 
									Integer modifiedBy, 
									Date modifiedDate,
									String stakeholder,
									String createdByName,
									String releaseName,
									Date releaseDate
		) {
		
			this.releaseItemId = releaseItemId;

			this.releaseManagement = new ReleaseManagement();
			this.releaseManagement.setReleaseId(releaseId); //set parent object
		
			this.releaseItemName = releaseItemName;
			this.rdstatus = rdstatus;
			this.createdBy = createdBy;
			this.createdDate = createdDate;
			this.modifiedBy = modifiedBy;
			this.modifiedDate = modifiedDate;
			this.stakeholder = stakeholder;
			this.createdByName = createdByName;
			this.releaseName = releaseName;
			this.releaseDate = releaseDate;
		}
	
    

}
