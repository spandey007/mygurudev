package com.infocepts.otc.repositories;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.persistence.EntityManager;
import javax.persistence.TemporalType;
import javax.persistence.TypedQuery;

import org.springframework.data.jpa.repository.JpaRepository;
/**
* Filename: /src/main/java/com/infocepts/otc/repositories/ExchangeRateRepository.java
* --------------------------------------------------------------------------
* Sr.No	 Author	      Version	Modified Date	Description
 ---------------------------------------------------------------------------
  1.    | Joselin V | 1.0     |  10-04-2019   |  Intial Version 
  --------------------------------------------------------------------------
*/

import com.infocepts.otc.entities.ExchangeRate;

public interface ExchangeRateRepository extends JpaRepository<ExchangeRate,Integer>{
    @Override
	public List<ExchangeRate> findAll();
	
	
    default Double getConversionRate(EntityManager manager, Integer currencyFromId, Integer currencyToId, Date expenseStartDate) {
		String queryString = "select conversionRate from ExchangeRate er where er.currencyFromId = :currencyFromId "
				+ "and er.currencyToId = :currencyToId and :expenseStartDate between er.effectiveFrom and er.effectiveTo";
		try {
			TypedQuery<BigDecimal> query = manager.createQuery(queryString, BigDecimal.class);
			query.setParameter("currencyFromId", currencyFromId);
			query.setParameter("currencyToId", currencyToId);
			query.setParameter("expenseStartDate", expenseStartDate, TemporalType.DATE);
			BigDecimal singleResult = query.getSingleResult();
			return singleResult != null ? singleResult.doubleValue(): 0.0;
		} catch (Exception e) {
			Logger.getLogger(ExchangeRateRepository.class.getName()).log(Level.WARNING, ""
					+ "Something went wrong while fetching the conversion rate with given currencyFromId = " + currencyFromId
					 + " and currencyToId = " + currencyToId, e);
		}
		return 0.0;
	}
}
