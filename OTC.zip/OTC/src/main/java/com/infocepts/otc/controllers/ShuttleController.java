package com.infocepts.otc.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.infocepts.otc.entities.Shuttle;
import com.infocepts.otc.repositories.ShuttleRepository;
import com.infocepts.otc.services.TimesheetService;

@RestController
@RequestMapping(value="/shuttle",headers="referer")
public class ShuttleController {
	@Autowired
	ShuttleRepository shuttleRepository;
	
	@Autowired
	TimesheetService service;
	
	@RequestMapping(method=RequestMethod.POST)
	public Shuttle addShuttle(@RequestBody Shuttle shuttle){
		shuttle.setShuttleId(null);
		Boolean isAValidCall = false;
		if(service.isTravel())
		{
			isAValidCall = true;
		}
		if(isAValidCall) {
			
			shuttleRepository.save(shuttle);
		}
		return shuttle;
	}
	
	@RequestMapping(method=RequestMethod.GET)
	public List<Shuttle> getShuttle(){
		List<Shuttle> list = null;
		Boolean isAValidCall = false;
		if(service.isTravel())
		{
			isAValidCall = true;
		}
		//if(isAValidCall) {
			list = shuttleRepository.findAll();
		//}
		return list;
	}
	
	@RequestMapping(value="/{shuttleId}",method=RequestMethod.GET)
	public Shuttle getShuttle(@PathVariable Integer shuttleId){
		Shuttle Shuttle = null;
		Boolean isAValidCall = false;
		if(service.isTravel())
		{
			isAValidCall = true;
		}
		if(isAValidCall) {
			
			Shuttle = shuttleRepository.findOne(shuttleId);
		}
		return Shuttle;
	}
	
	@RequestMapping(value="/{shuttleId}", method=RequestMethod.PUT)
	public Shuttle updateShuttle(@PathVariable Integer shuttleId,  @RequestBody Shuttle updatedShuttle){
		updatedShuttle.setShuttleId(shuttleId);
		Boolean isAValidCall = false;
		if(service.isTravel())
		{
			isAValidCall = true;
		}
		if(isAValidCall) {
			shuttleRepository.save(updatedShuttle);
		}
		return updatedShuttle;
	}
	
	@RequestMapping(value="/{shuttleId}",method=RequestMethod.DELETE)
	public void deleteShuttle(@PathVariable Integer shuttleId){
		Boolean isAValidCall = false;
		if(service.isTravel())
		{
			isAValidCall = true;
		}
		if(isAValidCall) {
			shuttleRepository.delete(shuttleId);
		}
	}
}
