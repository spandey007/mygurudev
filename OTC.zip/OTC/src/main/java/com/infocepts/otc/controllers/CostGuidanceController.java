package com.infocepts.otc.controllers;

import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.infocepts.otc.entities.CostGuidance;
import com.infocepts.otc.repositories.CostGuidanceRepository;
import com.infocepts.otc.services.TimesheetService;

@RestController
@RequestMapping(value="/costGuidance",headers="referer")
public class CostGuidanceController {
	
	final Logger logger = Logger.getLogger(CostGuidanceController.class);

	@Autowired
	CostGuidanceRepository repository;
	
	@Autowired
	TimesheetService service;
	
	@RequestMapping(method=RequestMethod.POST)
	public CostGuidance addCostGuidance(@RequestBody CostGuidance costguidance)
	{
		try{
			if(service.isAdmin()){
				costguidance.setCostGuidanceId(null);
				repository.save(costguidance);
			}
		}catch(Exception e){
			logger.error(e);
		}
		return costguidance;
	}	
 
	 @RequestMapping(method=RequestMethod.GET)
	 public List<CostGuidance> getAllCostGuidances(){
		 List<CostGuidance> costguidancelist=null;
		 try{
			 if(true){ //service.isAdmin() Removed the authorization for now - It should be accessibe t PM/PMO as well fro CMS and SOW creation
				 costguidancelist = repository.findAll();
			 }
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return costguidancelist;
	 }

	@RequestMapping(value="/{costGuidanceId}",method=RequestMethod.GET)
	 public CostGuidance getCostGuidance(@PathVariable Integer costGuidanceId){
		 CostGuidance costguidance=null;
		 try{
			 if(service.isAdmin()){
				 costguidance = repository.findOne(costGuidanceId);
			 }
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return costguidance;
	 }
	 
	@RequestMapping(value="/{costGuidanceId}",method=RequestMethod.PUT)
	 public CostGuidance updateCostGuidance(@RequestBody CostGuidance updatedCostGuidance,@PathVariable Integer costGuidanceId){
		 try{
			 if(service.isAdmin()){
				 updatedCostGuidance.setCostGuidanceId(costGuidanceId);
				 repository.save(updatedCostGuidance);
			 }
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return updatedCostGuidance;
	 }
	 
	 @RequestMapping(value="/{costGuidanceId}",method=RequestMethod.DELETE)
	 public void deleteCostGuidance(@PathVariable Integer costGuidanceId){
		 try{
			 if(service.isAdmin()){
				 repository.delete(costGuidanceId);
			 }
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
	 }	 
}
