/*
 * rk 13 Apr - Fixed the forced tsitem copy issue (Tsitems should not get copied from previous periods if tstimesheet object is present)
 * rk 14 Apr - Fixed async tsitem delete issue. tsitemhrs for the removed tsitem removed in backend now - no check in backend for filled / unfilled tsitemhrs
 */
package com.infocepts.otc.controllers;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.mail.MessagingException;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.collections.CollectionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.thymeleaf.context.Context;

import com.infocepts.otc.entities.Account;
import com.infocepts.otc.entities.Allocation;
import com.infocepts.otc.entities.Holidays;
import com.infocepts.otc.entities.Project;
import com.infocepts.otc.entities.ProjectTask;
import com.infocepts.otc.entities.Resource;
import com.infocepts.otc.entities.Timesheet;
import com.infocepts.otc.entities.TimesheetHours;
import com.infocepts.otc.entities.TimesheetItem;
import com.infocepts.otc.entities.TimesheetNonwork;
import com.infocepts.otc.entities.TimesheetPeriods;
import com.infocepts.otc.notification.SmtpMailSender;
import com.infocepts.otc.repositories.AccountRepository;
import com.infocepts.otc.repositories.AllocationRepository;
import com.infocepts.otc.repositories.ResourceRepository;
import com.infocepts.otc.repositories.TimesheetHoursRepository;
import com.infocepts.otc.repositories.TimesheetItemRepository;
import com.infocepts.otc.repositories.TimesheetNonworkRepository;
import com.infocepts.otc.repositories.TimesheetRepository;
import com.infocepts.otc.services.TimesheetService;
import com.infocepts.otc.utilities.DateConverter;
import com.infocepts.otc.utilities.LoadConstant;

@RestController
@RequestMapping(value="/tsitem",headers="referer")//JV: Added 'headers' param to validate the url.
public class TimesheetItemController {
	
	final Logger logger = Logger.getLogger(TimesheetItemController.class);
	private static final List<TimesheetNonwork> HOLIDAY_LIST = new ArrayList<>();
	/* This map will contain the list of generic tasks i.e. Project Name will be the key and Task title will be
	the value.
	*/
	private static final List<ProjectTask> GENERIC_TASKS_LIST = new ArrayList<>();
	
	@Autowired
	HttpSession session;
	@Autowired
	TimesheetItemRepository repository;
	
	@Autowired
	ResourceRepository resourceRepository;
	@Autowired
	TimesheetRepository tsRepository;
	@Autowired
	TimesheetHoursRepository thRepository;
	@Autowired
	ProjectController projectController;
	@Autowired
	ResourceController resourceController;
	@Autowired
	TimesheetPeriodsController timesheetPeriodsController;
	@Autowired
	private TimesheetItemRepository tsItemRepository;
	@Autowired
	private AllocationRepository allocationRepository;
	@Autowired
	private TimesheetHoursRepository timesheetHoursRepository;
	
	@Autowired
	AccountRepository accountRepository;
	@Autowired
	AccountController accountController;
	
	@Autowired
	private TimesheetNonworkRepository timesheetNonworkRepository;
	
	
	
	@Autowired
	TimesheetService service;
	
	@PersistenceContext(unitName="otc")
	private EntityManager manager;
	
	@Autowired
	private SmtpMailSender smtpMailSender;
	
	@RequestMapping(method=RequestMethod.GET)
	 public List<TimesheetItem> getTimesheetItems(@RequestParam(value = "timesheetId", defaultValue = "0") Integer timesheetId,
			 	@RequestParam(value = "periodId", defaultValue = "0") Integer periodId,
			 	@RequestParam(value = "projectId", defaultValue = "0") Integer projectId,
				@RequestParam(value = "uid", defaultValue = "0") Integer uid,
				@RequestParam(value = "copy", defaultValue = "0") Integer copy, HttpServletRequest request) throws MessagingException {
		List<TimesheetItem> tsitems = null;
		
		/* ------------------------- Authorization start ------------------------------------ */
		// Authorization for passed uid (user id)
		if(uid != 0)
		{
			Boolean isAValidCall = false;
			isAValidCall = service.isAValidTimesheetCall(uid);	
			
			if((isAValidCall == false) && (!service.isAdmin()))
			{
				service.sendTamperedMail("TsItem View", uid, 0, request);
				return tsitems;
			}
		}
		/* ------------------------- Authorization ends ------------------------------------ */
		
		TimesheetPeriods tsPeriod = tsItemRepository.findTimesheetPeriods(periodId);
		
		try{
			if(timesheetId != 0) // to retrieve tsitems by timesheetId
			{
				tsitems = manager.createNamedQuery("getTimesheetItemByTimesheetId", TimesheetItem.class)
							 .setParameter("timesheetId", timesheetId)
				            .getResultList();
			}
			else if((periodId != 0) && (projectId != 0))  // to retrieve tsitems by period and project
			{
				tsitems = manager.createNamedQuery("getTimesheetItemByPeriodIdAndProjectId", TimesheetItem.class)
						 .setParameter("periodId", periodId)
						 .setParameter("projectId", projectId)
			            .getResultList();
			}
			else if((periodId != 0) && (uid != 0))  // to retrieve tsitems by period and user
			{
				tsitems = manager.createNamedQuery("getTimesheetItemByPeriodIdAndUserId", TimesheetItem.class)
						 .setParameter("periodId", periodId)
						 .setParameter("uid", uid)
			            .getResultList();
				
				// If there are no timesheet item objects created for the period for the user,
				// find and copy the last added timesheet item objects for the most recent period by the user
				// and save them for the current period
				if(tsitems.isEmpty() && copy == 1)
				{
					// Save them for the current timesheet period
					Timesheet timesheet = null;
					List<Timesheet> timesheetList = tsRepository.findTimesheetsByPeriodByUser(periodId, uid);
					
					// If timesheet object present, then the tsitems were explicitly removed by user.	
					// In this case, tasks from previous periods are not copied as there was some manual interaction by the user in the 
					// timesheet period and hence the tstimesheet is created
					// If empty, create a new tstimesheet for the user for current period
					if(timesheetList.isEmpty())
					{
						timesheet = new Timesheet();
						timesheet.setPeriodId(periodId);
						timesheet.setUid(uid);
						timesheet.setCreatedBy(uid);
						timesheet.setCreatedDate(new Date());
						timesheet = tsRepository.save(timesheet); // put in try catch - rkj
					
						if(timesheet != null)
						{
							tsitems = manager.createNamedQuery("getLastAddedTimesheetItemByUserId", TimesheetItem.class)
								.setParameter("periodId", periodId) 
								.setParameter("uid", uid)
								 .getResultList();
							// Temporary arraylist to keep active timesheet items.
							List<TimesheetItem> activeItemList = new ArrayList<>();
						
							for (TimesheetItem ti : tsitems)
							{	
								if (isAllocationEndedForItem(ti, uid, tsPeriod)) {
									continue;
								}
								// While copying set submit status to zero
								ti.setSubmitted(false);
								ti.setApprovalStatus(0);
								ti.setCreatedBy(uid);
								ti.setCreatedDate(new Date());
								// Set the timesheet object reference (copied or existing)
							    ti.setTimesheet(timesheet);
							    addTimesheetItem(ti);
							    /* Execution control will end up here if and only if the allocation for the 
							    respective item is not ended.
							    */
							    activeItemList.add(ti);
							}
							tsitems.retainAll(activeItemList);
						}
					}
				}
				/* Check if holiday non-work items are already added in the current timesheet and period, If yes
				then don't add them again.
				 */
				if (tsitems.stream().filter(item -> item.getTaskId() == 3).count() == 0) {
					/* If all the timesheet items are submitted for this timesheet then the respective
					 * timesheet is submitted for the corresponding timesheet period. That means
					 * we can't add holiday items for a submitted timesheet. 
					*/
					if (CollectionUtils.isEmpty(tsitems) || !tsitems.stream().allMatch(item -> item.getSubmitted())) {
						tsitems.addAll(addNonWorkItemForHolidays(periodId, uid));
					}
				}
				tsitems.parallelStream().forEach(tsitem -> {
					isAllocationEndedForItem(tsitem, uid, tsPeriod);
				});
		  }
		}catch(Exception e){
			logger.error(e);
		}
		return tsitems;
	 }
	
	@RequestMapping(value="/{tsitemId}",method=RequestMethod.GET)
	 public TimesheetItem getTimesheetItem(@PathVariable Integer tsitemId){
		TimesheetItem tsitem=null;
		try{
			tsitem=repository.findOne(tsitemId);
		}
		catch(Exception e){
			logger.error(e);
		}
		return tsitem;
	 }
	
	@RequestMapping(method=RequestMethod.POST)
	public TimesheetItem addTimesheetItem(@RequestBody TimesheetItem tsitem) {
		try{
			tsitem.setTsitemId(null);
			repository.save(tsitem);
		}
		catch(Exception e){
			logger.error(e);
		}
		return tsitem;
	}
	
	@RequestMapping(value="/{tsitemId}",method=RequestMethod.PUT)
	public TimesheetItem updateTimesheetItem(@PathVariable Integer tsitemId,@RequestBody TimesheetItem utsitem,HttpServletRequest request)  throws MessagingException {
		try{
			utsitem.setTsitemId(tsitemId);
			repository.save(utsitem);
			// If the tsitem is rejected, send an email to the associate and PM who rejected it
			if(utsitem.getApprovalStatus() == 2)
			{
				Account accnt = null;
				Resource resourceDm = null;
				Project project = projectController.getProject(utsitem.getProjectId());
				Resource resourcePm = resourceController.findResource(project.getProjectManagersId());
				
				if(project.getAccountId() != null) {
					accnt = accountRepository.getOne(project.getAccountId());
					if(accnt != null) {
						if(accnt.getAhId() != null) {
						resourceDm = resourceController.findResource(accnt.getAhId());	
						}
					}
				}
								
				Resource resource = resourceController.findResource(utsitem.getAssociateId());				
				//Resource resource = resourceController.findResource(utsitem.get);
				TimesheetPeriods period = timesheetPeriodsController.getTimesheetByPeriodId(utsitem.getTimesheet().getPeriodId());
				
				Context context = new Context();
				context.setVariable("username",utsitem.getAssociateName());
				context.setVariable("projectName",utsitem.getProjectName());	
				context.setVariable("taskName",utsitem.getTaskName());				
				context.setVariable("pmName",project.getPmName());
				context.setVariable("tsPeriod",DateConverter.changeDate(period.getPeriodStart())+" to "+DateConverter.changeDate(period.getPeriodEnd()));
				//context.setVariable("pmEmail",resourcePm.getEmail());
				//context.setVariable("dmEmail",resourceDm.getEmail());
				context.setVariable("resourceEmail",resource.getEmail());				
				
				if(utsitem.getApprovalNotes() != null)
				{
					context.setVariable("comment",utsitem.getApprovalNotes());					
				}else{
					context.setVariable("comment","");
				}
				
				smtpMailSender.send("",resource.getEmail(),"Timesheet Task Rejected","mail/taskRejectByPm", context,resourcePm.getEmail(),request);
			}		
		}catch(Exception e){
			logger.error(e);
		}
		return utsitem;
	}
	
	@RequestMapping(value="/{tsitemId}",method=RequestMethod.DELETE)
	public void deleteTimesheetItem(@PathVariable Integer tsitemId, HttpServletRequest request) {
		try{
			//Deleting timesheet item with filled hours will delete that entry from parent table TimesheetItem and its child entry from TimesheetHours table
			//Deleting timesheet item with no filled hours will delete that entry only from TimesheetItem table
						
			/* ------------------------- Authorization start ------------------------------------ */
			// Authorization for deleting Timesheet item
			Boolean isAValidCall = false;
			Integer loggedInUid = (Integer) session.getAttribute("loggedInUid");		
		
			if(loggedInUid != 0 && loggedInUid != null)
			{
				TimesheetItem tsitem = repository.findTsitemByTsitemId(tsitemId);
				if(tsitem != null)
				{
					Timesheet ts = tsitem.getTimesheet();
					if(ts != null)
					{
						Integer uid = ts.getUid();
						
						isAValidCall = service.isAValidTimesheetCall(uid);	
						if(isAValidCall == true)
						{
							repository.delete(tsitemId);
						}
						else
						{
							service.sendTamperedMail("TsItem Delete", uid, 0, request);
						}
					}
				}
			}				
			/* ------------------------- Authorization End ------------------------------------ */					
		}
		catch(Exception e){
			logger.error(e);
		}
	}
	
	/**
	 * @param periodId
	 * @param userId
	 * @return - List of holiday items
	 * 
	 * This method is meant to find out the holidays in the selected period and add holiday items for them with 8 non-billable
	 * hours filled against it.
	 */
	private List<TimesheetItem> addNonWorkItemForHolidays(Integer periodId, Integer userId) {
		List<TimesheetItem> holidayItemList = new ArrayList<>();
		Date currentDate = new Date();
		
		// Get current timesheet by current period and user id.
		Timesheet currentTimesheet = tsItemRepository.findTimesheet(periodId, userId);

		
		// First get the period start and period end date for the given period id.
		TimesheetPeriods tsPeriod = tsItemRepository.findTimesheetPeriods(periodId);
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
		String periodStart = simpleDateFormat.format(tsPeriod.getPeriodStart());
		String periodEnd = simpleDateFormat.format(tsPeriod.getPeriodEnd());
		
		// Get holidays for the selected period.
		TypedQuery<Holidays> holidayQuery = manager.createNamedQuery("getHolidaysForUserInSelectedPeriod", Holidays.class);
		holidayQuery.setParameter("uid", userId);
		holidayQuery.setParameter("periodStart", periodStart);
		holidayQuery.setParameter("periodEnd", periodEnd);
		
		// Add non-work timesheet item for each holiday present in the selected period.
		holidayQuery.getResultList().forEach( holiday -> {
			TimesheetItem holidayItem = new TimesheetItem();
			holidayItem.setTimesheet(currentTimesheet);
//			holidayItem.setTshoursCount(1);
			holidayItem.setTaskName("Holiday");
			holidayItem.setCreatedBy(userId);
			holidayItem.setCreatedDate(currentDate);
			holidayItem.setItemType(2);
			// Setting task as 3 since it represents the type "Holiday" in non-work items.
			holidayItem.setTaskId(3);
			holidayItem.setSubmitted(false);

			holidayItemList.add(addTimesheetItem(holidayItem));

			TimesheetHours tsHours = new TimesheetHours();
			tsHours.setTaskName("Holiday");
			tsHours.setSubmitted(0);
			tsHours.setTimesheetItem(holidayItem);
			tsHours.setNonBillableHrs(new BigDecimal(8));
			tsHours.setItemDate(holiday.getDate());
			tsHours.setTotalWorkedHrs(new BigDecimal(8));
			timesheetHoursRepository.save(tsHours);
		});
		
		return holidayItemList;
	}
	
	/**
	 * @param timesheetItem - Item to be added in the current timesheet period if and only if project allocation 
	 * for it is still active.
	 * @param userId - User for which allocation is to be fetched.
	 * @param tsPeriod - Period for which allocation is to be fetched.
	 * @return - true if project allocation is ended for current user, false otherwise.
	 */
	private boolean isAllocationEndedForItem(TimesheetItem timesheetItem, final Integer userId, TimesheetPeriods tsPeriod) {
		
		if (HOLIDAY_LIST.isEmpty()) {
			fetchNonworkItems();
		}
		
		// We do not need to check allocation for a holiday item, That is why returning false.
		if (HOLIDAY_LIST.stream().anyMatch(item -> item.getTsnonworkId() == timesheetItem.getTaskId())) {
			return false;
		}
		
		if (GENERIC_TASKS_LIST.isEmpty()) {
			TypedQuery<ProjectTask> typedQuery = manager.createNamedQuery("getNonAllocatedTasksForUser", ProjectTask.class);
			GENERIC_TASKS_LIST.addAll(typedQuery.getResultList());
		}
		
		/* Here we are verifying a generic task by it's respective project name and task name.
		We are doing this, So that we can can allow generic tasks to be shown on UI. Before this change
		this method was considering generic tasks as regular tasks and hence checking allocation for them which at
		this point is not required.
		*/
		if (GENERIC_TASKS_LIST.stream().anyMatch( item -> item.getProjectName().equals(timesheetItem.getProjectName())
				&& item.getTitle().equals(timesheetItem.getTaskName()))) {
			return false;
		}
		
		final Integer projectId = timesheetItem.getProjectId();
		List<Allocation> allocationList = null;
		Date periodStartDate = tsPeriod.getPeriodStart();
		
		if ((projectId != null && projectId != 0) && (userId != null && userId != 0)) {
			allocationList = allocationRepository.findAllocation(projectId, userId);
			if (!CollectionUtils.isEmpty(allocationList)) {
				for(Allocation allocation : allocationList) {
					Date alcEndDate = allocation.getAlcEndDate();
					/* If project allocation end date is less than the period start date then it means project allocation is ended for 
					 * current user.
					 * Below statement is same as alcEndDate < periodStartDate.
					 */
					boolean projectAllocationEnded = alcEndDate.before(periodStartDate);
					if (allocation.getAlcType() == LoadConstant.ALLOCATION_BILLABLE || 
							allocation.getAlcType() == LoadConstant.ALLOCATION_BILLED_BUFFER) {
						timesheetItem.setProjectAllocBillableEndDate(alcEndDate);
						timesheetItem.setProjectAllocEndedForBillable(projectAllocationEnded);
					} else if (allocation.getAlcType() == LoadConstant.ALLOCATION_NON_BILLABLE ||
							allocation.getAlcType() == LoadConstant.ALLOCATION_NON_BILLABLE_TRAINEE) {
						timesheetItem.setProjectAllocNonBillableEndDate(alcEndDate);
						timesheetItem.setProjectAllocEndedForNonBillable(projectAllocationEnded);
					}
				}
				
				/* This condition signifies that if there is only one type of allocation, Whether it is billable or non-billable
				then we need to check allocation end date either for billable or non-billable allocation.
				*/
				if (allocationList.size() == 1) {
					return timesheetItem.getProjectAllocEndedForBillable() || timesheetItem.getProjectAllocEndedForNonBillable();
				}
				
				/* If billable allocation is ended and non-billable is active then allocation for this item is
				considered to be active.
				*/
				if (timesheetItem.getProjectAllocEndedForBillable() && !timesheetItem.getProjectAllocEndedForNonBillable()) {
					return false;
				}
				
				/* If non-billable allocation is ended and billable is active then allocation for this item is
				considered to be active.
				 */
				else if (!timesheetItem.getProjectAllocEndedForBillable() && timesheetItem.getProjectAllocEndedForNonBillable()) {
					return false;
				}
				
				/* If billable and non-billable allocation are active then allocation for this item is
				considered to be active.
				 */
				else if (!timesheetItem.getProjectAllocEndedForBillable() && !timesheetItem.getProjectAllocEndedForNonBillable()) {
					return false;
				}
				
				/* If billable and non-billable allocation are ended then allocation for this item is
				considered to be inactive i.e. Ended.
				 */
				else if (timesheetItem.getProjectAllocEndedForBillable() && timesheetItem.getProjectAllocEndedForNonBillable()) {
					return true;
				}
				
				
			}
		}
		return CollectionUtils.isEmpty(allocationList);
	}
	
	// Fetch all the non-work items to check if a given timesheet item is holiday or leave
	private void fetchNonworkItems() {
		HOLIDAY_LIST.addAll(timesheetNonworkRepository.findByIsEnabled(true));
	}
}
