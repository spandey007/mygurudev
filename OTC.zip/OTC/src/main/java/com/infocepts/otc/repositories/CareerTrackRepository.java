/**
* Filename: /src/main/java/com/infocepts/otc/repositories/CareerTrackRepository.java
* @author  VVC
* @version 1.0
* @since   2018-11-13 
*/

package com.infocepts.otc.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import com.infocepts.otc.entities.CareerTrack;

public interface CareerTrackRepository extends CrudRepository<CareerTrack,Integer>{

	@Override
	public List<CareerTrack> findAll();
	
}

