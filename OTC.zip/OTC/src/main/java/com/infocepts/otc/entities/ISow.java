/**
* Filename: /src/main/java/com/infocepts/otc/controllers/ISow.java
* @author  JV
* @version 1.0
* @since   2018-10-31 
*/
package com.infocepts.otc.entities;


import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.SqlResultSetMappings;
import javax.persistence.Table;
import javax.persistence.Transient;
import com.infocepts.otc.utilities.LoadConstant;


@Entity
@Table(catalog=LoadConstant.otc, schema="[dbo]",name="isow")
@SqlResultSetMappings({
	@SqlResultSetMapping(
	      name = "isow_for_project_edit",
	      classes = {
	          @ConstructorResult(
	              targetClass = ISow.class,
	              columns = {
	            	  @ColumnResult(name = "isowId"),
	                  @ColumnResult(name = "isowNo"),
	                  @ColumnResult(name = "sowId"),
	                  @ColumnResult(name = "billingUnitId"), 
	                  @ColumnResult(name = "executionUnitId"), 
	                  @ColumnResult(name = "uomId"), 
	                  @ColumnResult(name = "projectId"),
	                  @ColumnResult(name = "currencyId"),
	                  @ColumnResult(name = "status"),
	                  @ColumnResult(name = "paymentTermDays"), 
	                  @ColumnResult(name = "internalServiceProvider"),
	                  @ColumnResult(name = "consultingAgrDate", type=Date.class),
	                  @ColumnResult(name = "scopeOfWork"),
	                  @ColumnResult(name = "conversionRate"),
	                  @ColumnResult(name = "outOfPocketExpense"),
	                  @ColumnResult(name = "partyTitle1"),
	                  @ColumnResult(name = "partyTitle2"),
	                  @ColumnResult(name = "name1"),
	                  @ColumnResult(name = "name2"),
	                  @ColumnResult(name = "partyDate", type=Date.class),
	                  @ColumnResult(name = "createdBy"),
	                  @ColumnResult(name = "modifiedBy"),
	                  @ColumnResult(name = "createdDate", type=Date.class),
	                  @ColumnResult(name = "modifiedDate", type=Date.class),
	                  @ColumnResult(name = "executionUnit"),
	                  @ColumnResult(name = "billingUnitAdr"),
	                  @ColumnResult(name = "comments"),
					  @ColumnResult(name = "filePath"),
					  @ColumnResult(name = "clientName"), 
	                  @ColumnResult(name = "projectName"),
	                  @ColumnResult(name = "sowNo")
	                }
	          )
	      }
	),
	@SqlResultSetMapping(
		      name = "isow_for_project_add",
		      classes = {
		          @ConstructorResult(
		              targetClass = ISow.class,
		              columns = {
		                  @ColumnResult(name = "clientName"), 
		                  @ColumnResult(name = "projectName"),
		                  @ColumnResult(name = "sowNo"),
		            	  @ColumnResult(name = "sowStartDate", type=Date.class),
		                  @ColumnResult(name = "sowEndDate", type=Date.class),
		                  @ColumnResult(name = "uomId"),
		                  @ColumnResult(name = "currencyId"),
		                  @ColumnResult(name = "currencySign"),
		                  @ColumnResult(name = "paymentTermDays")
		                }
		          )
		      }
		)
	
})
	@NamedNativeQueries({
	   @NamedNativeQuery(
	            name    =   "getISowForSowAdd",
	            query   =   " select  (Select title from " +LoadConstant.infomaster+ ".[dbo].accounts where itemId = p.accountId) as clientName," +
	            			" cast(p.title as varchar) as projectName,  "+
	            			" s.sowNo, s.sowStartDate, s.sowEndDate, " +
	            			" s.uomId as uomId,s.currencyId as currencyId, c.sign as currencySign, a.paymentTermDays as paymentTermDays "+
	            		 	" FROM " + LoadConstant.otc + ".[dbo].sow s"+
	            		 	" left join " + LoadConstant.otc + ".[dbo].isow i on s.sowId=i.sowId"+
	            			" left join " + LoadConstant.infomaster + ".[dbo].project p on p.itemId=s.projectId"+
	            			" left join " + LoadConstant.infomaster + ".[dbo].accounts a on p.accountId=a.itemId"+
	            			" LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[unit] u on u.unitId = p.billingUnitId "+
	            			" LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[billingtype] b on b.billingTypeId = p.billingTypeId " +
            				" left join " + LoadConstant.infomaster + ".[dbo].currency c on c.currencyId = s.currencyId" +
            				" Left Join " + LoadConstant.infomaster + ".[dbo].uom um on um.uomId = s.uomId"+
	                        " WHERE s.sowId= :sowId",
	                        resultClass=ISow.class, resultSetMapping = "isow_for_project_add"                       		
	    ),
	   @NamedNativeQuery(
	            name    =   "getISowForSowEdit",
	            query   =   " select i.*, ,'' as clientName, '' as projectName, '' as sowNo,(select u.name from " + LoadConstant.infomaster + ".[dbo].[unit] u on u.unitId = i.executionUnitId ) as executionUnit, '' as billingUnitAdr " +
	            		 	" FROM " + LoadConstant.otc + ".[dbo].isow i"+
	                        " WHERE i.isowId= :isowId",
	                        resultClass=ISow.class, resultSetMapping = "isow_for_project_edit"                       		
	    ),
	    @NamedNativeQuery(
	            name    =   "getLastISow",
	            query   =   "select TOP 1 i.* ,'' as clientName, '' as projectName, '' as sowNo, '' as executionUnit, '' as billingUnitAdr" +
	            			" FROM " + LoadConstant.otc + ".[dbo].isow i "+
	            			" Left Join " + LoadConstant.infomaster + ".[dbo].project p on p.itemId = i.projectId"+
	            			" Left Join " + LoadConstant.infomaster + ".[dbo].unit u on u.unitId = p.executionUnitId"+
	            			" where u.name = :executionUnit "+
	            			" order by i.isowId DESC",
	                        resultClass=ISow.class, resultSetMapping = "isow_for_project_edit"                       		
	    ),
	    @NamedNativeQuery(
	            name    =   "getISowsForAllProjects",
	            query   =   "select  i.* , (Select title from " +LoadConstant.infomaster+ ".[dbo].accounts where itemId = p.accountId) as clientName," +
	            			" cast(p.title as varchar) as projectName,  "+
	            			" s.sowNo, '' as executionUnit, '' as billingUnitAdr" +
	            			" FROM " + LoadConstant.otc + ".[dbo].isow i "+
	            			" left join " + LoadConstant.otc + ".[dbo].sow s on s.sowId=i.sowId"+
	            			" left join " + LoadConstant.infomaster + ".[dbo].project p on p.itemId=s.projectId"+
	            			" left join " + LoadConstant.infomaster + ".[dbo].accounts a on p.accountId=a.itemId"+
	            			" order by i.isowId DESC",
	                        resultClass=ISow.class, resultSetMapping = "isow_for_project_edit"                       		
	    )
	   
})
public class ISow {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer isowId;
	
	@ManyToOne
	@JoinColumn(name="sowId")
	private Sow sow;
	private String isowNo;
	// Fields related to project
	private Integer projectId;
	private Integer billingUnitId;
	private Integer executionUnitId;
	private Integer currencyId;
	private Integer uomId;
	private String status;
	private Integer paymentTermDays;
	private String internalServiceProvider;
	private Date consultingAgrDate;
	@Lob
	private String scopeOfWork;
	private String comments;
	@Column(precision=8,scale=4)
	private BigDecimal conversionRate;
	private String outOfPocketExpense;
	private String partyTitle1;
	private String partyTitle2;
	private String name1;
	private String name2;
	private Date partyDate;
	private Integer createdBy;
	private Integer modifiedBy;
	private Date createdDate;
	private Date modifiedDate;
	@Transient
	private String clientName;
	@Transient
	private String projectName;
	@Transient
	private String sowNo;
	@Transient
	private Date sowStartDate;
	@Transient
	private Date sowEndDate;
	@Transient
	private String currencySign;
	@Transient
	private String executionUnit;
	@Transient
	private String billingUnitAdr;
	private String filePath;
	/**
	 * @return the isowId
	 */
	public Integer getIsowId() {
		return isowId;
	}
	/**
	 * @param isowId the isowId to set
	 */
	public void setIsowId(Integer isowId) {
		this.isowId = isowId;
	}
	
	
	/**
	 * @return the sow
	 */
	public Sow getSow() {
		return sow;
	}
	/**
	 * @param sow the sow to set
	 */
	public void setSow(Sow sow) {
		this.sow = sow;
	}
	/**
	 * @return the isowNo
	 */
	public String getIsowNo() {
		return isowNo;
	}
	/**
	 * @param isowNo the isowNo to set
	 */
	public void setIsowNo(String isowNo) {
		this.isowNo = isowNo;
	}
	/**
	 * @return the projectId
	 */
	public Integer getProjectId() {
		return projectId;
	}
	/**
	 * @param projectId the projectId to set
	 */
	public void setProjectId(Integer projectId) {
		this.projectId = projectId;
	}
	/**
	 * @return the billingUnitId
	 */
	public Integer getBillingUnitId() {
		return billingUnitId;
	}
	/**
	 * @param billingUnitId the billingUnitId to set
	 */
	public void setBillingUnitId(Integer billingUnitId) {
		this.billingUnitId = billingUnitId;
	}
	/**
	 * @return the executionUnitId
	 */
	public Integer getExecutionUnitId() {
		return executionUnitId;
	}
	/**
	 * @param executionUnitId the executionUnitId to set
	 */
	public void setExecutionUnitId(Integer executionUnitId) {
		this.executionUnitId = executionUnitId;
	}
	
	/**
	 * @return the uomId
	 */
	public Integer getUomId() {
		return uomId;
	}
	/**
	 * @param uomId the uomId to set
	 */
	public void setUomId(Integer uomId) {
		this.uomId = uomId;
	}
	/**
	 * @return the currencyId
	 */
	public Integer getCurrencyId() {
		return currencyId;
	}
	/**
	 * @param currencyId the currencyId to set
	 */
	public void setCurrencyId(Integer currencyId) {
		this.currencyId = currencyId;
	}
	
	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	/**
	 * @return the paymentTermDays
	 */
	public Integer getPaymentTermDays() {
		return paymentTermDays;
	}
	/**
	 * @param paymentTermDays the paymentTermDays to set
	 */
	public void setPaymentTermDays(Integer paymentTermDays) {
		this.paymentTermDays = paymentTermDays;
	}
	/**
	 * @return the internalServiceProvider
	 */
	public String getInternalServiceProvider() {
		return internalServiceProvider;
	}
	/**
	 * @param internalServiceProvider the internalServiceProvider to set
	 */
	public void setInternalServiceProvider(String internalServiceProvider) {
		this.internalServiceProvider = internalServiceProvider;
	}
	/**
	 * @return the consultingAgrDate
	 */
	public Date getConsultingAgrDate() {
		return consultingAgrDate;
	}
	/**
	 * @param consultingAgrDate the consultingAgrDate to set
	 */
	public void setConsultingAgrDate(Date consultingAgrDate) {
		this.consultingAgrDate = consultingAgrDate;
	}
	/**
	 * @return the scopeOfWork
	 */
	public String getScopeOfWork() {
		return scopeOfWork;
	}
	/**
	 * @param scopeOfWork the scopeOfWork to set
	 */
	public void setScopeOfWork(String scopeOfWork) {
		this.scopeOfWork = scopeOfWork;
	}
	/**
	 * @return the outOfPocketExpense
	 */
	public String getOutOfPocketExpense() {
		return outOfPocketExpense;
	}
	/**
	 * @param outOfPocketExpense the outOfPocketExpense to set
	 */
	public void setOutOfPocketExpense(String outOfPocketExpense) {
		this.outOfPocketExpense = outOfPocketExpense;
	}
	/**
	 * @return the partyTitle
	 */
	public String getPartyTitle1() {
		return partyTitle1;
	}
	/**
	 * @param partyTitle the partyTitle to set
	 */
	public void setPartyTitle1(String partyTitle1) {
		this.partyTitle1 = partyTitle1;
	}
	/**
	 * @return the partyTitle
	 */
	public String getPartyTitle2() {
		return partyTitle2;
	}
	/**
	 * @param partyTitle the partyTitle to set
	 */
	public void setPartyTitle2(String partyTitle2) {
		this.partyTitle2 = partyTitle2;
	}
	/**
	 * @return the partyDate
	 */
	public Date getPartyDate() {
		return partyDate;
	}
	/**
	 * @param partyDate the partyDate to set
	 */
	public void setPartyDate(Date partyDate) {
		this.partyDate = partyDate;
	}
	/**
	 * @return the createdBy
	 */
	public Integer getCreatedBy() {
		return createdBy;
	}
	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}
	/**
	 * @return the modifiedBy
	 */
	public Integer getModifiedBy() {
		return modifiedBy;
	}
	/**
	 * @param modifiedBy the modifiedBy to set
	 */
	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	/**
	 * @return the createdDate
	 */
	public Date getCreatedDate() {
		return createdDate;
	}
	/**
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	/**
	 * @return the modifiedDate
	 */
	public Date getModifiedDate() {
		return modifiedDate;
	}
	/**
	 * @param modifiedDate the modifiedDate to set
	 */
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	/**
	 * @return the clientName
	 */
	public String getClientName() {
		return clientName;
	}
	/**
	 * @param clientName the clientName to set
	 */
	public void setClientName(String clientName) {
		this.clientName = clientName;
	}
	/**
	 * @return the projectName
	 */
	public String getProjectName() {
		return projectName;
	}
	/**
	 * @param projectName the projectName to set
	 */
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	/**
	
	/**
	 * @return the sowNo
	 */
	public String getSowNo() {
		return sowNo;
	}
	/**
	 * @param sowNo the sowNo to set
	 */
	public void setSowNo(String sowNo) {
		this.sowNo = sowNo;
	}
	/**
	 * @return the sowStartDate
	 */
	public Date getSowStartDate() {
		return sowStartDate;
	}
	/**
	 * @param sowStartDate the sowStartDate to set
	 */
	public void setSowStartDate(Date sowStartDate) {
		this.sowStartDate = sowStartDate;
	}
	/**
	 * @return the sowEndDate
	 */
	public Date getSowEndDate() {
		return sowEndDate;
	}
	/**
	 * @param sowEndDate the sowEndDate to set
	 */
	public void setSowEndDate(Date sowEndDate) {
		this.sowEndDate = sowEndDate;
	}
	/**
	 * @return the executionUnit
	 */
	public String getExecutionUnit() {
		return executionUnit;
	}
	/**
	 * @param executionUnit the executionUnit to set
	 */
	public void setExecutionUnit(String executionUnit) {
		this.executionUnit = executionUnit;
	}
	
	/**
	 * @return the currencySign
	 */
	public String getCurrencySign() {
		return currencySign;
	}
	/**
	 * @param currencySign the currencySign to set
	 */
	public void setCurrencySign(String currencySign) {
		this.currencySign = currencySign;
	}
	
	
	/**
	 * @return the billingUnitAdr
	 */
	public String getBillingUnitAdr() {
		return billingUnitAdr;
	}
	/**
	 * @param billingUnitAdr the billingUnitAdr to set
	 */
	public void setBillingUnitAdr(String billingUnitAdr) {
		this.billingUnitAdr = billingUnitAdr;
	}
	
	/**
	 * @return the name1
	 */
	public String getName1() {
		return name1;
	}
	/**
	 * @param name1 the name1 to set
	 */
	public void setName1(String name1) {
		this.name1 = name1;
	}
	/**
	 * @return the name2
	 */
	public String getName2() {
		return name2;
	}
	/**
	 * @param name2 the name2 to set
	 */
	public void setName2(String name2) {
		this.name2 = name2;
	}
	
	/**
	 * @return the comments
	 */
	public String getComments() {
		return comments;
	}
	/**
	 * @param comments the comments to set
	 */
	public void setComments(String comments) {
		this.comments = comments;
	}
		public String getFilePath() {
		return filePath;
	}
	
	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}

	/**
	 * @return the conversionRate
	 */
	public BigDecimal getConversionRate() {
		return conversionRate;
	}
	/**
	 * @param conversionRate the conversionRate to set
	 */
	public void setConversionRate(BigDecimal conversionRate) {
		this.conversionRate = conversionRate;
	}
	
	public ISow() {
	}
	
	
	public ISow(String clientName, String projectName, String sowNo, Date sowStartDate, Date sowEndDate ,Integer uomId,Integer currencyId
			,String currencySign, Integer paymentTermDays) {
		super();
		this.clientName = clientName;
		this.projectName = projectName;
		this.sowNo = sowNo;
		this.sowStartDate = sowStartDate;
		this.sowEndDate = sowEndDate;
		this.uomId = uomId;
		this.currencyId = currencyId;
		this.currencySign = currencySign;
	    this.paymentTermDays = paymentTermDays;
	}
	
	public ISow(Integer isowId, String isowNo, Integer sowId,Integer billingUnitId,
			Integer executionUnitId, Integer uomId, Integer projectId, Integer currencyId,  String status, Integer paymentTermDays,
			String internalServiceProvider, Date consultingAgrDate, String scopeOfWork, BigDecimal conversionRate, String outOfPocketExpense,
			String partyTitle1,String partyTitle2, String name1, String name2, Date partyDate, Integer createdBy, Integer modifiedBy, Date createdDate,
			Date modifiedDate,String executionUnit, String billingUnitAdr, String comments, String filePath,String clientName, String projectName, String sowNo) {
		super();
		this.isowId = isowId;
		this.isowNo = isowNo;
		if(sowId != null)
		{
			this.sow = new Sow();
			this.sow.setSowId(sowId);
		}
		this.billingUnitId = billingUnitId;
		this.executionUnitId = executionUnitId;
		this.uomId = uomId;
		this.projectId = projectId;
		this.currencyId = currencyId;
		this.status = status;
		this.paymentTermDays = paymentTermDays;
		this.internalServiceProvider = internalServiceProvider;
		this.consultingAgrDate = consultingAgrDate;
		this.scopeOfWork = scopeOfWork;
		this.conversionRate = conversionRate;
		this.outOfPocketExpense = outOfPocketExpense;
		this.partyTitle1 = partyTitle1;
		this.partyTitle2 = partyTitle2;
		this.name1 = name1;
		this.name2 = name2;
		this.partyDate = partyDate;
		this.createdBy = createdBy;
		this.modifiedBy = modifiedBy;
		this.createdDate = createdDate;
		this.modifiedDate = modifiedDate;
		this.executionUnit = executionUnit;
		this.billingUnitAdr  = billingUnitAdr;
		this.comments = comments;
		this.filePath = filePath;
		this.clientName = clientName;
		this.projectName = projectName;
		this.sowNo = sowNo;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "ISow [isowId=" + isowId + ", sow=" + sow + ", isowNo=" + isowNo + ", projectId=" + projectId
				+ ", billingUnitId=" + billingUnitId + ", executionUnitId=" + executionUnitId + ", currencyId="
				+ currencyId + ", uomId=" + uomId + ", status=" + status + ", paymentTermDays=" + paymentTermDays
				+ ", internalServiceProvider=" + internalServiceProvider + ", consultingAgrDate=" + consultingAgrDate
				+ ", scopeOfWork=" + scopeOfWork + ", comments=" + comments + ", outOfPocketExpense="
				+ outOfPocketExpense + ", partyTitle1=" + partyTitle1 + ", partyTitle2=" + partyTitle2 + ", name1="
				+ name1 + ", name2=" + name2 + ", partyDate=" + partyDate + ", createdBy=" + createdBy + ", modifiedBy="
				+ modifiedBy + ", createdDate=" + createdDate + ", modifiedDate=" + modifiedDate + ", clientName="
				+ clientName + ", projectName=" + projectName + ", sowNo=" + sowNo + ", sowStartDate=" + sowStartDate
				+ ", sowEndDate=" + sowEndDate + ", currencySign=" + currencySign + ", executionUnit=" + executionUnit
				+ ", billingUnitAdr=" + billingUnitAdr + ", filePath=" + filePath + "]";
	}	
}
