/**
* Filename: /src/main/java/com/infocepts/otc/controllers/CategoryController.java
* @author  SRA
* @version 1.0
* @since   2018-08-01 
* Step 1 - Replace <ModuleName> (case-sensitive) with the ModuleName 
* Step 2 - Replace <moduleName> (case-sensitive) with the moduleName 
* Step 3 - Replace moduleNameList with the <moduleNameList>
* Step 3 - Replace <database(e.g. pms)>/<moduleurl> (case-sensitive) with the pms/category 
* 
*/

package com.infocepts.otc.controllers;

import java.util.logging.Logger;
import com.infocepts.pms.entities.PmsCategory;
import com.infocepts.pms.repositories.PmsCategoryRepository;
import com.infocepts.otc.services.TimesheetService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.mail.MessagingException;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.List;

@RestController
@RequestMapping(value="api/pms/category",headers="referer")
public class PmsCategoryController {

    final Logger logger = Logger.getLogger(PmsCategoryController.class.getName());

    @Autowired
    PmsCategoryRepository repository;
    
    @Autowired
    HttpSession session;

    @PersistenceContext(unitName = "pms") 
    private EntityManager manager;
			
	@Autowired
	TimesheetService service;

	/**
   * This method is used to find results set from module entity
   * based on params passed from JS file
   */
    @RequestMapping(method = RequestMethod.GET)
    public List<PmsCategory> findAllCategories(HttpServletRequest request){
        List<PmsCategory> categoryList = null;
        Integer loggedInUid = (Integer) session.getAttribute("loggedInUid");
        
        try {
        	/* ------------------------- Authorization start ------------------------------------ */
			// Authorization for HR-PMS role
			if(!service.isHRPms() || !service.isHRPmsAdmin())
			{
				service.sendTamperedMail("Category view all", 0, 0, request);
				return categoryList;
			}
			/* ------------------------- Authorization ends ------------------------------------ */
				
			categoryList = manager.createNamedQuery("getAllCategories", PmsCategory.class) 
                    .getResultList();
         } 
		catch (Exception e){
			 logger.info(String.format("exception - ", e));
        }
        return categoryList;

    }
    
    /**
     * This method is add row in moduleName entity
     * 
     */
    @RequestMapping(method=RequestMethod.POST)
	public PmsCategory addCategory(@RequestBody PmsCategory category, HttpServletRequest request) throws MessagingException {
		// Authorization for Admin role
		if(service.isHRPms() || service.isHRPmsAdmin())
		{
			try{
				category.setCategoryId(null);
				repository.save(category);
			}
			catch(Exception e){
				 logger.info(String.format("exception - ", e));
			}
		}
		else 
		{
			service.sendTamperedMail("Category Save", 0, 0, request);
		}		
		return category;
	}
    
    /**
     * This method is update row in moduleName entity
     * based on primaryKey Of Module Table 
     */
    @RequestMapping(value="/{categoryId}", method=RequestMethod.PUT)
	 public PmsCategory updateCategory(@RequestBody PmsCategory updatedCategory, @PathVariable Integer categoryId, HttpServletRequest request)  throws MessagingException{
        // Authorization for Admin role
		if(service.isHRPms() || service.isHRPmsAdmin())
		{	
			try{
				 updatedCategory.setCategoryId(categoryId);
				 repository.save(updatedCategory);
			}
			catch(Exception e){
				 logger.info(String.format("exception - ", e));
			}
		}
		else
		{
			service.sendTamperedMail("Category Save", 0, 0, request);
		}
		 return updatedCategory;
	 }
    
    /**
     * This method is get data for specific row in moduleName entity
     * based on primaryKey Of Module Table 
     */
    @RequestMapping(value="/{categoryId}", method=RequestMethod.GET)
	 public PmsCategory getCategory(@PathVariable Integer categoryId, HttpServletRequest request) throws MessagingException{
    	
    	PmsCategory category = null;
		// Authorization for Admin role
		if(service.isHRPms() || service.isHRPmsAdmin())
		{
			try{
				 category = manager.createNamedQuery("getCategoryById", PmsCategory.class)
						 .setParameter("categoryId", categoryId)
						 .getSingleResult();
			 }
			 catch(Exception e){
				 logger.info(String.format("exception - ", e));
			 }
		}
		else 
		{
			service.sendTamperedMail("Category Get", 0, 0, request);
		}
		 
		 return category;
	 }
	 
    
    /**
     * This method is delete data for specific row in moduleName entity
     * based on primaryKey Of Module Table 
     */	 
	@RequestMapping(value="/{categoryId}", method=RequestMethod.DELETE)
	public void deleteCategory(@PathVariable Integer categoryId, HttpServletRequest request) throws MessagingException {
		// Authorization for XYZ role
		if(service.isHRPms() || service.isHRPmsAdmin())
		{
			try{
			repository.delete(categoryId);
			}
			catch(Exception e){
				 logger.info(String.format("exception - ", e));
			}
		}
		else
		{
			service.sendTamperedMail("Category Delete", 0, 0, request);
		}		 
	}
   
}
