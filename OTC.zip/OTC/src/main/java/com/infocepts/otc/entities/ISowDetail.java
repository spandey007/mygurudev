/**
* Filename: /src/main/java/com/infocepts/otc/controllers/ISowDetail.java
* @author  JV
* @version 1.0
* @since   2018-10-31 
*/
package com.infocepts.otc.entities;

import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.SqlResultSetMappings;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.infocepts.otc.utilities.LoadConstant;

@Entity
@Table(catalog=LoadConstant.otc, schema="[dbo]",name="isowDetail")
@SqlResultSetMappings({
	@SqlResultSetMapping(
		      name = "isowdetails_edit",
		      classes = {
		          @ConstructorResult(
		              targetClass = ISowDetail.class,
		              columns = {
		                  @ColumnResult(name = "isowDetailId"),
		                  @ColumnResult(name = "isowId"),
		                  @ColumnResult(name = "billableRate", type=BigDecimal.class),
		                  @ColumnResult(name = "expectedBillability", type=BigDecimal.class),
		                  @ColumnResult(name = "clientRole", type=String.class),
		                 // @ColumnResult(name = "conversionRate", type=BigDecimal.class),
		                  @ColumnResult(name = "rateInSGD", type=BigDecimal.class),
		                  @ColumnResult(name = "createdBy"),
		                  @ColumnResult(name = "modifiedBy"),
		                  @ColumnResult(name = "createdDate", type=Date.class),
		                  @ColumnResult(name = "modifiedDate", type=Date.class),
		                  @ColumnResult(name = "sowRoleStartDate", type=Date.class),
		                  @ColumnResult(name = "sowRoleEndDate", type=Date.class),
		                  @ColumnResult(name = "countryId")
		                }
		          )
		      }
	),
	@SqlResultSetMapping(
		      name = "isowdetails_add",
		      classes = {
		          @ConstructorResult(
		              targetClass = ISowDetail.class,
		              columns = {
		                   @ColumnResult(name = "billableRate", type=BigDecimal.class),
		                   @ColumnResult(name = "sowRoleStartDate", type=Date.class),
		                   @ColumnResult(name = "sowRoleEndDate", type=Date.class),
		                   @ColumnResult(name = "expectedBillability", type=BigDecimal.class),
		                   @ColumnResult(name = "clientRole", type=String.class),
		                   @ColumnResult(name = "sowMilestoneId"),
		                   @ColumnResult(name = "description"),
		                   @ColumnResult(name = "milestoneEndDate", type=Date.class),
		                   @ColumnResult(name = "countryName", type=String.class),
		                   @ColumnResult(name = "uomName", type=String.class),
		                }
		          )
		      }
	)
})
	@NamedNativeQueries({
		 @NamedNativeQuery(
		            name    =   "getISowDetailsBySowId",
		            query   =   " select sd.billableRate as billableRate,sd.sowRoleStartDate,sd.sowRoleEndDate,sd.expectedBillability as expectedBillability, "+
		            			" sd.clientRole as clientRole, c.countryName,  uom.name as uomName " +
		            		 	" FROM " + LoadConstant.otc + ".[dbo].sowDetail sd "+
		            		 	" left join " + LoadConstant.otc + ".[dbo].sow s on s.sowId = sd.sowId"+
		            		 	" left join " + LoadConstant.infomaster + ".[dbo].uom uom on uom.uomId = s.uomId"+
		            		 	" left join " + LoadConstant.infomaster + ".[dbo].currency cur on cur.currencyId = s.currencyId"+
		            		 	" left join " + LoadConstant.infomaster + ".[dbo].country c on c.countryId = sd.countryId"+
		            		    " WHERE s.sowId= :sowId and  sd.isBillable = 1 and (sd.sowRoleStartDate between :sowStartDate and :sowEndDate) and " +
		            		    " (sd.sowRoleEndDate between :sowStartDate and :sowEndDate)",
		                        resultClass=ISowDetail.class, resultSetMapping = "isowdetails_add"                       		
		    ),
		 @NamedNativeQuery(
		            name    =   "getISowDetailsByISowId",
		            query   =   " select  sd.* " +
		            		 	" FROM " + LoadConstant.otc + ".[dbo].isowDetail sd "+
		            		 	" left join " + LoadConstant.otc + ".[dbo].isow i on i.isowId = sd.isowId"+
		            		    " WHERE i.isowId= :isowId  ", 
		            		     resultClass=ISowDetail.class, resultSetMapping = "isowdetails_edit"                       		
		    )
	})
public class ISowDetail {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer isowDetailId;
	
	@ManyToOne
	@JoinColumn(name="isowId")
	private ISow isow;
	
	// Different fields as compared to cmsDetails entity
	@Column(precision=12,scale=2)
	private BigDecimal billableRate;//for T&M 
	private Integer createdBy;
	private Integer modifiedBy;
	private Date createdDate;
	private Date modifiedDate;
	/*@Column(precision=8,scale=4)
	private BigDecimal conversionRate;*/
	@Column(precision=12,scale=4)
	private BigDecimal rateInSGD;
	@Transient
	private String countryName;
	@Transient
	private String uomName;
	private String clientRole;
	private Date sowRoleStartDate;
	private Date sowRoleEndDate;
	private Integer countryId;
	
	@Column(precision=6,scale=2)
	private BigDecimal expectedBillability;//for T&M 
	/**
	 * @return the isowDetailId
	 */
	public Integer getIsowDetailId() {
		return isowDetailId;
	}
	/**
	 * @param isowDetailId the isowDetailId to set
	 */
	public void setIsowDetailId(Integer isowDetailId) {
		this.isowDetailId = isowDetailId;
	}
	/**
	 * @return the isow
	 */
	public ISow getIsow() {
		return isow;
	}
	/**
	 * @param isow the isow to set
	 */
	public void setIsow(ISow isow) {
		this.isow = isow;
	}
	/**
	 * @return the clientRole
	 */
	public String getClientRole() {
		return clientRole;
	}
	/**
	 * @param clientRole the clientRole to set
	 */
	public void setClientRole(String clientRole) {
		this.clientRole = clientRole;
	}
	/**
	 * @return the sowRoleStartDate
	 */
	public Date getSowRoleStartDate() {
		return sowRoleStartDate;
	}
	/**
	 * @param sowRoleStartDate the sowRoleStartDate to set
	 */
	public void setSowRoleStartDate(Date sowRoleStartDate) {
		this.sowRoleStartDate = sowRoleStartDate;
	}
	/**
	 * @return the sowRoleEndDate
	 */
	public Date getSowRoleEndDate() {
		return sowRoleEndDate;
	}
	/**
	 * @param sowRoleEndDate the sowRoleEndDate to set
	 */
	public void setSowRoleEndDate(Date sowRoleEndDate) {
		this.sowRoleEndDate = sowRoleEndDate;
	}
	/**
	 * @return the billableRate
	 */
	public BigDecimal getBillableRate() {
		return billableRate;
	}
	/**
	 * @param billableRate the billableRate to set
	 */
	public void setBillableRate(BigDecimal billableRate) {
		this.billableRate = billableRate;
	}
	/**
	 * @return the expectedBillability
	 */
	public BigDecimal getExpectedBillability() {
		return expectedBillability;
	}
	/**
	 * @param expectedBillability the expectedBillability to set
	 */
	public void setExpectedBillability(BigDecimal expectedBillability) {
		this.expectedBillability = expectedBillability;
	}
	/**
	 * @return the createdBy
	 */
	public Integer getCreatedBy() {
		return createdBy;
	}
	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}
	/**
	 * @return the modifiedBy
	 */
	public Integer getModifiedBy() {
		return modifiedBy;
	}
	/**
	 * @param modifiedBy the modifiedBy to set
	 */
	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	/**
	 * @return the createdDate
	 */
	public Date getCreatedDate() {
		return createdDate;
	}
	/**
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	/**
	 * @return the modifiedDate
	 */
	public Date getModifiedDate() {
		return modifiedDate;
	}
	/**
	 * @param modifiedDate the modifiedDate to set
	 */
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	
	
	/**
	 * @return the conversionRate
	 *//*
	public BigDecimal getConversionRate() {
		return conversionRate;
	}
	*//**
	 * @param conversionRate the conversionRate to set
	 *//*
	public void setConversionRate(BigDecimal conversionRate) {
		this.conversionRate = conversionRate;
	}*/
	/**
	 * @return the rateInSGD
	 */
	public BigDecimal getRateInSGD() {
		return rateInSGD;
	}
	/**
	 * @param rateInSGD the rateInSGD to set
	 */
	public void setRateInSGD(BigDecimal rateInSGD) {
		this.rateInSGD = rateInSGD;
	}
	/**
	 * @return the countryName
	 */
	public String getCountryName() {
		return countryName;
	}
	/**
	 * @param countryName the countryName to set
	 */
	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}
	/**
	 * @return the uomName
	 */
	public String getUomName() {
		return uomName;
	}
	/**
	 * @param uomName the uomName to set
	 */
	public void setUomName(String uomName) {
		this.uomName = uomName;
	}
	
	
	
	/**
	 * @return the countryId
	 */
	public Integer getCountryId() {
		return countryId;
	}
	/**
	 * @param countryId the countryId to set
	 */
	public void setCountryId(Integer countryId) {
		this.countryId = countryId;
	}
	public ISowDetail() {
		
	}
	public ISowDetail(Integer isowDetailId, Integer isowId,BigDecimal billableRate, BigDecimal expectedBillability,
			String clientRole/*,BigDecimal conversionRate*/, BigDecimal rateInSGD,Integer createdBy, Integer modifiedBy, Date createdDate,
			Date modifiedDate, Date sowRoleStartDate, Date sowRoleEndDate, Integer countryId) {
		super();
		this.isowDetailId = isowDetailId;
		if(isowId != null)
		{
			this.isow = new ISow();
			this.isow.setIsowId(isowId);
		}
		this.billableRate = billableRate;
		this.expectedBillability = expectedBillability;
		this.clientRole = clientRole;
		//this.conversionRate = conversionRate;
		this.rateInSGD = rateInSGD;
		this.createdBy = createdBy;
		this.modifiedBy = modifiedBy;
		this.createdDate = createdDate;
		this.modifiedDate = modifiedDate;
		this.sowRoleStartDate = sowRoleStartDate;
		this.sowRoleEndDate = sowRoleEndDate;
		this.countryId = countryId;
	}
	
	public ISowDetail(BigDecimal billableRate,Date sowRoleStartDate, Date sowRoleEndDate, BigDecimal expectedBillability,
			String clientRole , String countryName, String uomName) {
		super();
		
		this.billableRate = billableRate;
		this.sowRoleStartDate = sowRoleStartDate;
		this.sowRoleEndDate = sowRoleEndDate;
		this.expectedBillability = expectedBillability;
		this.clientRole = clientRole;
		this.countryName = countryName;
		this.uomName = uomName;
		
	}
}
