package com.infocepts.otc.repositories;

import java.util.List;
import org.springframework.data.repository.CrudRepository;
import com.infocepts.otc.entities.Milestone;

public interface MilestoneRepository extends CrudRepository<Milestone,Integer>{

	@Override
	public List<Milestone> findAll();
}
