package com.infocepts.otc.entities;

import java.math.BigDecimal;
import java.sql.Date;

import org.springframework.stereotype.Component;

@Component
public class WeeklyHours {
	
	private Date periodEnd;
	private String resourceName;
	private BigDecimal tsHrs;
	private Integer uid;
	private String infoCeptsRole;
	public Date getPeriodEnd() {
		return periodEnd;
	}
	public void setPeriodEnd(Date periodEnd) {
		this.periodEnd = periodEnd;
	}
	public String getResourceName() {
		return resourceName;
	}
	public void setResourceName(String resourceName) {
		this.resourceName = resourceName;
	}
	public BigDecimal getTsHrs() {
		return tsHrs;
	}
	public void setTsHrs(BigDecimal tsHrs) {
		this.tsHrs = tsHrs;
	}
	public Integer getUid() {
		return uid;
	}
	public void setUid(Integer uid) {
		this.uid = uid;
	}
	
	public String getInfoCeptsRole() {
		return infoCeptsRole;
	}
	public void setInfoCeptsRole(String infoCeptsRole) {
		this.infoCeptsRole = infoCeptsRole;
	}
	/*@Override
	public String toString() {
		return "WeeklyHours [periodEnd=" + periodEnd + ", resourceName=" + resourceName + ", tsHrs=" + tsHrs + ", uid="
				+ uid + ", getPeriodEnd()=" + getPeriodEnd() + ", getResourceName()=" + getResourceName()
				+ ", getTsHrs()=" + getTsHrs() + ", getUid()=" + getUid() + ", getClass()=" + getClass()
				+ ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}*/
	
	

}
