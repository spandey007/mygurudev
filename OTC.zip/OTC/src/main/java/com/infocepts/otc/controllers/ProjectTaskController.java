package com.infocepts.otc.controllers;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;

import javax.mail.MessagingException;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.collections.CollectionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.infocepts.otc.entities.Allocation;
import com.infocepts.otc.entities.GtpSr;
import com.infocepts.otc.entities.ProjectTask;
import com.infocepts.otc.entities.TimesheetPeriods;
import com.infocepts.otc.repositories.AllocationRepository;
import com.infocepts.otc.repositories.ProjectTaskRepository;
import com.infocepts.otc.repositories.TimesheetPeriodsRepository;
import com.infocepts.otc.services.ProjectTaskService;
import com.infocepts.otc.services.TimesheetService;



/**
 * @author vkamble
 * Modified by: Rewatiraman Singh, Modified Date: 19th March 2019
 *
 */
@RestController
@RequestMapping(value="/projecttask",headers="referer")//JV: Added 'headers' param to validate the url.
public class ProjectTaskController {

	final Logger logger = Logger.getLogger(ProjectTaskController.class);
	
	@Autowired
	ProjectTaskRepository repository;

	@Autowired
    ProjectTaskService projectTaskService;
	
	@Autowired
	TimesheetPeriodsRepository periodRepository;
	
	@Autowired
	HttpSession session;
	
	@Autowired
	TimesheetService service;
	
	@Autowired
	private AllocationRepository allocationRepository;
	
	@PersistenceContext(unitName="otc")
    private EntityManager manager;
	
	@RequestMapping(method=RequestMethod.GET)
	public List<ProjectTask> findAllProjectTasks(@RequestParam(value = "periodId", defaultValue = "0") Integer periodId,
			@RequestParam(value = "uid", defaultValue = "0") Integer uid,
			@RequestParam(value = "pid", defaultValue = "0") Integer pid,
			@RequestParam(value = "status", defaultValue = "Active") String status,					
			@RequestParam(value = "unalc", defaultValue = "0") Boolean unalc,
			HttpServletRequest request) {
		List<ProjectTask> projectTasks = null;
		try{
			/* ------------------------- Authorization start ------------------------------------ */
			Integer loggedInUid = (Integer) session.getAttribute("loggedInUid");
			
			Boolean isAValidCall = false;
			if(uid == 0) // If uid is not passed, set it to current logged in user id
			{
				uid = loggedInUid;
			}
			else // If uid is passed, it can be of a delegated user
			{
				if((!uid.equals(loggedInUid)) && (!service.isAdmin()))
				{
					//code for delegation
					isAValidCall = service.isValidDelegation(uid);
					if(isAValidCall == false)
					{
						service.sendTamperedMail("Projects Tasks", 0, 0, request);
						return projectTasks; // return null for invalid delegation
					}
				}
			}
			/* ------------------------- Authorization end ------------------------------------ */
			TimesheetPeriods currentPeriod = null;
			
			if(pid != 0) // Retrieve all tasks for the project with pid provided for the user
			{
				projectTasks = manager.createNamedQuery("getAllProjectTasks", ProjectTask.class)
						 .setParameter("pid", pid)
				            .getResultList();				
			}			
			else if(periodId != 0 && uid != 0 && unalc) // Retrieve all tasks for all un-allocated internal projects for the user
			{
				projectTasks = manager.createNamedQuery("getNonAllocatedTasksForUser", ProjectTask.class)
//						.setParameter("uid", uid) 
//						.setParameter("periodId", periodId)
				            .getResultList();
			}
			else if(periodId != 0 && uid != 0) // Retrieve all tasks for all projects for the user
			{				
				currentPeriod = periodRepository.findOne(periodId);
				
				String assignedToUid = Integer.toString(uid);			
				projectTasks = manager.createNamedQuery("getProjectTasksForUserNotInCurrentTs", ProjectTask.class)
						 .setParameter("uid", uid)
						 .setParameter("assignedToUid", assignedToUid)
						 .setParameter("periodId", periodId)
						 //.setParameter("periodStartDate", currentPeriod.getPeriodStart())
						 //.setParameter("periodEndDate", currentPeriod.getPeriodEnd())
				         .getResultList();
				
			}
			else if(uid != 0) // Retrieve all tasks for the user
			{	
				String assignedToUid = Integer.toString(uid);	
				if(status.equals("Active"))
				{
					projectTasks = manager.createNamedQuery("getActiveProjectTasksForUser", ProjectTask.class)
							 .setParameter("assignedToUid", assignedToUid)
					         .getResultList();
				}
				else
				{
					projectTasks = manager.createNamedQuery("getInActiveProjectTasksForUser", ProjectTask.class)
							 .setParameter("assignedToUid", assignedToUid)
					         .getResultList();
				}
			}
			
			/* Don't apply the filter to check projection allocation end dates if the current request is 
			 * sent to fetch generic tasks. 
			*/
			if (!unalc) {
				projectTasks.retainAll(getActiveProjectTasks(projectTasks, currentPeriod, uid));
			}
			
		
			
		}
		catch(Exception e){
			logger.error(e);
		}
		return projectTasks;
	}	
	
	@RequestMapping(value="/{taskId}",method=RequestMethod.GET)
	public ProjectTask findProjectTaskById(@PathVariable Integer taskId) {
		ProjectTask projecttask = null;
		try{
			projecttask = repository.findOne(taskId);
		}catch(Exception e){
			logger.error(e);
		}
		return projecttask;
	}
	
	@RequestMapping(method=RequestMethod.POST)
	public ProjectTask addProjectTask(@RequestBody ProjectTask task) {
		try{
			repository.save(task);
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		return task;
	}
	
	@RequestMapping(value="/{taskId}",method=RequestMethod.PUT)
	public ProjectTask updateProjectTask(@PathVariable Integer taskId,@RequestBody ProjectTask task) {
		 try{
			repository.save(task);
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		return task;
	}
	
	@RequestMapping(value="/{taskId}",method=RequestMethod.DELETE)
	public void deleteProjectTask(@PathVariable Integer taskId) {
		 try{
			 repository.delete(taskId);
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
	}


	@RequestMapping(value = "get-all-tasks/{projectId}", method = RequestMethod.GET)
	public ResponseEntity<List<ProjectTask>> getAllTasksInProject(@PathVariable final Integer projectId,
												HttpServletRequest request) throws MessagingException, UnauthorizedException {
		
		/* ------------------------- Authorization start ------------------------------------ */
		Boolean isAValidCall = true; 
		if(projectId != 0)
		{
			isAValidCall = service.isAValidSOWCall(projectId, 0, "Project plan By Project", request);
			if(isAValidCall == false)
			{	
				throw new UnauthorizedException("Access Denied");
			}
		}		
		return new ResponseEntity<>(this.projectTaskService.getAllTasksForProject(projectId), HttpStatus.OK);
	}

	@RequestMapping(value = "update-task-center/{projectId}", method = RequestMethod.PUT)
	public ResponseEntity<List<ProjectTask>> patchTaskCenter(@PathVariable final Integer projectId, @RequestBody List<ProjectTask> projectTaskList) {
		return new ResponseEntity<>(this.projectTaskService.saveAllTasksForProject(projectId, projectTaskList), HttpStatus.OK);
	}
	
	/**
	 * @param projectTaskList
	 * @param currentPeriod
	 * @return - ArrayList containing only active project tasks.
	 */
	private List<ProjectTask> getActiveProjectTasks(List<ProjectTask> projectTaskList, TimesheetPeriods currentPeriod, Integer uid) {
		List<ProjectTask> filteredProjectTaskList = new ArrayList<>();
		Date periodStart = null;
		
		if (!CollectionUtils.isEmpty(projectTaskList) && currentPeriod != null && uid != null) {
			periodStart = currentPeriod.getPeriodStart();
			for (ProjectTask projectTask : projectTaskList) {
				List<Allocation> allocationList = allocationRepository.findAllocation(projectTask.getProjectId(), uid);
				List<Date> allocDateList = new ArrayList<>();
				int size = allocationList.size();
				
				for (int count = 0; count < size; count++) {
					/*
					 * If allocation size is one then it means that the particular project either
					 * have a billable or a non-billable allocation, not both.
					 */
					if (size == 1) {
						if (allocationList.get(0).getAlcEndDate().before(periodStart)) {
							break;
						} else {
							filteredProjectTaskList.add(projectTask);
						}

					} else {
						Date firstAllocEndDate = allocDateList.get(0);
						Date secondAllocEndDate = allocDateList.get(1);
						
						/* When one allocation is ended and another is yet to end, then consider it active and add to 
						arraylist. */
						if (firstAllocEndDate.before(periodStart) && !secondAllocEndDate.before(periodStart)) {
							filteredProjectTaskList.add(projectTask);
						} else if (!firstAllocEndDate.before(periodStart) && secondAllocEndDate.before(periodStart)) {
							filteredProjectTaskList.add(projectTask);
						} 
						/*When both the allocations are active then add that project task in array list*/
						else if (!firstAllocEndDate.before(periodStart) && !secondAllocEndDate.before(periodStart)) {
							filteredProjectTaskList.add(projectTask);
						} 
						/*When both billable/non-billable that is both types of allocations are ended then skip that project
						 * task.*/
						else {
							continue;
						}
						
					}
				}
			}
		}
		
		return filteredProjectTaskList;
	}
	@GetMapping("/getAllProjectTasksByProjectDropdown")
	public Object getAllProjectTasksByProjectDropdown(@RequestParam(value = "projId", defaultValue = "0") Integer projId
			, HttpServletRequest request) {
		List<ProjectTask> projectTasks = null;

		try {
			if (projId!=0) {
				 projectTasks =  manager.createNamedQuery("getAllProjectTasksByProjectDropdown", ProjectTask.class)
						 .setParameter("projId", projId)
						 .getResultList();
			       
			}
		} catch (Exception e) {
			//logger.log(Level.SEVERE, "exceptn msg", e);
		}
		return projectTasks;
	}
}
