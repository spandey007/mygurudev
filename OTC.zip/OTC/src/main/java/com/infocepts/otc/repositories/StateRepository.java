package com.infocepts.otc.repositories;

import java.util.List;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import com.infocepts.otc.entities.State;
import java.lang.String;

public interface StateRepository extends CrudRepository<State,Integer>{

	@Override
	public List<State> findAll();
	
	@Query("from State where stateName = :stateName")
	public State findByStateName(@Param("stateName") String stateName);
	
	@Query("from State where countryId = :countryId")
	public List<State> findByCountryId(@Param("countryId") Integer countryId);
}
