package com.infocepts.otc.controllers;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import java.util.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import org.springframework.web.bind.annotation.RestController;

import com.infocepts.otc.entities.Project;
import com.infocepts.otc.repositories.MSTRConnectRepository;
import com.infocepts.otc.webservice.MSTREncryptionService;


@RestController
@RequestMapping(value="/mstr",headers="referer") //JV: Added 'headers' param to validate the url.
public class MSTRConnectController {
	final Logger logger = Logger.getLogger(MSTRConnectController.class.getName());
	
	@Autowired
	HttpSession session;
	
	@Value("${spring.mstr.url}")
	private String commonrUrl;
	
	@Value("${spring.mstr.pmdm.url}")
	private String pmDmUrl;
	
	@Value("${spring.mstr.admin.url}")
	private String adminUrl;
			
	@Value("${spring.encrypt.url}")
	private String encrypturl;

	@Autowired
	MSTRConnectRepository mstrrepository;
	
	@PersistenceContext(unitName="otc")
    private EntityManager manager;
	
	@RequestMapping(method=RequestMethod.GET, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<String>> getMSTRMapping ( HttpServletRequest request) throws Exception{
	
		String mstruser 			= null;
		String mstrresponse 		= null;
		String mstrurl				= null;
		List<String> responseList 	= new ArrayList<String>();
		List<Project> projects		= null;
		String uid 					= String.valueOf(session.getAttribute("loggedInUid"));
		String ldapuser				= String.valueOf(session.getAttribute("username"));
		try {
			/*projects = manager.createNamedQuery("getProjectsAsCep", Project.class)
					.setParameter("state", "Active") 
					.setParameter("cepUid", uid)
					.getResultList();
			if(!projects.isEmpty()){
				mstruser = "RM1";
				mstrurl  = pmDmUrl;
				projects.clear();
			}else{
				projects =  manager.createNamedQuery("getDMProjects", Project.class)
						 	.setParameter("dmUid", uid)
						 	.getResultList();
				if(!projects.isEmpty()){
					mstruser = "DM1";
					mstrurl  = pmDmUrl;
					projects.clear();
				}else{
					projects = manager.createNamedQuery("getProjectsByPm", Project.class)
							.setParameter("state", "Active") 
							.setParameter("pmUid", uid)
							.getResultList();
					if(!projects.isEmpty()){
							mstruser = "PM1";
							mstrurl  = pmDmUrl;
							projects.clear();
					}else{
						projects =  manager.createNamedQuery("getPlanners", Project.class)
								  .setParameter("uid", uid)
								  .getResultList();
						if(!projects.isEmpty()){
							mstruser = "PP1";
							mstrurl  = commonrUrl;
							projects.clear();
						}else{
							mstruser = "Associate";
							mstrurl  = commonrUrl;
						}
					}
				}
			}*/
			mstruser = "Infobiz";
			mstrurl  = adminUrl;
			
			logger.info("mstrurl="+mstrurl);
			logger.info("ldapuser="+ldapuser);	
			logger.info("mstruser="+mstruser);		
				
			if(mstruser != null){
				mstrresponse = MSTREncryptionService.callMSTRService(mstruser,ldapuser,encrypturl);
	    		responseList.add(mstrresponse);
				responseList.add(mstrurl);
				}
			
			
		}
	    	 catch (NullPointerException e) {
	    		 logger.info("MSTR user account does not exists");			
		} catch (Exception e) {
			 logger.info(String.format("exception - ", e));
		}
		return new ResponseEntity<List<String>>(responseList, HttpStatus.OK);
	 }
}
