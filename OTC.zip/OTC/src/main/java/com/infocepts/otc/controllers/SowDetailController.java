package com.infocepts.otc.controllers;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import javax.mail.MessagingException;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.infocepts.otc.entities.Sow;
import com.infocepts.otc.entities.SowDetail;
import com.infocepts.otc.repositories.ProjectRepository;
import com.infocepts.otc.repositories.SowDetailRepository;
import com.infocepts.otc.repositories.SowRepository;
import com.infocepts.otc.services.StoredProcedureService;
import com.infocepts.otc.services.TimesheetService;


@RestController
@RequestMapping(value="/sowdetail")
public class SowDetailController {

	@Autowired
	SowDetailRepository repository;
	
	@Autowired
	SowRepository sowRepository;
	
	@Autowired
	ProjectRepository projectRepository;
	
	@Autowired
	TimesheetService service;
	
	@Autowired
	HttpSession session;
	
	@Autowired 
	StoredProcedureService storedProcedureService;
	
	@PersistenceContext
    private EntityManager manager;
	
    final Logger logger = Logger.getLogger(SowDetailController.class);
	
    @RequestMapping(method=RequestMethod.POST)
	public SowDetail addSowDetail(@RequestBody SowDetail sowdetail, 
			HttpServletRequest request) throws MessagingException {

		/* ------------------------- Authorization start ------------------------------------ */
		// Authorization for passed sowDetail
		if(sowdetail != null)
		{
			Integer projectId = sowdetail.getSow().getProjectId();
			// Authorization for passed sowId
			 if(projectId != 0)
			 {
				Boolean isAValidCall = service.isAValidSOWCall(projectId, 0, "SowDetail Update", request);
				if(isAValidCall == false)
				{	
					return sowdetail;
				}			 
			 }
		}
		
		try{
			sowdetail.setSowDetailId(null);
			repository.save(sowdetail);
		}catch(Exception e){
			logger.error(e);
		}
		return sowdetail;
	}	
 
	  @RequestMapping(method=RequestMethod.GET)
	 public List<SowDetail> getAllSowDetail(@RequestParam(value = "sowId", defaultValue = "0") Integer sowId,
			 			@RequestParam(value = "projectId", defaultValue = "0") Integer projectId,			 			
						@RequestParam(value = "firstmonth", defaultValue = "") String firstmonth,
						@RequestParam(value = "lastmonth", defaultValue = "") String lastmonth,						
						@RequestParam(value = "joinTreq", defaultValue = "false") Boolean joinTreq, // isBillable == true (billable), false (non-billable)
						@RequestParam(value = "isRevenuePlanning", defaultValue = "0") Integer isRevenuePlanning,
						HttpServletRequest request) throws MessagingException {
		 List<SowDetail> sowdetaillist=null;
		 
		 /* ------------------------- Authorization start ------------------------------------ */
		 Integer loggedInUid = (Integer) session.getAttribute("loggedInUid");
		 // Authorization for passed projectId (project id)
		 if(projectId == 0 && sowId == 0)
		 {
			 return sowdetaillist;
		 }
		 if(sowId != 0)
		 {
			 Sow sow = sowRepository.getOne(sowId);
			 if(sow != null)
			 {
				 projectId = sow.getProjectId();
			 }
		 }
		 // Finally validate for project manager / admin / pmo / amg
		 if(projectId != 0)
		 {
			 Boolean isAValidCall = service.isAValidSOWCall(projectId, 0, "SowDetail By Project", request);
			if(isAValidCall == false)
			{	
				return sowdetaillist;
			}
		 }
			
		 try
		 {		
			 if(sowId != 0) // sowDetails are retrieved by sowId only for SOW page (active roles)
			 {
				 sowdetaillist = manager.createNamedQuery("getSowDetailsBySowId",SowDetail.class)
			 				.setParameter("sowId", sowId)
			 				.setParameter("isRevenuePlanning", isRevenuePlanning)
			     			.getResultList();
			 }
			 else if(projectId != 0) 
			 {
				 if( (!firstmonth.equals("")) && (!lastmonth.equals("")))
				 {
					 Integer month=service.getMonth(firstmonth);
					 Integer year=service.getYear(firstmonth);
					 
					 Integer month1=service.getMonth(lastmonth);
					 Integer year1=service.getYear(lastmonth);
					 firstmonth=year+"-"+month+"-"+01;
					 //lastmonth=year1+"-"+month1+"-"+31;
					 
					 
					 Calendar calendar = Calendar.getInstance();
					 calendar.set(year, month1 - 1, 1);
					 calendar.set(Calendar.DATE, calendar.getActualMaximum(Calendar.DATE));
					 Date date = calendar.getTime();
					 DateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd");
					 lastmonth = DATE_FORMAT.format(date);
					    
					 sowdetaillist = manager.createNamedQuery("getSowDetailsForProjectWithMonthStartDateEndDate",SowDetail.class)
				 			.setParameter("projectId", projectId)
			 				.setParameter("firstmonth", firstmonth)
							.setParameter("lastmonth", lastmonth)
							.setParameter("isBillable", true)
							.getResultList();
				 }
				 else				 
				 {
					 if(joinTreq) // to retrieve sowDetails Data joined with the treq data
					 {
						 sowdetaillist = manager.createNamedQuery("getSowDetailsJoinedWithTreqsForProject",SowDetail.class)
					 				.setParameter("projectId", projectId)
					     			.getResultList();
					 }
					 else // to retrieve clean sowDetails data
					 {
						 sowdetaillist = manager.createNamedQuery("getSowDetailsForProject",SowDetail.class)
					 				.setParameter("projectId", projectId)					 				
					     			.getResultList();
					 }
				 }
				 
			 }			 
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return sowdetaillist;
	 }

	 @RequestMapping(value="/{sowDetailId}",method=RequestMethod.GET)
	 public SowDetail getSowDetail(@PathVariable Integer sowDetailId){
		 SowDetail sowdetail=null;
		 try{
			 sowdetail = manager.createNamedQuery("getSowDetailsById",SowDetail.class)
		 				.setParameter("sowDetailId", sowDetailId)					 				
		     			.getSingleResult();
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return sowdetail;
	 }

	 @RequestMapping(value="/{sowDetailId}",method=RequestMethod.PUT)
	 public SowDetail updateSowDetail(@RequestBody SowDetail updatedsowdetail,
			 							@PathVariable Integer sowDetailId, 
			 							HttpServletRequest request) throws MessagingException {
		 
		 /* ------------------------- Authorization start ------------------------------------ */
		 Integer loggedInUid = (Integer) session.getAttribute("loggedInUid");
		 // Authorization for passed projectId (project id)
		 if(updatedsowdetail != null)
		 {
			Integer projectId = updatedsowdetail.getSow().getProjectId();
			Boolean isAValidCall = service.isAValidSOWCall(projectId, 0, "SowDetail Update", request);
			if(isAValidCall == false)
			{	
				return updatedsowdetail;
			}
		 }	
		 
		 try{
			 updatedsowdetail.setSowDetailId(sowDetailId);
			 repository.save(updatedsowdetail);
			 
			 //To update the allocation on change of role details
			 storedProcedureService.UpdateAllocationOnSowUpdate(sowDetailId);
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return updatedsowdetail;
	 }
	 
	 @RequestMapping(value="/{sowDetailId}",method=RequestMethod.DELETE)
	 public void deleteSowDetail(@PathVariable Integer sowDetailId) {

		if(service.isPmo() || service.isAdmin())
		{
			try{
				 repository.delete(sowDetailId);
			 }
			 catch(Exception e){
				 logger.error(e);
			 }
		}
	 }	 
	 
	 
	 //To delete the complete flow from sowdetail to allocation to treq
	 @RequestMapping(value="/delete/{sowDetailId}",method=RequestMethod.DELETE)
	 public void deleteSowDetailAllocationTreq(@PathVariable Integer sowDetailId, HttpServletRequest request)throws MessagingException{

		//Get the user roles
		String userRoles = session.getAttribute("userRoles") != null ? session.getAttribute("userRoles").toString() : "";
		int uid = session.getAttribute("loggedInUid") != null ? Integer.valueOf(session.getAttribute("loggedInUid").toString()) : 0;
		
		boolean hasDeletePermission = false;
		
		if(userRoles.toLowerCase().contains("deletesowrole")) hasDeletePermission = true;

		if(hasDeletePermission)
		{
			try{
				storedProcedureService.DeleteSOWDetailAllocatioTreq(sowDetailId, uid);
				service.sendSowDetailDeleteNotification(sowDetailId,uid, request); 	
			 }
			 catch(Exception e){
				 logger.error(e);
			 }
		}
	 }
}
