package com.infocepts.otc.repositories;

import java.util.List;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import com.infocepts.otc.entities.Currency;
import java.lang.String;

public interface CurrencyRepository extends CrudRepository<Currency,Integer>{

	@Override
	public List<Currency> findAll();
	
	@Query("from Currency where currencyName = :currencyName")
	public Currency findByCurrencyName(@Param("currencyName") String currencyName);

	@Query("from Currency where status=1")
	public List<Currency> findAllActive();
}
