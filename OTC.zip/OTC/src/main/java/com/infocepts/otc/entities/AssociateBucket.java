package com.infocepts.otc.entities;

import java.util.Date;

import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.infocepts.otc.utilities.LoadConstant;
import com.infocepts.otc.utilities.QueryConstant;

@Entity
@Table(catalog=LoadConstant.otc,schema="[dbo]",name="associatebucket")
@SqlResultSetMapping(
	      name = "associate_bucket_count",
	      classes = {
	          @ConstructorResult(
	              targetClass = AssociateBucket.class,
	              columns = {
	                  @ColumnResult(name = "bucketName", type=String.class),
	                  @ColumnResult(name = "count", type=Integer.class)	                  
	              }
	          )
	      }
	)
	@NamedNativeQueries({    
	    @NamedNativeQuery(
	            name    =   "getAssociateBucketCount",
	            query   =   "select b.bucketName, " + 
	            		"CASE WHEN b.bucketName = 'B_FIRM'" + 
	            		"		THEN " + 
	            		"		(Select count(DISTINCT r.title) "+
	            					QueryConstant.Query_Resources_By_Bfirm_Bucket +")"+ 
	            		/*"	WHEN b.bucketName = 'B_RISK'" + 
	            		"		THEN " + 
	            		"		(Select count(DISTINCT r.title) "+
	            					QueryConstant.Query_Resources_By_Brisk_Bucket +")" +*/ 
	            		"	WHEN b.bucketName = 'NB_BUFFER'" + 
	            		"		THEN " + 
	            		"		(Select count(DISTINCT r.title) " + 
	            					QueryConstant.Query_Resources_By_NBbuffer_Bucket +")" + 
	            		"	WHEN b.bucketName = 'NB_POOL'" + 
	            		"		THEN " + 
	            		"		(Select count(DISTINCT r.title) " + 
	            					QueryConstant.Query_Resources_By_NBpool_Bucket +")" + 
	            		"	ELSE (count(distinct r.title))" + 
	            		" END as count" + 
	            		" from " + LoadConstant.otc + ".[dbo].[bucket] b" + 
	            		" left join " + LoadConstant.otc + ".[dbo].[associatebucket] ab on ab.bucketId = b.bucketId and ab.status = 1" + 
	            		" left join " + LoadConstant.infomaster + ".[dbo].[resource] r on r.uid = ab.associateUid and r.disabled = 0" + 
	            		" group by b.bucketName, b.bucketId" + 
	            		" order by b.bucketId",						             
	                    resultClass=AssociateBucket.class,  resultSetMapping = "associate_bucket_count"  
	                        
	    )
})
public class AssociateBucket {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer associateBucketId;
	
	@ManyToOne
	@JoinColumn(name="bucketId")
	private Bucket bucket;
	private Integer associateUid;
	private Integer createdBy;
	private Date createdDate;
	private Integer modifiedBy;
	private Date modifiedDate;
	private Boolean status;
	
	@Transient
	private String bucketName;
	
	@Transient
	private Integer count;
	
	public Integer getAssociateBucketId() {
		return associateBucketId;
	}
	public void setAssociateBucketId(Integer associateBucketId) {
		this.associateBucketId = associateBucketId;
	}
	public Bucket getBucket() {
		return bucket;
	}
	public void setBucket(Bucket bucket) {
		this.bucket = bucket;
	}
	public Integer getAssociateUid() {
		return associateUid;
	}
	public void setAssociateUid(Integer associateUid) {
		this.associateUid = associateUid;
	}
	public Integer getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public Integer getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public Date getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public Boolean getStatus() {
		return status;
	}
	public void setStatus(Boolean status) {
		this.status = status;
	}
	
	@Transient	
	public String getBucketName() {
		return bucketName;
	}
	public void setBucketName(String bucketName) {
		this.bucketName = bucketName;
	}
	@Transient
	public Integer getCount() {
		return count;
	}
	public void setCount(Integer count) {
		this.count = count;
	}
	public AssociateBucket() {

    }
	
	public AssociateBucket(String bucketName, Integer count) {
		this.bucketName = bucketName;
		this.count = count;
    }
}
