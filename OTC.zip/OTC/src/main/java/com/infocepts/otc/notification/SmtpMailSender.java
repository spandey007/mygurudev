package com.infocepts.otc.notification;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import com.infocepts.otc.utilities.LoadConstant;

import javax.mail.MessagingException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.servlet.http.HttpServletRequest;
import java.util.logging.Logger;

@Component
public class SmtpMailSender {

    @Autowired
    TemplateEngine templateEngine;
    @Autowired
    private JavaMailSender javaMailSender;

    public void send(String from, String to, String subject, String templateName, Context context, String ccEmails, HttpServletRequest request) throws MessagingException {
        final Logger logger = Logger.getLogger(SmtpMailSender.class.getName());
        try {
            MimeMessage message = javaMailSender.createMimeMessage();
            MimeMessageHelper helper;
            String body = templateEngine.process(templateName, context);
            helper = new MimeMessageHelper(message, true);    // true indicates

            // Getting servlet request URL
            helper.setSubject(subject);
            if (request.getServerName().equals(LoadConstant.LOCALHOST) || request.getServerName().equals(LoadConstant.INFOBIZ_DEV) || request.getServerName().equals(LoadConstant.INFOBIZ_STAGE)|| request.getServerName().equals(LoadConstant.INFOBIZ_STAGE2)|| request.getServerName().equals(LoadConstant.INFOBIZ_STAGE1)|| request.getServerName().equals(LoadConstant.INFOBIZ_FE2)) {
                helper.setTo(LoadConstant.INFOBIZ);

            } else {
            	
                if(!"".equals(to)) {                
	                String[] toEmail = to.split(",");
	                InternetAddress[] toAddress = new InternetAddress[toEmail.length];
	                for (int i = 0; i < toAddress.length; i++) {
	                    if(toEmail[i].equals("sgarg@infocepts.com") || toEmail[i].equals("rbhayana@infocepts.com")) {
	                    	toEmail[i] = LoadConstant.INFOBIZ;
	                    }
	                    toAddress[i] = new InternetAddress(toEmail[i]);
	                }	
	                helper.setTo(toAddress);
                }

                
                if(!"".equals(ccEmails)) {                
	                String[] ccEmail = ccEmails.split(",");
	                InternetAddress[] address = new InternetAddress[ccEmail.length];
	                for (int i = 0; i < ccEmail.length; i++) {
	                    if(ccEmail[i].equals("sgarg@infocepts.com") || ccEmail[i].equals("rbhayana@infocepts.com")) {
	                    	ccEmail[i] =  LoadConstant.INFOBIZ;
	                    }
	                    address[i] = new InternetAddress(ccEmail[i]);
	                }
	
	                if (ccEmails != LoadConstant.INFOBIZ_ADMIN) {
	                    helper.setCc(address);
	                }
                }
            }
            helper.setText(body, true);
            if(!"".equals(from)) {
            	 helper.setFrom(from);
            }
           
            javaMailSender.send(message);
            logger.info("Mail successfully send to - " + to);
        } catch (Exception e) {
        	e.printStackTrace();
            logger.info(String.format("exception - ", e));
        }
    }

}

