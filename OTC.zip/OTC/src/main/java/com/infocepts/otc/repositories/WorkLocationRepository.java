package com.infocepts.otc.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.infocepts.otc.entities.WorkLocation;

public interface WorkLocationRepository extends CrudRepository<WorkLocation,Integer>{
	
	@Override
	public List<WorkLocation> findAll();
	
}
