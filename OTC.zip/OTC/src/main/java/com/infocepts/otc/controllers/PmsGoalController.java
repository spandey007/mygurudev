/**
* Filename: /src/main/java/com/infocepts/otc/controllers/PmsGoalController.java
* @author  SRA
* @version 1.0
* @since   2018-08-01 
*/

package com.infocepts.otc.controllers;

import java.util.logging.Logger;
import com.infocepts.pms.entities.PmsGoal;
import com.infocepts.pms.entities.PmsPerformance;
import com.infocepts.pms.entities.PmsResource;
import com.infocepts.pms.repositories.PmsGoalRepository;
import com.infocepts.pms.repositories.PmsResourceRepository;
import com.infocepts.otc.services.PmsService;
import com.infocepts.otc.services.TimesheetService;
import com.infocepts.otc.utilities.ExportUtil;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.mail.MessagingException;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.io.File;
import java.io.FileNotFoundException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

@RestController
@RequestMapping(value="/api/pms/goal",headers="referer")
public class PmsGoalController {

    final Logger logger = Logger.getLogger(PmsGoalController.class.getName());

    @Autowired
    PmsGoalRepository pmsGoalRepository;
    
    @Autowired
    HttpSession session;

    @PersistenceContext(unitName = "pms") 
    private EntityManager manager;
	
	@Autowired
	TimesheetService service;
	
	@Autowired
	PmsService pmsService;
	
    @Autowired
    PmsResourceRepository pmsResourceRepository;

	@Autowired
	ExportUtil exportUtil;
	
	String path=null;
	String filepath="";	
	
	/**
   * This method is used to find results set from module entity
   * based on params passed from JS file
   */
    @RequestMapping(method = RequestMethod.GET)
    public List<PmsGoal> findAllPmsGoal(@RequestParam(value = "performanceId", defaultValue = "0") Integer performanceId
										, HttpServletRequest request){
        List<PmsGoal> pmsGoalList = null;
        
        logger.info("--------------------in PmsGoal controller------------------");		
		logger.info("performanceId="+performanceId);
		
        try {
             if (performanceId != 0) {			
        			
				pmsGoalList = manager.createNamedQuery("getGoalByPerformanceId", PmsGoal.class)                        
                        .setParameter("performanceId", performanceId)						
                        .getResultList();
        					
        	} else {			
        		
				pmsGoalList = manager.createNamedQuery("getAllGoal", PmsGoal.class)                                               					
                        .getResultList();
			}
			
         } 
		catch (Exception e){
			 logger.info(String.format("exception - ", e.getMessage()));
        }
        return pmsGoalList;

    }
    
    /**
     * This method is add row in ModuleName entity
     * 
     */
    @RequestMapping(method=RequestMethod.POST)
	public PmsGoal addPmsGoal(@RequestBody PmsGoal pmsGoal, HttpServletRequest request) {
		
			try{
				pmsGoal.setGoalId(null);
				pmsGoalRepository.save(pmsGoal);
			}
			catch(Exception e){
				logger.info(String.format("exception - ", e.getMessage()));
			}
	
		return pmsGoal;
	}
    
    /**
     * This method is update row in moduleName entity
     * based on primaryKey Of Module  Table 
     */
    @RequestMapping(value="/{goalId}",method=RequestMethod.PUT)
	 public PmsGoal updatePmsGoal(@RequestBody PmsGoal updatedPmsGoal,@PathVariable Integer goalId, HttpServletRequest request){
       	
    	String userType = "";
		String phase = "";
		PmsGoal goalObject = null;
		PmsResource pmsResourceObj = null;
		
		// individual form Unlock workflow - check PmsResource object to check cycle and enable Phase
		Boolean flagHandshake = false;
		Boolean flagPitstop = false;
		Boolean flagEvaluation = false;
		
			try{
				
				Integer uid = session.getAttribute("loggedInUid") != null ? Integer.valueOf(session.getAttribute("loggedInUid").toString()) : 0;
				
				//To update the performance field as per user type
			    HashMap<String,String> typeAndPhase = pmsService.getUserTypeAndPhase(updatedPmsGoal.getPmsPerformance().getPerformanceId(),uid);
				
			    userType = typeAndPhase.get("userType");
			    phase = typeAndPhase.get("phase");
			    
			    goalObject = pmsGoalRepository.findOne(goalId);
			   
				 
			    // individual form Unlock workflow - check PmsResource object to check cycle and enable Phase
			    pmsResourceObj = pmsResourceRepository.findResourceById(goalObject.getPmsPerformance().getUid());
			    	
			    if(pmsResourceObj != null) {
			    	if(pmsResourceObj.getEnableHandshake() && (pmsResourceObj.getEnableHandshakeCycle() == goalObject.getPmsPerformance().getCycle().getCycleId())) {
			    		flagHandshake = true;
			    	}
			    	else if(pmsResourceObj.getEnablePitstop() && (pmsResourceObj.getEnablePitstopCycle() == goalObject.getPmsPerformance().getCycle().getCycleId())) {
			    		flagPitstop = true;
			    	}
			    	else if(pmsResourceObj.getEnableEvaluation() && (pmsResourceObj.getEnableEvaluationCycle() == goalObject.getPmsPerformance().getCycle().getCycleId())) {
			    		flagEvaluation = true;
			    	}
			    }
			    
			    //Generic fields 
			    goalObject.setModifiedBy(updatedPmsGoal.getModifiedBy());
			    goalObject.setModifiedDate(updatedPmsGoal.getModifiedDate());
			    
			    //=====For Handshake=====
			    if(phase == "Handshake" || flagHandshake)
			    {		
			    	//Generic fields
			    	
			    	//-----For Associate-----
				    if(userType == "Associate"){
				    	
				    	goalObject.setGoalName(updatedPmsGoal.getGoalName());		
				    	goalObject.setKpi(updatedPmsGoal.getKpi());
				    	goalObject.setTarget(updatedPmsGoal.getTarget());
				    	goalObject.setUom(updatedPmsGoal.getUom());
				    	goalObject.setUomDate(updatedPmsGoal.getUomDate());
				    	goalObject.setUomNumber(updatedPmsGoal.getUomNumber());
				    	goalObject.setUomPercentage(updatedPmsGoal.getUomPercentage());
				    	goalObject.setWeightage(updatedPmsGoal.getWeightage());
				    }
				    //-----For Manager-----
				    else if(userType == "Manager"){
				    	goalObject.setGoalName(updatedPmsGoal.getGoalName());		
				    	goalObject.setKpi(updatedPmsGoal.getKpi());
				    	goalObject.setTarget(updatedPmsGoal.getTarget());
				    	goalObject.setUom(updatedPmsGoal.getUom());
				    	goalObject.setUomDate(updatedPmsGoal.getUomDate());
				    	goalObject.setUomNumber(updatedPmsGoal.getUomNumber());
				    	goalObject.setUomPercentage(updatedPmsGoal.getUomPercentage());
				    	goalObject.setWeightage(updatedPmsGoal.getWeightage());
				    	goalObject.setApprovalStatus(updatedPmsGoal.getApprovalStatus());
				    	goalObject.setCommentsRejection(updatedPmsGoal.getCommentsRejection());
				    }
				    //-----Reviewer-----
				    else if(userType == "Reviewer"){

				    }
				    else if(userType == "HR"){
				    	goalObject.setApprovalStatus(updatedPmsGoal.getApprovalStatus());
				    }
			    	
			    }
			    //=====For Pitstop=====
			    else if(phase == "Pitstop" || flagPitstop)
			    {
			    	//Generic fields
			    	
			    	
			    	//-----For Associate-----
				    if(userType == "Associate"){
				    	goalObject.setCommentsSelfPitstop(updatedPmsGoal.getCommentsSelfPitstop());
				    }
				    //-----For Manager-----
				    else if(userType == "Manager" || userType == "HR"){
				    	goalObject.setCommentsManagerPitstop(updatedPmsGoal.getCommentsManagerPitstop());
				    }
				    //-----Reviewer-----
				    else if(userType == "Reviewer" || userType == "HR"){
				  
				    }
			    	
			    }
			    //=====For Evaluation=====
			    else if(phase == "Evaluation" || flagEvaluation)
			    {
			    	//Generic fields
			    	
			    	
			    	//-----For Associate-----
				    if(userType == "Associate"){
				    	goalObject.setCommentsSelfAnnual(updatedPmsGoal.getCommentsSelfAnnual());
				    	goalObject.setSelfRating(updatedPmsGoal.getSelfRating());
				    	goalObject.setDocLinkSelfAnnual(updatedPmsGoal.getDocLinkSelfAnnual());
				    }
				    //-----For Manager-----
				    else if(userType == "Manager" || userType == "HR"){
				    	goalObject.setCommentsManagerAnnual(updatedPmsGoal.getCommentsManagerAnnual());
				    	goalObject.setManagersRating(updatedPmsGoal.getManagersRating());
				    	goalObject.setDocLinkManagerAnnual(updatedPmsGoal.getDocLinkManagerAnnual());
				    }
				    //-----Reviewer-----
				    else if(userType == "Reviewer" || userType == "HR"){
				    
				    }
			    	
			    }
			    goalObject.setGoalId(goalId);
				pmsGoalRepository.save(goalObject);
			}
			catch(Exception e){
				logger.info(String.format("exception - ", e.getMessage()));
			}
		
		 return goalObject;
	 }
    
    /**
     * This method is get data for specific row in moduleName entity
     * based on primaryKey Of Module Table 
     */
    @RequestMapping(value="/{goalId}",method=RequestMethod.GET)
	 public PmsGoal getPmsGoal(@PathVariable Integer goalId, HttpServletRequest request) throws MessagingException{
    	
    	PmsGoal PmsGoal=null;
		
			try{
				PmsGoal =  manager.createNamedQuery("getGoalById", PmsGoal.class)
                     .setParameter("goalId", goalId)
                     .getSingleResult();
			}
			catch(Exception e){
				logger.info(String.format("exception - ", e.getMessage()));
			}
		
		return PmsGoal;
	 }
	 
    
    /**
     * This method is delete data for specific row in moduleName entity
     * based on primaryKey Of Module Table 
     */	 
	@RequestMapping(value="/{goalId}",method=RequestMethod.DELETE)
	public void deletePmsGoal(@PathVariable Integer goalId, HttpServletRequest request) {
		
			try{
				pmsGoalRepository.delete(goalId);
			}
			catch(Exception e){
				logger.info(String.format("exception - ", e.getMessage()));
			}
		
		 
	}
	
	 /**
     * This method is upload file for specific row in goal entity
     * based on primaryKey Of Module Table 
     */	
	@RequestMapping(value="/upload/{docPath}/{goalId}",method=RequestMethod.POST,consumes = {"multipart/form-data"})
    @ResponseBody
	public String uploadFile(@RequestPart("file") MultipartFile file,@PathVariable(value = "docPath") Integer docPath,@PathVariable(value = "goalId") Integer goalId,HttpServletRequest request)
	{			
		PmsGoal pmsGoal = pmsGoalRepository.findOne(goalId);
		path=exportUtil.getPmsGoalDocPath(file,request,goalId);		
		
		if(docPath==1){
			pmsGoal.setDocLinkSelfAnnual(path);	
		}else{
			pmsGoal.setDocLinkManagerAnnual(path);;				
		}
		pmsGoalRepository.save(pmsGoal);
		return path;
	}
	
	 /**
     * This method is download file for specific row in goal entity
     * based on primaryKey Of pmsGoal Table 
     */	
	@RequestMapping(value="/download/{flag}/{goalId}",method=RequestMethod.GET)
	public void download(@PathVariable(value = "flag") Integer flag,@PathVariable(value = "goalId") Integer goalId,HttpServletRequest request,HttpServletResponse response) throws ServletException, Exception {
		String path=null;
		File home=exportUtil.checkPath(request);
		String separator=File.separator;
		String Filepath = "";
		path=home.getPath();
		
		PmsGoal pmsGoal = pmsGoalRepository.findOne(goalId);
		
		if(flag==1) {
			Filepath = pmsGoal.getDocLinkSelfAnnual();
		}else {
			Filepath = pmsGoal.getDocLinkManagerAnnual();	
		}
		
		
		List<String> list = Arrays.asList(Filepath.split("\\s*,\\s*"));
	
		if(list.size() > 1){
		
			if (home.exists() && home.isDirectory()) {
				 logger.info("home is a directory");
				    if(path.equals(separator)){
					 	path="usr"+File.separator+"home"+File.separator+"Download";
					}
					else{
						path=File.separator+"usr"+File.separator+"home"+File.separator+"Download";
					}
				
					if (Files.isDirectory(Paths.get(home + path))) {
						if(path.equals(separator)){
							path="usr"+File.separator+"home"+File.separator+"Download"+File.separator+"pmsgoal";
						}
						else{
							path=File.separator+"usr"+File.separator+"home"+File.separator+"Download"+File.separator+"pmsgoal";
						}
						
						if (Files.isDirectory(Paths.get(home + path))) {
							if(path.equals(separator)){
								path="usr"+File.separator+"home"+File.separator+"Download"+File.separator+"pmsgoal"+File.separator;
							}
							else{
								path=File.separator+"usr"+File.separator+"home"+File.separator+"Download"+File.separator+"pmsgoal"+File.separator;
							}
							
						} 
					}
				
			}
			
			
		}
		else{
			try{
				File outputFile = new File(Filepath);
				Path file = Paths.get(outputFile+"");
			    response.addHeader("Content-Disposition", "attachment; filename="+file.getFileName());
			    Files.copy(file, response.getOutputStream());
			    response.getOutputStream().flush();
			}
			catch(FileNotFoundException fe){
				fe.printStackTrace();
			}
		}
	}
	
	/**
     * This method is upload file for specific row in goal entity
     * based on primaryKey Of Module Table 
     */	
/*	@RequestMapping(value="/uploadManagerFile/{goalId}",method=RequestMethod.POST,consumes = {"multipart/form-data"})
    @ResponseBody
	public String uploadManagerFile(@RequestPart("file") MultipartFile file,@PathVariable(value = "goalId") Integer goalId,HttpServletRequest request)
	{			
		PmsGoal pmsGoal = pmsGoalRepository.findOne(goalId);
		path=exportUtil.getPmsGoalDocPath(file,request,goalId);		
		pmsGoal.setDocLinkManagerAnnual(path);	
		pmsGoalRepository.save(pmsGoal);
		return path;
	}
	*/
//	 /**
//     * This method is download file for specific row in goal entity
//     * based on primaryKey Of pmsGoal Table 
//     */	
//	@RequestMapping(value="/downloadManagerFile/{goalId}",method=RequestMethod.GET)
//	public void downloadManagerFile(@PathVariable(value = "goalId") Integer goalId,HttpServletRequest request,HttpServletResponse response) throws ServletException, Exception {
//		String path=null;
//		File home=exportUtil.checkPath(request);
//		String separator=File.separator;
//		String Filepath = "";
//		path=home.getPath();
//		
//		PmsGoal pmsGoal = pmsGoalRepository.findOne(goalId);
//		Filepath = pmsGoal.getDocLinkManagerAnnual();
//		List<String> list = Arrays.asList(Filepath.split("\\s*,\\s*"));
//	
//		if(list.size() > 1){
//		
//			if (home.exists() && home.isDirectory()) {
//				 logger.info("home is a directory");
//				    if(path.equals(separator)){
//					 	path="usr"+File.separator+"home"+File.separator+"Download";
//					}
//					else{
//						path=File.separator+"usr"+File.separator+"home"+File.separator+"Download";
//					}
//				
//					if (Files.isDirectory(Paths.get(home + path))) {
//						if(path.equals(separator)){
//							path="usr"+File.separator+"home"+File.separator+"Download"+File.separator+"pmsgoal";
//						}
//						else{
//							path=File.separator+"usr"+File.separator+"home"+File.separator+"Download"+File.separator+"pmsgoal";
//						}
//						
//						if (Files.isDirectory(Paths.get(home + path))) {
//							if(path.equals(separator)){
//								path="usr"+File.separator+"home"+File.separator+"Download"+File.separator+"pmsgoal"+File.separator;
//							}
//							else{
//								path=File.separator+"usr"+File.separator+"home"+File.separator+"Download"+File.separator+"pmsgoal"+File.separator;
//							}
//							
//						} 
//					}
//				
//			}
//			
//			
//		}
//		else{
//			try{
//				File outputFile = new File(Filepath);
//				Path file = Paths.get(outputFile+"");
//			    response.addHeader("Content-Disposition", "attachment; filename="+file.getFileName());
//			    Files.copy(file, response.getOutputStream());
//			    response.getOutputStream().flush();
//			}
//			catch(FileNotFoundException fe){
//				fe.printStackTrace();
//			}
//		}
//	}
   
}
