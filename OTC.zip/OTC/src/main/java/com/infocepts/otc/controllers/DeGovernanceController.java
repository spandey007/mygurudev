package com.infocepts.otc.controllers;

import com.infocepts.otc.entities.DeGovernance;
import com.infocepts.otc.notification.SmtpMailSender;
import com.infocepts.otc.repositories.DeGovernanceRepository;
import com.infocepts.otc.services.DEGovernanceToolService;
import com.infocepts.otc.services.TimesheetService;

import java.util.List;

import javax.mail.MessagingException;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/deGovernance")
public class DeGovernanceController {
	
	@Autowired
	HttpSession session;
	
	@PersistenceContext
    private EntityManager manager;
	
	@Autowired
	DEGovernanceToolService deService;

	@Autowired
	TimesheetService service;
	
	@Autowired
	SmtpMailSender smtpMailSender;
	
	
	private static final Logger logger = Logger.getLogger(DeGovernanceController.class);

	@Autowired
	private DeGovernanceRepository deGovernanceRepository;

    @RequestMapping(value = "/{itemId}",method=RequestMethod.GET)
    public DeGovernance findProjectMetricById(@PathVariable("itemId") Integer itemId){
        return this.deGovernanceRepository.findOne(itemId);
    }

	@RequestMapping(method=RequestMethod.POST)
	public DeGovernance saveProjectMetric(@RequestBody DeGovernance deGovernance, HttpServletRequest request) throws MessagingException 
	{
		
        this.deGovernanceRepository.save(deGovernance);
        
        if(deGovernance.getNotesByDE()!=null) {
    		service.sendDeNotification(deGovernance, "add","DE", request);        	
        }
        return deGovernance;
        
	}

	@RequestMapping(value = "/{itemId}", method = RequestMethod.PUT)
	public DeGovernance  updateProjectMetric( @RequestBody DeGovernance deGovernance ,@PathVariable Integer itemId, HttpServletRequest request) throws MessagingException 
	{
		DeGovernance deGovernanceold;
		String newDeComment = "";
		Boolean isDEMember = false;
		Boolean isPHMember = false;

		
		String userRoles = session.getAttribute("userRoles") != null ? session.getAttribute("userRoles").toString() : "";
		int uid = session.getAttribute("loggedInUid") != null ? Integer.valueOf(session.getAttribute("loggedInUid").toString()) : 0;
		if(userRoles.toLowerCase().contains("de")) isDEMember = true;
		if(userRoles.toLowerCase().contains("ph")) isPHMember = true;
		
		
		
		if(deGovernance.getNotesByDE() !=null) {
				newDeComment = deGovernance.getNotesByDE();
		}
		
        if(deGovernance.getItemId() != null) {
        	deGovernanceold = this.deGovernanceRepository.findOne(deGovernance.getItemId());
            
            if(isDEMember) {
                if(deGovernanceold != null) {
        	        if(!newDeComment.equals(deGovernanceold.getNotesByDE()) && newDeComment != "") {
        	            service.sendDeNotification(deGovernance, "update","DE", request);
        	        }
                }        	            	
            }
            
            if(isPHMember) {
                service.sendDeNotification(deGovernance, "update","PH", request);
            }
            
            
            
        }
        
        deGovernance.setItemId(itemId);
        this.deGovernanceRepository.save(deGovernance);
        return deGovernance;
    }
	
	@RequestMapping(method=RequestMethod.GET)
	 public List<DeGovernance> getAllDeGovernance(
			 					@RequestParam(value = "view", defaultValue = "") String view,
			 					@RequestParam(value = "monthYear", defaultValue = "") String monthYear,
			 					@RequestParam(value = "projectId", defaultValue = "") Integer projectId,
			 					@RequestParam(value = "deProjectType", defaultValue = "") String deProjectType,			 					
			 					HttpServletRequest request) throws MessagingException {
		
		 Boolean isAValidCall = false;
		 List<DeGovernance> list=null;
		 
		 //Get the user roles
		 String userRoles = session.getAttribute("userRoles") != null ? session.getAttribute("userRoles").toString() : "";
		 int uid = session.getAttribute("loggedInUid") != null ? Integer.valueOf(session.getAttribute("loggedInUid").toString()) : 0;
		 
		 boolean isDEMember = false;
		 int month = 0;
		 int year = 0;
		 
		 if(!monthYear.equals("") && monthYear.contains("-")) { month = Integer.valueOf(monthYear.split("-")[0]); year = Integer.valueOf(monthYear.split("-")[1]); }
		 
		 if(userRoles.toLowerCase().contains("de")) isDEMember = true;
		 
		 
		 try{
		 	if( (view.equals("de") && isDEMember) || (view.equals("dh") && uid == 512)){ //Get all the Project data for DE team members
		 		list = manager.createNamedQuery("getProjects",DeGovernance.class)
		 				.setParameter("uid", uid)
		 				.setParameter("view", view)
		 				.setParameter("month", month)
		 				.setParameter("year", year)
		 				.getResultList();
		 	}
		 	else if(view.equals("pm") || view.equals("ph") || view.equals("ah") || view.equals("cep"))
		 	{
		 			list = manager.createNamedQuery("getProjects",DeGovernance.class)
		 				.setParameter("uid", uid)
		 				.setParameter("view", view)
		 				.setParameter("month", month)
		 				.setParameter("year", year)
		 				.getResultList();
		 	}
		 	else if(projectId !=null) 
		 	{			
	 			list = manager.createNamedQuery("getYTDDeGovernanceDetail",DeGovernance.class)
		 				.setParameter("projectId", projectId)
		 				.setParameter("year", year)
		 				.setParameter("deProjectType", deProjectType)		 				
		 				.getResultList();
	 			
		 	}
		 	
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return list;
	}
}
