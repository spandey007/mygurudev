package com.infocepts.otc.controllers;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.infocepts.otc.entities.CT_BehavioralTraining;
import com.infocepts.otc.entities.CT_Competency;
import com.infocepts.otc.repositories.CT_BehavioralTrainingRepository;
import com.infocepts.otc.services.TimesheetService;

@RestController
@RequestMapping(value="behavioralTraining",headers="referer")
public class CT_BehavioralTrainingController {
	@Autowired
	CT_BehavioralTrainingRepository ct_BehavioralTrainingRepository;
	
	@Autowired
	TimesheetService service;
	
	@PersistenceContext(unitName = "otc")
	private EntityManager manager;
	
	@RequestMapping(method=RequestMethod.POST)
	public CT_BehavioralTraining addCT_BehavioralTraining(@RequestBody CT_BehavioralTraining cT_BehavioralTraining){
		cT_BehavioralTraining.setBehavioralTrainingId(null);
		Boolean isAValidCall = false;
		if(service.isHR() || service.isAdmin())
		{
			isAValidCall = true;
		}
		if(isAValidCall) {
			
			ct_BehavioralTrainingRepository.save(cT_BehavioralTraining);
		}
		return cT_BehavioralTraining;
	}
	
	@RequestMapping(method=RequestMethod.GET)
	public List<CT_BehavioralTraining> getCT_BehavioralTraining(){
		List<CT_BehavioralTraining> list = null;
		Boolean isAValidCall = false;
		if(service.isHR() || service.isAdmin())
		{
			isAValidCall = true;
		}
		if(isAValidCall) {
		System.out.println("inside AllBehavioralTraining page");
		list =  manager.createNamedQuery("getAllBehavioralTraining",CT_BehavioralTraining.class)
				.getResultList();
		}
		return list;
	}
	
	@RequestMapping(value="/{behavioralTrainingId}",method=RequestMethod.GET)
	public CT_BehavioralTraining getCT_BehavioralTraining(@PathVariable Integer behavioralTrainingId){
		CT_BehavioralTraining cT_BehavioralTraining = null;
		Boolean isAValidCall = false;
		if(service.isHR() || service.isAdmin())
		{
			isAValidCall = true;
		}
		if(isAValidCall) {
			
			cT_BehavioralTraining = ct_BehavioralTrainingRepository.findOne(behavioralTrainingId);
		}
		return cT_BehavioralTraining;
	}
	
	@RequestMapping(value="/{behavioralTrainingId}", method=RequestMethod.PUT)
	public CT_BehavioralTraining updateCT_BehavioralTraining(@PathVariable Integer behavioralTrainingId,  @RequestBody CT_BehavioralTraining updatedCT_BehavioralTraining){
		updatedCT_BehavioralTraining.setBehavioralTrainingId(behavioralTrainingId);
		Boolean isAValidCall = false;
		if(service.isHR() || service.isAdmin())
		{
			isAValidCall = true;
		}
		if(isAValidCall) {
		ct_BehavioralTrainingRepository.save(updatedCT_BehavioralTraining);
		}
		return updatedCT_BehavioralTraining;
	}
	
	@RequestMapping(value="/{behavioralTrainingId}",method=RequestMethod.DELETE)
	public void deleteCT_BehavioralTraining(@PathVariable Integer behavioralTrainingId){
		Boolean isAValidCall = false;
		if(service.isHR() || service.isAdmin())
		{
			isAValidCall = true;
		}
		if(isAValidCall) {
		ct_BehavioralTrainingRepository.delete(behavioralTrainingId);
		}
	}
}

