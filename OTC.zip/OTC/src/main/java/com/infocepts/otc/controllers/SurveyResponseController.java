package com.infocepts.otc.controllers;

import java.util.logging.Logger;
import com.infocepts.otc.entities.SurveyResponse;
import com.infocepts.otc.repositories.SurveyResponseRepository;
import com.infocepts.otc.utilities.DateConverter;
import com.infocepts.otc.services.TimesheetService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.mail.MessagingException;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@RestController
@RequestMapping(value="/SurveyResponse", headers="referer")
public class SurveyResponseController {

    final Logger logger = Logger.getLogger(SurveyResponseController.class.getName());

    @Autowired
    SurveyResponseRepository repository;
    
    @Autowired
    HttpSession session;

    @PersistenceContext(unitName = "otc") 
    private EntityManager manager;
			
	@Autowired
	TimesheetService service;

	/**
   * This method is used to find results set from module entity
   * based on params passed from JS file
   */
    @RequestMapping(method = RequestMethod.GET)
    public List<SurveyResponse> findAllSurveyResponse(@RequestParam(value = "responceId", defaultValue = "1") Integer responceId
            						,@RequestParam(value = "surveyId", defaultValue = "") Integer surveyId
            						,@RequestParam(value = "email", defaultValue = "") String email
									,@RequestParam(value = "userName", defaultValue = "") String userName								
            						,HttpServletRequest request){
        List<SurveyResponse> SurveyResponseList = null;
        Integer loggedInUid = (Integer) session.getAttribute("loggedInUid");
        
        logger.info("--------------------in <ModuleName> controller------------------");		
		logger.info("responceId="+responceId);
		logger.info("surveyId="+surveyId);
		logger.info("email="+email);
		logger.info("userName="+userName);
		
        try {
        	/* ------------------------- Authorization start ------------------------------------ */
			// Authorization for XYZ role
			if(!service.isAdmin()) // isXYZ() needs implementation in declaration  in TimesheetService Class & implementation in TimesheetServiceImpl Class
			{
				service.sendTamperedMail("SurveyResponse view all", 0, 0, request);
				return SurveyResponseList;
			}
			/* ------------------------- Authorization ends ------------------------------------ */
			
        	
			
        		//option 1 to get moduleNameList using namedQuery		
        		SurveyResponseList = manager.createNamedQuery("SurveyResponseQuery", SurveyResponse.class)                        
                        
                       .getResultList();
        		logger.info("SurveyResponseList="+SurveyResponseList);
        		
        	
			
         } 
		catch (Exception e){
			 logger.info(String.format("exception - ", e));
        }
        return SurveyResponseList;

    }
    
    /**
     * This method is add row in moduleName entity
     * 
     */
    @RequestMapping(method=RequestMethod.POST)
	public SurveyResponse addSurveyResponse(@RequestBody SurveyResponse SurveyResponse, HttpServletRequest request) throws MessagingException {
		// Authorization for XYZ role
		if(service.isAdmin())
		{
			try{
				SurveyResponse.setResponceId(null);
				repository.save(SurveyResponse);
			}
			catch(Exception e){
				 logger.info(String.format("exception - ", e));
			}
		}
		else 
		{
			service.sendTamperedMail("SurveyResponse Save", 0, 0, request);
		}
		
		return SurveyResponse;
	}
    
    /**
     * This method is update row in moduleName entity
     * based on primaryKey Of Module Table 
     */
    @RequestMapping(value="/{responseId}",method=RequestMethod.PUT)
	 public SurveyResponse updateSurveyResponse(@RequestBody SurveyResponse updatedSurveyResponse,@PathVariable Integer responseId,HttpServletRequest request) throws MessagingException{
        // Authorization for XYZ role
		if(service.isAdmin())
		{	
			try{
				 updatedSurveyResponse.setResponceId(responseId);
				 repository.save(updatedSurveyResponse);
			}
			catch(Exception e){
				 logger.info(String.format("exception - ", e));
			}
		}
		else
		{
			service.sendTamperedMail("SurveyResponse Save", 0, 0, request);
		}
		 return updatedSurveyResponse;
	 }
    
    /**
     * This method is get data for specific row in moduleName entity
     * based on primaryKey Of Module Table 
     */
    @RequestMapping(value="/{responseId}",method=RequestMethod.GET)
	 public SurveyResponse getSurveyResponse(@PathVariable Integer responseId, HttpServletRequest request) throws MessagingException{
    	
    	SurveyResponse SurveyResponse = null;
		// Authorization for XYZ role
		if(service.isAdmin())
		{
			try{
				SurveyResponse = manager.createNamedQuery("SurveyResponseQuery", SurveyResponse.class)
						 .setParameter("responseId", responseId)
						 .getSingleResult();
			 }
			 catch(Exception e){
				 logger.info(String.format("exception - ", e));
			 }
		}
		else 
		{
			service.sendTamperedMail("SurveyResponse Get", 0, 0, request);
		}
		 
		 return SurveyResponse;
	 }
	 
    
    /**
     * This method is delete data for specific row in moduleName entity
     * based on primaryKey Of Module Table 
     */	 
	@RequestMapping(value="/{responseId}",method=RequestMethod.DELETE)
	public void deleteSurveyResponse(@PathVariable Integer responseId, HttpServletRequest request)  throws MessagingException {
		// Authorization for XYZ role
		if(service.isAdmin())
		{
			try{
			repository.delete(responseId);
			}
			catch(Exception e){
				 logger.info(String.format("exception - ", e));
			}
		}
		else
		{
			service.sendTamperedMail("<ModuleName> Delete", 0, 0, request);
		}		 
	}
	
  
   
}
