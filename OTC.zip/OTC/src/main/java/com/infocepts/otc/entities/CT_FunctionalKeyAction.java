package com.infocepts.otc.entities;

import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.SqlResultSetMappings;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.infocepts.otc.utilities.LoadConstant;

@Entity
@Table(catalog=LoadConstant.otc, schema="[dbo]",name="ct_functionalKeyAction")

@SqlResultSetMappings({
    @SqlResultSetMapping(
            name = "functionalKeyAction_mapping",
            classes = {
                    @ConstructorResult(
                            targetClass = CT_FunctionalKeyAction.class,
                            columns = {
                            		@ColumnResult(name = "functionalKeyActionId"),
                            		@ColumnResult(name = "proficiencyLevelId"),
                            		@ColumnResult(name = "functionalKeyAction", type = String.class),
                            		@ColumnResult(name = "competencyId"),
                            		@ColumnResult(name = "competencyName", type = String.class)
                            }
                    )
            }
    )
})
@NamedNativeQueries({
    @NamedNativeQuery(
            name    =   "getAllFunctionalKeyAction",   
            query 	=   "select bt.functionalKeyActionId as functionalKeyActionId,bt.proficiencyLevelId as proficiencyLevelId, " + 
            			" bt.functionalKeyAction as functionalKeyAction, bt.competencyId as competencyId, cl.competencyName as competencyName from " + LoadConstant.otc + ".[dbo].[ct_functionalKeyAction] bt " + 
            			" left join " + LoadConstant.otc + ".[dbo].[ct_competency] cl on cl.competencyId = bt.competencyId",
						 
						resultClass=CT_FunctionalKeyAction.class, resultSetMapping = "functionalKeyAction_mapping"
    )
})
public class CT_FunctionalKeyAction {

	// Entity Columns
    // --------------------------------------------------------------------------------
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Integer functionalKeyActionId;
    private Integer proficiencyLevelId;
    
    @Lob
    private String functionalKeyAction;
    
    private Integer competencyId;
    
    @Transient
    private String competencyName;

	public Integer getFunctionalKeyActionId() {
		return functionalKeyActionId;
	}

	public void setFunctionalKeyActionId(Integer functionalKeyActionId) {
		this.functionalKeyActionId = functionalKeyActionId;
	}

	public Integer getProficiencyLevelId() {
		return proficiencyLevelId;
	}

	public void setProficiencyLevelId(Integer proficiencyLevelId) {
		this.proficiencyLevelId = proficiencyLevelId;
	}

	public String getFunctionalKeyAction() {
		return functionalKeyAction;
	}

	public void setFunctionalKeyAction(String functionalKeyAction) {
		this.functionalKeyAction = functionalKeyAction;
	}
	public Integer getCompetencyId() {
		return competencyId;
	}

	public void setCompetencyId(Integer competencyId) {
		this.competencyId = competencyId;
	}

	public String getCompetencyName() {
		return competencyName;
	}

	public void setCompetencyName(String competencyName) {
		this.competencyName = competencyName;
	}

	public CT_FunctionalKeyAction(Integer functionalKeyActionId, Integer proficiencyLevelId, String functionalKeyAction,
			Integer competencyId, String competencyName) {
		//super();
		this.functionalKeyActionId = functionalKeyActionId;
		this.proficiencyLevelId = proficiencyLevelId;
		this.functionalKeyAction = functionalKeyAction;
		this.competencyId = competencyId;
		this.competencyName = competencyName;
	}

	public CT_FunctionalKeyAction() {
		//super();
		// TODO Auto-generated constructor stub
	}
    
	
	
	
    
}
