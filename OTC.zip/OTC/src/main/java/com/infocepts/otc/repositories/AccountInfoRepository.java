package com.infocepts.otc.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.infocepts.otc.entities.AccountInfo;


public interface AccountInfoRepository extends JpaRepository<AccountInfo,Integer>{

	@Override
	public List<AccountInfo> findAll();

	
	@Query("from AccountInfo where uid=:uid")
	public List<AccountInfo> findAccountInfoByUid(@Param(value="uid") Integer uid);
	
	@Query("from AccountInfo where accountId=:accountId")
	public List<AccountInfo> findAccountInfoByAccount(@Param(value="accountId") Integer accountId);	
	 

	
}
