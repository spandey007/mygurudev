/**
* Filename: /src/main/java/com/infocepts/otc/controllers/DePhUpdateController.java
* @author  SHRI
* @version 1.0
* @since   2018-11-28 
*/

package com.infocepts.otc.controllers;

import java.util.logging.Logger;
import com.infocepts.otc.entities.DeGovernance;
import com.infocepts.otc.entities.DePhUpdate;
import com.infocepts.otc.entities.DeValueAdd;
import com.infocepts.otc.entities.ISow;
import com.infocepts.otc.repositories.DePhUpdateRepository;
import com.infocepts.otc.utilities.DateConverter;
import com.infocepts.otc.utilities.ExportUtil;
import com.infocepts.otc.services.TimesheetService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.mail.MessagingException;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.io.File;
import java.io.FileNotFoundException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

@RestController
@RequestMapping(value="/dephupdate",headers="referer")
public class DePhUpdateController {

    final Logger logger = Logger.getLogger(DePhUpdateController.class.getName());

    @Autowired
    DePhUpdateRepository dePhUpdateRepository;
    
    @Autowired
    HttpSession session;

    @PersistenceContext(unitName = "otc") 
    private EntityManager manager;
			
	@Autowired
	ExportUtil exportUtil;
	
	@Autowired
	TimesheetService service;
	String path=null;
	String filepath="";
	
    @RequestMapping(method = RequestMethod.GET)
    public List<DePhUpdate> findAll(@RequestParam(value = "view", defaultValue = "0") String view, @RequestParam(value = "monthYear", defaultValue = "0") String monthYear,@RequestParam(value = "projectId", defaultValue = "0") Integer projectId, HttpServletRequest request) throws MessagingException{
         List<DePhUpdate> DePhUpdateList = null;
         Integer loggedInUid = (Integer) session.getAttribute("loggedInUid");
		 int month = 0;
		 int year = 0;
		 boolean isDEMember = false;
		 boolean isPMOMember = false;
		 
		 //Get the user roles
		 String userRoles = session.getAttribute("userRoles") != null ? session.getAttribute("userRoles").toString() : "";
		 int uid = session.getAttribute("loggedInUid") != null ? Integer.valueOf(session.getAttribute("loggedInUid").toString()) : 0;
		 if(userRoles.toLowerCase().contains("de")) isDEMember = true;
		 if(userRoles.toLowerCase().contains("pmo")) isPMOMember = true;
		 
        try {
        	
      		 if(!monthYear.equals("") && monthYear.contains("-")) { month = Integer.valueOf(monthYear.split("-")[0]); year = Integer.valueOf(monthYear.split("-")[1]); }

	   		 if( (view.equals("de") && isDEMember) || (view.equals("pmo") && isPMOMember) || (view.equals("dh") && uid == 512)){

	 	   			DePhUpdateList = manager.createNamedQuery("getAllDePhUpdateData", DePhUpdate.class)
			 				.setParameter("uid", uid)
		    				.setParameter("view", view)
			 				.getResultList();	   				 

	   			 
	        }else if(view.equals("ph") || view.equals("cep")){
	        	
		        		DePhUpdateList = manager.createNamedQuery("getAllDePhUpdateData", DePhUpdate.class)
				 				.setParameter("uid", uid)
		        				.setParameter("view", view)
				 				.getResultList();	   				 
		 	}

         } 
		catch (Exception e){
			e.printStackTrace();
			 logger.info(String.format("exception - ", e));
        }
        
        return DePhUpdateList;

    }
    
    /**
     * This method is add row in moduleName entity
     * 
     */
    @RequestMapping(method=RequestMethod.POST)
	public DePhUpdate addDePhUpdate(@RequestBody DePhUpdate deMsr, HttpServletRequest request) {
		// Authorization for XYZ role
			try{
				deMsr.setDePhUpdateId(null);
				dePhUpdateRepository.save(deMsr);
			}
			catch(Exception e){
				 logger.info(String.format("exception - ", e));
			}
		
		return deMsr;
	}
    
    
	@RequestMapping(value="/upload/{dePhUpdateId}",method=RequestMethod.POST,consumes = {"multipart/form-data"})
    @ResponseBody
	public String uploadFile(@RequestPart("file") MultipartFile file,@PathVariable(value = "dePhUpdateId") Integer dePhUpdateId,HttpServletRequest request)
	{
		DePhUpdate deMsr = dePhUpdateRepository.findOne(dePhUpdateId);

		String type = "dephupdate";
		path=exportUtil.getDeFilePath(file,request,dePhUpdateId,type);		
		deMsr.setFilepath(path);
		dePhUpdateRepository.save(deMsr);
		return path;
	}
	
	@RequestMapping(value="/download/{dePhUpdateId}",method=RequestMethod.GET)
	public void download(@PathVariable(value = "dePhUpdateId") Integer dePhUpdateId,HttpServletRequest request,HttpServletResponse response) throws ServletException, Exception {
		String path=null;
		File home=exportUtil.checkPath(request);
		String separator=File.separator;
		String Filepath = "";
		path=home.getPath();
		
		DePhUpdate deMsr =dePhUpdateRepository.findOne(dePhUpdateId);

		Filepath = deMsr.getFilepath();

		List<String> list = Arrays.asList(Filepath.split("\\s*,\\s*"));
	
		if(list.size() > 1){
		
			if (home.exists() && home.isDirectory()) {
				 logger.info("home is a directory");
				    if(path.equals(separator)){
					 	path="usr"+File.separator+"home"+File.separator+"Download";
					}
					else{
						path=File.separator+"usr"+File.separator+"home"+File.separator+"Download";
					}
				
					if (Files.isDirectory(Paths.get(home + path))) {
						if(path.equals(separator)){
							path="usr"+File.separator+"home"+File.separator+"Download"+File.separator+"infotravel";
						}
						else{
							path=File.separator+"usr"+File.separator+"home"+File.separator+"Download"+File.separator+"infotravel";
						}
						
						if (Files.isDirectory(Paths.get(home + path))) {
							if(path.equals(separator)){
								path="usr"+File.separator+"home"+File.separator+"Download"+File.separator+"infotravel"+File.separator;
							}
							else{
								path=File.separator+"usr"+File.separator+"home"+File.separator+"Download"+File.separator+"infotravel"+File.separator;
							}
							
						} 
					}
				
			}
			
			
		}
		else{
			try{
				File outputFile = new File(Filepath);
				Path file = Paths.get(outputFile+"");
			    response.addHeader("Content-Disposition", "attachment; filename="+file.getFileName());
			    Files.copy(file, response.getOutputStream());
			    response.getOutputStream().flush();
			}
			catch(FileNotFoundException fe){
				fe.printStackTrace();
			}
		}
	}
	
	
//    
    /**
     * This method is update row in moduleName entity
     * based on primaryKey Of Module Table 
     */
	
    @RequestMapping(value="/{dePhUpdateId}",method=RequestMethod.PUT)
	 public DePhUpdate updateDePhUpdate(@RequestBody DePhUpdate deMsr,@PathVariable Integer dePhUpdateId,HttpServletRequest request){
	
			try{
				 deMsr.setDePhUpdateId(dePhUpdateId);
				 dePhUpdateRepository.save(deMsr);
			}
			catch(Exception e){
				 logger.info(String.format("exception - ", e));
			}
		 return deMsr;
	 }
    
    /**
     * This method is get data for specific row in moduleName entity
     * based on primaryKey Of Module Table 
     */
	   @RequestMapping(value = "/{dePhUpdateId}",method=RequestMethod.GET)
	    public DePhUpdate findDePhUpdateId(@PathVariable("dePhUpdateId") Integer dePhUpdateId){
	        return this.dePhUpdateRepository.findOne(dePhUpdateId);
	    }
	 
    
    /**
     * This method is delete data for specific row in moduleName entity
     * based on primaryKey Of Module Table 
     */	 
		@RequestMapping(value= "/{dePhUpdateId}",method=RequestMethod.DELETE)
		public void deleteDeMsr(@PathVariable Integer dePhUpdateId, HttpServletRequest request) {
				try{
					if(dePhUpdateId!=null) {
						DePhUpdate dePhUpdate = dePhUpdateRepository.findOne(dePhUpdateId);
						dePhUpdateRepository.delete(dePhUpdateId);						
					}
				}
				catch(Exception e){
					 logger.info(String.format("exception - ", e));
				}
		}
	
  
   
}
