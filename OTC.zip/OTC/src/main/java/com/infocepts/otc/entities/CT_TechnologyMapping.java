package com.infocepts.otc.entities;

import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.SqlResultSetMappings;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.infocepts.otc.utilities.LoadConstant;

@Entity
@Table(catalog=LoadConstant.otc, schema="[dbo]",name="ct_technologyMapping")
@SqlResultSetMappings({
    @SqlResultSetMapping(
            name = "technologywise_mapping",
            classes = {
                    @ConstructorResult(
                            targetClass = CT_TechnologyMapping.class,
                            columns = {
                            		@ColumnResult(name = "technologyMappingId"),
                            		@ColumnResult(name = "gradeId"),
                            		@ColumnResult(name = "roleId"),
                            		@ColumnResult(name = "techCourseCode", type = String.class),
                            		@ColumnResult(name = "technologyId"),
                            		@ColumnResult(name = "technologyCourseId"),
									@ColumnResult(name = "courseName", type = String.class),
                            		@ColumnResult(name = "technologyName", type = String.class),
                            		@ColumnResult(name = "preRequisites", type = String.class),
                            		@ColumnResult(name = "grade", type = String.class),
                            		@ColumnResult(name = "role", type = String.class)
                            }
                    )
            }
    )
})
@NamedNativeQueries({
    @NamedNativeQuery(
            name    =   "getMappingsByGradeAndRole",   
            query 	=  "select tm.technologyMappingId as technologyMappingId, tm.gradeId as gradeId, tm.roleId as roleId, " + 
						"tc.techCourseCode as techCourseCode, tm.technologyId as technologyId, tm.technologyCourseId as technologyCourseId, tc.courseName as courseName, t.technologyName as technologyName, tc.preRequisites as preRequisites, g.grade as grade, hrR.role as role  from " + LoadConstant.otc + ".[dbo].[ct_technologyMapping] tm " + 
						"left join " + LoadConstant.otc + ".[dbo].[ct_technologyCourses] tc on tc.technologyCourseId = tm.technologyCourseId " + 
						"left join " + LoadConstant.otc + ".[dbo].[ct_technology] t on t.technologyId = tm.technologyId " +
						"left join " + LoadConstant.infomaster + ".[dbo].[grade] g on g.gradeId = tm.gradeId " +
						"left join " + LoadConstant.infomaster + ".[dbo].[hrRoles] hrR on hrR.hrmsId = tm.roleId " +
						"where tm.gradeId = :gradeId and tm.technologyId = :technologyId " + 
						"order by tm.technologyMappingId",
						resultClass=CT_TechnologyMapping.class, resultSetMapping = "technologywise_mapping"
    ),
    @NamedNativeQuery(
            name    =   "getAllMapping",   
            query 	=  "select tm.technologyMappingId as technologyMappingId, tm.gradeId as gradeId, tm.roleId as roleId, " + 
						"tc.techCourseCode as techCourseCode, tm.technologyId as technologyId, tm.technologyCourseId as technologyCourseId, tc.courseName as courseName, t.technologyName as technologyName, tc.preRequisites as preRequisites, g.grade as grade, hrR.role as role  from " + LoadConstant.otc + ".[dbo].[ct_technologyMapping] tm " + 
						"left join " + LoadConstant.otc + ".[dbo].[ct_technologyCourses] tc on tc.technologyCourseId = tm.technologyCourseId " + 
						"left join " + LoadConstant.otc + ".[dbo].[ct_technology] t on t.technologyId = tm.technologyId " +
						"left join " + LoadConstant.infomaster + ".[dbo].[grade] g on g.gradeId = tm.gradeId " +
						"left join " + LoadConstant.infomaster + ".[dbo].[hrRoles] hrR on hrR.hrmsId = tm.roleId " +
						"order by tm.technologyMappingId",
						resultClass=CT_TechnologyMapping.class, resultSetMapping = "technologywise_mapping"
    )
})
public class CT_TechnologyMapping {

	// Entity Columns
    // --------------------------------------------------------------------------------
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Integer technologyMappingId;
    private Integer gradeId;
    private Integer roleId;  
    
    @Transient
    private String techCourseCode;
    
    private Integer technologyId; 
    private Integer technologyCourseId;
    
    @Transient
    private String courseName;
    
    @Transient
    private String technologyName;
    
    @Transient
    private String preRequisites;
    
    @Transient
    private String grade;
    
    @Transient
    private String role;

  //getter setter
    
	public Integer getTechnologyMappingId() {
		return technologyMappingId;
	}

	public void setTechnologyMappingId(Integer technologyMappingId) {
		this.technologyMappingId = technologyMappingId;
	}

	public Integer getGradeId() {
		return gradeId;
	}

	public void setGradeId(Integer gradeId) {
		this.gradeId = gradeId;
	}

	public Integer getRoleId() {
		return roleId;
	}

	public void setRoleId(Integer roleId) {
		this.roleId = roleId;
	}

	public String getTechCourseCode() {
		return techCourseCode;
	}

	public void setTechCourseCode(String techCourseCode) {
		this.techCourseCode = techCourseCode;
	}

	

	public Integer getTechnologyId() {
		return technologyId;
	}

	public void setTechnologyId(Integer technologyId) {
		this.technologyId = technologyId;
	}
	
	

	public Integer getTechnologyCourseId() {
		return technologyCourseId;
	}

	public void setTechnologyCourseId(Integer technologyCourseId) {
		this.technologyCourseId = technologyCourseId;
	}

	public String getCourseName() {
		return courseName;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	public String getTechnologyName() {
		return technologyName;
	}

	public void setTechnologyName(String technologyName) {
		this.technologyName = technologyName;
	}
	
	
	public String getPreRequisites() {
		return preRequisites;
	}

	public void setPreRequisites(String preRequisites) {
		this.preRequisites = preRequisites;
	}
	

	public String getGrade() {
		return grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	//constructor 
	public CT_TechnologyMapping(Integer technologyMappingId, Integer gradeId, Integer roleId, String techCourseCode,
			Integer technologyId, Integer technologyCourseId, String courseName, String technologyName, String preRequisites, String grade,
			String role) {
		super();
		this.technologyMappingId = technologyMappingId;
		this.gradeId = gradeId;
		this.roleId = roleId;
		this.techCourseCode = techCourseCode;
		this.technologyId = technologyId;
		this.technologyCourseId = technologyCourseId;
		this.courseName = courseName;
		this.technologyName = technologyName;
		this.preRequisites = preRequisites;
		this.grade = grade;
		this.role = role;
	}

	public CT_TechnologyMapping() {
		// TODO Auto-generated constructor stub
	} 
    

	
    
	
}
