package com.infocepts.otc.entities;


import java.util.Date;
import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.SqlResultSetMappings;
import javax.persistence.Table;
import javax.persistence.Transient;
import com.infocepts.otc.utilities.LoadConstant;



@Entity
@Table(catalog=LoadConstant.otc,schema="[dbo]",name="associateSkills")
@SqlResultSetMappings({
	@SqlResultSetMapping(
		      name = "get_SkillDetails",
		      classes = {
		          @ConstructorResult(
		              targetClass = AssociateSkills.class,
		              columns = {
		                  @ColumnResult(name = "associateSkillId"),
		                  @ColumnResult(name = "skillId"),
		                  @ColumnResult(name = "proficiencyId"),
		                  @ColumnResult(name = "experienceId"),
		                  @ColumnResult(name = "lastWorkedOn", type=Date.class),
		                  @ColumnResult(name = "notes"),
		                  @ColumnResult(name = "isCurrentSkill"),
		                  @ColumnResult(name = "createdBy"),
		                  @ColumnResult(name = "createdDate", type=Date.class),
		                  @ColumnResult(name = "modifiedBy"),
		                  @ColumnResult(name = "modifiedDate", type=Date.class),
		                  @ColumnResult(name = "status"),
		                  @ColumnResult(name = "approvedById"),
		                  @ColumnResult(name = "uid"),
		                  @ColumnResult(name = "coeApproved"),	                  
		                  @ColumnResult(name = "isPrimarySkill"),
		                  @ColumnResult(name = "resourceName"),
		                  @ColumnResult(name = "employeeId"),
		                  @ColumnResult(name = "skillName"),
		                  @ColumnResult(name = "domain"),
		                  @ColumnResult(name = "coe"),
		                  @ColumnResult(name = "skillCategory"),
		                  @ColumnResult(name = "departmentName"),
		                  @ColumnResult(name = "isSecondarySkill")
		                }
		          )
		      }
	)
})
@NamedNativeQueries({
	    @NamedNativeQuery(
	            name    =   "getSkillsList_Associates",
	            query   =   "select s.*,r.empId as employeeId,r.title as resourceName,sk.skillName as skillName,sc.skillCategoryName as skillCategory,r.domain as domain,coe.coeName as coe,dept.departmentName"+
	            			" FROM " + LoadConstant.otc + ".[dbo].[associateSkills] s "+
	            		 	" left join " + LoadConstant.infomaster + ".[dbo].[resource] r on r.uid=s.uid"+
	            		 	" left join " + LoadConstant.infomaster + ".[dbo].[department] dept on r.departmentId=dept.departmentId"+
	            		 	" left join " + LoadConstant.infomaster + ".[dbo].[skill] sk on s.skillId=sk.skillId"+
	            		 	" left join " + LoadConstant.otc + ".[dbo].[coe] coe on coe.coeId=sk.coeId"+
	            		 	" left join " + LoadConstant.infomaster + ".[dbo].[skillcategory] sc on sc.skillCategoryId=sk.skillCategoryId where r.disabled='0'",
	                        resultClass=AssociateSkills.class, resultSetMapping = "get_SkillDetails"    
	    ),
	    @NamedNativeQuery(
	            name    =   "getSkillsByAssociates",
	            query   =   "select s.*,r.empId as employeeId,r.title as resourceName,sk.skillName as skillName,sc.skillCategoryName as skillCategory,r.domain as domain,coe.coeName as coe,dept.departmentName"+
	            			" FROM " + LoadConstant.otc + ".[dbo].[associateSkills] s "+
	            		 	" left join " + LoadConstant.infomaster + ".[dbo].[resource] r on r.uid=s.uid"+
	            		 	" left join " + LoadConstant.infomaster + ".[dbo].[department] dept on r.departmentId=dept.departmentId"+
	            		 	" left join " + LoadConstant.infomaster + ".[dbo].[skill] sk on s.skillId=sk.skillId"+
	            		 	" left join " + LoadConstant.otc + ".[dbo].[coe] coe on coe.coeId=sk.coeId"+
	            		 	" left join " + LoadConstant.infomaster + ".[dbo].[skillcategory] sc on sc.skillCategoryId=sk.skillCategoryId " +
	            		 	" where r.disabled='0' and r.uid = :uid"+
	            		 	" order by isPrimarySkill DESC, isCurrentSkill DESC",
	                        resultClass=AssociateSkills.class, resultSetMapping = "get_SkillDetails"    
	    )
})


public class AssociateSkills {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer associateSkillId;
	
	private Integer skillId;
	private Integer proficiencyId;
	private Integer experienceId;
	private Date lastWorkedOn;
	private String notes;
	private Boolean isCurrentSkill;
	private Integer createdBy;
	private Date createdDate;
	private Integer modifiedBy;
	private Date modifiedDate;
	private String status;
	private Integer approvedById;
	private Integer uid;
	private Integer coeApproved;
	private Boolean isPrimarySkill;
	private Boolean isSecondarySkill;
	public Boolean getIsSecondarySkill() {
		return isSecondarySkill;
	}
	public void setIsSecondarySkill(Boolean isSecondarySkill) {
		this.isSecondarySkill = isSecondarySkill;
	}
	@Transient
	private Skill skill;
	
	@Transient
	private String resourceName;
	
	@Transient
	private Integer employeeId;
	
	@Transient
	private String skillName;
	
	@Transient
	private String domain;
	
	@Transient
	private String coe;
	
	@Transient
	private String skillCategory;
	
	@Transient
	private String departmentName;
	
	
	public Integer getAssociateSkillId() {
		return associateSkillId;
	}
	public void setAssociateSkillId(Integer associateSkillId) {
		this.associateSkillId = associateSkillId;
	}
	public Integer getSkillId() {
		return skillId;
	}
	public void setSkillId(Integer skillId) {
		this.skillId = skillId;
	}
	public Skill getSkill() {
		return skill;
	}
	public void setSkill(Skill skill) {
		this.skill = skill;
	}
	public Integer getProficiencyId() {
		return proficiencyId;
	}
	public void setProficiencyId(Integer proficiencyId) {
		this.proficiencyId = proficiencyId;
	}
	public Integer getExperienceId() {
		return experienceId;
	}
	public void setExperienceId(Integer experienceId) {
		this.experienceId = experienceId;
	}
	public Date getLastWorkedOn() {
		return lastWorkedOn;
	}
	public void setLastWorkedOn(Date lastWorkedOn) {
		this.lastWorkedOn = lastWorkedOn;
	}
	public String getNotes() {
		return notes;
	}
	public void setNotes(String notes) {
		this.notes = notes;
	}
	public Boolean getIsCurrentSkill() {
		return isCurrentSkill;
	}
	public void setIsCurrentSkill(Boolean isCurrentSkill) {
		this.isCurrentSkill = isCurrentSkill;
	}
	public Integer getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public Integer getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public Date getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Integer getApprovedById() {
		return approvedById;
	}
	public void setApprovedById(Integer approvedById) {
		this.approvedById = approvedById;
	}
	public Integer getUid() {
		return uid;
	}
	public void setUid(Integer uid) {
		this.uid = uid;
	}
	public Integer getCoeApproved() {
		return coeApproved;
	}
	public void setCoeApproved(Integer coeApproved) {
		this.coeApproved = coeApproved;
	}
	public Boolean getIsPrimarySkill() {
		return isPrimarySkill;
	}
	public void setIsPrimarySkill(Boolean isPrimarySkill) {
		this.isPrimarySkill = isPrimarySkill;
	}
	public String getResourceName() {
		return resourceName;
	}
	public void setResourceName(String resourceName) {
		this.resourceName = resourceName;
	}
	public Integer getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}
	public String getSkillName() {
		return skillName;
	}
	public void setSkillName(String skillName) {
		this.skillName = skillName;
	}
	
	public String getDomain() {
		return domain;
	}
	
	public void setDomain(String domain) {
		this.domain = domain;
	}

	public String getCoe() {
		return coe;
	}

	public void setCoe(String coe) {
		this.coe = coe;
	}
	
	public String getSkillCategory() {
		return skillCategory;
	}

	public void setSkillCategory(String skillCategory) {
		this.skillCategory = skillCategory;
	}

	public String getDepartmentName() {
		return departmentName;
	}
	
	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}
	
	public AssociateSkills() {

	}
	public AssociateSkills(Integer associateSkillId, Integer skillId, Integer proficiencyId, Integer experienceId,
			Date lastWorkedOn, String notes, Boolean isCurrentSkill, Integer createdBy, Date createdDate,
			Integer modifiedBy, Date modifiedDate, String status, Integer approvedById, Integer uid,
			Integer coeApproved, Boolean isPrimarySkill,String resourceName,Integer employeeId,String skillName,String domain,String coe,String skillCategory, String departmentName, Boolean isSecondarySkill) {
		this.associateSkillId = associateSkillId;
		this.skillId = skillId;
		this.proficiencyId = proficiencyId;
		this.experienceId = experienceId;
		this.lastWorkedOn = lastWorkedOn;
		this.notes = notes;
		this.isCurrentSkill = isCurrentSkill;
		this.createdBy = createdBy;
		this.createdDate = createdDate;
		this.modifiedBy = modifiedBy;
		this.modifiedDate = modifiedDate;
		this.status = status;
		this.approvedById = approvedById;
		this.uid = uid;
		this.coeApproved = coeApproved;
		this.isPrimarySkill = isPrimarySkill;
		this.resourceName=resourceName;
		this.employeeId=employeeId;
		this.skillName=skillName;
		this.domain=domain;
		this.coe=coe;
		this.skillCategory=skillCategory;
		this.departmentName = departmentName;
		this.isSecondarySkill = isSecondarySkill;
	}
	
	
}
