/**
* Filename: /src/main/java/com/infocepts/otc/controllers/ISOWController.java
* @author  JV
* @version 1.0
* @since   2018-10-31 
*/
package com.infocepts.otc.controllers;

import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Iterator;
import java.util.List;
import javax.mail.MessagingException;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.infocepts.otc.entities.ISow;
import com.infocepts.otc.notification.SmtpMailSender;
import com.infocepts.otc.repositories.AccountRepository;
import com.infocepts.otc.repositories.ISowRepository;
import com.infocepts.otc.services.TimesheetService;
import com.infocepts.otc.utilities.ExportUtil;
import com.infocepts.otc.utilities.InvoiceNoGenerator;

@RestController
@RequestMapping(value="/isow",headers="referer")
public class ISowController {

	final Logger logger = Logger.getLogger(ISowController.class);
	
	@Autowired
	ISowRepository repository;
	
	@Value("${spring.host.localdrive}")
   	private String localdrive;
	
	@Autowired
	SmtpMailSender smtpMailSender;
		
	@Autowired
	TimesheetService service;
	
	@PersistenceContext
    private EntityManager manager;
	
	@Autowired
	ExportUtil exportUtil;
	
	@Autowired
	ProjectController projectController;
	
	@Autowired
	ResourceController resourceController;
	
	@Autowired
	AccountRepository accountRepository;

	String path=null;String filepath="";
	
	@RequestMapping(method=RequestMethod.POST)
	public ISow addISow(@RequestBody ISow isow, HttpServletRequest request) throws MessagingException{
	
		String isowNo = "";
		String isows = "";
		List<ISow> isowList  = null;
		Integer projectId = isow.getProjectId();
		// Authorization for Admin, PMO
		if(service.isPmo() || service.isAdmin())
 		{
				if(projectId != 0)
				{
			 			try{
							
							if(("Pending Approval".equals(isow.getStatus()) || "Draft".equals(isow.getStatus())) && "".equals(isow.getIsowNo())){
								
								isowList = manager.createNamedQuery("getLastISow",ISow.class)
										   .setParameter("executionUnit", isow.getExecutionUnit())
											.getResultList();
								
								if(isowList.size()>0){
									Iterator<ISow> it = isowList.iterator();
									while (it.hasNext()) {
										ISow isowIt = it.next();
										isows = isowIt.getIsowNo();
									}
									isowNo = InvoiceNoGenerator.generateISowNo(isows,isow.getExecutionUnitId());
									
									
								}else {
									isowNo = InvoiceNoGenerator.generateISowNo(isows,isow.getExecutionUnitId());
								}
								isow.setIsowNo(isowNo);
								
							}
							
							isow.setIsowId(null);
							repository.save(isow);
		
						}catch(Exception e){
							logger.error(e);
						}
					}
					else
					{
						throw new IllegalArgumentException("Access Denied");
					}
				}
 
		return isow;
	}
	
	 @RequestMapping(method=RequestMethod.GET)
	 public List<ISow> getAllSow(HttpServletRequest request) throws MessagingException {
		 List<ISow> isowList = null;
		 try{
			// Authorization for Admin, PMO and Legal
		 		if(service.isPmo() || service.isLegal() || service.isAdmin())
		 		{
		 			isowList = manager.createNamedQuery("getISowsForAllProjects",ISow.class)
		 				.getResultList();
		 		}
		 }			 	
		 
		 catch(Exception e){
			 logger.error(e);
		 }
			 return isowList;
	}
	 
	 @RequestMapping(value="/{isowId}",method=RequestMethod.GET)
	 public ISow getISow(@PathVariable Integer isowId,
			 			HttpServletRequest request) throws MessagingException {
		 ISow isow = null;
		// Authorization for Admin, PMO and Legal
		 if(service.isPmo() || service.isLegal() || service.isAdmin())
	 		{
				 if(isowId != 0)
				 {
					 try{		 
						 isow = repository.findOne(isowId);
					 }
					 catch(Exception e){
						 logger.error(e);
					 }
				}
	 		}
		 return isow;
	 }
	 
	 
	 @RequestMapping(value="/{isowId}",method=RequestMethod.PUT)
	 public ISow updateISow(@RequestBody ISow updatedISow,@PathVariable Integer isowId, HttpServletRequest request,@RequestParam(value = "isDownload", defaultValue="false") Boolean isDownload)throws URISyntaxException, IOException, MessagingException{
		 	 File outputFile=null;
	         String FileName = null;
			 File home =  exportUtil.checkPath(request);
			 path=home.getPath();
			 String separator=File.separator;		     
		     LocalDate localDate = updatedISow.getConsultingAgrDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
		     int year  = localDate.getYear();
		     int month = localDate.getMonthValue();
		     // Authorization for Admin, PMO and Legal
		     if(service.isPmo() || service.isLegal() || service.isAdmin())
		 		{ 
					
				 			try{
								  if(!isDownload){
										service.sendISowNotification(updatedISow, request); 
							      }else{
							    	 FileName = updatedISow.getIsowNo().toString();
						    		 if(path.equals(separator)){
						    			 path="usr"+File.separator+"home"+File.separator+"Download"+File.separator+"isow"+File.separator;
									 }else{
										 path=File.separator+"usr"+File.separator+"home"+File.separator+"Download"+File.separator+"isow"+File.separator;
									 }
							    	 outputFile = new File(home+path+year+File.separator+month+File.separator+FileName);
							      }					
								updatedISow.setIsowId(isowId);
						    	updatedISow.setFilePath(outputFile+".docx");
								repository.save(updatedISow);  
							}catch(Exception e){
								 logger.error(e);
							}
			}
		 	return updatedISow;
	 }
}
