package com.infocepts.otc.controllers;

import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.infocepts.otc.entities.AmgRoles;
import com.infocepts.otc.repositories.AmgRolesRepository;
import com.infocepts.otc.services.TimesheetService;

@RestController
@RequestMapping(value="/amgRoles",headers="referer")
public class AmgRolesController {

	final Logger logger = Logger.getLogger(AmgRolesController.class);
	
	@Autowired
	AmgRolesRepository repository;
	
	@Autowired
	TimesheetService service;
	
	@RequestMapping(method=RequestMethod.POST)
	public AmgRoles addAmgRoles(@RequestBody AmgRoles amgRoles){
		try{
			if(service.isAMG()){
				amgRoles.setAmgRoleId(null);
				repository.save(amgRoles);
			}
		}
		catch(Exception e){
			logger.error(e);
		}
		return amgRoles;
	}
	
	@RequestMapping(method=RequestMethod.GET)
	public List<AmgRoles> getAmgRoles(){
		List<AmgRoles> list=null;
		try{
			if(true){ //service.isAMG() Removed the authorization for now - It should be accessibe t PM/PMO as well fro CMS and SOW creation
				list = repository.findAll();
			}
		}
		catch(Exception e){
			logger.error(e);
		}
		return list;
	}
	
	@RequestMapping(value="/{amgRoleId}",method=RequestMethod.PUT)
	public AmgRoles updateAmgRoles(@PathVariable Integer amgRoleId,@RequestBody AmgRoles updatedAmgRoles){
		try{
			if(service.isAMG()){
				updatedAmgRoles.setAmgRoleId(amgRoleId);
				repository.save(updatedAmgRoles);
			}
		}
		catch(Exception e){
			logger.error(e);
		}
		return updatedAmgRoles;
	}
	
	@RequestMapping(value="/{amgRoleId}",method=RequestMethod.DELETE)
	public void deleteAmgRoles(@PathVariable Integer amgRoleId){
		try{
			if(service.isAMG()){
				repository.delete(amgRoleId);
			}
		}
		catch(Exception e){
			logger.error(e);
		}
	}
}
