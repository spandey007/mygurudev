package com.infocepts.otc.utilities;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.CodeSource;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import java.util.logging.Logger;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import com.infocepts.otc.controllers.AccountController;
import com.infocepts.otc.controllers.GtpController;
import com.infocepts.otc.entities.AmgRoles;
import com.infocepts.otc.entities.Band;
import com.infocepts.otc.entities.City;
import com.infocepts.otc.entities.Grade;
import com.infocepts.otc.entities.Gtp;
import com.infocepts.otc.entities.Skill;
import com.infocepts.otc.entities.Treq;
import com.infocepts.otc.entities.Unit;
import com.infocepts.otc.repositories.AccountRepository;
import com.infocepts.otc.repositories.AmgRolesRepository;
import com.infocepts.otc.repositories.BandRepository;
import com.infocepts.otc.repositories.CityRepository;
import com.infocepts.otc.repositories.GradeRepository;
import com.infocepts.otc.repositories.SkillRepository;
import com.infocepts.otc.repositories.TreqRepository;
import com.infocepts.otc.repositories.UnitRepository;

@Component
public class SchedulerTask {
	
	final Logger logger = Logger.getLogger(SchedulerTask.class.getName());

	@Autowired
	AccountRepository accountRepository;
	
	@Autowired
	SkillRepository skillRepository;
	
	@Autowired
	GradeRepository gradeRepository;
	
	@Autowired
	BandRepository bandRepository;
	
	@Autowired
	AccountController accountController;
	
	@Autowired
	TreqRepository repository;
	
	@Autowired
	AmgRolesRepository amgRolesRepository;
	
	@Autowired
	CityRepository cityRepository;
	
	@Autowired
	UnitRepository unitRepository;
	
	@Value("${spring.host.localdrive}")
   	private String localdrive;
	
	@Value("${spring.host.url}")
	private String url;
	
//	@Value("${spring.host.hostPathSeparator}")
//	private String hostPathSeparator;


	 @PersistenceContext(unitName = "otc")
	 private EntityManager manager;
	 
	 @Autowired
	 GtpController gtpController;
	 
	 /*
	 * SRA: function to copy GTP data from last date to current date along with new resources at 1 AM
	 */
	public List<Gtp> gtpUploadLastData() throws IOException, ParseException{		
		  logger.info("Cron job method gtpUploadLastData in execution"); 	
		  List<Gtp> gtpResourcelist = null;
		  	     
		  try {
			    DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		    	Date date = new Date();
		    	String currentDate = dateFormat.format(date);	 
		    	if (currentDate != null) {	        	     
	        	     
		    		//check if data is present in table for current date		
	        		gtpResourcelist = manager.createNamedQuery("isDataPresentForGtpDate", Gtp.class)                        
	                        .setParameter("gtpDate", currentDate)
	                        .getResultList();
	        		
	        		int retval = gtpResourcelist.size();
	        	    logger.info("No of GTP resource for current Date = " + retval); 
	        	      
	         	     
	         	    //if data for current date is not present, copy from previous date
	         		if(gtpResourcelist.isEmpty()){
	         		
	         				//get data for a date where data is available in GTP table(if not present in previous date..take a date previous to it..and so on..)
	         				gtpResourcelist = manager.createNamedQuery("getGtpResourcesFromLastDate", Gtp.class)
	                             .getResultList();
	         				
	         				int retval1 = gtpResourcelist.size();
	                	    logger.info("No of GTP resource for last Date = " + retval1); 
	                	     	
	         				//loop over data
	 						for (Gtp user : gtpResourcelist)
	 						{		
	 							Date formattedCurrentDate = null;
								int proposedDays = 0; String proposedDaysCateg = null;
															
				        		//convert String to Date dataType so as to save in table	        		
						    	formattedCurrentDate = DateConverter.convertStringToDate(currentDate);

						    	if(formattedCurrentDate != null && user.getProposedDate() != null){
						    		proposedDays = (int) DateConverter.daysBetween(formattedCurrentDate, user.getProposedDate());
							       
							        //user.setProposedDays(proposedDays);
							        if(proposedDays <= 15) {proposedDaysCateg = "0-15 Days";}
							        else if(proposedDays > 15) {proposedDaysCateg = "15+ Days";}
							        
						    	} else {
						    		proposedDays = 0;
						    		proposedDaysCateg = null;
						    	}
	 						    	 						    
	 						   
	 						   //While copying update gtpDate to current Date and other columns(last Alc columns/Gtp Days/Gtp Categ/Availability/)
							    user.setLastAlcProjectId(user.getLastAlcProjectId());	
							    user.setLastAlcAccountId(user.getLastAlcAccountId());	
							    user.setLastAlcDate(user.getLastAlcDate());	
							    user.setGtpDays(user.getGtpDays());	
							    user.setGtpDaysCateg(user.getGtpDaysCateg());	
							    user.setAvailability(user.getAvailability());
							    
								user.setGtpDate(formattedCurrentDate);
								
								user.setDeployableStatus(user.getDeployableStatus());
								user.setResourceStatus(user.getResourceStatus());
								user.setProposedDate(user.getProposedDate());
								
								user.setProposedDays(proposedDays);
								user.setProposedDaysCateg(proposedDaysCateg);
								
								user.setProposedAccountId(user.getProposedAccountId());
								user.setConfirmedDate(user.getConfirmedDate());
								user.setBillingStartDate(user.getBillingStartDate());
								user.setGtpRemarks(user.getGtpRemarks());
								//if(user.getBucketId() == null)
								//{
								//	int defaultBucketId = 11;
								//	user.setBucketId(defaultBucketId);	
								//	user.setBucket("NB_POOL");
								//}
								//else
								//{
								//	user.setBucketId(user.getBucketId());// set NB_POOL (bucketId = 11) as default
								logger.info("getDeployableStatus"+ user.getDeployableStatus());
								logger.info("getResourceStatus"+user.getResourceStatus());
								
								if("Deployable".equals(user.getDeployableStatus()) && ("Available".equals(user.getResourceStatus()) || "Proposed".equals(user.getResourceStatus()) || "Aligned Account".equals(user.getResourceStatus()))){
									user.setBucketId(11);	
									user.setBucket("NB_POOL");
								}
								if("Non-Deployable".equals(user.getDeployableStatus()) && "Earmarked".equals(user.getResourceStatus())){					
									user.setBucketId(13);	
									user.setBucket("NB_INDENTOPP");
								}
								if("Non-Deployable".equals(user.getDeployableStatus()) && ("Confirmed".equals(user.getResourceStatus()) || "Awaiting SOW Extension".equals(user.getResourceStatus()))){
									user.setBucketId(2);	
									user.setBucket("B_Risk");
								}
								if("Non-Deployable".equals(user.getDeployableStatus()) && ("Resigned".equals(user.getResourceStatus()) || "Absconded".equals(user.getResourceStatus()))){
									user.setBucketId(7);	
									user.setBucket("NB_Resigned");
								}
								if("Non-Deployable".equals(user.getDeployableStatus()) && "PIP".equals(user.getResourceStatus())) {
									user.setBucketId(25);	
									user.setBucket("NB_PERFCASE");
								}
								if("Non-Deployable".equals(user.getDeployableStatus()) && "Training".equals(user.getResourceStatus())) {
									user.setBucketId(24);	
									user.setBucket("NB_TRAINING");
								}
								if("Non-Deployable".equals(user.getDeployableStatus()) && ("LL/ML".equals(user.getResourceStatus()) || "Sabbatical Leave".equals(user.getResourceStatus()))){
									user.setBucketId(16);	
									user.setBucket("OH_LongLeave");
								}
								//} 
								
								user.setModifiedBy(null);
								user.setModifiedDate(new Date());	
								
								//check if uid is present in table for gtp date date  
								List<Gtp> gtpResourceForDate =  manager.createNamedQuery("isUidPresentForGtpDate", Gtp.class)                        
										.setParameter("gtpDate", currentDate)
										.setParameter("uid", user.getUid())
										.getResultList();
				                 
				        		int isPresentVal = gtpResourceForDate.size();
				        		
								if(isPresentVal == 0){ // add uid only if not present for gtpDate
									logger.info("Adding user= "+user.getUid()); 
									gtpController.addGtp(user);
									logger.info("============================================== "); 
								}
								
	 						}
	         		}
		    	}
		  }
		  catch (Exception e){
			  logger.info(String.format("exception - ", e));
	        }
		return gtpResourcelist;
	}
	
//	public List<Treq> generateExcelForTreqs() throws IOException, ParseException, URISyntaxException{
//		 List<Treq> treqList=null;String home=null;File rootPath = null;String pathSeparator="/";File usrDirectory=null;
//		 List<Treq> inactiveHiringTreqs=null;
//		 String status="Hiring";
//		 String billingType="Non Billable";
//		 Integer skillId=0;
//		 Skill skill=null;
//		 Integer secondarySkillId=0;
//		 Skill secondarySkill=null;
//		 Grade grade=null;
//		 Integer gradeId=0;
//		 Band band=null;
//		 HSSFWorkbook workbook = new HSSFWorkbook();
//		 Date d=new Date();
//		 DateFormat df = new SimpleDateFormat("dd_MMM_yyyy");
//		 String filename="TREQ_"+df.format(d);
//         if(!url.equals("")){
//        	 CodeSource codeSource = this.getClass().getProtectionDomain().getCodeSource();
//				rootPath = new File(codeSource.getLocation().toURI().getPath());
//				String path = rootPath.getCanonicalPath();
//				logger.info("path" + path);//returns /usr/share/tomcat8
//				int firstIndex=path.indexOf("/");
//				String substr=path.substring(firstIndex+1);//returns usr/share/tomcat8
//				int nextIndex=substr.indexOf("/");
//				if(nextIndex>0){
//					String finalStr=substr.substring(0,nextIndex);// returns usr
//					finalStr=pathSeparator+finalStr;//returns /usr
//					usrDirectory = new File(finalStr);
//					if (usrDirectory.exists() && usrDirectory.isDirectory()) 
//					{
//						if (Files.isDirectory(Paths.get(usrDirectory + "/home/treqs")))
//						{
//							Path p=Paths.get(usrDirectory + "/home/treqs");
//						    home=p.toString();
//						    logger.info("home is:"+home);
//						}
//						else{
//							home="\\\\INFO-INVOICE\\InfoBiz Treqs";//on production here the file gets generated
//						}
//					}
//				}
//         }
//         if(home!=null){
//		 File file = new File(home);   
//    	 File[] files = file.listFiles();
//    	 System.out.println("accessed done"+file.isDirectory());
//    	 if(file.isDirectory()){
//    		 FileOutputStream stream=null;
//    		 System.out.println("file1 is a directory");
//    		 File outputFile=null;
//				try {
//						Files.createDirectories(Paths.get(home));
//					} catch (IOException e) {
//						// TODO Auto-generated catch block
//						e.printStackTrace();
//					}
//				if(!url.equals(""))
//				{
//					outputFile = new File(home  +hostPathSeparator+ filename+".xls");
//				}
//    			System.out.println("outputFile created"+outputFile.getAbsolutePath());
//    			 DateFormat df1 = new SimpleDateFormat("yyyy-MM-dd");
//    			try{
//    				String modifiedDate=df1.format(d);
//       			 Date parsedDate =df1.parse(modifiedDate);
//       			 treqList = repository.findByStatus(status,parsedDate);
//       			 Iterator<Treq> it=treqList.iterator();
//       			 inactiveHiringTreqs=repository.findInactiveHiringTreqs(status);
//   			     Iterator<Treq> iteratorHiringTreqs=inactiveHiringTreqs.iterator();
//       			int counter=1;
//   			 if(treqList.size()>0){
//   				 HSSFSheet sheet = workbook.createSheet("TreqMarkedOnHiringToday");  
//   				 HSSFRow rowhead = sheet.createRow((short)0);
//   				 createRow(rowhead);
//   				 while(it.hasNext()){
//	   				 Treq tr=it.next();
//	   				 if(tr.getSkillId()!=null){
//	   					  skillId=tr.getSkillId();
//	   					  skill=skillRepository.findOne(skillId);
//	   				 }
//	   				if(tr.getSecondarySkillId()!=null){
//						 secondarySkillId=tr.getSecondarySkillId();
//						 secondarySkill=skillRepository.findOne(secondarySkillId);
//					 }
//	//				 Integer accountId=tr.getAccountId();
//	//				 Account account=accountController.getAccount(accountId);
//					 HSSFRow row = sheet.createRow((short)counter);
//					 if(tr.getTreqId()!=null){
//						 row.createCell(0).setCellValue(tr.getTreqId());
//					 }
//				    
//				     row.createCell(1).setCellValue(skill.getSkillName());
//				     if(secondarySkill!=null){
//				    	 row.createCell(2).setCellValue(secondarySkill.getSkillName());
//				     }
//				     if(tr.getPriority()!=null){
//				    	 row.createCell(3).setCellValue(tr.getPriority());
//				     }
//				     if(tr.getRequisitionType()!=null){
//    		        	 row.createCell(4).setCellValue(tr.getRequisitionType());
//    		         }
//    	             //row.createCell(5).setCellValue(account.getAccountShortName());
//    		         if(tr.getCountry()!=null){
//    		        	 row.createCell(6).setCellValue(tr.getCountry());
//    		         }
//    		         if(tr.getComments()!=null){
//    		        	row.createCell(7).setCellValue(tr.getComments());
//    		         }
//    		         if(tr.getCreatedBy()!=null){
//    		        	 row.createCell(8).setCellValue(tr.getCreatedBy());
//    		         }
//    		         if(tr.getCreatedDate()!=null){
//    		        	 row.createCell(9).setCellValue(df.format(tr.getCreatedDate()));
//    		         }
//    		         if(tr.getLocation()!=null){
//    		        	 row.createCell(10).setCellValue(tr.getLocation());
//    		         }
//    		         if(tr.getProjectName()!=null){
//    		        	row.createCell(11).setCellValue(tr.getProjectName());
//    		         }
//    		         if(tr.getStatus()!=null){
//    		        	 row.createCell(12).setCellValue(tr.getStatus());
//    		         }
//    		        
//    		         if(tr.getSowDetail()!=null)
//    		         {
//    		        	 if(tr.getSowDetail().getAssociateLevelId()!=null){
//    		        		  grade=gradeRepository.findOne(tr.getSowDetail().getAssociateLevelId());
//    		        		  gradeId=grade.getGradeId();
//    						  band=bandRepository.findOne(gradeId);
//    						  if(band!=null){
//    							  row.createCell(19).setCellValue(band.getBand());
//    						  }
//    						  if(grade!=null){
//    							  row.createCell(20).setCellValue(grade.getGrade());
//    						  }
//    		        	 }
//    					 Boolean billable=tr.getSowDetail().getIsBillable();
//    					 if(billable)
//    					 {
//    						 billingType="Billable";
//    					 }
//    					 
//    					 Integer roleId=tr.getSowDetail().getRoleId();
//    					 AmgRoles amgRoles =amgRolesRepository.findOne(roleId);
//    					 if(tr.getSowDetail().getCityId()!=null){
//    						 Integer cityId=tr.getSowDetail().getCityId();
//    						 City city=cityRepository.findOne(cityId);
//    						 row.createCell(21).setCellValue(city.getCityName());
//    					 }
//    					 if(tr.getSowDetail().getUnitId()!=null){
//    						 Integer unitId=tr.getSowDetail().getUnitId();
//    						 Unit unit=unitRepository.findOne(unitId);
//    						 row.createCell(18).setCellValue(unit.getUnitName());
//    					 }
//    					 
//    					 BigDecimal billableRate=tr.getSowDetail().getBillableRate();
//    					 double doublebillableRate=billableRate.doubleValue();
//    		        	 row.createCell(13).setCellValue(amgRoles.getAmgRoleName());
//    		    		 row.createCell(14).setCellValue(df.format(tr.getSowDetail().getSowRoleStartDate()));
//    		    		 row.createCell(15).setCellValue(df.format(tr.getSowDetail().getSowRoleEndDate()));
//    			         row.createCell(16).setCellValue(doublebillableRate);
//    			         row.createCell(17).setCellValue(billingType);
//    		         }
//    		         else{
//     		        	
//     		        	 if(tr.getCmsDetail()!=null){
//     		        		  grade=gradeRepository.findOne(tr.getCmsDetail().getAssociateLevelId());
//     						  gradeId=grade.getGradeId();
//     						  band=bandRepository.findOne(gradeId);
//     		        		 Boolean billable=tr.getCmsDetail().getIsBillable();
//     						 if(billable)
//     						 {
//     							 billingType="Billable";
//     						 }
//     			        	 row.createCell(14).setCellValue(df.format(tr.getCmsDetail().getSowRoleStartDate()));
//     				         row.createCell(15).setCellValue(df.format(tr.getCmsDetail().getSowRoleEndDate()));
//     						 Integer roleId=tr.getCmsDetail().getRoleId();
//     						 AmgRoles amgRoles =amgRolesRepository.findOne(roleId);
//     			        	 row.createCell(13).setCellValue(amgRoles.getAmgRoleName());
//     			        	 BigDecimal billableRate=tr.getCmsDetail().getBillableRate();
//     						 double doublebillableRate=billableRate.doubleValue();
//     						 row.createCell(16).setCellValue(doublebillableRate);
//     				         row.createCell(17).setCellValue(billingType);
//     				         if(tr.getCmsDetail().getCityId()!=null){
//     				        	 Integer cityId=tr.getCmsDetail().getCityId();
//     							 City city=cityRepository.findOne(cityId);
//     					         row.createCell(21).setCellValue(city.getCityName());
//     				         }
//     						 if(tr.getCmsDetail().getUnitId()!=null){
//     							 Integer unitId=tr.getCmsDetail().getUnitId();
//     							 Unit unit=unitRepository.findOne(unitId);
//     							 row.createCell(18).setCellValue(unit.getUnitName());
//     						 }
//     						 if(band!=null){
//     							 row.createCell(19).setCellValue(band.getBand());
//     						 }
//     						 if(grade!=null){
//     							 row.createCell(20).setCellValue(grade.getGrade());
//     						 }
//     		        	 }
//     		         }
//     		         row.createCell(22).setCellValue(tr.getJobDescription());
//				     stream = new FileOutputStream(outputFile);
//    				 workbook.write(stream);
//    				 counter++;
//   				 }
//   			 }
//   			if(inactiveHiringTreqs.size()>0){
//				 counter=1;
//				 HSSFSheet sheet = workbook.createSheet("TreqStatusChangedFromHiringToday");  
//				 HSSFRow rowhead = sheet.createRow((short)0);
//				 createRow(rowhead);
//				 while(iteratorHiringTreqs.hasNext()){
//   				 Treq tr=iteratorHiringTreqs.next();
//   				 if(tr.getSkillId()!=null){
//   					  skillId=tr.getSkillId();
//   					  skill=skillRepository.findOne(skillId);
//   				 }
//   				 if(tr.getSecondarySkillId()!=null){
//   					 secondarySkillId=tr.getSecondarySkillId();
//   					 secondarySkill=skillRepository.findOne(secondarySkillId);
//   				 }
////   				 Integer accountId=tr.getAccountId();
////   				 Account account=accountController.getAccount(accountId);
//   				 HSSFRow row = sheet.createRow((short)counter);
//   				 if(tr.getTreqId()!=null){
//   					 row.createCell(0).setCellValue(tr.getTreqId());
//   				 }
//   				 row.createCell(1).setCellValue(skill.getSkillName());
//   				 if(secondarySkill!=null){
//   					row.createCell(2).setCellValue(secondarySkill.getSkillName());
//   				 }
//   			     if(tr.getPriority()!=null){
//   			    	 row.createCell(3).setCellValue(tr.getPriority());
//   			     }
//   		         if(tr.getRequisitionType()!=null){
//   		        	 row.createCell(4).setCellValue(tr.getRequisitionType());
//   		         }
//   	             //row.createCell(5).setCellValue(account.getAccountShortName());
//   		         if(tr.getCountry()!=null){
//   		        	 row.createCell(6).setCellValue(tr.getCountry());
//   		         }
//   		         if(tr.getComments()!=null){
//   		        	row.createCell(7).setCellValue(tr.getComments());
//   		         }
//   		         if(tr.getCreatedBy()!=null){
//   		        	 row.createCell(8).setCellValue(tr.getCreatedBy());
//   		         }
//   		         if(tr.getCreatedDate()!=null){
//   		        	 row.createCell(9).setCellValue(df.format(tr.getCreatedDate()));
//   		         }
//   		         if(tr.getLocation()!=null){
//   		        	 row.createCell(10).setCellValue(tr.getLocation());
//   		         }
//   		         if(tr.getProjectName()!=null){
//   		        	row.createCell(11).setCellValue(tr.getProjectName());
//   		         }
//   		         if(tr.getStatus()!=null){
//   		        	 row.createCell(12).setCellValue(tr.getStatus());
//   		         }
//   		        
//   		         if(tr.getSowDetail()!=null)
//   		         {
//   		        	 if(tr.getSowDetail().getAssociateLevelId()!=null){
//   		        		  grade=gradeRepository.findOne(tr.getSowDetail().getAssociateLevelId());
//   		        		  gradeId=grade.getGradeId();
//   						  band=bandRepository.findOne(gradeId);
//   						  if(band!=null){
//   							  row.createCell(19).setCellValue(band.getBand());
//   						  }
//   						  if(grade!=null){
//   							  row.createCell(20).setCellValue(grade.getGrade());
//   						  }
//   		        	 }
//   					 Boolean billable=tr.getSowDetail().getIsBillable();
//   					 if(billable)
//   					 {
//   						 billingType="Billable";
//   					 }
//   					 
//   					 Integer roleId=tr.getSowDetail().getRoleId();
//   					 AmgRoles amgRoles =amgRolesRepository.findOne(roleId);
//   					 if(tr.getSowDetail().getCityId()!=null){
//   						 Integer cityId=tr.getSowDetail().getCityId();
//   						 City city=cityRepository.findOne(cityId);
//   						 row.createCell(21).setCellValue(city.getCityName());
//   					 }
//   					 if(tr.getSowDetail().getUnitId()!=null){
//   						 Integer unitId=tr.getSowDetail().getUnitId();
//   						 Unit unit=unitRepository.findOne(unitId);
//   						 row.createCell(18).setCellValue(unit.getUnitName());
//   					 }
//   					 
//   					 BigDecimal billableRate=tr.getSowDetail().getBillableRate();
//   					 double doublebillableRate=billableRate.doubleValue();
//   		        	 row.createCell(13).setCellValue(amgRoles.getAmgRoleName());
//   		    		 row.createCell(14).setCellValue(df.format(tr.getSowDetail().getSowRoleStartDate()));
//   		    		 row.createCell(15).setCellValue(df.format(tr.getSowDetail().getSowRoleEndDate()));
//   			         row.createCell(16).setCellValue(doublebillableRate);
//   			         row.createCell(17).setCellValue(billingType);
//   		         }
//   		         else{
//   		        	
//   		        	 if(tr.getCmsDetail()!=null){
//   		        		  grade=gradeRepository.findOne(tr.getCmsDetail().getAssociateLevelId());
//   						  gradeId=grade.getGradeId();
//   						  band=bandRepository.findOne(gradeId);
//   		        		 Boolean billable=tr.getCmsDetail().getIsBillable();
//   						 if(billable)
//   						 {
//   							 billingType="Billable";
//   						 }
//   			        	 row.createCell(14).setCellValue(df.format(tr.getCmsDetail().getSowRoleStartDate()));
//   				         row.createCell(15).setCellValue(df.format(tr.getCmsDetail().getSowRoleEndDate()));
//   						 Integer roleId=tr.getCmsDetail().getRoleId();
//   						 AmgRoles amgRoles =amgRolesRepository.findOne(roleId);
//   			        	 row.createCell(13).setCellValue(amgRoles.getAmgRoleName());
//   			        	 BigDecimal billableRate=tr.getCmsDetail().getBillableRate();
//   						 double doublebillableRate=billableRate.doubleValue();
//   						 row.createCell(16).setCellValue(doublebillableRate);
//   				         row.createCell(17).setCellValue(billingType);
//   				         if(tr.getCmsDetail().getCityId()!=null){
//   				        	 Integer cityId=tr.getCmsDetail().getCityId();
//   							 City city=cityRepository.findOne(cityId);
//   					         row.createCell(21).setCellValue(city.getCityName());
//   				         }
//   						 if(tr.getCmsDetail().getUnitId()!=null){
//   							 Integer unitId=tr.getCmsDetail().getUnitId();
//   							 Unit unit=unitRepository.findOne(unitId);
//   							 row.createCell(18).setCellValue(unit.getUnitName());
//   						 }
//   						 if(band!=null){
//   							 row.createCell(19).setCellValue(band.getBand());
//   						 }
//   						 if(grade!=null){
//   							 row.createCell(20).setCellValue(grade.getGrade());
//   						 }
//   		        	 }
//   		         }
//   		         row.createCell(22).setCellValue(tr.getJobDescription());
//   		         stream = new FileOutputStream(outputFile);
//				 workbook.write(stream);
//				 counter++;
//		         }
//		         
//			 }
//    			}
//    			finally {
//    				if(stream!=null){
//    					stream.close();
//    				}
//					
//				}
//    	 }
//		}
//         return treqList;
//		}


//	private void createRow(HSSFRow rowhead) {
//		rowhead.createCell(0).setCellValue("Treq No");
//        rowhead.createCell(1).setCellValue("Primary Skill");
//        rowhead.createCell(2).setCellValue("Secondary Skill");
//        rowhead.createCell(3).setCellValue("Priority");
//        rowhead.createCell(4).setCellValue("RequisitionType");
//        rowhead.createCell(5).setCellValue("AccountName");
//        rowhead.createCell(6).setCellValue("Country");
//        rowhead.createCell(7).setCellValue("Comments");
//        rowhead.createCell(8).setCellValue("Created By/Hiring Manager");
//        rowhead.createCell(9).setCellValue("Created Date");
//        rowhead.createCell(10).setCellValue("Location");
//        rowhead.createCell(11).setCellValue("ProjectName");
//        rowhead.createCell(12).setCellValue("Status");
//        rowhead.createCell(13).setCellValue("Infocepts Role");
//        rowhead.createCell(14).setCellValue("Role Start Date");
//        rowhead.createCell(15).setCellValue("Role End Date");
//        rowhead.createCell(16).setCellValue("Billable Rate");
//        rowhead.createCell(17).setCellValue("Billing Type");
//        rowhead.createCell(18).setCellValue("Unit");
//        rowhead.createCell(19).setCellValue("Band");
//        rowhead.createCell(20).setCellValue("Grade");
//        rowhead.createCell(21).setCellValue("City");
//        rowhead.createCell(22).setCellValue("Job Description");
//		
//	}
}




