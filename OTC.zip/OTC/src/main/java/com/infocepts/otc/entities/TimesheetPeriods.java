package com.infocepts.otc.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.SqlResultSetMappings;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.infocepts.otc.utilities.LoadConstant;


@Entity
@Table(catalog = LoadConstant.otc, schema = "[dbo]", name = "tsperiod")
@SqlResultSetMappings({ 
	@SqlResultSetMapping( //get_periods_for_month1
			name = "get_periods_for_month1", 
			classes = {
				@ConstructorResult(
						
					targetClass = TimesheetPeriods.class, 
					columns = { 
						@ColumnResult(name = "periodId"),
						@ColumnResult(name = "otcString",type = String.class) 			
					}
				) 
			}
	),
	@SqlResultSetMapping( //get_periods_for_year
			name = "get_periods_for_year", 
			classes = {
				@ConstructorResult(
						targetClass = TimesheetPeriods.class, 
						columns = { 
								@ColumnResult(name = "periodId"),
								@ColumnResult(name = "periodStart", type = Date.class),
								@ColumnResult(name = "periodEnd", type = Date.class),
								@ColumnResult(name = "month", type = String.class),
								@ColumnResult(name = "year", type = String.class), 
								@ColumnResult(name = "locked", type = boolean.class) 
						}
				) 
			}
	
	)
})

@NamedNativeQueries({ 
	
	@NamedNativeQuery( //getPeriodsForMonth//used in GTPWSR week filter
			
			name = "getPeriodsForMonth", 
			query = "SELECT "+
						 " per.period_id as periodId,"+
						 "per.period_start as periodStart ,per.period_end as periodEnd , month(per.period_start) as month, year(per.period_start) as year,per.locked"+
					 " FROM " + LoadConstant.otc + ".[dbo].[tsperiod] per  "+
					 " WHERE "+
						 " MONTH(per.period_start) = :month "+
						 " AND "+
						 " YEAR(per.period_start) = :year "+
						 " AND "+
						 " MONTH(per.period_end) = :month "+
						 " AND YEAR(per.period_end) = :year"+
						 " ORDER BY per.period_start",
					resultClass = TimesheetPeriods.class, 
					resultSetMapping = "get_periods_for_year"
	
	),
	@NamedNativeQuery( //getPeriodsForYear
			
			name = "getPeriodsForYear", 
			query = "SELECT "+
						 " per.period_id as periodId,"+
						 " per.period_start as periodStart,"+
						 " per.period_end as periodEnd,"+
						 " YEAR(per.period_start) as year,"+ 
						 " Format(per.period_start,'MMM') as month,"+ 
						 " per.locked as locked"+ 
					 " FROM "+
					 LoadConstant.otc + ".[dbo].[TSPERIOD] per"+
					 " WHERE" +
						 " YEAR(per.period_start) = :year"+
						 " AND "+
						 " YEAR(per.period_end) = :year "+
					 " ORDER BY per.period_start desc ", 
					resultClass = TimesheetPeriods.class, 
					resultSetMapping = "get_periods_for_year"

	) 
})

public class TimesheetPeriods {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="PERIOD_ID")
	private Integer periodId;
	
	@Column(name="PERIOD_START")
	private Date periodStart;
	
	@Column(name="PERIOD_END")
	private Date periodEnd;
	
	private boolean locked;

	@Transient
	private String month; // Added for displaying in UI

	@Transient
	private String year; // Added for displaying in UI

	@Transient
	private String otcString;

	public Integer getPeriodId() {
		return periodId;
	}

	public Date getPeriodStart() {		
		return periodStart;
	}

	public Date getPeriodEnd() {
		return periodEnd;
	}

	public boolean isLocked() {
		return locked;
	}
	

	public String getOtcString() {
		return otcString;
	}

	public void setOtcString(String otcString) {
		this.otcString = otcString;
	}
	
	public String getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month = month;
	}

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}
	//End of: Getter and Setter

	//Constructor(s)
	public TimesheetPeriods() {
			
	}
	
	public TimesheetPeriods(Integer periodId, String otcString) {
		this.periodId = periodId;
		this.otcString = otcString;

	}
	
	//Constructor for fetching periods by Year
	public TimesheetPeriods(Integer periodId, Date periodStart,Date periodEnd,String month,String year, boolean locked) {
		this.periodId = periodId;
		this.periodStart = periodStart;
		this.periodEnd = periodEnd;
		this.month = month;
		this.year = year;
		this.locked = locked;
	}
	
}
