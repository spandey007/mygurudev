/**
* Filename: /src/main/java/com/infocepts/otc/controllers/GtpSrController.java
* @author  AA
* @version 1.0
* @since   2019-08-30
*/

package com.infocepts.otc.controllers;
import java.util.logging.Level;
import java.util.logging.Logger;
import com.infocepts.otc.entities.GtpSr;
import com.infocepts.otc.repositories.GtpSrRepository;
import com.infocepts.otc.services.TimesheetService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import javax.mail.MessagingException;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.List;

@RestController
@RequestMapping(value = "/gtpSr", headers = "referer")
public class GtpSrController {

	final Logger logger = Logger.getLogger(GtpSrController.class.getName());

	@Autowired
	GtpSrRepository repository;

	@Autowired
	HttpSession session;

	@PersistenceContext(unitName = "otc")
	private EntityManager manager;

	@Autowired
	TimesheetService service;

	
	@RequestMapping(method = RequestMethod.POST)
	public GtpSr addGtpSr(@RequestBody GtpSr gtpSr, HttpServletRequest request) throws MessagingException {
		
		try {
			gtpSr.setGtpSrId(null);
			repository.save(gtpSr);
		} catch (Exception e) {
			e.printStackTrace();
			logger.info(String.format("exception - ", e));
		}
		
		{
			service.sendTamperedMail("GtpSr Save", 0, 0, request);
		}

		return gtpSr;
	}

	
	@RequestMapping(value = "/{gtpSrId}", method = RequestMethod.PUT)
	public GtpSr updateGtpSr(@RequestBody GtpSr updatedGtpSr, @PathVariable Integer gtpSrId, HttpServletRequest request)
			throws MessagingException {
		
		try {
			updatedGtpSr.setGtpSrId(gtpSrId);
			repository.save(updatedGtpSr);
		} catch (Exception e) {
			e.printStackTrace();
			logger.info(String.format("exception - ", e));
		}
		
		{
			service.sendTamperedMail("GtpSr Save", 0, 0, request);
		}
		return updatedGtpSr;
	}

	// to display for current associate
	@GetMapping("/getListByUid")
	public Object getListByUid(@RequestParam(value = "filterMyList", defaultValue = "0") Integer filterMyList,
			@RequestParam(value = "monthStartDate", defaultValue = "") String monthStartDate,
			@RequestParam(value = "monthEndDate", defaultValue = "") String monthEndDate,
			
			HttpServletRequest request) {
		List<GtpSr> gtpSrList = null;
		Integer loggedInUid = (Integer) session.getAttribute("loggedInUid");
		try {
			if (filterMyList == 1) {
				gtpSrList = manager.createNamedQuery("getGtpSrForaMonthByAssociate", GtpSr.class)
						.setParameter("uid", loggedInUid)
						.setParameter("monthStartDate", monthStartDate)
						.setParameter("monthEndDate", monthEndDate)
						.getResultList();
			}
		} catch (Exception e) {
			logger.log(Level.SEVERE, "exceptn msg", e);
		}
		return gtpSrList;
	} 
	
	// To display for project
	@GetMapping("/getListByProject")
	public Object getListByProject(@RequestParam(value = "projectId", defaultValue = "0") Integer projectId,
			@RequestParam(value = "monthStartDate", defaultValue = "") String monthStartDate,
			@RequestParam(value = "monthEndDate", defaultValue = "") String monthEndDate,
			HttpServletRequest request) {
		List<GtpSr> gtpSrList = null;

		try {
			if (projectId != 0) {
				gtpSrList = manager.createNamedQuery("getGtpSrForaMonthByProject", GtpSr.class)
						.setParameter("projectId", projectId)
						.setParameter("monthStartDate", monthStartDate)
						.setParameter("monthEndDate", monthEndDate)
						.getResultList();
			}
		} catch (Exception e) {
			logger.log(Level.SEVERE, "exceptn msg", e);
		}
		return gtpSrList;
	}

	// To display all gtpSrby month
	@GetMapping("/getListAllGtpSr")
	public Object getListAllGtpSr(@RequestParam(value = "monthStartDate", defaultValue = "") String monthStartDate,
			@RequestParam(value = "monthEndDate", defaultValue = "") String monthEndDate,
			HttpServletRequest request) {
		List<GtpSr> gtpSrList = null;

		try {
			if (monthStartDate != "") {
				gtpSrList = manager.createNamedQuery("getGtpSrForaMonth", GtpSr.class)
						.setParameter("monthStartDate", monthStartDate)
						.setParameter("monthEndDate", monthEndDate)
						.getResultList();
			}
		} catch (Exception e) {
			logger.log(Level.SEVERE, "exceptn msg", e);
		}
		return gtpSrList;
	}
	
	// To display all gtpSr
		@GetMapping("/getAllGtpSr")
		public Object getAllGtpSr( HttpServletRequest request) {
			
			List<GtpSr> gtpSrList = null;	
			try{
					gtpSrList = manager.createNamedQuery("GtpSrQuery", GtpSr.class)
							.getResultList();
			 }catch(Exception e){
		        	logger.info(String.format("error in fetching list - ", e.getMessage()));
					e.printStackTrace();
		        }
			return gtpSrList;
		}

	@RequestMapping(value = "/{gtpSrId}", method = RequestMethod.GET)
	public GtpSr getGtpSr(@PathVariable Integer gtpSrId, HttpServletRequest request) throws MessagingException {

		GtpSr gtpSr = null;
		
		gtpSr = manager.createNamedQuery("GtpSrQueryBygtpSrId", GtpSr.class).setParameter("gtpSrId", gtpSrId)
				.getSingleResult();

		
		service.sendTamperedMail("GtpSr Get", 0, 0, request);
		

		return gtpSr;
	}
}
