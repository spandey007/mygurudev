package com.infocepts.otc.controllers;

import java.util.List;

import javax.mail.MessagingException;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.infocepts.otc.entities.AccountPlanning;
import com.infocepts.otc.repositories.AccountPlanningRepository;
import com.infocepts.otc.services.TimesheetService;

@RestController
@RequestMapping(value="/accountplanning",headers="referer")
public class AccountPlanningController {

	@Autowired
	AccountPlanningRepository repository;
	
	@Autowired
	TimesheetService service;
	
	@PersistenceContext(unitName="otc")
    private EntityManager manager;

	final Logger logger = Logger.getLogger(AccountPlanningController.class);
	
	@RequestMapping(method=RequestMethod.GET)
	public List<AccountPlanning> getAccountplanning(@RequestParam(name="accountId", defaultValue="0") Integer accountId,
				@RequestParam(name="cepId", defaultValue="0") Integer cepId,
				@RequestParam(name="phId", defaultValue="0") Integer phId,
				//@RequestParam(value = "month", defaultValue = "0") Integer month,
				@RequestParam(value = "year", defaultValue = "0") Integer year){
		List<AccountPlanning> AccountPlanningList=null;
		System.out.println(AccountPlanningList);
	try{
		
		if(year != 0 )
		{
			AccountPlanningList = manager.createNamedQuery("getAccountPlanning", AccountPlanning.class)
					.setParameter("accountId", accountId)
					.setParameter("cepId", cepId)
					.setParameter("phId", phId)
					.setParameter("year", year)
	                .getResultList();
		}

	}catch(Exception e){
		 logger.error(e);
	 }
		return AccountPlanningList;
	}
	
	
	
}
