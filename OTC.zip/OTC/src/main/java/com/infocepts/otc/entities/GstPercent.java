package com.infocepts.otc.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.infocepts.otc.utilities.LoadConstant;

@Entity
@Table(catalog=LoadConstant.otc, schema="[dbo]",name="gstPercent")
public class GstPercent {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer gstPercentId;
	private String title;
	private Integer gstPercent;
	public Integer getGstPercentId() {
		return gstPercentId;
	}
	public void setGstPercentId(Integer gstPercentId) {
		this.gstPercentId = gstPercentId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public Integer getGstPercent() {
		return gstPercent;
	}
	public void setGstPercent(Integer gstPercent) {
		this.gstPercent = gstPercent;
	}
	
	
	
}
