package com.infocepts.otc.controllers;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Comparator;
import java.util.List;
import java.util.logging.Logger;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.io.IOUtils;
import org.apache.tomcat.util.http.fileupload.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.infocepts.otc.entities.InvoiceInfo;
import com.infocepts.otc.entities.Invoices;
import com.infocepts.otc.entities.InvoicesDetail;
import com.infocepts.otc.entities.Project;
import com.infocepts.otc.repositories.InvoiceInfoRepository;
import com.infocepts.otc.repositories.InvoicesDetailRepository;
import com.infocepts.otc.repositories.InvoicesRepository;
import com.infocepts.otc.repositories.ProjectRepository;
import com.infocepts.otc.services.TimesheetService;
import com.infocepts.otc.utilities.ExportUtil;
import com.infocepts.otc.utilities.ZipCreator;


@RestController
@RequestMapping(value="/invoicesdetail")
public class InvoicesDetailController {

	@Autowired
	InvoicesDetailRepository repository;
	
	@PersistenceContext
    private EntityManager manager;
	
	@Autowired
	ExportUtil exportUtil;
	
	@Autowired
	TimesheetService service;
	
	@Autowired
	InvoicesRepository invoicesRepository;
	
	@Autowired
	public InvoiceInfoRepository invoiceInfoRepository;
	
	@Autowired
	public ProjectRepository projectRepository;
	
	@Autowired
	HttpSession session;
	final Logger logger = Logger.getLogger(InvoicesDetailController.class.getName());
	
    @RequestMapping(method=RequestMethod.POST)
	public InvoicesDetail addInvoicesDetail(@RequestBody InvoicesDetail invoicesdetail)
	{
		try{
			invoicesdetail.setInvoiceDetailId(null);
			repository.save(invoicesdetail);
		}catch(Exception e){
			logger.info(e.getMessage()); 
			//logger.error(e);
		}
		return invoicesdetail;
	}	
 
    @RequestMapping(method=RequestMethod.GET)
	 public List<InvoicesDetail> getInvoiceDetail(@RequestParam(value = "invoiceId",defaultValue = "0") Integer invoiceId,
			 							@RequestParam(value = "projectId", defaultValue = "") Integer projectId,
			 							@RequestParam(value = "monthstartDate", defaultValue = "") String monthstartDate,
			 							@RequestParam(value = "monthEndDate", defaultValue = "") String monthEndDate,			 							
			 							@RequestParam(value = "checkIfPresent", defaultValue = "0")Integer checkIfPresent,
			 							@RequestParam(value = "mile", defaultValue = "0")Integer mile,
			 							@RequestParam(value = "fetchWeeklyHrs", defaultValue = "false")Boolean fetchWeeklyHrs,
										HttpServletRequest request){
		 List<InvoicesDetail> invoiceDetail = null;
		 try{
			 
				 if(invoiceId != 0)
				 {
					 if(fetchWeeklyHrs){
						 invoiceDetail =  manager.createNamedQuery("invoices_weekly_billable_hours_for_an_invoice",InvoicesDetail.class)
								 .setParameter("invoiceId", invoiceId)
								 .setParameter("monthstartDate", monthstartDate)
								 .setParameter("monthEndDate", monthEndDate)
								 .setParameter("projectId", projectId)
				 				.getResultList();
					 }else{
						 invoiceDetail =  manager.createNamedQuery("invoices_detail_query_edit",InvoicesDetail.class)
								 .setParameter("invoiceId", invoiceId)
				 				.getResultList();
					 }
					 
					 
				 }
				 else if(checkIfPresent == 1 && projectId != 0)
				 {
					 //Integer month = service.getMonth(monthstartDate);
					 //Integer year = service.getYear(monthstartDate);
					 invoiceDetail =  manager.createNamedQuery("invoices_detail_already_present",InvoicesDetail.class)
							 .setParameter("projectId", projectId)
							 .setParameter("monthstartDate", monthstartDate)
							 .setParameter("monthEndDate", monthEndDate)
			 				 .getResultList();
				 }
				 else if(mile == 1){
					 invoiceDetail =  manager.createNamedQuery("invoices_detail_query_milestone_add",InvoicesDetail.class)
							 	.setParameter("projectId", projectId)
				 				.getResultList();
				 }else
				 {
					 invoiceDetail =  manager.createNamedQuery("invoices_detail_query_add",InvoicesDetail.class)
						 	.setParameter("projectId", projectId)
							.setParameter("monthstartDate", monthstartDate)
							.setParameter("monthEndDate", monthEndDate)
			 				.getResultList();
				 }
			 
		 }
		 catch(Exception e){
			 logger.info(e.getMessage()); 
		 }
		 return invoiceDetail;
	 }
	 
		@RequestMapping(value="/download/{invoiceId}",method=RequestMethod.GET)
		public void downloadFile(@PathVariable(value = "invoiceId") Integer invoiceId, HttpServletResponse response) throws ServletException, Exception {		    
			Boolean isAValidCall = false;
			Integer uid=(Integer)session.getAttribute("loggedInUid");
			isAValidCall = service.isAValidTimesheetCall(uid);	
			if(invoiceId!=null){
				Invoices invoices = invoicesRepository.findOne(invoiceId);
				String Filepath = invoices.getFilePath();
				File outputFile = new File(Filepath);
				if(isAValidCall == true){			
					Path file = Paths.get(outputFile+"");
			        response.setContentType("application/msword");
			        response.addHeader("Content-Disposition", "attachment; filename="+file.getFileName());
			        Files.copy(file, response.getOutputStream());
			        response.getOutputStream().flush();
				}	
			}
		}
		
		@RequestMapping(value="/bulk/download/{year}/{month}/{invoiceType}",method=RequestMethod.GET)
		public void downloadBulk(@PathVariable(value = "year") Integer year,
				@PathVariable(value = "month") Integer month,
				@PathVariable(value = "invoiceType") String invoiceType,
									HttpServletRequest request,
									HttpServletResponse response) throws ServletException, Exception {
			Boolean isAValidCall = false;String path=null;
			File zipFile = null;
			Integer uid=(Integer)session.getAttribute("loggedInUid");
			isAValidCall = service.isAValidTimesheetCall(uid);
			if(isAValidCall == true){			
				
			File home=exportUtil.checkPath(request);
			path=home.getPath();
			String separator=File.separator;
			
			if (home.exists() && home.isDirectory()) {
				 logger.info("home is a directory");
				 if(path.equals(separator)){
					 path="usr" + File.separator + "home"+ File.separator +"Download";
				 }
				 else{
					 path=File.separator+"usr" + File.separator + "home"+ File.separator +"Download";
				 }
				  
					if (Files.isDirectory(Paths.get(home + path))) {
						path=home.getPath();
						if(path.equals(separator)){
							path="usr" + File.separator + "home"+ File.separator +"Download"+ File.separator +"invoices"+ File.separator + year+ File.separator + month + File.separator + invoiceType;
						}
						else{
							path=File.separator+"usr" + File.separator + "home"+ File.separator +"Download"+ File.separator +"invoices"+ File.separator + year+ File.separator + month + File.separator + invoiceType;
						}
						if (Files.isDirectory(Paths.get(home + path))) {
							path=home.getPath();
							if(path.equals(separator)){
								path= "usr" + File.separator + "home"+ File.separator +"Download"+ File.separator +"invoices"+ File.separator + year+ File.separator + month+ File.separator + invoiceType + File.separator + invoiceType;
							}
							else{
								path=File.separator+ "usr" + File.separator + "home"+ File.separator +"Download"+ File.separator +"invoices"+ File.separator + year+ File.separator + month+ File.separator + invoiceType + File.separator + invoiceType;
							}
							zipFile = new File(home +path + ".zip");
							logger.info("zipFile created");
						} 
					}
				
			}
			String Filepath = home + File.separator+"usr" + File.separator + "home"+ File.separator+ "Download" + File.separator +"invoices" + File.separator + year + File.separator + month + File.separator + invoiceType;
			String SOURCE_FOLDER   = Filepath;
			if(zipFile.exists()){
				logger.info("File Already exists hence deleting it and creating a new one");
				System.gc();
		        Thread.sleep(2000);//This part gives the Bufferedreaders and the InputStreams time to close Completely
		        FileUtils.forceDelete(zipFile);
			}
			ZipCreator appZip = new ZipCreator();	 
			List<String> fileList =  appZip.generateFileList(new File(SOURCE_FOLDER),SOURCE_FOLDER);
			
			try {
		 		// create byte buffer
		 		byte[] buffer = new byte[1024];
		 		FileOutputStream fos = new FileOutputStream(zipFile);
		 		ZipOutputStream zos = new ZipOutputStream(fos);
				for(String file : fileList){
					FileInputStream fis = new FileInputStream(SOURCE_FOLDER + File.separator + file);
			 		// begin writing a new ZIP entry, positions the stream to the start of the entry data
			 		zos.putNextEntry(new ZipEntry(file));
			 		int length;
			 		while ((length = fis.read(buffer)) > 0) {
			 			zos.write(buffer, 0, length);
			 		}
			 		zos.closeEntry();
			 		// close the InputStream
			 		fis.close();
			 		logger.info("file written to zip file");
				}
				zos.close();
				logger.info("zipFile "+zipFile); 
	            response.setHeader("Content-Length", String.valueOf(zipFile.length()));
	            response.setContentType("application/zip");
	            response.setHeader("Content-Disposition", "attachment; filename=\"" + zipFile);
	            InputStream is = new FileInputStream(zipFile);
	            FileCopyUtils.copy(IOUtils.toByteArray(is), response.getOutputStream());
	            response.flushBuffer();
	 	}
	 	catch (IOException ioe) {
	 		logger.info("Error creating zip file" + ioe);
	 	}
	}
	}
	 
		@RequestMapping(value="/download",method=RequestMethod.PUT)
		public void download(@RequestBody Invoices invoice,HttpServletRequest request) throws ServletException, Exception {
			Boolean isAValidCall = false;
			Integer uid=(Integer)session.getAttribute("loggedInUid");
			isAValidCall = service.isAValidTimesheetCall(uid);	
			InvoiceInfo invoiceInfo=null;
			String billing = null;
			BigDecimal exchangeRate = BigDecimal.ZERO;
	       	Project project;
	       	Integer unitID = null;
			if(invoice.getExchangeRate() != null)
			{
				exchangeRate = invoice.getExchangeRate();
			}
			if(isAValidCall == true)
			{
	         try{
				if(invoice.getProjectId() != null){
					invoiceInfo  = invoiceInfoRepository.findByProjectId(invoice.getProjectId());
				}

	 			List<InvoicesDetail> invoicesDetails = repository.findByInvoicesId(invoice.getInvoiceId());
	 			
	 			if(invoiceInfo!=null) {
		 			if(invoiceInfo.getOnsiteOffShoreSplit()!=null) {
			 			invoicesDetails.sort(Comparator.comparingInt(InvoicesDetail::getCountryId));
			 			//invoicesDetails.stream().map(InvoicesDetail::getCountryId).forEach(System.out::println);
		 			}	 				
	 			}
	 			
	        	if(invoice.getBillingType() != null){
		        	 billing = invoice.getBillingType();
	        	 }
	        	 
	        	 if(invoice.getProjectId()!=null){
	        		 project = projectRepository.findOne(invoice.getProjectId());
	        		 if(project!=null){
	        			 unitID = project.getBillingUnitId();
	        		 }
	        		 }
	        	 if(unitID==1 || unitID==4  || unitID==21  || unitID==22){
	        		 // same template for expense and Inter-unit module
	        		 if(invoice.getInvoiceType().equals("Expense Invoice") || invoice.getInvoiceType().equals("Inter-Unit Invoice")){
						 exportUtil.createInvoiceWord("invoices/print/ITPL/Expenses/EXPITPL",invoice,invoicesDetails,request);  
					 }else{
		        			 if(billing.equals("Fixed Bid Milestone")){
						        	 exportUtil.createInvoiceWord("invoices/print/ITPL/FB/FBITPL",invoice,invoicesDetails,request);
		        			 }else{
			        				 exportUtil.createInvoiceWord("invoices/print/ITPL/TM/TMITPL",invoice,invoicesDetails,request);
		        			 }
					 }
	        	 }else if(unitID==2){
					 if(invoice.getInvoiceType().equals("Expense Invoice")){
						 exportUtil.createInvoiceWord("invoices/print/PTE/Expenses/EXPPTE",invoice,invoicesDetails,request);  
					 }else{
						 if(billing.equals("Fixed Bid Milestone")){
			        		 exportUtil.createInvoiceWord("invoices/print/PTE/FB/FBPTE",invoice,invoicesDetails,request);
						 }else{ 
							 exportUtil.createInvoiceWord("invoices/print/PTE/TM/TMPTE",invoice,invoicesDetails,request); 	 						 
						 }
					 }
	        	 }else if(unitID==3){
					 if(invoice.getInvoiceType().equals("Expense Invoice")){
						 exportUtil.createInvoiceWord("invoices/print/LLC/Expenses/EXPLLC",invoice,invoicesDetails,request);  
					 }else{	 
					 if(billing.equals("Fixed Bid Milestone")){
		        		 exportUtil.createInvoiceWord("invoices/print/LLC/FB/FBLLC",invoice,invoicesDetails,request);
					 	}else{
					 		if(invoiceInfo!=null) {
					 			/* onsite and offshore template check*/
					 			if(invoiceInfo.getOnsiteOffShoreSplit()!=null && invoiceInfo.getOnsiteOffShoreSplit()==true) {
									 exportUtil.createInvoiceWord("invoices/print/LLC/FBM/FBMLLC",invoice,invoicesDetails,request); 					 			
						 		}else if(invoiceInfo.getHideTimesheet()!=null && invoiceInfo.getHideTimesheet()==true){
						 			/* - hide timesheet detail - replace associate */
									 exportUtil.createInvoiceWord("invoices/print/LLC/TM/HTSTMLLC",invoice,invoicesDetails,request); 					 			
						 		}else{
									 exportUtil.createInvoiceWord("invoices/print/LLC/TM/TMLLC",invoice,invoicesDetails,request); 					 			
						 		}	
					 		}else {
								 exportUtil.createInvoiceWord("invoices/print/LLC/TM/TMLLC",invoice,invoicesDetails,request); 					 								 			
					 		}
					 		
						 
					 	}
					 }
	        	 }
	         	}
				 catch(Exception e){
					 logger.info(e.getMessage()); 
				 }
			}
			}
     @RequestMapping(value="/{invoiceDetailId}",method=RequestMethod.PUT)
		 public InvoicesDetail updateInvoicesDetail(@RequestBody InvoicesDetail updatedinvoicesdetail,@PathVariable Integer invoiceDetailId){
			 try{
				 updatedinvoicesdetail.setInvoiceDetailId(invoiceDetailId); 
				 repository.save(updatedinvoicesdetail);
			 }
			 catch(Exception e){
				 logger.info(e.getMessage()); 
			 }
			 return updatedinvoicesdetail;
		 }

		 
	 @RequestMapping(value="/{invoiceDetailId}",method=RequestMethod.DELETE)
	 public void deleteInvoicesDetail(@PathVariable Integer invoiceDetailId){
		 try{
			 repository.delete(invoiceDetailId);
		 }
		 catch(Exception e){
			 logger.info(e.getMessage()); 
		 }
	 }	 
}
