package com.infocepts.otc.controllers;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.infocepts.otc.entities.TimesheetNonwork;
import com.infocepts.otc.repositories.TimesheetNonworkRepository;


@RestController
@RequestMapping(value="/tsnonwork",headers="referer")//JV: Added 'headers' param to validate the url.
public class TimesheetNonworkController {
	
	final Logger logger = Logger.getLogger(TimesheetNonworkController.class);
	
	@Autowired
	TimesheetNonworkRepository repository;
	
	@RequestMapping(method=RequestMethod.GET)
	public List<TimesheetNonwork> getNonwork(@RequestParam(value = "isEnabled", defaultValue = "1") Boolean isEnabled){
		List<TimesheetNonwork> tsnonworklist=null;
		try{
			if(isEnabled)
			{
				tsnonworklist=repository.findByIsEnabled(isEnabled);
			}
			else
			{
				tsnonworklist=repository.findAll();
			}
		}catch(Exception e){
			logger.error(e);
		}
		return tsnonworklist;
	}
	
    @RequestMapping(method=RequestMethod.POST)
	public TimesheetNonwork addNonwork(@RequestBody TimesheetNonwork tsnonwork){
    	try{
    		repository.save(tsnonwork);
		}
		catch(Exception e){
			logger.error(e);
		}
		return tsnonwork;
	}
    
    @RequestMapping(value="/{tsnonworkId}",method=RequestMethod.PUT)
	public TimesheetNonwork updateNonwork(@PathVariable Integer tsnonworkId,@RequestBody TimesheetNonwork updatedNonwork){
    	try{
    		updatedNonwork.setTsnonworkId(tsnonworkId);
    		repository.save(updatedNonwork);
		}
		catch(Exception e){
			logger.error(e);
		}
    	return updatedNonwork;
	}
	
	@RequestMapping(value="/{tsnonworkId}",method=RequestMethod.DELETE)
	public void deleteNonwork(@PathVariable Integer tsnonworkId){
		try{
			repository.delete(tsnonworkId);
		}
		catch(Exception e){
			logger.error(e);
		}
	}
    
}
