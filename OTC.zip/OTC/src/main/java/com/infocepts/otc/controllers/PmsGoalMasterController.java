/**
* Filename: /src/main/java/com/infocepts/otc/controllers/PmsGoalMasterController.java
* @author  SRA
* @version 1.0
* @since   2018-08-01 
*/

package com.infocepts.otc.controllers;

import java.util.logging.Logger;

import com.infocepts.pms.entities.PmsDepartmentMapping;
import com.infocepts.pms.entities.PmsGoalMaster;
import com.infocepts.pms.entities.PmsGradeMapping;
import com.infocepts.pms.repositories.PmsDepartmentMappingRepository;
import com.infocepts.pms.repositories.PmsGoalMasterRepository;
import com.infocepts.pms.repositories.PmsGradeMappingRepository;
import com.infocepts.otc.services.PmsService;
import com.infocepts.otc.services.TimesheetService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.mail.MessagingException;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import java.util.List;

@RestController
@RequestMapping(value="/api/pms/goalMaster", headers="referer")
public class PmsGoalMasterController {

    final Logger logger = Logger.getLogger(PmsGoalMasterController.class.getName());

    @Autowired
    PmsGoalMasterRepository repository;
    
    @Autowired
    HttpSession session;

    @PersistenceContext(unitName = "pms") 
    private EntityManager manager;
			
	@Autowired
	TimesheetService service;
	
	@Autowired
    PmsGradeMappingRepository gradeMappingRepository;
    
    @Autowired
    PmsDepartmentMappingRepository departmentMappingRepository;

	/**
   * This method is used to find results set from module entity
   * based on params passed from JS file
   */
    @RequestMapping(method = RequestMethod.GET)
    public List<PmsGoalMaster> findAllPmsGoalMaster(@RequestParam(value = "goalClusterId", defaultValue = "0") Integer goalClusterId,
    												@RequestParam(value = "byUserGradeAndDepartment", defaultValue = "false") Boolean byUserGradeAndDepartment
            						,HttpServletRequest request){
        List<PmsGoalMaster> pmsGoalMasterList = null;
        //Integer loggedInUid = (Integer) session.getAttribute("loggedInUid");
        
        try {
        	
        	Integer uid=(Integer)session.getAttribute("loggedInUid");
        	/* ------------------------- Authorization start ------------------------------------ */
        	// Authorization for all the associates hence no check
//			if(!service.isHRPms())
//			{
//				service.sendTamperedMail("PmsGoalMaster view all", 0, 0, request);
//				return pmsGoalMasterList;
//			}
			/* ------------------------- Authorization ends ------------------------------------ */
			
			if (goalClusterId != 0) {
				
				if(byUserGradeAndDepartment){
					pmsGoalMasterList = manager.createNamedQuery("getGoalMastersByClusterGradeDepartment", PmsGoalMaster.class) 
	        				.setParameter("goalClusterId", goalClusterId)
	        				.setParameter("uid", uid)
	                        .getResultList();
				}else{
					pmsGoalMasterList = manager.createNamedQuery("getGoalMastersByCluster", PmsGoalMaster.class) 
	        				.setParameter("goalClusterId", goalClusterId)
	                        .getResultList();
				}
        		
        					
        	} else {
	
        		pmsGoalMasterList = manager.createNamedQuery("getAllGoalMasters", PmsGoalMaster.class)   
                        .getResultList();
			}
			
         } 
		catch (Exception e){
			 logger.info(String.format("exception - ", e.getMessage()));
        }
        return pmsGoalMasterList;

    }
    
    /**
     * This method is add row in moduleName entity
     * 
     */
    @RequestMapping(method=RequestMethod.POST)
	public PmsGoalMaster addPmsGoalMaster(@RequestBody PmsGoalMaster pmsGoalMaster, HttpServletRequest request) throws MessagingException {
		// Authorization for XYZ role
		if(service.isHRPms() || service.isHRPmsAdmin())
		{
			List<PmsGradeMapping> gradeMapping = pmsGoalMaster.getGradeMapping();
			List<PmsDepartmentMapping> departmentMapping = pmsGoalMaster.getDepartmentMapping();
			
			try{
				pmsGoalMaster.setGoalMasterId(null);
				repository.save(pmsGoalMaster);
				
				//Save the mapping tables
				
				//Set the id in mapping list
				for (PmsGradeMapping pmsGradeMapping : gradeMapping) {
					pmsGradeMapping.setTypeId(pmsGoalMaster.getGoalMasterId());
				}
				
				gradeMappingRepository.save(gradeMapping);
				
				//Set the id in mapping list
				for (PmsDepartmentMapping pmsDepartmentMapping : departmentMapping) {
					pmsDepartmentMapping.setTypeId(pmsGoalMaster.getGoalMasterId());
				}
				
				departmentMappingRepository.save(departmentMapping);
			}
			catch(Exception e){
				 logger.info(String.format("exception - ",e.getMessage()));
			}
		}
		else 
		{
			service.sendTamperedMail("PmsGoalMaster Save", 0, 0, request);
		}
		
		return pmsGoalMaster;
	}
    
    /**
     * This method is update row in moduleName entity
     * based on primaryKey Of Module Table 
     */
    @RequestMapping(value="/{goalMasterId}",method=RequestMethod.PUT)
	 public PmsGoalMaster updatePmsGoalMaster(@RequestBody PmsGoalMaster updatedPmsGoalMaster,@PathVariable Integer goalMasterId,HttpServletRequest request) throws MessagingException{
        // Authorization for XYZ role
		if(service.isHRPms() || service.isHRPmsAdmin())
		{	
			List<PmsGradeMapping> gradeMapping = updatedPmsGoalMaster.getGradeMapping();
			List<PmsDepartmentMapping> departmentMapping = updatedPmsGoalMaster.getDepartmentMapping();
			
			try{
				 updatedPmsGoalMaster.setGoalMasterId(goalMasterId);
				 repository.save(updatedPmsGoalMaster);
				 
				//Delete the existing mapping
				gradeMappingRepository.deleteGradeMapping(goalMasterId, 3);
				
				gradeMappingRepository.save(gradeMapping);
				
				//Delete the existing mapping
				departmentMappingRepository.deleteDepartmentMapping(goalMasterId, 3);
				
				departmentMappingRepository.save(departmentMapping);
			}
			catch(Exception e){
				 logger.info(String.format("exception - ", e.getMessage()));
			}
		}
		else
		{
			service.sendTamperedMail("PmsGoalMaster Save", 0, 0, request);
		}
		 return updatedPmsGoalMaster;
	 }
    
    /**
     * This method is get data for specific row in moduleName entity
     * based on primaryKey Of Module Table 
     */
    @RequestMapping(value="/{goalMasterId}",method=RequestMethod.GET)
	 public PmsGoalMaster getPmsGoalMaster(@PathVariable Integer goalMasterId, HttpServletRequest request) throws MessagingException{
    	
    	PmsGoalMaster pmsGoalMaster = null;
		// Authorization for XYZ role
		if(service.isHRPms() || service.isHRPmsAdmin())
		{
			try{
				pmsGoalMaster = manager.createNamedQuery("getGoalMastersById", PmsGoalMaster.class)
						 .setParameter("goalMasterId", goalMasterId)
						 .getSingleResult();
				
				//Get Grade mapping
				 List<PmsGradeMapping> gradeMapping = gradeMappingRepository.findByTypeId(goalMasterId, 3);
				 
				 //Set Grade mapping
				 pmsGoalMaster.setGradeMapping(gradeMapping);
				 
				 //Get Department mapping
				 List<PmsDepartmentMapping> departmentMapping = departmentMappingRepository.findByTypeId(goalMasterId, 3);
				 
				 //Set Department mapping
				 pmsGoalMaster.setDepartmentMapping(departmentMapping);
			 }
			 catch(Exception e){
				 logger.info(String.format("exception - ", e.getMessage()));
			 }
		}
		else 
		{
			service.sendTamperedMail("PmsGoalMaster Get", 0, 0, request);
		}
		 
		 return pmsGoalMaster;
	 }
	 
    
    /**
     * This method is delete data for specific row in moduleName entity
     * based on primaryKey Of Module Table 
     */	 
	@RequestMapping(value="/{goalMasterId}",method=RequestMethod.DELETE)
	public void deletePmsGoalMaster(@PathVariable Integer goalMasterId, HttpServletRequest request)  throws MessagingException {
		// Authorization for XYZ role
		if(service.isHRPms() || service.isHRPmsAdmin())
		{
			try{
				 //Delete all grade and dep allocation rows first
				gradeMappingRepository.deleteGradeMapping(goalMasterId, 3);
				departmentMappingRepository.deleteDepartmentMapping(goalMasterId, 3);
				repository.delete(goalMasterId);
			}
			catch(Exception e){
				 logger.info(String.format("exception - ", e.getMessage()));
			}
		}
		else
		{
			service.sendTamperedMail("PmsGoalMaster Delete", 0, 0, request);
		}		 
	}
	
  
   
}
