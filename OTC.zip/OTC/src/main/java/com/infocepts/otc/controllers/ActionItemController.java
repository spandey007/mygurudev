
package com.infocepts.otc.controllers;

import java.util.ArrayList;
import java.util.List;

import javax.mail.MessagingException;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.infocepts.otc.entities.ActionItem;
import com.infocepts.otc.entities.Sow;
import com.infocepts.otc.repositories.ActionItemRepository;
import com.infocepts.otc.services.TimesheetService;



@RestController
@RequestMapping(value="/actionItems")
public class ActionItemController {

	final Logger logger = Logger.getLogger(ActionItemController.class);
	
	@Autowired
	ActionItemRepository repository;
	
	@PersistenceContext
    private EntityManager manager;
	
	@Autowired
	TimesheetService service;
	
	
	@RequestMapping(method=RequestMethod.POST)
	public ActionItem addActionItems(@RequestBody ActionItem actionItem, HttpServletRequest request) throws MessagingException 
	{
		try{
			actionItem.setActionItemId(null);
			
			repository.save(actionItem);
				if(actionItem!=null) {
		    		service.sendActionTrakerNotification(actionItem, "add", request);        	
				}
		}
		catch(Exception e){
			logger.error(e);
		}
		return actionItem;
	}
	List<ActionItem> list=new ArrayList<>();List<ActionItem> list1=new ArrayList<>();List<ActionItem> list2=new ArrayList<>();
	@RequestMapping(method=RequestMethod.GET)
	public List<ActionItem> getActionItems(@RequestParam(value = "portfolioId", defaultValue = "0")Integer portfolioId,
										   @RequestParam(value = "assignedTo", defaultValue = "")String assignedTo,
										   @RequestParam(value = "status", defaultValue = "")String status,	
										   @RequestParam(value = "all", defaultValue = "0") Integer all,	
										   @RequestParam(value = "assignedToName", defaultValue = "0") String assignedToName,
	   									   @RequestParam(value = "projectId", defaultValue = "0")Integer projectId){
		try{
			
			if(projectId != 0) {
				list = repository.findByProjectId(projectId);
			}else {
				list = manager.createNamedQuery("get_action_items",ActionItem.class)
						.setParameter("all", all)
						.setParameter("portfolioId", portfolioId)
						.setParameter("assignedToName", assignedToName)
						.getResultList();				
			}
			/*if(portfolioId != 0 && projectId !=0 && !status.equals("")){
				list = repository.findByPortfolioIdAndProjectIdAndStatus(portfolioId,projectId,status);

			}else if(portfolioId != 0 && projectId !=0){

				list = repository.findByPortfolioIdAndProjectId(portfolioId,projectId);

			}else if(portfolioId != 0){
				list = repository.findByPortfolioId(portfolioId);
			}else if(!assignedTo.equals("")){
				list = repository.findByAssignedTo(assignedTo);
			}else if(projectId != 0) {
				list = repository.findByProjectId(projectId);
			}else if(!status.equals("")) {
				list = repository.findByStatus(status);
			}else{
				list = repository.findAll();
			}*/
		}
		catch(Exception e){
			logger.error(e);
		}
		return list;
	}
	
	@RequestMapping(value="/{actionItemId}",method=RequestMethod.PUT)
	public ActionItem updateAmgRoles(@PathVariable Integer actionItemId,@RequestBody ActionItem updatedActionItem){
		try{
			updatedActionItem.setActionItemId(actionItemId);
			repository.save(updatedActionItem);
		}
		catch(Exception e){
			logger.error(e);
		}
		return updatedActionItem;
	}
	
	@RequestMapping(value="/{actionItemId}",method=RequestMethod.DELETE)
	public void deleteActionItem(@PathVariable Integer actionItemId){
		try{
			repository.delete(actionItemId);
		}
		catch(Exception e){
			logger.error(e);
		}
	}
}
