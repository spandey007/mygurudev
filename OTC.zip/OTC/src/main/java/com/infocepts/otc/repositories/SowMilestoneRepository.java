package com.infocepts.otc.repositories;

import java.util.List;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.infocepts.otc.entities.SowMilestone;

public interface SowMilestoneRepository extends CrudRepository<SowMilestone,Integer>{

	@Override
	public List<SowMilestone> findAll();
	
	@Query("select sm from SowMilestone sm where sm.sow.sowId=:sowId")
	public List<SowMilestone> findBySowId(@Param("sowId") Integer sowId);
}
