package com.infocepts.otc.db;

import java.util.HashMap;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

import org.apache.tomcat.jdbc.pool.DataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.env.Environment;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@EnableTransactionManagement
@EnableAutoConfiguration
@EnableJpaRepositories(
		basePackages = "com.infocepts.otc.repositories", 
		entityManagerFactoryRef = "otcEntityManagerFactory", 
		transactionManagerRef = "otcTransactionManager")
public class OtcDbConfig {
	
		@Autowired
		private Environment env;	
		
		/*@Bean   
		@Primary
		@ConfigurationProperties(prefix = "otc.datasource")
		public javax.sql.DataSource otcDataSource() {
			return DataSourceBuilder.create().build();
		}*/
		
		@Bean
		@Primary
		@ConfigurationProperties(prefix = "otc.datasource")
		public DataSource otcTomcatDataSource() {
			DataSource tomcatDataSource = new DataSource();
			tomcatDataSource.setUsername(env.getProperty("otc.datasource.username"));
			tomcatDataSource.setPassword(env.getProperty("otc.datasource.password"));
			tomcatDataSource.setUrl(env.getProperty("otc.datasource.url"));
			tomcatDataSource.setDriverClassName(env.getProperty("otc.datasource.driver-class-name"));
			tomcatDataSource.setTestOnConnect(true);
			tomcatDataSource.setTestWhileIdle(true);
			return tomcatDataSource;
		}

	    @Bean(name = "otcEntityManager")
	    @Primary
	    public EntityManager otcEntityManager() {
	        return otcEntityManagerFactory().createEntityManager();
	    }
	  	    
	    @Bean(name = "otcEntityManagerFactory")
	    @Primary
	    public EntityManagerFactory otcEntityManagerFactory() {
	        LocalContainerEntityManagerFactoryBean emf = new LocalContainerEntityManagerFactoryBean();
//	        emf.setDataSource(otcDataSource());
	        emf.setDataSource(otcTomcatDataSource());
	        
	        HibernateJpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();	 
	        emf.setJpaVendorAdapter(vendorAdapter);
	        emf.setPackagesToScan(new String[] {"com.infocepts.otc.entities"});
	        emf.setPersistenceUnitName("otc");   // <- giving 'default' as name
	        
	        HashMap<String, Object> properties = new HashMap<String, Object>();
		properties.put("hibernate.show_sql", env.getProperty("hibernate.show_sql"));
	        //properties.put("hibernate.hbm2ddl.auto", env.getProperty("hibernate.hbm2ddl.auto"));
	        properties.put("hibernate.dialect", env.getProperty("hibernate.dialect"));
	        properties.put("hibernate.generate_statistics", env.getProperty("hibernate.generate_statistics"));
	        emf.setJpaPropertyMap(properties);
	        emf.afterPropertiesSet();
	        return emf.getObject();
	    }
	    
	    @Bean(name = "otcTransactionManager")
	    @Primary
	    public PlatformTransactionManager otcTransactionManager() {
	        JpaTransactionManager tm = new JpaTransactionManager();
	        tm.setEntityManagerFactory(otcEntityManagerFactory());
	        return tm;
	    }
}


