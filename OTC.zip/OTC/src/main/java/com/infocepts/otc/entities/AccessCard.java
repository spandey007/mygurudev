/**
* Filename: /src/main/java/com/infocepts/otc/entities/AccessCard.java
* @author  SHRI
* @version 1.0
* @since   2018-09-25 
*/
package com.infocepts.otc.entities;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.persistence.*;
import javax.validation.constraints.NotNull;

import com.infocepts.otc.utilities.LoadConstant;
@Entity
@Table(catalog=LoadConstant.otc, schema="[dbo]", name="accessCard")

@SqlResultSetMappings({
        @SqlResultSetMapping(
                name = "list_all_access_detail",
                classes = {
                        @ConstructorResult(
                                targetClass = AccessCard.class,
                                columns = {
                                		@ColumnResult(name = "accessId"),
                                        @ColumnResult(name = "comment", type = String.class), 
										@ColumnResult(name = "uId"),
										@ColumnResult(name = "createdBy"),
                                        @ColumnResult(name = "createdDate", type = Date.class),
										@ColumnResult(name = "modifiedBy"),
                                        @ColumnResult(name = "modifiedDate", type = Date.class),
										@ColumnResult(name = "status"),
										@ColumnResult(name = "empId"),
										@ColumnResult(name = "title"),										
										@ColumnResult(name = "joiningDate"),
										@ColumnResult(name = "bloodGroup"),										
										@ColumnResult(name = "permMobNumber"),										
										@ColumnResult(name = "departmentName")
                                }
                        )
                }
        )
})
@NamedNativeQueries({
        @NamedNativeQuery(
                name    =   "getAllAccessCard",   
                query 	=   "Select ac.*, r.empId, r.title,r.joiningDate,r.bloodGroup,r.permMobNumber, parentDepartment.departmentName"+
							" from " + LoadConstant.otc + ".[dbo].[accessCard] as ac"+
							" Left JOIN " + LoadConstant.infomaster + ".[dbo].[resource] r on r.uid = ac.uId"+
							" Left JOIN " + LoadConstant.infomaster + ".[dbo].[department] d on r.departmentId = d.departmentId"+
							" Left JOIN " + LoadConstant.infomaster + ".[dbo].[department] parentDepartment on parentDepartment.departmentId = d.pid",							
							 
							resultClass=AccessCard.class, resultSetMapping = "list_all_access_detail"
        )        
})


public class AccessCard {

	// Entity Columns
    // --------------------------------------------------------------------------------
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Integer accessId; 
	
	@Lob 
	private String comment; // use @Lob to generate varchar(max) eg. to store big urls, text, notes
	
	private Integer uId;    

	 // Audit Trail columns 
    // --------------------------------------------------------------------------------
	private Integer createdBy;    
    private Date createdDate;
    private Integer modifiedBy;
    private Date modifiedDate;
    private Integer status;    
    
    // Transient Variables
    // --------------------------------------------------------------------------------
	//    @Transient
	//    private String column7;
    
	@Transient
	private Integer empId;
    
	@Transient
	private String title;
	
	@Transient
	private Date joiningDate;
	
	@Transient
	private String bloodGroup;
	
	@Transient
	private String permMobNumber;
	
	@Transient
	private String departmentName;

	public Integer getAccessId() {
		return accessId;
	}

	public void setAccessId(Integer accessId) {
		this.accessId = accessId;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public Integer getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Integer getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public Integer getuId() {
		return uId;
	}

	public void setuId(Integer uId) {
		this.uId = uId;
	}
	
	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	

	public Integer getEmpId() {
		return empId;
	}

	public void setEmpId(Integer empId) {
		this.empId = empId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Date getJoiningDate() {
		return joiningDate;
	}

	public void setJoiningDate(Date joiningDate) {
		this.joiningDate = joiningDate;
	}

	public String getBloodGroup() {
		return bloodGroup;
	}

	public void setBloodGroup(String bloodGroup) {
		this.bloodGroup = bloodGroup;
	}

	public String getPermMobNumber() {
		return permMobNumber;
	}

	public void setPermMobNumber(String permMobNumber) {
		this.permMobNumber = permMobNumber;
	}

	public String getDepartmentName() {
		return departmentName;
	}

	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}

	// Constructor
	// ---------------------------------------------------------------------------------
	public AccessCard() {
		//super();
		// TODO Auto-generated constructor stub
	}

	public AccessCard(Integer accessId, String comment, Integer uId, Integer createdBy, Date createdDate,
			Integer modifiedBy, Date modifiedDate, Integer status, Integer empId, String title, Date joiningDate,
			String bloodGroup, String permMobNumber, String departmentName) {
		super();
		this.accessId = accessId;
		this.comment = comment;
		this.uId = uId;
		this.createdBy = createdBy;
		this.createdDate = createdDate;
		this.modifiedBy = modifiedBy;
		this.modifiedDate = modifiedDate;
		this.status = status;
		this.empId = empId;
		this.title = title;
		this.joiningDate = joiningDate;
		this.bloodGroup = bloodGroup;
		this.permMobNumber = permMobNumber;
		this.departmentName = departmentName;
	}

	


	

    // Getter setter
	// --------------------------------------------------------------------------------
	//Right click -> go to the source -> Generate constructor
	

    
    
   
   



    
    

}
