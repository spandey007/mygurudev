package com.infocepts.otc.db;

import java.util.HashMap;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

import org.apache.tomcat.jdbc.pool.DataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.env.Environment;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@EnableTransactionManagement
@EnableAutoConfiguration
@EnableJpaRepositories(
		basePackages = "com.infocepts.pms.repositories", 
		entityManagerFactoryRef = "pmsEntityManagerFactory", 
		transactionManagerRef = "pmsTransactionManager")
public class PmsDbConfig {
	
		@Autowired
		private Environment env;	
		
		/*@Bean  
		@ConfigurationProperties(prefix = "pms.datasource")
		public DataSource pmsDataSource() {
			return DataSourceBuilder.create().build();
		}*/

		@Bean
		@ConfigurationProperties(prefix = "pms.datasource")
		public DataSource pmsTomcatDataSource() {
			DataSource tomcatDataSource = new DataSource();
			tomcatDataSource.setUsername(env.getProperty("pms.datasource.username"));
			tomcatDataSource.setPassword(env.getProperty("pms.datasource.password"));
			tomcatDataSource.setUrl(env.getProperty("pms.datasource.url"));
			tomcatDataSource.setDriverClassName(env.getProperty("pms.datasource.driver-class-name"));
			tomcatDataSource.setTestOnConnect(true);
			tomcatDataSource.setTestWhileIdle(true);
			return tomcatDataSource;
		}
		
	   @Bean(name = "pmsEntityManager")
	    public EntityManager pmsEntityManager() {
	        return pmsEntityManagerFactory().createEntityManager();
	    }
	  
	    @Bean(name = "pmsEntityManagerFactory")
	    public EntityManagerFactory pmsEntityManagerFactory() {
	        LocalContainerEntityManagerFactoryBean emf = new LocalContainerEntityManagerFactoryBean();
//	        emf.setDataSource(pmsDataSource());
	        emf.setDataSource(pmsTomcatDataSource());
	        
	        HibernateJpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();	        
	        emf.setJpaVendorAdapter(vendorAdapter);
	        emf.setPackagesToScan(new String[] {"com.infocepts.pms.entities"});
	        emf.setPersistenceUnitName("pms"); 
	        
	        HashMap<String, Object> properties = new HashMap<String, Object>();
			properties.put("hibernate.show_sql", env.getProperty("hibernate.show_sql"));
	        //properties.put("hibernate.hbm2ddl.auto", env.getProperty("hibernate.hbm2ddl.auto"));
	        properties.put("hibernate.dialect", env.getProperty("hibernate.dialect"));
	        emf.setJpaPropertyMap(properties);
	        emf.afterPropertiesSet();
	        return emf.getObject();
	    }
	    
	    @Bean(name = "pmsTransactionManager")
	    public PlatformTransactionManager pmsTransactionManager() {
	        JpaTransactionManager tm = new JpaTransactionManager();
	        tm.setEntityManagerFactory(pmsEntityManagerFactory());
	        return tm;
	    }
}


