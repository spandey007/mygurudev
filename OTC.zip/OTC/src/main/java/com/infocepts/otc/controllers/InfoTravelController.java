package com.infocepts.otc.controllers;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.mail.MessagingException;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.infocepts.otc.entities.InfoTravel;
import com.infocepts.otc.repositories.InfoTravelRepository;
import com.infocepts.otc.services.TimesheetService;
import com.infocepts.otc.utilities.AbstractExpenseFileHandling;
import com.infocepts.otc.utilities.ExportUtil;
import com.infocepts.otc.utilities.InvoiceNoGenerator;

@RestController
@RequestMapping(value="/infotravel",headers="referer")
public class InfoTravelController {
	
	final Logger logger = Logger.getLogger(InfoTravelController.class.getName());
	
	@Autowired
	InfoTravelRepository infoTravelRepository;
	
	@Autowired
	TimesheetService service;
	
	@PersistenceContext(unitName = "otc")
	private EntityManager manager;	
	
	@Autowired
	HttpSession session;
	
	
	@Value("${spring.host.localdrive}")
   	private String localdrive;
	
	@Autowired
	ExportUtil exportUtil;
	
	String path=null;String filepath="";
	
	@RequestMapping(method=RequestMethod.POST)
	public InfoTravel addInfoTravel(@RequestBody InfoTravel infoTravel, HttpServletRequest request){
		
		List<InfoTravel> lastTourCodeList=null; 
		String lastTourCode = "";
		Date creationDate = null;
		try{
			
			// SRA: code to find last tour code in InfoTravel module and find next tour code before insertion
			lastTourCodeList =  manager.createNamedQuery("getLastTourCode",InfoTravel.class).getResultList();
			
			//if last tour code is present
			if(lastTourCodeList.size()>0){
				Iterator<InfoTravel> it = lastTourCodeList.iterator();
				while (it.hasNext()) {
					InfoTravel infotravel = it.next();
					lastTourCode = infotravel.getTourCode();
					creationDate = infotravel.getCreatedDate();
					if (creationDate == null) {
						creationDate = new Date();
					}
				}
				
				//Logic to fetch next tour code
				String tourCode = InvoiceNoGenerator.infoTravelTourCodeNo(lastTourCode, creationDate);
				logger.info("tourCode");logger.info(tourCode);
				
				infoTravel.setTourCode(tourCode);
				
			}
			//if no tourCode is present in database - start with current year series  + 001
			else 
			{
				String tourCode="";
				String nextYearStr ="";
				String yearStr="";
				int nextYear = 0;
				Date date = new Date();
				LocalDate localDate = date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
				int year  = localDate.getYear();
				nextYear = year + 1;
				nextYearStr = String.valueOf(nextYear).substring(2, 4);
				yearStr 	 = String.valueOf(year).substring(2, 4);
				
				logger.info("Default Tour code is assigned to this Travel Request");
				tourCode = "TPN" + yearStr + nextYearStr +  "001";
				logger.info(tourCode);
				infoTravel.setTourCode(tourCode);	
			}
			
			
			
			infoTravel.setInfoTravelId(null);			
			infoTravelRepository.save(infoTravel);
			if (infoTravel.getSubmissionStatus() == 1) {
				//service.sendInfoTravelNotification(infoTravel, "add", request);
			}

		} catch (Exception e) {
			e.printStackTrace();
//			 logger.info(String.format("exception - ", e));
		}
		return infoTravel;
	}

	@RequestMapping(method = RequestMethod.GET)
	public List<InfoTravel> findInfoTravel(@RequestParam(value = "uid", defaultValue = "0") Integer uid,
			@RequestParam(value = "infoTravelId", defaultValue = "0") Integer infoTravelId,
			@RequestParam(value = "isPMPage", defaultValue = "false") Boolean isPMPage,
			@RequestParam(value = "isApprovalList", defaultValue = "false") Boolean isApprovalList,
			@RequestParam(value = "isTVF", defaultValue = "false") Boolean isTVF,
			@RequestParam(value = "isTravel", defaultValue = "false") Boolean isTravel,
			@RequestParam(value = "submissionStatus", defaultValue = "0") Integer submissionStatus,
			@RequestParam(value = "approverId", defaultValue = "0") Integer approverId, HttpServletRequest request) {
		List<InfoTravel> list = null;
		logger.info("uid="+uid);
		
		
		
		if(uid != 0){	//edit
			Integer loggedInUid = (Integer) session.getAttribute("loggedInUid");
			System.out.println("inside user page");
			list = manager.createNamedQuery("getInfoTravel_by_Uid",InfoTravel.class)
					.setParameter("uid", loggedInUid)
					 .getResultList();
		}
		else if (infoTravelId !=0) {
			System.out.println("inside infoTravelId page");
			list = manager.createNamedQuery("getInfoTravel_by_Id",InfoTravel.class)					
					.setParameter("infoTravelId", infoTravelId)
					 .getResultList();
		}
		else if(isTVF && submissionStatus==4) {
			System.out.println("inside finAnce status page");
			list = manager.createNamedQuery("getInfoTravel_financeSubmission",InfoTravel.class)
					.getResultList();
		}
		else if(isPMPage && submissionStatus==1){	//edit 	
			Integer loggedInUid = (Integer) session.getAttribute("loggedInUid");
			System.out.println("inside manager page");
			list = manager.createNamedQuery("getInfoTravel_by_PMSubmission",InfoTravel.class)					
					.setParameter("uid", loggedInUid)
					 .getResultList();
		}
		else if(isTravel && submissionStatus==6) {
			System.out.println("inside travel status page");
			list = manager.createNamedQuery("getInfoTravel_travelTeam",InfoTravel.class)
					.getResultList();
		}
		else if(isApprovalList){	//edit
			Integer loggedInUid = (Integer) session.getAttribute("loggedInUid");
			System.out.println("inside manager page");
			list = manager.createNamedQuery("getInfoTravel_by_PMUid",InfoTravel.class)
					.setParameter("uid", loggedInUid)
					 .getResultList();
		}
		else if(submissionStatus != 0) {
			System.out.println("inside travel getInfoTravel_submittedRequest page");
			list = manager.createNamedQuery("getInfoTravel_submittedRequest",InfoTravel.class)
					.setParameter("submissionStatus", submissionStatus)
					.getResultList();
		}
		else { // list for travel team
			System.out.println("inside all page");
			list = manager.createNamedQuery("getInfoTravel_by_All",InfoTravel.class)
					.getResultList();
//			}
			/* ------------------------- Authorization ends ------------------------------------ */
			
		}
		return list;
	}
	
@RequestMapping(value="/{infoTravelId}",method=RequestMethod.GET)
	public InfoTravel getInfoTravel(@PathVariable Integer infoTravelId){
		InfoTravel infoTravel = null;
		try {
				System.out.println("inside getInfoCab"+infoTravelId);
				infoTravel = infoTravelRepository.findOne(infoTravelId);
			} catch (Exception e) {
				logger.info(String.format("exception - ", e));
			}
		return infoTravel;
	}

	@RequestMapping(value = "/{infoTravelId}", method = RequestMethod.PUT)
	public InfoTravel updateInfoTravel(@PathVariable Integer infoTravelId, @RequestBody InfoTravel updatedInfoTravel,
			HttpServletRequest request) {
		// Authorization for XYZ role
		try {
			updatedInfoTravel.setInfoTravelId(infoTravelId);
			infoTravelRepository.save(updatedInfoTravel);
			if (updatedInfoTravel.getSubmissionStatus() >= 1) {
			//service.sendInfoTravelNotification(updatedInfoTravel, "update", request);
			}
		} catch (Exception e) {
			logger.info(String.format("exception - ", e));
		}
		return updatedInfoTravel;
	}
	
	@RequestMapping(value="/{infoTravelId}",method=RequestMethod.DELETE)
	public void deleteInfoTravel(@PathVariable Integer infoTravelId){
		Boolean isAValidCall = false;
		if(service.isTravel())
		{
			isAValidCall = true;
		}
		if(isAValidCall) {
		infoTravelRepository.delete(infoTravelId);
		}
	}
	
	@RequestMapping(value="/upload/{infoTravelId}",method=RequestMethod.POST,consumes = {"multipart/form-data"})
    @ResponseBody
	public String uploadFile(@RequestPart("file") MultipartFile file,@PathVariable(value = "infoTravelId") Integer infoTravelId,HttpServletRequest request)
	{
		String str1="";String str="";
	
		InfoTravel infoTravel=infoTravelRepository.findOne(infoTravelId);
		filepath = infoTravel.getTravellerDoc();
		logger.info("user doc filepath");
		logger.info(infoTravel.getTravellerDoc());
		path=exportUtil.getTravelDocPath(file,request,infoTravelId);
		logger.info("user doc fullpath");
		logger.info(path);
		if(path!=null){
			str="";
			str1=str+path;
			if(filepath != null && !filepath.isEmpty()){
				filepath=filepath+","+str1;
			}
			else{
				filepath=str1;
			}
		}
		infoTravel.setTravellerDoc(filepath);
		logger.info("user doc save filepath");
		logger.info(filepath);
		infoTravelRepository.save(infoTravel);
		return path;
	}	
	
	@RequestMapping(value="/download/{infoTravelId}",method=RequestMethod.GET)
	public void download(@PathVariable(value = "infoTravelId") Integer infoTravelId,HttpServletRequest request,HttpServletResponse response) throws ServletException, Exception {
		InfoTravel infoTravel=infoTravelRepository.findOne(infoTravelId);
		List<String> fileList = Arrays.asList(infoTravel.getTravellerDoc().split(","));
		
		
		try {
			File file = null;
			if (fileList.size() == 1) {
				file = new File(fileList.get(0));
			} else {
				file = AbstractExpenseFileHandling.zipFiles(fileList, 
						String.format("Travel_%s_", infoTravel.getInfoTravelId()));
			}
			
			Path path = Paths.get(file.toString());
		    response.addHeader(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename="+file.getName());
		    Files.copy(path, response.getOutputStream());
		    response.getOutputStream().flush();
		} catch (IOException e) {
			logger.log(Level.SEVERE, "COULD NOT DOWNLOAD FILE FOR Infotravel ID: " + infoTravelId, e);
		}
	
	}
	
	@RequestMapping(value = "/send-notification/{infoTravelId}", method=RequestMethod.PUT)
	public void sendInfoTravelNotification(@PathVariable Integer infoTravelId,HttpServletRequest request) throws MessagingException{
		InfoTravel infoTravelObject = null;
		
		infoTravelObject = infoTravelRepository.findOne(infoTravelId);

		if(infoTravelObject.getModifiedDate() == null) {
			System.out.println("inside new infotravel mail");
			service.sendInfoTravelNotification(infoTravelObject, "add", request);
		}		
		else {
			service.sendInfoTravelNotification(infoTravelObject, "update", request);
		}
		
	}
	
	@GetMapping("/getInfoTravelList")
    public Object getInfoTravelList(HttpServletRequest request){        
		List<InfoTravel> list = null;
        try{
        	list = manager.createNamedQuery("fetchAllInfoTravel",InfoTravel.class)
        			.getResultList();
        }catch(Exception e){
            logger.log(Level.SEVERE, "exceptn msg", e);
        }
        return list;
    }
	
}

