package com.infocepts.otc.repositories;

import java.util.List;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import com.infocepts.otc.entities.Certification;

public interface CertificationRepository extends CrudRepository<Certification,Integer>{
	
	@Query("select c from Certification c order by certificationName")
	public List<Certification> findAllCertifications();
	
	@Query("select c from Certification c where c.certificationName like :certificationName% order by certificationName")
	public List<Certification> findCertificationByName(@Param(value="certificationName") String certificationName);
	
}
