package com.infocepts.otc.repositories;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.persistence.EntityManager;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.infocepts.otc.entities.Account;
import com.infocepts.otc.utilities.LoadConstant;

public interface AccountRepository extends JpaRepository<Account,Integer>{
		@Override
		public List<Account> findAll();
		
		@Query("SELECT COUNT(*) FROM Account WHERE ahId = :userId")
		Integer getAccountHeadCountForUser(@Param("userId") Integer userId);
		
		@SuppressWarnings("unchecked")
		default List<Map<Object, Object>> getActiveInternalAccounts(EntityManager manager) {
			final Logger logger = Logger.getLogger(AccountRepository.class.getName());
			String queryString = "select distinct ac.itemId as accountId, ac.title as accountName from "
					+ LoadConstant.infomaster + ".[dbo].[accounts] ac "
					+ "where ac.strategic = 'Internal' and ac.status = 'Active' order by ac.title";
			
			List<Map<Object, Object>> accountList = new ArrayList<>();
			try {
				javax.persistence.Query accountQuery = manager.createNativeQuery(queryString, "fetchInternalAccounts");
				List<Object[]> resultList = accountQuery.getResultList();
				resultList.forEach(object -> {
					Map<Object, Object> map = new HashMap<>();
					Integer accountId = (Integer) object[0];
					String accountName = (String) object[1];
					map.putIfAbsent("accountId", accountId);
					map.putIfAbsent("accountName", accountName);
					accountList.add(map);
				});
			} catch (Exception e) {
				logger.log(Level.SEVERE, "SOMETHING WENT WRONG WHILE FETCHING THE ACTIVE INTERNAL ACCOUNTS!", e);
			}
			return accountList;
		}
}
