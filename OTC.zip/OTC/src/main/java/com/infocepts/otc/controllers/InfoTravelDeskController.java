package com.infocepts.otc.controllers;

import java.io.File;
import java.io.FileNotFoundException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.logging.Logger;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.infocepts.otc.entities.InfoTravelDesk;
import com.infocepts.otc.repositories.InfoTravelDeskRepository;
import com.infocepts.otc.services.TimesheetService;
import com.infocepts.otc.utilities.ExportUtil;

@RestController
@RequestMapping(value="/infotraveldesk",headers="referer")
public class InfoTravelDeskController {

	@Autowired
	InfoTravelDeskRepository infotraveldeskRepository;
	
	@PersistenceContext
    private EntityManager manager;
	
	@Autowired
	ExportUtil exportUtil;
	
	@Autowired
	TimesheetService service;
	
	String path=null;
	String filepath="";
	
	
	final Logger logger = Logger.getLogger(InfoTravelDeskController.class.getName());
	
	@RequestMapping(method=RequestMethod.POST)
	public InfoTravelDesk addInfoTravelDesk(@RequestBody InfoTravelDesk infotraveldesk){
		if (infotraveldesk.getIsChild() !=null && infotraveldesk.getIsChild() > 0) {
			
			Integer travelDeskFlag = infotraveldesk.getTravelDeskFlag();
			
			List<InfoTravelDesk> travelDesk = infotraveldeskRepository.findByParentId(infotraveldesk.getParentId(), travelDeskFlag);
			// Update if travel is not null insert otherwise.
			if (CollectionUtils.isEmpty(travelDesk)) {
				infotraveldesk.setInfoTravelDeskId(null);
				infotraveldesk.setTravelDeskFlag(travelDeskFlag);
			} else {
				infotraveldesk.setInfoTravelDeskId(travelDesk.get(0).getInfoTravelDeskId());
			}
			return infotraveldeskRepository.save(infotraveldesk);
		} else {
			infotraveldesk.setInfoTravelDeskId(null);
			try {
				infotraveldeskRepository.save(infotraveldesk);
			} catch (Exception e) {
				logger.info(String.format("exception - ", e));
			}
			return infotraveldesk;
		}
	}
	
	@RequestMapping(method=RequestMethod.GET)
	public List<InfoTravelDesk> getInfoTravelDesk(@RequestParam(value = "infoTravelId", defaultValue = "0") Integer infoTravelId			
			,@RequestParam(value = "getAll", defaultValue = "false") Boolean getAll
			,HttpServletRequest request){
		
		List<InfoTravelDesk> list = null;
		Integer infoTravelDeskId = NumberUtils.toInt(request.getParameter("infoTravelDeskId"));
		Integer travelDeskFlag = NumberUtils.toInt(request.getParameter("travelDeskFlag"));
		List<InfoTravelDesk> filteredTravelDeskList = new ArrayList<>();
		
		try{
			if(infoTravelId != 0 && !getAll){
				 logger.info("here in infotravel section");
				 list = infotraveldeskRepository.findById(infoTravelId);
				 List<InfoTravelDesk> parents = list.parallelStream().filter(desk -> desk.getParentId() == null).collect(Collectors.toList());
				 List<InfoTravelDesk> children = new ArrayList<>();
				 
				 for (InfoTravelDesk parent : parents) {
					 for (InfoTravelDesk infoTravelDesk : list) {
						 if (parent.getInfoTravelDeskId() == infoTravelDesk.getParentId()) {
							 children.add(infoTravelDesk);
						 }
					}
					if (children.isEmpty()) {
						filteredTravelDeskList.add(parent);
					} else {
						Optional<InfoTravelDesk> max = children.parallelStream().max(Comparator.comparingInt(InfoTravelDesk :: getTravelDeskFlag));
						filteredTravelDeskList.add(max.get());
					}
					children.clear();
				}
				 return filteredTravelDeskList;
			 }
			 else if(infoTravelId != 0 && getAll){
                 list = infotraveldeskRepository.findById(infoTravelId);
             }
			 else if(infoTravelDeskId != 0 && travelDeskFlag!=0){
				 list = infotraveldeskRepository.findByParentId(infoTravelDeskId, travelDeskFlag);
			 }
			 else{
				 list = infotraveldeskRepository.findAll();
			 }
			 
		 }
		 catch(Exception e){
			 logger.info(String.format("exception - ", e));
		 }
		return list;
	}
	
	@RequestMapping(value="/{infoTravelDeskId}",method=RequestMethod.GET)
	public InfoTravelDesk getInfoTravelDesk(@PathVariable Integer infoTravelDeskId){
		InfoTravelDesk infotraveldesk = null;
		infotraveldesk = infotraveldeskRepository.findOne(infoTravelDeskId);
		return infotraveldesk;
	}
	
	@RequestMapping(value="/{infoTravelDeskId}", method=RequestMethod.PUT)
	public InfoTravelDesk updateInfoTravelDesk(@PathVariable Integer infoTravelDeskId,  @RequestBody InfoTravelDesk updatedInfoTravelDesk){
		updatedInfoTravelDesk.setInfoTravelDeskId(infoTravelDeskId);
			infotraveldeskRepository.save(updatedInfoTravelDesk);
		
		return updatedInfoTravelDesk;
	}
	
	@RequestMapping(value="/{infoTravelDeskId}",method=RequestMethod.DELETE)
	public void deleteInfoTravelDesk(@PathVariable Integer infoTravelDeskId){
			infotraveldeskRepository.delete(infoTravelDeskId);
		
	}
	
	@RequestMapping(value="/upload/{infoTravelDeskId}",method=RequestMethod.POST,consumes = {"multipart/form-data"})
    @ResponseBody
	public String uploadFile(@RequestPart("file") MultipartFile file,@PathVariable(value = "infoTravelDeskId") Integer infoTravelDeskId,HttpServletRequest request)
	{	
		InfoTravelDesk infoTravelDesk = infotraveldeskRepository.findOne(infoTravelDeskId);
		path=exportUtil.getTravelDeskDocPath(file,request,infoTravelDeskId);		
		infoTravelDesk.setAttach(path);				
		infotraveldeskRepository.save(infoTravelDesk);
		return path;
	}
	
	
	@RequestMapping(value="/download/{infoTravelDeskId}",method=RequestMethod.GET)
	public void download(@PathVariable(value = "infoTravelDeskId") Integer infoTravelDeskId,HttpServletRequest request,HttpServletResponse response) throws ServletException, Exception {
		String path=null;
		File home=exportUtil.checkPath(request);
		String separator=File.separator;
		String Filepath = "";
		path=home.getPath();
		
		InfoTravelDesk infoTravelDesk = infotraveldeskRepository.findOne(infoTravelDeskId);
		Filepath = infoTravelDesk.getAttach();
		List<String> list = Arrays.asList(Filepath.split("\\s*,\\s*"));
	
		if(list.size() > 1){
		
			if (home.exists() && home.isDirectory()) {
				 logger.info("home is a directory");
				    if(path.equals(separator)){
					 	path="usr"+File.separator+"home"+File.separator+"Download";
					}
					else{
						path=File.separator+"usr"+File.separator+"home"+File.separator+"Download";
					}
				
					if (Files.isDirectory(Paths.get(home + path))) {
						if(path.equals(separator)){
							path="usr"+File.separator+"home"+File.separator+"Download"+File.separator+"infotravel";
						}
						else{
							path=File.separator+"usr"+File.separator+"home"+File.separator+"Download"+File.separator+"infotravel";
						}
						
						if (Files.isDirectory(Paths.get(home + path))) {
							if(path.equals(separator)){
								path="usr"+File.separator+"home"+File.separator+"Download"+File.separator+"infotravel"+File.separator;
							}
							else{
								path=File.separator+"usr"+File.separator+"home"+File.separator+"Download"+File.separator+"infotravel"+File.separator;
							}
							
						} 
					}
				
			}
			
			
		}
		else{
			try{
				File outputFile = new File(Filepath);
				Path file = Paths.get(outputFile+"");
			    response.addHeader("Content-Disposition", "attachment; filename="+file.getFileName());
			    Files.copy(file, response.getOutputStream());
			    response.getOutputStream().flush();
			}
			catch(FileNotFoundException fe){
				fe.printStackTrace();
			}
		}
	}

}
