package com.infocepts.otc.controllers;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.infocepts.otc.entities.RevenueProjection;
import com.infocepts.otc.repositories.RevenueProjectionRepository;
import com.infocepts.otc.services.TimesheetService;

@RestController
@RequestMapping(value="/revenue",headers="referer")
public class RevenueProjectionController {

final Logger logger = Logger.getLogger(RevenueProjectionController.class);
	
	@Autowired
	RevenueProjectionRepository repository;
	
	@Autowired
	TimesheetService service;
	
	@PersistenceContext(unitName="otc")
    private EntityManager manager;
	
	@RequestMapping(method=RequestMethod.POST)
	public RevenueProjection addRevenue(@RequestBody RevenueProjection revenue)
	{
		try{
			if(service.isPmo() || service.isPH() || service.isG5AndAboveGrade()){
			revenue.setRevId(null);
				repository.save(revenue);	
			}
		}catch(Exception e){
			logger.error(e);
		}
		return revenue;
	}	
 
	 @RequestMapping(method=RequestMethod.GET)
	 public List<RevenueProjection> getAllRevenue(@RequestParam(value = "uid", defaultValue = "0") Integer uid,
												@RequestParam(value = "accountId", defaultValue = "0") Integer accountId,
												@RequestParam(value = "year", defaultValue = "0") Integer year,
												@RequestParam(value = "pid", defaultValue = "0") Integer pid,
												@RequestParam(value = "type", defaultValue = "all") String type,
												@RequestParam(value = "getpmList", defaultValue = "false") Boolean getpmList){
		 List<RevenueProjection> revenueList=null;
		 try{
			 if(service.isPmo() || service.isPH() || service.isG5AndAboveGrade()){ 
			 if(type.equals("existing"))
			 {
				 revenueList = manager.createNamedQuery("getRevenueForecastForExistingBusiness", RevenueProjection.class)
					.setParameter("year", year)
					.setParameter("pid", pid)
					.setParameter("accountId", accountId)
					.setParameter("uid", uid)
					//.setParameter("ahId", ahId)
					//.setParameter("phId", phId)
					.getResultList();
			 }
			 else if(type.equals("pipeline"))
			 {
				 revenueList = manager.createNamedQuery("getRevenueForecastForPipelineBusiness", RevenueProjection.class)
					.setParameter("year", year)
					.setParameter("uid", uid)
					.getResultList();
			 }else if(getpmList) {
				 revenueList = manager.createNamedQuery("getPMsList", RevenueProjection.class)
							.getResultList();
			 }
			 else
			 {
				 revenueList = manager.createNamedQuery("getRevenueForecast", RevenueProjection.class)
					.setParameter("year", year)
					.getResultList();
			 }
		 }
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return revenueList;
	 }
	 
	
	 @RequestMapping(value="/{revId}",method=RequestMethod.PUT)
	 public RevenueProjection updateRevenue(@RequestBody RevenueProjection updatedRevenue,@PathVariable Integer revId){
		 try{
			 if(service.isPmo() || service.isPH() || service.isG5AndAboveGrade()){
				 updatedRevenue.setRevId(revId);
				 repository.save(updatedRevenue);
			 }
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return updatedRevenue;
	 }
	 
	/* @RequestMapping(value="/{revId}",method=RequestMethod.DELETE)
	 public void deleteRevenue(@PathVariable Integer revId){
		 try{
			 //if(service.isPmo()){
				 repository.delete(revId);
			// }
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
	 }*/
	
}
