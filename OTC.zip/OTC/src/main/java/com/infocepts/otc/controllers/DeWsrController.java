/**
* Filename: /src/main/java/com/infocepts/otc/controllers/DeWsrController.java
* @author  SHRI
* @version 1.0
* @since   2018-11-28 
*/

package com.infocepts.otc.controllers;

import java.util.logging.Logger;
import com.infocepts.otc.entities.DeGovernance;
import com.infocepts.otc.entities.DeWsr;
import com.infocepts.otc.entities.ISow;
import com.infocepts.otc.repositories.DeWsrRepository;
import com.infocepts.otc.utilities.DateConverter;
import com.infocepts.otc.utilities.ExportUtil;
import com.infocepts.otc.services.TimesheetService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.mail.MessagingException;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.io.File;
import java.io.FileNotFoundException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

@RestController
@RequestMapping(value="/dewsr",headers="referer")
public class DeWsrController {

    final Logger logger = Logger.getLogger(DeWsrController.class.getName());

    @Autowired
    DeWsrRepository deWsrRepository;
    
    @Autowired
    HttpSession session;

    @PersistenceContext(unitName = "otc") 
    private EntityManager manager;
			
	@Autowired
	ExportUtil exportUtil;
	
	@Autowired
	TimesheetService service;
	String path=null;
	String filepath="";
	String filepath1="";
	String filepath2="";
	String filepath3="";
	String filepath4="";
	
    @RequestMapping(method = RequestMethod.GET)
    public List<DeWsr> findAll(@RequestParam(value = "view", defaultValue = "0") String view,
    		@RequestParam(value = "monthYear", defaultValue = "0") String monthYear,
    		@RequestParam(value = "projectId", defaultValue = "0") Integer projectId,HttpServletRequest request) throws MessagingException{
         List<DeWsr> DeWsrList = null;
         Integer loggedInUid = (Integer) session.getAttribute("loggedInUid");
		 int month = 0;
		 int year = 0;
		 boolean isDEMember = false;
		 boolean isPMOMember = false;
		 
		 //Get the user roles
		 String userRoles = session.getAttribute("userRoles") != null ? session.getAttribute("userRoles").toString() : "";
		 int uid = session.getAttribute("loggedInUid") != null ? Integer.valueOf(session.getAttribute("loggedInUid").toString()) : 0;
		 if(userRoles.toLowerCase().contains("de")) isDEMember = true;
		 if(userRoles.toLowerCase().contains("pmo")) isPMOMember = true;
		 
        try {

			/* ------------------------- Authorization ends ------------------------------------ */
   		 if(!monthYear.equals("") && monthYear.contains("-")) { month = Integer.valueOf(monthYear.split("-")[1]); year = Integer.valueOf(monthYear.split("-")[0]); }
	   		 if( (view.equals("de") && isDEMember) || (view.equals("pmo") && isPMOMember) || (view.equals("dh") && uid == 512)){
	   			 if(projectId != 0) {
	   				DeWsrList = deWsrRepository.findByProjectId(projectId);
	   			 }else{
		 	   			DeWsrList = manager.createNamedQuery("getAllDeWsrData", DeWsr.class)
				 				.setParameter("uid", uid)
			    				.setParameter("view", view)
				 				.setParameter("month", month)
				 				.setParameter("year", year)
				 				.getResultList();
	   			 }
	        }else if(view.equals("pm") || view.equals("ph") || view.equals("cep")){
	   			 if(projectId != 0) {	   				 
	   				DeWsrList = deWsrRepository.findByProjectId(projectId);
	   			 }else{
	 	   			DeWsrList = manager.createNamedQuery("getAllDeWsrData", DeWsr.class)
			 				.setParameter("uid", uid)
		    				.setParameter("view", view)
			 				.setParameter("month", month)
			 				.setParameter("year", year)
			 				.getResultList();	   				 
	   			 }
		 	}

         } 
		catch (Exception e){
			e.printStackTrace();
			 logger.info(String.format("exception - ", e));
        }
        
        return DeWsrList;

    }
    
    /**
     * This method is add row in moduleName entity
     * 
     */
    @RequestMapping(method=RequestMethod.POST)
	public DeWsr addDeWsr(@RequestBody DeWsr deWsr, HttpServletRequest request) {
		// Authorization for XYZ role
			try{
				deWsr.setDeWsrId(null);
				deWsrRepository.save(deWsr);
				service.sendWsrNotification(deWsr, "add", request);

			}
			catch(Exception e){
				 logger.info(String.format("exception - ", e));
			}
		
		return deWsr;
	}
    
    
	@RequestMapping(value="/upload/{deWsrId}/{indexvalue}",method=RequestMethod.POST,consumes = {"multipart/form-data"})
    @ResponseBody
	public String uploadFile(@RequestPart("file") MultipartFile file,@PathVariable(value = "deWsrId") Integer deWsrId,@PathVariable(value = "indexvalue") Integer indexvalue,HttpServletRequest request)
	{
		DeWsr deWsr = deWsrRepository.findOne(deWsrId);

		String type = "dewsr";
		path=exportUtil.getDeFilePath(file,request,deWsrId,type);		

			if(indexvalue == 0) {
				deWsr.setFilepath(path);
				deWsr.setUploadDate1(deWsr.getCreatedDate());
			}
			
			if(indexvalue == 1) {
				deWsr.setFilepath1(path);
				deWsr.setUploadDate2(deWsr.getCreatedDate());
			}

			if(indexvalue == 2) {
				deWsr.setFilepath2(path);
				deWsr.setUploadDate3(deWsr.getCreatedDate());
			}
			
			if(indexvalue == 3) {
				deWsr.setFilepath3(path);
				deWsr.setUploadDate4(deWsr.getCreatedDate());
			}
			
			if(indexvalue == 4) {
				deWsr.setFilepath4(path);
				deWsr.setUploadDate5(deWsr.getCreatedDate());
			}

		deWsrRepository.save(deWsr);
		return path;
	}
	
	@RequestMapping(value="/download/{deWsrId}/{week}",method=RequestMethod.GET)
	public void download(@PathVariable(value = "deWsrId") Integer deWsrId,@PathVariable(value = "week") Integer week,HttpServletRequest request,HttpServletResponse response) throws ServletException, Exception {
		String path=null;
		File home=exportUtil.checkPath(request);
		String separator=File.separator;
		String Filepath = "";
		path=home.getPath();
		
		DeWsr deWsr =deWsrRepository.findOne(deWsrId);

		if(week==0) {
			Filepath = deWsr.getFilepath();
		}else if(week==1) {
			Filepath = deWsr.getFilepath1();
		}else if(week == 2) {
			Filepath = deWsr.getFilepath2();
		}else if(week == 3) {
			Filepath = deWsr.getFilepath3();
		}else if(week == 4) {
			Filepath = deWsr.getFilepath4();
		}
		
		List<String> list = Arrays.asList(Filepath.split("\\s*,\\s*"));
	
		if(list.size() > 1){
		
			if (home.exists() && home.isDirectory()) {
				 logger.info("home is a directory");
				    if(path.equals(separator)){
					 	path="usr"+File.separator+"home"+File.separator+"Download";
					}
					else{
						path=File.separator+"usr"+File.separator+"home"+File.separator+"Download";
					}
				
					if (Files.isDirectory(Paths.get(home + path))) {
						if(path.equals(separator)){
							path="usr"+File.separator+"home"+File.separator+"Download"+File.separator+"infotravel";
						}
						else{
							path=File.separator+"usr"+File.separator+"home"+File.separator+"Download"+File.separator+"infotravel";
						}
						
						if (Files.isDirectory(Paths.get(home + path))) {
							if(path.equals(separator)){
								path="usr"+File.separator+"home"+File.separator+"Download"+File.separator+"infotravel"+File.separator;
							}
							else{
								path=File.separator+"usr"+File.separator+"home"+File.separator+"Download"+File.separator+"infotravel"+File.separator;
							}
							
						} 
					}
				
			}
			
			
		}
		else{
			try{
				File outputFile = new File(Filepath);
				Path file = Paths.get(outputFile+"");
			    response.addHeader("Content-Disposition", "attachment; filename="+file.getFileName());
			    Files.copy(file, response.getOutputStream());
			    response.getOutputStream().flush();
			}
			catch(FileNotFoundException fe){
				fe.printStackTrace();
			}
		}
	}
	
	
//    
    /**
     * This method is update row in moduleName entity
     * based on primaryKey Of Module Table 
     */
	
    @RequestMapping(value="/{deWsrId}",method=RequestMethod.PUT)
	 public DeWsr updateDeWsr(@RequestBody DeWsr deWsr,@PathVariable Integer deWsrId,HttpServletRequest request){
	
			try{
				 deWsr.setDeWsrId(deWsrId);
				 deWsrRepository.save(deWsr);
				 service.sendWsrNotification(deWsr, "update", request);
			}
			catch(Exception e){
				 logger.info(String.format("exception - ", e));
			}
		 return deWsr;
	 }
    
    /**
     * This method is get data for specific row in moduleName entity
     * based on primaryKey Of Module Table 
     */
	   @RequestMapping(value = "/{deWsrId}",method=RequestMethod.GET)
	    public DeWsr findDeWsrId(@PathVariable("deWsrId") Integer deWsrId){
	        return this.deWsrRepository.findOne(deWsrId);
	    }
	 
    
    /**
     * This method is delete data for specific row in moduleName entity
     * based on primaryKey Of Module Table 
     */	 
//	@RequestMapping(value="/{<primaryKeyOfModuleNameTable>}",method=RequestMethod.DELETE)
//	public void delete<ModuleName>(@PathVariable Integer <primaryKeyOfModuleNameTable>, HttpServletRequest request) {
//		// Authorization for XYZ role
//		if(service.isXYZ())
//		{
//			try{
//			repository.delete(<primaryKeyOfModuleNameTable>);
//			}
//			catch(Exception e){
//				 logger.info(String.format("exception - ", e));
//			}
//		}
//		else
//		{
//			service.sendTamperedMail("Module Name delete", 0, 0, request);
//		}		 
//	}
	
  
   
}
