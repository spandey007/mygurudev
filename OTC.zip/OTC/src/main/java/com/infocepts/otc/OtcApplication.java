package com.infocepts.otc;

import java.net.InetAddress;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Import;
import org.springframework.scheduling.annotation.EnableScheduling;

import com.infocepts.otc.db.OtcDbConfig;
import com.infocepts.otc.db.PmsDbConfig;

@Import({OtcDbConfig.class, PmsDbConfig.class})
@EnableScheduling
@SpringBootApplication
public class OtcApplication extends SpringBootServletInitializer {
	
	// This enum represents constants depicting host names for different environments.
	public enum Server {
		infobizdev,
		infobizstage2,
		infobiz,
	}
	
	/* This enum represents constants depicting profile names for different environments.
	 NOTE: Spring boot follows this pattern "application-{profile}.properties".
	 So if we create a properties file as "application-dev.properties" and set active profile as "dev" 
	 then spring boot will find "application-dev.properties" file in the classpath so we don't have to do any extra
	 work for that.
	 Should a new profile requires to be created then we'll have to make an entry for that in below enum.
	*/
	public enum Profile {
		local,
		dev,
		stage,
		prod,
	}
	
	private static final Logger OTC_LOGGER = Logger.getLogger(OtcApplication.class.getName());

	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
		setApplicationProfile();
		return super.configure(builder);
	}
	
	public static void main(String[] args) {
		setApplicationProfile();
		SpringApplication.run(OtcApplication.class);
	}

	/**
	 * This method will check the current host and based upon the host name we will activate the respective 
	 * profile. For ex. For dev environment, application-dev.properties will be loaded.
	 */
	private static void setApplicationProfile() {
		StringBuilder currentProfile = new StringBuilder("");
		InetAddress localHost = null;

		try {
			localHost = InetAddress.getLocalHost();
			String hostName = localHost.getHostName();
			if (Server.infobizdev.name().equalsIgnoreCase(hostName)) {
				currentProfile.append(Profile.dev.name());
			} else if (Server.infobizstage2.name().equalsIgnoreCase(hostName)) {
				currentProfile.append(Profile.stage.name());
			} else if (Server.infobiz.name().equalsIgnoreCase(hostName)) {
				currentProfile.append(Profile.prod.name());
			} else {
				currentProfile.append(Profile.local.name());
			}
			
			// This property is being set as a JVM argument.
			System.setProperty("spring.profiles.active", currentProfile.toString());
		} catch(Exception ex) {
			OTC_LOGGER.log(Level.SEVERE, "SOMETHING WENT WRONG WHILE SETTING SPRING PROFILES!\n", ex);
		}
	}
}
