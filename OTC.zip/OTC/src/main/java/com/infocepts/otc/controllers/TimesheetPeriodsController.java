package com.infocepts.otc.controllers;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.infocepts.otc.entities.TimesheetPeriods;
import com.infocepts.otc.repositories.TimesheetPeriodsRepository;
import com.infocepts.otc.services.TimesheetService;



@RestController
@RequestMapping(value="/tsperiod",headers="referer")//JV: Added 'headers' param to validate the url.
public class TimesheetPeriodsController {
	
	final Logger logger = Logger.getLogger(TimesheetPeriodsController.class);

	@Autowired
	TimesheetPeriodsRepository repository;
	
	@Autowired
	TimesheetService service;
	
	@PersistenceContext(unitName="otc")
    private EntityManager manager;
	
	@RequestMapping(method=RequestMethod.GET)
	public List<TimesheetPeriods> getTimesheetPeriods(@RequestParam(value = "state", defaultValue = "false") Boolean state,
			@RequestParam(value = "tsyear", defaultValue = "") String tsyear,
			@RequestParam(value = "tsmonth", defaultValue = "") String tsmonth) {
		List<TimesheetPeriods> timesheetperiodslist=null;
		try{
			
			if(!tsmonth.equals("")) // for all open periods
			{	
				Integer month=service.getMonth(tsmonth);
				Integer year=service.getYear(tsmonth);
				if(month != null && year != null)
				{	
					timesheetperiodslist = manager.createNamedQuery("getPeriodsForMonth", TimesheetPeriods.class)
												.setParameter("year", year)
												.setParameter("month", month)
												.getResultList();
				}				
			}
			else if (!tsyear.equals("")) { //To get all the periods for a particular Year
				
				timesheetperiodslist = manager.createNamedQuery("getPeriodsForYear", TimesheetPeriods.class)
									   .setParameter("year", tsyear)
									   .getResultList();

			} //End of: To get all the periods for a particular Year
			else{
				timesheetperiodslist=repository.findAllPeriodsByStatus(state);
			}
		}
		catch(Exception e){
			logger.error(e);
		}
		return timesheetperiodslist;
	}
	
	@RequestMapping(value="/{id}",method=RequestMethod.GET)
	 public TimesheetPeriods getTimesheetByPeriodId(@PathVariable Integer id) {
		TimesheetPeriods period = null;
		try{
			period = repository.findOne(id);
		}
		catch(Exception e){
			logger.error(e);
		}
		return period;
	 }
	
	@RequestMapping(method=RequestMethod.POST)
	public TimesheetPeriods addTimesheetPeriods(@RequestBody TimesheetPeriods tsperiod) {
		try{
			if(service.isPmo()){
				repository.save(tsperiod);
			}
		}catch(Exception e){
			logger.error(e);
		}
		return tsperiod;
	}
	
	@RequestMapping(value="/{id}",method=RequestMethod.PUT)
	public TimesheetPeriods updateTimesheetPeriods(@PathVariable Integer id,@RequestBody TimesheetPeriods utsperiod) {
		try{
			if(service.isPmo()){
				repository.save(utsperiod);
			}
		}catch(Exception e){
			logger.error(e);
		}
		return utsperiod;
	}
	
	@RequestMapping(value="/{id}",method=RequestMethod.DELETE)
	public void deleteTimesheetPeriods(@PathVariable Integer id) {
		try{
			if(service.isPmo()){
				repository.delete(id);
			}
		}
		catch(Exception e){
			 logger.error(e);
		}
	}
}
