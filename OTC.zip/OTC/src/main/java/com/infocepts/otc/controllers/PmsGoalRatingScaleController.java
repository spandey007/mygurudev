/**
* Filename: /src/main/java/com/infocepts/otc/controllers/PmsGoalRatingScaleController.java
* @author  SRA
* @version 1.0
* @since   2018-11-13 
*/

package com.infocepts.otc.controllers;

import java.util.logging.Logger;
import com.infocepts.pms.entities.PmsGoalRatingScale;
import com.infocepts.pms.repositories.PmsGoalRatingScaleRepository;
import com.infocepts.otc.services.TimesheetService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.mail.MessagingException;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import java.util.List;

@RestController
@RequestMapping(value="/api/pms/goalRatingScale", headers="referer")
public class PmsGoalRatingScaleController {

    final Logger logger = Logger.getLogger(PmsGoalRatingScaleController.class.getName());

    @Autowired
    PmsGoalRatingScaleRepository repository;
    
    @Autowired
    HttpSession session;

    @PersistenceContext(unitName = "pms") 
    private EntityManager manager;
			
	@Autowired
	TimesheetService service;

	/**
   * This method is used to find results set from module entity
   * based on params passed from JS file
   */
    @RequestMapping(method = RequestMethod.GET)
    public List<PmsGoalRatingScale> findAllPmsGoalRatingScale(HttpServletRequest request){
        List<PmsGoalRatingScale> pmsGoalRatingScaleList = null;
        //Integer loggedInUid = (Integer) session.getAttribute("loggedInUid");
        
        try {
        	/* ------------------------- Authorization start ------------------------------------ */
        	// Authorization for all the associates hence no check
//			if(!service.isHRPms())
//			{
//				service.sendTamperedMail("PmsGoalRatingScale view all", 0, 0, request);
//				return pmsGoalRatingScaleList;
//			}
			/* ------------------------- Authorization ends ------------------------------------ */
			pmsGoalRatingScaleList = manager.createNamedQuery("getAllGoalRatingScales", PmsGoalRatingScale.class)   
                        .getResultList();
					
         } 
		catch (Exception e){
			 logger.info(String.format("exception - ", e.getMessage()));
        }
        return pmsGoalRatingScaleList;

    }
    
    /**
     * This method is add row in moduleName entity
     * 
     */
    @RequestMapping(method=RequestMethod.POST)
	public PmsGoalRatingScale addPmsGoalRatingScale(@RequestBody PmsGoalRatingScale pmsGoalRatingScale, HttpServletRequest request) throws MessagingException {
		// Authorization for XYZ role
		if(service.isHRPms() || service.isHRPmsAdmin())
		{
			try{
				pmsGoalRatingScale.setGoalRatingScaleId(null);
				repository.save(pmsGoalRatingScale);
			}
			catch(Exception e){
				logger.info(String.format("exception - ", e.getMessage()));
			}
		}
		else 
		{
			service.sendTamperedMail("PmsGoalRatingScale Save", 0, 0, request);
		}
		
		return pmsGoalRatingScale;
	}
    
    /**
     * This method is update row in moduleName entity
     * based on primaryKey Of Module Table 
     */
    @RequestMapping(value="/{goalRatingScaleId}",method=RequestMethod.PUT)
	 public PmsGoalRatingScale updatePmsGoalRatingScale(@RequestBody PmsGoalRatingScale updatedPmsGoalRatingScale,@PathVariable Integer goalRatingScaleId,HttpServletRequest request) throws MessagingException{
        // Authorization for XYZ role
		if(service.isHRPms() || service.isHRPmsAdmin())
		{	
			try{
				 updatedPmsGoalRatingScale.setGoalRatingScaleId(goalRatingScaleId);
				 repository.save(updatedPmsGoalRatingScale);
			}
			catch(Exception e){
				logger.info(String.format("exception - ", e.getMessage()));
			}
		}
		else
		{
			service.sendTamperedMail("PmsGoalRatingScale Save", 0, 0, request);
		}
		 return updatedPmsGoalRatingScale;
	 }
    
    /**
     * This method is get data for specific row in moduleName entity
     * based on primaryKey Of Module Table 
     */
    @RequestMapping(value="/{goalRatingScaleId}",method=RequestMethod.GET)
	 public PmsGoalRatingScale getPmsGoalRatingScale(@PathVariable Integer goalRatingScaleId, HttpServletRequest request) throws MessagingException{
    	
    	PmsGoalRatingScale pmsGoalRatingScale = null;
		// Authorization for XYZ role
		if(service.isHRPms() || service.isHRPmsAdmin())
		{
			try{
			
				pmsGoalRatingScale = manager.createNamedQuery("getGoalRatingScaleById", PmsGoalRatingScale.class)
						 .setParameter("goalRatingScaleId", goalRatingScaleId)
						 .getSingleResult();
			 }
			 catch(Exception e){
				 logger.info(String.format("exception - ", e.getMessage()));
			 }
		}
		else 
		{
			service.sendTamperedMail("PmsGoalRatingScale Get", 0, 0, request);
		}
		 
		 return pmsGoalRatingScale;
	 }
	 
    
    /**
     * This method is delete data for specific row in moduleName entity
     * based on primaryKey Of Module Table 
     */	 
	@RequestMapping(value="/{goalRatingScaleId}",method=RequestMethod.DELETE)
	public void deletePmsGoalRatingScale(@PathVariable Integer goalRatingScaleId, HttpServletRequest request)  throws MessagingException {
		// Authorization for XYZ role
		if(service.isHRPms() || service.isHRPmsAdmin())
		{
			try{
			repository.delete(goalRatingScaleId);
			}
			catch(Exception e){
				logger.info(String.format("exception - ", e.getMessage()));
			}
		}
		else
		{
			service.sendTamperedMail("PmsGoalRatingScale Delete", 0, 0, request);
		}		 
	}
	
  
   
}
