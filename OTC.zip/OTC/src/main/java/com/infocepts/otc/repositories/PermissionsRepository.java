package com.infocepts.otc.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.infocepts.otc.entities.Permissions;



public interface PermissionsRepository extends JpaRepository<Permissions,Integer>{

	@Override
	public List<Permissions> findAll();

	@Query("select p from Permissions p where p.permissionsId=:permissionsId")
	public List<Permissions> findPermissionsByPermissionsId(@Param("permissionsId") Integer permissionsId);
	
	
	@Query("select p from Permissions p where p.url.url=:url and p.status = true")
	public List<Permissions> findActivePermissionsByUrl(@Param("url") String url);
	
	@Query("select p from Permissions p where p.status = true")
	public List<Permissions> findActivePermissions();
}
