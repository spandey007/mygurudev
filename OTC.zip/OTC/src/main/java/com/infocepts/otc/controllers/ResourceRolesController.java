package com.infocepts.otc.controllers;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.infocepts.otc.entities.ResourceRoles;
import com.infocepts.otc.repositories.ResourceRolesRepository;
import com.infocepts.otc.services.TimesheetService;



@RestController
@RequestMapping(value="/resourceroles",headers="referer")//JV: Added 'headers' param to validate the url.
public class ResourceRolesController {
	
	final Logger logger = Logger.getLogger(ResourceRolesController.class);

	@Autowired
	ResourceRolesRepository repository;
	
	@Autowired
	HttpSession session;
	
	@Autowired
	TimesheetService service;
	
	@RequestMapping(method=RequestMethod.POST)
	public ResourceRoles addResourceRole(@RequestBody ResourceRoles resourceRoles,
										HttpServletRequest request){
		try{
			/* ------------------------- Authorization start ------------------------------------ */
			// Authorization for admin role
			if(!service.isAdmin())
			{
				service.sendTamperedMail("Resource Roles Add", 0, 0, request);
				return resourceRoles;
			}
			/* ------------------------- Authorization ends ------------------------------------ */
			
			resourceRoles.setResourceRoleId(null);
			repository.save(resourceRoles);
		 }
		 catch(Exception e){
			logger.error(e);
		 }
		return resourceRoles;
	}
	
	@RequestMapping(method=RequestMethod.GET)
	public List<ResourceRoles> findResourcesRoles(@RequestParam(value = "uid", defaultValue = "0") Integer uid,
			@RequestParam(value = "roleId", defaultValue = "0") Integer roleId,
			HttpServletRequest request){
		List<ResourceRoles> resourceroleslist=null;
		try{
			/* ------------------------- Authorization start ------------------------------------ */
			Integer loggedInUid = (Integer) session.getAttribute("loggedInUid");
			// Authorization for admin role
			if(!service.isAdmin())
			{
				service.sendTamperedMail("Resource Roles View All", 0, 0, request);
				return resourceroleslist;
			}
			/* ------------------------- Authorization ends ------------------------------------ */
			
			if(uid != 0)
			 {
				resourceroleslist = repository.findResourceRoles(uid);
			 }
			 else if(roleId != 0){
				 logger.info("get count");
				 resourceroleslist = repository.findRoleAssignmentCount(roleId);
			 }
			 else
			 {
				 resourceroleslist = repository.findAllActiveResourceRoles();
			 }
		}
		catch(Exception e){
			logger.error(e);
		}
		return resourceroleslist;
	}
	
	@RequestMapping(value="/{resourceRoleId}",method=RequestMethod.GET)
	public List<ResourceRoles> findResourcesRolesByUser(@PathVariable(value="resourceRoleId") Integer resourceRoleId){
		List<ResourceRoles> resourceroleslist=null;
		try{
			resourceroleslist = repository.findResourceRoles(resourceRoleId);
		}catch(Exception e){
			logger.error(e);
		}
		return resourceroleslist;
	}
	
	@RequestMapping(value="/{resourceRoleId}",method=RequestMethod.PUT)
	public ResourceRoles updateResource(@PathVariable Integer resourceRoleId,@RequestBody ResourceRoles updatedRoles,
										HttpServletRequest request){
		try{			
			/* ------------------------- Authorization start ------------------------------------ */
			Integer loggedInUid = (Integer) session.getAttribute("loggedInUid");
			// Authorization for admin role
			if(service.isAdmin())
			{
				updatedRoles.setResourceRoleId(resourceRoleId);
				repository.save(updatedRoles);
			}
			else
			{
				service.sendTamperedMail("Resource Roles update", 0, 0, request);
			}
			/* ------------------------- Authorization ends ------------------------------------ */
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		return updatedRoles;
		
	}
	
	 @RequestMapping(value="/{resourceRoleId}",method=RequestMethod.DELETE)
	 public void deleteResourceRoles(@PathVariable Integer resourceRoleId,
			 						HttpServletRequest request){
		 try{
			/* ------------------------- Authorization start ------------------------------------ */
			Integer loggedInUid = (Integer) session.getAttribute("loggedInUid");
			// Authorization for admin role
			if(service.isAdmin())
			{
				repository.delete(resourceRoleId);
			}
			else
			{
				service.sendTamperedMail("Resource Roles Delete", 0, 0, request);
			}
			/* ------------------------- Authorization ends ------------------------------------ */			
		 }
		 catch(Exception e){
			logger.error(e);
		 }
	}	 
}
