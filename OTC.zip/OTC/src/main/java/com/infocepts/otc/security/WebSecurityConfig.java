package com.infocepts.otc.security;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;

import java.util.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.annotation.web.configurers.ExpressionUrlAuthorizationConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.ldap.authentication.ad.ActiveDirectoryLdapAuthenticationProvider;
import org.springframework.security.web.session.HttpSessionEventPublisher;

import com.infocepts.otc.entities.Permissions;
import com.infocepts.otc.repositories.PermissionsRepository;

@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled=true)
public class WebSecurityConfig extends WebSecurityConfigurerAdapter{

	@Value("${spring.ldap.domain}")
	private String domain;
	
	@Value("${spring.ldap.url}")
	private String url;
	
	@Autowired
	LdapUserDetailsMapper userDetailsContextMapper;
	
	@Autowired
	PermissionsRepository permissionsrepository;

	@Autowired
	AuthFailureHandler authFailureHandler;
	
	@Autowired
	AuthSuccessHandler successHandler;
	
	
	 @Autowired
	 private CustomAuthenticationProvider authProvider;
	 
	String loginUrl="/login";
	
	private static final Logger log = Logger.getLogger(WebSecurityConfig.class.getName());

    public void showConfig(HttpSecurity http) throws Exception{
		log.info("inside showConfig");
		// Create a map with key => url and value as list of roles
				Map<String, List<String>> map = new HashMap<String, List<String>>();
				
				// Retrieve all the permissions urls
				List<Permissions> listPermissions = permissionsrepository.findActivePermissions();
				if(listPermissions.size() > 0) {
					ListIterator iterator = listPermissions.listIterator();
					while(iterator.hasNext())
					{
						Permissions permission = (Permissions)iterator.next();				
						String mapKey = permission.getUrl().getUrl();
					    if (!map.containsKey(mapKey)) {
					    	List<String> list = new ArrayList<>();
					    	list.add(permission.getRoles().getRole());
					        map.put(mapKey, list);
					    }
					    else{
					    	List<String> urlList = map.get(mapKey);
					    	urlList.add(permission.getRoles().getRole());
					    }
					}
				}		
				
				log.info(map.toString());
			    
			    ExpressionUrlAuthorizationConfigurer<HttpSecurity>.ExpressionInterceptUrlRegistry httpsecurity = http.authorizeRequests();
			    
			    // Generic antMatchers here
			    httpsecurity.antMatchers("/login**").permitAll();
			    httpsecurity.antMatchers("/").access("hasRole('MEMBER')");
			    httpsecurity.antMatchers("/help/**").access("hasRole('MEMBER')");
			    httpsecurity.antMatchers("/permissions/**").access("hasRole('ADMIN')");
	
			    //not required as all other urls will be visible to MEMBER role
			    //httpsecurity.antMatchers("/timesheet/**").access("hasRole('MEMBER')");
			   
			    httpsecurity.antMatchers("/sessionExpired").permitAll();
			    httpsecurity.antMatchers("/invalidSession").permitAll();
			    
			     for(Map.Entry<String, List<String>> entry : map.entrySet()) {
					  String key 		= entry.getKey();
					  String urlSuffix 	= "/**";
					  key				= key.concat(urlSuffix);
					  List<String> val 	= entry.getValue();
					  String[] publicURL = val.toArray(new String[val.size()]);
					  log.info(publicURL.toString());
                      
					httpsecurity.antMatchers(key).hasAnyRole(publicURL);
              }	   

    
			  // JV: code for session management			  
		       httpsecurity.anyRequest().authenticated()
		      .and()
		      		.formLogin().loginPage(loginUrl).permitAll()
		      		.usernameParameter("username").passwordParameter("password").defaultSuccessUrl("/")
		      		.successHandler(successHandler)//changes to be done here during maintenance
		      		.failureHandler(authFailureHandler) 
		      .and()
		      		.logout()
		      		.logoutUrl("/logout").logoutSuccessUrl("/login")	
		      		.deleteCookies("JSESSIONID", "SESSION")
		      		.invalidateHttpSession(true)
		      .and()
		      		.csrf().disable()
		      		.sessionManagement()
		      		.sessionFixation().migrateSession()
		      		.sessionCreationPolicy(SessionCreationPolicy.IF_REQUIRED)
		      		.maximumSessions(1)
		      		.expiredUrl("/sessionExpired");
	        /* .and()
	         .invalidSessionUrl("/invalidSession");*/

    }

	@Override
	protected void configure(HttpSecurity http) throws Exception {
		log.info("http is:"+http);
    	showConfig(http);
    }
	
	
	@Override
    public void configure(WebSecurity web) throws Exception {
        web
                .ignoring()
                .antMatchers("/images/**");
    }
	

	@Autowired
	protected void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {
		auth.authenticationProvider(authProvider); // JV calling the custom auth Provided to check the access lock
		auth.authenticationProvider(activeDirectoryLdapAuthenticationProvider());
	}
	
	@Bean
	public AuthenticationProvider activeDirectoryLdapAuthenticationProvider() {
	    ActiveDirectoryLdapAuthenticationProvider authenticationProvider = 
	        new ActiveDirectoryLdapAuthenticationProvider(domain, url);
	    
	    authenticationProvider.setSearchFilter("mail={0}"); // rkj 14 June - to fix LDAP authentication issue faced by Pankaj with proxy settting in AD 
	    authenticationProvider.setConvertSubErrorCodesToExceptions(true);
	    authenticationProvider.setUseAuthenticationRequestCredentials(true);
	    authenticationProvider.setUserDetailsContextMapper(userDetailsContextMapper);
	    return authenticationProvider;
	}
	
	//Session Management
	@Bean
		public HttpSessionEventPublisher httpSessionEventPublisher() {
			return new HttpSessionEventPublisher();
		}

}
	
