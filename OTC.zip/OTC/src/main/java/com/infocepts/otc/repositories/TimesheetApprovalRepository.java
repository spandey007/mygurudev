package com.infocepts.otc.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.infocepts.otc.entities.TimesheetApproval;

@Repository
public interface TimesheetApprovalRepository extends JpaRepository<TimesheetApproval,Integer>{
	
	@Override
	public List<TimesheetApproval> findAll();
}
