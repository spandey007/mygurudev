package com.infocepts.otc.repositories;

import java.util.Date;
import java.util.List;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import com.infocepts.otc.entities.Treq;

public interface TreqRepository extends CrudRepository<Treq,Integer>{

	@Override
	public List<Treq> findAll();
	
	@Query("from Treq where status = :status and modifiedDate = :modifiedDate")
	public List<Treq> findByStatus(@Param("status") String status,@Param("modifiedDate") Date modifiedDate);
	
	@Query("from Treq where movedToHiringOn is not null and status != :status")
	public List<Treq> findInactiveHiringTreqs(@Param("status") String status);
}
