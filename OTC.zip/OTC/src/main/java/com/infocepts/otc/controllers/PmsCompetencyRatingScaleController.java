/**
* Filename: /src/main/java/com/infocepts/otc/controllers/PmsCompetencyRatingScaleController.java
* @author  SRA
* @version 1.0
* @since   2018-11-13 
*/

package com.infocepts.otc.controllers;

import java.util.logging.Logger;
import com.infocepts.pms.entities.PmsCompetencyRatingScale;
import com.infocepts.pms.repositories.PmsCompetencyRatingScaleRepository;
import com.infocepts.otc.services.TimesheetService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.mail.MessagingException;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import java.util.List;

@RestController
@RequestMapping(value="/api/pms/competencyRatingScale", headers="referer")
public class PmsCompetencyRatingScaleController {

    final Logger logger = Logger.getLogger(PmsCompetencyRatingScaleController.class.getName());

    @Autowired
    PmsCompetencyRatingScaleRepository repository;
    
    @Autowired
    HttpSession session;

    @PersistenceContext(unitName = "pms") 
    private EntityManager manager;
			
	@Autowired
	TimesheetService service;

	/**
   * This method is used to find results set from module entity
   * based on params passed from JS file
   */
    @RequestMapping(method = RequestMethod.GET)
    public List<PmsCompetencyRatingScale> findAllPmsCompetencyRatingScale(HttpServletRequest request){
        List<PmsCompetencyRatingScale> pmsCompetencyRatingScaleList = null;
        //Integer loggedInUid = (Integer) session.getAttribute("loggedInUid");
        
        try 
        {        
				
			pmsCompetencyRatingScaleList = manager.createNamedQuery("getAllCompetencyRatingScales", PmsCompetencyRatingScale.class)   
	                        .getResultList();
				
			
        }
		catch (Exception e){
			 logger.info(String.format("exception - ", e.getMessage()));
        }
			
		return pmsCompetencyRatingScaleList;
}
					
    
    /**
     * This method is add row in moduleName entity
     * 
     */
    @RequestMapping(method=RequestMethod.POST)
	public PmsCompetencyRatingScale addPmsCompetencyRatingScale(@RequestBody PmsCompetencyRatingScale pmsCompetencyRatingScale, HttpServletRequest request) throws MessagingException {
		// Authorization for XYZ role
		if(service.isHRPms() || service.isHRPmsAdmin())
		{
			try{
				pmsCompetencyRatingScale.setcompetencyRatingScaleId(null);
				repository.save(pmsCompetencyRatingScale);
			}
			catch(Exception e){
				 logger.info(String.format("exception - ", e));
			}
		}
		else 
		{
			service.sendTamperedMail("PmsCompetencyRatingScale Save", 0, 0, request);
		}
		
		return pmsCompetencyRatingScale;
	}
    
    /**
     * This method is update row in moduleName entity
     * based on primaryKey Of Module Table 
     */
    @RequestMapping(value="/{competencyRatingScaleId}",method=RequestMethod.PUT)
	 public PmsCompetencyRatingScale updatePmsCompetencyRatingScale(@RequestBody PmsCompetencyRatingScale updatedPmsCompetencyRatingScale,@PathVariable Integer competencyRatingScaleId,HttpServletRequest request) throws MessagingException{
        // Authorization for XYZ role
		if(service.isHRPms() || service.isHRPmsAdmin())
		{	
			try{
				 updatedPmsCompetencyRatingScale.setcompetencyRatingScaleId(competencyRatingScaleId);
				 repository.save(updatedPmsCompetencyRatingScale);
			}
			catch(Exception e){
				 logger.info(String.format("exception - ", e));
			}
		}
		else
		{
			service.sendTamperedMail("PmsCompetencyRatingScale Save", 0, 0, request);
		}
		 return updatedPmsCompetencyRatingScale;
	 }
    
    /**
     * This method is get data for specific row in moduleName entity
     * based on primaryKey Of Module Table 
     */
    @RequestMapping(value="/{competencyRatingScaleId}",method=RequestMethod.GET)
	 public PmsCompetencyRatingScale getPmsCompetencyRatingScale(@PathVariable Integer competencyRatingScaleId, HttpServletRequest request) throws MessagingException{
    	
    	PmsCompetencyRatingScale pmsCompetencyRatingScale = null;
		// Authorization for XYZ role
		if(service.isHRPms() || service.isHRPmsAdmin())
		{
			try{
				pmsCompetencyRatingScale = manager.createNamedQuery("getCompetencyRatingScaleById", PmsCompetencyRatingScale.class)
						 .setParameter("competencyRatingScaleId", competencyRatingScaleId)
						 .getSingleResult();
			 }
			 catch(Exception e){
				 logger.info(String.format("exception - ", e));
			 }
		}
		else 
		{
			service.sendTamperedMail("PmsCompetencyRatingScale Get", 0, 0, request);
		}
		 
		 return pmsCompetencyRatingScale;
	 }
	 
    
    /**
     * This method is delete data for specific row in moduleName entity
     * based on primaryKey Of Module Table 
     */	 
	@RequestMapping(value="/{competencyRatingScaleId}",method=RequestMethod.DELETE)
	public void deletePmsCompetencyRatingScale(@PathVariable Integer competencyRatingScaleId, HttpServletRequest request)  throws MessagingException {
		// Authorization for XYZ role
		if(service.isHRPms() || service.isHRPmsAdmin())
		{
			try{
			repository.delete(competencyRatingScaleId);
			}
			catch(Exception e){
				 logger.info(String.format("exception - ", e));
			}
		}
		else
		{
			service.sendTamperedMail("PmsCompetencyRatingScale Delete", 0, 0, request);
		}		 
	}
	
  
   
}
