package com.infocepts.otc.controllers;


import com.infocepts.otc.entities.Gtp;
import com.infocepts.otc.repositories.GtpRepository;
import com.infocepts.otc.utilities.DateConverter;

import java.util.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpSession;


import java.text.ParseException;
import java.util.Date;
import java.util.List;

@RestController
@RequestMapping(value="/gtp",headers="referer")
public class GtpController {

    final Logger logger = Logger.getLogger(GtpController.class.getName());

    @Autowired
    GtpRepository repository;

    
    @Autowired
    HttpSession session;

    @PersistenceContext(unitName = "otc")
    private EntityManager manager;

    @RequestMapping(method = RequestMethod.GET)
    public List<Gtp> findGtpResources(@RequestParam(value = "gtpId", defaultValue = "") Integer gtpId
            						,@RequestParam(value = "currentDate", defaultValue = "") String currentDate
            						,@RequestParam(value = "previousDate", defaultValue = "") String previousDate
            						,@RequestParam(value = "copy", defaultValue = "1") Integer copy) throws ParseException{
        List<Gtp> gtpResourcelist = null;
        Integer loggedInUid = (Integer) session.getAttribute("loggedInUid");
        
        logger.info("--------------------in GTP controller------------------");		
		logger.info("currentDate="+currentDate);
		
        try {
        	
        	if (currentDate != null) {
				    	
        		//check if data is present in table for current date		
        		gtpResourcelist = manager.createNamedQuery("isDataPresentForGtpDate", Gtp.class)                        
                        .setParameter("gtpDate", currentDate)
                        .getResultList();
        		
        		int retval = gtpResourcelist.size();
        	    logger.info("No of GTP resource for current Date = " + retval); 
        	     
        		//if data for current date is not present, copy from previous date
        		if(copy == 1){
        		
        				//get data for a date where data is available in GTP table(if not present in previous date..take a date previous to it..and so on..)
        				gtpResourcelist = manager.createNamedQuery("getGtpResourcesFromLastDate", Gtp.class)                        
                                          .getResultList();
        				
        				int retval1 = gtpResourcelist.size();
               	     	logger.info("No of GTP resource for last Date = " + retval1); 
               	     	
        				//loop over data
						for (Gtp user : gtpResourcelist)
						{		
							Date formattedCurrentDate = null;
							int proposedDays = 0; String proposedDaysCateg = null;
														
			        		//convert String to Date dataType so as to save in table	        		
					    	formattedCurrentDate = DateConverter.convertStringToDate(currentDate);
					    	
						    if(formattedCurrentDate != null && user.getProposedDate() != null){
								proposedDays = (int) DateConverter.daysBetween(formattedCurrentDate, user.getProposedDate());
							    
							    //user.setProposedDays(proposedDays);
							    if(proposedDays <= 15) {proposedDaysCateg = "0-15 Days";}
							    else if(proposedDays > 15) {proposedDaysCateg = "15+ Days";}
							    
							} else {
								proposedDays = 0;
								proposedDaysCateg = null;
							}
						    
						    //While copying update gtpDate to current Date and other columns(last Alc columns/Gtp Days/Gtp Categ/Availability/)
						    user.setLastAlcProjectId(user.getLastAlcProjectId());	
						    user.setLastAlcAccountId(user.getLastAlcAccountId());	
						    user.setLastAlcDate(user.getLastAlcDate());	
						    user.setGtpDays(user.getGtpDays());	
						    user.setGtpDaysCateg(user.getGtpDaysCateg());	
						    user.setAvailability(user.getAvailability());
						    
							user.setGtpDate(formattedCurrentDate);
							
							user.setDeployableStatus(user.getDeployableStatus());
							user.setResourceStatus(user.getResourceStatus());
							user.setProposedDate(user.getProposedDate());
							
							user.setProposedDays(proposedDays);
							user.setProposedDaysCateg(proposedDaysCateg);
							
							user.setProposedAccountId(user.getProposedAccountId());
							user.setConfirmedDate(user.getConfirmedDate());
							user.setBillingStartDate(user.getBillingStartDate());
							user.setGtpRemarks(user.getGtpRemarks());
							//if(user.getBucketId() == null)
							//{
							//	int defaultBucketId = 11;
							//	user.setBucketId(defaultBucketId);	
							//	user.setBucket("NB_POOL");
							//}
							//else
							//{
								//user.setBucketId(user.getBucketId());// set NB_POOL (bucketId = 11) as default
								logger.info("getDeployableStatus"+ user.getDeployableStatus());
								logger.info("getResourceStatus"+user.getResourceStatus());
								
								if("Deployable".equals(user.getDeployableStatus()) && ("Available".equals(user.getResourceStatus()) || "Proposed".equals(user.getResourceStatus()) || "Aligned Account".equals(user.getResourceStatus()))){
									user.setBucketId(11);	
									user.setBucket("NB_POOL");
								}
								if("Non-Deployable".equals(user.getDeployableStatus()) && "Earmarked".equals(user.getResourceStatus())){					
									user.setBucketId(13);	
									user.setBucket("NB_INDENTOPP");
								}
								if("Non-Deployable".equals(user.getDeployableStatus()) && ("Confirmed".equals(user.getResourceStatus()) || "Awaiting SOW Extension".equals(user.getResourceStatus()))){
									user.setBucketId(2);	
									user.setBucket("B_Risk");
								}
								if("Non-Deployable".equals(user.getDeployableStatus()) && ("Resigned".equals(user.getResourceStatus()) || "Absconded".equals(user.getResourceStatus()))){
									user.setBucketId(7);	
									user.setBucket("NB_Resigned");
								}
								if("Non-Deployable".equals(user.getDeployableStatus()) && "PIP".equals(user.getResourceStatus())) {
									user.setBucketId(25);	
									user.setBucket("NB_PERFCASE");
								}
								if("Non-Deployable".equals(user.getDeployableStatus()) && "Training".equals(user.getResourceStatus())) {
									user.setBucketId(24);	
									user.setBucket("NB_TRAINING");
								}
								if("Non-Deployable".equals(user.getDeployableStatus()) && ("LL/ML".equals(user.getResourceStatus()) || "Sabbatical Leave".equals(user.getResourceStatus()))){
									user.setBucketId(16);	
									user.setBucket("OH_LongLeave");
								}									
							//} 							
							
							user.setModifiedBy(loggedInUid);
							user.setModifiedDate(new Date());	
							
							//check if uid is present in table for gtp date date    
							List<Gtp> gtpResourceForDate =  manager.createNamedQuery("isUidPresentForGtpDate", Gtp.class)                        
															.setParameter("gtpDate", currentDate)
															.setParameter("uid", user.getUid())
															.getResultList();
							
			        		int isPresentVal = gtpResourceForDate.size();

							if(isPresentVal == 0){ // add uid only if not present for gtpDate	
								logger.info("Adding user= "+user.getUid()); 
								addGtp(user);	
								logger.info("============================================== "); 
							}
							
						}
        		}
        	}
			
         } 
		catch (Exception e){
			 logger.info(String.format("exception - ", e));
        }
        return gtpResourcelist;

    }
    
    @RequestMapping(method=RequestMethod.POST)
	public Gtp addGtp(@RequestBody Gtp user) {
		try{
			user.setGtpId(null);
			repository.save(user);
		}
		catch(Exception e){
			 logger.info(String.format("exception - ", e));
		}
		return user;
	}
    
    @RequestMapping(value="/{gtpId}",method=RequestMethod.PUT)
	 public Gtp updateGtp(@RequestBody Gtp updatedGtp,@PathVariable Integer gtpId){
    	 
 		logger.info("gtpId"+gtpId);
    	
		 try{
			 updatedGtp.setGtpId(gtpId);
			 repository.save(updatedGtp);
		 }
		 catch(Exception e){
			 logger.info(String.format("exception - ", e));
		 }
		 return updatedGtp;
	 }
    
    @RequestMapping(value="/{gtpId}",method=RequestMethod.GET)
	 public List<Gtp> getGtp(@PathVariable Integer gtpId){
    	
    	List<Gtp> gtp=null;
		 try{
			 gtp = manager.createNamedQuery("getGtpResourceById", Gtp.class)
                     .setParameter("gtpId", gtpId)
                     .getResultList();
		 }
		 catch(Exception e){
			 logger.info(String.format("exception - ", e));
		 }
		 return gtp;
	 }
	
  
   
}
