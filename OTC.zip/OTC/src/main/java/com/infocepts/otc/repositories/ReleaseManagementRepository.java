/**
* Filename: /src/main/java/com/infocepts/otc/repositories/ReleaseManagementRepository.java
* @author  Anjali S. Kalbande
* @version 1.0
* @since   2018-01-08 
*/

package com.infocepts.otc.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import com.infocepts.otc.entities.ReleaseManagement;

public interface ReleaseManagementRepository extends JpaRepository<ReleaseManagement,Integer>{

	@Override
	public List<ReleaseManagement> findAll();
	
	@Query("from ReleaseManagement where releaseId = :releaseId")
	public ReleaseManagement findReleaseManagementByreleaseId(@Param(value = "releaseId") Integer releaseId);
	
}
