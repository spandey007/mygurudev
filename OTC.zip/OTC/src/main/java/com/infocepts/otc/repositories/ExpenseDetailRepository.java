/**
 * 
 */
package com.infocepts.otc.repositories;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.persistence.EntityManager;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.infocepts.otc.entities.ExpenseDetail;
import com.infocepts.otc.utilities.LoadConstant;
import com.infocepts.otc.utilities.UniqueArrayList;

/**
 * @author Rewatiraman Singh
 *
 */

@Repository
public interface ExpenseDetailRepository extends JpaRepository<ExpenseDetail, Integer> {
	
	public static final Logger LOGGER = Logger.getLogger(ExpenseDetailRepository.class.getName());
	
	@Query("FROM ExpenseDetail WHERE expenseId = :expenseId")
	public List<ExpenseDetail> findExpenseDetailByExpenseId (@Param("expenseId") Integer expenseId);
	
	
	/* This method will fetch the expense details containing string values for resource name, purpose type name, purpose name,
	 * category name etc. which are transient fields.
	*/
	@SuppressWarnings("unchecked")
	default List<ExpenseDetail> findFormattedExpenseDetailByExpenseId (EntityManager manager, Integer expenseId) {
		List<ExpenseDetail> approvalList = new ArrayList<>();
		String queryString = "select ed.*, ep.purposeName, ec.categoryName, c.code as currencyCode"
				+ " from " + LoadConstant.otc + ".[dbo].[expenseDetail] ed"
				+ " inner join " + LoadConstant.infomaster + ".[dbo].[expenseCategory] ec on ec.expenseCategoryId = ed.expenseCategoryId"
				+ " inner join " + LoadConstant.infomaster + ".[dbo].[expensePurpose] ep on ep.purposeId = ed.purposeId"
				+ " inner join " + LoadConstant.infomaster + ".[dbo].[currency] c on c.currencyId = ed.currencyId"
				+ " where ed.expenseId = :expenseId";
		
		try {
			List<Object[]> resultList = manager.createNativeQuery(queryString, "expenseClaims")
					.setParameter("expenseId", expenseId)
					.getResultList();
			for (Object[] object : resultList) {
				ExpenseDetail expenseDetail = (ExpenseDetail) object[0];
				expenseDetail.setPurposeName((String) object[1]);
				expenseDetail.setCategoryName((String) object[2]);
				expenseDetail.setCurrencyCode((String) object[3]);
				approvalList.add(expenseDetail);
			}
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, "SOMETHING WENT WRONG WHILE FETCHING APPROVAL LIST WITH EXPENSE ID: " + expenseId, e);
		}
		return approvalList;
	}
	
	@SuppressWarnings("unchecked")
	default List<Integer> fetchProjectOwners(EntityManager manager, Integer projectId) {
		List<Integer> owners = new UniqueArrayList<>();
		String queryString = "select p.projectManagersId, ac.ahId, ac.dmId from "
				+ LoadConstant.infomaster + ".[dbo].[accounts] ac"
				+ " inner join " + LoadConstant.infomaster + ".[dbo].[project] p on p.accountId = ac.itemId"
				+ " where p.itemId = :projectId";
		if (projectId != null && projectId > 0) {
			List<Object[]> resultList = manager.createNativeQuery(queryString, "fetchProjectOwners")
					.setParameter("projectId", projectId)
					.getResultList();
			resultList.forEach(obj -> {
				Integer projectManagersId = (Integer) obj[0];
				Integer ahId = (Integer) obj[1];
				Integer dmId = (Integer) obj[2];
				owners.add(projectManagersId);
				owners.add(ahId);
				owners.add(dmId);
			});
		}
		return owners;
	}
}
