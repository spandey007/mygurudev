package com.infocepts.otc.repositories;

import java.util.List;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.infocepts.otc.entities.Uom;
import java.lang.String;

public interface UomRepository extends CrudRepository<Uom,Integer>{

	@Override
	public List<Uom> findAll();
	
	@Query("from Uom where uomName = :uomName")
	public Uom findByUomName(@Param("uomName") String uomName);
	
	
}
