package com.infocepts.otc.repositories;

import java.util.List;
import org.springframework.data.repository.CrudRepository;
import com.infocepts.otc.entities.ContributionMargin;

public interface ContributionMarginRepository extends CrudRepository<ContributionMargin,Integer>{

	@Override
	public List<ContributionMargin> findAll();
}
