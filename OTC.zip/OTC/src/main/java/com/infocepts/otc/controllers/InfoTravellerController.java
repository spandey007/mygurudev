package com.infocepts.otc.controllers;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;


import java.util.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.infocepts.otc.entities.InfoTravel;
import com.infocepts.otc.entities.InfoTraveller;
import com.infocepts.otc.repositories.InfoTravellerRepository;
import com.infocepts.otc.services.TimesheetService;

@RestController
@RequestMapping(value="/infotraveller",headers="referer")
public class InfoTravellerController {

	@Autowired
	InfoTravellerRepository infoTravellerRepository;
	
	@PersistenceContext
    private EntityManager manager;
	
	@Autowired
	TimesheetService service;
	
	
	final Logger logger = Logger.getLogger(InfoTravellerController.class.getName());
	
	@RequestMapping(method=RequestMethod.POST)
	public InfoTraveller addInfoTraveller(@RequestBody InfoTraveller infoTraveller){
		
		infoTraveller.setInfoTravellerId(null);
			infoTravellerRepository.save(infoTraveller);
		return infoTraveller;
	}
	
	@RequestMapping(method=RequestMethod.GET)
	public List<InfoTraveller> getInfoTraveller(@RequestParam(value = "infoTravelId", defaultValue = "0") Integer infoTravelId			
			,HttpServletRequest request){
		List<InfoTraveller> list = null;
		try{
			System.out.println("inside infotraveller"+infoTravelId);
			 if(infoTravelId != 0){
				 logger.info("here in infotravel section");
				 list = infoTravellerRepository.findById(infoTravelId);
			 }
			 else{
				 list = infoTravellerRepository.findAll();
			 }
			 
		 }
		 catch(Exception e){
			 logger.info(String.format("exception - ", e));
		 }
		return list;
	}
	
	@RequestMapping(value="/{infoTravellerId}",method=RequestMethod.GET)
	public InfoTraveller getInfoTraveller(@PathVariable Integer infoTravellerId){
		InfoTraveller infoTraveller = null;
		try {
				System.out.println("inside getInfoCab"+infoTravellerId);
				infoTraveller = infoTravellerRepository.findOne(infoTravellerId);
			} catch (Exception e) {
				logger.info(String.format("exception - ", e));
			}
		
		return infoTraveller;
	}
	
	@RequestMapping(value="/{infoTravellerId}", method=RequestMethod.PUT)
	public InfoTraveller updateInfoTraveller(@PathVariable Integer infoTravellerId,  @RequestBody InfoTraveller updatedInfoTraveller){
		updatedInfoTraveller.setInfoTravellerId(infoTravellerId);
			infoTravellerRepository.save(updatedInfoTraveller);
		
		return updatedInfoTraveller;
	}
	
	@RequestMapping(value="/{infoTravellerId}",method=RequestMethod.DELETE)
	public void deleteInfoTraveller(@PathVariable Integer infoTravellerId){
			infoTravellerRepository.delete(infoTravellerId);
	
	}

}
