
/**
* Filename: /src/main/java/com/infocepts/otc/repositories/<ModuleName>Repository.java
* @author  VVC
* @version 1.0
* @since   2019-05-07 
*/
package com.infocepts.otc.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import com.infocepts.otc.entities.InfoCabVehicle;

public interface InfoCabVehicleRepository extends CrudRepository<InfoCabVehicle,Integer>{

	@Override
	public List<InfoCabVehicle> findAll();	
	
}

