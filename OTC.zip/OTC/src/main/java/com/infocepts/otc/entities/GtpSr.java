/**
* Filename: /src/main/java/com/infocepts/otc/entities/GtpSr.java
* @author  AA
* @version 1.0
* @since   2019-08-30
*/
package com.infocepts.otc.entities;
import java.util.Date;
import javax.persistence.*;
import javax.validation.constraints.NotNull;

import com.infocepts.otc.utilities.LoadConstant;
@Entity
@Table(catalog=LoadConstant.otc, schema="[dbo]", name="gtpSr")

@SqlResultSetMappings({
        @SqlResultSetMapping(
                name = "GtpSrlist",
                classes = {
                        @ConstructorResult(
                                targetClass = GtpSr.class,
                                columns = {
                                		@ColumnResult(name = "gtpSrId"),
										@ColumnResult(name = "uid"),                                     
                                        @ColumnResult(name = "gtpSrDate",type = Date.class),
										@ColumnResult(name = "projectId",type = Integer.class),
										@ColumnResult(name = "focusArea",type = Integer.class),
										@ColumnResult(name = "activites",type = String.class),																			
                                        @ColumnResult(name = "hours", type = Float.class),                                                                                                        
                                        @ColumnResult(name = "isDeleted", type = Boolean.class),
                                        @ColumnResult(name = "createdBy"),
                                        @ColumnResult(name = "createdDate", type = Date.class),
										@ColumnResult(name = "modifiedBy"),
                                        @ColumnResult(name = "modifiedDate", type = Date.class),
                                        @ColumnResult(name = "associate",type = String.class),    
                                        @ColumnResult(name = "focusAreaTitle",type = String.class),
                                        @ColumnResult(name = "projectTitle",type = String.class)
                                       
                                }
                        )
                }
        )
})
@NamedNativeQueries({
        @NamedNativeQuery( //used to load by Id
                name    =   "GtpSrQueryBygtpSrId",   
                query 	=   "Select tb.* , r.title as associate,tc.title as focusAreaTitle,p.title as projectTitle"+
							" from " + LoadConstant.otc + ".[dbo].GtpSr as tb"+							
							" LEFT JOIN " + LoadConstant.infomaster + ".[dbo].resource r on tb.uid = r.uid"+
							" LEFT JOIN " + LoadConstant.otc + ".[dbo].taskCenter tc on tb.focusArea = tc.taskId "+
							" LEFT JOIN " +  LoadConstant.infomaster +".[dbo].project p on tb.projectId = p.itemId "+
							 "  where gtpSrId =:gtpSrId and (isDeleted != 1 or isDeleted is NULL)",
							resultClass=GtpSr.class, resultSetMapping = "GtpSrlist"
        ),
        
      @NamedNativeQuery(    //not used currently.For load all
                name    =   "GtpSrQuery",   
                query 	=   "Select tb.* , r.title as associate,tc.title as focusAreaTitle,p.title as projectTitle "+
							" from " + LoadConstant.otc + ".[dbo].GtpSr as tb"+						
							" LEFT JOIN " + LoadConstant.infomaster + ".[dbo].resource r on tb.uid = r.uid "+
							" LEFT JOIN " + LoadConstant.otc + ".[dbo].taskCenter tc on tb.focusArea = tc.taskId "+
							" LEFT JOIN " +  LoadConstant.infomaster +".[dbo].project p on tb.projectId = p.itemId "+
							" where  (isDeleted != 1 or isDeleted is NULL)",
							  resultClass=GtpSr.class, resultSetMapping = "GtpSrlist"
        ), 
      
      @NamedNativeQuery(  //this query for Init/page load with month filter//load all for admin or coe head
              name    =   "getGtpSrForaMonth",   
              query 	=   "Select tb.*, r.title as associate,tc.title as focusAreaTitle,p.title as projectTitle"+
							" from " + LoadConstant.otc + ".[dbo].GtpSr as tb"+						
							" LEFT JOIN " + LoadConstant.infomaster + ".[dbo].resource r on tb.uid = r.uid "+
							" LEFT JOIN " + LoadConstant.otc + ".[dbo].taskCenter tc on tb.focusArea = tc.taskId "+
							" LEFT JOIN " +  LoadConstant.infomaster +".[dbo].project p on tb.projectId = p.itemId "+
							" WHERE (tb.gtpSrDate >= :monthStartDate and tb.gtpSrDate <= :monthEndDate) and  (isDeleted != 1 or isDeleted is NULL)",
							  resultClass=GtpSr.class, resultSetMapping = "GtpSrlist" 
		 ),
      @NamedNativeQuery(  //this query is for getting list by logged in associate with month filter
              name    =   "getGtpSrForaMonthByAssociate",   
              query 	=   "Select tb.*, r.title as associate,tc.title as focusAreaTitle,p.title as projectTitle"+
							" from " + LoadConstant.otc + ".[dbo].GtpSr as tb"+						
							" LEFT JOIN " + LoadConstant.infomaster + ".[dbo].resource r on tb.uid = r.uid "+
							" LEFT JOIN " + LoadConstant.otc + ".[dbo].taskCenter tc on tb.focusArea = tc.taskId "+
							" LEFT JOIN " +  LoadConstant.infomaster +".[dbo].project p on tb.projectId = p.itemId "+
							" WHERE (tb.gtpSrDate >= :monthStartDate and tb.gtpSrDate <= :monthEndDate) and  (isDeleted != 1 or isDeleted is NULL) and (tb.uid=:uid)  ",
							  resultClass=GtpSr.class, resultSetMapping = "GtpSrlist" 
		 ),     
      @NamedNativeQuery( //this query is for particular project with month filter for coe-pm
              name    =   "getGtpSrForaMonthByProject",   
              query 	=   "Select tb.*, r.title as associate,tc.title as focusAreaTitle,p.title as projectTitle"+
							" from " + LoadConstant.otc + ".[dbo].GtpSr as tb"+						
							" LEFT JOIN " + LoadConstant.infomaster + ".[dbo].resource r on tb.uid = r.uid "+
							" LEFT JOIN " + LoadConstant.otc + ".[dbo].taskCenter tc on tb.focusArea = tc.taskId "+
							" LEFT JOIN " +  LoadConstant.infomaster +".[dbo].project p on tb.projectId = p.itemId "+
							" WHERE (tb.gtpSrDate >= :monthStartDate and tb.gtpSrDate <= :monthEndDate) and  (isDeleted != 1 or isDeleted is NULL) and (tb.projectId=:projectId)",
							  resultClass=GtpSr.class, resultSetMapping = "GtpSrlist" 
		 )
        
        
})
public class GtpSr {

	// Entity Columns
    // --------------------------------------------------------------------------------
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Integer gtpSrId; 
	
    @NotNull
    private Integer uid;
    private Date gtpSrDate;    
    private Integer projectId; 
    private Integer focusArea;
    private String activites;
    private Float hours;
    private Integer createdBy; 
    private Date createdDate;
    private Integer modifiedBy;
    private Date modifiedDate;
    private Boolean isDeleted;
    @Transient
    private String associate;
    @Transient
    private String focusAreaTitle;
    @Transient
    private String projectTitle;
    
  
    
	
    public Integer getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public Integer getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public Date getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	
  
    
    public Boolean getIsDeleted() {
		return isDeleted;
	}
	public void setIsDeleted(Boolean isDeleted) {
		this.isDeleted = isDeleted;
	}
	
	public String getProjectTitle() {
		return projectTitle;
	}
	public void setProjectTitle(String projectTitle) {
		this.projectTitle = projectTitle;
	}
	public String getFocusAreaTitle() {
		return focusAreaTitle;
	}
	public void setFocusAreaTitle(String focusAreaTitle) {
		this.focusAreaTitle = focusAreaTitle;
	}
	public Integer getGtpSrId() {
		return gtpSrId;
	}
	public void setGtpSrId(Integer gtpSrId) {
		this.gtpSrId = gtpSrId;
	}
	public Integer getUid() {
		return uid;
	}
	public void setUid(Integer uid) {
		this.uid = uid;
	}
	public Date getGtpSrDate() {
		return gtpSrDate;
	}
	public void setGtpSrDate(Date gtpSrDate) {
		this.gtpSrDate = gtpSrDate;
	}
	
	
	public Integer getFocusArea() {
		return focusArea;
	}
	public void setFocusArea(Integer focusArea) {
		this.focusArea = focusArea;
	}
	public String getActivites() {
		return activites;
	}
	public void setActivites(String activites) {
		this.activites = activites;
	}
	public Float getHours() {
		return hours;
	}
	public void setHours(Float hours) {
		this.hours = hours;
	}
	public String getAssociate() {
		return associate;
	}
	public void setAssociate(String associate) {
		this.associate = associate;
	}
	
	public Integer getProjectId() {
		return projectId;
	}
	public void setProjectId(Integer projectId) {
		this.projectId = projectId;
	}
	public GtpSr(Integer gtpSrId, Integer uid, Date gtpSrDate, Integer projectId, Integer focusArea, String activites,
			 Float hours, Boolean isDeleted, Integer createdBy, Date createdDate,
			Integer modifiedBy, Date modifiedDate, String associate, String focusAreaTitle, String projectTitle) {
		super();
		this.gtpSrId = gtpSrId;
		this.uid = uid;
		this.gtpSrDate = gtpSrDate;
		this.projectId = projectId;
		this.focusArea = focusArea;
		this.activites = activites;
		this.hours = hours;
		this.isDeleted = isDeleted;
		this.createdBy = createdBy;
		this.createdDate = createdDate;
		this.modifiedBy = modifiedBy;
		this.modifiedDate = modifiedDate;
		this.associate = associate;
		this.focusAreaTitle = focusAreaTitle;
		this.projectTitle = projectTitle;
	}
	
	
	
	public GtpSr() {
		super();
		// TODO Auto-generated constructor stub
	}
	
    

}
