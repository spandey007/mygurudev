/**
* Filename: /src/main/java/com/infocepts/otc/controllers/ReleaseManagementDetailController.java
* @author  Anjali S. Kalbande
* @version 1.0
* @since   2018-01-08 
*/

package com.infocepts.otc.controllers;

import java.util.List;
import java.util.logging.Logger;

import com.infocepts.otc.entities.ReleaseManagementDetail;
import com.infocepts.otc.repositories.ReleaseManagementDetailRepository;
import com.infocepts.otc.services.TimesheetService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.mail.MessagingException;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

@RestController
@RequestMapping(value="/releaseManagementDetail",headers="referer")
public class ReleaseManagementDetailController {

	final Logger logger = Logger.getLogger(ReleaseManagementDetailController.class.getName());
	
	@Autowired
	ReleaseManagementDetailRepository repository;
	
	@Autowired
	HttpSession session;

	@PersistenceContext(unitName = "otc") 
	private EntityManager manager;
		
	@Autowired
	TimesheetService service;
	
	
	@GetMapping("/findAllReleaseManagementDetail")
    public Object findAllReleaseManagementDetail(@RequestParam(value = "releaseId", defaultValue = "0") Integer releaseId						
												,HttpServletRequest request) throws MessagingException{        
		List<ReleaseManagementDetail> releaseManagementDetailList = null;
        try{
        	if(releaseId != 0){ 
    			// list to get Release Item by releaseId
    			releaseManagementDetailList = manager.createNamedQuery("getReleaseItemsByReleaseId",ReleaseManagementDetail.class)
    					.setParameter("releaseId", releaseId)
    					.getResultList();
    		}
    		else
    		{
    			// list to get All Release Items
    			releaseManagementDetailList = manager.createNamedQuery("getAllReleaseItem",ReleaseManagementDetail.class)
    					.getResultList();
    		}
        }catch(Exception e){
        	logger.info(String.format("error in fetching release detail list list - ", e.getMessage()));
			e.printStackTrace();
        }
        return releaseManagementDetailList;
    }
	
	 @RequestMapping(method=RequestMethod.POST)
	 public ReleaseManagementDetail addReleaseManagementDetail(@RequestBody ReleaseManagementDetail releaseManagementDetail, HttpServletRequest request) throws MessagingException{
			try{
				releaseManagementDetail.setReleaseItemId(null);
				repository.save(releaseManagementDetail);

			}catch(Exception e){
				logger.info(String.format("exception - ", e));
			}
			return releaseManagementDetail;
	 }

	 @RequestMapping(value="/{releaseItemId}",method=RequestMethod.PUT)
	 public ReleaseManagementDetail updateReleaseManagementDetail(@RequestBody ReleaseManagementDetail updatedReleaseManagementDetail,@PathVariable Integer releaseItemId, HttpServletRequest request)throws MessagingException{
			try{
				updatedReleaseManagementDetail.setReleaseItemId(releaseItemId);
				repository.save(updatedReleaseManagementDetail);
						
			}catch(Exception e){
				logger.info(String.format("exception - ", e));
			}		
			return updatedReleaseManagementDetail;
	 }
	 
	 @RequestMapping(value="/{releaseItemId}",method=RequestMethod.DELETE)
	 public void deleteReleaseManagementDetail(@PathVariable Integer releaseItemId){
		 	try{
		 		repository.delete(releaseItemId);
		 	}
		 	catch(Exception e){
		 		logger.info(String.format("exception - ", e));
		 	}
	 }	 
	
}
