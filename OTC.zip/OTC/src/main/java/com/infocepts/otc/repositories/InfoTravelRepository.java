/**
* Filename: /src/main/java/com/infocepts/otc/repositories/<ModuleName>Repository.java
* @author  SRA
* @version 1.0
* @since   2018-08-01 
*/
package com.infocepts.otc.repositories;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import com.infocepts.otc.entities.InfoTravel;

public interface InfoTravelRepository extends CrudRepository<InfoTravel,Integer>{

	public static final Logger LOGGER = Logger.getLogger(InfoTravelRepository.class.getName());
	
	@Override
	public List<InfoTravel> findAll();	
	
	@Query("from InfoTravel where infoTravelId=:infoTravelId")
	public InfoTravel findOne(@Param("infoTravelId") Integer infoTravelId);
	
	default List<InfoTravel> fetchAllInfoTravel(EntityManager manager, Integer infoTravelId){
		List<InfoTravel> infoTravelList = new ArrayList<>();
		String queryString = "SELECT * FROM InfoTravel iT, InfoTraveller iTr, InfoTravelDetail iTd, InfoTravelDesk iTde"
				+ " WHERE iT.infoTravelId = iTr.infoTravelId AND"
				+ " iT.infoTravelId = iTd.infoTravelId AND"
				+ " iT.infoTravelId = iTde.infoTravelId AND"
				+ " iT.infoTravelId = :infoTravelId";
		
		try {
			TypedQuery<InfoTravel> typedQuery = manager.createQuery(queryString, InfoTravel.class);
			typedQuery.setParameter("infoTravelId", infoTravelId);
			infoTravelList.addAll(typedQuery.getResultList());
			
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, "SOMETHING WENT WRONG WHILE FETCHING INFOTRAVEL LIST!", e);
		}
		return infoTravelList;
		
	}
	
}

