package com.infocepts.otc.controllers;

import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.infocepts.otc.entities.State;
import com.infocepts.otc.repositories.StateRepository;

@RestController
@RequestMapping(value="/state",headers="referer")
public class StateController {

	@Autowired
	StateRepository repository;
	
	final Logger logger = Logger.getLogger(StateController.class);
	
	
	@RequestMapping(method=RequestMethod.POST)
	public State addState(@RequestBody State state)
	{
		try{
			state.setStateId(null);
			repository.save(state);	
		}catch(Exception e){
			logger.error(e);
		}
		return state;
	}	
 
	 @RequestMapping(method=RequestMethod.GET)
	 public List<State> getAllState(
			 @RequestParam(value="countryId",defaultValue="0") Integer countryId){
		 
		 List<State> statelist=null;
		 try{
			 if(countryId!=0)
				 statelist = repository.findByCountryId(countryId);
			 else
				 statelist = repository.findAll();
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return statelist;
	 }
	 
	 @RequestMapping(value="/{stateId}",method=RequestMethod.GET)
	 public State getStateById(@PathVariable Integer stateId){
		 State state=null;
		 try{
			 state = repository.findOne(stateId);
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return state;
	 }
	
	 
	 
	 @RequestMapping(value="/{stateId}",method=RequestMethod.PUT)
	 public State updateState(@RequestBody State updatedState,@PathVariable Integer stateId){
		 try{
			 updatedState.setStateId(stateId);
			 repository.save(updatedState);
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return updatedState;
	 }
	 
	 @RequestMapping(value="/{stateId}",method=RequestMethod.DELETE)
	 public void deleteState(@PathVariable Integer stateId){
		 try{
			 repository.delete(stateId);
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
	 }	 
	
}
