package com.infocepts.otc.entities;

/**
* Filename: /src/main/java/com/infocepts/otc/entities/ExchangeRate.java
* --------------------------------------------------------------------------
* Sr.No	 Author	      Version	Modified Date	Description
 ---------------------------------------------------------------------------
  1.    | Joselin V | 1.0     |  10-04-2019   |  Intial Version 
  --------------------------------------------------------------------------
*/

import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.*;
import javax.validation.constraints.NotNull;

import com.infocepts.otc.utilities.LoadConstant;
@Entity
@Table(catalog=LoadConstant.infomaster, schema="[dbo]", name="exchangeRate")

@SqlResultSetMappings({
        @SqlResultSetMapping(
                name = "get_exchange_rates",
                classes = {
                        @ConstructorResult(
                                targetClass = ExchangeRate.class,
                                columns = {
                                		@ColumnResult(name = "rateId"),
										@ColumnResult(name = "effectiveFrom",type = Date.class),
                                        @ColumnResult(name = "effectiveTo",type = Date.class),   
                                        @ColumnResult(name = "currencyFromId"),  
                                        @ColumnResult(name = "currencyToId"),
										@ColumnResult(name = "conversionRate",type = BigDecimal.class),										
										@ColumnResult(name = "createdBy"),
                                        @ColumnResult(name = "createdDate", type = Date.class),
										@ColumnResult(name = "modifiedBy"),
                                        @ColumnResult(name = "modifiedDate", type = Date.class),
                                        @ColumnResult(name = "currencyFrom"),
                                        @ColumnResult(name = "currencyTo"),
                                        @ColumnResult(name = "isDeleted", type = Boolean.class)
                                }
                        )
                }
        )
})
@NamedNativeQueries({
	   @NamedNativeQuery(
	            name    =   "getExchangeRateForaMonth",
	            query   =   " select  s.*, (select code from " + LoadConstant.infomaster + ".[dbo].currency where currencyId = s.currencyFromId) as currencyFrom, "  +
	            		    " (select code from " + LoadConstant.infomaster + ".[dbo].currency where currencyId = s.currencyToId) as currencyTo"  +
	            			" FROM " + LoadConstant.infomaster + ".[dbo].exchangeRate s" +
	            		    " WHERE effectiveFrom < :monthEndDate and effectiveTo > :monthStartDate and (isDeleted != 1 or isDeleted is NULL) ",
	                        resultClass=ExchangeRate.class, resultSetMapping = "get_exchange_rates"                       		
	    ),
	   @NamedNativeQuery(
	            name    =   "getExchangeRateForPrevMonth",
	            query   =   " select  s.*,  (select code from " + LoadConstant.infomaster + ".[dbo].currency where currencyId = s.currencyFromId) as currencyFrom, "+
	            		    " (select code from " + LoadConstant.infomaster + ".[dbo].currency where currencyId = s.currencyToId) as currencyTo"  +
	            			" FROM " + LoadConstant.infomaster + ".[dbo].exchangeRate s" +
	            		    " WHERE MONTH(effectiveFrom) = :prevMonthNo and YEAR(effectiveTo) = :currYear and (isDeleted != 1 or isDeleted is NULL) ",
	                        resultClass=ExchangeRate.class, resultSetMapping = "get_exchange_rates"                       		
	    )
	   
})
public class ExchangeRate {

	// Entity Columns
    // --------------------------------------------------------------------------------
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Integer rateId; 
	
    private Date effectiveFrom;
    private Date effectiveTo;
    
    private Boolean isDeleted;
    
    public Boolean getIsDeleted() {
		return isDeleted;
	}
	public void setIsDeleted(Boolean isDeleted) {
		this.isDeleted = isDeleted;
	}

	@NotNull
    private Integer currencyFromId;
    
    @NotNull
    private Integer currencyToId;
    
    @Column(precision=12,scale=2)
    private BigDecimal conversionRate; // stores xxxxxxxxxx.xx
	
	 // Audit Trail columns 
    // --------------------------------------------------------------------------------
	private Integer createdBy;    
    private Date createdDate;
    private Integer modifiedBy;
    private Date modifiedDate;
    // Transient Variables
    // --------------------------------------------------------------------------------
    @Transient
    private String currencyFrom;
    @Transient
    private String currencyTo;
    // Getter setter
   	// --------------------------------------------------------------------------------
   	
	/**
	 * @return the rateId
	 */
	public Integer getRateId() {
		return rateId;
	}
	/**
	 * @param rateId the rateId to set
	 */
	public void setRateId(Integer rateId) {
		this.rateId = rateId;
	}
	/**
	 * @return the effectiveFrom
	 */
	public Date getEffectiveFrom() {
		return effectiveFrom;
	}
	/**
	 * @param effectiveFrom the effectiveFrom to set
	 */
	public void setEffectiveFrom(Date effectiveFrom) {
		this.effectiveFrom = effectiveFrom;
	}
	/**
	 * @return the effectiveTo
	 */
	public Date getEffectiveTo() {
		return effectiveTo;
	}
	/**
	 * @param effectiveTo the effectiveTo to set
	 */
	public void setEffectiveTo(Date effectiveTo) {
		this.effectiveTo = effectiveTo;
	}
	/**
	 * @return the currencyFromId
	 */
	public Integer getCurrencyFromId() {
		return currencyFromId;
	}
	/**
	 * @param currencyFromId the currencyFromId to set
	 */
	public void setCurrencyFromId(Integer currencyFromId) {
		this.currencyFromId = currencyFromId;
	}
	/**
	 * @return the currencyToId
	 */
	public Integer getCurrencyToId() {
		return currencyToId;
	}
	/**
	 * @param currencyToId the currencyToId to set
	 */
	public void setCurrencyToId(Integer currencyToId) {
		this.currencyToId = currencyToId;
	}
	/**
	 * @return the conversionRate
	 */
	public BigDecimal getConversionRate() {
		return conversionRate;
	}
	/**
	 * @param conversionRate the conversionRate to set
	 */
	public void setConversionRate(BigDecimal conversionRate) {
		this.conversionRate = conversionRate;
	}
	/**
	 * @return the createdBy
	 */
	public Integer getCreatedBy() {
		return createdBy;
	}
	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}
	/**
	 * @return the createdDate
	 */
	public Date getCreatedDate() {
		return createdDate;
	}
	/**
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	/**
	 * @return the modifiedBy
	 */
	public Integer getModifiedBy() {
		return modifiedBy;
	}
	/**
	 * @param modifiedBy the modifiedBy to set
	 */
	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	/**
	 * @return the modifiedDate
	 */
	public Date getModifiedDate() {
		return modifiedDate;
	}
	/**
	 * @param modifiedDate the modifiedDate to set
	 */
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	
	/**
	 * @return the currencyFrom
	 */
	public String getCurrencyFrom() {
		return currencyFrom;
	}
	/**
	 * @param currencyFrom the currencyFrom to set
	 */
	public void setCurrencyFrom(String currencyFrom) {
		this.currencyFrom = currencyFrom;
	}
	/**
	 * @return the currencyTo
	 */
	public String getCurrencyTo() {
		return currencyTo;
	}
	/**
	 * @param currencyTo the currencyTo to set
	 */
	public void setCurrencyTo(String currencyTo) {
		this.currencyTo = currencyTo;
	}
	//Constructor
	public ExchangeRate() {
		//super();
		// TODO Auto-generated constructor stub
	}
    
	public ExchangeRate(Integer rateId, Date effectiveFrom, Date effectiveTo, Integer currencyFromId,
			Integer currencyToId, BigDecimal conversionRate, Integer createdBy, Date createdDate, Integer modifiedBy,
			Date modifiedDate,String currencyFrom, String currencyTo, Boolean isDeleted) {
		super();
		this.rateId = rateId;
		this.effectiveFrom = effectiveFrom;
		this.effectiveTo = effectiveTo;
		this.currencyFromId = currencyFromId;
		this.currencyToId = currencyToId;
		this.conversionRate = conversionRate;
		this.createdBy = createdBy;
		this.createdDate = createdDate;
		this.modifiedBy = modifiedBy;
		this.modifiedDate = modifiedDate;
		this.currencyFrom = currencyFrom;
		this.currencyTo = currencyTo;
		this.isDeleted = isDeleted;
	}
}
