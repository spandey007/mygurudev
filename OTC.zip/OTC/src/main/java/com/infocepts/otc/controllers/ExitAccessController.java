package com.infocepts.otc.controllers;

import java.util.List;

import javax.mail.MessagingException;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.infocepts.otc.entities.ExitAccess;
import com.infocepts.otc.entities.ExitForm;
import com.infocepts.otc.repositories.ExitAccessRepository;
import com.infocepts.otc.services.TimesheetService;

@RestController
@RequestMapping(value="/exitaccess",headers="referer")
public class ExitAccessController {

	@Autowired
	ExitAccessRepository repository;
	
	@Autowired
	ExitAccessController exitAccessController;
	
	@Autowired
	TimesheetService service;
	
	@PersistenceContext(unitName="otc")
    private EntityManager manager;

	final Logger logger = Logger.getLogger(ExitAccessController.class);
	
	
	@RequestMapping(method=RequestMethod.GET)
	public List<ExitAccess> getExitAccess(@RequestParam(name="uid",defaultValue="0") Integer uid){
		List<ExitAccess> exitAccessList=null;
		
	try{
		if(uid!=null && uid!=0) {
			exitAccessList = repository.findByUid(uid);
		}
		else
		{
			List<ExitAccess> exitaccess = null;
			exitaccess = manager.createNamedQuery("getAllResourceData", ExitAccess.class).getResultList();
			return exitaccess;
		}
	}catch(Exception e){
		 logger.error(e);
	 }
		return exitAccessList;
	}
	
	
	 @RequestMapping(value="/{exitAccessId}",method=RequestMethod.GET)
	 public ExitAccess getExitAccessById(@PathVariable Integer exitAccessId){
		 
		 ExitAccess exitAccess=null;
		 try{		
			 exitAccess = repository.findOne(exitAccessId);
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return exitAccess;
	 }
	
	@RequestMapping(method=RequestMethod.POST)
	public ExitAccess addExitAccess(@RequestBody ExitAccess exitAccess, HttpServletRequest request) throws MessagingException
	{
		try{
			exitAccess.setExitAccessId(null);
			repository.save(exitAccess);	
			service.sendExitAccessNotification(exitAccess, "add", request);																	

		}catch(Exception e){
			logger.error(e);
		}
		return exitAccess;
	}	
	
    /**
     * This method is delete data for specific row in moduleName entity
     * based on primaryKey Of Module Table 
     */	 
		@RequestMapping(value= "/{exitAccessId}",method=RequestMethod.DELETE)
		public void deleteExitAccess(@PathVariable Integer exitAccessId, HttpServletRequest request) {
				try{
					if(exitAccessId!=null) {
						repository.delete(exitAccessId);						
					}
				}
				catch(Exception e){
					 logger.info(String.format("exception - ", e));
				}
		}
	
}
