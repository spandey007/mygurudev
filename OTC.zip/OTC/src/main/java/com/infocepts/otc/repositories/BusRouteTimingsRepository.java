package com.infocepts.otc.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.infocepts.otc.entities.BusRouteTimings;


public interface BusRouteTimingsRepository extends CrudRepository<BusRouteTimings,Integer> {
	@Override
	public List<BusRouteTimings> findAll();

	@Query("from BusRouteTimings where busRouteId = :routeId")
	public List<BusRouteTimings> findById(@Param(value="routeId") Integer routeId);
	
	@Query("from BusRouteTimings where busRouteId = :routeid and busNodalPointId = :nodalpointid")
	public List<BusRouteTimings> findByNodalPtAndRoute(@Param("nodalpointid") Integer nodalpointid, @Param("routeid") Integer routeid);
}
