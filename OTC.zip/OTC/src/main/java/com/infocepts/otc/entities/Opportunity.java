/* 
 * Country JPA Entity to manage Country
 * -------------------------------------------------------------------------------------------------------------------------
 * 20 Sep 2017 - EW creation of the file
 *
*/
package com.infocepts.otc.entities;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.SqlResultSetMappings;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.infocepts.otc.utilities.LoadConstant;

@Entity
@Table(catalog=LoadConstant.infomaster, schema="[dbo]",name="opportunity")

@SqlResultSetMappings({
	@SqlResultSetMapping(
		      name = "get_opportunity",
		      classes = {
		          @ConstructorResult(
		              targetClass = Opportunity.class,
		              columns = {
		                  @ColumnResult(name = "opportunityId"),
		                  @ColumnResult(name = "opportunityName", type=String.class), //Not to be Push on Stage
		                  @ColumnResult(name = "createdDate", type=Date.class),
		                  @ColumnResult(name = "modifiedDate", type=Date.class),
		                  @ColumnResult(name = "createdBy"),
		                  @ColumnResult(name = "modifiedBy"),
		                  @ColumnResult(name = "accountId"),
		                  @ColumnResult(name = "crmId", type=String.class),
		                  @ColumnResult(name = "description", type=String.class),
		                  @ColumnResult(name = "estimatedCloseDate", type=Date.class),
		                  @ColumnResult(name = "info_OpportunityNumber", type=String.class),	                  
		                  @ColumnResult(name = "ownerId"),            
		                  @ColumnResult(name = "stepName", type=String.class),	
		                  @ColumnResult(name = "title", type=String.class),	                                    
		                  @ColumnResult(name = "opportunityValue"),
		                  @ColumnResult(name = "teamComposition", type=String.class),
		                  @ColumnResult(name = "currencyId"),
		                  @ColumnResult(name = "opportunityStage", type=String.class),
		                  @ColumnResult(name = "cmsId"),
		                  @ColumnResult(name = "cmsCreater", type=String.class),
		                  @ColumnResult(name = "currency", type=String.class),
		                  @ColumnResult(name = "estimatedProjectStartDate", type=Date.class),
		                  @ColumnResult(name = "sowExpirationDate", type=Date.class),
		                  @ColumnResult(name = "negotiationvalue"),
		                  @ColumnResult(name = "proposalvalue"),
		                  @ColumnResult(name = "actualValue"),
		                  @ColumnResult(name = "totalRevenue", type=BigDecimal.class),
		                  @ColumnResult(name = "totalRevenueCertain", type=BigDecimal.class),
		                  @ColumnResult(name = "totalRevenueHigh", type=BigDecimal.class),
		                  @ColumnResult(name = "totalRevenueMedium", type=BigDecimal.class),
		                  @ColumnResult(name = "totalRevenueLow", type=BigDecimal.class),
		                  @ColumnResult(name = "totalRevenueProbability", type=BigDecimal.class),
		                  @ColumnResult(name = "accountName", type=String.class),
		                  @ColumnResult(name = "dmName", type=String.class),
		                  @ColumnResult(name = "isDeleted", type=Boolean.class),
		                  @ColumnResult(name = "status", type=String.class),
		                  
		                  @ColumnResult(name = "hubspotId", type=String.class),
		                  @ColumnResult(name = "pipeline", type=String.class)
		                  
		                }
		          )
		      }
	)
})
	@NamedNativeQueries({
	   @NamedNativeQuery(
	            name    =   "getOpportunityForAccount",
	            query   =   "select o.*, rDm.title as dmName,"+
		            		" cms.cmsId, cast(r.title as VARCHAR (max)) as cmsCreater, cur.code as currency, pa.accountShortName as accountName, "+
		            		" cms.revenue as totalRevenue, cms.revenueCertain as totalRevenueCertain, cms.revenueHigh as totalRevenueHigh, "+
		            		" cms.revenueMedium as totalRevenueMedium, cms.revenueLow as totalRevenueLow, cms.revenueProbability as totalRevenueProbability " +
		            		" FROM " + LoadConstant.infomaster + ".dbo.opportunity o "+
		            		" left join " + LoadConstant.otc + ".dbo.cms cms on o.opportunityId = cms.opportunityId "+
		            		" left join " + LoadConstant.infomaster + ".dbo.accounts pa on pa.itemId = o.accountId "+
		            		" left join " + LoadConstant.infomaster + ".dbo.resource r on r.uid = cms.createdBy "+
		            		" left join " + LoadConstant.infomaster + ".dbo.resource rDm on rDm.uid = pa.dmId "+
		            		" left join " + LoadConstant.infomaster + ".dbo.currency cur on cur.currencyId = o.currencyId "+
		            		" WHERE ((:accountId != 0 and o.accountId = :accountId) or (:accountId = 0)) and isDeleted <> 1 ",
	                        resultClass=Opportunity.class, resultSetMapping = "get_opportunity"                       		
	    ),
	    @NamedNativeQuery(
	            name    =   "getPlanningOpportunityForPh",
	            query   =   "select o.*, rDm.title as dmName,"+
		            		" cms.cmsId, cast(r.title as VARCHAR (max)) as cmsCreater, cur.code as currency, pa.accountShortName as accountName, " + 
		            		" cms.revenue as totalRevenue, cms.revenueCertain as totalRevenueCertain, cms.revenueHigh as totalRevenueHigh, " + 
		            		" cms.revenueMedium as totalRevenueMedium, cms.revenueLow as totalRevenueLow, cms.revenueProbability as totalRevenueProbability "+ 
		            		" FROM " + LoadConstant.infomaster + ".dbo.opportunity o "+
		            		" left join " + LoadConstant.otc + ".dbo.cms cms on o.opportunityId = cms.opportunityId "+
		            		" left join " + LoadConstant.infomaster + ".dbo.accounts pa on pa.itemId = o.accountId "+
		            		" left join " + LoadConstant.infomaster + ".dbo.resource r on r.uid = cms.createdBy "+
		            		" left join " + LoadConstant.infomaster + ".dbo.resource rDm on rDm.uid = pa.dmId "+
		            		" left join " + LoadConstant.infomaster + ".dbo.currency cur on cur.currencyId = o.currencyId "+
		            		" WHERE ( (:uid != 0 and (pa.dmId = :uid or cms.createdBy = :uid or (:uid IN (select ahId FROM " + LoadConstant.infomaster + ".[dbo].[accounts] ac "+
		            		" left join " + LoadConstant.infomaster + ".dbo.project p on ac.itemId=p.accountId "+
		            		" where p.accountId = ac.itemId and p.state = 'Active' and p.billingTypeId != 4)) or (:uid IN (select projectManagersId FROM " + LoadConstant.infomaster + ".[dbo].[project] p where p.accountId = pa.itemId and p.state = 'Active' and p.billingTypeId != 4)) ) ) or (:uid = 0)) " + 
		            		"  and isDeleted <> 1", //and o.opportunityName like :planningYear + '%'
	                        resultClass=Opportunity.class, resultSetMapping = "get_opportunity"                       		
	    )
	})

public class Opportunity {

	//Columns
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer opportunityId;
	private String opportunityName;

	private Date createdDate;
	private Date modifiedDate;
	private Integer createdBy;
	private Integer modifiedBy;
	private Integer accountId;
	private String crmId;
	private String description;
	private Date estimatedCloseDate;
	private String info_OpportunityNumber;
	private Integer ownerId;
	private String stepName;
	private String title;
	private Integer opportunityValue;
	private String teamComposition;	
	private Integer currencyId;
	private String opportunityStage;
	private Date estimatedProjectStartDate;
	private Date sowExpirationDate;
	private Integer negotiationvalue;
	private Integer proposalvalue;
	private Integer actualValue ;
	private Boolean isDeleted;
	private String status;
	
	private String hubspotId;
	private String pipeline;
	
	@Transient
	private Integer cmsId;
	@Transient
	private String cmsCreater;
	@Transient
	private String currency;
	@Transient
	private BigDecimal totalRevenue;
	
	@Transient
	private BigDecimal totalRevenueCertain;
	@Transient
	private BigDecimal totalRevenueHigh;
	@Transient
	private BigDecimal totalRevenueMedium;
	@Transient
	private BigDecimal totalRevenueLow;
	@Transient
	private BigDecimal totalRevenueProbability;
    
	@Transient
	private String dmName;
	//End of: Columns

	//Getter and Setter


	public Integer getOpportunityId() {
		return opportunityId;
	}
	public void setOpportunityId(Integer opportunityId) {
		this.opportunityId = opportunityId;
	}

	public String getOpportunityName() {
		return opportunityName;
	}

	public void setOpportunityName(String opportunityName) {
		this.opportunityName = opportunityName;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public Integer getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	public Integer getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Integer getAccountId() {
		return accountId;
	}

	public void setAccountId(Integer accountId) {
		this.accountId = accountId;
	}

	public String getCrmId() {
		return crmId;
	}

	public void setCrmId(String crmId) {
		this.crmId = crmId;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Date getEstimatedCloseDate() {
		return estimatedCloseDate;
	}

	public void setEstimatedCloseDate(Date estimatedCloseDate) {
		this.estimatedCloseDate = estimatedCloseDate;
	}

	public String getInfo_OpportunityNumber() {
		return info_OpportunityNumber;
	}

	public void setInfo_OpportunityNumber(String info_OpportunityNumber) {
		this.info_OpportunityNumber = info_OpportunityNumber;
	}

	public Integer getOwnerId() {
		return ownerId;
	}

	public void setOwnerId(Integer ownerId) {
		this.ownerId = ownerId;
	}

	public String getStepName() {
		return stepName;
	}

	public void setStepName(String stepName) {
		this.stepName = stepName;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Integer getOpportunityValue() {
		return opportunityValue;
	}

	public void setOpportunityValue(Integer opportunityValue) {
		this.opportunityValue = opportunityValue;
	}

	public String getTeamComposition() {
		return teamComposition;
	}

	public void setTeamComposition(String teamComposition) {
		this.teamComposition = teamComposition;
	}

	public Integer getCurrencyId() {
		return currencyId;
	}

	public void setCurrencyId(Integer currencyId) {
		this.currencyId = currencyId;
	}

	public String getOpportunityStage() {
		return opportunityStage;
	}

	public void setOpportunityStage(String opportunityStage) {
		this.opportunityStage = opportunityStage;
	}

	public Integer getCmsId() {
		return cmsId;
	}

	public void setCmsId(Integer cmsId) {
		this.cmsId = cmsId;
	}
	
	public String getCmsCreater() {
		return cmsCreater;
	}
	public void setCmsCreater(String cmsCreater) {
		this.cmsCreater = cmsCreater;
	}
		
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	
	public Date getEstimatedProjectStartDate() {
		return estimatedProjectStartDate;
	}
	
	public void setEstimatedProjectStartDate(Date estimatedProjectStartDate) {
		this.estimatedProjectStartDate = estimatedProjectStartDate;
	}
	
	public Date getSowExpirationDate() {
		return sowExpirationDate;
	}
	
	public void setSowExpirationDate(Date sowExpirationDate) {
		this.sowExpirationDate = sowExpirationDate;
	}
	
	public Integer getNegotiationvalue() {
		return negotiationvalue;
	}
	
	public void setNegotiationvalue(Integer negotiationvalue) {
		this.negotiationvalue = negotiationvalue;
	}
	
	public Integer getProposalvalue() {
		return proposalvalue;
	}
	
	public void setProposalvalue(Integer proposalvalue) {
		this.proposalvalue = proposalvalue;
	}
	
	public Integer getActualValue() {
		return actualValue;
	}
	
	public void setActualValue(Integer actualValue) {
		this.actualValue = actualValue;
	}
	
	public BigDecimal getTotalRevenue() {
		return totalRevenue;
	}
	public void setTotalRevenue(BigDecimal totalRevenue) {
		this.totalRevenue = totalRevenue;
	}
	
	public BigDecimal getTotalRevenueCertain() {
		return totalRevenueCertain;
	}
	public void setTotalRevenueCertain(BigDecimal totalRevenueCertain) {
		this.totalRevenueCertain = totalRevenueCertain;
	}
	public BigDecimal getTotalRevenueHigh() {
		return totalRevenueHigh;
	}
	public void setTotalRevenueHigh(BigDecimal totalRevenueHigh) {
		this.totalRevenueHigh = totalRevenueHigh;
	}
	public BigDecimal getTotalRevenueMedium() {
		return totalRevenueMedium;
	}
	public void setTotalRevenueMedium(BigDecimal totalRevenueMedium) {
		this.totalRevenueMedium = totalRevenueMedium;
	}
	public BigDecimal getTotalRevenueLow() {
		return totalRevenueLow;
	}
	public void setTotalRevenueLow(BigDecimal totalRevenueLow) {
		this.totalRevenueLow = totalRevenueLow;
	}
	public BigDecimal getTotalRevenueProbability() {
		return totalRevenueProbability;
	}
	public void setTotalRevenueProbability(BigDecimal totalRevenueProbability) {
		this.totalRevenueProbability = totalRevenueProbability;
	}
	public String getDmName() {
		return dmName;
	}
	public void setDmName(String dmName) {
		this.dmName = dmName;
	}
	
	public Boolean getIsDeleted() {
		return isDeleted;
	}
	public void setIsDeleted(Boolean isDeleted) {
		this.isDeleted = isDeleted;
	}
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	public String getHubspotId() {
		return hubspotId;
	}
	public void setHubspotId(String hubspotId) {
		this.hubspotId = hubspotId;
	}
	public String getPipeline() {
		return pipeline;
	}
	public void setPipeline(String pipeline) {
		this.pipeline = pipeline;
	}
	//End of: Getter and Setter
	
	public Opportunity() {

	}	
	
	public Opportunity(Integer opportunityId, String opportunityName, Date createdDate, Date modifiedDate,
			Integer createdBy, Integer modifiedBy, Integer accountId, String crmId, String description,
			Date estimatedCloseDate, String info_OpportunityNumber, Integer ownerId, String stepName, String title,
			Integer opportunityValue, String teamComposition, Integer currencyId, String opportunityStage,
			Integer cmsId, String cmsCreater, String currency, Date estimatedProjectStartDate, Date sowExpirationDate,
			Integer negotiationvalue, Integer proposalvalue, Integer actualValue, BigDecimal totalRevenue, 
			BigDecimal totalRevenueCertain, BigDecimal totalRevenueHigh, BigDecimal totalRevenueMedium, BigDecimal totalRevenueLow, BigDecimal totalRevenueProbability, 
			String accountName, String dmName, Boolean isDeleted, String status,String hubspotId,String pipeline) {
		this.opportunityId = opportunityId;
		this.opportunityName = opportunityName;
		this.createdDate = createdDate;
		this.modifiedDate = modifiedDate;
		this.createdBy = createdBy;
		this.modifiedBy = modifiedBy;
		this.accountId = accountId;
		this.crmId = crmId;
		this.description = description;
		this.estimatedCloseDate = estimatedCloseDate;
		this.info_OpportunityNumber = info_OpportunityNumber;
		this.ownerId = ownerId;
		this.stepName = stepName;
		this.title = accountName; // Setting the account name to title field
		this.opportunityValue = opportunityValue;
		this.teamComposition = teamComposition;
		this.currencyId = currencyId;
		this.opportunityStage = opportunityStage;
		this.cmsId = cmsId;
		this.cmsCreater = cmsCreater;
		this.currency = currency;
		this.estimatedProjectStartDate = estimatedProjectStartDate;
		this.sowExpirationDate = sowExpirationDate;
		this.negotiationvalue = negotiationvalue;
		this.proposalvalue = proposalvalue;
		this.actualValue = actualValue;
		this.totalRevenue = totalRevenue;
		this.totalRevenueCertain = totalRevenueCertain;
		this.totalRevenueHigh = totalRevenueHigh;
		this.totalRevenueMedium = totalRevenueMedium;
		this.totalRevenueLow = totalRevenueLow;
		this.totalRevenueProbability = totalRevenueProbability;
		this.dmName = dmName;
		this.isDeleted = isDeleted;
		this.status = status;
		
		this.hubspotId = hubspotId;
		this.pipeline = pipeline;
		
	}
	
}
