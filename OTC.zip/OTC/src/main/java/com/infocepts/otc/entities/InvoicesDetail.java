package com.infocepts.otc.entities;


import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.SqlResultSetMappings;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import com.infocepts.otc.utilities.LoadConstant;
import com.infocepts.otc.utilities.QueryConstant;

@Entity
@Table(catalog=LoadConstant.otc, schema="[dbo]",name="invoiceDetail")
@SqlResultSetMappings({
@SqlResultSetMapping(
	      name = "invoices_detail_edit",
	      classes = {
	          @ConstructorResult(
	              targetClass = InvoicesDetail.class,
	              columns = {
	            		//Transient start
		      	      @ColumnResult(name = "resourceName", type=String.class),
		              @ColumnResult(name = "countryName", type=String.class),
		              @ColumnResult(name = "currencyCode", type=String.class),
		              @ColumnResult(name = "expectedHrs", type=BigDecimal.class),
		              @ColumnResult(name = "uom", type=String.class), 
		                  //Transient end
	                  @ColumnResult(name = "invoiceDetailId"),
	                  @ColumnResult(name = "amount", type=BigDecimal.class),
	                  @ColumnResult(name = "arDetailID", type=String.class),
	                  @ColumnResult(name = "arHeaderId", type=String.class),
	                  @ColumnResult(name = "comments", type=String.class),
	                  @ColumnResult(name = "billableRate", type=BigDecimal.class),	                 
	                  @ColumnResult(name = "uid"),	                  
	                  @ColumnResult(name = "currencyId"),
	                  @ColumnResult(name = "countryId"),
	                  @ColumnResult(name = "expenseAmount", type=BigDecimal.class),
	                  @ColumnResult(name = "description", type=String.class),
	                  @ColumnResult(name = "initialBilledAmount", type=BigDecimal.class),
	                  @ColumnResult(name = "sowMilestoneId"),
	                  @ColumnResult(name = "resNameMilestone", type=String.class),	                 
	                  @ColumnResult(name = "purposeExpense", type=String.class),
	                  @ColumnResult(name = "sowHrs", type=BigDecimal.class),
	                  @ColumnResult(name = "tsHrs", type=BigDecimal.class), 
	                  @ColumnResult(name = "invoiceId"),
	                  @ColumnResult(name = "sowNo", type=String.class),
	                  @ColumnResult(name = "infoCeptsRole", type=String.class),
	                  @ColumnResult(name = "expStartDate", type=Date.class),
	                  @ColumnResult(name = "expEndDate", type=Date.class),
	                  @ColumnResult(name = "createdBy"),
	                  @ColumnResult(name = "createdDate", type=Date.class),
	                  @ColumnResult(name = "modifiedBy"),
	                  @ColumnResult(name = "modifiedDate", type=Date.class),
	                  @ColumnResult(name = "sowId"),
		      	      @ColumnResult(name = "clientRole", type=String.class)
	                }
	          )
	      }),
@SqlResultSetMapping(
	      name = "invoices_detail_add",
	      classes = {
	          @ConstructorResult(
	              targetClass = InvoicesDetail.class,
	              columns = {
	            		//Transient start
		      	      @ColumnResult(name = "resourceName", type=String.class),
		      	      @ColumnResult(name = "uid"),
		              @ColumnResult(name = "infoCeptsRole", type=String.class),
		              @ColumnResult(name = "sowNo", type=String.class),
		              @ColumnResult(name = "sowId"),
		              @ColumnResult(name = "countryId"),
		              @ColumnResult(name = "countryName", type=String.class),
		              @ColumnResult(name = "billableRate", type=BigDecimal.class),
		              @ColumnResult(name = "expectedHrs", type=BigDecimal.class),
		              @ColumnResult(name = "currencyId"),
		              @ColumnResult(name = "currencyCode", type=String.class),
		              @ColumnResult(name = "sowDetailId"),
		              @ColumnResult(name = "tsHrs", type=BigDecimal.class),
		              @ColumnResult(name = "uom", type=String.class), 
		      	      @ColumnResult(name = "uomId"),
		      	      @ColumnResult(name = "clientRole", type=String.class),
		      	      @ColumnResult(name = "fte", type=BigDecimal.class)
		                  //Transient end
	                }
	          )
	      }),
@SqlResultSetMapping(
	      name = "invoices_detail_milestone_add",
	      classes = {
	          @ConstructorResult(
	              targetClass = InvoicesDetail.class,
	              columns = {
	            		//Transient start
	            	  @ColumnResult(name = "sowNo", type=String.class),
	            	  @ColumnResult(name = "sowId"),
	  		          @ColumnResult(name = "currencyId"),  
	  		          @ColumnResult(name = "uom", type=String.class),  
	  		         // @ColumnResult(name = "countryName", type=String.class),  
	  		          @ColumnResult(name = "currencyCode", type=String.class),
	  		          @ColumnResult(name = "resNameMilestone", type=String.class),	
	  		          @ColumnResult(name = "sowMilestoneId"),
	  		          @ColumnResult(name = "description", type=String.class),
	  		          @ColumnResult(name = "initialBilledAmount", type=BigDecimal.class),
	  		          @ColumnResult(name = "uomId")
	  		            //Transient end
	                }
	          )
	      }),
@SqlResultSetMapping(
	      name = "invoices_detail_get_Timesheet_Weekly_Hours",
	      classes = {
	          @ConstructorResult(
	              targetClass = InvoicesDetail.class,
	              columns = {
	            		//Transient start
	            		  @ColumnResult(name = "resourceName", type=String.class),
	            		  @ColumnResult(name = "uid"),
	            		  @ColumnResult(name = "periodEnd", type=Date.class),  
	  		          	  @ColumnResult(name = "tsHrs", type=BigDecimal.class),
	  		          	  @ColumnResult(name = "infoCeptsRole", type=String.class)  
	  		          	 //Transient end
	                }
	          )
	      })
	})

	@NamedNativeQueries({
		 @NamedNativeQuery(
	            name    =   "invoices_detail_query_edit",
	            query   =    QueryConstant.Query_Invoices_get_Detail_Edit,
	                        resultClass=InvoicesDetail.class, resultSetMapping = "invoices_detail_edit"                       		
	    ),
	    @NamedNativeQuery(
	            name    =   "invoices_detail_query_add",
	            query   = 	QueryConstant.Query_Invoices_get_Detail_Add,
	            			resultClass=InvoicesDetail.class, resultSetMapping = "invoices_detail_add"                       		
	    ),
	    @NamedNativeQuery(
	            name    =   "invoices_detail_already_present",
	            query   = 	QueryConstant.Query_Invoices_Present_Already,
	            			resultClass=InvoicesDetail.class, resultSetMapping = "invoices_detail_edit"                       		
	    ),
	    @NamedNativeQuery(
	            name    =   "invoices_detail_query_milestone_add",
	            query   = 	QueryConstant.Query_Invoices_get_Detail_Milestone_Add,
	            			resultClass=InvoicesDetail.class, resultSetMapping = "invoices_detail_milestone_add"                       		
	    ),
	    @NamedNativeQuery(
	            name    =   "invoices_weekly_billable_hours_for_an_invoice",
	            query   = 	QueryConstant.Query_Weekly_Billiable_hours_for_an_Invoice,
	            			resultClass=InvoicesDetail.class, resultSetMapping = "invoices_detail_get_Timesheet_Weekly_Hours"                       		
	    )
})
public class InvoicesDetail {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer invoiceDetailId;
	
	@ManyToOne
	@OnDelete(action=OnDeleteAction.CASCADE)
	@JoinColumn(name="invoiceId")
	private Invoices invoices;
	
	private String resNameMilestone;
	
	private Integer uid;
	private String infoCeptsRole;
	private String sowNo;	
	private Integer countryId;	
	private Integer currencyId;
	
	@Column(precision=12,scale=2)
	private BigDecimal tsHrs;
	
	@Column(precision=12,scale=2)
	private BigDecimal initialBilledAmount;
	
	@Column(precision=12,scale=2)
	private BigDecimal billableRate;
	
	@Column(precision=12,scale=2)
	private BigDecimal amount;
	
	@Transient
	private Integer sowDetailId;
	
	@Column(precision=12,scale=2)
	private BigDecimal sowHrs;
		
	@Lob
	private String comments;	
	
	private String arDetailID;	
	private String arHeaderId;
	private String description;
	
	// Expense related fields
	private Date expStartDate; 	
	private Date expEndDate;
	@Column(precision=12,scale=2)
	private BigDecimal expenseAmount;
	private String purposeExpense;
	
	private Integer createdBy;	
	private Date createdDate;
	private Integer modifiedBy;		
	private Date modifiedDate;
	@Transient
	private Date periodEnd;
	
	private Integer sowMilestoneId;
	
	private Integer sowId;
	
	// Transient Variables
	//-----------------------------------------------------------------------------
	
	@Transient
	private String resourceName;	

	@Transient
	private String countryName;
	
	@Transient
	@Column(precision=6,scale=4)
	private BigDecimal expectedHrs;
	
	@Transient
	private String currencyCode;
	
	@Transient
	private String uom;
	
	@Transient
	private Integer uomId;
	
	private String clientRole;
	
	@Transient
	@Column(precision=6,scale=4)
	private BigDecimal fte;
	// Getters and Setters
	//-----------------------------------------------------------------------------
	
	public Integer getInvoiceDetailId() {
		return invoiceDetailId;
	}



	public void setInvoiceDetailId(Integer invoiceDetailId) {
		this.invoiceDetailId = invoiceDetailId;
	}


	
	public Invoices getInvoices() {
		return invoices;
	}



	public void setInvoices(Invoices invoices) {
		this.invoices = invoices;
	}



	public String getArDetailID() {
		return arDetailID;
	}



	public void setArDetailID(String arDetailID) {
		this.arDetailID = arDetailID;
	}



	public String getArHeaderId() {
		return arHeaderId;
	}



	public void setArHeaderId(String arHeaderId) {
		this.arHeaderId = arHeaderId;
	}



	public BigDecimal getTsHrs() {
		return tsHrs;
	}



	public void setTsHrs(BigDecimal tsHrs) {
		this.tsHrs = tsHrs;
	}



	public BigDecimal getSowHrs() {
		return sowHrs;
	}



	public void setSowHrs(BigDecimal sowHrs) {
		this.sowHrs = sowHrs;
	}

	public Integer getSowDetailId() {
		return sowDetailId;
	}



	public void setSowDetailId(Integer sowDetailId) {
		this.sowDetailId = sowDetailId;
	}


	public String getResNameMilestone() {
		return resNameMilestone;
	}



	public void setResNameMilestone(String resNameMilestone) {
		this.resNameMilestone = resNameMilestone;
	}


	@Transient
	public String getCurrencyCode() {
		return currencyCode;
	}
	
	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

    public Integer getCurrencyId() {
		return currencyId;
	}

	public void setCurrencyId(Integer currencyId) {
		this.currencyId = currencyId;
	}
	
	 public Integer getCountryId() {
		return countryId;
	}

	public void setCountryId(Integer countryId) {
		this.countryId = countryId;
	}



	public String getInfoCeptsRole() {
		return infoCeptsRole;
	}



	public void setInfoCeptsRole(String infoCeptsRole) {
		this.infoCeptsRole = infoCeptsRole;
	}

	public String getCountryName() {
		return countryName;
	}



	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}

	public BigDecimal getBillableRate() {
		return billableRate;
	}

	public void setBillableRate(BigDecimal billableRate) {
		this.billableRate = billableRate;
	}   

	



	public Date getExpStartDate() {
		return expStartDate;
	}



	public void setExpStartDate(Date expStartDate) {
		this.expStartDate = expStartDate;
	}



	public Date getExpEndDate() {
		return expEndDate;
	}



	public void setExpEndDate(Date expEndDate) {
		this.expEndDate = expEndDate;
	}



	public String getResourceName() {
		return resourceName;
	}



	public void setResourceName(String resourceName) {
		this.resourceName = resourceName;
	}

	

	public BigDecimal getExpectedHrs() {
		return expectedHrs;
	}



	public void setExpectedHrs(BigDecimal expectedHrs) {
		this.expectedHrs = expectedHrs;
	}



	public BigDecimal getAmount() {
		return amount;
	}



	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}



	public String getComments() {
		return comments;
	}



	public void setComments(String comments) {
		this.comments = comments;
	}



	public BigDecimal getInitialBilledAmount() {
		return initialBilledAmount;
	}



	public void setInitialBilledAmount(BigDecimal initialBilledAmount) {
		this.initialBilledAmount = initialBilledAmount;
	}



	public String getPurposeExpense() {
		return purposeExpense;
	}



	public void setPurposeExpense(String purposeExpense) {
		this.purposeExpense = purposeExpense;
	}



	public String getDescription() {
		return description;
	}



	public void setDescription(String description) {
		this.description = description;
	}



	public BigDecimal getExpenseAmount() {
		return expenseAmount;
	}



	public void setExpenseAmount(BigDecimal expenseAmount) {
		this.expenseAmount = expenseAmount;
	}

	

	/**
	 * @return the sowId
	 */
	public Integer getSowId() {
		return sowId;
	}



	/**
	 * @param sowId the sowId to set
	 */
	public void setSowId(Integer sowId) {
		this.sowId = sowId;
	}



	public Integer getUid() {
		return uid;
	}
	
	public void setUid(Integer uid) {
		this.uid = uid;
	}

	public Integer getCreatedBy() {
		return createdBy;
	}
	
	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}
	
	public Date getCreatedDate() {
		return createdDate;
	}
	
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Integer getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}	

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}


	public String getSowNo() {
		return sowNo;
	}



	public void setSowNo(String sowNo) {
		this.sowNo = sowNo;
	}

	

	public String getUom() {
		return uom;
	}



	public void setUom(String uom) {
		this.uom = uom;
	}



	public Integer getUomId() {
		return uomId;
	}



	public void setUomId(Integer uomId) {
		this.uomId = uomId;
	}

	

	public String getClientRole() {
		return clientRole;
	}



	public void setClientRole(String clientRole) {
		this.clientRole = clientRole;
	}



	public Date getPeriodEnd() {
		return periodEnd;
	}



	public void setPeriodEnd(Date periodEnd) {
		this.periodEnd = periodEnd;
	}



	public Integer getSowMilestoneId() {
		return sowMilestoneId;
	}



	public void setSowMilestoneId(Integer sowMilestoneId) {
		this.sowMilestoneId = sowMilestoneId;
	}



	/**
	 * @return the fte
	 */
	public BigDecimal getFte() {
		return fte;
	}



	/**
	 * @param fte the fte to set
	 */
	public void setFte(BigDecimal fte) {
		this.fte = fte;
	}



	public InvoicesDetail() {
		}   

	public InvoicesDetail(String resourceName, String countryName, String currencyCode,
			BigDecimal expectedHrs,String uom, Integer invoiceDetailId, BigDecimal amount,
			String arDetailID, String arHeaderId, String comments, BigDecimal billableRate, Integer uid, 
			Integer currencyId, Integer countryId, BigDecimal expenseAmount, String description,
			BigDecimal initialBilledAmount,Integer sowMilestoneId, String resNameMilestone, 
			String purposeExpense, BigDecimal sowHrs,
			BigDecimal tsHrs, Integer invoiceId, String sowNo, String infoCeptsRole, Date expStartDate, Date expEndDate,
			Integer createdBy, Date createdDate, Integer modifiedBy, Date modifiedDate,Integer sowId, String clientRole) {
		super();
		this.resourceName = resourceName;
		this.countryName = countryName;
		this.currencyCode = currencyCode;
		this.billableRate = billableRate;
		this.expectedHrs = expectedHrs;
		this.uom = uom;
		this.currencyId = currencyId;
		this.countryId = countryId;
		this.invoiceDetailId = invoiceDetailId;
		this.amount = amount;
		this.arDetailID = arDetailID;
		this.arHeaderId = arHeaderId;
		this.comments = comments;
		this.uid = uid;		
		this.expenseAmount = expenseAmount;
		this.description = description;
		this.initialBilledAmount = initialBilledAmount;
		this.sowMilestoneId = sowMilestoneId;
		this.resNameMilestone = resNameMilestone;
		this.purposeExpense = purposeExpense;
		this.sowHrs = sowHrs;
		this.tsHrs = tsHrs;
		this.invoices = null;
		if(invoiceId != null)
		{
			this.invoices = new Invoices();
			this.invoices.setInvoiceId(invoiceId);
		}
		this.sowNo = sowNo;
		this.infoCeptsRole = infoCeptsRole;
		this.expStartDate = expStartDate;
		this.expEndDate = expEndDate;
		this.createdBy = createdBy;
		this.createdDate = createdDate;
		this.modifiedBy = modifiedBy;
		this.modifiedDate = modifiedDate;
		this.sowId = sowId;
		this.clientRole = clientRole;
	}
	
	public InvoicesDetail(String resourceName, Integer uid, String infoCeptsRole, String sowNo, Integer sowId, Integer countryId, String countryName,
			BigDecimal billableRate, BigDecimal expectedHrs, Integer currencyId, String currencyCode, Integer sowDetailId, BigDecimal tsHrs, String uom, 
			Integer uomId, String clientRole, BigDecimal fte) {
		super();
		this.resourceName = resourceName;
		this.uid = uid;
		this.infoCeptsRole = infoCeptsRole;
		this.sowNo = sowNo;
		this.sowId = sowId;
		this.countryId = countryId;
		this.countryName = countryName;
		this.billableRate = billableRate;
		this.expectedHrs = expectedHrs;
		this.currencyId = currencyId;
		this.currencyCode = currencyCode;
		this.sowDetailId = sowDetailId;
		this.tsHrs = tsHrs;
		this.uom = uom;
		this.uomId = uomId;
		this.clientRole = clientRole;
		this.fte = fte;
	}

	public InvoicesDetail(String sowNo,Integer sowId, Integer currencyId,String uom,/*String countryName,*/
			   String currencyCode,String resNameMilestone,Integer sowMilestoneId, String description,BigDecimal initialBilledAmount, Integer uomId) {
		super();
		
		this.sowNo = sowNo;
		this.sowId = sowId;
		this.currencyId = currencyId;
		this.uom = uom;
		//this.countryName = countryName;
		this.currencyCode = currencyCode;
		this.resNameMilestone = resNameMilestone;
		this.sowMilestoneId = sowMilestoneId;
		this.description = description;
		this.initialBilledAmount = initialBilledAmount;
		this.uomId = uomId;
	}



	public InvoicesDetail(String resourceName,Integer uid, Date periodEnd, BigDecimal tsHrs, String infoCeptsRole ) {
		super();
		this.resourceName = resourceName;
		this.uid = uid;
		this.periodEnd = periodEnd;
		this.tsHrs = tsHrs;
		this.infoCeptsRole = infoCeptsRole;
		
	}
}
