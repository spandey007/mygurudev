/**
* Filename: /src/main/java/com/infocepts/otc/controllers/targetAudienceController.java
* @author  Anjali S. Kalbande
* @version 1.0
* @since   2019-06-03 
*/

package com.infocepts.otc.controllers;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.mail.MessagingException;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.infocepts.otc.entities.TargetAudience;
import com.infocepts.otc.repositories.ResourceRepository;
import com.infocepts.otc.repositories.TargetAudienceRepository;
import com.infocepts.otc.services.TimesheetService;

@Controller
@RestController
@RequestMapping(value="/targetAudience", headers="referer")
public class TargetAudienceController {
	
	final Logger logger = Logger.getLogger(TargetAudienceController.class.getName());

    @Autowired
    TargetAudienceRepository repository;
    
    @Autowired
    HttpSession session;

    @PersistenceContext(unitName = "otc") 
    private EntityManager manager;
			
	@Autowired
	TimesheetService service;
	
	@Autowired
	private ResourceRepository resourceRepository;

    @RequestMapping(method = RequestMethod.GET)
    public List<TargetAudience> findAlltargetAudience(@RequestParam(value = "surveyId", defaultValue = "0") Integer surveyId,  
    												  @RequestParam(value = "surveyChange", defaultValue = "false") Boolean surveyChange,
    												  HttpServletRequest request){
        List<TargetAudience> targetAudienceList = null;
        Integer loggedInUid = (Integer) session.getAttribute("loggedInUid");   
        
        logger.info("--------------------in Target Audience controller------------------");						
        try {
			// Authorization for Admin role
			if(!service.isAdmin()) 
			{
				service.sendTamperedMail("All Target Audience", 0, 0, request);
				return targetAudienceList;
			}
			if(surveyId != 0 && surveyChange == true)
			{
				System.out.println(surveyId);
				targetAudienceList = manager.createNamedQuery("getTargetAudienceOnSurveyChange", TargetAudience.class)                        
						.setParameter("surveyId", surveyId)
						.getResultList(); 
			}
			else if(surveyId != 0)
			{
				targetAudienceList = manager.createNamedQuery("getTargetAudienceBySurveyId", TargetAudience.class)                        
						.setParameter("surveyId", surveyId)
						.getResultList(); 
			}
         } 
		catch (Exception e){
			logger.log(Level.SEVERE, "Error in fetching Target Audience details", e);
        }
        
        return targetAudienceList;
    }
    
    @RequestMapping(method=RequestMethod.POST)
	public TargetAudience addtargetAudience(@RequestBody TargetAudience targetAudience, HttpServletRequest request) throws MessagingException {
    	List<String> resourcePKList = targetAudience.getResourcePKList();    	  	
    	Integer surveyId = targetAudience.getSurveyId();
    	Boolean targetDelete = targetAudience.getTargetDelete();
    	
    	// Authorization for Admin role
		if(service.isAdmin())
		{
			try{				
			
				if(targetDelete == true)
				{
					repository.deleteTargetAudienceBySurveyId(surveyId);				
					
				}
				else 
				{		
					
					repository.deleteTargetAudienceBySurveyId(surveyId);	
					
					if (!CollectionUtils.isEmpty(resourcePKList)) {
						for(String pkAndEmail: resourcePKList) {
							String[] split = pkAndEmail.split("_");
							Integer uid = NumberUtils.toInt(split[0]);
							String email = split[1];
							TargetAudience ta = (TargetAudience) targetAudience.clone();
							ta.setEmployeeId(uid);
							ta.setEmployeeEmail(email);
							repository.save(ta);
						}
					}
				}
			}
			catch(Exception e){
				 logger.log(Level.SEVERE, "Error in saving Target Audience details", e);

			}
		}
		else 
		{
			service.sendTamperedMail("Target Audience Saved", 0, 0, request);
		}
		
		return targetAudience;
	}
    
    @RequestMapping(value="/{targetAudienceId}",method=RequestMethod.PUT)
	 public TargetAudience updatetargetAudience(@RequestBody TargetAudience updatedtargetAudience,@PathVariable Integer targetAudienceId, HttpServletRequest request) throws MessagingException{
        
    	// Authorization for Admin role
		if(service.isAdmin())
		{	
			try{
				updatedtargetAudience.setTargetAudienceId(targetAudienceId);
				 repository.save(updatedtargetAudience);
			}
			catch(Exception e){
				 logger.info(String.format("Error in while updating Target Audience details ", e));
			}
		}
		
		 return updatedtargetAudience;
	 }
    
    @RequestMapping(value="/{targetAudienceId}",method=RequestMethod.GET)
	 public TargetAudience gettargetAudienceById(@PathVariable Integer targetAudienceId, HttpServletRequest request) throws MessagingException{	

    	TargetAudience targetAudience = null;
		// Authorization for Admin role
    	if(service.isAdmin())
		{
    		try {
    			targetAudience = repository.findOne(targetAudienceId);
    		} catch (Exception e) {
    			logger.info(String.format("exception - ", e));
    		}
		}
    	
		 return targetAudience;
	 }
	  
	@RequestMapping(value="/{targetAudienceId}",method=RequestMethod.DELETE)
	public void deletetargetAudience(@PathVariable Integer targetAudienceId, HttpServletRequest request)  throws MessagingException {
		// Authorization for Admin role
		if(service.isAdmin())
		{
			try{
			repository.delete(targetAudienceId);
			}
			catch(Exception e){
				 logger.info(String.format("exception - ", e));
			}
		}			 
	}

}
