package com.infocepts.otc.entities;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
import com.infocepts.otc.utilities.LoadConstant;

@Entity
@Table(catalog=LoadConstant.otc, schema="[dbo]",name="invoiceInfo")
public class InvoiceInfo {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer invoiceInfoId;
	
	@Lob
	private String billingAddress;
	
	@Lob
	private String shippingAddress;
	
	private Integer billingstateId;
	private Integer shippingstateId;
	private Integer shippingcountryId;
	private Integer billingcountryId;
	
	private String gstApplied;
	private Boolean isDTA;
	private Boolean isSEZ;
	private Boolean isExport;
	public String headerId;
	
	private String billingGSTNo;
	private String shippingGSTNo;
	private Integer createdBy;
	private Date createdDate;
	private Date modifiedDate;
	private Integer projectId;
	private Integer cgst;
	private Integer sgst;
	private Integer utgst;
	private Integer igst;
	private Integer bankDetailsId;
	
	@Column(precision=4,scale=2)
	private BigDecimal delayedPayInterest;
	
	private Integer sgdgst;
	private String panNo;
	private Boolean timesheetUnlock;
	private Boolean onsiteOffShoreSplit;
	private Boolean hideTimesheet;
	private Boolean replaceAssociateNameWithRoleTitle;
	
	@Column(precision=6,scale=2)
	private BigDecimal discountAmt;
	
	public Integer getInvoiceInfoId() {
		return invoiceInfoId;
	}
	public void setInvoiceInfoId(Integer invoiceInfoId) {
		this.invoiceInfoId = invoiceInfoId;
	}
	public String getBillingAddress() {
		return billingAddress;
	}
	public void setBillingAddress(String billingAddress) {
		this.billingAddress = billingAddress;
	}
	public String getShippingAddress() {
		return shippingAddress;
	}
	public void setShippingAddress(String shippingAddress) {
		this.shippingAddress = shippingAddress;
	}
	public Integer getBillingstateId() {
		return billingstateId;
	}
	public void setBillingstateId(Integer billingstateId) {
		this.billingstateId = billingstateId;
	}
	public Integer getShippingstateId() {
		return shippingstateId;
	}
	public void setShippingstateId(Integer shippingstateId) {
		this.shippingstateId = shippingstateId;
	}
	public Integer getShippingcountryId() {
		return shippingcountryId;
	}
	public void setShippingcountryId(Integer shippingcountryId) {
		this.shippingcountryId = shippingcountryId;
	}
	public Integer getBillingcountryId() {
		return billingcountryId;
	}
	public void setBillingcountryId(Integer billingcountryId) {
		this.billingcountryId = billingcountryId;
	}
	public String getGstApplied() {
		return gstApplied;
	}
	public void setGstApplied(String gstApplied) {
		this.gstApplied = gstApplied;
	}
	public Boolean getIsDTA() {
		return isDTA;
	}
	public void setIsDTA(Boolean isDTA) {
		this.isDTA = isDTA;
	}
	public Boolean getIsSEZ() {
		return isSEZ;
	}
	public void setIsSEZ(Boolean isSEZ) {
		this.isSEZ = isSEZ;
	}
	public Boolean getIsExport() {
		return isExport;
	}
	public void setIsExport(Boolean isExport) {
		this.isExport = isExport;
	}
	public String getHeaderId() {
		return headerId;
	}
	public void setHeaderId(String headerId) {
		this.headerId = headerId;
	}
	public String getBillingGSTNo() {
		return billingGSTNo;
	}
	public void setBillingGSTNo(String billingGSTNo) {
		this.billingGSTNo = billingGSTNo;
	}
	public String getShippingGSTNo() {
		return shippingGSTNo;
	}
	public void setShippingGSTNo(String shippingGSTNo) {
		this.shippingGSTNo = shippingGSTNo;
	}
	public Integer getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public Date getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public Integer getProjectId() {
		return projectId;
	}
	public void setProjectId(Integer projectId) {
		this.projectId = projectId;
	}
	public Integer getCgst() {
		return cgst;
	}
	public void setCgst(Integer cgst) {
		this.cgst = cgst;
	}
	public Integer getSgst() {
		return sgst;
	}
	public void setSgst(Integer sgst) {
		this.sgst = sgst;
	}
	public Integer getUtgst() {
		return utgst;
	}
	public void setUtgst(Integer utgst) {
		this.utgst = utgst;
	}
	public Integer getIgst() {
		return igst;
	}
	public void setIgst(Integer igst) {
		this.igst = igst;
	}
	public Integer getBankDetailsId() {
		return bankDetailsId;
	}
	public void setBankDetailsId(Integer bankDetailsId) {
		this.bankDetailsId = bankDetailsId;
	}
	public BigDecimal getDelayedPayInterest() {
		return delayedPayInterest;
	}
	public void setDelayedPayInterest(BigDecimal delayedPayInterest) {
		this.delayedPayInterest = delayedPayInterest;
	}
	public Integer getSgdgst() {
		return sgdgst;
	}
	public void setSgdgst(Integer sgdgst) {
		this.sgdgst = sgdgst;
	}
	public String getPanNo() {
		return panNo;
	}
	public void setPanNo(String panNo) {
		this.panNo = panNo;
	}
	public Boolean getTimesheetUnlock() {
		return timesheetUnlock;
	}
	public void setTimesheetUnlock(Boolean timesheetUnlock) {
		this.timesheetUnlock = timesheetUnlock;
	}
	public BigDecimal getDiscountAmt() {
		return discountAmt;
	}
	public void setDiscountAmt(BigDecimal discountAmt) {
		this.discountAmt = discountAmt;
	}
	public Boolean getOnsiteOffShoreSplit() {
		return onsiteOffShoreSplit;
	}
	public void setOnsiteOffShoreSplit(Boolean onsiteOffShoreSplit) {
		this.onsiteOffShoreSplit = onsiteOffShoreSplit;
	}
	public Boolean getHideTimesheet() {
		return hideTimesheet;
	}
	public void setHideTimesheet(Boolean hideTimesheet) {
		this.hideTimesheet = hideTimesheet;
	}
	public Boolean getReplaceAssociateNameWithRoleTitle() {
		return replaceAssociateNameWithRoleTitle;
	}
	public void setReplaceAssociateNameWithRoleTitle(Boolean replaceAssociateNameWithRoleTitle) {
		this.replaceAssociateNameWithRoleTitle = replaceAssociateNameWithRoleTitle;
	}
	
}
