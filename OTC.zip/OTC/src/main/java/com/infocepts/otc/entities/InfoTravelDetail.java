package com.infocepts.otc.entities;

import java.util.Date;

import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.Table;

import com.infocepts.otc.utilities.LoadConstant;

@SqlResultSetMapping(
		name = "get_info_traveldetail",
	      classes = {
	          @ConstructorResult(
	              targetClass = InfoTravelDetail.class,
	              columns = {
	            	//normal cols
	            		//normal cols
		                  @ColumnResult(name = "origin", type=String.class),
		                  @ColumnResult(name = "destination", type=String.class),
		                  @ColumnResult(name = "departureDate", type=Date.class)
	                  }
	          )
	      }
	)
@NamedNativeQueries({
	   @NamedNativeQuery(
			   
			  
              
	            name    =   "getInfoTravelDetails",
	            query   =   " SELECT * FROM " + LoadConstant.otc + ".[dbo].[infoTravelDetail]" + 
	            			"  where infoTravelId=:infoTravelId",
	                       resultClass=InfoTravelDetail.class, resultSetMapping = "get_info_traveldetail"                       		
	    )
})
@Entity
@Table(catalog=LoadConstant.otc, schema="[dbo]",name="infoTravelDetail")
public class InfoTravelDetail {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer infoTravelDetailId;
	
	@ManyToOne
	@JoinColumn(name="infoTravelId")
	private InfoTravel infoTravel;
	
	@Lob
	private String origin;
	
	@Lob
	private String destination;
	private Date departureDate;
	
	//generate getter and setter
	public Integer getInfoTravelDetailId() {
		return infoTravelDetailId;
	}
	public void setInfoTravelDetailId(Integer infoTravelDetailId) {
		this.infoTravelDetailId = infoTravelDetailId;
	}
	public InfoTravel getInfoTravel() {
		return infoTravel;
	}
	public void setInfoTravel(InfoTravel infoTravel) {
		this.infoTravel = infoTravel;
	}
	public String getOrigin() {
		return origin;
	}
	public void setOrigin(String origin) {
		this.origin = origin;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public Date getDepartureDate() {
		return departureDate;
	}
	public void setDepartureDate(Date departureDate) {
		this.departureDate = departureDate;
	}
	
	//generate getter and setter
	
	
	public InfoTravelDetail(Integer infoTravelDetailId, InfoTravel infoTravel, String origin, String destination,
			Date departureDate) {
		this.infoTravelDetailId = infoTravelDetailId;
		this.infoTravel = infoTravel;
		this.origin = origin;
		this.destination = destination;
		this.departureDate = departureDate;
	}
	
	public InfoTravelDetail() {
		// TODO Auto-generated constructor stub
	}

	
	
	
}
