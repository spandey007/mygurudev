package com.infocepts.otc.repositories;

import java.util.List;
import org.springframework.data.repository.CrudRepository;
import com.infocepts.otc.entities.BillingType;

public interface BillingTypeRepository extends CrudRepository<BillingType,Integer>{

	@Override
	public List<BillingType> findAll();
}
