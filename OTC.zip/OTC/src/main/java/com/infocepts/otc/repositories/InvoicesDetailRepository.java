package com.infocepts.otc.repositories;

import java.util.List;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import com.infocepts.otc.entities.InvoicesDetail;


public interface InvoicesDetailRepository extends CrudRepository<InvoicesDetail,Integer>{

	@Override
	public List<InvoicesDetail> findAll();
	
	@Query("select i from InvoicesDetail i where i.invoices.invoiceId=:invoiceId")
	public List<InvoicesDetail> findByInvoicesId(@Param("invoiceId") Integer invoiceId);
}