/**
* Filename: /src/main/java/com/infocepts/otc/controllers/ISowMilestoneRepository.java
* @author  JV
* @version 1.0
* @since   2018-10-31 
*/
package com.infocepts.otc.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.infocepts.otc.entities.ISowMilestone;

public interface ISowMilestoneRepository  extends CrudRepository<ISowMilestone,Integer> {
	@Override
	public List<ISowMilestone> findAll();
	
	@Query("select sm from ISowMilestone sm where sm.isow.isowId=:isowId")
	public List<ISowMilestone> findByISowId(@Param("isowId") Integer isowId);
}
