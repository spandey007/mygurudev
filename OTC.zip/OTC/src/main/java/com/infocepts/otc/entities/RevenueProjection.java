/* 
	 * Revenue JPA to manage the Revenue Planning etc
	 * -------------------------------------------------------------------------------------------------------------------------
	 * 3 Jun 2018 - Author : Joselin Varghese
	 *
	*/
	
package com.infocepts.otc.entities;


import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.SqlResultSetMappings;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.infocepts.otc.utilities.LoadConstant;
import com.infocepts.otc.utilities.QueryConstant;

@Entity
@Table(catalog=LoadConstant.otc, schema="[dbo]",name="revenueProjection")
@SqlResultSetMappings({
	@SqlResultSetMapping(
			name = "revenue_planning",
	        classes = {
	                @ConstructorResult(
	                        targetClass = RevenueProjection.class,
	                        columns = {
	                        		@ColumnResult(name = "revId"),
	                                @ColumnResult(name = "projectId"),
	                                @ColumnResult(name = "acctId"),
	                                @ColumnResult(name = "sowJanFirm", type = BigDecimal.class),
	                                @ColumnResult(name = "sowFebFirm", type = BigDecimal.class),
	                                @ColumnResult(name = "sowMarFirm", type = BigDecimal.class),
	                                @ColumnResult(name = "sowAprFirm", type = BigDecimal.class),
	                                @ColumnResult(name = "sowMayFirm", type = BigDecimal.class),
	                                @ColumnResult(name = "sowJunFirm", type = BigDecimal.class),
	                                @ColumnResult(name = "sowJulFirm", type = BigDecimal.class),
	                                @ColumnResult(name = "sowAugFirm", type = BigDecimal.class),
	                                @ColumnResult(name = "sowSepFirm", type = BigDecimal.class),
	                                @ColumnResult(name = "sowOctFirm", type = BigDecimal.class),
	                                @ColumnResult(name = "sowNovFirm", type = BigDecimal.class),
	                                @ColumnResult(name = "sowDecFirm", type = BigDecimal.class),
	                                @ColumnResult(name = "year"),
	                                @ColumnResult(name = "cmsId"),
	                                @ColumnResult(name = "createdDate", type = Date.class),
	                                @ColumnResult(name = "modifiedDate", type = Date.class),
	                                @ColumnResult(name = "createdBy"),
	                        		@ColumnResult(name = "modifiedBy"),		                        		
	                        		@ColumnResult(name = "itemId"),
	                                @ColumnResult(name = "title", type = String.class),		
	                                @ColumnResult(name = "accountId"),
	                                @ColumnResult(name = "sowValue", type = BigDecimal.class),
	                                @ColumnResult(name = "invoiceValue", type = BigDecimal.class),
	                                @ColumnResult(name = "monthNo"),
	                                @ColumnResult(name = "currencySign", type = String.class),
	                                @ColumnResult(name = "invoiceCurrencySign", type = String.class),
	                                @ColumnResult(name = "accountName", type = String.class),
	                                @ColumnResult(name = "businessType", type = String.class),
	                                @ColumnResult(name = "deleteStatus", type = Boolean.class),
	                                @ColumnResult(name = "cmsIdfrmCMS"),
	                                @ColumnResult(name = "contractGapPercent", type = BigDecimal.class),
	                                @ColumnResult(name = "billingType", type = String.class),
	                                @ColumnResult(name = "janComment", type = String.class),
	                                @ColumnResult(name = "febComment", type = String.class),
	                                @ColumnResult(name = "marComment", type = String.class),
	                                @ColumnResult(name = "aprComment", type = String.class),
	                                @ColumnResult(name = "mayComment", type = String.class),
	                                @ColumnResult(name = "junComment", type = String.class),
	                                @ColumnResult(name = "julComment", type = String.class),
	                                @ColumnResult(name = "augComment", type = String.class),
	                                @ColumnResult(name = "sepComment", type = String.class),
	                                @ColumnResult(name = "octComment", type = String.class),
	                                @ColumnResult(name = "novComment", type = String.class),
	                                @ColumnResult(name = "decComment", type = String.class),
	                                @ColumnResult(name = "opportunityName", type = String.class),
	                                @ColumnResult(name = "opportunityValue", type = BigDecimal.class),
	                        }
                    )
	        }
		),
	    @SqlResultSetMapping(
	        name = "get_PM_List",
	        		  classes = {
	        		    @ConstructorResult(
	        		       targetClass = RevenueProjection.class,
	        		         columns = {
	        		                @ColumnResult(name = "uid"),
	        		                @ColumnResult(name = "pmName", type = String.class)
	        		                               
	        		                   }
	        	        )
	        		  }
	    )
})
@NamedNativeQueries({
	@NamedNativeQuery(
            name    =   "getRevenueForecastForExistingBusiness",
            query   =  	QueryConstant.Query_Revenue_Forecast_Existing_Business +
            		" order by mm.monthNo ",            
                        resultClass=RevenueProjection.class,  resultSetMapping = "revenue_planning"  
	),
	@NamedNativeQuery(
            name    =   "getRevenueForecastForPipelineBusiness",
			query   =  	QueryConstant.Query_Revenue_Forecast_Pipeline_Business +
					" order by mm.monthNo ",            
                        resultClass=RevenueProjection.class,  resultSetMapping = "revenue_planning"  
	),
	@NamedNativeQuery(
            name    =   "getRevenueForecast",
			query   =  	QueryConstant.Query_Revenue_Forecast,            
                        resultClass=RevenueProjection.class,  resultSetMapping = "revenue_planning"  
	),
	@NamedNativeQuery(
		    name 	= "getPMsList",
		    query	= "select uid, title as pmName " +
		    		 "from " + LoadConstant.infomaster + ".dbo.resource where gradeId >= 5  order by pmName" ,
		    		 resultClass=RevenueProjection.class,  resultSetMapping = "get_PM_List"  
	)

})

public class RevenueProjection {
	
	//Columns
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer revId;
	private Integer projectId;
	private BigDecimal sowJanFirm;
	private BigDecimal sowFebFirm;
	private BigDecimal sowMarFirm;
	private BigDecimal sowAprFirm;
	private BigDecimal sowMayFirm;
	private BigDecimal sowJunFirm;
	private BigDecimal sowJulFirm;
	private BigDecimal sowAugFirm;
	private BigDecimal sowSepFirm;
	private BigDecimal sowOctFirm;
	private BigDecimal sowNovFirm;
	private BigDecimal sowDecFirm;
	private Integer year;
	private Integer cmsId;
	private Date createdDate;
	private Date modifiedDate;
	private Integer createdBy;
	private Integer modifiedBy;
	private String businessType;
	private Boolean deleteStatus;
	private String janComment;
	private String febComment;
	private String marComment;
	private String aprComment;
	private String mayComment;
	private String junComment;
	private String julComment;
	private String augComment;
	private String sepComment;
	private String octComment;
	private String novComment;
	private String decComment;
	//private Integer acctId;
	@Transient
	private Integer itemId;
	@Transient
	private String title;

	private Integer acctId;
	@Transient
	private BigDecimal sowValue;
	@Transient
	private BigDecimal invoiceValue;
	@Transient
	private Integer monthNo;
	@Transient
	private Integer accountId;
	@Transient
    private String accountName;
	@Transient
	private String currencySign;
	@Transient
	private String invoiceCurrencySign;	
	@Transient
	private Integer cmsIdfrmCMS;
	@Transient
    private BigDecimal contractGapPercent;
	@Transient
	private String billingType;
	@Transient
	private BigDecimal opportunityValue;
	@Transient
	private String opportunityName;
	@Transient
	private Integer uid;
	@Transient
	private String pmName;
	/**
	 * @return the revId
	 */
	public Integer getRevId() {
		return revId;
	}
	/**
	 * @param revId the revId to set
	 */
	public void setRevId(Integer revId) {
		this.revId = revId;
	}
	/**
	 * @return the projectId
	 */
	public Integer getProjectId() {
		return projectId;
	}
	/**
	 * @param projectId the projectId to set
	 */
	public void setProjectId(Integer projectId) {
		this.projectId = projectId;
	}
	/**
	 * @return the sowAmt
	 */
	public BigDecimal getSowJanFirm() {
		return sowJanFirm;
	}
	/**
	 * @param sowAmt the sowAmt to set
	 */
	public void setSowJanFirm(BigDecimal sowJanFirm) {
		this.sowJanFirm = sowJanFirm;
	}
	
	/**
	 * @return the sowFebFirm
	 */
	public BigDecimal getSowFebFirm() {
		return sowFebFirm;
	}
	/**
	 * @param sowFebFirm the sowFebFirm to set
	 */
	public void setSowFebFirm(BigDecimal sowFebFirm) {
		this.sowFebFirm = sowFebFirm;
	}
	/**
	 * @return the sowMarFirm
	 */
	public BigDecimal getSowMarFirm() {
		return sowMarFirm;
	}
	/**
	 * @param sowMarFirm the sowMarFirm to set
	 */
	public void setSowMarFirm(BigDecimal sowMarFirm) {
		this.sowMarFirm = sowMarFirm;
	}
	/**
	 * @return the sowAprFirm
	 */
	public BigDecimal getSowAprFirm() {
		return sowAprFirm;
	}
	/**
	 * @param sowAprFirm the sowAprFirm to set
	 */
	public void setSowAprFirm(BigDecimal sowAprFirm) {
		this.sowAprFirm = sowAprFirm;
	}
	/**
	 * @return the sowMayFirm
	 */
	public BigDecimal getSowMayFirm() {
		return sowMayFirm;
	}
	/**
	 * @param sowMayFirm the sowMayFirm to set
	 */
	public void setSowMayFirm(BigDecimal sowMayFirm) {
		this.sowMayFirm = sowMayFirm;
	}
	/**
	 * @return the sowJunFirm
	 */
	public BigDecimal getSowJunFirm() {
		return sowJunFirm;
	}
	/**
	 * @param sowJunFirm the sowJunFirm to set
	 */
	public void setSowJunFirm(BigDecimal sowJunFirm) {
		this.sowJunFirm = sowJunFirm;
	}
	/**
	 * @return the sowJulFirm
	 */
	public BigDecimal getSowJulFirm() {
		return sowJulFirm;
	}
	/**
	 * @param sowJulFirm the sowJulFirm to set
	 */
	public void setSowJulFirm(BigDecimal sowJulFirm) {
		this.sowJulFirm = sowJulFirm;
	}
	/**
	 * @return the sowAugFirm
	 */
	public BigDecimal getSowAugFirm() {
		return sowAugFirm;
	}
	/**
	 * @param sowAugFirm the sowAugFirm to set
	 */
	public void setSowAugFirm(BigDecimal sowAugFirm) {
		this.sowAugFirm = sowAugFirm;
	}
	/**
	 * @return the sowSepFirm
	 */
	public BigDecimal getSowSepFirm() {
		return sowSepFirm;
	}
	/**
	 * @param sowSepFirm the sowSepFirm to set
	 */
	public void setSowSepFirm(BigDecimal sowSepFirm) {
		this.sowSepFirm = sowSepFirm;
	}
	/**
	 * @return the sowOctFirm
	 */
	public BigDecimal getSowOctFirm() {
		return sowOctFirm;
	}
	/**
	 * @param sowOctFirm the sowOctFirm to set
	 */
	public void setSowOctFirm(BigDecimal sowOctFirm) {
		this.sowOctFirm = sowOctFirm;
	}
	/**
	 * @return the sowNovFirm
	 */
	public BigDecimal getSowNovFirm() {
		return sowNovFirm;
	}
	/**
	 * @param sowNovFirm the sowNovFirm to set
	 */
	public void setSowNovFirm(BigDecimal sowNovFirm) {
		this.sowNovFirm = sowNovFirm;
	}
	/**
	 * @return the sowDecFirm
	 */
	public BigDecimal getSowDecFirm() {
		return sowDecFirm;
	}
	/**
	 * @param sowDecFirm the sowDecFirm to set
	 */
	public void setSowDecFirm(BigDecimal sowDecFirm) {
		this.sowDecFirm = sowDecFirm;
	}
	public Integer getYear() {
		return year;
	}
	/**
	 * @param year the year to set
	 */
	public void setYear(Integer year) {
		this.year = year;
	}
	/**
	 * @return the createdDate
	 */
	public Date getCreatedDate() {
		return createdDate;
	}
	/**
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	/**
	 * @return the modifiedDate
	 */
	public Date getModifiedDate() {
		return modifiedDate;
	}
	/**
	 * @param modifiedDate the modifiedDate to set
	 */
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	/**
	 * @return the createdBy
	 */
	public Integer getCreatedBy() {
		return createdBy;
	}
	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}
	/**
	 * @return the modifiedBy
	 */
	public Integer getModifiedBy() {
		return modifiedBy;
	}
	/**
	 * @param modifiedBy the modifiedBy to set
	 */
	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	/**
	 * @return the itemId
	 */
	public Integer getItemId() {
		return itemId;
	}
	/**
	 * @param itemId the itemId to set
	 */
	public void setItemId(Integer itemId) {
		this.itemId = itemId;
	}
	/**
	 * @return the title
	 */
	public String getTitle() {
		return title;
	}
	/**
	 * @param title the title to set
	 */
	public void setTitle(String title) {
		this.title = title;
	}
	
	/**
	 * @return the acctId
	 */
	public Integer getAcctId() {
		return acctId;
	}
	/**
	 * @param acctId the acctId to set
	 */
	public void setAcctId(Integer acctId) {
		this.acctId = acctId;
	}
	/**
	 * @return the sowValue
	 */
	public BigDecimal getSowValue() {
		return sowValue;
	}
	/**
	 * @param sowValue the sowValue to set
	 */
	public void setSowValue(BigDecimal sowValue) {
		this.sowValue = sowValue;
	}
	/**
	 * @return the invoiceValue
	 */
	public BigDecimal getInvoiceValue() {
		return invoiceValue;
	}
	/**
	 * @param invoiceValue the invoiceValue to set
	 */
	public void setInvoiceValue(BigDecimal invoiceValue) {
		this.invoiceValue = invoiceValue;
	}
	
	/**
	 * @return the monthNo
	 */
	public Integer getMonthNo() {
		return monthNo;
	}
	/**
	 * @param monthNo the monthNo to set
	 */
	public void setMonthNo(Integer monthNo) {
		this.monthNo = monthNo;
	}
	
	public Integer getCmsId() {
		return cmsId;
	}
	public void setCmsId(Integer cmsId) {
		this.cmsId = cmsId;
	}
	@Transient
	public Integer getAccountId() {
		return accountId;
	}
	public void setAccountId(Integer accountId) {
		this.accountId = accountId;
	}
	@Transient
	public String getAccountName() {
		return accountName;
	}
	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}
	@Transient
	public String getCurrencySign() {
		return currencySign;
	}
	public void setCurrencySign(String currencySign) {
		this.currencySign = currencySign;
	}
	
	@Transient
	public String getInvoiceCurrencySign() {
		return invoiceCurrencySign;
	}
	public void setInvoiceCurrencySign(String invoiceCurrencySign) {
		this.invoiceCurrencySign = invoiceCurrencySign;
	}		
	
	/**
	 * @return the valueType
	 */
	public String getBusinessType() {
		return businessType;
	}
	/**
	 * @param valueType the valueType to set
	 */
	public void setBusinessType(String businessType) {
		this.businessType = businessType;
	}
	/**
	 * @return the deleteStatus
	 */
	public Boolean getDeleteStatus() {
		return deleteStatus;
	}
	/**
	 * @param deleteStatus the deleteStatus to set
	 */
	public void setDeleteStatus(Boolean deleteStatus) {
		this.deleteStatus = deleteStatus;
	}
	
	/**
	 * @return the cmsIdfrmCMS
	 */
	public Integer getCmsIdfrmCMS() {
		return cmsIdfrmCMS;
	}
	/**
	 * @param cmsIdfrmCMS the cmsIdfrmCMS to set
	 */
	public void setCmsIdfrmCMS(Integer cmsIdfrmCMS) {
		this.cmsIdfrmCMS = cmsIdfrmCMS;
	}
	
	@Transient
	public BigDecimal getContractGapPercent() {
		return contractGapPercent;
	}

	public void setContractGapPercent(BigDecimal contractGapPercent) {
		this.contractGapPercent = contractGapPercent;
	}
	
	/**
	 * @return the billingType
	 */
	public String getBillingType() {
		return billingType;
	}
	/**
	 * @param billingType the billingType to set
	 */
	public void setBillingType(String billingType) {
		this.billingType = billingType;
	}
	
	/**
	 * @return the janComment
	 */
	public String getJanComment() {
		return janComment;
	}
	/**
	 * @param janComment the janComment to set
	 */
	public void setJanComment(String janComment) {
		this.janComment = janComment;
	}
	/**
	 * @return the febComment
	 */
	public String getFebComment() {
		return febComment;
	}
	/**
	 * @param febComment the febComment to set
	 */
	public void setFebComment(String febComment) {
		this.febComment = febComment;
	}
	/**
	 * @return the marComment
	 */
	public String getMarComment() {
		return marComment;
	}
	/**
	 * @param marComment the marComment to set
	 */
	public void setMarComment(String marComment) {
		this.marComment = marComment;
	}
	/**
	 * @return the aprComment
	 */
	public String getAprComment() {
		return aprComment;
	}
	/**
	 * @param aprComment the aprComment to set
	 */
	public void setAprComment(String aprComment) {
		this.aprComment = aprComment;
	}
	/**
	 * @return the mayComment
	 */
	public String getMayComment() {
		return mayComment;
	}
	/**
	 * @param mayComment the mayComment to set
	 */
	public void setMayComment(String mayComment) {
		this.mayComment = mayComment;
	}
	/**
	 * @return the junComment
	 */
	public String getJunComment() {
		return junComment;
	}
	/**
	 * @param junComment the junComment to set
	 */
	public void setJunComment(String junComment) {
		this.junComment = junComment;
	}
	/**
	 * @return the julComment
	 */
	public String getJulComment() {
		return julComment;
	}
	/**
	 * @param julComment the julComment to set
	 */
	public void setJulComment(String julComment) {
		this.julComment = julComment;
	}
	/**
	 * @return the augComment
	 */
	public String getAugComment() {
		return augComment;
	}
	/**
	 * @param augComment the augComment to set
	 */
	public void setAugComment(String augComment) {
		this.augComment = augComment;
	}
	/**
	 * @return the sepComment
	 */
	public String getSepComment() {
		return sepComment;
	}
	/**
	 * @param sepComment the sepComment to set
	 */
	public void setSepComment(String sepComment) {
		this.sepComment = sepComment;
	}
	/**
	 * @return the octComment
	 */
	public String getOctComment() {
		return octComment;
	}
	/**
	 * @param octComment the octComment to set
	 */
	public void setOctComment(String octComment) {
		this.octComment = octComment;
	}
	/**
	 * @return the novComment
	 */
	public String getNovComment() {
		return novComment;
	}
	/**
	 * @param novComment the novComment to set
	 */
	public void setNovComment(String novComment) {
		this.novComment = novComment;
	}
	/**
	 * @return the decComment
	 */
	public String getDecComment() {
		return decComment;
	}
	/**
	 * @param decComment the decComment to set
	 */
	public void setDecComment(String decComment) {
		this.decComment = decComment;
	}
	
	/**
	 * @return the opportunityValue
	 */
	public BigDecimal getOpportunityValue() {
		return opportunityValue;
	}
	/**
	 * @param opportunityValue the opportunityValue to set
	 */
	public void setOpportunityValue(BigDecimal opportunityValue) {
		this.opportunityValue = opportunityValue;
	}
	
	/**
	 * @return the opportunityName
	 */
	public String getOpportunityName() {
		return opportunityName;
	}
	/**
	 * @param opportunityName the opportunityName to set
	 */
	public void setOpportunityName(String opportunityName) {
		this.opportunityName = opportunityName;
	}
	
	/**
	 * @return the projectManagersId
	 */
	public Integer getUid() {
		return uid;
	}
	/**
	 * @param projectManagersId the projectManagersId to set
	 */
	public void setUid(Integer uid) {
		this.uid = uid;
	}
	/**
	 * @return the pmName
	 */
	public String getPmName() {
		return pmName;
	}
	/**
	 * @param pmName the pmName to set
	 */
	public void setPmName(String pmName) {
		this.pmName = pmName;
	}
	public RevenueProjection() {
	}
	
	public RevenueProjection(Integer revId, Integer projectId, Integer acctId,BigDecimal sowJanFirm,
			BigDecimal sowFebFirm, BigDecimal sowMarFirm, BigDecimal sowAprFirm, BigDecimal sowMayFirm,
			BigDecimal sowJunFirm, BigDecimal sowJulFirm, BigDecimal sowAugFirm, BigDecimal sowSepFirm,
			BigDecimal sowOctFirm, BigDecimal sowNovFirm, BigDecimal sowDecFirm,
			Integer year, Integer cmsId, Date createdDate, Date modifiedDate, Integer createdBy,
			Integer modifiedBy, Integer itemId, String title, Integer accountId,BigDecimal sowValue, BigDecimal invoiceValue,
			Integer monthNo, String currencySign, String invoiceCurrencySign,  String accountName,
			String businessType, Boolean deleteStatus,Integer cmsIdfrmCMS, BigDecimal contractGapPercent,String billingType,String janComment
			,String febComment,String marComment,String aprComment,String mayComment,String junComment,String julComment,String augComment,String sepComment
			,String octComment,String novComment,String decComment,String opportunityName,BigDecimal opportunityValue) {
		super();
		this.revId = revId;
		this.projectId = projectId;
		this.acctId=acctId;
		this.sowJanFirm = sowJanFirm;
		this.sowFebFirm = sowFebFirm;
		this.sowMarFirm = sowMarFirm;
		this.sowAprFirm = sowAprFirm;
		this.sowMayFirm = sowMayFirm;
		this.sowJunFirm = sowJunFirm;
		this.sowJulFirm = sowJulFirm;
		this.sowAugFirm = sowAugFirm;
		this.sowSepFirm = sowSepFirm;
		this.sowOctFirm = sowOctFirm;
		this.sowNovFirm = sowNovFirm;
		this.sowDecFirm = sowDecFirm;
		this.year = year;
		this.cmsId = cmsId;
		this.createdDate = createdDate;
		this.modifiedDate = modifiedDate;
		this.createdBy = createdBy;
		this.modifiedBy = modifiedBy;
		this.itemId = itemId;
		this.title = title;
		this.accountId = accountId;
		this.sowValue = sowValue;
		this.invoiceValue = invoiceValue;
		this.monthNo = monthNo;;
		
		this.accountName = accountName;
		this.currencySign = currencySign;
		this.invoiceCurrencySign = invoiceCurrencySign;	
		this.businessType = businessType;
		this.deleteStatus = deleteStatus;
		this.cmsIdfrmCMS = cmsIdfrmCMS;
		this.contractGapPercent = contractGapPercent;
		this.billingType = billingType;
		this.janComment = janComment;
		this.febComment = febComment;
		this.marComment = marComment;
		this.aprComment = aprComment;
		this.mayComment = mayComment;
		this.junComment = junComment;
		this.julComment = julComment;
		this.augComment = augComment;
		this.sepComment = sepComment;
		this.octComment = octComment;
		this.novComment = novComment;
		this.decComment = decComment;
		this.opportunityName = opportunityName;
		this.opportunityValue = opportunityValue;
	}
	public RevenueProjection(Integer uid, String pmName) {
		super();
		this.uid = uid;
		this.pmName = pmName;
	}
	
}
