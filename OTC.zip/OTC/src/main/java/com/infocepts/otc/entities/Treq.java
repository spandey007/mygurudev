package com.infocepts.otc.entities;

import java.util.Date;

import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.infocepts.otc.utilities.LoadConstant;

@Entity
@Table(catalog=LoadConstant.otc, schema="[dbo]",name="treq")
@SqlResultSetMapping(
	      name = "treq_for_cms",
	      classes = {
	          @ConstructorResult(
	              targetClass = Treq.class,
	              columns = {
	                  @ColumnResult(name = "treqId"),
	                  @ColumnResult(name = "treqNo", type=String.class),
	                  @ColumnResult(name = "skillId"),
	                  @ColumnResult(name = "projectName", type=String.class),
	                  @ColumnResult(name = "priority", type=String.class),
	                  @ColumnResult(name = "requisitionType", type=String.class),
	                  @ColumnResult(name = "opportunityStatus", type=String.class),	                  
	                  @ColumnResult(name = "status", type=String.class),
	                  @ColumnResult(name = "reqStartDate", type=Date.class),	                  
	                  @ColumnResult(name = "reqEndDate", type=Date.class),	                  
	                  @ColumnResult(name = "alcId"),
	                  @ColumnResult(name = "sowDetailId"),
	                  @ColumnResult(name = "cmsDetailId"),
	                  @ColumnResult(name = "accountId"),
	                  @ColumnResult(name = "fulfilledBy"),
	                  @ColumnResult(name = "fulfilledDate", type=Date.class),
	                  @ColumnResult(name = "rejectedDate", type=Date.class),
	                  @ColumnResult(name = "cancelledDate", type=Date.class),
	                  @ColumnResult(name = "amgFulfilledDate", type=Date.class),
	                  @ColumnResult(name = "extension", type=Boolean.class),
	                  @ColumnResult(name = "fulfilmentType", type=String.class),
	                  @ColumnResult(name = "billingPriority", type=String.class),
	                  @ColumnResult(name = "proposedWithUid"),
	                  @ColumnResult(name = "reasonForCancellation", type=String.class),
	                  @ColumnResult(name = "comments", type=String.class),	                 
	                  @ColumnResult(name = "createdBy"),                  
	                  @ColumnResult(name = "createdDate", type=Date.class),
	                  @ColumnResult(name = "modifiedBy"),
	                  @ColumnResult(name = "modifiedDate", type=Date.class),
	                  @ColumnResult(name = "empId"),
	                  @ColumnResult(name = "allocatedResourceName", type=String.class),
	                  @ColumnResult(name = "createdByName", type=String.class),
	                  @ColumnResult(name = "modifiedName", type=String.class),
	                  @ColumnResult(name = "skillName", type=String.class),
	                  @ColumnResult(name = "jobDescription", type=String.class),
	                  @ColumnResult(name = "accountName", type=String.class),
	                  @ColumnResult(name = "location", type=String.class),  // To capture migrated data
	                  @ColumnResult(name = "country", type=String.class),  // To capture migrated data
	                  @ColumnResult(name = "secondarySkillId", type=Integer.class),
	                  @ColumnResult(name = "secondarySkillName", type=String.class),
	                  @ColumnResult(name = "associateLevel", type=String.class),
	                  @ColumnResult(name = "billingPercentage", type=Integer.class),
	                  @ColumnResult(name = "allocationPercentage",type=Integer.class),
	                  @ColumnResult(name = "strategicAccount",type=String.class),
	                  @ColumnResult(name = "movedToHiringOn",type=Date.class),
	                  @ColumnResult(name = "treqComments",type=String.class),
	                  @ColumnResult(name = "billingLossStartDate",type=Date.class),
	                  @ColumnResult(name = "billingLossEndDate",type=Date.class),
	                  @ColumnResult(name = "isMigrated",type=Boolean.class),
	                  @ColumnResult(name = "treqIdInfoHire"),
	                  @ColumnResult(name = "projectNameFromSow", type=String.class),
	                  @ColumnResult(name = "existingAssociateId"), 
	                  @ColumnResult(name = "existingAssociateName", type=String.class)
	              }
	          )
	      }
	)
	@NamedNativeQueries({
		//To get all the Treqs linked to particular CMS by cmsId
	   @NamedNativeQuery(
            name    =   "getTreqByCmsId",
            query   =   "SELECT t.*, rn.title as existingAssociateName, rc.title as createdByName, rm.title as modifiedName,"+
            			" ra.empId,"+
            			" cast(ra.title as varchar) as allocatedResourceName,"+
            		    "'' as accountName,"+
            			"'' as strategicAccount,"+
            			" s.skillName as skillName,"+
            			" ss.skillName as secondarySkillName,"+
            			" '' as projectNameFromSow"+
						" FROM " + LoadConstant.otc + ".[dbo].treq t"+
						" LEFT JOIN " + LoadConstant.otc + ".[dbo].allocation al on al.alcId = t.alcId"+
						" LEFT join " + LoadConstant.infomaster + ".[dbo].resource rc on rc.uid = t.createdBy"+
						" LEFT join " + LoadConstant.infomaster + ".[dbo].resource rm on rm.uid = t.modifiedBy"+
						" LEFT join " + LoadConstant.infomaster + ".[dbo].resource ra on ra.uid = al.uid"+
						" LEFT join " + LoadConstant.infomaster + ".[dbo].resource rn on rn.uid = t.existingAssociateId"+
						" LEFT JOIN " + LoadConstant.otc + ".[dbo].cmsDetail cd ON t.cmsDetailId = cd.cmsDetailId"+
						" LEFT JOIN " + LoadConstant.otc + ".[dbo].cms c ON c.cmsId = cd.cmsId"+
						" left join " + LoadConstant.infomaster + ".[dbo].skill s on s.skillId = t.skillId"+
						" left join " + LoadConstant.infomaster + ".[dbo].skill ss on ss.skillId = t.secondarySkillId"+
						" WHERE c.cmsId = :cmsId"+
						" order by t.treqId",
						resultClass=Treq.class, resultSetMapping = "treq_for_cms"	                                  		
	   ),
	   @NamedNativeQuery(
	            name    =   "getTreqByAccountId",
	            query   =   "SELECT t.*, rn.title as existingAssociateName, rc.title as createdByName, rm.title as modifiedName,"+
	            		" ra.empId,"+
            			" cast(ra.title as varchar) as allocatedResourceName,"+
	            		    "'' as accountName,"+
	            		    "'' as strategicAccount,"+
            				" s.skillName as skillName,"+ 
            				" ss.skillName as secondarySkillName,"+
            				" '' as projectNameFromSow"+
							" FROM " + LoadConstant.otc + ".[dbo].treq t"+
							" LEFT JOIN " + LoadConstant.otc + ".[dbo].allocation al on al.alcId = t.alcId"+
							" LEFT join " + LoadConstant.infomaster + ".[dbo].resource rc on rc.uid = t.createdBy"+
							" LEFT join " + LoadConstant.infomaster + ".[dbo].resource rm on rm.uid = t.modifiedBy"+
							" LEFT join " + LoadConstant.infomaster + ".[dbo].resource ra on ra.uid = al.uid"+
							" LEFT join " + LoadConstant.infomaster + ".[dbo].resource rn on rn.uid = t.existingAssociateId"+
							" left join " + LoadConstant.infomaster + ".[dbo].skill s on s.skillId = t.skillId"+
							" left join " + LoadConstant.infomaster + ".[dbo].skill ss on ss.skillId = t.secondarySkillId"+
							" WHERE t.accountId = :accountId"+
							" order by t.treqId",
							resultClass=Treq.class, resultSetMapping = "treq_for_cms"	                                  		
	   ),
	   @NamedNativeQuery(
            name    =   "getTreqByAllocationId",
            query   =   "SELECT t.*, '' as existingAssociateName, rc.title as createdByName, rm.title as modifiedName,"+
            		" ra.empId,"+
        				" cast(ra.title as varchar) as allocatedResourceName,"+
            		    " '' as accountName,"+
            		    " '' as strategicAccount,"+
            			" s.skillName as skillName,"+ 
            			" ss.skillName as secondarySkillName,"+
            			" '' as projectNameFromSow"+
						" FROM " + LoadConstant.otc + ".[dbo].treq t"+
						" LEFT JOIN " + LoadConstant.otc + ".[dbo].allocation al on al.alcId = t.alcId"+
						" LEFT join " + LoadConstant.infomaster + ".[dbo].resource rc on rc.uid = t.createdBy"+
						" LEFT join " + LoadConstant.infomaster + ".[dbo].resource rm on rm.uid = t.modifiedBy"+
						" LEFT join " + LoadConstant.infomaster + ".[dbo].resource ra on ra.uid = al.uid"+
						" left join " + LoadConstant.infomaster + ".[dbo].skill s on s.skillId = t.skillId"+
						" left join " + LoadConstant.infomaster + ".[dbo].skill ss on ss.skillId = t.secondarySkillId"+
						" LEFT JOIN " + LoadConstant.otc + ".[dbo].allocation a ON a.alcId = t.alcId"+
						
						" WHERE a.alcId = :alcId"+
						" order by t.treqId",
						resultClass=Treq.class, resultSetMapping = "treq_for_cms"	                                  		
	   ),	
	   @NamedNativeQuery(
            name    =   "getTreqBySowDetailId",
            query   =   "SELECT t.*, '' as existingAssociateName, rc.title as createdByName, rm.title as modifiedName,"+
            		" ra.empId,"+
        				" cast(ra.title as varchar) as allocatedResourceName,"+
            		    " '' as accountName,"+
            		    " '' as strategicAccount,"+
            			" s.skillName as skillName,"+ 
            			" ss.skillName as secondarySkillName,"+
            			" '' as projectNameFromSow"+
						" FROM " + LoadConstant.otc + ".[dbo].treq t"+		
						" LEFT JOIN " + LoadConstant.otc + ".[dbo].allocation al on al.alcId = t.alcId"+
						" LEFT join " + LoadConstant.infomaster + ".[dbo].resource rc on rc.uid = t.createdBy"+
						" LEFT join " + LoadConstant.infomaster + ".[dbo].resource rm on rm.uid = t.modifiedBy"+
						" LEFT join " + LoadConstant.infomaster + ".[dbo].resource ra on ra.uid = al.uid"+
						" left join " + LoadConstant.infomaster + ".[dbo].skill s on s.skillId = t.skillId"+
						" left join " + LoadConstant.infomaster + ".[dbo].skill ss on ss.skillId = t.secondarySkillId"+
						" WHERE t.sowDetailId = :sowDetailId"+
						" order by t.treqId",
						resultClass=Treq.class, resultSetMapping = "treq_for_cms"	                                  		
	   ),	
	   @NamedNativeQuery(
	            name    =   "getTreqByCmsDetailId",
	            query   =   "SELECT t.*, '' as existingAssociateName, rc.title as createdByName, rm.title as modifiedName,"+
	            		" ra.empId,"+
            				" cast(ra.title as varchar) as allocatedResourceName,"+
	            		    " '' as accountName,"+
	            		    " '' as strategicAccount,"+
            				" s.skillName as skillName,"+ 
            				" ss.skillName as secondarySkillName,"+
            				" '' as projectNameFromSow"+
							" FROM " + LoadConstant.otc + ".[dbo].treq t"+		
							" LEFT JOIN " + LoadConstant.otc + ".[dbo].allocation al on al.alcId = t.alcId"+
							" LEFT join " + LoadConstant.infomaster + ".[dbo].resource rc on rc.uid = t.createdBy"+
							" LEFT join " + LoadConstant.infomaster + ".[dbo].resource rm on rm.uid = t.modifiedBy"+
							" LEFT join " + LoadConstant.infomaster + ".[dbo].resource ra on ra.uid = al.uid"+
							" left join " + LoadConstant.infomaster + ".[dbo].skill s on s.skillId = t.skillId"+
							" left join " + LoadConstant.infomaster + ".[dbo].skill ss on ss.skillId = t.secondarySkillId"+
							" WHERE t.cmsDetailId = :cmsDetailId"+
							" order by t.treqId",
							resultClass=Treq.class, resultSetMapping = "treq_for_cms"	                                  		
		   ),
	   @NamedNativeQuery(
	            name    =   "getAllTreqs",
	            query   =   "SELECT t.*, '' as existingAssociateName, rc.title as createdByName, rm.title as modifiedName,"+
	            		" ra.empId,"+
            				" cast(ra.title as varchar) as allocatedResourceName,"+
	            		    " cast(pa.title as varchar) as accountName,"+
	            		    " pa.strategic as strategicAccount,"+
	            		    " s.skillName as skillName,"+
	            		    " ss.skillName as secondarySkillName,"+
	            		    " (SELECT pp.title FROM " + LoadConstant.otc + ".[dbo].treq tt" +
	            		    	" LEFT JOIN " + LoadConstant.otc + ".[dbo].sowDetail sdd on sdd.sowDetailId = tt.sowDetailId" +
	            		    	" LEFT JOIN " + LoadConstant.otc + ".[dbo].sow ss on ss.sowId = sdd.sowId" +
	            		    	" LEFT JOIN "+ LoadConstant.infomaster + ".[dbo].project pp on pp.itemId = ss.projectId" + 
	            		    	" WHERE tt.treqId = t.treqId) as projectNameFromSow"+
							" FROM " + LoadConstant.otc + ".[dbo].treq t"+
							" LEFT JOIN " + LoadConstant.otc + ".[dbo].allocation al on al.alcId = t.alcId"+
							" LEFT join " + LoadConstant.infomaster + ".[dbo].resource rc on rc.uid = t.createdBy"+
							" LEFT join " + LoadConstant.infomaster + ".[dbo].resource rm on rm.uid = t.modifiedBy"+
							" LEFT join " + LoadConstant.infomaster + ".[dbo].resource ra on ra.uid = al.uid"+
							" left join " + LoadConstant.infomaster + ".[dbo].accounts pa on t.accountId=pa.itemId"+
							" left join " + LoadConstant.infomaster + ".[dbo].skill s on s.skillId = t.skillId"+
							" left join " + LoadConstant.infomaster + ".[dbo].skill ss on ss.skillId = t.secondarySkillId"+
							" order by t.treqId DESC",
							resultClass=Treq.class, resultSetMapping = "treq_for_cms"	                                  		
		   ),	   
	   @NamedNativeQuery(
	            name    =   "getTreqByAssociate",
	            query   =   "SELECT t.*, '' as existingAssociateName, rc.title as createdByName, rm.title as modifiedName,"+
	            		" ra.empId,"+
            				" cast(ra.title as varchar) as allocatedResourceName,"+
	            		    " cast(pa.title as varchar) as accountName,"+
	            		    " pa.strategic as strategicAccount,"+
	            		    " s.skillName as skillName,"+
	            		    " ss.skillName as secondarySkillName,"+
							" (SELECT pp.title FROM " + LoadConstant.otc + ".[dbo].treq tt" +
	            		    	" LEFT JOIN " + LoadConstant.otc + ".[dbo].sowDetail sdd on sdd.sowDetailId = tt.sowDetailId" +
	            		    	" LEFT JOIN " + LoadConstant.otc + ".[dbo].sow ss on ss.sowId = sdd.sowId" +
	            		    	" LEFT JOIN "+ LoadConstant.infomaster + ".[dbo].project pp on pp.itemId = ss.projectId" + 
	            		    	" WHERE tt.treqId = t.treqId) as projectNameFromSow"+
							" FROM " + LoadConstant.otc + ".[dbo].treq t"+
							" LEFT JOIN " + LoadConstant.otc + ".[dbo].allocation al on al.alcId = t.alcId"+
							" LEFT join " + LoadConstant.infomaster + ".[dbo].resource rc on rc.uid = t.createdBy"+
							" LEFT join " + LoadConstant.infomaster + ".[dbo].resource rm on rm.uid = t.modifiedBy"+
							" LEFT join " + LoadConstant.infomaster + ".[dbo].resource ra on ra.uid = al.uid"+
							" left join " + LoadConstant.infomaster + ".[dbo].accounts pa on t.accountId=pa.itemId"+
							" left join " + LoadConstant.infomaster + ".[dbo].skill s on s.skillId = t.skillId"+
							" left join " + LoadConstant.infomaster + ".[dbo].skill ss on ss.skillId = t.secondarySkillId"+
							" WHERE t.createdBy = :createdBy or pa.rmId = :cepId"+
							" order by t.treqId DESC",
							resultClass=Treq.class, resultSetMapping = "treq_for_cms"	                                  		
		   ),
	   @NamedNativeQuery(
	            name    =   "getTreqByProject",
	            query   =   "SELECT t.*, rn.title as existingAssociateName, rc.title as createdByName, rm.title as modifiedName,"+
	            		" ra.empId,"+
            				" cast(ra.title as varchar) as allocatedResourceName,"+
	            		    " cast(pa.title as varchar) as accountName,"+
	            		    " pa.strategic as strategicAccount,"+
	            		    " s.skillName as skillName,"+
	            		    " ss.skillName as secondarySkillName,"+
							" (SELECT pp.title FROM " + LoadConstant.otc + ".[dbo].treq tt" +
	            		    	" LEFT JOIN " + LoadConstant.otc + ".[dbo].sowDetail sdd on sdd.sowDetailId = tt.sowDetailId" +
	            		    	" LEFT JOIN " + LoadConstant.otc + ".[dbo].sow ss on ss.sowId = sdd.sowId" +
	            		    	" LEFT JOIN "+ LoadConstant.infomaster + ".[dbo].project pp on pp.itemId = ss.projectId" + 
	            		    	" WHERE tt.treqId = t.treqId) as projectNameFromSow"+
	            		    	" ,(SELECT ss.projectId FROM " + LoadConstant.otc + ".[dbo].treq tt"+
	            		    	" LEFT JOIN " + LoadConstant.otc + ".[dbo].sowDetail sdd on sdd.sowDetailId = tt.sowDetailId"+
	            		    	" LEFT JOIN " + LoadConstant.otc + ".[dbo].sow ss on ss.sowId = sdd.sowId"+
	            		    	" LEFT JOIN " + LoadConstant.infomaster + ".[dbo].project pp on pp.itemId = ss.projectId"+
	            		    	" WHERE tt.treqId = t.treqId) as projectId"+
							" FROM " + LoadConstant.otc + ".[dbo].treq t"+
							" LEFT JOIN " + LoadConstant.otc + ".[dbo].allocation al on al.alcId = t.alcId"+
							" LEFT join " + LoadConstant.infomaster + ".[dbo].resource rc on rc.uid = t.createdBy"+
							" LEFT join " + LoadConstant.infomaster + ".[dbo].resource rm on rm.uid = t.modifiedBy"+
							" LEFT join " + LoadConstant.infomaster + ".[dbo].resource ra on ra.uid = al.uid"+
							" LEFT join " + LoadConstant.infomaster + ".[dbo].resource rn on rn.uid = t.existingAssociateId"+
							" left join " + LoadConstant.infomaster + ".[dbo].accounts pa on t.accountId=pa.itemId"+
							" left join " + LoadConstant.infomaster + ".[dbo].skill s on s.skillId = t.skillId"+
							" left join " + LoadConstant.infomaster + ".[dbo].skill ss on ss.skillId = t.secondarySkillId"+
							" WHERE t.sowDetailId in"+ 
							"(select sowDetailId from " + LoadConstant.otc + ".[dbo].[sowDetail] where"+
							" sowId in (select sowId from " + LoadConstant.otc + ".[dbo].[sow] where projectId = :projectId))"+
							" order by t.treqId DESC",
							resultClass=Treq.class, resultSetMapping = "treq_for_cms"	                                  		
		   ),
	   @NamedNativeQuery(
	            name    =   "getTreqById",
	            query   =   "SELECT t.*, rn.title as existingAssociateName, rc.title as createdByName, rm.title as modifiedName,"+
	            		" ra.empId,"+
        					" cast(ra.title as varchar) as allocatedResourceName,"+
	            		    " cast(pa.title as varchar) as accountName,"+
	            		    " pa.strategic as strategicAccount,"+
	            		    " s.skillName as skillName,"+
	            		    " ss.skillName as secondarySkillName,"+
	            		    " (SELECT pp.title FROM " + LoadConstant.otc + ".[dbo].treq tt" +
            		    	" LEFT JOIN " + LoadConstant.otc + ".[dbo].sowDetail sdd on sdd.sowDetailId = tt.sowDetailId" +
            		    	" LEFT JOIN " + LoadConstant.otc + ".[dbo].sow ss on ss.sowId = sdd.sowId" +
            		    	" LEFT JOIN "+ LoadConstant.infomaster + ".[dbo].project pp on pp.itemId = ss.projectId" + 
            		    	" WHERE tt.treqId = t.treqId) as projectNameFromSow"+
							" FROM " + LoadConstant.otc + ".[dbo].treq t"+
							" LEFT join " + LoadConstant.otc + ".[dbo].allocation a on a.alcId = t.alcId"+
							" LEFT join " + LoadConstant.infomaster + ".[dbo].resource rc on rc.uid = t.createdBy"+
							" LEFT join " + LoadConstant.infomaster + ".[dbo].resource rm on rm.uid = t.modifiedBy"+							
							" LEFT join " + LoadConstant.infomaster + ".[dbo].resource ra on ra.uid = a.uid"+
							" LEFT join " + LoadConstant.infomaster + ".[dbo].resource rn on rn.uid = t.existingAssociateId"+
							" left join " + LoadConstant.infomaster + ".[dbo].accounts pa on t.accountId=pa.itemId"+
							" left join " + LoadConstant.infomaster + ".[dbo].skill s on s.skillId = t.skillId"+
							" left join " + LoadConstant.infomaster + ".[dbo].skill ss on ss.skillId = t.secondarySkillId"+
							" WHERE t.treqId = :treqId"+
							" order by t.treqId DESC",
							resultClass=Treq.class, resultSetMapping = "treq_for_cms"	                                  		
		   ),
	   @NamedNativeQuery(
	            name    =   "getAllTreqsByTreqStatus",
	            query   =   "SELECT t.*, '' as existingAssociateName, rc.title as createdByName, rm.title as modifiedName,"+
	            		" ra.empId,"+
           				" cast(ra.title as varchar) as allocatedResourceName,"+
	            		    " cast(pa.title as varchar) as accountName,"+
	            		    " pa.strategic as strategicAccount,"+
	            		    " s.skillName as skillName,"+
	            		    " ss.skillName as secondarySkillName,"+
	            		    " (SELECT pp.title FROM " + LoadConstant.otc + ".[dbo].treq tt" +
	            		    	" LEFT JOIN " + LoadConstant.otc + ".[dbo].sowDetail sdd on sdd.sowDetailId = tt.sowDetailId" +
	            		    	" LEFT JOIN " + LoadConstant.otc + ".[dbo].sow ss on ss.sowId = sdd.sowId" +
	            		    	" LEFT JOIN "+ LoadConstant.infomaster + ".[dbo].project pp on pp.itemId = ss.projectId" + 
	            		    	" WHERE tt.treqId = t.treqId) as projectNameFromSow"+
							" FROM " + LoadConstant.otc + ".[dbo].treq t"+
							" LEFT JOIN " + LoadConstant.otc + ".[dbo].allocation al on al.alcId = t.alcId"+
							" LEFT join " + LoadConstant.infomaster + ".[dbo].resource rc on rc.uid = t.createdBy"+
							" LEFT join " + LoadConstant.infomaster + ".[dbo].resource rm on rm.uid = t.modifiedBy"+
							" LEFT join " + LoadConstant.infomaster + ".[dbo].resource ra on ra.uid = al.uid"+
							" left join " + LoadConstant.infomaster + ".[dbo].accounts pa on t.accountId=pa.itemId"+
							" left join " + LoadConstant.infomaster + ".[dbo].skill s on s.skillId = t.skillId"+
							" left join " + LoadConstant.infomaster + ".[dbo].skill ss on ss.skillId = t.secondarySkillId"+
							" where t.status = :status or 'ALL' = :status"+
							" order by t.treqId DESC",
							resultClass=Treq.class, resultSetMapping = "treq_for_cms"	                                  		
		   )	
})
@DynamicUpdate
@DynamicInsert
public class Treq {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer treqId;
	
	private String treqNo;
	
	private Integer skillId;
	
	private String projectName; //Temp project name to be used for displaying migrated data
	
	private String priority;
	
	private String requisitionType;
	
	private String opportunityStatus;//autofill 
	
	private String status;//treqStatus
	
	private Date reqStartDate;	
	private Date reqEndDate;
	
	@ManyToOne
	@JoinColumn(name="alcId")
	private Allocation allocation;
	
	@ManyToOne
	@JoinColumn(name="sowDetailId")
	private SowDetail sowDetail;
	
	@ManyToOne
	@JoinColumn(name="cmsDetailId")
	private CmsDetail cmsDetail;
	
	private Integer accountId;
	
	private Integer fulfilledBy;
	private Date fulfilledDate;
	private Date rejectedDate;
	private Date cancelledDate;
	private Date amgFulfilledDate;
	// This field will hold value as "true" if the TREQ is an existing TREQ, false otherwise.
	private Boolean extension;
	
	private String fulfilmentType; // Internal or External
	
	private String billingPriority;
	@Lob
	private String jobDescription;
	
	private Integer proposedWithUid;
	private String reasonForCancellation;
	private String comments;
	
	private Integer createdBy;
	private Date createdDate;
	private Integer modifiedBy;
	private Date modifiedDate;
	@Transient
	private Integer empId;
	@Transient
	private String allocatedResourceName;	
	@Transient
	private String createdByName;
	@Transient
	private String modifiedName;
	
	@Transient
	private String skillName;
	
	@Transient
	private String secondarySkillName;
	
	
	@Transient
	private String accountName;
	@Transient
	private String strategicAccount;
	
	// To be only used for display purpose (migrated data in string, save string for new treqs as well)
	//-----------------------------------------------------------------------
	private String location; 
	private String country;
	//only for migration fields
	private Integer secondarySkillId;
	private String associateLevel;
	private Integer billingPercentage;
	private Integer allocationPercentage;
	private Date movedToHiringOn;
	@Lob
	private String treqComments;
	private Date billingLossStartDate;
	private Date billingLossEndDate;
	private Boolean isMigrated;
	
	private Integer treqIdInfoHire;
	
	private Integer existingAssociateId;
	
	@Transient
	private String existingAssociateName;
	
	@Transient
	private Boolean isTreqPage;

	// rkj - New fields added - Vidisha to implement these
	//private String grade;  
	
	
	//Getter and Setter
	public Integer getTreqId() {
		return treqId;
	}
	public void setTreqId(Integer treqId) {
		this.treqId = treqId;
	}
	
	public String getTreqNo() {
		return treqNo;
	}
	public void setTreqNo(String treqNo) {
		this.treqNo = treqNo;
	}
	public Integer getSkillId() {
		return skillId;
	}
	public void setSkillId(Integer skillId) {
		this.skillId = skillId;
	}
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	public String getPriority() {
		return priority;
	}
	public void setPriority(String priority) {
		this.priority = priority;
	}
	public String getRequisitionType() {
		return requisitionType;
	}
	public void setRequisitionType(String requisitionType) {
		this.requisitionType = requisitionType;
	}
	public String getOpportunityStatus() {
		return opportunityStatus;
	}
	public void setOpportunityStatus(String opportunityStatus) {
		this.opportunityStatus = opportunityStatus;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}	
	public Date getReqStartDate() {
		return reqStartDate;
	}
	public void setReqStartDate(Date reqStartDate) {
		this.reqStartDate = reqStartDate;
	}
	public Date getReqEndDate() {
		return reqEndDate;
	}
	public void setReqEndDate(Date reqEndDate) {
		this.reqEndDate = reqEndDate;
	}
	public Allocation getAllocation() {
		return allocation;
	}
	public void setAllocation(Allocation allocation) {
		this.allocation = allocation;
	}
	public SowDetail getSowDetail() {
		return sowDetail;
	}
	public void setSowDetail(SowDetail sowDetail) {
		this.sowDetail = sowDetail;
	}
	public Integer getAccountId() {
		return accountId;
	}
	public void setAccountId(Integer accountId) {
		this.accountId = accountId;
	}	
	public String getFulfilmentType() {
		return fulfilmentType;
	}
	public void setFulfilmentType(String fulfilmentType) {
		this.fulfilmentType = fulfilmentType;
	}
	public Integer getProposedWithUid() {
		return proposedWithUid;
	}
	public void setProposedWithUid(Integer proposedWithUid) {
		this.proposedWithUid = proposedWithUid;
	}
	public String getReasonForCancellation() {
		return reasonForCancellation;
	}
	public void setReasonForCancellation(String reasonForCancellation) {
		this.reasonForCancellation = reasonForCancellation;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public Integer getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public Integer getFulfilledBy() {
		return fulfilledBy;
	}
	public void setFulfilledBy(Integer fulfilledBy) {
		this.fulfilledBy = fulfilledBy;
	}
	public Date getFulfilledDate() {
		return fulfilledDate;
	}
	public void setFulfilledDate(Date fulfilledDate) {
		this.fulfilledDate = fulfilledDate;
	}
	public Integer getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public Date getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	
	/**
	 * @return the empId
	 */
	public Integer getEmpId() {
		return empId;
	}
	/**
	 * @param empId the empId to set
	 */
	public void setEmpId(Integer empId) {
		this.empId = empId;
	}
	@Transient
	public String getAllocatedResourceName() {
		return allocatedResourceName;
	}
	public void setAllocatedResourceName(String allocatedResourceName) {
		this.allocatedResourceName = allocatedResourceName;
	}
	@Transient
	public String getCreatedByName() {
		return createdByName;
	}
	public void setCreatedByName(String createdByName) {
		this.createdByName = createdByName;
	}
	@Transient
	public String getModifiedName() {
		return modifiedName;
	}
	public void setModifiedName(String modifiedName) {
		this.modifiedName = modifiedName;
	}
	@Transient
	public String getSkillName() {
		return skillName;
	}
	public void setSkillName(String skillName) {
		this.skillName = skillName;
	}
	@Transient
	public String getSecondarySkillName() {
		return secondarySkillName;
	}
	public void setSecondarySkillName(String secondarySkillName) {
		this.secondarySkillName = secondarySkillName;
	}
	public CmsDetail getCmsDetail() {
		return cmsDetail;
	}
	public void setCmsDetail(CmsDetail cmsDetail) {
		this.cmsDetail = cmsDetail;
	}
	public String getJobDescription() {
		return jobDescription;
	}

	public void setJobDescription(String jobDescription) {
		this.jobDescription = jobDescription;
	}
	@Transient
	public String getAccountName() {
		return accountName;
	}
	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public String getStrategicAccount() {
		return strategicAccount;
	}
	public void setStrategicAccount(String strategicAccount) {
		this.strategicAccount = strategicAccount;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getBillingPriority() {
		return billingPriority;
	}
	public void setBillingPriority(String billingPriority) {
		this.billingPriority = billingPriority;
	}
	public Integer getSecondarySkillId() {
		return secondarySkillId;
	}
	public void setSecondarySkillId(Integer secondarySkillId) {
		this.secondarySkillId = secondarySkillId;
	}
	public String getAssociateLevel() {
		return associateLevel;
	}
	public void setAssociateLevel(String associateLevel) {
		this.associateLevel = associateLevel;
	}
	public Integer getBillingPercentage() {
		return billingPercentage;
	}
	public void setBillingPercentage(Integer billingPercentage) {
		this.billingPercentage = billingPercentage;
	}
	public Integer getAllocationPercentage() {
		return allocationPercentage;
	}
	public void setAllocationPercentage(Integer allocationPercentage) {
		this.allocationPercentage = allocationPercentage;
	}
	public Date getMovedToHiringOn() {
		return movedToHiringOn;
	}
	public void setMovedToHiringOn(Date movedToHiringOn) {
		this.movedToHiringOn = movedToHiringOn;
	}

	public String getTreqComments() {
		return treqComments;
	}
	public void setTreqComments(String treqComments) {
		this.treqComments = treqComments;
	}
	public Date getBillingLossStartDate() {
		return billingLossStartDate;
	}
	public void setBillingLossStartDate(Date billingLossStartDate) {
		this.billingLossStartDate = billingLossStartDate;
	}
	public Date getBillingLossEndDate() {
		return billingLossEndDate;
	}
	public void setBillingLossEndDate(Date billingLossEndDate) {
		this.billingLossEndDate = billingLossEndDate;
	}
	public Boolean getIsMigrated() {
		return isMigrated;
	}
	public void setIsMigrated(Boolean isMigrated) {
		this.isMigrated = isMigrated;
	}
	public Integer getTreqIdInfoHire() {
		return treqIdInfoHire;
	}
	public void setTreqIdInfoHire(Integer treqIdInfoHire) {
		this.treqIdInfoHire = treqIdInfoHire;
	}	
	public Integer getExistingAssociateId() {
		return existingAssociateId;
	}
	public void setExistingAssociateId(Integer existingAssociateId) {
		this.existingAssociateId = existingAssociateId;
	}
	public String getExistingAssociateName() {
		return existingAssociateName;
	}
	public void setExistingAssociateName(String existingAssociateName) {
		this.existingAssociateName = existingAssociateName;
	}

	public Boolean getIsTreqPage() {
		return isTreqPage;
	}
	public void setIsTreqPage(Boolean isTreqPage) {
		this.isTreqPage = isTreqPage;
	}
	
	public Treq() {
	}
	
	public Treq(Integer treqId, String treqNo, Integer skillId, String projectName, String priority, String requisitionType, String opportunityStatus,
				String status, Date reqStartDate, Date reqEndDate, Integer alcId, Integer sowDetailId, Integer cmsDetailId, Integer accountId,
				Integer fulfilledBy, Date fulfilledDate, Date rejectedDate, Date cancelledDate, Date amgFulfilledDate, Boolean extension, String fulfilmentType, String billingPriority,Integer proposedWithUid, String reasonForCancellation,
				String comments, Integer createdBy, Date createdDate, Integer modifiedBy, Date modifiedDate,Integer empId,
				String allocatedResourceName, String createdByName, String modifiedName, String skillName, String jobDescription,String accountName,
				String location, String country,Integer secondarySkillId, String secondarySkillName,
				String associateLevel,Integer billingPercentage,Integer allocationPercentage, String strategicAccount,
				Date movedToHiringOn, String treqComments, Date billingLossStartDate, Date billingLossEndDate, Boolean isMigrated, 
				Integer treqIdInfoHire, String projectNameFromSow, Integer existingAssociateId,String existingAssociateName)
	{
		this.treqId = treqId;
		if(treqNo != null)
		{
			if(treqNo.equals("") && treqId != null)
				this.treqNo = treqId.toString();
			else
				this.treqNo = treqNo;
		}
		else if(treqId != null)
			this.treqNo = treqId.toString();
		
		this.skillId = skillId;
		
		this.projectName = projectNameFromSow;
		if(projectNameFromSow == null || projectNameFromSow.isEmpty()) this.projectName = projectName;
		
		this.priority = priority;
		this.requisitionType = requisitionType;
		this.opportunityStatus = opportunityStatus;
		this.status = status;
		this.reqStartDate = reqStartDate;
		this.reqEndDate = reqEndDate;
		
		this.allocation = null;
		if(alcId != null)
		{
			this.allocation = new Allocation();
			this.allocation.setAlcId(alcId);
		}
		
		this.sowDetail = null;
		if(sowDetailId != null)
		{
			this.sowDetail = new SowDetail();
			this.sowDetail.setSowDetailId(sowDetailId);
		}
		
		this.cmsDetail = null;
		if(cmsDetailId != null)
		{
			this.cmsDetail = new CmsDetail();
			this.cmsDetail.setCmsDetailId(cmsDetailId);
		}
		
		this.accountId = accountId;
		
		this.fulfilledBy = fulfilledBy;
		this.fulfilledDate = fulfilledDate;
		this.fulfilmentType = fulfilmentType;
		//Set FulfillmentType =  'Internal' by default
		if(fulfilmentType == null)
		{
			this.fulfilmentType = "Internal";
		}
		this.billingPriority=billingPriority;
		this.proposedWithUid = proposedWithUid;
		this.reasonForCancellation = reasonForCancellation;
		this.comments = comments;
		
		this.createdBy = createdBy;
		this.createdDate = createdDate;
		this.modifiedBy = modifiedBy;
		this.modifiedDate = modifiedDate;
		this.empId = empId;
		this.allocatedResourceName = allocatedResourceName;
		this.createdByName = createdByName;
		this.modifiedName = modifiedName;
		this.skillName = skillName;
		this.jobDescription = jobDescription;
		this.accountName=accountName;
		
		this.location = location; // To capture migrated data
		this.country = country;  // To capture migrated data
		this.secondarySkillId=secondarySkillId;
		this.secondarySkillName = secondarySkillName;
		this.associateLevel=associateLevel;
		this.billingPercentage=billingPercentage;
		this.allocationPercentage=allocationPercentage;
		this.strategicAccount = strategicAccount;
		this.movedToHiringOn = movedToHiringOn;
		this.treqComments = treqComments;
		this.billingLossStartDate = billingLossStartDate;
		this.billingLossEndDate = billingLossEndDate;
		this.isMigrated = isMigrated;
		this.treqIdInfoHire = treqIdInfoHire;
		this.rejectedDate = rejectedDate;
		this.cancelledDate = cancelledDate;
		this.amgFulfilledDate = amgFulfilledDate;
		this.extension = extension;
		this.existingAssociateId = existingAssociateId;
		this.existingAssociateName = existingAssociateName;

	}
	/**
	 * @return the rejectedDate
	 */
	public Date getRejectedDate() {
		return rejectedDate;
	}
	/**
	 * @param rejectedDate the rejectedDate to set
	 */
	public void setRejectedDate(Date rejectedDate) {
		this.rejectedDate = rejectedDate;
	}
	/**
	 * @return the cancelledDate
	 */
	public Date getCancelledDate() {
		return cancelledDate;
	}
	/**
	 * @param cancelledDate the cancelledDate to set
	 */
	public void setCancelledDate(Date cancelledDate) {
		this.cancelledDate = cancelledDate;
	}
	/**
	 * @return the amgFulfilledDate
	 */
	public Date getAmgFulfilledDate() {
		return amgFulfilledDate;
	}
	/**
	 * @param amgFulfilledDate the amgFulfilledDate to set
	 */
	public void setAmgFulfilledDate(Date amgFulfilledDate) {
		this.amgFulfilledDate = amgFulfilledDate;
	}
	/**
	 * @return the extension
	 */
	public Boolean getExtension() {
		return extension;
	}
	/**
	 * @param extension the extension to set
	 */
	public void setExtension(Boolean extension) {
		this.extension = extension;
	}
}
