package com.infocepts.otc.controllers;

import java.util.List;

import javax.mail.MessagingException;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.infocepts.otc.entities.Coe;
import com.infocepts.otc.entities.Skill;
import com.infocepts.otc.notification.SmtpMailSender;
import com.infocepts.otc.repositories.SkillRepository;
import com.infocepts.otc.services.TimesheetService;

@RequestMapping(value="/skill",headers="referer")
@RestController
public class SkillController {
	
	final Logger logger = Logger.getLogger(SkillController.class);

	@Autowired
	SkillRepository repository;
	
	 @PersistenceContext(unitName = "otc") 
	    private EntityManager manager;
	 
	@Autowired
	TimesheetService service;
	
	@Autowired
	HttpSession session;
	
	@Autowired
	SmtpMailSender smtpMailSender;
		
	@RequestMapping(method=RequestMethod.POST)
	public void saveSkills(@RequestBody Skill skill, HttpServletRequest request) throws MessagingException{
		try{
			 //All user should be able to request new skill from skill page
				skill.setSkillId(null);
				repository.save(skill);
				service.sendSkillNotification(skill, "add", request); 
			
		}
		catch(Exception e){
			logger.error(e);
		}
	}
	
	@RequestMapping(method=RequestMethod.GET)
	public List<Skill> getSkills(@RequestParam(name="skillCategoryId",defaultValue="0") Integer skillCategoryId,
			@RequestParam(name="skillName",defaultValue="") String skillName,
			@RequestParam(name="isCoeOwner",defaultValue="true") Boolean isCoeOwner)
		
	
	
	{
		List<Skill> skillList=null;
		Integer uid = (Integer) session.getAttribute("loggedInUid");
		try
		{	
			if(skillCategoryId != 0){
					skillList = repository.findBySkillCategoryId(skillCategoryId);
			}
			else if(!skillName.equals("")){
			

			
				skillList = manager.createNamedQuery("SkillByNameQuery", Skill.class)
						.setParameter("skillName", skillName)
						.getResultList();
			}
			else if(isCoeOwner){
				
				skillList = manager.createNamedQuery("SkillByCoEOwner", Skill.class)
					
						.getResultList();
				
			}
			
			
			
			else{
				skillList = manager.createNamedQuery("SkillQuery", Skill.class) .getResultList();
			}
			

		}
		catch(Exception e){
			logger.error(e);
		}
		return skillList;
	}
	
	@RequestMapping(value="/{skillId}",method=RequestMethod.GET)
	public Skill getSkill(@PathVariable Integer skillId){
		Skill skill=null;
		try
		{
			if(skillId != 0){
					skill = repository.findOne(skillId);
			}
		}
		catch(Exception e){
			logger.error(e);
		}
		return skill;
	}
	
	@RequestMapping(value="/{skillId}",method=RequestMethod.PUT)
	public void updateSkills(@PathVariable Integer skillId,@RequestBody Skill updatedskill){
		try{
			Integer uid = (Integer) session.getAttribute("loggedInUid");
			if(updatedskill.getOwnerId().equals(uid.toString())){ 
				updatedskill.setSkillId(skillId);
				repository.save(updatedskill);
			}
		}
		catch(Exception e){
			logger.error(e);
		}
	}
	
	@RequestMapping(value="/{skillId}",method=RequestMethod.DELETE)
	public void deleteSkills(@PathVariable Integer skillId){
			try{
				if(service.isAMG()){
					repository.delete(skillId);
				}
			}
			catch(Exception e){
				logger.error(e);
			}
	}
}
