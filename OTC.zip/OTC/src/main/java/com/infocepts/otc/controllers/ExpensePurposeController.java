/**
 * 
 */
package com.infocepts.otc.controllers;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.infocepts.otc.entities.ExpensePurpose;
import com.infocepts.otc.repositories.ExpensePurposeRepository;
import com.infocepts.otc.utilities.LoadConstant;

/**
 * @author Rewatiraman Singh
 *
 */
@RestController
@RequestMapping("/expensePurpose")
public class ExpensePurposeController extends Object {

	private final Logger logger = Logger.getLogger(ExpensePurposeController.class.getName());
	
	@PersistenceContext(unitName="otc")
    private EntityManager entityManager;
	
	@Autowired
	private ExpensePurposeRepository expensePurposeRepository;
	
	@GetMapping
	public List<ExpensePurpose> getAllExpensePurpose(@RequestParam(value = "status", required = false, defaultValue = "0") Integer status) {
		if (status == LoadConstant.EXPENSE_PURPOSE_ACTIVE) {
			return expensePurposeRepository.findActiveExpensePurposes();
		}
		return expensePurposeRepository.findAll();
	}
	
	@PostMapping
	public Object saveExpensePurpose(@RequestBody List<ExpensePurpose> expensePurposeList) {
		List<ExpensePurpose> emptyPurposeList = new ArrayList<>();
		Map<String, List<ExpensePurpose>> expensePurposeMap = new HashMap<>();
		
		for (ExpensePurpose expensePurpose : expensePurposeList) {
			try {
				emptyPurposeList.add(expensePurposeRepository.save(expensePurpose));
				expensePurposeMap.put("purposes", emptyPurposeList);
			} catch (Exception ex) {
				logger.log(Level.SEVERE, "ERROR WHILE SAVING/UPDATING EXPENSE PURPOSE WITH EXPENSE PURPOSE ID: " + expensePurpose.getPurposeId()
				+ " AND PURPOSE NAME: " + expensePurpose.getPurposeName(), ex);
			}
		}
		
		return expensePurposeMap;
	}
	
	@DeleteMapping
	public Object deleteExpensePurpose(@RequestParam("purposeIds") List<Integer> expensePurposeList) {
		List<Integer> deletedRecords = new ArrayList<>(); 
		Map<String, List<Integer>> deletedRecordsMap = new HashMap<>();
		
		for (Integer expensePurpose : expensePurposeList) {
			try {
				expensePurposeRepository.delete(expensePurpose);
				deletedRecords.add(expensePurpose);
				deletedRecordsMap.put("purposeIds", deletedRecords);
			} catch (Exception ex) {
				logger.log(Level.SEVERE, "ERROR WHILE DELETING EXPENSE PURPOSE WITH EXPENSE PURPOSE ID: " + expensePurpose, ex);
			}
		}
		return deletedRecordsMap;
	}
	
	@GetMapping("/{expensePurposeId}") 
	public ExpensePurpose getExpensePurpose (@RequestParam("expensePurposeId") Integer expensePurposeId) {
		ExpensePurpose expensePurpose  = null;
		if (expensePurposeId != 0) {
			expensePurpose = expensePurposeRepository.findExpensePurpose(expensePurposeId);
		}
		
		if (expensePurpose == null) {
			logger.info("COULD NOT FIND THE EXPENSE PURPOSE WITH ID: " + expensePurposeId);
		}
		return expensePurpose;
	}
}
