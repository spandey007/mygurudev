//package com.infocepts.otc.controllers;
//import java.math.BigDecimal;
//import java.math.RoundingMode;
//import java.sql.ResultSet;
//import java.sql.SQLException;
//import java.sql.Timestamp;
//import java.text.DateFormat;
//import java.text.ParseException;
//import java.text.SimpleDateFormat;
//import java.util.Date;
//import java.util.Iterator;
//import java.util.List;
//
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpSession;
//import javax.sql.DataSource;
//
//import org.apache.log4j.Logger;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;
//
//import com.infocepts.otc.db.EpmDbConfig;
//import com.infocepts.otc.db.OtcDbConfig;
//import com.infocepts.otc.entities.Allocation;
//import com.infocepts.otc.entities.MonthlyAllocation;
//import com.infocepts.otc.loader.ReadFile;
//import com.infocepts.otc.services.TimesheetService;
//import com.infocepts.otc.utilities.LoadConstant;
//
//import org.springframework.jdbc.core.JdbcTemplate;
//import org.springframework.jdbc.core.RowMapper;
//
//
//@RestController
//public class ReadCsvController {
//	
//	final Logger logger = Logger.getLogger(PermissionsUrlsController.class);
//	
//	@Autowired  
//	private JdbcTemplate jdbcTemplate;  
//	
//	@Autowired
//	ReadFile readFile;
//	
//	@Autowired
//	EpmDbConfig epmconfig;
//	
//	@Autowired
//	OtcDbConfig otcconfig;
//	
//	@Autowired
//	HttpSession session;
//		
//	@Autowired
//	TimesheetService service;
//		
//	@RequestMapping(value="/importMonthlyAllocation")//JV: Added 'headers' param to validate the url.
//	public List<?> importMonthlyAllocation(HttpServletRequest request){
//		
//		try{
//			 /*------------------------- Authorization start ------------------------------------ */
//			// Authorization for admin role
//			if(!service.isAdmin())
//			{
//				service.sendTamperedMail("Import Monthly Allocation Data", 0, 0, request);	
//				return null;
//			}
//			/*-- ------------------------- Authorization ends ------------------------------------ */ 
//		}
//		catch(Exception e){
//			logger.error(e);
//		}
//		
//		List<?> rows = null;
//		
//		// Setting the data source as EPM database
//		DataSource datasource = epmconfig.epmDataSource();
//		jdbcTemplate.setDataSource(datasource);
//		
//		/*******************************************************allocation insert logic**************************************************************************************/
//		
//		String alcSql = "SELECT"+
//						"(Select top 1 lpc.[ItemId] from "+ LoadConstant.otc +".[dbo].[project] lpc where cp.[PROJECT NAME] = lpc.Title) as projectId,"+
//						" (Select top 1 Rp.SharePointAccountID from "+ LoadConstant.epmReporting +".[dbo].[LSTResourcepool] RP where cp.[ResourceID] = RP.EXTID order by RP.JoiningDate desc) as uid,"+
//						" cp.[CustomTextField3] as alcStartDate,"+
//						" cp.[CustomTextField4] as alcEndDate,"+
//						" cp.[CustomCodeField1] as alcType,"+
//						" cp.[CMH_FTES] as alcFte,"+
//						" NULL as sowDetailId,"+						
//						" cp.[CustomTextField1] as requisitionId,"+			
//						" cp.[CMT_DESC] as comments,"+
//						" (Select top 1 Rp.SharePointAccountID from "+ LoadConstant.epmReporting +".[dbo].[LSTResourcepool] RP where cp.[CMT_ENTEREDBY_WRES_ID] = RP.EXTID order by RP.JoiningDate desc) as createdBy,"+
//						" cp.[CMT_TIMESTAMP] as createdDate,"+
//						" NULL as modifiedBy,"+
//						" NULL as modifiedDate,"+
//						" count(*) as noOfMonths"+						
//						" FROM "+ LoadConstant.epmReporting +".[dbo].[EPG_RPT_CapacityPlanner] as cp"+
//						" where (cp.[CustomTextField3] != '0' and cp.[CustomTextField3] != '' )"+
//						" and (cp.[CustomTextField4] != '0' and cp.[CustomTextField4] != '')"+
//						" and (cp.[CustomTextField2] != '0' and  cp.[CustomTextField2] != '')"+
//						//" and cp.[ResourceID] = 10814"+
//						" group by cp.[PROJECT NAME], cp.[ResourceID], cp.[CustomTextField3], cp.[CustomTextField4], cp.[CustomCodeField1],"+
//						" cp.[CMH_FTES],"+
//						" cp.[CustomTextField1], cp.[CMT_DESC], cp.[CMT_ENTEREDBY_WRES_ID], cp.[CMT_TIMESTAMP]"+
//						" having count(*) > 1;"
//						;
//		
//		List<Allocation> listAllocation = jdbcTemplate.query(alcSql, new RowMapper<Allocation>() {
//			 
//			 public Allocation mapRow(ResultSet result, int rowNum) throws SQLException {
//				 
//				 /*------------------------- Allocation date conversion Logic start ------------------------------------ */
//				 	// Format Start Date. eliminate .0000	
//				 	String startdatealc = null;
//				    String startdateppms = result.getString("alcStartDate").trim();	    							
//					String[] parts_start = startdateppms.split("\\.");		
//					if(parts_start.length > 0){
//						startdateppms = parts_start[0];	
//						if(startdateppms.length() > 6)
//	 					{
//							String startdateppms_y =startdateppms.substring((startdateppms.length() - 4),(startdateppms.length()));            	
//			            	startdateppms = startdateppms.replace(startdateppms_y, "");//305	                
//				            String startdateppms_d = startdateppms.substring((startdateppms.length() - 2),startdateppms.length());//05
//				            String startdateppms_m = startdateppms.replaceFirst(startdateppms_d, "");//3
//				            if(startdateppms_m.length() == 1) {
//				            	 startdateppms_m = "0" + startdateppms_m;
//				            }		          
//				            startdatealc = startdateppms_y + '-' + startdateppms_m + '-' + startdateppms_d;
//	 					}
//					} 					
//		        
//		            // Generate end date. eliminate .0000
//					String enddatealc = null;
//	  		        String enddateppms = result.getString("alcEndDate").trim(); 
//	 				String[] parts_end = enddateppms.split("\\.");
//	 				if(parts_end.length > 0){
//	 					enddateppms = parts_end[0]; 
//	 					if(enddateppms.length() > 6)
//	 					{
//		 					String enddateppms_y =enddateppms.substring((enddateppms.length() - 4),(enddateppms.length()));
//			 				enddateppms = enddateppms.replace(enddateppms_y, "");//305
//			            	String enddateppms_d = enddateppms.substring((enddateppms.length() - 2),enddateppms.length());//05
//				        	String enddateppms_m = enddateppms.replaceFirst(enddateppms_d, "");//3
//				            if(enddateppms_m.length() == 1) {
//				            	enddateppms_m = "0" + enddateppms_m;
//				            }	  		 
//				            enddatealc = enddateppms_y + '-' + enddateppms_m + '-' + enddateppms_d;
//	 					}
//	 				}	 				
//	 				
//		            
//		            /********************Convert alcFte***********/
//		            BigDecimal bg1 = new BigDecimal("10000");
//		            BigDecimal alcFteNew = result.getBigDecimal("alcFte").divide(bg1);
//		            
//		            /********************Convert alcType***********/
//		            Integer alcType = null;
//		            if(result.getInt("alcType") == 226){alcType = 1;}
//		            if(result.getInt("alcType") == 227){alcType = 2;}
//		            
//		            Allocation alc = new Allocation();
//				 	if(enddatealc != null) alc.setAlcEndDate(convertStringToDate(enddatealc));
//	            	alc.setAlcFte(alcFteNew);	            	
//	            	if(startdatealc != null) alc.setAlcStartDate(convertStringToDate(startdatealc));
//	             	alc.setAlcType(alcType);	              	
//	            	alc.setComments(result.getString("comments"));
//	            	alc.setCreatedBy(result.getInt("createdBy"));
//	              	alc.setCreatedDate(result.getDate("createdDate"));
//	            	alc.setModifiedBy(null);
//	              	alc.setModifiedDate(null);	              	
//	            	alc.setProjectId(result.getInt("projectId"));	          	
//	            	alc.setRequisitionId(result.getString("requisitionId"));
//	            	//alc.setSowDetailId(null);	           
//	            	alc.setUid(result.getInt("uid"));
//	               	return alc; 
//			 }			
//		 });
//		
//		
//		/*------------------------- Allocation insert logic start ------------------------------------ */
//		 int i=0;
//	        for (Allocation aAlc : listAllocation) {
//	        	
//	        	if((aAlc.getAlcEndDate() != null) && (aAlc.getAlcStartDate() != null))
//	        	{
//	        	
//	        	  	String ALC_INSERT_SQL = "Insert into "+ LoadConstant.otc +".[dbo].allocation values (" 						
//											
//	        	  			+ "'" + aAlc.getAlcEndDate()+"', "
//							+ "'" + aAlc.getAlcFte()+"',"												
//							+ "'" + aAlc.getAlcStartDate()+"', "
//							+ "NULL, "
//							+ "'" + aAlc.getAlcType()+"',"
//							+ "'" + aAlc.getComments()+"',"								
//							+ "'" + aAlc.getCreatedBy()+"',"
//							+ "'" + aAlc.getCreatedDate()+"',"
//							+ "NULL, "	
//							+ "NULL, "						
//							+ "'" + aAlc.getProjectId()+"', "
//							+ "'" + aAlc.getRequisitionId()+"', "
//							+ "'" + aAlc.getUid()+"', "
//							+ "NULL "
//							+ ")";	
//	        	  	System.out.println(i+"sql======>"+ ALC_INSERT_SQL);
//	        	 
//		        	// Setting the data source as OTC database
//		        	datasource = otcconfig.otcDataSource();
//		     		jdbcTemplate.setDataSource(datasource);
//	
//		     		//jdbcTemplate.update(ALC_INSERT_SQL);
//	        	}
//	             
//	            i++;
//	            /*------------------------- Allocation insert logic end ------------------------------------ */
//	        }
//	        //System.out.println("Total "+ i + " allocations imported successfully in allocation table");
//		
//	
//		
//		        /*******************************************************monthly_allocation insert logic start***********************************************************************************/
//	        
//	        String monthlyAlcSql = "SELECT "+
//					"(Select top 1 lpc.[ItemId] from "+ LoadConstant.otc +".[dbo].[project] lpc where cp.[PROJECT NAME] = lpc.Title) as projectId,"+
//					"(Select top 1 Rp.SharePointAccountID from "+ LoadConstant.epmReporting +".[dbo].[LSTResourcepool] RP where cp.[ResourceID] = RP.EXTID order by RP.JoiningDate desc) as uid,"+
//					" cp.[CustomTextField3] as alcStartDate,"+
//					" cp.[CustomTextField4] as alcEndDate,"+
//					" cp.[CustomCodeField1] as alcType,"+ //billable-nonbillable
//					" cp.[CMH_FTES] as alcFte,"+
//					" cp.[PeriodID] as prdId," +//month master
//					" cp.[Period Name] as prdName,"+				
//					" cp.[Hours] as alcHrs,"+
//					" NULL as sowDetailId,"+// need to be added from migration.. logic to be decided
//					" cp.[CustomTextField1] as requisitionId,"+				
//					" cp.[CMT_DESC] as comments,"+
//					" (Select top 1 Rp.SharePointAccountID from "+ LoadConstant.epmReporting +".[dbo].[LSTResourcepool] RP where cp.[CMT_ENTEREDBY_WRES_ID] = RP.EXTID order by RP.JoiningDate desc) as createdBy,"+
//					" cp.[CMT_TIMESTAMP] as createdDate,"+
//					" NULL as modifiedBy,"+
//					" NULL as modifiedDate"+
//					" FROM "+ LoadConstant.epmReporting +".[dbo].[EPG_RPT_CapacityPlanner] as cp"+
//					" where (cp.[CustomTextField3] != '0' and cp.[CustomTextField3] != '' )"+ // omit where allocation start date is not set
//					" and (cp.[CustomTextField4] != '0' and cp.[CustomTextField4] != '')" // omit where allocation end date is not set
//					+ " and (cp.[CustomTextField2] != '0' and  cp.[CustomTextField2] != '')" // where allocation fte is not set 24298
//					;
//	        
//	        List<MonthlyAllocation> listMonthlyAllocation = jdbcTemplate.query(monthlyAlcSql, new RowMapper<MonthlyAllocation>() {
//				 
//				 public MonthlyAllocation mapRow(ResultSet result, int rowNum) throws SQLException {
//					 
//					 /*------------------------- Allocation date conversion Logic start ------------------------------------ */
//					 	// Format Start Date. eliminate .0000	
//					 	String startdatealc = null;
//					    String startdateppms = result.getString("alcStartDate").trim();	    							
//						String[] parts_start = startdateppms.split("\\.");		
//						if(parts_start.length > 0){
//							startdateppms = parts_start[0];	
//							if(startdateppms.length() > 6)
//		 					{
//								String startdateppms_y =startdateppms.substring((startdateppms.length() - 4),(startdateppms.length()));            	
//				            	startdateppms = startdateppms.replace(startdateppms_y, "");//305	                
//					            String startdateppms_d = startdateppms.substring((startdateppms.length() - 2),startdateppms.length());//05
//					            String startdateppms_m = startdateppms.replaceFirst(startdateppms_d, "");//3
//					            if(startdateppms_m.length() == 1) {
//					            	 startdateppms_m = "0" + startdateppms_m;
//					            }		          
//					            startdatealc = startdateppms_y + '-' + startdateppms_m + '-' + startdateppms_d;
//		 					}
//						} 					
//			        
//			            // Generate end date. eliminate .0000
//						String enddatealc = null;
//		  		        String enddateppms = result.getString("alcEndDate").trim(); 
//		 				String[] parts_end = enddateppms.split("\\.");
//		 				if(parts_end.length > 0){
//		 					enddateppms = parts_end[0]; 
//		 					if(enddateppms.length() > 6)
//		 					{
//			 					String enddateppms_y =enddateppms.substring((enddateppms.length() - 4),(enddateppms.length()));
//				 				enddateppms = enddateppms.replace(enddateppms_y, "");//305
//				            	String enddateppms_d = enddateppms.substring((enddateppms.length() - 2),enddateppms.length());//05
//					        	String enddateppms_m = enddateppms.replaceFirst(enddateppms_d, "");//3
//					            if(enddateppms_m.length() == 1) {
//					            	enddateppms_m = "0" + enddateppms_m;
//					            }	  		 
//					            enddatealc = enddateppms_y + '-' + enddateppms_m + '-' + enddateppms_d;
//		 					}
//		 				}	 				
//		 				/*------------------------- Allocation date conversion Logic end ------------------------------------ */
//			            	            	
//			            String prdName = result.getString("prdName").trim(); 
//		 				String[] prdName_arr = prdName.split(" ");
//		 				Integer prdYear = Integer.parseInt(prdName_arr[1]);; //2017		 string but need to store as integer		
//			            String prdMonthName = prdName_arr[0];//Jan, Feb ...
//			            
//			            /********************Need generalized method for getting month num from name***********/
//			            Integer prdMonth = 0;
//			            if(("Jan").equals(prdMonthName)){ prdMonth = 1;} 
//			            if(("Feb").equals(prdMonthName)){ prdMonth = 2;} 
//			            if(("Mar").equals(prdMonthName)){ prdMonth = 3;} 
//			            if(("Apr").equals(prdMonthName)){ prdMonth = 4;} 
//			            if(("May").equals(prdMonthName)){ prdMonth = 5;} 
//			            if(("Jun").equals(prdMonthName)){ prdMonth = 6;} 
//			            if(("Jul").equals(prdMonthName)){ prdMonth = 7;} 
//			            if(("Aug").equals(prdMonthName)){ prdMonth = 8;} 
//			            if(("Sep").equals(prdMonthName)){ prdMonth = 9;} 
//			            if(("Oct").equals(prdMonthName)){ prdMonth = 10;} 
//			            if(("Nov").equals(prdMonthName)){ prdMonth = 11;} 
//			            if(("Dec").equals(prdMonthName)){ prdMonth = 12;}
//			            
//			            /********************Convert alcFte***********/
//			            BigDecimal bg1 = new BigDecimal("10000");
//			            BigDecimal alcFteNew = result.getBigDecimal("alcFte").divide(bg1);
//			            
//			            /********************Convert alcType***********/
//			            Integer alcType = null;
//			            if(result.getInt("alcType") == 226){alcType = 1;}
//			            if(result.getInt("alcType") == 227){alcType = 2;}
//			            
//					 	MonthlyAllocation alc = new MonthlyAllocation();
//					 	if(enddatealc != null) alc.setAlcEndDate(convertStringToDate(enddatealc));
//		            	alc.setAlcFte(alcFteNew);
//		            	alc.setAlcHrs(result.getBigDecimal("alcHrs"));
//		            	if(startdatealc != null) alc.setAlcStartDate(convertStringToDate(startdatealc));
//		             	alc.setAlcType(alcType);	             
//		            	alc.setComments(result.getString("comments"));
//		            	alc.setCreatedBy(result.getInt("createdBy"));
//		              	alc.setCreatedDate(result.getDate("createdDate"));
//		            	alc.setModifiedBy(null);
//		              	alc.setModifiedDate(null);
//		              	alc.setPrdId(result.getInt("prdId"));
//		              	alc.setPrdMonth(prdMonth);
//		            	alc.setPrdName(result.getString("prdName"));
//		            	alc.setPrdYear(prdYear);
//		            	alc.setProjectId(result.getInt("projectId"));	          	
//		            	alc.setRequisitionId(result.getString("requisitionId"));
//		            	alc.setSowDetailId(null);	           
//		            	alc.setUid(result.getInt("uid"));
//		               	return alc; 
//				 }			
//			 });
//	        
//	        /*------------------------- Allocation insert logic start ------------------------------------ */
//			 int j=0;
//		        for (MonthlyAllocation aAlc : listMonthlyAllocation) {
//		        	
//		        	if((aAlc.getAlcEndDate() != null) && (aAlc.getAlcStartDate() != null))
//		        	{
//		        	
//		        	  	String ALC_MONTHLY_INSERT_SQL = "Insert into "+ LoadConstant.otc +".[dbo].monthly_allocation values (" 						
//												
//		        	  			+ "'" + aAlc.getAlcEndDate()+"', "
//								+ "'" + aAlc.getAlcFte()+"',"
//								+ "'" + aAlc.getAlcHrs()+"',"							
//								+ "'" + aAlc.getAlcStartDate()+"', "
//								+ "'" + aAlc.getAlcType()+"',"
//															
//								+ "'" + aAlc.getComments()+"',"								
//								+ "'" + aAlc.getCreatedBy()+"',"
//								+ "'" + aAlc.getCreatedDate()+"',"
//								+ "NULL, "
//								+ "NULL, "
//								+ "'" + aAlc.getPrdId()+"', "	
//								+ "'" + aAlc.getPrdMonth()+"', "						
//								+ "'" + aAlc.getPrdName()+"', "
//								+ "'" + aAlc.getPrdYear()+"', "
//								+ "'" + aAlc.getProjectId()+"', "
//								+ "'" + aAlc.getRequisitionId()+"', "
//								+ "NULL, "	//+ "'" + aAlc.getSowDetailId()+"', "
//								+ "'" + aAlc.getUid()+"', "+
//								 "NULL) ";	
//		        	  	System.out.println(j+"sql======>"+ ALC_MONTHLY_INSERT_SQL);
//		        	 
//			        	// Setting the data source as OTC database
//			        	datasource = otcconfig.otcDataSource();
//			     		jdbcTemplate.setDataSource(datasource);
//		
//			     		jdbcTemplate.update(ALC_MONTHLY_INSERT_SQL);
//		        	}
//		             
//		            j++;
//		            /*------------------------- Allocation insert logic end ------------------------------------ */
//		        }
//		        System.out.println("Total "+ j + " allocation imported successfully in monthly_allocation table");
//			
//	        /*******************************************************monthly_allocation insert logic end ***********************************************************************************/
//		
//		
//		
//		return rows;
//	}
//	
//	public static Date convertStringToDate(String dateString)
//	{
//		try {
//		      DateFormat formatter;
//		      formatter = new SimpleDateFormat("yyyy-MM-dd");		       
//		      Date date = formatter.parse(dateString);		      
//		      java.sql.Timestamp timeStampDate = new Timestamp(date.getTime());		      
//		      return timeStampDate;
//		    } catch (ParseException e) {
//		      System.out.println("Exception :" + e);
//		      return null;
//		    }
//	}
//		
//}
////1. first comment code starting from --**********monthly_allocation insert logic start-******** and ending at --**********monthly_allocation insert logic end--********
////2. hit /importMonthlyAllocation from url
////3. Parent table "allocation" shall get populated
////4. now comment code for parent table and uncomment code for monthly_allocation insert, that was commented in step 1
////5. again hit /importMonthlyAllocation from url
////6. monthly_allocation table will get populated (takes time for ~25000 rows)
////Update alcId(FK) in monthly_allocation table by running below query directly:
//
////Update obj_monthly_allocation
////SET obj_monthly_allocation.alcId = obj_allocation.alcId
////FROM [OTC_Local].[dbo].[monthly_allocation] obj_monthly_allocation,[OTC_Local].[dbo].[allocation] obj_allocation
////WHERE obj_monthly_allocation.projectId = obj_allocation.projectId
////AND obj_monthly_allocation.alcStartDate = obj_allocation.alcStartDate
////AND obj_monthly_allocation.alcEndDate = obj_allocation.alcEndDate
////AND obj_monthly_allocation.alcType = obj_allocation.alcType
////AND obj_monthly_allocation.alcFte = obj_allocation.alcFte
////AND obj_monthly_allocation.uid = obj_allocation.uid
