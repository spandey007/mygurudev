/**
 * 
 */
package com.infocepts.otc.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.ColumnResult;
import javax.persistence.Entity;
import javax.persistence.EntityResult;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.SqlResultSetMappings;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.infocepts.otc.utilities.LoadConstant;

/**
 * @author Rewatiraman Chandrol
 *
 */
@Entity
@Table(catalog=LoadConstant.otc, schema="[dbo]",name="expenseDetail")
@DynamicUpdate
@DynamicInsert
@SqlResultSetMappings({
	@SqlResultSetMapping(name = "expenseClaims", entities = {
		@EntityResult(entityClass = ExpenseDetail.class) },
		columns = {@ColumnResult(name = "purposeName"),
		@ColumnResult(name = "categoryName"), @ColumnResult(name = "currencyCode"),
	}),
	@SqlResultSetMapping(name = "fetchProjectOwners", 
	columns = {
			@ColumnResult(name="projectManagersId"),
			@ColumnResult(name="ahId"),
			@ColumnResult(name="dmId"),
	}
	)
})
public class ExpenseDetail implements Serializable {

	/**
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer expenseDetailId;
	@ManyToOne
	@JoinColumn(name="expenseId")
	private Expense expense;
	private String faComments;
	private String pmComments;
	private String tdComments;
	private Integer purposeId;
	private Integer expenseCategoryId;
	private Date startDate;
	private Date endDate;
	private Integer currencyId;
	private Double amount;
	private Double convertedAmount;
	private String filePath;
	private Integer createdBy;
	private Date createdDate;
	private Integer modifiedBy;
	private Date modifiedDate;
	@Transient
	private String formattedStartDate;
	@Transient
	private String formattedEndDate;
	

	@Transient
	private String purposeTypeName;
	
	@Transient
	private String purposeName;
	
	@Transient
	private String categoryName;
	
	/**
	 * This field is used to store project title.
	 */
	@Transient
	private String projectTitle;
	
	/**
	 * This field is used to store currency code.
	 */
	@Transient
	private String currencyCode;
	
	@Transient
	private String resourceName;
	
	@Transient
	private ExpenseDetail expenseDetail;
	
	public ExpenseDetail() {
	}
	
	
	public ExpenseDetail(ExpenseDetail expenseDetail, String purposeTypeName, String purposeName, String categoryName, String projectTitle, String currencyCode, String resourceName) {
		super();
		this.expenseDetail = expenseDetail;
		this.purposeTypeName = purposeTypeName;
		this.purposeName = purposeName;
		this.categoryName = categoryName;
		this.projectTitle = projectTitle;
		this.currencyCode = currencyCode;
		this.resourceName = resourceName;
	}


	
	
	/**
	 * @return the expenseDetail
	 */
	public ExpenseDetail getExpenseDetail() {
		return expenseDetail;
	}


	/**
	 * @param expenseDetail the expenseDetail to set
	 */
	public void setExpenseDetail(ExpenseDetail expenseDetail) {
		this.expenseDetail = expenseDetail;
	}



	/**
	 * @return the expenseDetailId
	 */
	public Integer getExpenseDetailId() {
		return expenseDetailId;
	}
	/**
	 * @return the expense
	 */
	public Expense getExpense() {
		return expense;
	}
	/**
	 * @return the faComments
	 */
	public String getFaComments() {
		return faComments;
	}
	/**
	 * @return the pmComments
	 */
	public String getPmComments() {
		return pmComments;
	}
	/**
	 * @return the tdComments
	 */
	public String getTdComments() {
		return tdComments;
	}
	/**
	 * @return the purposeId
	 */
	public Integer getPurposeId() {
		return purposeId;
	}
	/**
	 * @return the expenseCategoryId
	 */
	public Integer getExpenseCategoryId() {
		return expenseCategoryId;
	}
	/**
	 * @return the startDate
	 */
	public Date getStartDate() {
		return startDate;
	}
	/**
	 * @return the endDate
	 */
	public Date getEndDate() {
		return endDate;
	}
	/**
	 * @return the currencyId
	 */
	public Integer getCurrencyId() {
		return currencyId;
	}
	/**
	 * @return the amount
	 */
	public Double getAmount() {
		return amount;
	}
	/**
	 * @return the filePath
	 */
	public String getFilePath() {
		return filePath;
	}
	/**
	 * @return the createdBy
	 */
	public Integer getCreatedBy() {
		return createdBy;
	}
	/**
	 * @return the createdDate
	 */
	public Date getCreatedDate() {
		return createdDate;
	}
	/**
	 * @return the modifiedBy
	 */
	public Integer getModifiedBy() {
		return modifiedBy;
	}
	/**
	 * @return the modifiedDate
	 */
	public Date getModifiedDate() {
		return modifiedDate;
	}
	/**
	 * @param expenseDetailId the expenseDetailId to set
	 */
	public void setExpenseDetailId(Integer expenseDetailId) {
		this.expenseDetailId = expenseDetailId;
	}
	/**
	 * @param expense the expense to set
	 */
	public void setExpense(Expense expense) {
		this.expense = expense;
	}
	/**
	/**
	 * @param faComments the faComments to set
	 */
	public void setFaComments(String faComments) {
		this.faComments = faComments;
	}
	/**
	 * @param pmComments the pmComments to set
	 */
	public void setPmComments(String pmComments) {
		this.pmComments = pmComments;
	}
	/**
	 * @param tdComments the tdComments to set
	 */
	public void setTdComments(String tdComments) {
		this.tdComments = tdComments;
	}
	/**
	 * @param purposeId the purposeId to set
	 */
	public void setPurposeId(Integer purposeId) {
		this.purposeId = purposeId;
	}
	/**
	 * @param expenseCategoryId the expenseCategoryId to set
	 */
	public void setExpenseCategoryId(Integer expenseCategoryId) {
		this.expenseCategoryId = expenseCategoryId;
	}
	/**
	 * @param startDate the startDate to set
	 */
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	/**
	 * @param endDate the endDate to set
	 */
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	/**
	 * @param currencyId the currencyId to set
	 */
	public void setCurrencyId(Integer currencyId) {
		this.currencyId = currencyId;
	}
	/**
	 * @param amount the amount to set
	 */
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	/**
	 * @param filePath the filePath to set
	 */
	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}
	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}
	/**
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	/**
	 * @param modifiedBy the modifiedBy to set
	 */
	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	/**
	 * @param modifiedDate the modifiedDate to set
	 */
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	/**
	 * @return the purposeTypeName
	 */
	public String getPurposeTypeName() {
		return purposeTypeName;
	}
	/**
	 * @return the purposeName
	 */
	public String getPurposeName() {
		return purposeName;
	}
	/**
	 * @return the categoryName
	 */
	public String getCategoryName() {
		return categoryName;
	}
	/**
	 * @return the projectName
	 */
	public String getProjectTitle() {
		return projectTitle;
	}
	/**
	 * @return the currencyCode
	 */
	public String getCurrencyCode() {
		return currencyCode;
	}
	/**
	 * @param purposeTypeName the purposeTypeName to set
	 */
	public void setPurposeTypeName(String purposeTypeName) {
		this.purposeTypeName = purposeTypeName;
	}
	/**
	 * @param purposeName the purposeName to set
	 */
	public void setPurposeName(String purposeName) {
		this.purposeName = purposeName;
	}
	/**
	 * @param categoryName the categoryName to set
	 */
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	/**
	 * @param projectTitle the projectName to set
	 */
	public void setProjectTitle(String projectTitle) {
		this.projectTitle = projectTitle;
	}
	/**
	 * @param currencyCode the currencyCode to set
	 */
	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}


	/**
	 * @return the resourceName
	 */
	public String getResourceName() {
		return resourceName;
	}


	/**
	 * @param resourceName the resourceName to set
	 */
	public void setResourceName(String resourceName) {
		this.resourceName = resourceName;
	}


	/**
	 * @return the convertedAmount
	 */
	public Double getConvertedAmount() {
		return convertedAmount;
	}


	/**
	 * @param convertedAmount the convertedAmount to set
	 */
	public void setConvertedAmount(Double convertedAmount) {
		this.convertedAmount = convertedAmount;
	}


	/**
	 * @return the formattedStartDate
	 */
	public String getFormattedStartDate() {
		return formattedStartDate;
	}

	/**
	 * @param formattedStartDate the formattedStartDate to set
	 */
	public void setFormattedStartDate(String formattedStartDate) {
		this.formattedStartDate = formattedStartDate;
	}


	/**
	 * @return the formattedEndDate
	 */
	public String getFormattedEndDate() {
		return formattedEndDate;
	}

	/**
	 * @param formattedEndDate the formattedEndDate to set
	 */
	public void setFormattedEndDate(String formattedEndDate) {
		this.formattedEndDate = formattedEndDate;
	}
}
