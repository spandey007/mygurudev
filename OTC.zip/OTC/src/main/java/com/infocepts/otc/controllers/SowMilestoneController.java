package com.infocepts.otc.controllers;

import java.util.List;

import javax.mail.MessagingException;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.infocepts.otc.entities.SowMilestone;
import com.infocepts.otc.repositories.SowMilestoneRepository;
import com.infocepts.otc.services.TimesheetService;

@RestController
@RequestMapping(value="/sowmilestone"/*,headers="referer"*/)
public class SowMilestoneController {

	final Logger logger = Logger.getLogger(SowMilestoneController.class);
	
	@Autowired
	SowMilestoneRepository repository;
	
	@Autowired
	TimesheetService service;
	
	@RequestMapping(method=RequestMethod.POST)
	public SowMilestone addSowMilestone(@RequestBody SowMilestone sowmilestone)
	{
		try{
			sowmilestone.setSowMilestoneId(null);
			repository.save(sowmilestone);
		}catch(Exception e){
			logger.error(e);
		}
		return sowmilestone;
	}	
 
	 @RequestMapping(method=RequestMethod.GET)
	 public List<SowMilestone> getAllSowMilestone(@RequestParam(value = "sowId", defaultValue = "0") Integer sowId,
			 										HttpServletRequest request) throws MessagingException {
		 List<SowMilestone> sowMilestoneList=null;
		 // Authorization for passed sowId
		 if(sowId != 0)
		 {
			Boolean isAValidCall = service.isAValidSOWCall(0, sowId, "SowMilestone By sowId", request);
			if(isAValidCall == false)
			{	
				return null;
			}			 
		 }
			 
		 try{
			 if(sowId != 0)
			 {
				 sowMilestoneList = repository.findBySowId(sowId);
			 }
			 else
			 {
				 sowMilestoneList = repository.findAll();
			 }
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return sowMilestoneList;
	 }

         @RequestMapping(value="/{sowId}",method=RequestMethod.GET)
	 public SowMilestone getSowMilestone(@PathVariable Integer sowId){
		 SowMilestone sowmilestone=null;
		 try{
			 sowmilestone = repository.findOne(sowId);
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return sowmilestone;
	 }
	 
	 @RequestMapping(value="/{sowMilestoneId}",method=RequestMethod.PUT)
	 public SowMilestone updateSowMilestone(@RequestBody SowMilestone updatedsowmilestone,@PathVariable Integer sowMilestoneId){
		 try{
			 updatedsowmilestone.setSowMilestoneId(sowMilestoneId);
			 repository.save(updatedsowmilestone);
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return updatedsowmilestone;
	 }
	 
	 @RequestMapping(value="/{sowMilestoneId}",method=RequestMethod.DELETE)
	 public void deleteSowMilestone(@PathVariable Integer sowMilestoneId){
		 try{
			 repository.delete(sowMilestoneId);
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
	 }	 
}
