/* 
 * Country JPA Entity to manage Country
 * -------------------------------------------------------------------------------------------------------------------------
 * 20 Sep 2017 - EW creation of the file
 *
*/
package com.infocepts.otc.entities;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.infocepts.otc.utilities.LoadConstant;

@Entity
@Table(catalog=LoadConstant.otc, schema="[dbo]",name="deGovernanceNotes")
public class DEGovernanceNotes {

	//Columns
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer Id;
	private Integer portfolioId;
	private Integer deliveryId;
	private Integer accountId;
	
	
	@Lob
	private String portfolioComments;
	
	@Lob
	private String deliveryComments;
	
	@Lob
	private String accountComments;
	
	private Integer month;
	private Integer year;

	private Date createdDate;
	private Date modifiedDate;
	private Integer createdBy;
	private Integer modifiedBy;
	
	private Integer deId;	
	
	@Lob
	private String deComments;
	
	private Integer portfolioHeadId;
	
	public Integer getId() {
		return Id;
	}
	public void setId(Integer id) {
		Id = id;
	}
	public Integer getPortfolioId() {
		return portfolioId;
	}
	public void setPortfolioId(Integer portfolioId) {
		this.portfolioId = portfolioId;
	}
	public Integer getDeliveryId() {
		return deliveryId;
	}
	public void setDeliveryId(Integer deliveryId) {
		this.deliveryId = deliveryId;
	}
	public Integer getAccountId() {
		return accountId;
	}
	public void setAccountId(Integer accountId) {
		this.accountId = accountId;
	}
	public String getPortfolioComments() {
		return portfolioComments;
	}
	public void setPortfolioComments(String portfolioComments) {
		this.portfolioComments = portfolioComments;
	}
	public String getDeliveryComments() {
		return deliveryComments;
	}
	public void setDeliveryComments(String deliveryComments) {
		this.deliveryComments = deliveryComments;
	}
	public String getAccountComments() {
		return accountComments;
	}
	public void setAccountComments(String accountComments) {
		this.accountComments = accountComments;
	}
	public Integer getMonth() {
		return month;
	}
	public void setMonth(Integer month) {
		this.month = month;
	}
	public Integer getYear() {
		return year;
	}
	public void setYear(Integer year) {
		this.year = year;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public Date getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public Integer getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}
	public Integer getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public Integer getDeId() {
		return deId;
	}
	public void setDeId(Integer deId) {
		this.deId = deId;
	}
	public String getDeComments() {
		return deComments;
	}
	public void setDeComments(String deComments) {
		this.deComments = deComments;
	}
	public Integer getPortfolioHeadId() {
		return portfolioHeadId;
	}
	public void setPortfolioHeadId(Integer portfolioHeadId) {
		this.portfolioHeadId = portfolioHeadId;
	}
	
	
	
}
	
	