package com.infocepts.otc.entities;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.SqlResultSetMappings;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.infocepts.otc.utilities.LoadConstant;
import com.infocepts.otc.utilities.QueryConstant;

@Entity
@Table(catalog = LoadConstant.infomaster, schema = "[dbo]", name = "project") // rkj rename this to project
@SqlResultSetMappings({
	@SqlResultSetMapping(
	        name = "list_of_projects",
	        classes = {
	                @ConstructorResult(
	                        targetClass = Project.class,
	                        columns = {
	                                @ColumnResult(name = "itemId"),
	                                @ColumnResult(name = "title", type = String.class),
	                                @ColumnResult(name = "accountId"),
	                                @ColumnResult(name = "accountName", type = String.class),
	                                @ColumnResult(name = "portfolioId"),
	                                @ColumnResult(name = "portfolioText", type = String.class),
	                                @ColumnResult(name = "billingEntity"),
	                                //@ColumnResult(name = "programId"),
	                                //@ColumnResult(name = "programText", type = String.class),
	                                @ColumnResult(name = "infoCeptsProjectCode", type = String.class),
	                                @ColumnResult(name = "state", type = String.class),
	                                @ColumnResult(name = "technology", type = String.class),
	                                @ColumnResult(name = "cancelReason", type = String.class),
	                                @ColumnResult(name = "billingUnitId"),
	                                @ColumnResult(name = "billingUnit", type = String.class),
	                                @ColumnResult(name = "executionUnitId"),
	                                @ColumnResult(name = "executionUnit", type = String.class),
	                                @ColumnResult(name = "billingTypeId"),
	                                @ColumnResult(name = "billingType", type = String.class),
	//                                //@ColumnResult(name = "departmentId"),
	//                                //@ColumnResult(name = "departmentText", type = String.class),
	                                @ColumnResult(name = "projectManagersId"),
	                                @ColumnResult(name = "pmName", type = String.class),
	                                @ColumnResult(name = "dmName", type = String.class),
	                                @ColumnResult(name = "rmName", type = String.class),
	                                @ColumnResult(name = "plannersId", type = String.class),
	                                @ColumnResult(name = "plannersText", type = String.class),
	                                @ColumnResult(name = "ownersId"),
	                                @ColumnResult(name = "ownerName", type = String.class),
	                                @ColumnResult(name = "projectStart", type = Date.class),
	                                @ColumnResult(name = "projectEnd", type = Date.class),
	                                @ColumnResult(name = "month", type = String.class),
	                                @ColumnResult(name = "allocationType"),
	                                @ColumnResult(name = "allocation", type = BigDecimal.class),
	                                @ColumnResult(name = "pmEmpId", type = Float.class),								
									@ColumnResult(name = "createdBy"),
									@ColumnResult(name = "createdDate", type=Date.class),
					                @ColumnResult(name = "modifiedBy"),
					                @ColumnResult(name = "modifiedDate", type=Date.class),
	                                //@ColumnResult(name = "notes", type=String.class),
	                                //@ColumnResult(name = "assignedToId", type=String.class),
	                                @ColumnResult(name = "projectActualStartDate", type=Date.class),
	                                @ColumnResult(name = "projectActualEndDate", type=Date.class),
	                                @ColumnResult(name = "sowStatus", type=String.class),
	                                //@ColumnResult(name = "unitId"),
	                                @ColumnResult(name = "projectTypeId"),
	                                @ColumnResult(name = "projectTypeText", type=String.class),
	                                @ColumnResult(name = "projectSubTypeId"),
									@ColumnResult(name = "deProjectType", type=String.class),
									@ColumnResult(name = "dmId"),
									@ColumnResult(name = "parentProjectId"),
									@ColumnResult(name = "parentProjectName", type=String.class),
									@ColumnResult(name = "portfolioOwnerId"),
									@ColumnResult(name = "ahId"),
									@ColumnResult(name = "strategic", type=String.class)
	                        }
	                )
	        }
	),
	@SqlResultSetMapping(
	        name = "project_with_revenue",
	        classes = {
	                @ConstructorResult(
	                        targetClass = Project.class,
	                        columns = {
	                        		@ColumnResult(name = "itemId"),
	                                @ColumnResult(name = "title", type = String.class),
	                                @ColumnResult(name = "accountId"),
	                                @ColumnResult(name = "accountName", type = String.class),
	                                @ColumnResult(name = "projectManagersId"),
	                                @ColumnResult(name = "billingTypeId"),
	                                @ColumnResult(name = "pmName", type = String.class),
	                                @ColumnResult(name = "dmName", type = String.class),
	                                @ColumnResult(name = "rmName", type = String.class),
	                                @ColumnResult(name = "month", type = String.class),
	                                @ColumnResult(name = "monthNo"),
	                                @ColumnResult(name = "sowStartDate", type = Date.class),
	                                @ColumnResult(name = "sowEndDate", type = Date.class),
	                                @ColumnResult(name = "sowValue", type = BigDecimal.class),
	                                @ColumnResult(name = "alcValue", type = BigDecimal.class),
	                                @ColumnResult(name = "totalContractValue", type = BigDecimal.class),
	                                @ColumnResult(name = "contractGapPercent", type = BigDecimal.class),
	                                @ColumnResult(name = "invoiceValue", type = BigDecimal.class),
	                                @ColumnResult(name = "currencySign", type = String.class),
	                                @ColumnResult(name = "invoiceCurrencySign", type = String.class),
	                                @ColumnResult(name = "sowNo", type = String.class),
	                                @ColumnResult(name = "sowId", type = Integer.class),
	                                @ColumnResult(name = "regionName", type = String.class),
	                                @ColumnResult(name = "documentType", type = String.class),
	                                @ColumnResult(name = "accountNo", type = String.class),
	                        		@ColumnResult(name = "executionUnit", type = String.class),
	                                @ColumnResult(name = "billingTypeName", type = String.class)
	                        		
	                        }
                    )
	        }
    ),
	@SqlResultSetMapping(
		      name = "projects_dropdown_list",
		      classes = {
		          @ConstructorResult(
		              targetClass = Project.class,
		              columns = {	
		            	  @ColumnResult(name = "itemId"),
		                  @ColumnResult(name = "title",type=String.class),
		                  @ColumnResult(name = "projectManagersId"),
		              }
		          )
		      }
		),
	@SqlResultSetMapping(
		      name = "de_project_list",
		      classes = {
		          @ConstructorResult(
		              targetClass = Project.class,
		              columns = {	
		            	  @ColumnResult(name = "itemId"),
		                  @ColumnResult(name = "title",type=String.class),
		                  @ColumnResult(name = "portfolioId"),
		                  @ColumnResult(name = "isUnderDECoverage",type=String.class),
		                  @ColumnResult(name = "deCoverageComment ",type=String.class),		                  
		                  @ColumnResult(name = "projectReporting"),
		                  @ColumnResult(name = "deProjectType",type=String.class),
		              }
		          )
		      }
		),
	@SqlResultSetMapping(
	        name = "list_of_projects_byState",
	        classes = {
	                @ConstructorResult(
	                        targetClass = Project.class,
	                        columns = {
	                                @ColumnResult(name = "itemId"),
	                                @ColumnResult(name = "title", type = String.class),
	                                @ColumnResult(name = "accountId"),
	                                @ColumnResult(name = "accountName", type = String.class),
	                                @ColumnResult(name = "portfolioId"),
	                                @ColumnResult(name = "portfolioText", type = String.class),
	                                @ColumnResult(name = "billingEntity"),
	                                //@ColumnResult(name = "programId"),
	                                //@ColumnResult(name = "programText", type = String.class),
	                                @ColumnResult(name = "infoCeptsProjectCode", type = String.class),
	                                @ColumnResult(name = "state", type = String.class),
	                                @ColumnResult(name = "technology", type = String.class),
	                                @ColumnResult(name = "cancelReason", type = String.class),
	                                @ColumnResult(name = "billingUnitId"),
	                                @ColumnResult(name = "billingUnit", type = String.class),
	                                @ColumnResult(name = "executionUnitId"),
	                                @ColumnResult(name = "executionUnit", type = String.class),
	                                @ColumnResult(name = "billingTypeId"),
	                                @ColumnResult(name = "billingType", type = String.class),
	//                                //@ColumnResult(name = "departmentId"),
	//                                //@ColumnResult(name = "departmentText", type = String.class),
	                                @ColumnResult(name = "projectManagersId"),
	                                @ColumnResult(name = "pmName", type = String.class),
	                                @ColumnResult(name = "dmName", type = String.class),
	                                @ColumnResult(name = "rmName", type = String.class),
	                                @ColumnResult(name = "plannersId", type = String.class),
	                                @ColumnResult(name = "plannersText", type = String.class),
	                                @ColumnResult(name = "ownersId"),
	                                @ColumnResult(name = "ownerName", type = String.class),
	                                @ColumnResult(name = "projectStart", type = Date.class),
	                                @ColumnResult(name = "projectEnd", type = Date.class),
	                                @ColumnResult(name = "month", type = String.class),
	                                @ColumnResult(name = "allocationType"),
	                                @ColumnResult(name = "allocation", type = BigDecimal.class),
	                                @ColumnResult(name = "pmEmpId", type = Float.class),								
									@ColumnResult(name = "createdBy"),
									@ColumnResult(name = "createdDate", type=Date.class),
					                @ColumnResult(name = "modifiedBy"),
					                @ColumnResult(name = "modifiedDate", type=Date.class),
	                                //@ColumnResult(name = "notes", type=String.class),
	                                //@ColumnResult(name = "assignedToId", type=String.class),
	                                @ColumnResult(name = "projectActualStartDate", type=Date.class),
	                                @ColumnResult(name = "projectActualEndDate", type=Date.class),
	                                @ColumnResult(name = "sowStatus", type=String.class),
	                                //@ColumnResult(name = "unitId"),
	                                @ColumnResult(name = "projectTypeId"),
	                                @ColumnResult(name = "projectTypeText", type=String.class),
	                                @ColumnResult(name = "projectSubTypeId"),
									@ColumnResult(name = "deProjectType", type=String.class),
									@ColumnResult(name = "dmId"),
									@ColumnResult(name = "parentProjectId"),
									@ColumnResult(name = "parentProjectName", type=String.class),
									@ColumnResult(name = "portfolioOwnerId"),
	                                @ColumnResult(name = "city", type=String.class),
									@ColumnResult(name = "allocationStartDate", type=Date.class),
									@ColumnResult(name = "allocationEndDate", type=Date.class),
									@ColumnResult(name = "monthlyAlcId")
									
									
	                        }
	                )
	        }
	),
	@SqlResultSetMapping(
		      name = "projects_heads_list",
		      classes = {
		          @ConstructorResult(
		              targetClass = Project.class,
		              columns = {	
		            	  @ColumnResult(name = "itemId"),
		                  @ColumnResult(name = "title",type=String.class),
		                  @ColumnResult(name = "state", type = String.class),
		                  @ColumnResult(name = "projectManagersId"),
		                  @ColumnResult(name = "billingTypeId"),
		                  @ColumnResult(name = "ownersId"),
		                  @ColumnResult(name = "projectManager", type = String.class),
		                  @ColumnResult(name = "projectOwner", type = String.class),
		                  @ColumnResult(name = "ahIDname", type = String.class),
		                  @ColumnResult(name = "dmIDname", type = String.class),
		                  @ColumnResult(name = "rmIDname", type = String.class),
		                  @ColumnResult(name = "portOwnerIdname", type = String.class),
		                  
		                  @ColumnResult(name = "projectManagerGrade", type = String.class),
		                  @ColumnResult(name = "projectOwnerGrade", type = String.class),
		                  @ColumnResult(name = "ahGrade", type = String.class),
		                  @ColumnResult(name = "dmGrade", type = String.class),
		                  @ColumnResult(name = "rmGrade", type = String.class),
		                  @ColumnResult(name = "portOwnerGrade", type = String.class),
		                  @ColumnResult(name = "ahId"),
		                  @ColumnResult(name = "dmId"),
		                  @ColumnResult(name = "rmId"),
		                  @ColumnResult(name = "portOwnerId")
		                  
		                  
		              }
		          )
		      }
		),
})
@NamedNativeQueries({
		@NamedNativeQuery(
	            name = "getAllProjects",
	            query = "select p.*, " +
	            		"cast(pa.title as varchar(max)) as accountName, " +
	                    "cast(po.title as varchar(max)) as portfolioText, " +
	                    //"null as programText, " + 
	                    "bu.unitName as billingEntity," +
	                    "cast(bu.name as varchar(max)) as billingUnit, " +
	                    "cast(eu.name as varchar(max)) as executionUnit, " +
	                    "b.name as billingType, " +
	                    //"null as departmentText, " +
	                    "cast(rPm.title as VARCHAR (max)) as pmName, " +
	                    "'' as plannersText, " +
	                    "pt.name as projectTypeText, " +
	                    "cast(rPo.title as VARCHAR (max)) as ownerName, " +
                        "cast(rDm.title as VARCHAR (max)) as dmName, " +
                        "pa.dmId as dmId, "+
                        "cast(rRm.title as VARCHAR (max)) as rmName, " +                          
	                    " null as month, 0 as allocationType, 0 as allocation, " +
	                    "(select title from " + LoadConstant.infomaster + ".[dbo].project where itemId = p.parentProjectId ) as parentProjectName, "+
	                    "po.ownerId as portfolioOwnerId, pa.ahId, pa.strategic, "+
	                    "(select TOP 1 rr.empId from " + LoadConstant.infomaster + ".[dbo].[resource] rr where rr.uid = p.projectManagersId) as pmEmpId " +
	                    " FROM " + LoadConstant.infomaster + ".[dbo].[project] p " +
	                    " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[accounts] pa on pa.itemId = p.accountId " +
	                    " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[portfolio] po on po.itemId = p.portfolioId " +
	                    " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[unit] bu on bu.unitId = p.billingUnitId " +
	                    " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[unit] eu on eu.unitId = p.executionUnitId " +
	                    " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[entities] e on e.entityId = bu.entityId "+
	                    " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[billingtype] b on b.billingTypeId = p.billingTypeId " +
	                    " LEFT JOIN " + LoadConstant.otc + ".[dbo].[projectType] pt on pt.projectTypeId = p.projectTypeId " +
	                    " Left JOIN " + LoadConstant.infomaster + ".[dbo].[resource] rPm on rPm.uid = p.projectManagersId " +
	                    " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[resource] rDm on rDm.uid = pa.dmId "+
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[resource] rRm on rRm.uid = pa.rmId "+
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[resource] rPo on rPo.uid = pa.ahId "+
	                    " order by p.itemId DESC",
	            resultClass = Project.class, resultSetMapping = "list_of_projects"
	
	    ),
		@NamedNativeQuery(
                name = "getMyAllocatedProjects",
                query = "select p.*, " +
                		"cast(pa.title as varchar(max)) as accountName, " +
                        "cast(po.title as varchar(max)) as portfolioText, " +
                        //"null as programText, " + 
                        "bu.unitName as billingEntity," +
                        "cast(bu.name as varchar(max)) as billingUnit, " +
	                    "cast(eu.name as varchar(max)) as executionUnit, " +
                        "b.name as billingType, " +
                        //"null as departmentText, " +
                        "cast(rPm.title as VARCHAR (max)) as pmName, " +
                        "'' as plannersText, " +
                        "pt.name as projectTypeText, " +
                        "cast(rPo.title as VARCHAR (max)) as ownerName, " +
                        "cast(rDm.title as VARCHAR (max)) as dmName, " +
                        "pa.dmId as dmId, "+
                        "cast(rRm.title as VARCHAR (max)) as rmName, " +
                        "a.prdName as month, a.alcType as allocationType, a.alcFte as allocation, ct.cityName as city, "+ 
                        "a.alcStartDate as allocationStartDate, a.alcEndDate as allocationEndDate, a.monthlyAlcId, "+
                        "(select title from " + LoadConstant.infomaster + ".[dbo].project where itemId = p.parentProjectId ) as parentProjectName, "+
                        "po.ownerId as portfolioOwnerId,"+
                        "(select TOP 1 rr.empId from " + LoadConstant.infomaster + ".[dbo].[resource] rr where rr.uid = p.projectManagersId) as pmEmpId " +
                        " FROM " + LoadConstant.infomaster + ".[dbo].[project] p " +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[accounts] pa on pa.itemId = p.accountId " +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[portfolio] po on po.itemId = p.portfolioId " +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[unit] bu on bu.unitId = p.billingUnitId " +
	                    " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[unit] eu on eu.unitId = p.executionUnitId " +
	                    " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[entities] e on e.entityId = bu.entityId "+
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[billingtype] b on b.billingTypeId = p.billingTypeId " +
                        " LEFT JOIN " + LoadConstant.otc + ".[dbo].[projectType] pt on pt.projectTypeId = p.projectTypeId " +
                        " Left JOIN " + LoadConstant.infomaster + ".[dbo].[resource] rPm on rPm.uid = p.projectManagersId " +
                        " LEFT JOIN " + LoadConstant.otc + ".[dbo].[monthly_allocation] a on a.projectId = p.itemId " + 
                        " LEFT JOIN " + LoadConstant.otc + ".[dbo].[allocation] al on al.projectId = p.itemId and al.uid = a.uid"+
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[resource] r on r.uid = a.uid "+
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[resource] rDm on rDm.uid = pa.dmId "+
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[resource] rRm on rRm.uid = pa.rmId "+
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[resource] rPo on rPo.uid = pa.ahId "+
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[city] ct on ct.cityId = r.cityId "+
                        " WHERE ( ((:state = 'Active') and (a.prdName = concat(FORMAT(getDate(), 'MMM'),' ', FORMAT(getDate(), 'yyyy'))) and (al.alcStatus='Active') ) OR "+
                        		" ((:state = 'Closed') and ( (p.state = 'Closed') or ((p.state = 'Active') and (a.prdName != concat(FORMAT(getDate(), 'MMM'),' ', FORMAT(getDate(), 'yyyy'))))) and al.alcStatus='Active') ) "+
                        " AND  r.uid = :uid " +
                        " order by p.itemId DESC",
                resultClass = Project.class, resultSetMapping = "list_of_projects_byState"

        ),
        @NamedNativeQuery(
                name = "getMyPortfolioProjects",
                query = "select p.*, " +
                        "cast(pa.title as varchar(max)) as accountName, " +
                        "cast(po.title as varchar(max)) as portfolioText, " +
                        //"null as programText, " + 
                        "bu.unitName as billingEntity," +
                        "cast(bu.name as varchar(max)) as billingUnit, " +
	                    "cast(eu.name as varchar(max)) as executionUnit, " +
                        "b.name as billingType, " +
                        //"null as departmentText, " +
                        "cast(rPm.Title as VARCHAR (max)) as pmName, " +
                        "'' as plannersText, " +
                        "pt.name as projectTypeText, " +
                        "cast(rPo.title as VARCHAR (max)) as ownerName, " +
                        "cast(rDm.title as VARCHAR (max)) as dmName, " +
                        "pa.dmId as dmId, "+
                        "cast(rRm.title as VARCHAR (max)) as rmName, " + 
                        " null as month, 0 as allocationType, 0 as allocation, " +
                        "(select title from " + LoadConstant.infomaster + ".[dbo].project where itemId = p.parentProjectId ) as parentProjectName, "+
                        "po.ownerId as portfolioOwnerId, pa.ahId, pa.strategic, "+
                        " cast(rPm.empId as VARCHAR (max)) as pmEmpId "+
                        " from " + LoadConstant.infomaster + ".[dbo].project as p " +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[accounts] pa on pa.itemId = p.accountId " +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[portfolio] po on po.itemId = p.portfolioId " +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[unit] bu on bu.unitId = p.billingUnitId " +
	                    " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[unit] eu on eu.unitId = p.executionUnitId " +
	                    " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[entities] e on e.entityId = bu.entityId "+
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[billingtype] b on b.billingTypeId = p.billingTypeId " +
                        " LEFT JOIN " + LoadConstant.otc + ".[dbo].[projectType] pt on pt.projectTypeId = p.projectTypeId " +
                        " Left JOIN " + LoadConstant.infomaster + ".[dbo].[resource] rPm on rPm.uid = p.projectManagersId " +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[resource] rDm on rDm.uid = pa.dmId "+
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[resource] rRm on rRm.uid = pa.rmId "+
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[resource] rPo on rPo.uid = pa.ahId "+
                        " where p.state = :state and pa.dmId =:dmUid order by p.itemId Desc",
                resultClass = Project.class, resultSetMapping = "list_of_projects"

        ),
        @NamedNativeQuery(
                name = "getProjectsByPm",
                query = "select p.*, " +
                        "cast(pa.title as varchar(max)) as accountName, " +
                        "cast(po.title as varchar(max)) as portfolioText, " +
                        //"null as programText, " + 
                        "bu.unitName as billingEntity," +
                        "cast(bu.name as varchar(max)) as billingUnit, " +
	                    "cast(eu.name as varchar(max)) as executionUnit, " +
                        "b.name as billingType, " +
                        //"null as departmentText, " +
                        "cast(rPm.title as VARCHAR (max)) as pmName, " +
                        "'' as plannersText, " +
                        "pt.name as projectTypeText, " +
                        "cast(rPo.title as VARCHAR (max)) as ownerName, " +
                        "cast(rDm.title as VARCHAR (max)) as dmName, " +
                        "pa.dmId as dmId, "+
                        "cast(rRm.title as VARCHAR (max)) as rmName, " +
                        " null as month, 0 as allocationType, 0 as allocation, " +
                        "(select title from " + LoadConstant.infomaster + ".[dbo].project where itemId = p.parentProjectId ) as parentProjectName, "+
                        "po.ownerId as portfolioOwnerId, pa.ahId, pa.strategic, "+
                        " cast(rPm.empId as VARCHAR (max)) as pmEmpId "+
                        " FROM " + LoadConstant.infomaster + ".[dbo].project as p " +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[accounts] pa on pa.itemId = p.accountId " +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[portfolio] po on po.itemId = p.portfolioId " +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[unit] bu on bu.unitId = p.billingUnitId " +
	                    " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[unit] eu on eu.unitId = p.executionUnitId " +
	                    " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[entities] e on e.entityId = bu.entityId "+
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[billingtype] b on b.billingTypeId = p.billingTypeId " +
                        " LEFT JOIN " + LoadConstant.otc + ".[dbo].[projectType] pt on pt.projectTypeId = p.projectTypeId " +
                        " Left JOIN " + LoadConstant.infomaster + ".[dbo].[resource] rPm on rPm.uid = p.projectManagersId " +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[resource] rDm on rDm.uid = pa.dmId "+
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[resource] rRm on rRm.uid = pa.rmId "+
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[resource] rPo on rPo.uid = pa.ahId "+
                        " where p.state = :state and p.projectManagersId =:pmUid order by p.itemId Desc",
                resultClass = Project.class, resultSetMapping = "list_of_projects"

        ),
        @NamedNativeQuery(
                name = "getProjectsAsAh",
                query = "select p.*, " +
                        "cast(pa.title as varchar(max)) as accountName, " +
                        "cast(po.title as varchar(max)) as portfolioText, " +
                        //"null as programText, " + 
                        "bu.unitName as billingEntity," +
                        "cast(bu.name as varchar(max)) as billingUnit, " +
	                    "cast(eu.name as varchar(max)) as executionUnit, " +
                        "b.name as billingType, " +
                        //"null as departmentText, " +
                        "cast(rPm.title as VARCHAR (max)) as pmName, " +
                        "'' as plannersText, " +
                        "pt.name as projectTypeText, " +
                        "cast(rPo.title as VARCHAR (max)) as ownerName, " +
                        "cast(rDm.title as VARCHAR (max)) as dmName, " +
						"pa.dmId as dmId, "+
                        "cast(rRm.title as VARCHAR (max)) as rmName, " +
                        " null as month, 0 as allocationType, 0 as allocation, " +
                        "(select title from " + LoadConstant.infomaster + ".[dbo].project where itemId = p.parentProjectId ) as parentProjectName, "+
                        "po.ownerId as portfolioOwnerId, pa.ahId, pa.strategic, "+
                        " cast(rPm.empId as VARCHAR (max)) as pmEmpId "+
                        " FROM " + LoadConstant.infomaster + ".[dbo].project as p " +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[accounts] pa on pa.itemId = p.accountId " +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[portfolio] po on po.itemId = p.portfolioId " +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[unit] bu on bu.unitId = p.billingUnitId " +
	                    " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[unit] eu on eu.unitId = p.executionUnitId " +
	                    " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[entities] e on e.entityId = bu.entityId "+
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[billingtype] b on b.billingTypeId = p.billingTypeId " +
                        " LEFT JOIN " + LoadConstant.otc + ".[dbo].[projectType] pt on pt.projectTypeId = p.projectTypeId " +
                        " Left JOIN " + LoadConstant.infomaster + ".[dbo].[resource] rPm on rPm.uid = p.projectManagersId " +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[resource] rDm on rDm.uid = pa.dmId "+
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[resource] rRm on rRm.uid = pa.rmId "+
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[resource] rPo on rPo.uid = pa.ahId "+
                        " where p.state = :state and pa.ahId =:ahUid order by p.itemId Desc",
                resultClass = Project.class, resultSetMapping = "list_of_projects"

        ),
        @NamedNativeQuery(
                name = "getProjectsAsCep",
                query = "select p.*, " +
                        "cast(pa.title as varchar(max)) as accountName, " +
                        "cast(po.title as varchar(max)) as portfolioText, " +
                        //"null as programText, " + 
                        "bu.unitName as billingEntity," +
                        "cast(bu.name as varchar(max)) as billingUnit, " +
	                    "cast(eu.name as varchar(max)) as executionUnit, " +
                        "b.name as billingType, " +
                        //"null as departmentText, " +
                        "cast(rPm.title as VARCHAR (max)) as pmName, " +
                        "'' as plannersText, " +
                        "pt.name as projectTypeText, " +
                        "cast(rPo.title as VARCHAR (max)) as ownerName, " +
                        "cast(rDm.title as VARCHAR (max)) as dmName, " +
                        "pa.dmId as dmId, "+
                        "cast(rRm.title as VARCHAR (max)) as rmName, " +
                        " null as month, 0 as allocationType, 0 as allocation, " +
                        "(select title from " + LoadConstant.infomaster + ".[dbo].project where itemId = p.parentProjectId ) as parentProjectName, "+
                        "po.ownerId as portfolioOwnerId, pa.ahId, pa.strategic, "+
                        " cast(rPm.empId as VARCHAR (max)) as pmEmpId "+
                        " FROM " + LoadConstant.infomaster + ".[dbo].project as p " +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[accounts] pa on pa.itemId = p.accountId " +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[portfolio] po on po.itemId = p.portfolioId " +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[unit] bu on bu.unitId = p.billingUnitId " +
	                    " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[unit] eu on eu.unitId = p.executionUnitId " +
	                    " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[entities] e on e.entityId = bu.entityId "+
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[billingtype] b on b.billingTypeId = p.billingTypeId " +
                        " LEFT JOIN " + LoadConstant.otc + ".[dbo].[projectType] pt on pt.projectTypeId = p.projectTypeId " +
                        " Left JOIN " + LoadConstant.infomaster + ".[dbo].[resource] rPm on rPm.uid = p.projectManagersId " +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[resource] rDm on rDm.uid = pa.dmId "+
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[resource] rRm on rRm.uid = pa.rmId "+
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[resource] rPo on rPo.uid = pa.ahId "+
                        " where p.state = :state and pa.rmId =:cepUid order by p.itemId Desc",
                resultClass = Project.class, resultSetMapping = "list_of_projects"

        ),
        @NamedNativeQuery(
                name = "getProjectsByAccount",
                query = "select p.*, " +
                        "cast(pa.title as varchar(max)) as accountName, " +
                        "cast(po.title as varchar(max)) as portfolioText, " +
                        //"null as programText, " +
                        "bu.unitName as billingEntity," +
                        "cast(bu.name as varchar(max)) as billingUnit, " +
	                    "cast(eu.name as varchar(max)) as executionUnit, " +
                        "b.name as billingType, " +
                        //"null as departmentText, " +
                        "cast(rPm.title as VARCHAR (max)) as pmName, " +
                        "'' as plannersText, " +
                        "pt.name as projectTypeText, " +
                        "cast(rPo.title as VARCHAR (max)) as ownerName, " +
                        "cast(rDm.title as VARCHAR (max)) as dmName, " +
                        "pa.dmId as dmId, "+
                        "cast(rRm.title as VARCHAR (max)) as rmName, " +   
                        " null as month, 0 as allocationType, 0 as allocation, " +
                        "(select title from " + LoadConstant.infomaster + ".[dbo].project where itemId = p.parentProjectId ) as parentProjectName, "+
                        "po.ownerId as portfolioOwnerId, pa.ahId, pa.strategic, "+
                        " cast(rPm.empId as VARCHAR (max)) as pmEmpId "+
                        " FROM " + LoadConstant.infomaster + ".[dbo].project as p " +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[accounts] pa on pa.itemId = p.accountId " +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[portfolio] po on po.itemId = p.portfolioId " +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[unit] bu on bu.unitId = p.billingUnitId " +
	                    " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[unit] eu on eu.unitId = p.executionUnitId " +
	                    " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[entities] e on e.entityId = bu.entityId "+
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[billingtype] b on b.billingTypeId = p.billingTypeId " +
                        " LEFT JOIN " + LoadConstant.otc + ".[dbo].[projectType] pt on pt.projectTypeId = p.projectTypeId " +
                        " Left JOIN " + LoadConstant.infomaster + ".[dbo].[resource] rPm on rPm.uid = p.projectManagersId " +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[resource] rDm on rDm.uid = pa.dmId "+
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[resource] rRm on rRm.uid = pa.rmId "+
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[resource] rPo on rPo.uid = pa.ahId "+
                        " where p.state = :state and p.accountId =:accountId order by p.itemId DESC",
                resultClass = Project.class, resultSetMapping = "list_of_projects"

        )
        ,
        @NamedNativeQuery(
                name = "getLatestProjects",
                query = "select TOP 10 p.*, " +
                        "cast(pa.title as varchar(max)) as accountName, " +
                        "cast(po.title as varchar(max)) as portfolioText, " +
                        //"null as programText, " +
                        "bu.unitName as billingEntity," +
                        "cast(bu.name as varchar(max)) as billingUnit, " +
	                    "cast(eu.name as varchar(max)) as executionUnit, " +
                        "b.name as billingType, " +
                        //"null as departmentText, " +
                        "cast(rPm.title as VARCHAR (max)) as pmName, " +
                        "'' as plannersText, " +
                        "pt.name as projectTypeText, " +
                        "cast(rPo.title as VARCHAR (max)) as ownerName, " +
                        "cast(rDm.title as VARCHAR (max)) as dmName, " +
                        "pa.dmId as dmId, "+
                        "cast(rRm.title as VARCHAR (max)) as rmName, " +    
                        " null as month, 0 as allocationType, 0 as allocation, " +
                        "(select title from " + LoadConstant.infomaster + ".[dbo].project where itemId = p.parentProjectId ) as parentProjectName, "+
                        "po.ownerId as portfolioOwnerId, pa.ahId, pa.strategic, "+
                        " cast(rPm.empId as VARCHAR (max)) as pmEmpId "+
                        " FROM " + LoadConstant.infomaster + ".[dbo].project as p " +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[accounts] pa on pa.itemId = p.accountId " +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[portfolio] po on po.itemId = p.portfolioId " +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[unit] bu on bu.unitId = p.billingUnitId " +
	                    " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[unit] eu on eu.unitId = p.executionUnitId " +
	                    " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[entities] e on e.entityId = bu.entityId "+
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[billingtype] b on b.billingTypeId = p.billingTypeId " +
                        " LEFT JOIN " + LoadConstant.otc + ".[dbo].[projectType] pt on pt.projectTypeId = p.projectTypeId " +
                        " Left JOIN " + LoadConstant.infomaster + ".[dbo].[resource] rPm on rPm.uid = p.projectManagersId " +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[resource] rDm on rDm.uid = pa.dmId "+
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[resource] rRm on rRm.uid = pa.rmId "+
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[resource] rPo on rPo.uid = pa.ahId "+
                        " where p.state = :state order by p.itemId DESC",
                resultClass = Project.class, resultSetMapping = "list_of_projects"

        ),
        @NamedNativeQuery(
                //this query has not been modified to use the project table in OTC
                name = "getDMProjects",
                query = "select p.*, " +
                        "cast(pa.title as varchar(max)) as accountName, " +
                        "cast(po.title as varchar(max)) as portfolioText, " +
                        //"null as programText, " +
                        "bu.unitName as billingEntity," +
                        "cast(bu.name as varchar(max)) as billingUnit, " +
	                    "cast(eu.name as varchar(max)) as executionUnit, " +
                        "b.name as billingType, " +
                        //"null as departmentText, " +
                        "cast(rPm.title as VARCHAR (max)) as pmName, " +
                        "'' as plannersText, " +
                        "pt.name as projectTypeText, " +
                        "cast(rPo.title as VARCHAR (max)) as ownerName, " +
                        "cast(rDm.title as VARCHAR (max)) as dmName, " +
                        "pa.dmId as dmId, "+
                        "cast(rRm.title as VARCHAR (max)) as rmName, " +  
                        " null as month," +
                        " 0 as allocationType," +
                        " 0 as allocation," +
                        "(select title from " + LoadConstant.infomaster + ".[dbo].project where itemId = p.parentProjectId ) as parentProjectName, "+
                        "po.ownerId as portfolioOwnerId, pa.ahId, pa.strategic, "+
                        " rPm.empId as pmEmpId " +
                        " FROM " + LoadConstant.infomaster + ".[dbo].project p" +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[accounts] pa on pa.itemId = p.accountId " +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[portfolio] po on po.itemId = p.portfolioId " +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[unit] bu on bu.unitId = p.billingUnitId " +
	                    " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[unit] eu on eu.unitId = p.executionUnitId " +
	                    " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[entities] e on e.entityId = bu.entityId "+
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[billingtype] b on b.billingTypeId = p.billingTypeId " +
                        " LEFT JOIN " + LoadConstant.otc + ".[dbo].[projectType] pt on pt.projectTypeId = p.projectTypeId " +
                        " Left JOIN " + LoadConstant.infomaster + ".[dbo].[resource] rPm on rPm.uid = p.projectManagersId " +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[resource] rDm on rDm.uid = pa.dmId "+
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[resource] rRm on rRm.uid = pa.rmId "+
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[resource] rPo on rPo.uid = pa.ahId "+
                        " WHERE p.state = 'Active'" +
                        " AND  po.OwnerID = :dmUid" +
                        " order by p.itemId DESC;",
                resultClass = Project.class, resultSetMapping = "list_of_projects"
        ),
        @NamedNativeQuery(
                //this query has not been modified to use the project table in OTC
                name = "getProjectById",
                query = "select p.*, " +
                        "cast(pa.title as varchar(max)) as accountName, " +
                        "cast(po.title as varchar(max)) as portfolioText, " +
                        //"null as programText, " +
                        "bu.unitName as billingEntity," +
                        "cast(bu.name as varchar(max)) as billingUnit, " +
	                    "cast(eu.name as varchar(max)) as executionUnit, " +
                        "b.name as billingType, " +
                        //"null as departmentText, " +
                        "cast(rPm.title as VARCHAR (max)) as pmName, " +
                        "'' as plannersText, " +
                        "pt.name as projectTypeText, " +
                        "cast(rPo.title as VARCHAR (max)) as ownerName, " +
                        "cast(rDm.title as VARCHAR (max)) as dmName, " +
                        "pa.dmId as dmId, "+
                        "cast(rRm.title as VARCHAR (max)) as rmName, " +
                        " null as month, 0 as allocationType, 0 as allocation, " +
                        "(select title from " + LoadConstant.infomaster + ".[dbo].project where itemId = p.parentProjectId ) as parentProjectName, "+
                        "po.ownerId as portfolioOwnerId, pa.ahId, pa.strategic, "+
                        " cast(rPm.empId as VARCHAR (max)) as pmEmpId "+
                        " FROM " + LoadConstant.infomaster + ".[dbo].project as p " +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[accounts] pa on pa.itemId = p.accountId " +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[portfolio] po on po.itemId = p.portfolioId " +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[unit] bu on bu.unitId = p.billingUnitId " +
	                    " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[unit] eu on eu.unitId = p.executionUnitId " +
	                    " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[entities] e on e.entityId = bu.entityId "+
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[billingtype] b on b.billingTypeId = p.billingTypeId " +
                        " LEFT JOIN " + LoadConstant.otc + ".[dbo].[projectType] pt on pt.projectTypeId = p.projectTypeId " +
                        " Left JOIN " + LoadConstant.infomaster + ".[dbo].[resource] rPm on rPm.uid = p.projectManagersId " +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[resource] rDm on rDm.uid = pa.dmId "+
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[resource] rRm on rRm.uid = pa.rmId "+
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[resource] rPo on rPo.uid = pa.ahId "+
                        " where p.itemId = :itemId",

                resultClass = Project.class, resultSetMapping = "list_of_projects"
        ),
        @NamedNativeQuery(
                //this query has not been modified to use the project table in OTC
                name = "getPlanners",
                query = "select p.*, " +
                        "cast(pa.title as varchar(max)) as accountName, " +
                        "cast(po.title as varchar(max)) as portfolioText, " +
                        //"null as programText, " +
                        "bu.unitName as billingEntity," +
                        "cast(bu.name as varchar(max)) as billingUnit, " +
	                    "cast(eu.name as varchar(max)) as executionUnit, " +
                        "b.name as billingType, " +
                        //"null as departmentText, " +
                        "cast(rPm.title as VARCHAR (max)) as pmName, " +
                        "'' as plannersText, " +
                        "pt.name as projectTypeText, " +
                        "cast(rPo.title as VARCHAR (max)) as ownerName, " +
                        "cast(rDm.title as VARCHAR (max)) as dmName, " +
                        "pa.dmId as dmId, "+
                        "cast(rRm.title as VARCHAR (max)) as rmName, " +
                        " null as month, 0 as allocationType, 0 as allocation," +
                        "(select title from " + LoadConstant.infomaster + ".[dbo].project where itemId = p.parentProjectId ) as parentProjectName, "+
                        "po.ownerId as portfolioOwnerId, pa.ahId, pa.strategic, "+
                        " rPm.empId as pmEmpId " +	    				
                        " FROM " + LoadConstant.infomaster + ".[dbo].project p" +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[accounts] pa on pa.itemId = p.accountId " +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[portfolio] po on po.itemId = p.portfolioId " +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[unit] bu on bu.unitId = p.billingUnitId " +
	                    " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[unit] eu on eu.unitId = p.executionUnitId " +
	                    " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[entities] e on e.entityId = bu.entityId "+
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[billingtype] b on b.billingTypeId = p.billingTypeId " +
                        " LEFT JOIN " + LoadConstant.otc + ".[dbo].[projectType] pt on pt.projectTypeId = p.projectTypeId " +
                        " Left JOIN " + LoadConstant.infomaster + ".[dbo].[resource] rPm on rPm.uid = p.projectManagersId " +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[resource] rDm on rDm.uid = pa.dmId "+
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[resource] rRm on rRm.uid = pa.rmId "+
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[resource] rPo on rPo.uid = pa.ahId "+
                        " WHERE p.state = 'Active'" +
                        " AND  (',' + RTRIM(p.plannersId) + ',') LIKE '%,' + :uid + ',%' " +
                        " order by p.itemId DESC;",
                resultClass = Project.class, resultSetMapping = "list_of_projects"
        ),
        @NamedNativeQuery(
                name = "getProjectsByCreater",
                query = "select p.*, " +
                        "cast(pa.title as varchar(max)) as accountName, " +
                        "cast(po.title as varchar(max)) as portfolioText, " +
                        //"null as programText, " + 
                        "bu.unitName as billingEntity," +
                        "cast(bu.name as varchar(max)) as billingUnit, " +
	                    "cast(eu.name as varchar(max)) as executionUnit, " +
                        "b.name as billingType, " +
                        //"null as departmentText, " +
                        "cast(rPm.title as VARCHAR (max)) as pmName, " +
                        "'' as plannersText, " +
                        "pt.name as projectTypeText, " +
                        "cast(rPo.title as VARCHAR (max)) as ownerName, " +
                        "cast(rDm.title as VARCHAR (max)) as dmName, " +
                        "pa.dmId as dmId, "+
                        "cast(rRm.title as VARCHAR (max)) as rmName, " +
                        " null as month, 0 as allocationType, 0 as allocation, " +
                        "(select title from " + LoadConstant.infomaster + ".[dbo].project where itemId = p.parentProjectId ) as parentProjectName, "+
                        "po.ownerId as portfolioOwnerId, pa.ahId, pa.strategic, "+
                        " cast(rPm.empId as VARCHAR (max)) as pmEmpId "+
                        " FROM " + LoadConstant.infomaster + ".[dbo].project as p " +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[accounts] pa on pa.itemId = p.accountId " +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[portfolio] po on po.itemId = p.portfolioId " +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[unit] bu on bu.unitId = p.billingUnitId " +
	                    " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[unit] eu on eu.unitId = p.executionUnitId " +
	                    " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[entities] e on e.entityId = bu.entityId "+
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[billingtype] b on b.billingTypeId = p.billingTypeId " +
                        " LEFT JOIN " + LoadConstant.otc + ".[dbo].[projectType] pt on pt.projectTypeId = p.projectTypeId " +
                        " Left JOIN " + LoadConstant.infomaster + ".[dbo].[resource] rPm on rPm.uid = p.projectManagersId " +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[resource] rDm on rDm.uid = pa.dmId "+
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[resource] rRm on rRm.uid = pa.rmId "+
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[resource] rPo on rPo.uid = pa.ahId "+
                        " where p.state = :state and p.createdBy = :createdBy" +
                        " order by p.itemId desc",
                resultClass = Project.class, resultSetMapping = "list_of_projects"
        ), 
        // Query to get sowValue and invoice Value for a month
        @NamedNativeQuery(
                name = "getProjectWithRevenueByMonth",
                query = "SELECT sowRev.itemId, sowRev.title, sowRev.accountId, sowRev.projectManagersId, sowRev.billingTypeId," + 
                		" '' as sowNo, '' as sowId, sowRev.regionName,"+
                		" sowRev.accountName, sowRev.pmName, sowRev.projectTypeText, sowRev.ownerName, sowRev.dmName, sowRev.rmName," + 
                		" SUM(sowRev.sowValue) as sowValue, SUM(sowRev.alcValue) as alcValue, SUM(sowRev.totalContractValue) as totalContractValue, sowRev.contractGapPercent, "+
                		" sowRev.invoiceValue, sowRev.invoiceCurrencySign, sowRev.currencySign, sowRev.month,"+    
                		" sowRev.sowStartDate, sowRev.sowEndDate, sowRev.monthNo, sowRev.documentType, sowRev.accountNo"+
                		" FROM (" +
                			QueryConstant.Query_Revenue_Dashboard + ") as sowRev" + 
                		" group by sowRev.title, sowRev.itemId, sowRev.accountId, sowRev.projectManagersId, sowRev.billingTypeId, "+
                		" sowRev.accountName, sowRev.pmName, sowRev.projectTypeText, sowRev.ownerName, sowRev.dmName, sowRev.rmName," + 
                		" sowRev.month, sowRev.monthNo, sowRev.totalContractValue, sowRev.contractGapPercent, sowRev.invoiceValue, sowRev.regionName, "+
                		" sowRev.invoiceCurrencySign, sowRev.currencySign, sowRev.documentType, sowRev.accountNo, sowRev.sowStartDate, sowRev.sowEndDate" +
                		" order by sowRev.accountName",
                		resultClass = Project.class, resultSetMapping = "project_with_revenue"
        ), 
        // Query to get sowValue and invoice Value for a month
        @NamedNativeQuery(
                name = "getSowWithRevenueByMonth",
                query = QueryConstant.Query_Revenue_Dashboard +
                		" order by pa.accountShortName",
                resultClass = Project.class, resultSetMapping = "project_with_revenue"
        ),
        @NamedNativeQuery(
	            name    =   "getAllProjectsDropDown",
	            query   =  	" select itemId, title,projectManagersId "+ 
						    " from "+ LoadConstant.infomaster +".[dbo].[project]"+
						    " WHERE state = :state or ('All' = :state)"+
						    " order by title",             
	                        resultClass=Project.class,  resultSetMapping = "projects_dropdown_list"  
		),
        @NamedNativeQuery(
	            name    =   "getAllProjectsByCoE",
	            query   =  	" select itemId, title,projectManagersId "+ 
						    " from "+ LoadConstant.infomaster +".[dbo].[project]"+
						    " WHERE state = 'Active' and title like '%COE%'"+
						    " order by title",             
	                        resultClass=Project.class,  resultSetMapping = "projects_dropdown_list"  
		),
        
        @NamedNativeQuery(
	            name    =   "getDeProjects",
	            query   =  	" select p.itemId, p.title, p.portfolioId, p.isUnderDECoverage, p.deCoverageComment,"+
	            			"(select count(*) from " + LoadConstant.otc + ".[dbo].degovernance de where de.projectId = p.itemId and month(de.projectMetricsForDate) = month(dateadd(m,-1,getdate())) and Year(de.projectMetricsForDate) = Year(dateadd(m,-1,getdate()))) as projectReporting, "+
	            			"p.deProjectType"+ 
						    " from "+ LoadConstant.infomaster +".[dbo].[project] p"+
						    " WHERE p.state = :state or ('All' = :state)"+
						    " order by p.title",             
	                        resultClass=Project.class,  resultSetMapping = "de_project_list"  
		),
        @NamedNativeQuery(
	            name    =   "getAllProjectsDropDownForPH",
	            query   =  	" select itemId, title,projectManagersId "+ 
						    " from "+ LoadConstant.infomaster +".[dbo].[project] p " +
						    " LEFT JOIN "+LoadConstant.infomaster +".[dbo].[portfolio] pf " +
						    " ON p.portfolioId = pf.itemId "+
						    " WHERE (p.state = :state or ('All' = :state)) and "+
						    " pf.ownerId = :portfolioHeadId "+
						    " order by title",             
	                        resultClass=Project.class,  resultSetMapping = "projects_dropdown_list"  
        ),
        @NamedNativeQuery(
	            name    =   "getProjectAllHeads",
	            query   =  	"select p.itemId, p.title, p.state, " + 
	            		" p.projectManagersId,(select r1.title from "+ LoadConstant.infomaster +".[dbo].resource r1 where r1.uid = p.projectManagersId) as ProjectManager, " + 
	            		" (select gradeNo from "+ LoadConstant.infomaster +".[dbo].grade g where g.gradeId= (select r2.gradeId from "+ LoadConstant.infomaster +".[dbo].resource r2 where r2.uid = p.projectManagersId)) as projectManagerGrade,  " + 
	            		"p.billingTypeId as billingTypeId, p.ownersId as ownersId,(select r3.title from "+ LoadConstant.infomaster +".[dbo].resource r3 where r3.uid = p.ownersId) as ProjectOwner, " + 
	            		"(select gradeNo from "+ LoadConstant.infomaster +".[dbo].grade g where g.gradeId= (select r8.gradeId from "+ LoadConstant.infomaster +".[dbo].resource r8 where r8.uid = p.ownersId)) as projectOwnerGrade, " + 
	            		"a.ahId,(select r4.title from "+ LoadConstant.infomaster +".[dbo].resource r4 where r4.uid = a.ahId) as ahIDname, " + 
	            		"(select gradeNo from "+ LoadConstant.infomaster +".[dbo].grade g where g.gradeId= (select r9.gradeId from "+ LoadConstant.infomaster +".[dbo].resource r9 where r9.uid = a.ahId)) as ahGrade, " + 
	            		"a.dmId,(select r5.title from "+ LoadConstant.infomaster +".[dbo].resource r5 where r5.uid = a.dmId) as dmIDname, " + 
	            		"(select gradeNo from "+ LoadConstant.infomaster +".[dbo].grade g where g.gradeId= (select r10.gradeId from "+ LoadConstant.infomaster +".[dbo].resource r10 where r10.uid = a.dmId)) as dmGrade, " + 
	            		"a.rmId,(select r6.title from "+ LoadConstant.infomaster +".[dbo].resource r6 where r6.uid = a.rmId) as rmIDname, " + 
	            		"(select gradeNo from "+ LoadConstant.infomaster +".[dbo].grade g where g.gradeId= (select r11.gradeId from "+ LoadConstant.infomaster +".[dbo].resource r11 where r11.uid = a.rmId)) as rmGrade, " + 
	            		"pt.ownerId as portOwnerId,(select r7.title from "+ LoadConstant.infomaster +".[dbo].resource r7 where r7.uid = pt.ownerId) as portOwnerIdname, " + 
	            		"(select gradeNo from "+ LoadConstant.infomaster +".[dbo].grade g where g.gradeId= (select r12.gradeId from "+ LoadConstant.infomaster +".[dbo].resource r12 where r12.uid = pt.ownerId)) as portOwnerGrade " + 
	            		"from "+ LoadConstant.infomaster +".[dbo].project p " + 
	            		"left join "+ LoadConstant.infomaster +".[dbo].accounts a on a.itemid = p.accountId " + 
	            		"left join "+ LoadConstant.infomaster +".[dbo].portfolio pt on pt.itemid = a.portfolioId " + 
	            		"where p.itemId=:itemId and p.state = 'Active' ",             
	                        resultClass=Project.class,  resultSetMapping = "projects_heads_list"  
        ),
        @NamedNativeQuery(
	            name    =   "getDePlannerProjects",
	            query   =  	" select p.itemId, p.title, p.portfolioId, p.isUnderDECoverage, p.deCoverageComment,"+
	            			"(select count(*) from " + LoadConstant.otc + ".[dbo].degovernance de where de.projectId = p.itemId and month(de.projectMetricsForDate) = month(dateadd(m,-1,getdate())) and Year(de.projectMetricsForDate) = Year(dateadd(m,-1,getdate()))) as projectReporting, "+
	            			"p.deProjectType"+ 
						    " from "+ LoadConstant.infomaster +".[dbo].[project] p"+
						    " WHERE ((p.projectManagersId = :plannerId) or (p.plannersId like concat('%',:plannerId,'%') or p.plannersId like concat('%,',:plannerId) or p.plannersId like concat(:plannerId,',%'))) " + 
						    " and p.state = :state"+
						    " order by p.title",             
	                        resultClass=Project.class,  resultSetMapping = "de_project_list"  
		)
       
})
@DynamicUpdate
@DynamicInsert
public class Project {	

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer itemId;
    private String title;
    
    private Integer accountId;
    private Integer portfolioId;

    private String infoCeptsProjectCode;
    private String state;
    private String technology;

    private Integer billingUnitId; // From unit master
    private Integer executionUnitId; // From unit master
    private Integer billingTypeId; // From billing type master
    
    private Integer projectManagersId;
    private String plannersId;
    private Integer ownersId; // Project owner - different from  DM / RM
    
    private Date projectStart;
    private Date projectEnd;
    
    private Integer projectTypeId;
    
    private String isUnderDECoverage;
    
	private String deCoverageComment;
	
    @Transient
    private Integer projectReporting;
    
    @Column(columnDefinition = "varchar(MAX)")
    private String cancelReason;
    
    @Lob
    private String notes;
    @Lob
    private String assignedToId; // rkj this may not be required in future - check
    private Date projectActualStartDate; // rkj this may not be required in future - check
    private Date projectActualEndDate; // rkj this may not be required in future - check
    private String sowStatus; // rkj this may not be required in future - check
    private String projectSubTypeId; // rkj this may not be required in future - check
    
    private Date modifiedDate;
    private Date createdDate;
    private Integer createdBy;
    private Integer modifiedBy;   
    
    // This column acts as a flag to fetch generic projects.
    private Byte isGeneric;

    @Transient
    private String accountName;
    
    @Transient
    private String portfolioText;

    @Transient
    private String billingEntity;
    @Transient
    private String billingUnit;
    @Transient
    private String executionUnit;
    
    @Transient
    private String billingType;
    
    @Transient
    private String pmName;
    
    @Transient
    private String dmName;
    
    @Transient
    private String rmName;
    
    @Transient
    private String ownerName;
    
    @Transient
    private String plannersText;
    
    @Transient
    private String projectTypeText;
    
    @Transient
    private String month; // Transient variable created to get period name == month (e.g. Apr 2017)
    
    @Transient
    private Integer monthNo;
    
    @Transient
    private String allocationType;
    
    @Transient
    private BigDecimal allocation;
    
    @Transient
    private Integer pmEmpId; // rkj check why is this required - how different from projectManagersId
    
    @Transient
    private BigDecimal sowValue;
    
    @Transient
    private BigDecimal alcValue;
    
    @Transient
    private BigDecimal totalContractValue;
    
    @Transient
    private BigDecimal contractGapPercent;
    
    @Transient
    private String sowNo;
    
    @Transient
    private Integer sowId;
    
    @Transient
    private BigDecimal invoiceValue;  
    
    @Transient
    private String currencySign;
    @Transient
    private String invoiceCurrencySign;
	
	private String deProjectType; //Project Type for Delivery Excellence Tool
	
	private Integer parentProjectId; //Parent Project Id for Delivery Excellence Tool
	
	@Transient
    private String parentProjectName;

	@Transient
    private Integer dmId;
	
	@Transient
    private Integer portfolioOwnerId;
	
	@Transient
	private String documentType;
	
	@Transient
	private String regionName;
	
	@Transient
	private String accountNo;
	
	@Transient
	private Date sowStartDate;
	
	@Transient
	private Date sowEndDate;
    
    @Transient
    private String billingTypeName;
    
    @Transient
	private String city;
	
	@Transient
	private Date allocationStartDate;
	
	@Transient
	private Date allocationEndDate;    
	
	@Transient
    private Integer ahId;
	
	@Transient
	private String strategic;
	
	@Transient
	private String projectManager;
	
	@Transient
	private String projectOwner;
	
	@Transient
	private String ahIDname;
	
	@Transient
	private String dmIDname;
	
	@Transient
	private String rmIDname;
	
	@Transient
	private String portOwnerIdname;
	
	@Transient
	private String projectManagerGrade;
	
	@Transient
	private String projectOwnerGrade;
	
	@Transient
	private String ahGrade;
	
	@Transient
	private String dmGrade;
	
	@Transient
	private String rmGrade;
	
	@Transient
	private String portOwnerGrade;
	
	@Transient
	private Integer rmId;
	
	@Transient
	private Integer portOwnerId;
	
	@Transient
	private Integer monthlyAlcId;
	
    public Integer getMonthlyAlcId() {
		return monthlyAlcId;
	}

	public void setMonthlyAlcId(Integer monthlyAlcId) {
		this.monthlyAlcId = monthlyAlcId;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public Date getAllocationStartDate() {
		return allocationStartDate;
	}

	public void setAllocationStartDate(Date allocationStartDate) {
		this.allocationStartDate = allocationStartDate;
	}

	public Date getAllocationEndDate() {
		return allocationEndDate;
	}

	public void setAllocationEndDate(Date allocationEndDate) {
		this.allocationEndDate = allocationEndDate;
	}
	
    public Integer getItemId() {
        return itemId;
    }

    public void setItemId(Integer itemId) {
        this.itemId = itemId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    @Transient
    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }
    
    @Transient
    public Integer getMonthNo() {
		return monthNo;
	}

	public void setMonthNo(Integer monthNo) {
		this.monthNo = monthNo;
	}

	@Transient
    public BigDecimal getAllocation() {
        return allocation;
    }

    public void setAllocation(BigDecimal allocation) {
        this.allocation = allocation;
    }

    @Transient
    public Integer getPmEmpId() {
        return pmEmpId;
    }

    public void setPmEmpId(Integer pmEmpId) {
        this.pmEmpId = pmEmpId;
    }
    
    @Transient
    public String getBillingType() {
        return billingType;
    }

    public void setBillingType(String billingType) {
        this.billingType = billingType;
    }

    @Transient
    public String getPlannersText() {
        return plannersText;
    }

    public void setPlannersText(String plannersText) {
        this.plannersText = plannersText;
    }

    @Transient
    public String getPortfolioText() {
        return portfolioText;
    }

    public void setPortfolioText(String portfolioText) {
        this.portfolioText = portfolioText;
    }

    @Transient
    public String getPmName() {
        return pmName;
    }

    public void setPmName(String pmName) {
        this.pmName = pmName;
    }
    
    @Transient
    public String getDmName() {
		return dmName;
	}

	public void setDmName(String dmName) {
		this.dmName = dmName;
	}

	@Transient
	public String getRmName() {
		return rmName;
	}

	public void setRmName(String rmName) {
		this.rmName = rmName;
	}
	
	@Transient    
    public String getOwnerName() {
		return ownerName;
	}

	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}	

	@Transient
    public String getAccountName() {
        return accountName;
    }

    public void setAccountName(String accountName) {
        this.accountName = accountName;
    }

    @Transient
    public String getAllocationType() {
        return allocationType;
    }

    public void setAllocationType(String allocationType) {
        this.allocationType = allocationType;
    }

    public Integer getAccountId() {
        return accountId;
    }

    public void setAccountId(Integer accountId) {
        this.accountId = accountId;
    }

    public Integer getPortfolioId() {
        return portfolioId;
    }

    public void setPortfolioId(Integer portfolioId) {
        this.portfolioId = portfolioId;
    }

    public Integer getBillingTypeId() {
        return billingTypeId;
    }

    public void setBillingTypeId(Integer billingTypeId) {
        this.billingTypeId = billingTypeId;
    }

    public String getInfoCeptsProjectCode() {
        return infoCeptsProjectCode;
    }

    public void setInfoCeptsProjectCode(String infoCeptsProjectCode) {
        this.infoCeptsProjectCode = infoCeptsProjectCode;
    }

    public Integer getBillingUnitId() {
		return billingUnitId;
	}

	public void setBillingUnitId(Integer billingUnitId) {
		this.billingUnitId = billingUnitId;
	}

	public Integer getExecutionUnitId() {
		return executionUnitId;
	}

	public void setExecutionUnitId(Integer executionUnitId) {
		this.executionUnitId = executionUnitId;
	}
	
	@Transient
	public String getBillingUnit() {
		return billingUnit;
	}

	public void setBillingUnit(String billingUnit) {
		this.billingUnit = billingUnit;
	}
	@Transient
	public String getExecutionUnit() {
		return executionUnit;
	}

	public void setExecutionUnit(String executionUnit) {
		this.executionUnit = executionUnit;
	}

	public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public Integer getOwnersId() {
        return ownersId;
    }

    public void setOwnersId(Integer ownersId) {
        this.ownersId = ownersId;
    }

    public Integer getProjectManagersId() {
        return projectManagersId;
    }

    public void setProjectManagersId(Integer projectManagersId) {
        this.projectManagersId = projectManagersId;
    }

    public String getPlannersId() {
        return plannersId;
    }

    public void setPlannersId(String plannersId) {
        this.plannersId = plannersId;
    }

    public Date getProjectStart() {
        return projectStart;
    }

    public void setProjectStart(Date projectStart) {
        this.projectStart = projectStart;
    }

    public Date getProjectEnd() {
        return projectEnd;
    }

    public void setProjectEnd(Date projectEnd) {
        this.projectEnd = projectEnd;
    }

    public Date getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(Date modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public Integer getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(Integer createdBy) {
        this.createdBy = createdBy;
    }

    public Integer getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(Integer modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    public String getTechnology() {
        return technology;
    }

    public void setTechnology(String technology) {
        this.technology = technology;
    }
	

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	public String getAssignedToId() {
		return assignedToId;
	}

	public void setAssignedToId(String assignedToId) {
		this.assignedToId = assignedToId;
	}

	public Date getProjectActualStartDate() {
		return projectActualStartDate;
	}

	public void setProjectActualStartDate(Date projectActualStartDate) {
		this.projectActualStartDate = projectActualStartDate;
	}

	public Date getProjectActualEndDate() {
		return projectActualEndDate;
	}

	public void setProjectActualEndDate(Date projectActualEndDate) {
		this.projectActualEndDate = projectActualEndDate;
	}

	public String getSowStatus() {
		return sowStatus;
	}

	public void setSowStatus(String sowStatus) {
		this.sowStatus = sowStatus;
	}	

	public Integer getProjectTypeId() {
		return projectTypeId;
	}

	public void setProjectTypeId(Integer projectTypeId) {
		this.projectTypeId = projectTypeId;
	}

	public String getIsUnderDECoverage() {
		return isUnderDECoverage;
	}

	public void setIsUnderDECoverage(String isUnderDECoverage) {
		this.isUnderDECoverage = isUnderDECoverage;
	}

	public String getDeCoverageComment() {
		return deCoverageComment;
	}

	public void setDeCoverageComment(String deCoverageComment) {
		this.deCoverageComment = deCoverageComment;
	}

	public Integer getProjectReporting() {
		return projectReporting;
	}

	public void setProjectReporting(Integer projectReporting) {
		this.projectReporting = projectReporting;
	}

	public String getProjectSubTypeId() {
		return projectSubTypeId;
	}

	public void setProjectSubTypeId(String projectSubTypeId) {
		this.projectSubTypeId = projectSubTypeId;
	}
	
	@Transient
	public String getProjectTypeText() {
		return projectTypeText;
	}

	public void setProjectTypeText(String projectTypeText) {
		this.projectTypeText = projectTypeText;
	}

	public String getBillingEntity() {
		return billingEntity;
	}

	public void setBillingEntity(String billingEntity) {
		this.billingEntity = billingEntity;
	}
	
	@Transient
	public BigDecimal getSowValue() {
		return sowValue;
	}

	public void setSowValue(BigDecimal sowValue) {
		this.sowValue = sowValue;
	}
	
	@Transient
	public BigDecimal getAlcValue() {
		return alcValue;
	}

	public void setAlcValue(BigDecimal alcValue) {
		this.alcValue = alcValue;
	}
	
	
	@Transient
	public BigDecimal getTotalContractValue() {
		return totalContractValue;
	}

	

	public void setTotalContractValue(BigDecimal totalContractValue) {
		this.totalContractValue = totalContractValue;
	}
	
	
	@Transient
	public BigDecimal getContractGapPercent() {
		return contractGapPercent;
	}

	public void setContractGapPercent(BigDecimal contractGapPercent) {
		this.contractGapPercent = contractGapPercent;
	}

	@Transient
	public BigDecimal getInvoiceValue() {
		return invoiceValue;
	}

	public void setInvoiceValue(BigDecimal invoiceValue) {
		this.invoiceValue = invoiceValue;
	}
	

	@Transient	
	public String getCurrencySign() {
		return currencySign;
	}

	public void setCurrencySign(String currencySign) {
		this.currencySign = currencySign;
	}
	
	@Transient	
	public String getInvoiceCurrencySign() {
		return invoiceCurrencySign;
	}

	public void setInvoiceCurrencySign(String invoiceCurrencySign) {
		this.invoiceCurrencySign = invoiceCurrencySign;
	}

	public String getDeProjectType() {
		return deProjectType;
	}

	public void setDeProjectType(String deProjectType) {
		this.deProjectType = deProjectType;
	}
	

	public Integer getDmId() {
		return dmId;
	}

	public void setDmId(Integer dmId) {
		this.dmId = dmId;
	}
	
	public Integer getParentProjectId() {
		return parentProjectId;
	}

	public void setParentProjectId(Integer parentProjectId) {
		this.parentProjectId = parentProjectId;
	}
	

	public String getParentProjectName() {
		return parentProjectName;
	}

	public void setParentProjectName(String parentProjectName) {
		this.parentProjectName = parentProjectName;
	}

	public Integer getPortfolioOwnerId() {
		return portfolioOwnerId;
	}

	public void setPortfolioOwnerId(Integer portfolioOwnerId) {
		this.portfolioOwnerId = portfolioOwnerId;
	}
	
	@Transient
	public String getSowNo() {
		return sowNo;
	}

	public void setSowNo(String sowNo) {
		this.sowNo = sowNo;
	}
	
	@Transient
	public Integer getSowId() {
		return sowId;
	}

	public void setSowId(Integer sowId) {
		this.sowId = sowId;
	}
	
	@Transient
	public String getDocumentType() {
		return documentType;
	}	

	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}
		
	@Transient
	public String getRegionName() {
		return regionName;
	}

	public void setRegionName(String regionName) {
		this.regionName = regionName;
	}

	@Transient
	public String getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	
	@Transient
	public Date getSowStartDate() {
		return sowStartDate;
	}

	public void setSowStartDate(Date sowStartDate) {
		this.sowStartDate = sowStartDate;
	}

	@Transient
	public Date getSowEndDate() {
		return sowEndDate;
	}

	public void setSowEndDate(Date sowEndDate) {
		this.sowEndDate = sowEndDate;
	}
	
	public String getCancelReason() {
        return cancelReason;
    }

    public void setCancelReason(String cancelReason) {
        this.cancelReason = cancelReason;
    }
	
	public String getBillingTypeName() {
		return billingTypeName;
	}

	public void setBillingTypeName(String billingTypeName) {
		this.billingTypeName = billingTypeName;
	}

	public Integer getAhId() {
		return ahId;
	}

	public void setAhId(Integer ahId) {
		this.ahId = ahId;
	}

	public String getStrategic() {
		return strategic;
	}

	public void setStrategic(String strategic) {
		this.strategic = strategic;
	}
	
	

	public String getProjectManager() {
		return projectManager;
	}

	public void setProjectManager(String projectManager) {
		this.projectManager = projectManager;
	}

	public String getProjectOwner() {
		return projectOwner;
	}

	public void setProjectOwner(String projectOwner) {
		this.projectOwner = projectOwner;
	}

	public String getAhIDname() {
		return ahIDname;
	}

	public void setAhIDname(String ahIDname) {
		this.ahIDname = ahIDname;
	}

	public String getDmIDname() {
		return dmIDname;
	}

	public void setDmIDname(String dmIDname) {
		this.dmIDname = dmIDname;
	}

	public String getRmIDname() {
		return rmIDname;
	}

	public void setRmIDname(String rmIDname) {
		this.rmIDname = rmIDname;
	}

	public String getPortOwnerIdname() {
		return portOwnerIdname;
	}

	public void setPortOwnerIdname(String portOwnerIdname) {
		this.portOwnerIdname = portOwnerIdname;
	}
	

	public String getProjectManagerGrade() {
		return projectManagerGrade;
	}

	public void setProjectManagerGrade(String projectManagerGrade) {
		this.projectManagerGrade = projectManagerGrade;
	}

	public String getProjectOwnerGrade() {
		return projectOwnerGrade;
	}

	public void setProjectOwnerGrade(String projectOwnerGrade) {
		this.projectOwnerGrade = projectOwnerGrade;
	}

	public String getAhGrade() {
		return ahGrade;
	}

	public void setAhGrade(String ahGrade) {
		this.ahGrade = ahGrade;
	}

	public String getDmGrade() {
		return dmGrade;
	}

	public void setDmGrade(String dmGrade) {
		this.dmGrade = dmGrade;
	}

	public String getRmGrade() {
		return rmGrade;
	}

	public void setRmGrade(String rmGrade) {
		this.rmGrade = rmGrade;
	}

	public String getPortOwnerGrade() {
		return portOwnerGrade;
	}

	public void setPortOwnerGrade(String portOwnerGrade) {
		this.portOwnerGrade = portOwnerGrade;
	}

	
	public Integer getRmId() {
		return rmId;
	}

	public void setRmId(Integer rmId) {
		this.rmId = rmId;
	}

	public Integer getPortOwnerId() {
		return portOwnerId;
	}

	public void setPortOwnerId(Integer portOwnerId) {
		this.portOwnerId = portOwnerId;
	}
	
	public Project() {
    }

	public Project(Integer itemId, String title, Integer accountId, String accountName, Integer portfolioId, String portfolioText,String billingEntity,
			String infoCeptsProjectCode, String state, String technology, String cancelReason,
            Integer billingUnitId, String billingUnit, Integer executionUnitId, String executionUnit,
            Integer billingTypeId, String billingType,
            Integer projectManagersId, String pmName, String dmName, String rmName, String plannersId, String plannersText, Integer ownersId, String ownerName,
            Date projectStart, Date projectEnd, String month, Integer allocationType, BigDecimal allocation, 
            Float pmEmpId,
            Integer createdBy, Date createdDate, Integer modifiedBy, Date modifiedDate,
            Date projectActualStartDate, Date projectActualEndDate, String sowStatus,
            Integer projectTypeId, String projectTypeText, String projectSubTypeId,
            String deProjectType, Integer dmId, Integer parentProjectId, String parentProjectName, Integer portfolioOwnerId,Integer ahId, String strategic
            )
	{
		this.itemId = itemId;
        this.title = title;
        this.accountId = accountId;
        this.accountName = accountName;
        this.portfolioId = portfolioId;
        this.portfolioText = portfolioText;
        this.billingEntity = billingEntity;

        this.infoCeptsProjectCode = infoCeptsProjectCode;        
        this.state = state;
        this.technology = technology;
        this.cancelReason = cancelReason;
        
        this.billingUnitId = billingUnitId;
        this.billingUnit = billingUnit;
        this.executionUnitId = executionUnitId;
        this.executionUnit = executionUnit;        
        
        this.billingTypeId = billingTypeId;
        this.billingType = billingType;
        
        this.projectManagersId = projectManagersId;
        this.pmName = pmName;
		this.dmName = dmName;
		this.rmName = rmName;
        this.plannersId = plannersId;
        this.plannersText = plannersText;
        this.ownersId = ownersId;
        this.ownerName = ownerName;
        
        this.projectStart = projectStart;
        this.projectEnd = projectEnd;
        
        this.month = month;
        if (allocationType == 1) this.allocationType = "Billable";
        if (allocationType == 2) this.allocationType = "Non Billable";
        if (allocationType == 3) this.allocationType = "Non Billable Trainee";
        if (allocationType == 4) this.allocationType = "Billed Buffer";
        this.allocation = allocation;
        
        if (null != pmEmpId) this.pmEmpId = Math.round(pmEmpId);
        
        this.createdBy = createdBy;
        this.createdDate = createdDate;        
        this.modifiedBy = modifiedBy;
        this.modifiedDate = modifiedDate;

        this.projectActualStartDate = projectActualStartDate;
        this.projectActualEndDate = projectActualEndDate;
        
        
        this.sowStatus = sowStatus;
        this.projectTypeId = projectTypeId;    
        this.projectTypeText = projectTypeText;
        this.projectSubTypeId = projectSubTypeId;     
        this.deProjectType = deProjectType;
        this.dmId = dmId;
        this.parentProjectId = parentProjectId;
        this.parentProjectName = parentProjectName;
        this.portfolioOwnerId = portfolioOwnerId;
        this.ahId = ahId;
        this.strategic = strategic;

	}
	
	public Project(Integer itemId, String title, Integer accountId, String accountName, 
            Integer projectManagersId, Integer billingTypeId, String pmName, String dmName, String rmName, 
            String month, Integer monthNo, Date sowStartDate, Date sowEndDate,
            BigDecimal sowValue, BigDecimal alcValue, BigDecimal totalContractValue, BigDecimal contractGapPercent, BigDecimal invoiceValue, String currencySign, String invoiceCurrencySign,
            String sowNo, Integer sowId, String regionName, String documentType, String accountNo, String executionUnit, String billingTypeName)
	{
		this.itemId = itemId;
        this.title = title;
        this.accountId = accountId;
        this.accountName = accountName;
        
        this.projectManagersId = projectManagersId;
        this.billingTypeId = billingTypeId;
        this.pmName = pmName;
		this.dmName = dmName;
		this.rmName = rmName;
		
		this.month = month;
		this.monthNo = monthNo;
        
		this.sowNo = sowNo;
		this.sowId = sowId;
        this.sowValue = sowValue;
        this.alcValue = alcValue;
        this.totalContractValue = totalContractValue;
        this.contractGapPercent = contractGapPercent;
        this.invoiceValue = invoiceValue;  
        this.currencySign = currencySign;
        this.invoiceCurrencySign = invoiceCurrencySign;
        this.documentType = documentType;
        this.accountNo = accountNo;
        this.sowStartDate = sowStartDate;
        this.sowEndDate = sowEndDate;
        this.regionName = regionName;
        this.executionUnit = executionUnit;
        this.billingTypeName = billingTypeName;
        
	}
	
	
	
	
  
	public Project(Integer itemId, String title, Integer projectManagersId ) {
		super();
		this.itemId = itemId;
		this.title = title;
		 this.projectManagersId = projectManagersId;
	}

	public Project(Integer itemId, String title, Integer portfolioId, String isUnderDECoverage,
			String deCoverageComment, Integer projectReporting, String deProjectType) {
		super();
		this.itemId = itemId;
		this.title = title;
		this.portfolioId = portfolioId;
		this.isUnderDECoverage = isUnderDECoverage;
		this.deCoverageComment = deCoverageComment;
		this.projectReporting = projectReporting;
		this.deProjectType = deProjectType;
	}
	
	public Project(Integer itemId, String title, Integer accountId, String accountName, Integer portfolioId, String portfolioText,String billingEntity,
			String infoCeptsProjectCode, String state, String technology, String cancelReason,
            Integer billingUnitId, String billingUnit, Integer executionUnitId, String executionUnit,
            Integer billingTypeId, String billingType,
            Integer projectManagersId, String pmName, String dmName, String rmName, String plannersId, String plannersText, Integer ownersId, String ownerName,
            Date projectStart, Date projectEnd, String month, Integer allocationType, BigDecimal allocation, 
            Float pmEmpId,
            Integer createdBy, Date createdDate, Integer modifiedBy, Date modifiedDate,
            Date projectActualStartDate, Date projectActualEndDate, String sowStatus,
            Integer projectTypeId, String projectTypeText, String projectSubTypeId,
            String deProjectType, Integer dmId, Integer parentProjectId, String parentProjectName, Integer portfolioOwnerId,
            String city, Date allocationStartDate, Date allocationEndDate, Integer monthlyAlcId)
	{
		
		this.itemId = itemId;
        this.title = title;
        this.accountId = accountId;
        this.accountName = accountName;
        this.portfolioId = portfolioId;
        this.portfolioText = portfolioText;
        this.billingEntity = billingEntity;

        this.infoCeptsProjectCode = infoCeptsProjectCode;        
        this.state = state;
        this.technology = technology;
        this.cancelReason = cancelReason;
        
        this.billingUnitId = billingUnitId;
        this.billingUnit = billingUnit;
        this.executionUnitId = executionUnitId;
        this.executionUnit = executionUnit;        
        
        this.billingTypeId = billingTypeId;
        this.billingType = billingType;
        
        this.projectManagersId = projectManagersId;
        this.pmName = pmName;
		this.dmName = dmName;
		this.rmName = rmName;
        this.plannersId = plannersId;
        this.plannersText = plannersText;
        this.ownersId = ownersId;
        this.ownerName = ownerName;
        
        this.projectStart = projectStart;
        this.projectEnd = projectEnd;
        
        this.month = month;
        if (allocationType == 1) this.allocationType = "Billable";
        if (allocationType == 2) this.allocationType = "Non Billable";
        if (allocationType == 3) this.allocationType = "Non Billable Trainee";
        if (allocationType == 4) this.allocationType = "Billed Buffer";
        this.allocation = allocation;
        
        if (null != pmEmpId) this.pmEmpId = Math.round(pmEmpId);
        
        this.createdBy = createdBy;
        this.createdDate = createdDate;        
        this.modifiedBy = modifiedBy;
        this.modifiedDate = modifiedDate;

        this.projectActualStartDate = projectActualStartDate;
        this.projectActualEndDate = projectActualEndDate;
        
        
        this.sowStatus = sowStatus;
        this.projectTypeId = projectTypeId;    
        this.projectTypeText = projectTypeText;
        this.projectSubTypeId = projectSubTypeId;     
        this.deProjectType = deProjectType;
        this.dmId = dmId;
        this.parentProjectId = parentProjectId;
        this.parentProjectName = parentProjectName;
        this.portfolioOwnerId = portfolioOwnerId;
        this.city = city;
		this.allocationStartDate = allocationStartDate;
		this.allocationEndDate = allocationEndDate;
		this.monthlyAlcId = monthlyAlcId;
	}
	
	

	public Project(Integer itemId, String title, String state,
			Integer projectManagersId, Integer billingTypeId, Integer ownersId, String projectManager, String projectOwner, String ahIDname,
			String dmIDname, String rmIDname, String portOwnerIdname, String projectManagerGrade, String projectOwnerGrade, String ahGrade, String dmGrade, String rmGrade,
			String portOwnerGrade, Integer ahId, Integer dmId, Integer rmId, Integer portOwnerId) {

		this.itemId = itemId;
		this.title = title;
		this.state = state;
		this.projectManagersId = projectManagersId;
		this.billingTypeId =billingTypeId;
		this.ownersId = ownersId;
		this.projectManager = projectManager;
		this.projectOwner = projectOwner;
		this.ahIDname = ahIDname;
		this.dmIDname = dmIDname;
		this.rmIDname = rmIDname;
		this.portOwnerIdname = portOwnerIdname;
		this.projectManagerGrade = projectManagerGrade;
		this.projectOwnerGrade = projectOwnerGrade;
		this.ahGrade = ahGrade;
		this.dmGrade = dmGrade;
		this.rmGrade = rmGrade;
		this.portOwnerGrade = portOwnerGrade;
		this.ahId = ahId;
		this.dmId = dmId;
		this.rmId = rmId;
		this.portOwnerId = portOwnerId;
		
	}
	
	
	

	/**
	 * @return the isGeneric
	 */
	public Byte getIsGeneric() {
		return isGeneric;
	}

	/**
	 * @param isGeneric the isGeneric to set
	 */
	public void setIsGeneric(Byte isGeneric) {
		this.isGeneric = isGeneric;
	}
}
