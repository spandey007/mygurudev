package com.infocepts.otc.repositories;

import java.util.List;
import org.springframework.data.repository.CrudRepository;
import com.infocepts.otc.entities.Band;

public interface BandRepository extends CrudRepository<Band,Integer>{

	@Override
	public List<Band> findAll();
	
}
