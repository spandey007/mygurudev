/**
* Filename: /src/main/java/com/infocepts/otc/entities/Coe.java
* @author  SRA
* @version 1.0
* @since   2018-08-01 
*/
package com.infocepts.otc.entities;
import java.util.Date;
import javax.persistence.*;
import javax.validation.constraints.NotNull;

import com.infocepts.otc.utilities.LoadConstant;
@Entity
@Table(catalog=LoadConstant.otc, schema="[dbo]", name="Coe")

@SqlResultSetMappings({
        @SqlResultSetMapping(
                name = "CoeList",
                classes = {
                        @ConstructorResult(
                                targetClass = Coe.class,
                                columns = {
                                		@ColumnResult(name = "coeId"),
                                		@ColumnResult(name = "ownerId", type = Integer.class),
                                        @ColumnResult(name = "coeName", type = String.class),   
                                        @ColumnResult(name = "practiceId", type = Integer.class),
                                        @ColumnResult(name = "createdBy"),
                                        @ColumnResult(name = "createdDate", type = Date.class),
										@ColumnResult(name = "modifiedBy"),
                                        @ColumnResult(name = "modifiedDate", type = Date.class),
                                        @ColumnResult(name = "ownerName", type = String.class),   
                                        @ColumnResult(name = "coeStatus", type = Boolean.class),
                                }
                        )
                }
        )
})

@NamedNativeQueries({
        @NamedNativeQuery(
                name    =   "CoeQuery",   
                query 	=   "Select tb. *,r.title as ownerName "+
							" from " + LoadConstant.otc + ".[dbo].Coe as tb"+
							" LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[resource] r on r.uid = tb.ownerId ",
								
							resultClass=Coe.class, resultSetMapping = "CoeList"
        )   ,
        @NamedNativeQuery(
                name    =   "CoeQuerybycoeId",   
                query 	=   "Select tb. *,r.title as ownerName "+
							" from " + LoadConstant.otc + ".[dbo].Coe as tb"+
							" LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[resource] r on r.uid = tb.ownerId "
									+ "where tb.coeId = :coeId",
							resultClass=Coe.class, resultSetMapping = "CoeList"
        )        
})
public class Coe {
	// Entity Columns
    // --------------------------------------------------------------------------------
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Integer coeId; 
	
    @NotNull
    private Integer ownerId;
    private Integer practiceId;
    private Boolean coeStatus ;
    public Boolean getCoeStatus() {
		return coeStatus;
	}
	public void setCoeStatus(Boolean coeStatus) {
		this.coeStatus = coeStatus;
	}
	@Transient                     // to get Coe owner name by uid from resource table
    private String ownerName ; 
    
    public Integer getCoeId() {
		return coeId;
	}
	public void setCoeId(Integer coeId) {
		this.coeId = coeId;
	}
	public Integer getOwnerId() {
		return ownerId;
	}
	public void setOwnerId(Integer ownerId) {
		this.ownerId = ownerId;
	}
	public Integer getPracticeId() {
		return practiceId;
	}
	public void setPracticeId(Integer practiceId) {
		this.practiceId = practiceId;
	}
	public String getCoeName() {
		return coeName;
	}
	public void setCoeName(String coeName) {
		this.coeName = coeName;
	}
	public Integer getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public Integer getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public Date getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	private String coeName;    
   
   
	
	
	
	 public String getOwnerName() {
		return ownerName;
	}
	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}
	// Audit Trail columns 
    // --------------------------------------------------------------------------------
	private Integer createdBy;    
    private Date createdDate;
    private Integer modifiedBy;
    private Date modifiedDate;
  
	// Constructor
	// ---------------------------------------------------------------------------------
	public Coe() {
		//super();
		// TODO Auto-generated constructor stub
	}
	public Coe (Integer coeId, 
						 Integer ownerId,						 
						 String coeName,   
						 Integer practiceId,
						 Integer createdBy,    						 
						 Date createdDate,
						 Integer modifiedBy,
						 Date modifiedDate,
						 String ownerName,
						 Boolean coeStatus
	) {
		this.coeId   = coeId;
		this.ownerId = ownerId;
		this.practiceId = practiceId;
		this.coeName = coeName;
		this.createdBy = createdBy;
		this.createdDate = createdDate;
		this.ownerName = ownerName;
		this.coeStatus = coeStatus;
		
	}
    
	
	

}

