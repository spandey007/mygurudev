package com.infocepts.otc.controllers;

import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.infocepts.otc.entities.HolidaySchedules;
import com.infocepts.otc.repositories.HolidaySchedulesRepository;
import com.infocepts.otc.services.TimesheetService;



@RestController
@RequestMapping(value="/holidaySchedules",headers="referer")//JV: Added 'headers' param to validate the url.
public class HolidaySchedulesController {
	
	final Logger logger = Logger.getLogger(HolidaySchedulesController.class);
	
	@Autowired
	HolidaySchedulesRepository repository;
	
	@Autowired
	TimesheetService service;
	
	@RequestMapping(method=RequestMethod.GET)
	public List<HolidaySchedules> getHolidaySchedules() {
		List<HolidaySchedules> holidayscheduleslist = null;
		try{
			//visible to all permissions
			holidayscheduleslist = repository.findAll();
			
		}
		catch(Exception e){
			logger.error(e);
		}
		return holidayscheduleslist;
		
	}
	
	@RequestMapping(method=RequestMethod.POST)
	public HolidaySchedules addHolidaySchedules(@RequestBody HolidaySchedules holidayschedules) {
		try{
			if(service.isPmo()){
				repository.save(holidayschedules);
			}
		}
		catch(Exception e){
			logger.error(e);
		}
		return holidayschedules;
	}
	
	@RequestMapping(value="/{holidayScheduleId}",method=RequestMethod.DELETE)
	public void deleteHolidaySchedules(@PathVariable Integer holidayScheduleId) {
		try{
			if(service.isPmo()){
				repository.delete(holidayScheduleId);
			}
		}
		catch(Exception e){
			logger.error(e);
		}
	}
	
	@RequestMapping(value="/{holidayScheduleId}",method=RequestMethod.PUT)
	public HolidaySchedules updateHolidaySchedules(@PathVariable Integer holidayScheduleId,@RequestBody HolidaySchedules holidayschedules) {
		try{
			if(service.isPmo()){
				holidayschedules.setHolidayScheduleId(holidayScheduleId);
				repository.save(holidayschedules);
			}
		}
		catch(Exception e){
			logger.error(e);
		}
		return holidayschedules;
	}
    
}
