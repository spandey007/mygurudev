package com.infocepts.otc.repositories;

import java.util.List;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.infocepts.otc.entities.ProjectTask;



@Repository
@Transactional
public interface ProjectTaskRepository extends CrudRepository<ProjectTask,Integer> {

	@Override
    List<ProjectTask> findAll();

	@Query("select tasks FROM ProjectTask tasks where tasks.taskDisabled IS NULL and tasks.projectId = :projectId order by tasks.taskOrder")
	List<ProjectTask> getAllActiveTasksForProject(@Param("projectId") Integer projectId);

	@Query("select tasks FROM ProjectTask tasks where tasks.taskDisabled IS NULL and tasks.projectId = :projectId order by tasks.taskId")
	List<ProjectTask> getAllActiveTasksForProjectOrderedByTaskId(@Param("projectId") Integer projectId);

	@Query("SELECT tasks.taskId FROM ProjectTask tasks where tasks.projectId = :projectId and taskId NOT IN (:taskIds)")
	List<Integer> getTasksToDisabled(@Param("projectId") Integer projectId, @Param("taskIds") List<Integer> taskIds);

	@Override
	<S extends ProjectTask> List<S> save(Iterable<S> iterable);

	@Modifying
	@Query("update ProjectTask taskCenter set taskCenter.taskDisabled = true where taskCenter.taskId in (:taskIds)")
	void setTaskToDisabled(@Param("taskIds") List<Integer> taskids);
}
