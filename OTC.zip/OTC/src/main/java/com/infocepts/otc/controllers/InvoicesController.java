package com.infocepts.otc.controllers;

import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.mail.MessagingException;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.thymeleaf.context.Context;

import com.infocepts.otc.entities.Account;
import com.infocepts.otc.entities.Invoices;
import com.infocepts.otc.entities.Project;
import com.infocepts.otc.entities.Resource;
import com.infocepts.otc.notification.SmtpMailSender;
import com.infocepts.otc.repositories.AccountRepository;
import com.infocepts.otc.repositories.InvoicesRepository;
import com.infocepts.otc.services.TimesheetService;
import com.infocepts.otc.utilities.DateConverter;
import com.infocepts.otc.utilities.ExportUtil;
import com.infocepts.otc.utilities.InvoiceNoGenerator;
import com.infocepts.otc.utilities.QueryConstant;

@RestController
@RequestMapping(value="/invoices",headers="referer")
public class InvoicesController {

	final Logger logger = Logger.getLogger(InvoicesController.class);
	
	@Autowired
	InvoicesRepository repository;
	
	@Autowired
	SmtpMailSender smtpMailSender;
	
	@PersistenceContext
    private EntityManager manager;
	
	@Autowired
	ExportUtil exportUtil;
	
	@Autowired
	TimesheetService service;
	
	@Autowired
	ProjectController projectController;
	
	@Autowired
	ResourceController resourceController;
	
	@Autowired
	AccountRepository accountRepository;
	
	@Autowired
	HttpSession session;
	
	final String CreditNoteStr="Credit Note";
	
	 @RequestMapping(method=RequestMethod.POST)
		public Invoices addInvoice(@RequestBody Invoices invoice, HttpServletRequest request) throws MessagingException
		{	
		 String invoiceNo = "";
		 String finalInvoiceNo = "";
		 String invoices = "";
		 String invoiceType="";
		 List<Invoices> invoiceslist=null;
			try{
				if("Draft".equals(invoice.getInvoiceStatus()) || "Pending Approval".equals(invoice.getInvoiceStatus())){
						if(invoice.getInvoiceType().equals(CreditNoteStr)){
							invoiceslist = manager.createNamedQuery("getLastInvoice_CreditNote",Invoices.class)
									.setParameter("billingUnit", invoice.getBillingUnit())
									.setParameter("invoiceType", invoice.getInvoiceType())
									.getResultList();
						}
						else{
							invoiceslist = manager.createNamedQuery("getLastInvoice",Invoices.class)
									.setParameter("billingUnit", invoice.getBillingUnit())
									.getResultList();
						}
						if(invoiceslist.size()>0){
							Iterator<Invoices> it = invoiceslist.iterator();
							while (it.hasNext()) {
								Invoices invoicesIt = it.next();
								invoices = invoicesIt.getInvoiceNo();
								invoiceType=invoicesIt.getInvoiceType();
							}
							invoiceNo = InvoiceNoGenerator.generateInvoiceno(invoices,"draft",invoice.getBillingEntity(),invoice.getUnitId(),invoiceType,invoice.getArInvoiceDate());
							invoice.setInvoiceNo(invoiceNo);
							
							service.sendInvoiceNotification(invoice, "add", request);
						}
						else{
							invoiceNo = InvoiceNoGenerator.generateInvoiceno_CreditNote(invoices,"draft",invoice.getUnitId(),invoice.getInvoiceType());
							invoice.setInvoiceNo(invoiceNo);
						}
						
				}else if("Completed".equals(invoice.getInvoiceStatus()) && ("".equals(invoice.getInvoiceNo()))){
					if("".equals(invoice.getInvoiceNo())){
						invoiceslist = manager.createNamedQuery("getLastInvoice",Invoices.class)
												.setParameter("billingUnit", invoice.getBillingUnit())
												.getResultList();
						Iterator<Invoices> it = invoiceslist.iterator();
						while (it.hasNext()) {
							Invoices invoicesIt = it.next();
							invoices = invoicesIt.getInvoiceNo();
								
						}
						invoiceNo = InvoiceNoGenerator.generateInvoiceno(invoices,"draft",invoice.getBillingEntity(),invoice.getUnitId(),invoiceType,invoice.getArInvoiceDate());
								
					}
					invoiceslist = manager.createNamedQuery("getLastFinalInvoice",Invoices.class)
										.setParameter("billingUnit", invoice.getBillingUnit())
										.getResultList();
						Iterator<Invoices> it = invoiceslist.iterator();
						while (it.hasNext()) {
							Invoices invoicesIt = it.next();
							invoices = invoicesIt.getFinalInvoiceNo();
							
						}
					finalInvoiceNo = InvoiceNoGenerator.generateInvoiceno(invoices,"final",invoice.getBillingEntity(),invoice.getUnitId(),invoiceType,invoice.getArInvoiceDate());
					invoice.setInvoiceNo(invoiceNo);
					invoice.setFinalInvoiceNo(finalInvoiceNo);
					
						service.sendInvoiceNotification(invoice, "add", request); 											
				}
				invoice.setInvoiceId(null);
				repository.save(invoice);
					}catch(Exception e){
				logger.error(e);
			}
			return invoice;
		}
	
	@SuppressWarnings("unchecked")
	@GetMapping("/getInvoices")
	public List<Invoices> getAllInvoices(@RequestParam(value = "invoiceId",defaultValue = "0") Integer invoiceId,
														@RequestParam(value = "accountId",defaultValue = "") String accountId,
														@RequestParam(value = "projectId",defaultValue = "") String projectId,
														@RequestParam(value = "billingType", defaultValue = "") String projectType,
														@RequestParam(value = "invoiceNo", defaultValue = "") String invoiceNo,
														@RequestParam(value = "invoiceStatus", defaultValue = "") String invoiceStatus,
														@RequestParam(value = "month", defaultValue = "0") Integer month,
														@RequestParam(value = "year", defaultValue = "0") Integer year,
														@RequestParam(value = "milestone", defaultValue = "0") Integer milestone,
														@RequestParam(value = "billingUnit", defaultValue = "") String billingUnit,
														@RequestParam(value = "monthEndDate", defaultValue = "")String monthEndDate,
														@RequestParam(value = "monthstartDate", defaultValue = "")String monthstartDate,
														@RequestParam(value = "invoiceType", defaultValue = "services")String invoiceType,
														@RequestParam(value = "lastInvoice", defaultValue = "0") Integer lastInvoice,
														@RequestParam(value = "pmId",defaultValue = "0") Integer pmId,
														@RequestParam(value = "receipt",defaultValue = "false") Boolean receipt,
														@RequestParam(value = "lastFinalInvoice", defaultValue = "0") Integer lastFinalInvoice,
														@RequestParam(value = "getEndClientProjects", defaultValue = "0") Integer getEndClientProjects,
														@RequestParam(value = "getEndClientInvoiceNo", defaultValue = "0") Integer getEndClientInvoiceNo,
														@RequestParam(value = "dmId",defaultValue = "0") Integer dmId,
														@RequestParam(value = "rmId",defaultValue = "0") Integer rmId,
														@RequestParam(value = "bulk",defaultValue = "0") Integer bulk,
														@RequestParam(value = "ahId",defaultValue = "0") Integer ahId,
														@RequestParam(value = "revenueYTD",defaultValue = "0") Integer revenueYTD,
														@RequestParam(value = "report",defaultValue = "") String report,
														@RequestParam(value = "invoiceCountCheck", defaultValue = "0") Integer invoiceCountCheck,
														@RequestParam(value = "uid", defaultValue = "0") Integer uid,
														@RequestParam(value = "searchInvoiceNo", defaultValue = "") String searchInvoiceNo,
														HttpServletRequest request){
	//public List<Invoices> getAllActiveProjects(){
		 
	List<Invoices> invoiceslist=null;
	Boolean isAValidAdminRole = false;
	Boolean isBF			  = false;
	Integer loggedInUid = (Integer) session.getAttribute("loggedInUid");
		try{
			
			isAValidAdminRole = service.isAValidAdminRole();
			isBF 			  = service.isBF();
			
			Query invoicesQuery = null;
			String query = null;
			StringBuilder str = new StringBuilder();
			StringBuilder invoiceApproval = new StringBuilder();
			
			if(invoiceCountCheck == 1 && loggedInUid == uid) {
				pmId = uid; 
				dmId = uid;
				rmId = uid;
				ahId = uid;			
			}
			
			if(isAValidAdminRole || (loggedInUid.equals(pmId) || loggedInUid.equals(dmId) || loggedInUid.equals(rmId) ||  loggedInUid.equals(ahId) || isBF)){
			if(!"".equals(searchInvoiceNo)) {
				invoiceslist = manager.createNamedQuery("getInvoiceByInvoiceNo",Invoices.class)
						.setParameter("searchInvoiceNo", searchInvoiceNo)
						.getResultList();
			}else if(invoiceCountCheck == 1) {
					invoiceApproval.append(QueryConstant.Query_Invoices_Project_Count);
					query = invoiceApproval.toString();
					invoicesQuery = this.manager.createNativeQuery(query, "invoices_count_result"); 
					invoiceslist = invoicesQuery.setParameter("monthstartDate", monthstartDate)
							.setParameter("monthEndDate", monthEndDate)
							.setParameter("uid", uid)
							.getResultList();
			}
			else if(lastInvoice == 1){
				invoiceslist = manager.createNamedQuery("getLastInvoice",Invoices.class)
						.setParameter("billingUnit", billingUnit)
						 .getResultList();
			}
			else if(lastFinalInvoice == 1){
				invoiceslist = manager.createNamedQuery("getLastFinalInvoice",Invoices.class)
						.setParameter("billingUnit", billingUnit)
						 .getResultList();
			}else if(getEndClientProjects == 1){
				invoiceslist = manager.createNamedQuery("getEndClientProjectsForInternalInvoice",Invoices.class)
						.setParameter("monthstartDate", monthstartDate)
						.setParameter("monthEndDate", monthEndDate)
						 .getResultList();
			}else if(revenueYTD == 1){
					invoiceslist = manager.createNamedQuery("getInvoiceRevenueYTD",Invoices.class)
						.setParameter("year", year)
						.setParameter("phId", dmId)
						.setParameter("cepId", rmId)
						.getResultList();
			}else if("timesheet".equalsIgnoreCase(report)) {
				invoiceslist = manager.createNamedQuery("getMonthlyTimesheetReport",Invoices.class)
						.setParameter("monthstartDate", monthstartDate)
						.setParameter("monthEndDate", monthEndDate)
						.getResultList();
			}else if("invoice".equalsIgnoreCase(report)) {
				invoiceslist = manager.createNamedQuery("getMonthlyInvoiceReport",Invoices.class)
						.setParameter("monthstartDate", monthstartDate)
						.setParameter("monthEndDate", monthEndDate)
						.getResultList();
			}
			else if(getEndClientInvoiceNo == 1){
				invoiceslist = manager.createNamedQuery("getFinalInvoiceNosForInternalInvoice",Invoices.class)
						.setParameter("monthstartDate", monthstartDate)
						.setParameter("monthEndDate", monthEndDate)
						.getResultList();
			}else if(bulk == 1){
				str.append(QueryConstant.Query_Bulk_Invoices);
				if (!("".equals(accountId)))
				{
					str.append(" and p.accountId = '").append(accountId).append("'");
				}
				if (!("".equals(projectId)))
				{
				   str.append(" and p.itemId = '").append(projectId).append("'");
				}
				if (!("".equals(invoiceNo)))
				{
				   str.append(" and i.invoiceNo = '").append(invoiceNo).append("'");
				}
				if (!("".equals(invoiceType)) && !("services".equals(invoiceType)))
				{
					str.append(" and i.invoicetype = '").append(invoiceType).append("'");
			    }
				str.append(" order by p.title, i.arInvoiceDate Desc ");
				
				query = str.toString();
				invoicesQuery = this.manager.createNativeQuery(query, "project_for_invoices"); 
				invoiceslist = invoicesQuery.setParameter("monthstartDate", monthstartDate)
						.setParameter("monthEndDate", monthEndDate)
						.getResultList();
			}else
			{
				if(invoiceType.equals("services"))
				{
					str.append(QueryConstant.Query_Invoices_get_projects);
					if(pmId == 0 || dmId == 0 || ahId == 0){
						str.append(" and i.invoicetype = 'Services Invoice' ");
					}
					str.append(" where  b.name <> 'None'"); // Where billing type is 'None'
					
					if (!("".equals(accountId)))
					{
						str.append(" and p.accountId = '").append(accountId).append("'");
					}
					if (!("".equals(projectId)))
					{
					   str.append(" and p.itemId = '").append(projectId).append("'");
					}
					if (!("".equals(invoiceNo)))
					{
					   str.append(" and i.invoiceNo = '").append(invoiceNo).append("'");
					}
					if (!("".equals(invoiceStatus)))
					{
						str.append(" and i.invoiceStatus = '").append(invoiceStatus).append("'");
					}
					if (!("".equals(billingUnit)))
					{
					   str.append(" and u.name like '").append(billingUnit).append("%'");
					}
					if (pmId != 0 || dmId != 0 || ahId != 0)
					{
					   str.append(" and (i.pmId = '").append(pmId).append("'");
					   str.append(" or i.dmId = '").append(dmId).append("'");
					   str.append(" or i.ahId = '").append(ahId).append("'");
					   str.append(" or a.rmId = '").append(loggedInUid).append("')");
					   str.append(" and i.invoiceStatus != 'Draft'");
					   str.append(" and i.invoicetype != 'Internal Invoice'");
					}
					if(milestone == 1)
					{
						str.append(" and b.name = 'Fixed Bid Milestone' ");
					}
					else // DEFAULT - Non-Milestone projects (T&M, Fixed Bid Monthly)
					{
						str.append(" and b.name != 'Fixed Bid Milestone' ");					
					}
					if(receipt == true){
						str.append(" and i.finalInvoiceNo is not null ");
					}
					
					//" where p.state = 'Active'" + 
					
					str.append(" and (cast(p.projectStart as DATE) <= :monthEndDate or p.projectStart is null) ");
					str.append(" and (cast(p.projectEnd as DATE) >= :monthstartDate or p.projectEnd is null) ");
					str.append(" order by p.title, i.arInvoiceDate Desc ");
					
					query = str.toString();
					invoicesQuery = this.manager.createNativeQuery(query, "project_for_invoices"); 
					invoiceslist = invoicesQuery.setParameter("month", month)
							.setParameter("year", year)
							.setParameter("monthEndDate", monthEndDate)
							.setParameter("monthstartDate", monthstartDate)
							.getResultList();
				}
			else // to retrieve all other invoices
			{
				str.append(QueryConstant.Query_Other_Invoices_get_projects);
				
				if (!("".equals(invoiceType)))
				{
					str.append(" and i.invoicetype = '").append(invoiceType).append("'");
			    }
				if (!("".equals(accountId)))
				{
					str.append(" and p.accountsId = '").append(accountId).append("'");
			    }
				if (!("".equals(projectId)))
				{
				   str.append(" and p.itemId = '").append(projectId).append("'");
				}
				if (!("".equals(monthstartDate)))
				{
				   str.append(" and ((cast(i.periodStartDate as DATE) between '").append(monthstartDate).append("'").append(" and '").append(monthEndDate).append("')");
				}
				if (!("".equals(monthEndDate)))
				{
				   str.append(" or (cast(i.periodEndDate as DATE)  between '").append(monthEndDate).append("'").append(" and '").append(monthEndDate).append("'))");
				}
				if (!("".equals(invoiceNo)))
				{
					str.append(" and i.finalInvoiceNo = '").append(invoiceNo).append("'");
			    }
				if(receipt == true){
					str.append(" and i.finalInvoiceNo is not null ");
				}
				if (("Expense Invoice".equals(invoiceType)) || ("Internal Invoice".equals(invoiceType)) || ("Services Invoice".equals(invoiceType)))
				{
				   str.append(" order by i.arInvoiceDate Desc ");
				}
				query = str.toString();
				invoicesQuery = this.manager.createNativeQuery(query, "project_for_invoices"); 
				invoiceslist = invoicesQuery.getResultList();
			}
		  }
			
			}/*else{
				service.sendTamperedMail("Invoice list View By ", loggedInUid, pmId, request);
				return invoiceslist;
			}*/
		
		}catch(Exception e){
			 logger.error(e);
		}
		return invoiceslist;
	 }
	
	
	 @GetMapping("/getInvoiceById")
	 public Invoices getSow(@PathVariable Integer invoiceId){
		 Invoices invoice = null;
		 try{
			 if(invoiceId != 0){
				 invoice = repository.findOne(invoiceId);
			 }
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return invoice;
	 }
	
	 @RequestMapping(value="/{invoiceId}",method=RequestMethod.PUT)
	 public Invoices updateInvoice(@RequestBody Invoices updatedInvoice,@PathVariable Integer invoiceId,HttpServletRequest request,@RequestParam(value = "isDownload", defaultValue="false") Boolean isDownload) throws URISyntaxException, IOException, MessagingException{
		 String path=null;
		 try{
			 List<Invoices> invoiceslist=null;
			 Invoices internalInvoice = null;
			 InvoicesDetailController invoiceDetail = new InvoicesDetailController();
			 String invoices = "";
			 File outputFile=null;
	         String FileName = null;
		     String statusCompleted="Completed";
		     String monthName = "";
		     String accountName = "";
		     String invoiceNo = "";
		     String finalInvoiceNo = "";
	         Project project = null;
	         String updatedInvoiceNo = "";
			 File home =  exportUtil.checkPath(request);
			 path=home.getPath();
			 String separator=File.separator;
		     
		     LocalDate localDate = updatedInvoice.getArInvoiceDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
		     int year  = localDate.getYear();
		     int month = localDate.getMonthValue();
		     String invoiceType = updatedInvoice.getInvoiceType();
		     
		     if(!isDownload){
		    		if("Completed".equals(updatedInvoice.getInvoiceStatus()) && (!("".equals(updatedInvoice.getInvoiceNo()))) 
		    				&& ("".equals(updatedInvoice.getFinalInvoiceNo()))){
		    			if(updatedInvoice.getInvoiceType().equals(CreditNoteStr)){
		    				invoiceslist = manager.createNamedQuery("getLastFinalInvoice_CreditNote",Invoices.class)
					 				.setParameter("billingUnit", updatedInvoice.getBillingUnit())
					 				.setParameter("invoiceType", updatedInvoice.getInvoiceType())
					 				 .getResultList();
		    			}
		    			else{
		    				 invoiceslist = manager.createNamedQuery("getLastFinalInvoice",Invoices.class)
						 				.setParameter("billingUnit", updatedInvoice.getBillingUnit())
						 				 .getResultList();
		    			}
			    		if(invoiceslist.size()>0){
			    			Iterator<Invoices> it = invoiceslist.iterator();
				 			while (it.hasNext()) {
				 				Invoices invoicesIt = it.next();
				 				invoices = invoicesIt.getFinalInvoiceNo();
				 				invoiceType = invoicesIt.getInvoiceType();
				 			}
						//invoiceNo = InvoiceNoGenerator.generateInvoiceno(invoices,"draft",updatedInvoice.getBillingEntity(),updatedInvoice.getBillingUnit());
						finalInvoiceNo = InvoiceNoGenerator.generateInvoiceno(invoices,"final",updatedInvoice.getBillingEntity(),updatedInvoice.getUnitId(),invoiceType,updatedInvoice.getArInvoiceDate());
						//updatedInvoice.setInvoiceNo(invoiceNo);
						updatedInvoice.setFinalInvoiceNo(finalInvoiceNo);
			    		}
			    		else{
			    			finalInvoiceNo = InvoiceNoGenerator.generateInvoiceno_CreditNote(invoices,"final",updatedInvoice.getUnitId(),updatedInvoice.getInvoiceType());
			    			updatedInvoice.setFinalInvoiceNo(finalInvoiceNo);
			    		}
					}
		    		if("Pending Approval".equals(updatedInvoice.getInvoiceStatus()) && (!("".equals(updatedInvoice.getInvoiceNo()))) 
		    				&& !("".equals(updatedInvoice.getFinalInvoiceNo())) && (updatedInvoice.getFinalInvoiceNo() != null)){
		    			internalInvoice = repository.findInternalInvoiceByEndClientInvoiceNo(updatedInvoice.getFinalInvoiceNo());
		    			if(internalInvoice != null){
		    				invoiceDetail.deleteInvoicesDetail(internalInvoice.getInvoiceId());
			    			deleteInvoices(internalInvoice.getInvoiceId(),request);
		    			}
		    		}
		    		
					if("Pending Approval".equals(updatedInvoice.getInvoiceStatus())){
						service.sendInvoiceNotification(updatedInvoice, "add", request); 											
				     }
		
					if("Approved".equals(updatedInvoice.getInvoiceStatus())){
						service.sendInvoiceNotification(updatedInvoice, "update", request); 										
				     }
		
					if("Rejected".equals(updatedInvoice.getInvoiceStatus())){
						service.sendInvoiceNotification(updatedInvoice, "update", request); 											
				     }
					
					if("Completed".equals(updatedInvoice.getInvoiceStatus())){
						service.sendInvoiceNotification(updatedInvoice, "update", request); 											
				     }
		    	}else{
		    		project = manager.createNamedQuery("getProjectById", Project.class)
		                     .setParameter("itemId", updatedInvoice.getProjectId())
		                     .getSingleResult();
				 
					 monthName = DateConverter.theMonth(month);
			         accountName = project.getAccountName().replaceAll("[+.^:,~]", "");
			         
			         
					if (statusCompleted.equals(updatedInvoice.getInvoiceStatus())) {
						updatedInvoiceNo = updatedInvoice.getFinalInvoiceNo().replaceAll("[\\s+.^:,~]", "");
						FileName = "Invoice-" + monthName + "-InfoCepts-" +accountName+ "-" +updatedInvoiceNo;
					} else {
						updatedInvoiceNo = updatedInvoice.getInvoiceNo().replaceAll("[\\s+.^:,~]", "");
						FileName = "Invoice-" + monthName + "-InfoCepts-" +accountName+"-"+updatedInvoiceNo;
					}
				 
			    	if(updatedInvoice.getInvoiceStatus().equals(statusCompleted)){
			    		 if(path.equals(separator)){
							 path="usr"+File.separator+"home"+File.separator+"Download"+File.separator+"invoices"+File.separator;
						 }
						 else{
							 path=File.separator+"usr"+File.separator+"home"+File.separator+"Download"+File.separator+"invoices"+File.separator;
						 }
			    		 outputFile = new File(home+path+year+File.separator+month+File.separator+invoiceType+File.separator+FileName);
			    	}else{
			    		 if(path.equals(separator)){
							 path="usr"+File.separator+"temp"+File.separator+"Download"+File.separator+"invoices"+File.separator;
						 }
						 else{
							 path=File.separator+"usr"+File.separator+"temp"+File.separator+"Download"+File.separator+"invoices"+File.separator;
						 }
			    		 outputFile = new File(home+path+year+File.separator+month+File.separator+invoiceType+File.separator+FileName);
			    	}
		    	}
		    	
		    	 updatedInvoice.setInvoiceId(invoiceId);
		    	 updatedInvoice.setFilePath(outputFile+".docx");
		    	 repository.save(updatedInvoice);
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return updatedInvoice;
	 }
	 @RequestMapping(value="/{invoiceId}",method=RequestMethod.DELETE)
	 public void deleteInvoices(@PathVariable Integer invoiceId,HttpServletRequest request){
		 try{
			 repository.delete(invoiceId);
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
	 }	
}
