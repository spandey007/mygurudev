package com.infocepts.otc.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.infocepts.otc.entities.Cms;

public interface CmsRepository extends CrudRepository<Cms,Integer>{

	@Override
	public List<Cms> findAll();	
	
	@Query("select accountId from Cms where cmsId = :cmsId")
	public Integer getAccountIdByCmsId(@Param("cmsId") int cmsId);
}
