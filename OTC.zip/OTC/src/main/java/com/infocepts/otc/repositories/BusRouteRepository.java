package com.infocepts.otc.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.infocepts.otc.entities.BusRoute;

public interface BusRouteRepository extends CrudRepository<BusRoute,Integer>{

	@Override
	public List<BusRoute> findAll();

}
