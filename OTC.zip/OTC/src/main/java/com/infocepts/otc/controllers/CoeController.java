/**
* Filename: /src/main/java/com/infocepts/otc/controllers/CoeController.java
* @author  AA
* @version 1.0
* @since   2019-05-01 
*/
package com.infocepts.otc.controllers;
import java.util.logging.Logger;
import com.infocepts.otc.entities.Coe;
import com.infocepts.otc.repositories.CoeRepository;
import com.infocepts.otc.services.TimesheetService;
import org.hibernate.MappingException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import javax.mail.MessagingException;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.List;

@RestController
@RequestMapping(value = "/Coe", headers = "referer")
public class CoeController {

	final Logger logger = Logger.getLogger(CoeController.class.getName());

	@Autowired
	CoeRepository repository;

	@Autowired
	HttpSession session;

	@PersistenceContext(unitName = "otc")
	private EntityManager manager;

	@Autowired
	TimesheetService service;
	@RequestMapping(method = RequestMethod.POST)
	public Coe addCoe(@RequestBody Coe Coe, HttpServletRequest request) throws MappingException, Exception {
		// Authorization for COE role
		if (service.isCOE()) {
			try {
				Coe.setCoeId(null);
				repository.save(Coe);
			} catch (Exception e) {
				logger.info(String.format("exception - ", e));
			}
		} else {
			service.sendTamperedMail("Coe Save", 0, 0, request);
		}

		return Coe;
	}

	/**
	 * This method is update row in moduleName entity based on primaryKey Of Module
	 * Table
	 * 
	 * @throws Throwable
	 */
	@RequestMapping(value = "/{coeId}", method = RequestMethod.PUT)
	public Coe updateCoe(@RequestBody Coe updatedCoe, @PathVariable Integer coeId, HttpServletRequest request)
			throws MappingException, Throwable {
		// Authorization for COE role
		if (service.isCOE()) {
			try {
				updatedCoe.setCoeId(coeId);
				repository.save(updatedCoe);
			} catch (Exception e) {
				logger.info(String.format("exception - ", e));
			}
		} else {
			service.sendTamperedMail("Coe Save", 0, 0, request);
		}
		return updatedCoe;
	}

	/**
	 * This method is get data for specific row in moduleName entity based on
	 * primaryKey Of Module Table
	 */
	@RequestMapping(value = "/{coeId}", method = RequestMethod.GET)
	public Coe getCoe(@PathVariable Integer coeId, HttpServletRequest request) throws MappingException {

		Coe Coe = null;
		// Authorization for COE role
		if (service.isCOE()) {
			try {
				Coe = manager.createNamedQuery("CoeQuerybycoeId", Coe.class).setParameter("coeId", coeId)
						.getSingleResult();
			} catch (Exception e) {
				logger.info(String.format("exception - ", e));
			}
		} else {
			try {
				service.sendTamperedMail("Coe Get", 0, 0, request);
			} catch (MessagingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return Coe;
	}

	// To display all COE
	@GetMapping("/getAllCoe")
	public Object getAllCoe(HttpServletRequest request) {

		List<Coe> CoeList = null;
		try {
			CoeList = manager.createNamedQuery("CoeQuery", Coe.class).getResultList();
		} catch (Exception e) {
			logger.info(String.format("error in fetching list - ", e.getMessage()));

		}
		return CoeList;
	}
}
