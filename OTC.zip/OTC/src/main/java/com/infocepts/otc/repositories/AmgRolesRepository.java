package com.infocepts.otc.repositories;

import java.util.List;
import org.springframework.data.repository.CrudRepository;
import com.infocepts.otc.entities.AmgRoles;

public interface AmgRolesRepository extends CrudRepository<AmgRoles,Integer>{
	
	@Override
	public List<AmgRoles> findAll();
}
