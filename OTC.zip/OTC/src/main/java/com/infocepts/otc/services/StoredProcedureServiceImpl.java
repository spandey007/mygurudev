package com.infocepts.otc.services;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
public class StoredProcedureServiceImpl implements StoredProcedureService {

    private static final Logger logger = LoggerFactory.getLogger(StoredProcedureServiceImpl.class);

    @PersistenceContext(unitName = "otc")
	private EntityManager entityManager;

	@Override
	@Transactional
	@Modifying
	public void ResourceBucket(Integer alcId) {
		
		this.entityManager.createNativeQuery("BEGIN exec spResourceBucket :alcId ; END;")
        .setParameter("alcId", alcId)
        .executeUpdate();
		
	}
	
	@Override
	@Transactional
	@Modifying
	public void UpdateAllocationOnSowUpdate(Integer sowDetailId) {
		
		this.entityManager.createNativeQuery("BEGIN exec spUpdateAllocationOnSowUpdate :sowDetailId ; END;")
        .setParameter("sowDetailId", sowDetailId)
        .executeUpdate();
		
	}
	
	@Override
	@Transactional
	@Modifying
	public void GenerateMonthlyAllocation(Integer alcId) {
		
		this.entityManager.createNativeQuery("BEGIN exec spGenerateMonthlyAllocation :alcId ; END;")
        .setParameter("alcId", alcId)
        .executeUpdate();
		
	}
	
	@Override
	@Transactional
	@Modifying
	public void DeleteSOWDetailAllocatioTreq(Integer sowDetailId, Integer uid) {
		
		this.entityManager.createNativeQuery("BEGIN exec spDeleteSOWDetailAllocatioTreq :sowDetailId,:uid ; END;")
        .setParameter("sowDetailId", sowDetailId)
        .setParameter("uid", uid)
        .executeUpdate();
		
	}
    

    

}
