package com.infocepts.otc.controllers;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.infocepts.otc.entities.AssociateSkills;
import com.infocepts.otc.repositories.AssociateSkillsRepository;
import com.infocepts.otc.services.TimesheetService;

@RequestMapping(value="/associateSkills",headers="referer")
@RestController
public class AssociateSkillsController {
	
	@PersistenceContext(unitName="otc")
    private EntityManager manager;
	
	@Autowired
	TimesheetService service;
	
	final Logger logger = Logger.getLogger(AssociateSkillsController.class);

	@Autowired
	AssociateSkillsRepository repository;
	
	@RequestMapping(method=RequestMethod.POST)
	public AssociateSkills saveAssociateSkills(@RequestBody AssociateSkills associateSkills){
		try{
				associateSkills.setAssociateSkillId(null);
				repository.save(associateSkills);
		}
		catch(Exception e){
			logger.error(e);
		}
		return associateSkills;
	}
	
	@RequestMapping(method=RequestMethod.GET)
	public List<AssociateSkills> getAssociateSkills(@RequestParam(value = "uid", defaultValue = "0") Integer uid){
		List<AssociateSkills> associateSkillsList=null;
		try
		{
			if(uid!=0)
			{	
				associateSkillsList = manager.createNamedQuery("getSkillsByAssociates",AssociateSkills.class)
							.setParameter("uid", uid)	
							.getResultList();
			}
			else
			{
				if(service.isAMG())
				{
					associateSkillsList = manager.createNamedQuery("getSkillsList_Associates",AssociateSkills.class)
									  .getResultList();
				}
			}
		}
		catch(Exception e){
			logger.error(e);
		}
		return associateSkillsList;
	}
	
	@RequestMapping(value="/{associateSkillId}",method=RequestMethod.PUT)
	public AssociateSkills updateAssociateSkills(@PathVariable Integer associateSkillId,@RequestBody AssociateSkills updatedassociateSkills){
		try{
				updatedassociateSkills.setAssociateSkillId(associateSkillId);
				repository.save(updatedassociateSkills);
		}
		catch(Exception e){
			logger.error(e);
		}
		return updatedassociateSkills;
	}
	
	@RequestMapping(value="/{associateSkillId}",method=RequestMethod.DELETE)
	public void deleteAssociateSkills(@PathVariable Integer associateSkillId){
			try{
					repository.delete(associateSkillId);
			}
			catch(Exception e){
				logger.error(e);
			}
	}
	
}
