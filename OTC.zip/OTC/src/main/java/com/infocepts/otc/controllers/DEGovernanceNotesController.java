package com.infocepts.otc.controllers;

import com.infocepts.otc.entities.DEGovernanceNotes;
import com.infocepts.otc.entities.DeGovernance;
import com.infocepts.otc.entities.Portfolio;
import com.infocepts.otc.repositories.DEGovernanceNotesRepository;
import com.infocepts.otc.services.TimesheetService;

import java.util.List;

import javax.mail.MessagingException;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/deGovernanceNotes")
public class DEGovernanceNotesController {
	
	@Autowired
	HttpSession session;
	
	@PersistenceContext
    private EntityManager manager;
	
	@Autowired
	TimesheetService service;
		
	private static final Logger logger = Logger.getLogger(DEGovernanceNotesController.class);

	@Autowired
	private DEGovernanceNotesRepository deGovernanceNotesRepository;

    @RequestMapping(value = "/{itemId}",method=RequestMethod.GET)
    public DEGovernanceNotes findNotesById(@PathVariable("itemId") Integer Id){
        return this.deGovernanceNotesRepository.findOne(Id);
    }

	@RequestMapping(method=RequestMethod.POST)
	public DEGovernanceNotes saveProjectMetric(@RequestBody DEGovernanceNotes deGovernanceNotes,
				HttpServletRequest request) throws MessagingException {
		
         this.deGovernanceNotesRepository.save(deGovernanceNotes);
   		 if(deGovernanceNotes.getDeComments()!=null) {
			 service.sendDeNoteNotification(deGovernanceNotes, request);			
		 }         
         return deGovernanceNotes;
	}

	@RequestMapping(value = "/{itemId}", method = RequestMethod.PUT)
	public DEGovernanceNotes  updateProjectMetric( @RequestBody DEGovernanceNotes deGovernanceNotes ,@PathVariable Integer Id,
			HttpServletRequest request) throws MessagingException {
		deGovernanceNotes.setId(Id);
        
        this.deGovernanceNotesRepository.save(deGovernanceNotes);
		if(deGovernanceNotes.getDeComments()!=null) {
			 service.sendDeNoteNotification(deGovernanceNotes, request);
		}
		
        return deGovernanceNotes;
    }
	
	@RequestMapping(method=RequestMethod.GET)
	public List<DEGovernanceNotes>  getAllDeGovernance(
			 					@RequestParam(value = "portfolioId", defaultValue = "") Integer portfolioId,
			 					@RequestParam(value = "deliveryId", defaultValue = "") Integer deliveryId,
			 					@RequestParam(value = "accountId", defaultValue = "") Integer accountId,
			 					@RequestParam(value = "deId", defaultValue = "") Integer deId,			 
			 					@RequestParam(value = "portfolioHeadId", defaultValue = "") Integer portfolioHeadId,			 					
			 					@RequestParam(value = "monthYear", defaultValue = "") String monthYear,
			 					HttpServletRequest request) throws MessagingException {
		
		List<DEGovernanceNotes> notes = null;
		
		int month = 0;
		int year = 0;
		 
		 if(!monthYear.equals("") && monthYear.contains("-")) { month = Integer.valueOf(monthYear.split("-")[0]); year = Integer.valueOf(monthYear.split("-")[1]); }
		try{
			
			if(portfolioId != null ) {
				notes = deGovernanceNotesRepository.findByPortfolioIdAndPeriod(portfolioId,month,year);				
			}

			if(portfolioHeadId != null ) {
				notes = deGovernanceNotesRepository.findByPortfolioHeadIdAndPeriod(portfolioHeadId,month,year);				
			}
			
			if (deliveryId != null) {
				notes = deGovernanceNotesRepository.findByDeliveryIdAndPeriod(deliveryId,month,year);
			}
			
			if (accountId != null) {
				notes = deGovernanceNotesRepository.findByAccountIdAndPeriod(accountId,month,year);
			}
			
		}catch (Exception e) {
			// TODO: handle exception
		}
		
		return notes;
		
	}
	
}
