package com.infocepts.otc.entities;


	import javax.persistence.ColumnResult;
	import javax.persistence.ConstructorResult;
	import javax.persistence.Entity;
	import javax.persistence.GeneratedValue;
	import javax.persistence.GenerationType;
	import javax.persistence.Id;
	import javax.persistence.NamedNativeQueries;
	import javax.persistence.NamedNativeQuery;
	import javax.persistence.SqlResultSetMapping;
	import javax.persistence.Table;

	import com.infocepts.otc.utilities.LoadConstant;

	@Entity
	@Table(catalog=LoadConstant.otc,schema="[dbo]",name="mstrconnect")
	@SqlResultSetMapping(
		      name = "mstr_ldap_mapping",
		      classes = {
		          @ConstructorResult(
		              targetClass = MSTRConnect.class,
		              columns = {	
		            	  @ColumnResult(name = "mappingId"),
		                  @ColumnResult(name = "mstruser",type=String.class),
		                  @ColumnResult(name = "ldapuser",type=String.class)
		             }
		          )
		      }
		)

		@NamedNativeQueries({    
		    @NamedNativeQuery(
		            name    =   "findLdapMstrMapping",
		            query   =  	"	select " 
		            			+ "	mappingId as mappingId,"
		            		   + "	cast(mstruser as varchar) as mstruser, "
							   + "	cast(ldapuser as varchar) as ldapuser"
							   + "	from "+ LoadConstant.otc +".[dbo].[mstrconnect] "
							   + "	where ldapuser = :ldapuser " 
							   + "	;",						             
		                        resultClass=MSTRConnect.class,  resultSetMapping = "mstr_ldap_mapping"  
		    				),
		    
						})
	public class MSTRConnect {
		 @Id
		 @GeneratedValue(strategy=GenerationType.IDENTITY)
		  private Integer mappingId;
		  

		private String mstruser;
		
		private String ldapuser; 
		
		
	    public Integer getMappingId() {
			return mappingId;
		}

		public void setMappingId(Integer mappingId) {
			this.mappingId = mappingId;
		}

		public String getMstruser() {
			return mstruser;
		}

		public void setMstruser(String mstruser) {
			this.mstruser = mstruser;
		}

		public String getLdapuser() {
			return ldapuser;
		}

		public void setLdapuser(String ldapuser) {
			this.ldapuser = ldapuser;
		}

		public MSTRConnect() {
		}

		public MSTRConnect(Integer mappingId, String mstruser, String ldapuser) {
			super();
			this.mappingId = mappingId;
			this.mstruser = mstruser;
			this.ldapuser = ldapuser;
		}
}
