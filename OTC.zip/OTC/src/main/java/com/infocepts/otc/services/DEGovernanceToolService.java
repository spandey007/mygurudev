package com.infocepts.otc.services;

import org.springframework.stereotype.Service;

import com.infocepts.otc.entities.DeGovernance;

@Service
public interface DEGovernanceToolService {
	
	//To insert or update monthly allocation table
	public void InsertUpdateComments(DeGovernance de);

}
