package com.infocepts.otc.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.infocepts.otc.entities.AssociateBucket;
import java.lang.Integer;

public interface AssociateBucketRepository extends CrudRepository<AssociateBucket,Integer>{

	@Override
	public List<AssociateBucket> findAll();
	
	
	@Query("from AssociateBucket where associateUid=:associateUid")
	public List<AssociateBucket> findByAssociateUid(@Param("associateUid")Integer associateUid);


	@Query("select count(*) from AssociateBucket where bucketId=:bucketId")
	public List<AssociateBucket> findByBucketId(@Param("bucketId")Integer bucketId);
}
