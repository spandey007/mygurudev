/**
* Filename: /src/main/java/com/infocepts/otc/entities/DeMsr.java
* @author  SHRI
* @version 1.0
* @since   2018-11-28 
*/
package com.infocepts.otc.entities;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.persistence.*;
import javax.validation.constraints.NotNull;

import com.infocepts.otc.utilities.LoadConstant;
@Entity
@Table(catalog=LoadConstant.otc, schema="[dbo]", name="deMsr")

@SqlResultSetMappings({
        @SqlResultSetMapping(
                name = "list_all_deMsr",
                classes = {
                        @ConstructorResult(
                                targetClass = DeMsr.class,
                                columns = {
                                		@ColumnResult(name = "deMsrId"),
                                        @ColumnResult(name = "projectId"), 
										@ColumnResult(name = "filepath", type = String.class),
										@ColumnResult(name = "deMsrMonth", type = Date.class),	
										@ColumnResult(name = "createdBy"),	
										@ColumnResult(name = "createdDate", type = Date.class),
										@ColumnResult(name = "modifiedBy"),
										@ColumnResult(name = "modifiedDate", type = Date.class),	
										@ColumnResult(name = "status", type = String.class),										
                                        @ColumnResult(name = "comments", type = String.class),
                                        @ColumnResult(name = "projectName", type = String.class),
										@ColumnResult(name = "itemId "),
										@ColumnResult(name = "ahId"),
										@ColumnResult(name = "projectManagersId"),
										@ColumnResult(name = "portfolioId "),
                                        @ColumnResult(name = "accountName", type = String.class),
                                        @ColumnResult(name = "portfolioName", type = String.class)
                                }
                        )
                }
        )
})
@NamedNativeQueries({
        @NamedNativeQuery(
                name    =   "getAllDeMsrData",   
                query 	=   "Select dpr.*, p.title as projectName,p.itemId, a.ahId, p.projectManagersId, p.portfolioId, a.accountShortName as accountName, po.title as portfolioName"+
							" from " + LoadConstant.infomaster + ".[dbo].[project] p"+
							" Left JOIN " + LoadConstant.otc + ".[dbo].[deMsr] as dpr on p.itemId = dpr.projectId and month(dpr.deMsrMonth) = :month and year(dpr.deMsrMonth) = :year"+
							" Left JOIN " + LoadConstant.infomaster + ".[dbo].[accounts] as a on p.accountId = a.itemId"+
							" Left JOIN " + LoadConstant.infomaster + ".[dbo].[portfolio] as po on a.portfolioId = po.itemId"+
							" WHERE p.state = 'Active' AND p.parentProjectId is NULL AND "+
		            		"(('pm' = :view and p.projectManagersId = :uid ) "+
		            		"or ('pm' = :view and p.plannersId like concat('%,',:uid,',%') or p.plannersId like concat('%,',:uid) or p.plannersId like concat(:uid,',%')) "+
		            		"or "+
		            		"('ph' = :view and po.ownerId = :uid ) "+
		            		"or "+
		            		"('pmo' = :view ) "+
		            		"or "+
		            		"('cep' = :view and a.rmId = :uid ) "+
		            		"or "+
		            		"('dh' = :view ) "+
		            		"or "+
		            		"('de' = :view )) order by dpr.deMsrId desc",
							
							resultClass=DeMsr.class, resultSetMapping = "list_all_deMsr"
        )        
})


public class DeMsr {

	// Entity Columns
    // --------------------------------------------------------------------------------
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Integer deMsrId; 		
	private Integer projectId;    
	private String filepath;
    private Date deMsrMonth;
	private Integer createdBy;    
    private Date createdDate;
    private Integer modifiedBy;
    private Date modifiedDate;
	private String status;

	@Lob
	private String comments;
	
	@Transient
	private String projectName;
	
	@Transient
	private Integer itemId;

	@Transient
	private Integer ahId;
	
	@Transient
	private Integer projectManagersId;

	@Transient
	private Integer portfolioId;
	
	@Transient
	private String accountName;
	
	@Transient
	private String portfolioName;

	

	public Integer getDeMsrId() {
		return deMsrId;
	}



	public void setDeMsrId(Integer deMsrId) {
		this.deMsrId = deMsrId;
	}



	public Integer getProjectId() {
		return projectId;
	}



	public void setProjectId(Integer projectId) {
		this.projectId = projectId;
	}



	public String getFilepath() {
		return filepath;
	}



	public void setFilepath(String filepath) {
		this.filepath = filepath;
	}


	public Date getDeMsrMonth() {
		return deMsrMonth;
	}



	public void setDeMsrMonth(Date deMsrMonth) {
		this.deMsrMonth = deMsrMonth;
	}



	public Integer getCreatedBy() {
		return createdBy;
	}



	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}



	public Date getCreatedDate() {
		return createdDate;
	}



	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}



	public Integer getModifiedBy() {
		return modifiedBy;
	}



	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}



	public Date getModifiedDate() {
		return modifiedDate;
	}



	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}



	public String getComments() {
		return comments;
	}



	public void setComments(String comments) {
		this.comments = comments;
	}



	public String getProjectName() {
		return projectName;
	}



	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}



	public Integer getItemId() {
		return itemId;
	}



	public void setItemId(Integer itemId) {
		this.itemId = itemId;
	}


	public Integer getAhId() {
		return ahId;
	}



	public void setAhId(Integer ahId) {
		this.ahId = ahId;
	}



	public Integer getProjectManagersId() {
		return projectManagersId;
	}



	public void setProjectManagersId(Integer projectManagersId) {
		this.projectManagersId = projectManagersId;
	}



	public Integer getPortfolioId() {
		return portfolioId;
	}



	public void setPortfolioId(Integer portfolioId) {
		this.portfolioId = portfolioId;
	}



	public String getAccountName() {
		return accountName;
	}



	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}



	public String getPortfolioName() {
		return portfolioName;
	}



	public void setPortfolioName(String portfolioName) {
		this.portfolioName = portfolioName;
	}


	public String getStatus() {
		return status;
	}



	public void setStatus(String status) {
		this.status = status;
	}



	/*default constructor*/
	public DeMsr() {
		
	}



	public DeMsr(Integer deMsrId, Integer projectId, String filepath, Date deMsrMonth, Integer createdBy,
			Date createdDate, Integer modifiedBy, Date modifiedDate, String status, String comments, String projectName,
			Integer itemId, Integer ahId, Integer projectManagersId, Integer portfolioId, String accountName,
			String portfolioName) {
		super();
		this.deMsrId = deMsrId;
		this.projectId = projectId;
		this.filepath = filepath;
		this.deMsrMonth = deMsrMonth;
		this.createdBy = createdBy;
		this.createdDate = createdDate;
		this.modifiedBy = modifiedBy;
		this.modifiedDate = modifiedDate;
		this.status = status;
		this.comments = comments;
		this.projectName = projectName;
		this.itemId = itemId;
		this.ahId = ahId;
		this.projectManagersId = projectManagersId;
		this.portfolioId = portfolioId;
		this.accountName = accountName;
		this.portfolioName = portfolioName;
	}
	
	

}
