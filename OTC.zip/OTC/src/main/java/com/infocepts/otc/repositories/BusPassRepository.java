package com.infocepts.otc.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.infocepts.otc.entities.BusPass;

public interface BusPassRepository extends CrudRepository<BusPass,Integer> {
 @Override
public List<BusPass> findAll();

 @Query("select count(rr) from BusPass rr where rr.cardNo = :cardNo and rr.status = 'Active'")
public List<BusPass> findIfCardNoAssigned(@Param(value = "cardNo") Integer cardNo);
}
