package com.infocepts.otc.controllers;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.mail.MessagingException;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.math.NumberUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.infocepts.otc.entities.Account;
import com.infocepts.otc.repositories.AccountRepository;
import com.infocepts.otc.services.TimesheetService;

@RestController
@RequestMapping(value="/account",headers="referer") //JV: Added 'headers' param to validate the url.
public class AccountController {

	final Logger logger = Logger.getLogger(AccountController.class);
	
	@Autowired
	AccountRepository repository;
	
	@PersistenceContext(unitName="otc")
    private EntityManager manager;
	
	@Autowired
	HttpSession session;
	
	@Autowired
	TimesheetService service;
	
	/* As Account creation is owned by CRM account controller will not have add / update / delete account apis */
	/* ------------------------------------------------------------------------------------------------------- */
	@RequestMapping(method=RequestMethod.GET)
	public List<Account> getAccountDetails(@RequestParam(value = "limit", defaultValue = "0") Integer limit,
										   @RequestParam(value = "accountDDL", defaultValue = "false") boolean accountDDL,
										   @RequestParam(value = "accountStatus", defaultValue = "Active") String accountStatus,
										   @RequestParam(value = "uid", defaultValue = "0") Integer uid,
											HttpServletRequest request) {
		List<Account> accountlist = null;
		try{
			/* ------------------------- Authorization start ------------------------------------ */
			// Authorization for admin role
//			if(!service.isAValidAdminRole() && accountDDL) // When accountDDL is true, only restricted account details are fetched which is allowed
//			{
//				service.sendTamperedMail("Accounts View All", 0, 0, request);	
//				return accountlist;
//			}
			/* ------------------------- Authorization ends ------------------------------------ */
			if(0 != limit)
			{
				accountlist = manager.createNamedQuery("getLatestAccounts", Account.class).getResultList();
			}
			else if(accountDDL)//To populate account drop down list
			{	
				if(accountStatus.equals("Active-Prospect")) accountStatus = ""; // Fetch all but dormant accounts
				accountlist = manager.createNamedQuery("getAllAccountsDropDown", Account.class)
							.setParameter("status", accountStatus)
							.getResultList();				
			}else if(uid != 0) {
				accountlist = manager.createNamedQuery("getAccountbyIdforAH", Account.class)
						.setParameter("uid", uid)
						.getResultList();
			}
			else
			{
				accountlist = manager.createNamedQuery("getAllAccounts", Account.class)
							.getResultList();
			}
		}
		catch(Exception e){
			logger.error(e);
		}
	    return accountlist;		
	}

	
	@RequestMapping(value="/{itemId}",method=RequestMethod.GET)
	public Account getAccount(@PathVariable Integer itemId){
		Account account = null;
		try{		
		account = manager.createNamedQuery("getAccountsByItemId", Account.class)
				.setParameter("itemId", itemId)
				.getSingleResult();		

		}catch(Exception e){
			logger.error(e);
		}
		return account;
	}
	
	@GetMapping("/getaccountcount/{userId}")
	public Map<String, Object> getAccountCount(@PathVariable Integer userId) {
		Map<String, Object> countMap = new HashMap<>();
		countMap.putIfAbsent("accountHeadCount", repository.getAccountHeadCountForUser(userId));		
		return countMap;
	}
	
	@GetMapping("/getActiveInternalAccounts") 
	public List<Map<Object, Object>> getActiveInternalAccounts(HttpServletRequest request){
		return repository.getActiveInternalAccounts(manager);
	}
	
	 @GetMapping("/getAccounts")
		public List<Account> getAccounts( @RequestParam(value = "accountStatus", defaultValue = "Active") String accountStatus) {
		 List<Account> accountlist = null;
			try{
				if(accountStatus.equals("Active-Prospect")) accountStatus = ""; // Fetch all but dormant accounts
				accountlist = manager.createNamedQuery("getAllAccountsDropDown", Account.class)
							.setParameter("status", accountStatus)
							.getResultList();	
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return accountlist;

		}
	 @GetMapping("/getAccountsByItemId")
		public Account getAccountsByItemId(@RequestParam(value = "itemId", defaultValue = "0") Integer itemId){
			Account account = null;
			try{		
			account = manager.createNamedQuery("getAccountsByItemId", Account.class)
					.setParameter("itemId", itemId)
					.getSingleResult();		

			}catch(Exception e){
				logger.error(e);
			}
			return account;
		}
}
