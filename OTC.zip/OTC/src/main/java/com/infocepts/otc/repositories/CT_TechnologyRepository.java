/**
* Filename: /src/main/java/com/infocepts/otc/repositories/CT_FunctionalTrainingRepository.java
* @author  VVC
* @version 1.0
* @since   2018-12-03 
*/

package com.infocepts.otc.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import com.infocepts.otc.entities.CT_Technology;

public interface CT_TechnologyRepository extends CrudRepository<CT_Technology,Integer>{

	@Override
	public List<CT_Technology> findAll();
	
}


