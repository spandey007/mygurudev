package com.infocepts.otc.repositories;

import java.util.List;
import java.util.Map;

import org.springframework.data.repository.CrudRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.infocepts.otc.entities.InfoTravelDesk;

public interface InfoTravelDeskRepository extends CrudRepository<InfoTravelDesk,Integer>{

	@Override
	public List<InfoTravelDesk> findAll();	
	
	@Query("from InfoTravelDesk where infoTravelId = :infoTravelId")
	public List<InfoTravelDesk> findById(@Param(value="infoTravelId") Integer infoTravelId);
	
	@Query("FROM InfoTravelDesk trd WHERE trd.infoTravel.infoTravelId=:infoTravelId")
	public List<InfoTravelDesk> getTravelDesk(@Param("infoTravelId") int infoTravelId);
	
	
	@Query("from InfoTravelDesk d where d.parentId = :infoTravelDeskId and d.travelDeskFlag=:travelDeskFlag")
	public List<InfoTravelDesk> findByParentId(@Param(value="infoTravelDeskId") Integer infoTravelDeskId, @Param(value="travelDeskFlag") Integer travelDeskFlag);
}


