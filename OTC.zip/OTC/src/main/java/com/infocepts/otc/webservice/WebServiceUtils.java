/**
 * 
 */
package com.infocepts.otc.webservice;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.util.CollectionUtils;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

/**This class is a utility class for consuming web services and generating web service url with proper 
 * exception handling mechanism.
 * 
 * @author Rewatiraman Chandrol
 *
 */
public abstract class WebServiceUtils extends Object {

	private WebServiceUtils() {}
	
	private static RestTemplate getRestTemplate() {
		RestTemplate restTemplate = new RestTemplate();
		/* Setting WebServiceUtils class as an error handler class so that should any exception occur 
		spring can call hasError() and handleError() method.*/
		restTemplate.setErrorHandler(new WebServiceExceptionHandler());
		return restTemplate;
	}
	
	public static String callWebService(final String webServiceURL) throws Exception {
		return getRestTemplate().getForEntity(webServiceURL, String.class).getBody();
	}
	
	/**
	 * @param webServiceURL - A well formed web service URL.
	 * @param httpMethod - GET, POST, PUT, DELETE etc. Depending upon the requirement.
	 * @param headerMap - Headers to be sent to remote server along with web service URL.
	 * @return - Response received after a successful web service call.
	 * @throws Exception - An Exception will be thrown in case of any client/server side error while making a web service call. 
	 */
	public static String callPreparedWebService(final String webServiceURL, HttpMethod httpMethod, final MultiValueMap<String, String>  headerMap) throws Exception {
		RestTemplate restTemplate = getRestTemplate();
		if (httpMethod == null) {
			httpMethod = HttpMethod.GET;
		}
		
		if (CollectionUtils.isEmpty(headerMap)) {
			return restTemplate.getForObject(webServiceURL, String.class);
		} else {
			return restTemplate.exchange(webServiceURL, httpMethod, new HttpEntity<>(headerMap), String.class).getBody();
		}
	}
	
	/**
	 * @param baseURL - Base URL with only host name, port number etc.
	 * @param urlParamMap - Query parameters to be appended in the base URL
	 * @return - Well formed constructed URL from the given base URL and query parameters
	 * @throws Exception - An Exception will be thrown if something goes wrong while constructing the URL.
	 */
	public static String buildWebServiceURL(final String baseURL, final MultiValueMap<String, String> urlParamMap) throws Exception {
		UriComponentsBuilder uriCompBuilder = UriComponentsBuilder.fromHttpUrl(baseURL);
		uriCompBuilder.queryParams(urlParamMap);
		return uriCompBuilder.toUriString();
	}
}
