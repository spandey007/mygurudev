/**
 * 
 */
package com.infocepts.otc.utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.DataFormat;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.VerticalAlignment;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.ss.util.DateFormatConverter;
import org.springframework.web.multipart.MultipartFile;

import com.infocepts.otc.entities.Expense;
import com.infocepts.otc.entities.ExpenseDetail;

/**
 * Utility class for handling file upload/download
 * for expense attachments.
 * 
 * @author Rewatiraman Singh
 *
 */
public abstract class AbstractExpenseFileHandling extends Object {
	
	private static final String UPLOAD_DIRECTORY = "usr/home/Download/%s/%s";
	private static final String D_DRIVE = "D:";
	private static final String PATH_TO_EXCEL_TEMPLATE = "/templates/expense/expenseExport.xlsx";
	private static final Logger LOGGER = Logger.getLogger(AbstractExpenseFileHandling.class.getName());

	public static synchronized File upload(MultipartFile multipartFile, String moduleName, String storageFolder) {
		String rootPath = "";
		String absolutePath = "";
		boolean isUploaded = false;
		Path newFilePath = null;
		try {
			StringBuilder hostName = new StringBuilder(InetAddress.getLocalHost().getHostName());
			Iterator<Path> iterator = Paths.get("").getFileSystem().getRootDirectories().iterator();
			/* For production server, Save the file in C drive where rest of the uploaded file reside.
			 * Else store the files in D directory if the host happen to be a localhost or dev, stage environment.
			*/
			if ("infobiz-fe1".equals(hostName.toString())) {
				rootPath = iterator.next().toString();
			} else {
				while(iterator.hasNext()) {
					String rootDrive = iterator.next().toString();
					if (rootDrive.contains(D_DRIVE)) {
						rootPath = rootDrive;
						break;
					}
				}
			}
			
			absolutePath = rootPath + String.format(UPLOAD_DIRECTORY, moduleName, storageFolder);
			Files.createDirectories(Paths.get(absolutePath));
			newFilePath = Paths.get(absolutePath + "/" + multipartFile.getOriginalFilename());
			if (!new File(absolutePath + "/" + multipartFile.getOriginalFilename()).exists()) {
				Files.createFile(newFilePath);
			}
			Files.write(newFilePath, multipartFile.getBytes(), StandardOpenOption.WRITE);
			isUploaded = true;
			LOGGER.info("FILE UPLOADED: " + newFilePath.toString());
		} catch (UnknownHostException e) {
			LOGGER.log(Level.SEVERE, "UNABLE TO IDENTIFY THE HOST NAME OF CURRENT SERVER ENVIRONMENT!", e);
		} catch (IOException e) {
			LOGGER.log(Level.SEVERE, "ERROR WHILE CREATING DIRECTORIES AT: " + absolutePath, e);
		}
		
		return isUploaded ? newFilePath.toFile() : null;
	}
	
	/**
	 * @param fileList
	 * @param zipFileName
	 * @return
	 */
	public static synchronized File zipFiles(List<String> fileList, String zipFileName) {
		File tempFile = null;
		try {
			Path tempPath = Files.createTempFile(zipFileName,".zip");
			tempFile = tempPath.toFile();
			FileOutputStream fos = new FileOutputStream(tempFile);
			ZipOutputStream zipOut = new ZipOutputStream(fos);
			for (String srcFile : fileList) {
				File fileToZip = new File(srcFile);
				FileInputStream fis = new FileInputStream(fileToZip);
				ZipEntry zipEntry = new ZipEntry(fileToZip.getName());
				zipOut.putNextEntry(zipEntry);
				
				byte[] bytes = new byte[1024];
				int length;
				while((length = fis.read(bytes)) >= 0) {
					zipOut.write(bytes, 0, length);
				}
				zipOut.closeEntry();
				fis.close();
			}
			zipOut.close();
			fos.close();
			LOGGER.info("FILE ZIPPED : " + tempFile.toString());
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, "ERROR WHILE ZIPPING : " + fileList.toString(), e);
		}
		return tempFile;
	}
	
	
	/**
	 * @param expense - For which the data needs to be exported.
	 * @return Excel file after the data is written into the excel.
	 */
	public static synchronized File exportExpenseToExcel(Expense expense, List<ExpenseDetail> expenseDetailList, String fileNameWithExtension) {
		File file = null;
		if (CollectionUtils.isNotEmpty(expenseDetailList)) {
			InputStream inputStream = AbstractExpenseFileHandling.class.getResourceAsStream(PATH_TO_EXCEL_TEMPLATE);
			Path tempPath = null;
			try {
				/* Creating a temporary file which will be a duplicate of the original template
				so that we get to edit the fresh Template always.
				*/
				tempPath = Files.createTempFile("expenseExport1", ".xlsx");
				Files.copy(inputStream, tempPath, StandardCopyOption.REPLACE_EXISTING);
			} catch (Exception e1) {
				LOGGER.log(Level.SEVERE, "Something went wrong while copying the template excel to temporary excel.", e1);
			}
			try(Workbook workbook = WorkbookFactory.create(tempPath.toFile())) {
				Sheet sheet = workbook.getSheetAt(0);
				Iterator<Row> rowIterator = sheet.rowIterator();
				DataFormat dateFormat = workbook.createDataFormat();
				String dateFormatString = DateFormatConverter.convert(Locale.getDefault(), "dd MMM, yyyy");
				short dateFormatCode = dateFormat.getFormat(dateFormatString);
				CellStyle dateStyle = workbook.createCellStyle();
				dateStyle.setAlignment(HorizontalAlignment.CENTER);
				dateStyle.setVerticalAlignment(VerticalAlignment.CENTER);
				dateStyle.setDataFormat(dateFormatCode);
				dateStyle.setBorderBottom(BorderStyle.THIN);
				
				while(rowIterator.hasNext()) {
					Row row = rowIterator.next();
					int rowNum = row.getRowNum();
					if (rowNum == 1) {
						row.getCell(1).setCellValue(expense.getEmpId());
						row.getCell(5).setCellValue(expense.getResourceName());
						continue;
					}
					if (rowNum == 2) {
						row.getCell(1).setCellValue(expense.getDesignation());
						row.getCell(5).setCellValue(expense.getProjectTitle());
						continue;
					}
					if (rowNum == 3) {
						Cell cell1 = row.getCell(1);
						Cell cell5 = row.getCell(5);
						
						cell1.setCellValue(expense.getStartDate());
						cell5.setCellValue(expense.getEndDate());
						
						cell1.setCellStyle(dateStyle);
						cell5.setCellStyle(dateStyle);
						continue;
					}
					if (rowNum == 4) {
						Cell cell1 = row.getCell(1);
						cell1.setCellValue(expense.getDateOfSubmission());
						cell1.setCellStyle(dateStyle);
						
						Cell cell5 = row.getCell(5);
						cell5.setCellValue(expense.getComments());
						continue;
					}
					if (rowNum == 5) {
						Cell cell1 = row.getCell(1);
						// Making the font weight as bold here.
						CellStyle cellStyle = workbook.createCellStyle();
						Font font = workbook.createFont();
						font.setBold(true);
						cellStyle.setFont(font);
						cellStyle.setAlignment(HorizontalAlignment.CENTER);
						cellStyle.setVerticalAlignment(VerticalAlignment.CENTER);
						cellStyle.setBorderBottom(BorderStyle.THIN);
						
						Integer reimburseType = expense.getReimburseType();
						if (reimburseType != null && reimburseType == LoadConstant.EXPENSE_REIMBURSEMENT_BILLABLE_TO_CLIENT) {
							cell1.setCellValue("Billable to client");
							cell1.setCellStyle(cellStyle);
						} else if (reimburseType != null && reimburseType == LoadConstant.EXPENSE_REIMBURSEMENT_NON_BILLABLE_TO_CLIENT) {
							cell1.setCellValue("Non-Billable to client");
							cell1.setCellStyle(cellStyle);
						}
						row.getCell(5).setCellValue(expense.getCurrencyCode() + " " + expense.getTotalAmount());
						continue;
					}
					if (rowNum == 7) {
						int rowIndex = 7;
						CellStyle cellStyle = workbook.createCellStyle();
						cellStyle.setAlignment(HorizontalAlignment.CENTER);
						cellStyle.setVerticalAlignment(VerticalAlignment.CENTER);
						// Setting the border bottom as none for child rows as there is already a bottom border present in the cells.
						dateStyle.setBorderBottom(BorderStyle.NONE);
						for (ExpenseDetail expDetail : expenseDetailList) {
							Row newRow = sheet.createRow(++ rowIndex);
							newRow.setHeight((short)400);
							newRow.setRowStyle(cellStyle);

							Cell cell1 = newRow.createCell(0);
							cell1.setCellStyle(cellStyle);

							Cell cell2 = newRow.createCell(1);
							cell2.setCellStyle(cellStyle);

							Cell cell3 = newRow.createCell(2);
							cell3.setCellStyle(cellStyle);

							Cell cell4 = newRow.createCell(3);
							cell4.setCellStyle(cellStyle);

							Cell cell5 = newRow.createCell(4);
							cell5.setCellStyle(cellStyle);

							Cell cell6 = newRow.createCell(5);
							cell6.setCellStyle(cellStyle);

							Cell cell7 = newRow.createCell(6);
							cell7.setCellStyle(cellStyle);

							Cell cell8 = newRow.createCell(7);
							cell8.setCellStyle(cellStyle);

							Cell cell9 = newRow.createCell(8);
							cell9.setCellStyle(cellStyle);

							Cell cell10 = newRow.createCell(9);
							cell10.setCellStyle(cellStyle);

							Cell cell11 = newRow.createCell(10);
							cell11.setCellStyle(cellStyle);

							/* Setting date format for expense detail start and end date explicitly so that
							unnecessarily bottom border is not added.
							 */
							CellStyle style = workbook.createCellStyle();
							style.setAlignment(HorizontalAlignment.CENTER);
							style.setVerticalAlignment(VerticalAlignment.CENTER);
							style.setDataFormat(dateFormatCode);

							cell1.setCellValue(expenseDetailList.indexOf(expDetail) + 1);
							cell2.setCellValue(expDetail.getStartDate());
							cell2.setCellStyle(style);

							cell3.setCellValue(expDetail.getEndDate());
							cell3.setCellStyle(style);

							cell4.setCellValue(expDetail.getPurposeName());
							cell5.setCellValue(expDetail.getCategoryName());
							cell6.setCellValue(expDetail.getCurrencyCode());
							cell7.setCellValue(expDetail.getAmount());
							cell8.setCellValue(expDetail.getConvertedAmount());
							cell9.setCellValue(expDetail.getPmComments());
							cell10.setCellValue(expDetail.getTdComments());
							cell11.setCellValue(expDetail.getFaComments());
							dateStyle.setBorderBottom(BorderStyle.THIN);
						}
					}
				}
				try(FileOutputStream outputStream = new FileOutputStream(fileNameWithExtension)) {
					workbook.write(outputStream);
					file = new File(fileNameWithExtension);
				}
			} catch (Exception e) {
				LOGGER.log(Level.SEVERE, "Something went wrong while wrting excel file!", e);
			}
		}
		return file;
	}
}
