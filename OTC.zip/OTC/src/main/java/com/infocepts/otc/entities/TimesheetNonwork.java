package com.infocepts.otc.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.infocepts.otc.utilities.LoadConstant;

@Entity
@Table(catalog=LoadConstant.otc,schema="[dbo]",name="tsnonwork")
public class TimesheetNonwork {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Integer tsnonworkId;
	private String taskName;	
	private Boolean isEnabled;
	
	public Integer getTsnonworkId() {
		return tsnonworkId;
	}
	public void setTsnonworkId(Integer tsnonworkId) {
		this.tsnonworkId = tsnonworkId;
	}
	public String getTaskName() {
		return taskName;
	}
	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}
	
	public Boolean getIsEnabled() {
		return isEnabled;
	}
	public void setIsEnabled(Boolean isEnabled) {
		this.isEnabled = isEnabled;
	}
	
}
