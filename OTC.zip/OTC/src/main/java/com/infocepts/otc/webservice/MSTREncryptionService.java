package com.infocepts.otc.webservice;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

	/**
	 * @author Joselin Varghese:
	 */
	/**
	 * MSTRConnectService Client Service Class
	 */
	@Component
	public class MSTREncryptionService {
	
	public static String callMSTRService(String mstruser, String ldapuser, String url)
										throws Exception{
		final Logger logger = Logger.getLogger(MSTREncryptionService.class.getName());							
		String mstresponse = null;
		try{
		RestTemplate resttemplate = new RestTemplate();
		
		ResponseEntity<String> response = resttemplate.getForEntity(url
														+"mstrUserName="+mstruser+"&"
														+"ldapUserName="+ldapuser,
														String.class);
		logger.info("response");logger.info(response.toString());
		System.out.println("response");System.out.println(response);
		
		Pattern pattern2 = Pattern.compile("(?<=<res>).*.(?=([^\n]*\n+)</res>)");
		Matcher matcher2 = pattern2.matcher(String.valueOf(response));
		logger.info("matcher2="+matcher2);
		
		System.out.println("matcher2");System.out.println(matcher2);
		
		while (matcher2.find()){
			mstresponse = String.valueOf(matcher2.group());
			
			logger.info("mstresponse="+mstresponse);
			System.out.println("mstresponse");System.out.println(mstresponse);
		}
		}catch(Exception e){
			logger.log(Level.SEVERE, "exceptn msg", e);
		}
		return mstresponse;	
	}
}
