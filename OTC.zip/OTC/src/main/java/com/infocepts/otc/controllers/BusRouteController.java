package com.infocepts.otc.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.infocepts.otc.entities.BusPass;
import com.infocepts.otc.entities.BusRoute;
import com.infocepts.otc.repositories.BusRouteRepository;
import com.infocepts.otc.services.TimesheetService;

@RestController
@RequestMapping(value="/busroute",headers="referer")
public class BusRouteController {
	@Autowired
	BusRouteRepository busRouteRepository;
	
	@Autowired
	TimesheetService service;
	
	@RequestMapping(method=RequestMethod.POST)
	public BusRoute addBusRoute(@RequestBody BusRoute busRoute){
		busRoute.setBusRouteId(null);
		Boolean isAValidCall = false;
		if(service.isTravel())
		{
			isAValidCall = true;
		}
		if(isAValidCall) {
			
			busRouteRepository.save(busRoute);
		}
		return busRoute;
	}
	
	@RequestMapping(method=RequestMethod.GET)
	public List<BusRoute> getBusRoute(){
		List<BusRoute> list = null;
		Boolean isAValidCall = false;
		if(service.isTravel())
		{
			isAValidCall = true;
		}
		//if(isAValidCall) {
			list = busRouteRepository.findAll();
		//}
		return list;
	}
	
	@RequestMapping(value="/{busRouteId}",method=RequestMethod.GET)
	public BusRoute getBusRoute(@PathVariable Integer busRouteId){
		BusRoute busRoute = null;
		Boolean isAValidCall = false;
		if(service.isTravel())
		{
			isAValidCall = true;
		}
		if(isAValidCall) {
			
			busRoute = busRouteRepository.findOne(busRouteId);
		}
		return busRoute;
	}
	
	@RequestMapping(value="/{busRouteId}", method=RequestMethod.PUT)
	public BusRoute updateBusRoute(@PathVariable Integer busRouteId,  @RequestBody BusRoute updatedBusRoute){
		updatedBusRoute.setBusRouteId(busRouteId);
		Boolean isAValidCall = false;
		if(service.isTravel())
		{
			isAValidCall = true;
		}
		if(isAValidCall) {
		busRouteRepository.save(updatedBusRoute);
		}
		return updatedBusRoute;
	}
	
	@RequestMapping(value="/{busRouteId}",method=RequestMethod.DELETE)
	public void deleteBusRoute(@PathVariable Integer busRouteId){
		Boolean isAValidCall = false;
		if(service.isTravel())
		{
			isAValidCall = true;
		}
		if(isAValidCall) {
		busRouteRepository.delete(busRouteId);
		}
	}
}
