package com.infocepts.otc.controllers;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.infocepts.otc.entities.AssociateCertifications;
import com.infocepts.otc.entities.AssociateSkills;
import com.infocepts.otc.repositories.AssociateCertificationsRepository;


@RestController
@RequestMapping("/associateCertifications")
public class AssociateCertificationsController {

	final Logger logger = Logger.getLogger(AssociateCertificationsController.class);

	@Autowired
	AssociateCertificationsRepository repository;
	
	@PersistenceContext(unitName="otc")
    private EntityManager manager;
	
	@RequestMapping(method=RequestMethod.POST)
	public AssociateCertifications saveAssociateCertifications(@RequestBody AssociateCertifications associateCertifications){
		try{
				associateCertifications.setAssociateCertificationsId(null);
				repository.save(associateCertifications);
		}
		catch(Exception e){
			logger.error(e);
		}
		return associateCertifications;
	}
	
	@RequestMapping(method=RequestMethod.GET)
	public List<AssociateCertifications> getAssociateCertifications(@RequestParam(value = "uid", defaultValue = "0") Integer uid){
		List<AssociateCertifications> associateCertificationsList=null;
		try
		{
			if(uid!=0){
				associateCertificationsList = repository.findByUid(uid);
			}
			else
			{
				associateCertificationsList = manager.createNamedQuery("getCertificationsList_Associates",AssociateCertifications.class)
						  .getResultList();
			}
		}
		catch(Exception e){
			logger.error(e);
		}
		return associateCertificationsList;
	}
	
	@RequestMapping(value="/{associateCertificationsId}",method=RequestMethod.PUT)
	public void updateAssociateCertifications(@PathVariable Integer associateCertificationsId,@RequestBody AssociateCertifications updatedassociateCertifications){
		try{
				updatedassociateCertifications.setAssociateCertificationsId(associateCertificationsId);
				repository.save(updatedassociateCertifications);
		}
		catch(Exception e){
			logger.error(e);
		}
	}
	
	@RequestMapping(value="/{associateCertificationsId}",method=RequestMethod.DELETE)
	public void deleteAssociateCertifications(@PathVariable Integer associateCertificationsId){
			try{
					repository.delete(associateCertificationsId);
			}
			catch(Exception e){
				logger.error(e);
			}
	}
}
