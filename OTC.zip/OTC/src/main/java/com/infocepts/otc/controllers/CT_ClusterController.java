package com.infocepts.otc.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.infocepts.otc.entities.CT_Cluster;
import com.infocepts.otc.repositories.CT_ClusterRepository;
import com.infocepts.otc.services.TimesheetService;

@RestController
@RequestMapping(value="/cluster",headers="referer")
public class CT_ClusterController {
	@Autowired
	CT_ClusterRepository clusterRepository;
	
	@Autowired
	TimesheetService service;
	
	@RequestMapping(method=RequestMethod.POST)
	public CT_Cluster addCluster(@RequestBody CT_Cluster cluster){
		cluster.setClusterId(null);
		Boolean isAValidCall = false;
		if(service.isHR() || service.isAdmin())
		{
			isAValidCall = true;
		}
		if(isAValidCall) {
			
			clusterRepository.save(cluster);
		}
		return cluster;
	}
	
	@RequestMapping(method=RequestMethod.GET)
	public List<CT_Cluster> getCluster(){
		List<CT_Cluster> list = null;
		Boolean isAValidCall = false;
		if(service.isHR() || service.isAdmin())
		{
			isAValidCall = true;
		}
		//if(isAValidCall) {
			list = clusterRepository.findAll();
		//}
		return list;
	}
	
	@RequestMapping(value="/{clusterId}",method=RequestMethod.GET)
	public CT_Cluster getCluster(@PathVariable Integer clusterId){
		CT_Cluster cluster = null;
		Boolean isAValidCall = false;
		if(service.isHR() || service.isAdmin())
		{
			isAValidCall = true;
		}
		if(isAValidCall) {
			
			cluster = clusterRepository.findOne(clusterId);
		}
		return cluster;
	}
	
	@RequestMapping(value="/{clusterId}", method=RequestMethod.PUT)
	public CT_Cluster updateCluster(@PathVariable Integer clusterId,  @RequestBody CT_Cluster updatedCluster){
		updatedCluster.setClusterId(clusterId);
		Boolean isAValidCall = false;
		if(service.isHR() || service.isAdmin())
		{
			isAValidCall = true;
		}
		if(isAValidCall) {
		clusterRepository.save(updatedCluster);
		}
		return updatedCluster;
	}
	
	@RequestMapping(value="/{clusterId}",method=RequestMethod.DELETE)
	public void deleteCluster(@PathVariable Integer clusterId){
		Boolean isAValidCall = false;
		if(service.isHR() || service.isAdmin())
		{
			isAValidCall = true;
		}
		if(isAValidCall) {
		clusterRepository.delete(clusterId);
		}
	}
}
