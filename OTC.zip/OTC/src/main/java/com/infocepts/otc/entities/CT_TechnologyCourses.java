package com.infocepts.otc.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.infocepts.otc.utilities.LoadConstant;

@Entity
@Table(catalog=LoadConstant.otc, schema="[dbo]",name="ct_technologyCourses")
public class CT_TechnologyCourses {

	// Entity Columns
    // --------------------------------------------------------------------------------
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Integer technologyCourseId;
    private String techCourseCode;
    private String courseName;
    
    @Lob
    private String preRequisites;
    
	public Integer getTechnologyCourseId() {
		return technologyCourseId;
	}
	public void setTechnologyCourseId(Integer technologyCourseId) {
		this.technologyCourseId = technologyCourseId;
	}
	public String getTechCourseCode() {
		return techCourseCode;
	}
	public void setTechCourseCode(String techCourseCode) {
		this.techCourseCode = techCourseCode;
	}
	public String getCourseName() {
		return courseName;
	}
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	public String getPreRequisites() {
		return preRequisites;
	}
	public void setPreRequisites(String preRequisites) {
		this.preRequisites = preRequisites;
	}
	
}
