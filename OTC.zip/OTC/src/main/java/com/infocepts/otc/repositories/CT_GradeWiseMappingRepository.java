/**
* Filename: /src/main/java/com/infocepts/otc/repositories/CT_GradeWiseMappingRepository.java
* @author  VVC
* @version 1.0
* @since   2018-12-03 
*/

package com.infocepts.otc.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import com.infocepts.otc.entities.CT_GradeWiseMapping;

public interface CT_GradeWiseMappingRepository extends CrudRepository<CT_GradeWiseMapping,Integer>{

	@Override
	public List<CT_GradeWiseMapping> findAll();
	
}


