/**
* Filename: /src/main/java/com/infocepts/otc/controllers/ViewController.java
* --------------------------------------------------------------------------
* Sr.No	 Author	      Version	Modified Date	Description
 ---------------------------------------------------------------------------
  1.    | IS Team   | 1.0     |  01-01-2017   |  Intial Version 
  2.    | Joselin V | 1.1     |  10-04-2019   |  Added Exchange Rate Master Link 
  --------------------------------------------------------------------------
*/

package com.infocepts.otc.controllers;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.infocepts.otc.entities.PermissionsUrls;
import com.infocepts.otc.repositories.PermissionsUrlsRepository;


@Controller // this controller will return view
public class ViewController {
	
	final Logger logger = Logger.getLogger(ViewController.class);
	
	/* view controller for the help pages */
	/* --------------------------------------------------------------------------------------- */
	@RequestMapping("/help/timesheet")
	public String helpTs()
	{
		return "help/timesheet";
	}
	
	/* view controller for the resources */
	/* --------------------------------------------------------------------------------------- */
	@RequestMapping("/resource/list")
	public String listResource()
	{
		return "amg/resource/list";
	}
	
	@RequestMapping("/staff-directory")
	public String listStaffDirectory()
	{
		return "amg/resource/staff-directory";
	}
	
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/gtp/list')")
	@RequestMapping("/gtp/list")
	public String listGtp()
	{
		return "amg/gtp/list";
	}
	
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/gtp/edit')")
	@RequestMapping("/gtp/edit")
	public String editGtp()
	{
		return "amg/gtp/edit";
	}
	
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/associate-bucket/list')")
	@RequestMapping("/associate-bucket/list")
	public String listAssociateBuckets()
	{
		return "amg/resource/list";
	}

    @RequestMapping("/resource/updateNewAssociateInfo")
    public String updateNewAssociateInfo() {
        return "amg/resource/updateNewAssociateInfo";
    }

	@RequestMapping("/resource/add")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/resource/add')")
	public String addResource()
	{
		return "amg/resource/add";
	}
	
	@RequestMapping("/resource/edit")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/resource/edit')")
	public String editResource()
	{
		return "amg/resource/add";
	}
	
	@RequestMapping("/user")
	public String viewMyProfile()
	{
		return "amg/resource/view";
	}
	@RequestMapping("/user/{id}")
	public String viewResource()
	{
		return "amg/resource/view";
	}
	@RequestMapping("/user/my-projects")
	public String viewMyProjects()
	{
		return "pmo/project/my-projects";
	}
	@RequestMapping("/user/my-tasks")
	public String viewMyTasks()
	{
		return "pmo/project/my-tasks";
	}


	@RequestMapping("/user/initiation")
    public String projectInitiation() {
		return "pmo/project/initiation";
	}
	@RequestMapping("/project/add")
    @PreAuthorize(value = "@securityService.userHasPermissionForURL('/project/add')")
    public String projectCreate() {
		return "pmo/project/initiation";
	}
	@RequestMapping("/project/edit")
    public String projectUpdate() {
		return "pmo/project/initiation";
	}
	@RequestMapping("/exitform/add")
    public String exitFormCreate() {
		return "hr/exitForm/add";
	}
	@RequestMapping("/exitform/edit")
    public String exitFormUpdate() {
		return "hr/exitForm/add";
	}
	@RequestMapping("/exitAccess/list")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/exitAccess/list')")	
    public String exitAccessList() {
		return "hr/exitForm/access";
	}
	@RequestMapping("/project/initiation")
    public String myProjectRequests() {
		return "pmo/project/initiation-list";
	}



	@RequestMapping("/user/my-allocations")
	public String viewMyAllocations()
	{
		return "pmo/project/my-allocations";
	}
	
	
	/* view controller for the left sidebar menu */
	/* --------------------------------------------------------------------------------------- */
	@RequestMapping("/layouts/left-sidebar-menu")
	public String left_sidebar_menu()
	{
		return "layouts/left-sidebar-menu";
	}
	
	/* view controller for the sow */
	/* --------------------------------------------------------------------------------------- */
	@RequestMapping("/sow/list")
	public String sow_list()
	{
		return "pmo/sow/list";
	}
	@RequestMapping("/sow/add")
	public String sow_add()
	{
		return "pmo/sow/add";
	}
	@RequestMapping("/sow/edit")
	public String sow_edit()
	{
		return "pmo/sow/add";
	}
	@RequestMapping("/isow/add")
	public String isow_add()
	{
		return "pmo/isow/add";
	}
	@RequestMapping("/isow/edit")
	public String isow_edit()
	{
		return "pmo/isow/add";
	}
	@RequestMapping("/isow/list")
	@PreAuthorize(value = "@securityService.userHasPermissionForURL('/isow/list')")
	public String isow_list()
	{
		return "pmo/isow/list";
	}
	@RequestMapping("/sow/sow-revenue")
	public String sow_revenue()
	{
		return "pmo/sow/sow-revenue";
	}
	
	@RequestMapping("/project/generic-tabs")
	public String generic_tabs()
	{
		return "pmo/project/generic-tabs";
	}
	
	@RequestMapping("/project/action-tabs")
	public String action_tabs()
	{
		return "pmo/project/action-tabs";
	}
	
	@RequestMapping("/amg/account/associate-generic-tabs")
	public String account_tabs()
	{
		return "amg/account/associate-generic-tabs";
	}
	
	@RequestMapping("/utility/close-msgbox")
	public String msgbox()
	{
		return "utility/close-msgbox";
	}
	
	
	@RequestMapping("/pmo/dashboard")
	@PreAuthorize(value = "@securityService.userHasPermissionForURL('/pmo/dashboard')")
	public String sow_dashboard()
	{
		return "pmo/dashboard";
	}
	@RequestMapping("/sow/latest")
	public String sow_latest()
	{
		return "pmo/sow/latest";
	}
	
	/* view controller for the accounts */
	/* --------------------------------------------------------------------------------------- */
	@RequestMapping("/reports/revenue-dashboard")
	@PreAuthorize(value = "@securityService.userHasPermissionForURL('/reports/revenue-dashboard')")
	public String reports_revenue_dashboard()
	{
		return "reports/monthly-revenue-by-account";
	}
	
	@RequestMapping("/reports/budgeted-vs-revenue-in-hand")
	@PreAuthorize(value = "@securityService.userHasPermissionForURL('/reports/budgeted-vs-revenue-in-hand')")
	public String reports_revenue_budgeted_vs_revenue_in_hand()
	{
		return "reports/monthly-revenue-by-account";
	}
	
	@RequestMapping("/reports/monthly-revenue-by-account")
	@PreAuthorize(value = "@securityService.userHasPermissionForURL('/reports/monthly-revenue-by-account')")
	public String reports_monthly_revenue_by_account()
	{
		return "reports/monthly-revenue-by-account";
	}
	
	@RequestMapping("/reports/revenue-projection")
	public String revenue_projection()
	{
		return "reports/revenue-projection";
	}
	
	@RequestMapping("/reports/monthly-revenue-by-project")	
	@PreAuthorize(value = "@securityService.userHasPermissionForURL('/reports/monthly-revenue-by-project')")
	public String reports_monthly_revenue_by_project()
	{
		return "reports/monthly-revenue-by-account";
	}
	@RequestMapping("/reports/monthly-revenue-by-sow")	
	@PreAuthorize(value = "@securityService.userHasPermissionForURL('/reports/monthly-revenue-by-sow')")
	public String reports_monthly_revenue_by_sow()
	{
		return "reports/monthly-revenue-by-account";
	}
	@RequestMapping("/reports/monthly-revenue-projection")	
	@PreAuthorize(value = "@securityService.userHasPermissionForURL('/reports/monthly-revenue-projection')")
	public String reports_monthly_revenue_projection()
	{
		return "reports/monthly-revenue-by-account";
	}
	
	@RequestMapping("/reports/monthly-revenue-by-project-nwd")	
	@PreAuthorize(value = "@securityService.userHasPermissionForURL('/reports/monthly-revenue-by-project-nwd')")
	public String reports_monthly_revenue_by_project_nwd()
	{
		return "reports/monthly-revenue-by-account";
	}
	@RequestMapping("/reports/monthly-revenue-by-account-nwd")	
	@PreAuthorize(value = "@securityService.userHasPermissionForURL('/reports/monthly-revenue-by-account-nwd')")
	public String reports_monthly_revenue_by_account_nwd()
	{
		return "reports/monthly-revenue-by-account";
	}
	@RequestMapping("/reports/monthly-revenue-by-sow-nwd")	
	@PreAuthorize(value = "@securityService.userHasPermissionForURL('/reports/monthly-revenue-by-sow-nwd')")
	public String reports_monthly_revenue_by_sow_nwd()
	{
		return "reports/monthly-revenue-by-account";
	}
	@RequestMapping("/reports/monthly-revenue-projection-nwd")	
	@PreAuthorize(value = "@securityService.userHasPermissionForURL('/reports/monthly-revenue-projection-nwd')")
	public String reports_monthly_revenue_projection_nwd()
	{
		return "reports/monthly-revenue-by-account";
	}
	
	@RequestMapping("/revenueprojection")
	public String revenue_planning_pm()
	{
		return "pm/revenueprojection";
	}
	/*@RequestMapping("/revenue-planning/by-ah")
	public String revenue_planning_ah()
	{
		return "pm/revenue-planning/by-pm";
	}
	@RequestMapping("/revenue-planning/by-ph")
	public String revenue_planning_ph()
	{
		return "pm/revenue-planning/by-pm";
	}*/
	
	/* view controller for the accounts */
	/* --------------------------------------------------------------------------------------- */
	@RequestMapping("/account/list")	
	public String account_list()
	{
		return "pmo/account/list";
	}
	@RequestMapping("/account/view")	
	public String account_view()
	{
		return "pmo/account/view";
	}
	
	@RequestMapping("/account/latest")
	public String account_latest()
	{
		return "pmo/account/latest";
	}
	
	@RequestMapping("/accountInfo/list")
	@PreAuthorize(value = "@securityService.userHasPermissionForURL('/accountInfo/list')")
	public String accountinfo_list()
	{
		return "amg/accountInfo/list";
	}
	
	@RequestMapping("/accountInfo/add")
	@PreAuthorize(value = "@securityService.userHasPermissionForURL('/accountInfo/add')")
	public String accountinfo_add()
	{
		return "amg/accountInfo/add";
	}
	
	@RequestMapping("/accountInfo/edit")
	@PreAuthorize(value = "@securityService.userHasPermissionForURL('/accountInfo/edit')")
	public String accountinfo_edit()
	{
		return "amg/accountInfo/add";
	}
	/* view controller for the projects */
	/* --------------------------------------------------------------------------------------- */
	@RequestMapping("/project/list")	
	public String project_list()
	{
		return "pmo/project/list";
	}
	
	@RequestMapping("/project/view")	
	public String project_view()
	{
		return "pmo/project/view";
	}

    @RequestMapping("/project/plan")
    public String project_plan() {
        return "pmo/project/plan";
    }
	
	@RequestMapping("/project/latest")
	public String project_latest()
	{
		return "pmo/project/latest";
	}
	
	@RequestMapping("/amg/associate-buckets")
	public String associate_buckets()
	{
		return "amg/buckets/associate-buckets";
	}
	
	@RequestMapping("/project/projects-by-account")
	public String projects_by_account()
	{
		return "pmo/project/projects-by-account";
	}
	@RequestMapping("/project/my-portfolio")
	public String my_portfolio()
	{
		return "pmo/project/my-portfolio";
	}
	@RequestMapping("/project/projects-by-pm")
	public String projects_by_pm()
	{
		return "pmo/project/projects-by-pm";
	}
	@RequestMapping("/project/projects-as-ah")
	public String projects_as_ah()
	{
		return "pmo/project/projects-as-ah";
	}
	@RequestMapping("/project/projects-as-cep")
	public String projects_as_cep()
	{
		return "pmo/project/projects-as-cep";
	}
	/* view controller for the allocation */
	/* --------------------------------------------------------------------------------------- */
	@RequestMapping("/allocation/list")
	public String allocation_list()
	{
		return "amg/allocation/list";
	}
		
	@RequestMapping("/amg/dashboard")
	@PreAuthorize(value = "@securityService.userHasPermissionForURL('/amg/dashboard')")
	public String allocation_dashboard()
	{
		return "amg/dashboard";
	}
	@RequestMapping("/allocation/latest")
	public String allocation_latest()
	{
		return "amg/allocation/latest";
	}
	
	@RequestMapping("/allocation/soft-allocation")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/allocation/soft-allocation')")
	public String amg_soft_allocation()
	{
		return "amg/allocation/list";
	}
	

	@RequestMapping("/masters/month")
	public String mastersMonth()
	{
		return "masters/month";
	}
	
	/***********************buspass module******************************************/
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/travel/worklocation/list')")
	@RequestMapping("/travel/worklocation/list")
	public String mastersWorkLocation()
	{
		return "travel/worklocation/list";
	}
	
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/worklocation/add')")
	@RequestMapping("/worklocation/add")
	public String mastersWorkLocationAdd()
	{
		return "travel/worklocation/add";
	}
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/travel/busroute/list')")
	@RequestMapping("/travel/busroute/list")
	public String mastersBusRoute()
	{
		return "travel/busroute/list";
	}
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/busroute/add')")
	@RequestMapping("/busroute/add")
	public String mastersBusRouteAdd()
	{
		return "travel/busroute/add";
	}
	
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/travel/busroutetimings/list')")
	@RequestMapping("/travel/busroutetimings/list")
	public String mastersBusRouteTimings()
	{
		return "travel/busroutetimings/list";
	}
	
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/busroutetimings/add')")
	@RequestMapping("/busroutetimings/add")
	public String mastersBusRouteTimingsAdd()
	{
		return "travel/busroutetimings/add";
	}
	
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/travel/busnodalpoint/list')")
	@RequestMapping("/travel/busnodalpoint/list")
	public String mastersBusNodalPoint()
	{
		return "travel/busnodalpoint/list";
	}
	
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/busnodalpoint/add')")
	@RequestMapping("/busnodalpoint/add")
	public String mastersBusNodalPointAdd()
	{
		return "travel/busnodalpoint/add";
	}
	
	@RequestMapping("/travel/buspass/list")
	public String mastersBusPassList()
	{
		return "travel/buspass/list";
	}
	
	@RequestMapping("/travel/buspass/all-list")
	public String mastersBusPassAllList()
	{
		return "travel/buspass/all-list";
	}
	
	@RequestMapping("/buspass/add")
	public String mastersBusPassAdd()
	{
		return "travel/buspass/add";
	}
	
	@RequestMapping("/buspass/edit")
	public String mastersBusPassEdit()
	{
		return "travel/buspass/add";
	}
	
	@RequestMapping("/buspass/generic-tabs")
	public String mastersBusPassTabs()
	{
		return "travel/buspass/generic-tabs";
	}
	
	
	
	
	/* Action 1: Add below functions for view controller for the <moduleName> */
	/* --------------------------------------------------------------------------------------- */
	
	@RequestMapping("/travel/infocab/list")
	public String mastersInfoCabList()
	{
		return "travel/infocab/list";
	}
	
	@RequestMapping("/travel/infocab/all-list")
	public String mastersInfoCabAllList()
	{
		return "travel/infocab/list";
	}
	@RequestMapping("/travel/infocab/approval-list")
	public String mastersInfoCabApprovalList()
	{
		return "travel/infocab/list";
	}
	
	@RequestMapping("/travel/infocab/approved-list")
	public String mastersInfoCabApprovedList()
	{
		return "travel/infocab/list";
	}
	
	@RequestMapping("/travel/infocab/request-list")
	public String mastersInfoCabRequestList()
	{
		return "travel/infocab/list";
	}
	
	//@PreAuthorize(value="@securityService.userHasPermissionForURL('/travel/infocab/add')")
	@RequestMapping("/travel/infocab/add")
	public String mastersInfoCabAdd()
	{
		return "travel/infocab/add";
	}
	@RequestMapping("/infocab/edit")
	public String mastersInfoCabEdit()
	{
		return "travel/infocab/add";
	}
	
	@RequestMapping("/infocab/generic-tabs")
	public String mastersInfoCabTabs()
	{
		return "travel/infocab/generic-tabs";
	}
	
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/travel/infocabdriver/list')")
	@RequestMapping("/travel/infocabdriver/list")
	public String mastersInfoCabDriverList()
	{
		return "travel/infocabdriver/list";
	}
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/travel/infocabdriver/add')")
	@RequestMapping("/travel/infocabdriver/add")
	public String mastersInfoCabDriverAdd()
	{
		return "travel/infocabdriver/add";
	}
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/travel/infocabdriver/add')")
	@RequestMapping("/travel/infocabdriver/edit")
	public String mastersInfoCabDriverEdit()
	{
		return "travel/infocabdriver/add";
	}
	
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/travel/infocabvehicle/list')")
	@RequestMapping("/travel/infocabvehicle/list")
	public String mastersInfoCabVehicleList()
	{
		return "travel/infocabvehicle/list";
	}
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/travel/infocabvehicle/add')")
	@RequestMapping("/travel/infocabvehicle/add")
	public String mastersInfoCabVehicleAdd()
	{
		return "travel/infocabvehicle/add";
	}
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/travel/infocabvehicle/add')")
	@RequestMapping("/travel/infocabvehicle/edit")
	public String mastersInfoCabVehicleEdit()
	{
		return "travel/infocabvehicle/add";
	}
	
	/***********************shuttle module******************************************/
	@RequestMapping("/travel/shuttle/add")
	public String mastersShuttleAdd()
	{
		return "travel/shuttle/add";
	}
	
	/***********************InfoTravel module******************************************/	
	@RequestMapping("/travel/infotravel/add")
	public String mastersInfoTravelAdd()
	{
		return "travel/infotravel/add";
	}
	
	@RequestMapping("/travel/infotravel/edit")
	public String mastersInfoTravelEdit()
	{
		return "travel/infotravel/add";
	}	
	
	@RequestMapping("/travel/infotravel/list")
	public String mastersInfoTravelList()
	{
		return "travel/infotravel/list";
	}
	
	@RequestMapping("/travel/infotravel/all-list")
	public String mastersInfoTravelPmList()
	{
		return "travel/infotravel/list";
	}
	
	@RequestMapping("/travel/infotravel/approval-list")
	public String mastersInfoTravelApprovalList()
	{
		return "travel/infotravel/list";
	}
	
	@RequestMapping("/travel/infotravel/validated-list")
	public String mastersInfoTravelValidatedList()
	{
		return "travel/infotravel/list";
	}
	
	@RequestMapping("/travel/infotravel/finance-list")
	public String mastersInfoTravelFinanceList()
	{
		return "travel/infotravel/list";
	}
	@RequestMapping("/infotravel/generic-tabs")
	public String mastersInfoTravelTabs()
	{
		return "travel/infotravel/generic-tabs";
	}
	/*****************************************************************/	
	@RequestMapping("/masters/year")
	public String mastersYear()
	{
		return "masters/year";
	}
	/** 
	 * Added Exchange Rate Master <JV>*/
	@RequestMapping("/masters/exchangerate")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/masters/exchangerate')")
	public String exchangeRate()
	{
		return "masters/exchangerate";
	}
	
	@RequestMapping("/masters/portfolio")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/masters/portfolio')")
	public String mastersPortfolio()
	{
		return "masters/portfolio";
	}
	
	@RequestMapping("/treq/list")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/treq/list')")
	public String showTreqs()
	{
		return "amg/treq/list";
	}
	
	@RequestMapping("/treq/edit")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/treq/edit')")
	public String editTreq()
	{
		return "amg/treq/edit";
	}
	

	@RequestMapping("/treq/my-list")	
	public String showTreqByAssociate()
	{
		return "amg/treq/list";
	}
	
	@RequestMapping("/treq/project")	
	public String showTreqByProject()
	{
		return "amg/treq/list";
	}
		
	@RequestMapping("/skills/my-list")
	public String showAssociateSkills()
	{
		return "amg/associateSkills/list";
	}
	
	@RequestMapping("/associateskills/view")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/associateskills/view')")
	public String viewAssociateSkills()
	{
		return "amg/associateSkills/view";
	}
	
	@RequestMapping("/masters/doctype")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/masters/doctype')")
	public String mastersDocumentType()
	{
		return "masters/documenttype";
	}
	
	@RequestMapping("/masters/uom")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/masters/uom')")
	public String mastersUom()
	{
		return "masters/uom";
	}
	
	@RequestMapping("/masters/currency")
	public String mastersCurrency()
	{
		return "masters/currency";
	}

	@RequestMapping("/masters/milestone")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/masters/milestone')")
	public String mastersMilestone()
	{
		return "masters/milestone";
	}
	
	@RequestMapping("/masters/region")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/masters/region')")
	public String mastersRegion()
	{
		return "masters/region";
	}
	
	@RequestMapping("/masters/skill")
	//@PreAuthorize(value="@securityService.userHasPermissionForURL('/masters/skill')")
	public String mastersSkill()
	{
		return "masters/skill";
	}

	@RequestMapping("/masters/empType")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/masters/empType')")
	public String mastersEmpType()
	{
		return "masters/empType";
	}
	
	@RequestMapping("/masters/skillcategory")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/masters/skillcategory')")
	public String mastersSkillCategory()
	{
		return "masters/skillcategory";
	}
	
	@RequestMapping("/masters/amgroles")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/masters/amgroles')")
	public String mastersAmgRoles()
	{
		return "masters/amgroles";
	}
	
	@RequestMapping("/masters/costguidance")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/masters/costguidance')")
	public String mastersCostGuidance()
	{
		return "masters/costguidance";
	}
	
	@RequestMapping("/masters/treq")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/masters/treq')")
	public String mastersTreq()
	{
		return "treqs/treq";
	}

	
	@RequestMapping("/masters/billtype")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/masters/billtype')")
	public String mastersBillingType()
	{
		return "masters/billingtype";
	}
	
	@RequestMapping("/masters/bucket")
	@PreAuthorize(value = "@securityService.userHasPermissionForURL('/masters/bucket')")
	public String mastersBucket()
	{
		return "masters/bucket";
	}
	
	@RequestMapping("/masters/associatebucket")
	@PreAuthorize(value = "@securityService.userHasPermissionForURL('/masters/associatebucket')")
	public String mastersAssociateBucket()
	{
		return "masters/associatebucket";
	}

	@RequestMapping("/masters/projectTypes")
    @PreAuthorize(value = "@securityService.userHasPermissionForURL('/masters/projectTypes')")
    public String mastersProjectTypes() {
        return "masters/projectTypes";
	}

    @RequestMapping("/masters/taskCategory")
    @PreAuthorize(value = "@securityService.userHasPermissionForURL('/masters/taskCategory')")
    public String mastersTaskCategory() {
        return "masters/taskCategory";
    }

	@RequestMapping("/masters/termcondition")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/masters/termcondition')")
	public String mastersTermCondition()
	{
		return "masters/termcondition";
	}

	@RequestMapping("/masters/entities")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/masters/entities')")
	public String mastersEntities()
	{
		return "masters/entities";
	}
	
	@RequestMapping("/masters/expensePurpose")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/masters/expensePurpose')")
	public String mastersExpensePurpose()
	{
		return "masters/expensePurpose";
	}
	
	@RequestMapping("/masters/expenseCategory")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/masters/expenseCategory')")
	public String mastersExpenseCategory()
	{
		return "masters/expenseCategory";
	}
	
	@RequestMapping("/masters/unit")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/masters/unit')")
	public String mastersUnit()
	{
		return "masters/unit";
	}
	
	@RequestMapping("/masters/period")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/masters/period')")
	public String managePeriod()
	{
		return "masters/period";
	}
	
	@RequestMapping("/masters/country")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/masters/country')")
	public String mastersCountry()
	{
		return "masters/country";
	}
	
	@RequestMapping("/masters/state")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/masters/state')")
	public String mastersState()
	{
		return "masters/state";
	}
	
	@RequestMapping("/masters/city")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/masters/city')")
	public String mastersCity()
	{
		return "masters/city";
	}
	
	@RequestMapping("/masters/holidaySchedules")
	public String mastersHolidaySchedules()
	{
		return "masters/holidaySchedules";
	}
	
	@RequestMapping("/masters/holiday")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/masters/holiday')")
	public String mastersHoliday()
	{
		return "masters/holiday";
	}
	@RequestMapping("/masters/coe")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/masters/coe')")
	public String mastersCoe()
	{
		return "masters/coe";
	} 
	
	@RequestMapping("/coe/edit")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/coe/edit')")
	public String editCoe()
	{
		return "masters/coe";
	}
	
	@RequestMapping("/masters/coelist")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/masters/coelist')")
	public String mastersList()
	{
		return "masters/coelist";
	}
	
	@RequestMapping("/survey/survey")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/survey/survey')")
	public String mastersSurvey()
	{
		return "survey/survey";
	} 
	
	@RequestMapping("/survey/surveyedit")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/survey/surveyedit')")
	public String editSurvey()
	{
		return "survey/survey";
	} 
	
	@RequestMapping("/survey/surveylist")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/survey/surveylist')")
	public String mastersSurveyList()
	{
		return "survey/surveylist";
	}
	
	@RequestMapping("/survey/targetAudience")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/survey/targetAudience')")
	public String mastersTargetAudience()
	{
		return "survey/targetAudience";
	} 
	
	@RequestMapping("/survey/targetAudienceEdit")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/survey/targetAudienceEdit')")
	public String editTargetAudience()
	{
		return "survey/targetAudience";
	} 
	
	@RequestMapping("/survey/surveyResponselist")   
	public String SurveyResponseList()
	{
		return "survey/surveyResponselist";
	}
	
	@RequestMapping("/survey/targetAudienceList")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/survey/targetAudienceList')")
	public String mastersTargetAudienceList()
	{
		return "survey/targetAudienceList";
	}
	
	@RequestMapping("/releaseManagement/list")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/releaseManagement/list')")
	public String mastersReleaseList()
	{
		return "releaseManagement/list";
	}
	
	@RequestMapping("/releaseManagement/add")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/releaseManagement/add')")
	public String mastersReleaseAdd()
	{
		return "releaseManagement/add";
	}
	
	@RequestMapping("/releaseManagement/edit")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/releaseManagement/edit')")
	public String mastersReleaseEdit()
	{
		return "releaseManagement/add";
	}
	
	@RequestMapping("/releaseManagement/all-list")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/releaseManagement/all-list')")
	public String mastersReleaseListAll()
	{
		return "releaseManagement/all-list";
	}
	
	@RequestMapping("/list/my-holidays")
	public String myHoliday()
	{
		return "masters/holiday";
	}
	
	@RequestMapping("/deliveryExcellence/actionitems")
	public String mastersActionItems()
	{
		return "deliveryExcellence/actionitems";
	}
	
	@RequestMapping("/invoiceinfo/list")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/invoiceinfo/list')")
	public String mastersInvoiceInfo()
	{
		return "pmo/project/invoiceinfo/invoiceinfo";
	}
	
	@RequestMapping("/invoices/receipt/add")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/invoices/receipt/add')")
	public String showInvoiceReceipt()
	{
		return "invoices/receipt/add";
	}
	
	@RequestMapping("/cms/list")
	public String listCms()
	{
		return "pm/cms/list";
	}
	
	@RequestMapping("/cms/all-list")
	public String listAllCms()
	{
		return "pm/cms/all-list";
	}
	
	@RequestMapping("/opportunity/list")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/opportunity/list')")
	public String listOpportunity()
	{
		return "pmo/opportunity/list";
	}
	
	@RequestMapping("/planning/revenue")
	//@PreAuthorize(value="@securityService.userHasPermissionForURL('/planning/list-by-ph')")
	public String listOpportunityByPh()
	{
		return "pmo/opportunity/list";
	}
	
	@RequestMapping("/planning/monthly-revenue")
	public String listplanningRevenuneByMonth()
	{
		return "pmo/opportunity/monthly-revenue";
	}
	
	
	@RequestMapping("/cms/add")
	public String addCms()
	{
		return "pmo/sow/add";
	}
	@RequestMapping("/cms/edit")
	public String editCms()
	{
		return "pmo/sow/add";
	}

	@RequestMapping("/exitform/list")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/exitform/list')")	
	public String exitFormResource()
	{
		return "hr/exitForm/list";
	}
	
	@RequestMapping("/account-planning/list")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/account-planning/list')")
	public String accountPlanning()
	{
		return "pmo/accountPlanning/list";
	}
	
	@RequestMapping("/invoices/ytd-revenue")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/invoices/ytd-revenue')")
	public String revenuePlanning()
	{
		return "invoices/ytd-revenue";
	}
	
	@RequestMapping("/masters/report")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/masters/report')")
	public String reports()
	{
		return "reports/list";
	}
	
	@RequestMapping("/reports/list")
	public String reportsDashboard()
	{
		return "reports/dashboard";
	}
	
	@RequestMapping("/reports/add")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/reports/add')")		
	public String reportsAdd()
	{
		return "reports/add";
	}
	
	@RequestMapping("/reports/edit")
    public String reportsUpdate() {
		return "reports/add";
	}
	
	@RequestMapping("/masters/certification")
	@PreAuthorize(value = "@securityService.userHasPermissionForURL('/masters/certification')")
	public String mastersCertification()
	{
		return "masters/certification";
	}
		
	/* view controller for the timesheets */
	/* --------------------------------------------------------------------------------------- */
	@RequestMapping("/timesheet/myts")
	public String showTstimesheet(){
		try{
			return "timesheet/tstimesheet";
		}
		catch(Exception e){
			logger.warn(e);
		}
		return null;
	}
	
	@RequestMapping("/timesheet/tsapprove-task-pm")	
	public String pmApproveTask(){
		return "timesheet/tstimesheet";
	}
	
	@RequestMapping("/timesheet/showTsitem")
	public String showTsitem(){
		return "timesheet/tsitem";
	}
	
	@RequestMapping("/timesheet/showTsitemhours")
	public String showTsitemhours(){
		return "timesheet/tsitemhours";
	}
	
	@RequestMapping("/timesheet/showTsnotes")
	public String showTsnotes(){
		return "timesheet/tsnotes";
	}
	
	@RequestMapping("/timesheet/showTsperiod")
	public String showTsperiod(){
		return "timesheet/tsperiod";
	}
	
	@RequestMapping("/timesheet/tsapprove-project-pm")
	public String pmApproveProject(){
		return "timesheet/tsapprove";
	}
	
	@RequestMapping("/timesheet/tsapprove-project-ah")
	public String ahApproveProject(){
		return "timesheet/tsapprove";
	}
	
	@RequestMapping("/timesheet/tsapprove-project-dm")
	public String dmApproveProject(){
		return "timesheet/tsapprove";
	}
	
	@RequestMapping("/timesheet/tsapprove-project-pp")
	public String ppApproveProject(){
		return "timesheet/tsapprove";
	}
	
	@RequestMapping("/timesheet/approveTask")
	public String showTsapproveTask(){
		return "timesheet/tsapproveTask";
	}
	
	@RequestMapping("/timesheet/addnonwork")
	public String addTsNonwork(){
		return "timesheet/addnonwork";
	}
	@RequestMapping("/timesheet/addwork")
	public String addTsWork(){
		return "timesheet/addwork";
	}
	
	/*View controller for GTPWSR */
	@RequestMapping("/gtpSr/gtpSrList")
	public String getGtpSrList()
	{
		return "gtpSr/gtpSrList";
	}
	
	@RequestMapping("/gtpSr/gtpSr-myList")
	public String showGtpSrByAssociate(){
		return "gtpSr/gtpSrList";
	}
	
	@RequestMapping("/gtpSr/project")
	public String showGtpSrByProject(){
		return "gtpSr/gtpSrList";
	}
	
	
	/* view controller for the invoices */
	/* --------------------------------------------------------------------------------------- */
	@RequestMapping("/invoices/list")
	public String invoices_list()
	{
		return "invoices/list";
	}
	@RequestMapping("/invoices/searchByInvoice")
	public String invoices_SearchByInvoice()
	{
		return "invoices/searchByInvoice";
	}
	@RequestMapping("/invoices/add")
	public String invoices_add()
	{
		return "invoices/add";
	}
	@RequestMapping("/invoices/edit")
	public String invoices_edit()
	{
		return "invoices/add";
	}
	
	@RequestMapping("/invoices/expenses/list")
	public String invoices_expense_list()
	{
		return "invoices/other-invoices";
	}
	
	@RequestMapping("/invoices/inter-unit/list")
	public String invoices_interunit_list()
	{
		return "invoices/other-invoices";
	}
	
	@RequestMapping("/invoices/cndn/list")
	public String invoices_cndn_list()
	{
		return "invoices/other-invoices";
	}
	
	@RequestMapping("/invoices/internal/list")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/invoices/internal/list')")
	public String invoices_internal_list()
	{
		return "invoices/other-invoices";
	}
	
	@RequestMapping("/invoices/license/list")
	public String invoices_license_list()
	{
		return "invoices/other-invoices";
	}
	@RequestMapping("/invoices/bulk/list")
	public String invoices_bulk()
	{
		return "invoices/bulk-list";
	}
	@RequestMapping("/invoices/reports")
	public String invoices_report()
	{
		return "invoices/reports/report-list";
	}
	@RequestMapping("/notes/list")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/notes/list')")
	public String notes_list()
	{
		return "invoices/notes-list";
	}
	
	@RequestMapping("/exchange-rates")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/exchange-rates')")
	public String exchange_rates_list()
	{
		return "masters/exchange-rates";
	}
	
	@RequestMapping("/invoices/generic-tabs")
	public String invoices_generic_tabs()
	{
		return "invoices/generic-tabs";
	}
	
	@RequestMapping("/invoicesdetail/download")
	public String download()
	{
		return "invoicesdetail/download";
	}

	@RequestMapping("/isowdetail/download")
	public String isowdownload()
	{
		return "isowdetail/download";
	}
	//DE

	@RequestMapping("/deliveryExcellence/projectMetricForm")
	public String deMetricsForm() {
		return "deliveryExcellence/metricsGatheringForm";
	}

	@RequestMapping("/deliveryExcellence/governanceDashboard")
	public String deGovernanceDashboard() {
		return "deliveryExcellence/governanceDashboard";
	}

	@RequestMapping("/deliveryExcellence/deProjects")
	public String projectsUnderDeGovernanceDashboard()
	{
		return "deliveryExcellence/deProjects";
	}
	
	//DE

//	@RequestMapping("/invoicesdetail/pdfdownload")
//	@PreAuthorize(value="@securityService.userHasPermissionForURL('/invoicesdetail/pdfdownload')")
//	public String pdfdownload()
//	{
//		return "invoicesdetail/pdfdownload";
//	}
	/* --------------------------------------------------------------------------------------- */
	
	/* PMS - Category: Add below functions for view controller for the Category */
	/* --------------------------------------------------------------------------------------- */
	
	/*-------------------HR Dashboard--------------------------------------------------------------------*/
	
	@RequestMapping("/pms/career-tracks")
	public String pmsGradeWiseMapping()
	{
		return "pms/career-tracks/list";
	}
	//cluster
	@RequestMapping("/pms/career-tracks/cluster/add")
	public String pmsGradeClusterAdd()
	{
		return "pms/career-tracks/cluster/add";
	}
	@RequestMapping("/pms/career-tracks/cluster/list")
	public String pmsGradeClusterList()
	{
		return "pms/career-tracks/cluster/list";
	}
	@RequestMapping("/pms/career-tracks/cluster/edit")
	public String pmsGradeClusterEdit()
	{
		return "pms/career-tracks/cluster/add";
	}
	
	//competency
	@RequestMapping("/pms/career-tracks/competency/add")
	public String pmsCompetencyAdd()
	{
		return "pms/career-tracks/competency/add";
	}
	@RequestMapping("/pms/career-tracks/competency/list")
	public String pmsCompetencyList()
	{
		return "pms/career-tracks/competency/list";
	}
	@RequestMapping("/pms/career-tracks/competency/edit")
	public String pmsCompetencyEdit()
	{
		return "pms/career-tracks/competency/add";
	}
	
	//technology
	@RequestMapping("/pms/career-tracks/technology/add")
	public String pmsTechnologyAdd()
	{
		return "pms/career-tracks/technology/add";
	}
	@RequestMapping("/pms/career-tracks/technology/list")
	public String pmsTechnologyList()
	{
		return "pms/career-tracks/technology/list";
	}
	@RequestMapping("/pms/career-tracks/technology/edit")
	public String pmsTechnologyEdit()
	{
		return "pms/career-tracks/technology/add";
	}
	
	// technology courses
	@RequestMapping("/pms/career-tracks/technologyCourses/add")
	public String pmsTechnologyCourseAdd()
	{
		return "pms/career-tracks/technologyCourses/add";
	}
	@RequestMapping("/pms/career-tracks/technologyCourses/list")
	public String pmsTechnologyCourseList()
	{
		return "pms/career-tracks/technologyCourses/list";
	}
	@RequestMapping("/pms/career-tracks/technologyCourses/edit")
	public String pmsTechnologyCourseEdit()
	{
		return "pms/career-tracks/technologyCourses/add";
	}
	
	// behavior training
		@RequestMapping("/pms/career-tracks/behavioralTraining/add")
		public String pmsBehavioralTrainingAdd()
		{
			return "pms/career-tracks/behavioralTraining/add";
		}
		@RequestMapping("/pms/career-tracks/behavioralTraining/list")
		public String pmsBehavioralTrainingList()
		{
			return "pms/career-tracks/behavioralTraining/list";
		}
		@RequestMapping("/pms/career-tracks/behavioralTraining/edit")
		public String pmsBehavioralTrainingEdit()
		{
			return "pms/career-tracks/behavioralTraining/add";
		}
		
	// functional training
	@RequestMapping("/pms/career-tracks/functionalTraining/add")
	public String pmsfunctionalTrainingAdd()
	{
		return "pms/career-tracks/functionalTraining/add";
	}
	@RequestMapping("/pms/career-tracks/functionalTraining/list")
	public String pmsfunctionalTrainingList()
	{
	return "pms/career-tracks/functionalTraining/list";
	}
	@RequestMapping("/pms/career-tracks/functionalTraining/edit")
	public String pmsfunctionalTrainingEdit()
	{
	return "pms/career-tracks/functionalTraining/add";
	}
	
	// behavior training
	@RequestMapping("/pms/career-tracks/behavioralKeyAction/add")
	public String pmsBehavioralKeyActionAdd()
	{
		return "pms/career-tracks/behavioralKeyAction/add";
	}
	@RequestMapping("/pms/career-tracks/behavioralKeyAction/list")
	public String pmsBehavioralKeyActionList()
	{
		return "pms/career-tracks/behavioralKeyAction/list";
	}
	@RequestMapping("/pms/career-tracks/behavioralKeyAction/edit")
	public String pmsBehavioralKeyActionEdit()
	{
		return "pms/career-tracks/behavioralKeyAction/add";
	}
	
	// functional training
	@RequestMapping("/pms/career-tracks/functionalKeyAction/add")
	public String pmsfunctionalKeyActionAdd()
	{
		return "pms/career-tracks/functionalKeyAction/add";
	}
	@RequestMapping("/pms/career-tracks/functionalKeyAction/list")
	public String pmsfunctionalKeyActionList()
	{
	return "pms/career-tracks/functionalKeyAction/list";
	}
	@RequestMapping("/pms/career-tracks/functionalKeyAction/edit")
	public String pmsfunctionalKeyActionEdit()
	{
	return "pms/career-tracks/functionalKeyAction/add";
	}
	
	// technology mapping
		@RequestMapping("/pms/career-tracks/technologyMapping/add")
		public String pmstechnologyMappingAdd()
		{
			return "pms/career-tracks/technologyMapping/add";
		}
		@RequestMapping("/pms/career-tracks/technologyMapping/list")
		public String pmstechnologyMappingList()
		{
		return "pms/career-tracks/technologyMapping/list";
		}
		@RequestMapping("/pms/career-tracks/technologyMapping/edit")
		public String pmstechnologyMappingEdit()
		{
		return "pms/career-tracks/technologyMapping/add";
		}

		// gradewise mapping
		@RequestMapping("/pms/career-tracks/gradeWiseMapping/add")
		public String pmsgradeWiseMappingAdd()
		{
			return "pms/career-tracks/gradeWiseMapping/add";
		}
		@RequestMapping("/pms/career-tracks/gradeWiseMapping/list")
		public String pmsgradeWiseMappingList()
		{
		return "pms/career-tracks/gradeWiseMapping/list";
		}
		@RequestMapping("/pms/career-tracks/gradeWiseMapping/edit")
		public String pmsgradeWiseMappingEdit()
		{
		return "pms/career-tracks/gradeWiseMapping/add";
		}
		
		
	@RequestMapping("/pms/career-tracks/generic-tabs")
	public String genericPMS_tabs()
	{
		return "pms/career-tracks/generic-tabs";
	}

	
	@RequestMapping("/pms/dashboard")
	public String pmsDashboard()
	{
		return "pms/dashboard";
	}	
	
	@RequestMapping("/pms/hr-dashboard")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/pms/hr-dashboard')")
	public String pmsHrDashboard()
	{
		return "pms/dashboard";
	}
	
	@RequestMapping("/pms/hradmin-dashboard")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/pms/hradmin-dashboard')")
	public String pmsHrAdminDashboard()
	{
		return "pms/dashboard";
	}
	
	@RequestMapping("/pms/my-portfolio")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/pms/my-portfolio')")
	public String pmsMyPortfolioDashboard()
	{
		return "pms/dashboard";
	}
	
	/*-------------------PMS Resource--------------------------------------------------------------------*/
	@RequestMapping("/pms/resource/list")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/pms/resource/list')")
	public String pmsResourceList()
	{
		return "pms/resource/list";
	}
	/*-------------------PMS Resource--------------------------------------------------------------------*/
	@RequestMapping("/pms/resource/edit")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/pms/resource/edit')")
	public String pmsResourceEdit()
	{
		return "pms/resource/add";
	}
	
	/*-------------------Category--------------------------------------------------------------------*/
	@RequestMapping("/pms/category/list")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/pms/category/list')")
	public String categoryList()
	{
		return "pms/category/list";
	}	
	
	@RequestMapping("/pms/category/add")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/pms/category/add')")
	public String categoryAdd()
	{
		return "pms/category/add";
	}	
	
	@RequestMapping("/pms/category/edit")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/pms/category/edit')")
	public String categoryEdit()
	{
		return "pms/category/add";
	}
	@RequestMapping("/pms/category/admin-config-tabs")
	public String pmsAdminConfigTabs()
	{
		return "pms/category/admin-config-tabs";
	}
	/*-------------------Cycle--------------------------------------------------------------------*/
	@RequestMapping("/pms/cycle/list")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/pms/cycle/list')")
	public String cycleList()
	{
		return "pms/cycle/list";
	}	
	
	@RequestMapping("/pms/cycle/add")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/pms/cycle/add')")
	public String cycleAdd()
	{
		return "pms/cycle/add";
	}	
	
	@RequestMapping("/pms/cycle/edit")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/pms/cycle/edit')")
	public String cycleEdit()
	{
		return "pms/cycle/add";
	}
	/*-------------------Goal Cluster--------------------------------------------------------------------*/
	@RequestMapping("/pms/goalCluster/list")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/pms/goalCluster/list')")
	public String goalClusterList()
	{
		return "pms/goalCluster/list";
	}	
	
	@RequestMapping("/pms/goalCluster/add")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/pms/goalCluster/add')")
	public String goalClusterAdd()
	{
		return "pms/goalCluster/add";
	}	
	
	@RequestMapping("/pms/goalCluster/edit")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/pms/goalCluster/edit')")
	public String goalClusterEdit()
	{
		return "pms/goalCluster/add";
	}
	/*-------------------Goal master--------------------------------------------------------------------*/
	@RequestMapping("/pms/goalMaster/list")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/pms/goalMaster/list')")
	public String goalMasterList()
	{
		return "pms/goalMaster/list";
	}	
	
	@RequestMapping("/pms/goalMaster/add")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/pms/goalMaster/add')")
	public String goalMasterAdd()
	{
		return "pms/goalMaster/add";
	}	
	
	@RequestMapping("/pms/goalMaster/edit")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/pms/goalMaster/edit')")
	public String goalMasterEdit()
	{
		return "pms/goalMaster/add";
	}
	/*-------------------Goal Rating Scale--------------------------------------------------------------------*/
	@RequestMapping("/pms/goalRatingScale/list")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/pms/goalRatingScale/list')")
	public String goalRatingScaleList()
	{
		return "pms/goalRatingScale/list";
	}	
	
	@RequestMapping("/pms/goalRatingScale/add")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/pms/goalRatingScale/add')")
	public String goalRatingScaleAdd()
	{
		return "pms/goalRatingScale/add";
	}	
	
	@RequestMapping("/pms/goalRatingScale/edit")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/pms/goalRatingScale/edit')")
	public String goalRatingScaleEdit()
	{
		return "pms/goalRatingScale/add";
	}
	
	/*-------------------competency Cluster--------------------------------------------------------------------*/
	@RequestMapping("/pms/competencyCluster/list")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/pms/competencyCluster/list')")
	public String competencyClusterList()
	{
		return "pms/competencyCluster/list";
	}	
	
	@RequestMapping("/pms/competencyCluster/add")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/pms/competencyCluster/add')")
	public String competencyClusterAdd()
	{
		return "pms/competencyCluster/add";
	}	
	
	@RequestMapping("/pms/competencyCluster/edit")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/pms/competencyCluster/edit')")
	public String competencyClusterEdit()
	{
		return "pms/competencyCluster/add";
	}
	/*------------------- Competency master--------------------------------------------------------------------*/
	@RequestMapping("/pms/competencyMaster/list")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/pms/competencyMaster/list')")
	public String competencyMasterList()
	{
		return "pms/competencyMaster/list";
	}	
	
	@RequestMapping("/pms/competencyMaster/add")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/pms/competencyMaster/add')")
	public String competencyMasterAdd()
	{
		return "pms/competencyMaster/add";
	}	
	
	@RequestMapping("/pms/competencyMaster/edit")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/pms/competencyMaster/edit')")
	public String competencyMasterEdit()
	{
		return "pms/competencyMaster/add";
	}
	/*-------------------Competency Rating Scale--------------------------------------------------------------------*/
	@RequestMapping("/pms/competencyRatingScale/list")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/pms/competencyRatingScale/list')")
	public String competencyRatingScaleList()
	{
		return "pms/competencyRatingScale/list";
	}	
	
	@RequestMapping("/pms/competencyRatingScale/add")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/pms/competencyRatingScale/add')")
	public String competencyRatingScaleAdd()
	{
		return "pms/competencyRatingScale/add";
	}	
	
	@RequestMapping("/pms/competencyRatingScale/edit")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/pms/competencyRatingScale/edit')")
	public String competencyRatingScaleEdit()
	{
		return "pms/competencyRatingScale/add";
	}
	
	/*-------------------Performance--------------------------------------------------------------------*/
	@RequestMapping("/pms/performance")
	public String pmsPerformanceAdd()
	{
		return "pms/performance/add";
	}
	
	/* ------------------------------- end of PMS section -----------------------------------------*/
	
	@RequestMapping("/")
	public String home()
	{
		return "amg/resource/view";
	}
	@RequestMapping("/login")
	public String login()
	{
		return "login";
	}

	// JV: URL for session management
	@RequestMapping("/invalidSession")
	public String invalidSession()
	{
		return "invalidSession";
	}
	@RequestMapping("/sessionExpired")
	public String sessionExpired()
	{
		return "sessionExpired";
	}
		
	//--------------------------------------------Views for Roles-----------------------------------
	@RequestMapping("/roles/list")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/roles/list')")
	public String showRoles(){
		return "/access/roles/list";
	}
	
	@RequestMapping("/roles/add")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/roles/add')")
	public String addRoles(){
		return "/access/roles/add";
	}
	
	//--------------------------------------------Views for PermissionsUrls----------------------------------	
	@RequestMapping("/permissions/list")
	public String addModules(){
		return "/access/permissions/list";
	}
	
	@RequestMapping("/unlockuser/list")
	public String blockedUsers() {
		return "/access/unlockuser/list";
	}
	
	//--------------------------------------------Views for Expense Module----------------------------------	
	@RequestMapping("/expense/list")
	public String expense() {
		return "/expense/expense";
	}
	
	@RequestMapping("/expense/expenseDetail")
	public String expenseDetail() {
		return "/expense/expenseDetail";
	}
	
	//--------------------------------------------Views for Nonwork Items----------------------------------
		@RequestMapping("/non-work-items/list")
		@PreAuthorize(value="@securityService.userHasPermissionForURL('/non-work-items/list')")
		public String showNonWorkItems(){
			return "/pmo/nonwork/list";
		}
		
	//--------------------------------------------Views for Holiday Schedules----------------------------------
			@RequestMapping("/holidays/list")
			public String showHolidays(){
				//return "/pmo/holidayschedules/list";
				return "/pmo/holidayschedules/filterlist";
			}
				
			
	//--------------------------------------------Views for Project Report----------------------------------
	@RequestMapping("/timesheet/reports/project")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/timesheet/reports/project')")
	public String showTsReports(){
		return "/timesheet/reports/project";
	}
	
	@RequestMapping("/timesheet/reports/associate")
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/timesheet/reports/associate')")
	public String showAsTsReports(){
		return "/timesheet/reports/associate";
	}
	
	@RequestMapping("/planning/treqs")
	//@PreAuthorize(value="@securityService.userHasPermissionForURL('/planning/treqs')")
	public String resourcePlanning()
	{
		return "pmo/opportunity/resourcePlanning";
	}
	
	@RequestMapping("/accesscard/list")
	public String accessCardList()
	{
		return "admin/accesscard/list";
	}
	
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/accesscard/add')")
	@RequestMapping("/accesscard/add")
	public String accessCardAdd()
	{
		return "admin/accesscard/add";
	}
	
	@PreAuthorize(value="@securityService.userHasPermissionForURL('/accesscard/edit')")
	@RequestMapping("/accesscard/edit")
	public String accessCardEdit()
	{
		return "admin/accesscard/edit";
	}
							
	
	@RequestMapping("/depmoreview/add")
	public String dePmoReviewAdd()
	{
		return "deliveryExcellence/addDePmoReview";
	}
	
	@RequestMapping("/depmoreview/edit")
	public String dePmoReviewEdit()
	{
		return "deliveryExcellence/addDePmoReview";
	}
	
	@RequestMapping("/depmoreview/list")
	public String dePmoReviewList()
	{
		return "deliveryExcellence/listDePmoReview";
	}
	
	@RequestMapping("/dewsr/add")
	public String deWsrAdd()
	{
		return "deliveryExcellence/addWsr";
	}
	
	@RequestMapping("/dewsr/edit")
	public String deWsrEdit()
	{
		return "deliveryExcellence/addWsr";
	}
	
	@RequestMapping("/dewsr/list")
	public String deWsrList()
	{
		return "deliveryExcellence/listWsr";
	}
	
	@RequestMapping("/deappreciation/list")
	public String deAppreciationList()
	{
		return "deliveryExcellence/listAppreciation";
	}
	
	@RequestMapping("/deappreciation/add")
	public String deAppreciationAdd()
	{
		return "deliveryExcellence/addAppreciation";
	}
	
	@RequestMapping("/deappreciation/edit")
	public String deAppreciationEdit()
	{
		return "deliveryExcellence/addAppreciation";
	}


	@RequestMapping("/decomplaint/list")
	public String ComplaintList()
	{
		return "deliveryExcellence/listComplaint";
	}
	
	@RequestMapping("/decomplaint/add")
	public String complaintAdd()
	{
		return "deliveryExcellence/addComplaint";
	}
	
	@RequestMapping("/decomplaint/edit")
	public String complaintEdit()
	{
		return "deliveryExcellence/addComplaint";
	}
	
	@RequestMapping("/devalueadd/list")
	public String ValueAddList()
	{
		return "deliveryExcellence/listValueAdd";
	}
	
	@RequestMapping("/devalueadd/add")
	public String ValueAddAdd()
	{
		return "deliveryExcellence/addValueAdd";
	}
	
	@RequestMapping("/devalueadd/edit")
	public String ValueAddEdit()
	{
		return "deliveryExcellence/addValueAdd";
	}
	
	@RequestMapping("/demsr/list")
	public String MsrList()
	{
		return "deliveryExcellence/listMsr";
	}
	
	@RequestMapping("/demsr/add")
	public String MsrAdd()
	{
		return "deliveryExcellence/addMsr";
	}
	
	@RequestMapping("/demsr/edit")
	public String MsrEdit()
	{
		return "deliveryExcellence/addMsr";
	}

	@RequestMapping("/dephupdate/list")
	public String PhUpdateList()
	{	
		// return "deliveryExcellence/listPhUpdate";
		return "deliveryExcellence/addPhUpdate";
	}
	
	@RequestMapping("/dephupdate/add")
	public String PhUpdateAdd()
	{
		return "deliveryExcellence/addPhUpdate";
	}
	
	@RequestMapping("/dephupdate/edit")
	public String PhUpdateEdit()
	{
		return "deliveryExcellence/addPhUpdate";
	}
	
	
	//=========================================== Method to create Permissions Urls ====================================
	@Autowired
	PermissionsUrlsRepository repository;
	

	@RequestMapping("/permissions/update")
	public String updateUrls()
	{
		List<String> urlsList = new ArrayList<>();
				
		// For Allocations module
		//---------------------------------------
		urlsList.add("/allocation/soft-allocation");
		
		// For resource module
		//---------------------------------------		
		urlsList.add("/resource/add");
		urlsList.add("/resource/edit");
		urlsList.add("/gtp/list");
		urlsList.add("/gtp/edit");
		
		// For project module
		//---------------------------------------
		urlsList.add("/project/add");
		
		// For roles module
		//---------------------------------------
		urlsList.add("/roles/list");
		urlsList.add("/roles/add");
				
		// For permissions module
		//---------------------------------------
		//urlsList.add("/permissions/list");
		//urlsList.add("/permissions/update");
		
		// For non work item list module
		//---------------------------------------
		urlsList.add("/non-work-items/list");	
		
		
		// For timesheet module
		//---------------------------------------
		urlsList.add("/timesheet/reports/project");
		urlsList.add("/timesheet/reports/associate");

		// For masters module
		//---------------------------------------
		urlsList.add("/masters/doctype");
		urlsList.add("/masters/uom");
		urlsList.add("/masters/milestone");
		urlsList.add("/masters/billtype");
		urlsList.add("/masters/region");
		urlsList.add("/masters/skill");
		urlsList.add("/masters/skillcategory");
		urlsList.add("/masters/amgroles");
		urlsList.add("/masters/costguidance");
		urlsList.add("/masters/treq");
		urlsList.add("/masters/portfolio");
		urlsList.add("/masters/termcondition");
		urlsList.add("/masters/entities");
		urlsList.add("/masters/expensePurpose");
		urlsList.add("/masters/expenseCategory");
 		urlsList.add("/masters/unit");	
		urlsList.add("/masters/period");
		urlsList.add("/masters/country");
		urlsList.add("/masters/state");	
		urlsList.add("/masters/city");
		urlsList.add("/masters/projectTypes");
        urlsList.add("/masters/taskCategory");
		urlsList.add("/masters/holiday");
		urlsList.add("/masters/exchangerate");
		urlsList.add("/masters/empType");
		urlsList.add("/masters/bucket");
		urlsList.add("/masters/associatebucket");
		urlsList.add("/masters/certification");
		urlsList.add("/masters/report");
		urlsList.add("/masters/coelist");        //COE module
		urlsList.add("/masters/coe");
		urlsList.add("/coe/edit");
		
		// For release management module
		//---------------------------------------
		urlsList.add("/releaseManagement/list");
		urlsList.add("/releaseManagement/add");
		urlsList.add("/releaseManagement/edit");
		urlsList.add("/releaseManagement/all-list");
		
		// For Survey Module
		//---------------------------------------
		urlsList.add("/survey/surveylist");        	  //Survey
		urlsList.add("/survey/survey");
		urlsList.add("/survey/surveyedit");
		urlsList.add("/survey/targetAudienceList");  //Target Audience     
		urlsList.add("/survey/targetAudience");
		urlsList.add("/survey/targetAudienceEdit");
		urlsList.add("/survey/surveyResponselist");  //Survey response
		
		// For treq module
		//---------------------------------------
		urlsList.add("/treq/list");
		urlsList.add("/treq/edit");		
				
		// For invoice module
		//---------------------------------------
		urlsList.add("/invoiceinfo/list");
		urlsList.add("/invoices/internal/list");
		urlsList.add("/invoices/receipt/add");
		urlsList.add("/notes/list");			
		//urlsList.add("/invoicesdetail/pdfdownload");
		
		// For associate bucket list
		//---------------------------------------	
		urlsList.add("/associate-bucket/list");
		
		//For ISOW List Page
		urlsList.add("/isow/list");
		
		urlsList.add("/pmo/dashboard");
		urlsList.add("/amg/dashboard");
		urlsList.add("/reports/revenue-dashboard");
		urlsList.add("/reports/budgeted-vs-revenue-in-hand");
		urlsList.add("/reports/monthly-revenue-projection");
		urlsList.add("/reports/monthly-revenue-by-account");
		urlsList.add("/reports/monthly-revenue-by-project");
		urlsList.add("/reports/monthly-revenue-by-sow");
		
		urlsList.add("/account-planning/list");
		urlsList.add("/invoices/ytd-revenue");
		
		urlsList.add("/reports/monthly-revenue-projection-nwd");
		urlsList.add("/reports/monthly-revenue-by-account-nwd");
		urlsList.add("/reports/monthly-revenue-by-project-nwd");
		urlsList.add("/reports/monthly-revenue-by-sow-nwd");
		urlsList.add("/associateskills/view");

		// ExitForm module
		urlsList.add("/exitform/list");
		
		//Report module
		urlsList.add("/reports/add");
		urlsList.add("/reports/edit");
		
		
		//Travel module
		urlsList.add("/travel/worklocation/list");
		urlsList.add("/worklocation/add");
		
		urlsList.add("/travel/busroute/list");
		urlsList.add("/busroute/add");
		
		urlsList.add("/travel/busroutetimings/list");
		urlsList.add("/busroutetimings/add");
		
		urlsList.add("/travel/busnodalpoint/list");
		urlsList.add("/busnodalpoint/add");
		
		urlsList.add("/travel/infocabdriver/list");
		urlsList.add("/travel/infocabdriver/add");
		urlsList.add("/travel/infocabdriver/edit");

		urlsList.add("/travel/infocabvehicle/list");
		urlsList.add("/travel/infocabvehicle/add");
		urlsList.add("/travel/infocabvehicle/edit");
		
		//Opportunity PMO Module
		urlsList.add("/opportunity/list");
		urlsList.add("/planning/list-by-ph");
		
		//AccountInfo Module
		urlsList.add("/accountInfo/list");
		urlsList.add("/accountInfo/add");
		urlsList.add("/accountInfo/edit");
		
		//urlsList.add("/planning/treqs");
		urlsList.add("/accesscard/add");
		urlsList.add("/accesscard/edit");
		
		urlsList.add("/depmoreview/add");
		urlsList.add("/depmoreview/edit");
		/* -------------- start for PMS module -------------------------- */
		
		urlsList.add("/pms/hr-dashboard");
		urlsList.add("/pms/hradmin-dashboard");
		urlsList.add("/pms/my-portfolio");
		
		
		urlsList.add("/pms/resource/list");
		urlsList.add("/pms/resource/edit");
		
		// For Category module
		//---------------------------------------
		urlsList.add("/pms/category/add");
		urlsList.add("/pms/category/edit");
		urlsList.add("/pms/category/list");
		
		// For cycle module
		//---------------------------------------
		urlsList.add("/pms/cycle/add");
		urlsList.add("/pms/cycle/edit");
		urlsList.add("/pms/cycle/list");
		
		// For goal cluster module
		//---------------------------------------
		urlsList.add("/pms/goalCluster/add");
		urlsList.add("/pms/goalCluster/edit");
		urlsList.add("/pms/goalCluster/list");
		
		// For goal master module
		//---------------------------------------
		urlsList.add("/pms/goalMaster/add");
		urlsList.add("/pms/goalMaster/edit");
		urlsList.add("/pms/goalMaster/list");
		
		// For goal rating scale module
		//---------------------------------------
		urlsList.add("/pms/goalRatingScale/add");
		urlsList.add("/pms/goalRatingScale/edit");
		urlsList.add("/pms/goalRatingScale/list");
		
		// For competency cluster module
		//---------------------------------------
		urlsList.add("/pms/competencyCluster/add");
		urlsList.add("/pms/competencyCluster/edit");
		urlsList.add("/pms/competencyCluster/list");
		
		// For competency master module
		//---------------------------------------
		urlsList.add("/pms/competencyMaster/add");
		urlsList.add("/pms/competencyMaster/edit");
		urlsList.add("/pms/competencyMaster/list");
		
		// For competency rating scale module
		//---------------------------------------
		urlsList.add("/pms/competencyRatingScale/add");
		urlsList.add("/pms/competencyRatingScale/edit");
		urlsList.add("/pms/competencyRatingScale/list");
				
		urlsList.add("/exitAccess/list");
		
		
		/* -------------- end for PMS module -------------------------- */
		
		logger.info(urlsList);
		List<PermissionsUrls> listPermissionsUrls = repository.findAll();
		if(listPermissionsUrls.size() > 0) {
			ListIterator<PermissionsUrls> iterator = listPermissionsUrls.listIterator();
			while(iterator.hasNext())
			{
				PermissionsUrls permissionsUrl = (PermissionsUrls)iterator.next();	
				Object url = (Object)permissionsUrl.getUrl();
				if(urlsList.contains(url))
				{
					urlsList.remove(url);
				}
			}
		}
		logger.info(urlsList);
		for(String url:urlsList) 
		{
			createPermissionsUrls(url);
		}
		return "/access/permissions/list";
	}
	
	
	public void createPermissionsUrls(String url)
	{
		
		PermissionsUrls purl = new PermissionsUrls();
		purl.setUrl(url);
		purl.setStatus(true);
		repository.save(purl);
	}
}
