package com.infocepts.otc.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.infocepts.otc.entities.TimesheetNonwork;


public interface TimesheetNonworkRepository extends JpaRepository<TimesheetNonwork,Integer>{

	@Override
	public List<TimesheetNonwork> findAll();
	
	@Query("select tnw FROM TimesheetNonwork tnw where tnw.isEnabled = :isEnabled")
    public List<TimesheetNonwork> findByIsEnabled(@Param("isEnabled") Boolean isEnabled);
}
