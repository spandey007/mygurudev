package com.infocepts.otc.entities;

import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.SqlResultSetMappings;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.infocepts.otc.utilities.LoadConstant;

@Entity
@Table(catalog=LoadConstant.otc, schema="[dbo]",name="ct_gradeWiseMapping")
@SqlResultSetMappings({
    @SqlResultSetMapping(
            name = "gradewise_mapping",
            classes = {
                    @ConstructorResult(
                            targetClass = CT_GradeWiseMapping.class,
                            columns = {
                            		@ColumnResult(name = "gradeWiseMappingId"),
                            		@ColumnResult(name = "gradeId"),
                            		@ColumnResult(name = "roleId"),
                            		@ColumnResult(name = "proficiencyLevelId"),
                            		@ColumnResult(name = "competencyId"),
									@ColumnResult(name = "functionalKeyAction", type = String.class),
                            		@ColumnResult(name = "functionalTraining", type = String.class),
                            		@ColumnResult(name = "behavioralKeyAction", type = String.class),
                            		@ColumnResult(name = "behavioralTraining", type = String.class),
                            		@ColumnResult(name = "competencyName", type = String.class),
                            		@ColumnResult(name = "clusterName", type = String.class),
                            		@ColumnResult(name = "clusterType", type = String.class),
                            		@ColumnResult(name = "grade", type = String.class),
                            		@ColumnResult(name = "role", type = String.class),
                            		@ColumnResult(name = "departmentId"),
                            		@ColumnResult(name = "departmentName", type = String.class)
                            }
                    )
            }
    ),
    @SqlResultSetMapping(
            name = "competencies_mapping",
            classes = {
                    @ConstructorResult(
                            targetClass = CT_GradeWiseMapping.class,
                            columns = {
                            		@ColumnResult(name = "competencyId"),
                            		@ColumnResult(name = "gradeId"),
                            		@ColumnResult(name = "competencyName", type = String.class),
                            		@ColumnResult(name = "clusterName", type = String.class),
                            		@ColumnResult(name = "departmentId")
                            }
                    )
            }
    )
})
@NamedNativeQueries({
    @NamedNativeQuery(
            name    =   "getAllMappingsByGradeAndRole",   
            query 	=   "select gm.*, " + 
            		" fka.functionalKeyAction as functionalKeyAction, ft.functionalTraining as functionalTraining, " + 
            		" bka.behavioralKeyAction as behavioralKeyAction, bt.behavioralTraining as behavioralTraining, "+
            		" co.competencyName as competencyName, cl.clusterName as clusterName, cl.type as clusterType, g.grade as grade, hrR.role as role "+
            		" ,d.departmentId as departmentId, d.departmentName as departmentName" +
            		" from " + LoadConstant.otc + ".[dbo].ct_gradeWiseMapping as gm " + 
            		" left join " + LoadConstant.otc + ".[dbo].ct_functionalKeyAction fka on fka.competencyId = gm.competencyId and fka.proficiencyLevelId = gm.proficiencyLevelId " + 
            		" left join " + LoadConstant.otc + ".[dbo].ct_functionalTraining ft on ft.competencyId = gm.competencyId and ft.proficiencyLevelId = gm.proficiencyLevelId " + 
            		" left join " + LoadConstant.otc + ".[dbo].ct_behavioralKeyAction bka on bka.competencyId = gm.competencyId and bka.proficiencyLevelId = gm.proficiencyLevelId " + 
            		" left join " + LoadConstant.otc + ".[dbo].ct_behavioralTraining bt on bt.competencyId = gm.competencyId and bt.proficiencyLevelId = gm.proficiencyLevelId " +
            		" left join " + LoadConstant.otc + ".[dbo].[ct_competency] co on co.competencyId = gm.competencyId " +
            		" left join " + LoadConstant.otc + ".[dbo].[ct_cluster] cl on cl.clusterId = co.clusterId " +
            		"left join " + LoadConstant.infomaster + ".[dbo].[grade] g on g.gradeId = gm.gradeId " +
            		"left join " + LoadConstant.infomaster + ".[dbo].[department] d on d.departmentId = gm.departmentId " +
					"left join " + LoadConstant.infomaster + ".[dbo].[hrRoles] hrR on hrR.hrmsId = gm.roleId " +
            			" where gm.gradeId = :gradeId and gm.roleId = :roleId "+
						" order by gm.gradeWiseMappingId",
						 
						resultClass=CT_GradeWiseMapping.class, resultSetMapping = "gradewise_mapping"
    ),
    @NamedNativeQuery(
            name    =   "getAllMappings",   
            query 	=   "select gm.*, " + 
            		" fka.functionalKeyAction as functionalKeyAction, ft.functionalTraining as functionalTraining, " + 
            		" bka.behavioralKeyAction as behavioralKeyAction, bt.behavioralTraining as behavioralTraining, "+
            		" co.competencyName as competencyName, cl.clusterName as clusterName, cl.type as clusterType, g.grade as grade, hrR.role as role "+
            		" ,d.departmentId as departmentId, d.departmentName as departmentName" +
            		" from " + LoadConstant.otc + ".[dbo].ct_gradeWiseMapping as gm " + 
            		" left join " + LoadConstant.otc + ".[dbo].ct_functionalKeyAction fka on fka.competencyId = gm.competencyId and fka.proficiencyLevelId = gm.proficiencyLevelId " + 
            		" left join " + LoadConstant.otc + ".[dbo].ct_functionalTraining ft on ft.competencyId = gm.competencyId and ft.proficiencyLevelId = gm.proficiencyLevelId " + 
            		" left join " + LoadConstant.otc + ".[dbo].ct_behavioralKeyAction bka on bka.competencyId = gm.competencyId and bka.proficiencyLevelId = gm.proficiencyLevelId " + 
            		" left join " + LoadConstant.otc + ".[dbo].ct_behavioralTraining bt on bt.competencyId = gm.competencyId and bt.proficiencyLevelId = gm.proficiencyLevelId " +
            		" left join " + LoadConstant.otc + ".[dbo].[ct_competency] co on co.competencyId = gm.competencyId " +
            		" left join " + LoadConstant.otc + ".[dbo].[ct_cluster] cl on cl.clusterId = co.clusterId " +
            		"left join " + LoadConstant.infomaster + ".[dbo].[grade] g on g.gradeId = gm.gradeId " +
            		"left join " + LoadConstant.infomaster + ".[dbo].[department] d on d.departmentId = gm.departmentId " +
					"left join " + LoadConstant.infomaster + ".[dbo].[hrRoles] hrR on hrR.hrmsId = gm.roleId " +
					" order by gm.gradeWiseMappingId",
						 
						resultClass=CT_GradeWiseMapping.class, resultSetMapping = "gradewise_mapping"
    ),
    @NamedNativeQuery(
            name    =   "getFunctionalCompetency",   
            query 	=   "select distinct c.competencyName, cl.type,cl.clusterName,g.gradeId, gm.competencyId,d.departmentId as departmentId from " + LoadConstant.otc + ".[dbo].[ct_gradeWiseMapping] gm " + 
						"left join  " + LoadConstant.otc + ".[dbo].[ct_competency] c " + 
						"on c.competencyId = gm.competencyId " + 
						"left join " + LoadConstant.otc + ".dbo.ct_cluster cl " + 
						"on cl.clusterId = c.clusterId " + 
						"left join " + LoadConstant.infomaster + ".dbo.grade g " + 
						"on g.gradeId = gm.gradeId " + 
						"left join " + LoadConstant.infomaster + ".dbo.department d " + 
						"on d.departmentId = gm.departmentId " + 
						"where cl.type = 'F' and gm.gradeId = :gradeId and gm.departmentId = (select pid from " + LoadConstant.infomaster + ".dbo.department where departmentId = :departmentId)" + 
						" order by c.competencyName " ,
						 
						resultClass=CT_GradeWiseMapping.class, resultSetMapping = "competencies_mapping"
    )
    ,
    @NamedNativeQuery(
            name    =   "getBehavioralCompetency",   
            query 	=   "select distinct c.competencyName, cl.type,cl.clusterName,g.gradeId, gm.competencyId,d.departmentId as departmentId from " + LoadConstant.otc + ".[dbo].[ct_gradeWiseMapping] gm " + 
						"left join  " + LoadConstant.otc + ".[dbo].[ct_competency] c " + 
						"on c.competencyId = gm.competencyId " + 
						"left join " + LoadConstant.otc + ".dbo.ct_cluster cl " + 
						"on cl.clusterId = c.clusterId " + 
						"left join " + LoadConstant.infomaster + ".dbo.grade g " + 
						"on g.gradeId = gm.gradeId " + 
						"left join " + LoadConstant.infomaster + ".dbo.department d " + 
						"on d.departmentId = gm.departmentId " + 
						"where cl.type = 'B' and gm.gradeId = :gradeId " + 
						" order by c.competencyName " ,
						 
						resultClass=CT_GradeWiseMapping.class, resultSetMapping = "competencies_mapping"
    )
})
public class CT_GradeWiseMapping {

	// Entity Columns
    // --------------------------------------------------------------------------------
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Integer gradeWiseMappingId;  
    
    private Integer gradeId;
    private Integer departmentId;
    private Integer roleId;
    private Integer proficiencyLevelId;
    
    private Integer competencyId;
    
    @Transient
    private String functionalKeyAction;
    
    @Transient
    private String functionalTraining;
    
    @Transient
    private String behavioralKeyAction;
    
    @Transient
    private String behavioralTraining; 
    
    @Transient
    private String competencyName;
    
    @Transient
    private String clusterName;
    
    @Transient
    private String clusterType;    
    
    @Transient
    private String grade;
    
    @Transient
    private String departmentName;
    
    @Transient
    private String role;
    
	public Integer getGradeWiseMappingId() {
		return gradeWiseMappingId;
	}

	public void setGradeWiseMappingId(Integer gradeWiseMappingId) {
		this.gradeWiseMappingId = gradeWiseMappingId;
	}

	public Integer getGradeId() {
		return gradeId;
	}

	public void setGradeId(Integer gradeId) {
		this.gradeId = gradeId;
	}

	public Integer getRoleId() {
		return roleId;
	}

	public void setRoleId(Integer roleId) {
		this.roleId = roleId;
	}

	public Integer getProficiencyLevelId() {
		return proficiencyLevelId;
	}

	public void setProficiencyLevelId(Integer proficiencyLevelId) {
		this.proficiencyLevelId = proficiencyLevelId;
	}

	

	public Integer getCompetencyId() {
		return competencyId;
	}

	public void setCompetencyId(Integer competencyId) {
		this.competencyId = competencyId;
	}

	public String getFunctionalKeyAction() {
		return functionalKeyAction;
	}

	public void setFunctionalKeyAction(String functionalKeyAction) {
		this.functionalKeyAction = functionalKeyAction;
	}

	public String getFunctionalTraining() {
		return functionalTraining;
	}

	public void setFunctionalTraining(String functionalTraining) {
		this.functionalTraining = functionalTraining;
	}

	public String getBehavioralKeyAction() {
		return behavioralKeyAction;
	}

	public void setBehavioralKeyAction(String behavioralKeyAction) {
		this.behavioralKeyAction = behavioralKeyAction;
	}

	public String getBehavioralTraining() {
		return behavioralTraining;
	}

	public void setBehavioralTraining(String behavioralTraining) {
		this.behavioralTraining = behavioralTraining;
	}
	
	
	public String getCompetencyName() {
		return competencyName;
	}

	public void setCompetencyName(String competencyName) {
		this.competencyName = competencyName;
	}

	public String getClusterName() {
		return clusterName;
	}

	public void setClusterName(String clusterName) {
		this.clusterName = clusterName;
	}

	public String getClusterType() {
		return clusterType;
	}

	public void setClusterType(String clusterType) {
		this.clusterType = clusterType;
	}
	
	public String getGrade() {
		return grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}
	
	public Integer getDepartmentId() {
		return departmentId;
	}

	public void setDepartmentId(Integer departmentId) {
		this.departmentId = departmentId;
	}

	public String getDepartmentName() {
		return departmentName;
	}

	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}

	public CT_GradeWiseMapping(Integer gradeWiseMappingId, Integer gradeId, Integer roleId, Integer proficiencyLevelId,
								Integer competencyId, String functionalKeyAction, String functionalTraining,
								String behavioralKeyAction, String behavioralTraining, String competencyName, 
								String clusterName, String clusterType, String grade,
								String role, Integer departmentId, String departmentName)
    {
		this.gradeWiseMappingId = gradeWiseMappingId;
		this.gradeId = gradeId;
		this.roleId = roleId;
		this.proficiencyLevelId = proficiencyLevelId;
		this.competencyId = competencyId;		
		this.functionalKeyAction = functionalKeyAction;
		this.functionalTraining = functionalTraining;
		this.behavioralKeyAction = behavioralKeyAction;
		this.behavioralTraining = behavioralTraining;
		this.competencyName =competencyName;
		this.clusterName = clusterName;
		this.clusterType = clusterType;
		this.grade = grade;
		this.role = role;
		this.departmentId = departmentId;
		this.departmentName = departmentName;
    }
	
	

	public CT_GradeWiseMapping(Integer competencyId, Integer gradeId, String competencyName,
			String clusterName, Integer departmentId) {
		this.competencyId = competencyId;
		this.gradeId = gradeId;
		this.competencyName = competencyName;
		this.clusterName = clusterName;
		this.departmentId = departmentId;
	}

	public CT_GradeWiseMapping() {
		// TODO Auto-generated constructor stub
	}
	
	
    
    
    
}
