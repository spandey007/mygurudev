package com.infocepts.otc.entities;

 
import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.infocepts.otc.utilities.LoadConstant;
 
@Entity
@Table(catalog=LoadConstant.otc,schema="[dbo]",name="tsitem")
@SqlResultSetMapping(
      name = "detailed_tsitem",
      classes = {
          @ConstructorResult(
              targetClass = TimesheetItem.class,
              columns = {
                  @ColumnResult(name = "tsitemId"),
                  @ColumnResult(name = "timesheetId"),
                  @ColumnResult(name = "itemType"),
                  @ColumnResult(name = "taskId"),
                  @ColumnResult(name = "approvalStatus"),
                  @ColumnResult(name = "approvalNotes"),                  
                  @ColumnResult(name = "approvalDate", type=Date.class),
                  @ColumnResult(name = "approvedBy"),                  
                  @ColumnResult(name = "projectName"),
                  @ColumnResult(name = "projectId"),
                  @ColumnResult(name = "submitted"),
        		  @ColumnResult(name = "taskName"),
                  @ColumnResult(name = "taskDuration", type=Float.class),
                  @ColumnResult(name = "taskActualWork", type=Float.class),
                  @ColumnResult(name = "taskStartDate", type=Date.class),
                  @ColumnResult(name = "taskEndDate", type=Date.class),
                  @ColumnResult(name = "nonWorkItemName"),
                  @ColumnResult(name = "periodId"),
                  @ColumnResult(name = "associateName"),
                  @ColumnResult(name = "associateId"),
                  @ColumnResult(name = "bAllocation", type=BigDecimal.class),
                  @ColumnResult(name = "nbAllocation", type=BigDecimal.class),
                  @ColumnResult(name = "bbAllocation", type=BigDecimal.class),
                  @ColumnResult(name = "pmApprovalStatus"),
                  @ColumnResult(name = "tshoursCount"),
                  @ColumnResult(name = "taskHierarchy", type=String.class),
        		  @ColumnResult(name = "createdBy"),	
                  @ColumnResult(name = "createdDate", type=Date.class),
                  @ColumnResult(name = "modifiedBy"),	
                  @ColumnResult(name = "modifiedDate", type=Date.class)
              }
          )
      }
)
@NamedNativeQueries({
	@NamedNativeQuery(
            name    =   "getTimesheetItemByTimesheetId",
            query   =   "select tsitem.*,"+
	            		" CASE WHEN CHARINDEX('.', task.wbs) > 0"+
		    				" THEN (Select TOP 1 title FROM " + LoadConstant.otc + ".[dbo].[taskCenter] WHERE wbs = (SELECT LEFT(task.wbs, CHARINDEX('.', REVERSE(task.wbs))-1)) AND projectId = task.projectId)"+
		    				" ELSE ''"+
						" END as taskHierarchy,"+
            			" cast(p.title as varchar(max)) as projectName, p.itemId as projectId, cast(task.title as varchar(max)) as taskName, s.submitted as submitted, task.actualWork as taskActualWork, task.Duration as taskDuration, task.StartDate as taskStartDate, task.DueDate as taskEndDate, tsnw.taskName as nonWorkItemName, ts.periodId as periodId, ts.uid as associateId, cast(r.title as varchar(max)) as associateName" +
	    				" FROM " + LoadConstant.otc + ".[dbo].tsitem tsitem" +
	    				" left join " + LoadConstant.otc + ".[dbo].tstimesheet ts on ts.timesheetId=tsitem.timesheetId" +	
	    				" left join " + LoadConstant.otc + ".[dbo].taskCenter task on task.taskId=tsitem.taskId" +
	    				" left join " + LoadConstant.infomaster + ".[dbo].project p on p.itemId=task.ProjectID" +
	    				" left join " + LoadConstant.infomaster + ".[dbo].resource r on r.uid=ts.uid" +
	    				" left join " + LoadConstant.otc + ".[dbo].tssubmit s on (s.timesheetId=tsitem.timesheetId AND s.projectId=p.itemId)" +
	    				" left join " + LoadConstant.otc + ".[dbo].tsnonwork tsnw on tsnw.tsnonworkId=tsitem.taskId" +
            			" WHERE tsitem.timesheetId = :timesheetId" +
            			" order by projectName",
                        resultClass=TimesheetItem.class,  resultSetMapping = "detailed_tsitem"                       		
    ),
    @NamedNativeQuery(
            name    =   "getTimesheetItemByPeriodIdAndUserId",
            query   =   "select tsitem.*,"+
	            		" CASE WHEN CHARINDEX('.', task.wbs) > 0"+
		    				" THEN (Select TOP 1 title FROM " + LoadConstant.otc + ".[dbo].[taskCenter] WHERE wbs = (SELECT LEFT(task.wbs, CHARINDEX('.', REVERSE(task.wbs))-1)) AND projectId = task.projectId)"+
		    				" ELSE ''"+
						" END as taskHierarchy,"+
            			" cast(p.title as varchar(max)) as projectName, p.itemId as projectId," +
        				"cast(task.title as varchar(max)) as taskName, s.submitted as submitted, task.actualWork as taskActualWork, task.Duration as taskDuration, task.StartDate as taskStartDate, task.DueDate as taskEndDate, tsnw.taskName as nonWorkItemName," +
        				"ts.periodId as periodId, r.uid as associateId, cast(r.title as varchar(max)) as associateName," +
        				"(SELECT TOP 1 a.alcFte from " + LoadConstant.otc + ".[dbo].[monthly_allocation] a" +
        					" where a.projectId = p.itemId and (a.uid = r.uid) and (a.alcType = 1)" + // billable Allocation
        					" and ((a.prdName = concat(FORMAT(per.PERIOD_START, 'MMM'),' ', FORMAT(per.PERIOD_START, 'yyyy')))) order by a.alcType) as bAllocation, " +
        				"(SELECT TOP 1 a.alcFte from " + LoadConstant.otc + ".[dbo].[monthly_allocation] a" +
        					" where a.projectId = p.itemId and (a.uid = r.uid) and (a.alcType = 4)" + // billed buffer Allocation
        					" and ((a.prdName = concat(FORMAT(per.PERIOD_START, 'MMM'),' ', FORMAT(per.PERIOD_START, 'yyyy')))) order by a.alcType) as bbAllocation, " +
    					"(SELECT TOP 1 a.alcFte from " + LoadConstant.otc + ".[dbo].[monthly_allocation] a" +
        					" where a.projectId = p.itemId and (a.uid = r.uid) and (a.alcType != 1 or a.alcType != 4)" + // non-billable Allocation
        					" and ((a.prdName = concat(FORMAT(per.PERIOD_START, 'MMM'),' ', FORMAT(per.PERIOD_START, 'yyyy')))) order by a.alcType) as nbAllocation, " +        					
        				"(select ta.pmApprovalStatus from " + LoadConstant.otc + ".[dbo].[tsapproval] ta where ta.projectId = p.itemId and ta.month = FORMAT(per.PERIOD_START, 'MM') and ta.year = FORMAT(per.PERIOD_START, 'yyyy')) as pmApprovalStatus," +	
        				"(SELECT count(*) from " + LoadConstant.otc + ".[dbo].[tsitemhours] tsh where tsh.tsitemId = tsitem.tsitemId) as tshoursCount" +
        				" FROM " + LoadConstant.otc + ".[dbo].tsitem tsitem" +
	    				" left join " + LoadConstant.otc + ".[dbo].tstimesheet ts on ts.timesheetId=tsitem.timesheetId" +	 
	    				" left join " + LoadConstant.otc + ".[dbo].tsperiod per on per.period_id=ts.periodId" +
	    				" left join " + LoadConstant.otc + ".[dbo].taskCenter task on task.taskId=tsitem.taskId" +
	    				" left join " + LoadConstant.infomaster + ".[dbo].project p on p.itemId=task.ProjectID" +
	    				" left join " + LoadConstant.infomaster + ".[dbo].resource r on r.uid=ts.uid" +
	    				" left join " + LoadConstant.otc + ".[dbo].tssubmit s on (s.timesheetId=tsitem.timesheetId AND s.projectId=p.itemId)" +
	    				" left join " + LoadConstant.otc + ".[dbo].tsnonwork tsnw on tsnw.tsnonworkId=tsitem.taskId" +
	    				" WHERE ts.periodId = :periodId" +
	    				" AND ts.uid = :uid" +
	    				" order by task.title",
                        resultClass=TimesheetItem.class,  resultSetMapping = "detailed_tsitem"                       		
    ),
    // Return all the tasks added by user in the last period for which timesheet was filled
    // Only fetch the tasks with task start date <= period start date
    // Only fetch the tasks with task due date >= period start date
    // Eliminate the tasks for projects closed before the period start date
    @NamedNativeQuery(
            name    =   "getLastAddedTimesheetItemByUserId",
            query   =   "select tsitem.*,"+
	            		" CASE WHEN CHARINDEX('.', task.wbs) > 0"+
		    				" THEN (Select TOP 1 title FROM " + LoadConstant.otc + ".[dbo].[taskCenter] WHERE wbs = (SELECT LEFT(task.wbs, CHARINDEX('.', REVERSE(task.wbs))-1)) AND projectId = task.projectId)"+
		    				" ELSE ''"+
						" END as taskHierarchy,"+
            			" cast(p.title as varchar(max)) as projectName, p.itemId as projectId," +
            			"cast(task.title as varchar(max)) as taskName, s.submitted as submitted, task.actualWork as taskActualWork, task.Duration as taskDuration, task.StartDate as taskStartDate, task.DueDate as taskEndDate, tsnw.taskName as nonWorkItemName," +
            			"ts.periodId as periodId, r.uid as associateId, cast(r.title as varchar(max)) as associateName," +
            			"(SELECT TOP 1 a.alcFte from " + LoadConstant.otc + ".[dbo].[monthly_allocation] a" +
    						" where a.projectId = p.itemId and (a.uid = r.uid) and (a.alcType = 1)" + // billable Allocation
    						" and ((a.prdName = concat(FORMAT(per.PERIOD_START, 'MMM'),' ', FORMAT(per.PERIOD_START, 'yyyy')))) order by a.alcType) as bAllocation, " +
    					"(SELECT TOP 1 a.alcFte from " + LoadConstant.otc + ".[dbo].[monthly_allocation] a" +
        					" where a.projectId = p.itemId and (a.uid = r.uid) and (a.alcType = 4)" + // billed buffer Allocation
        					" and ((a.prdName = concat(FORMAT(per.PERIOD_START, 'MMM'),' ', FORMAT(per.PERIOD_START, 'yyyy')))) order by a.alcType) as bbAllocation, " +
    					"(SELECT TOP 1 a.alcFte from " + LoadConstant.otc + ".[dbo].[monthly_allocation] a" +
    						" where a.projectId = p.itemId and (a.uid = r.uid) and (a.alcType != 1 or a.alcType != 4)" + // non-billable Allocation
    						" and ((a.prdName = concat(FORMAT(per.PERIOD_START, 'MMM'),' ', FORMAT(per.PERIOD_START, 'yyyy')))) order by a.alcType) as nbAllocation, " +
            			"(select ta.pmApprovalStatus from " + LoadConstant.otc + ".[dbo].[tsapproval] ta "+
            				"where ta.projectId = p.itemId and ta.month = FORMAT((SELECT per_current.PERIOD_START from " + LoadConstant.otc + ".[dbo].tsperiod per_current where per_current.period_id = :periodId), 'MM') and ta.year = FORMAT((SELECT per_current.PERIOD_START from " + LoadConstant.otc + ".[dbo].tsperiod per_current where per_current.period_id = :periodId), 'yyyy')) as pmApprovalStatus," +	
            			"0 as tshoursCount" + // As this is a newly copied task, no hours are filled against this task
            			" FROM " + LoadConstant.otc + ".[dbo].tsitem tsitem" +
	    				" left join " + LoadConstant.otc + ".[dbo].tstimesheet ts on ts.timesheetId=tsitem.timesheetId" +
	    				" left join " + LoadConstant.otc + ".[dbo].tsperiod per on per.period_id=ts.periodId" +
	    				" left join " + LoadConstant.otc + ".[dbo].taskCenter task on task.taskId=tsitem.taskId" +
	    				" left join " + LoadConstant.infomaster + ".[dbo].project p on p.itemId=task.projectId" +
	    				" left join " + LoadConstant.infomaster + ".[dbo].resource r on r.uid=ts.uid" +
	    				" left join " + LoadConstant.otc + ".[dbo].tssubmit s on (s.timesheetId=tsitem.timesheetId AND s.projectId=p.itemId)" +
	    				" left join " + LoadConstant.otc + ".[dbo].tsnonwork tsnw on tsnw.tsnonworkId=tsitem.taskId" +
	    				" WHERE ts.periodId = (select TOP 1 ts1.periodId from " + LoadConstant.otc + ".[dbo].tsitem tsitem1 LEFT JOIN " + LoadConstant.otc + ".[dbo].tstimesheet ts1 on ts1.timesheetId=tsitem1.timesheetId WHERE ts1.uid = :uid and ts1.periodId < :periodId ORDER BY ts1.periodId DESC)" +
	    				//" AND ((task.StartDate <= per.PERIOD_START AND task.DueDate >= per.PERIOD_START) OR (task.StartDate >= per.PERIOD_START AND task.StartDate <= per.PERIOD_END))" + // Only tasks assigned within the period start and end date date are copied
	    				" and p.state = 'Active'" + 	// project is active
	    				" AND ts.uid = :uid" +
	    				//" AND (cp.[CMH_FTES] is not null)" + // rkj added 5 Apr to avoid copying tasks from projects where associates allocation is removed 
	    				" order by task.title",
                        resultClass=TimesheetItem.class,  resultSetMapping = "detailed_tsitem"                       		
    ),
    // Return all the tasks added by all team members in the given timesheet period
    @NamedNativeQuery(
            name    =   "getTimesheetItemByPeriodIdAndProjectId",
            query   =   "select tsitem.*,"+
            			" CASE WHEN CHARINDEX('.', task.wbs) > 0"+
            				" THEN (Select TOP 1 title FROM " + LoadConstant.otc + ".[dbo].[taskCenter] WHERE wbs = (SELECT LEFT(task.wbs, CHARINDEX('.', REVERSE(task.wbs))-1)) AND projectId = task.projectId)"+
            				" ELSE ''"+
        				" END as taskHierarchy,"+
            			" cast(p.title as varchar(max)) as projectName, p.itemId as projectId," +
        				"cast(task.title as varchar(max)) as taskName, s.submitted as submitted, task.actualWork as taskActualWork, task.Duration as taskDuration, task.StartDate as taskStartDate, task.DueDate as taskEndDate, tsnw.taskName as nonWorkItemName," +
        				"ts.periodId as periodId, r.uid as associateId, cast(r.title as varchar(max)) as associateName," +
        				"(SELECT TOP 1 a.alcFte from " + LoadConstant.otc + ".[dbo].[monthly_allocation] a" +
							" where a.projectId = p.itemId and (a.uid = r.uid) and (a.alcType = 1)" + // billable Allocation
							" and ((a.prdName = concat(FORMAT(per.PERIOD_START, 'MMM'),' ', FORMAT(per.PERIOD_START, 'yyyy')))) order by a.alcType) as bAllocation, " +
	        			"(SELECT TOP 1 a.alcFte from " + LoadConstant.otc + ".[dbo].[monthly_allocation] a" +
								" where a.projectId = p.itemId and (a.uid = r.uid) and (a.alcType = 4)" + // billed buffer Allocation
								" and ((a.prdName = concat(FORMAT(per.PERIOD_START, 'MMM'),' ', FORMAT(per.PERIOD_START, 'yyyy')))) order by a.alcType) as bbAllocation, " +
						"(SELECT TOP 1 a.alcFte from " + LoadConstant.otc + ".[dbo].[monthly_allocation] a" +
							" where a.projectId = p.itemId and (a.uid = r.uid) and (a.alcType != 1 or a.alcType != 4)" + // non-billable Allocation
							" and ((a.prdName = concat(FORMAT(per.PERIOD_START, 'MMM'),' ', FORMAT(per.PERIOD_START, 'yyyy')))) order by a.alcType) as nbAllocation, " +
        				"(select ta.pmApprovalStatus from " + LoadConstant.otc + ".[dbo].[tsapproval] ta where ta.projectId = p.itemId and ta.month = FORMAT(per.PERIOD_START, 'MM') and ta.year = FORMAT(per.PERIOD_START, 'yyyy')) as pmApprovalStatus," +	
        				"(SELECT count(*) from " + LoadConstant.otc + ".[dbo].[tsitemhours] tsh where tsh.tsitemId = tsitem.tsitemId) as tshoursCount" +
        				" FROM " + LoadConstant.otc + ".[dbo].tsitem tsitem" +
	    				" left join " + LoadConstant.otc + ".[dbo].tstimesheet ts on ts.timesheetId=tsitem.timesheetId" +
	    				" left join " + LoadConstant.otc + ".[dbo].tsperiod per on per.period_id=ts.periodId" +
	    				" left join " + LoadConstant.otc + ".[dbo].taskCenter task on task.taskId=tsitem.taskId" +
	    				" left join " + LoadConstant.infomaster + ".[dbo].project p on p.itemId=task.ProjectID" +
	    				" left join " + LoadConstant.infomaster + ".[dbo].resource r on r.uid=ts.uid" +
	    				" left join " + LoadConstant.otc + ".[dbo].tssubmit s on (s.timesheetId=tsitem.timesheetId AND s.projectId=p.itemId)" +
	    				" left join " + LoadConstant.otc + ".[dbo].tsnonwork tsnw on tsnw.tsnonworkId=tsitem.taskId" +
	    				" WHERE ts.periodId = :periodId" +
	    				" AND p.itemId = :projectId" +
	    				" order by task.title",
                        resultClass=TimesheetItem.class,  resultSetMapping = "detailed_tsitem"                       		
    )
	
    
})
public class TimesheetItem {
 
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer tsitemId;
 	 
	@ManyToOne
	@JoinColumn(name="timesheetId")
	private Timesheet timesheet;
	
	private Integer itemType;
	private Integer taskId;
 	
 	@Transient
	private String taskName;	// Transient field for task reference
 	
 	@Transient
	private String taskHierarchy;	// Transient field for task reference
 	
 	@Transient
	private String projectName;	// Transient field for project reference
 	
 	@Transient
	private String associateName;	// Transient field for associate name reference

 	@Transient
	private Integer associateId;	// Transient field for associate name reference 	
 	
 	@Transient
 	private Float taskDuration; // Transient field for task duration
 	
 	@Transient
 	private Float taskWork; // Transient field for task work
 	
 	@Transient
 	private Float taskActualWork; // Transient field for task actual work
 	
 	@Transient
 	private Date taskStartDate; // Transient field for task start date
 	
 	@Transient
 	private Date taskEndDate; // Transient field for task end date
 	
 	@Transient
	private Integer projectId;	// Transient field for project reference
 	
 	@Transient
	private Boolean submitted;	// Transient field for project submit status by associate
 	
 	@Transient
	private BigDecimal bAllocation; // Transient field for associates allocation on project
 	
 	@Transient
	private BigDecimal nbAllocation; // Transient field for associates allocation on project
 	
 	@Transient
	private BigDecimal bbAllocation; // Transient field for associates allocation on project
	
 	@Transient
	private Integer pmApprovalStatus;  // Transient field for pm approval status
 	
 	@Transient
 	private Integer tshoursCount;  // Transient field to check the tsitemhours present for the tsitem
 	
 	@Transient
 	private Date projectAllocBillableEndDate; // To check project billable end date of each item while populating on timesheet.
 	
 	@Transient
 	private Date projectAllocNonBillableEndDate; // To check project non-billable end date of each item while populating on timesheet.
 	
 	@Transient
 	private boolean projectAllocEndedForBillable; // To check project end date of each item while populating on timesheet.
 	@Transient
 	private boolean projectAllocEndedForNonBillable;
 	
 	private Integer approvalStatus;
 	private String approvalNotes; 	
 	private Date approvalDate;
 	private Integer approvedBy;
 	
	private Integer createdBy;	
	private Date createdDate;	
	private Integer modifiedBy;
	private Date modifiedDate;

	public Integer getTsitemId() {
		return tsitemId;
	}

	public void setTsitemId(Integer tsitemId) {
		this.tsitemId = tsitemId;
	}

	public Timesheet getTimesheet() {
		return timesheet;
	}

	public void setTimesheet(Timesheet timesheet) {
		this.timesheet = timesheet;
	}
	
	public Integer getItemType() {
		return itemType;
	}

	public void setItemType(Integer itemType) {
		this.itemType = itemType;
	}

	public Integer getTaskId() {
		return taskId;
	}

	public void setTaskId(Integer taskId) {
		this.taskId = taskId;
	}
	
	public Float getTaskDuration() {
		return taskDuration;
	}

	public void setTaskDuration(Float taskDuration) {
		this.taskDuration = taskDuration;
	}
	
	public Float getTaskWork() {
		return taskWork;
	}

	public void setTaskWork(Float taskWork) {
		this.taskWork = taskWork;
	}
	
	public Float getTaskActualWork() {
		return taskActualWork;
	}

	public void setTaskActualWork(Float taskActualWork) {
		this.taskActualWork = taskActualWork;
	}

	public Date getTaskStartDate() {
		return taskStartDate;
	}

	public void setTaskStartDate(Date taskStartDate) {
		this.taskStartDate = taskStartDate;
	}

	public Date getTaskEndDate() {
		return taskEndDate;
	}

	public void setTaskEndDate(Date taskEndDate) {
		this.taskEndDate = taskEndDate;
	}

	public String getTaskName() {
		return taskName;
	}

	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	
	@Transient	
	public String getAssociateName() {
		return associateName;
	}

	public void setAssociateName(String associateName) {
		this.associateName = associateName;
	}

	@Transient	
	public Integer getAssociateId() {
		return associateId;
	}

	public void setAssociateId(Integer associateId) {
		this.associateId = associateId;
	}	
	
	public Integer getProjectId() {
		return projectId;
	}
	public void setProjectId(Integer projectId) {
		this.projectId = projectId;
	}	
	
	public Boolean getSubmitted() {
		return submitted;
	}

	public void setSubmitted(Boolean submitted) {
		this.submitted = submitted;
	}

	public Integer getApprovalStatus() {
		return approvalStatus;
	}

	public void setApprovalStatus(Integer approvalStatus) {
		this.approvalStatus = approvalStatus;
	}
	
	public String getApprovalNotes() {
		return approvalNotes;
	}

	public void setApprovalNotes(String approvalNotes) {
		this.approvalNotes = approvalNotes;
	}
	
	public Date getApprovalDate() {
		return approvalDate;
	}

	public void setApprovalDate(Date approvalDate) {
		this.approvalDate = approvalDate;
	}

	public Integer getApprovedBy() {
		return approvedBy;
	}

	public void setApprovedBy(Integer approvedBy) {
		this.approvedBy = approvedBy;
	}	
	
	@Transient
	public BigDecimal getbAllocation() {
		return bAllocation;
	}

	public void setbAllocation(BigDecimal bAllocation) {
		this.bAllocation = bAllocation;
	}

	@Transient
	public BigDecimal getNbAllocation() {
		return nbAllocation;
	}

	public void setNbAllocation(BigDecimal nbAllocation) {
		this.nbAllocation = nbAllocation;
	}
	
	public BigDecimal getBbAllocation() {
		return bbAllocation;
	}

	public void setBbAllocation(BigDecimal bbAllocation) {
		this.bbAllocation = bbAllocation;
	}

	@Transient
	public Integer getPmApprovalStatus() {
		return pmApprovalStatus;
	}
	
	public void setPmApprovalStatus(Integer pmApprovalStatus) {
		this.pmApprovalStatus = pmApprovalStatus;
	}
	
	@Transient
	public Integer getTshoursCount() {
		return tshoursCount;
	}
	public void setTshoursCount(Integer tshoursCount) {
		this.tshoursCount = tshoursCount;
	}
	
	public String getTaskHierarchy() {
		return taskHierarchy;
	}

	public void setTaskHierarchy(String taskHierarchy) {
		this.taskHierarchy = taskHierarchy;
	}
	
	public Integer getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public Integer getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public Date getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}	

	public TimesheetItem() {
	};
	
			
	public TimesheetItem(Integer tsitemId, Integer timesheetId, Integer itemType, 
			Integer taskId, Integer approvalStatus, String approvalNotes, Date approvalDate, Integer approvedBy,
    		String projectName, Integer projectId, Boolean submitted,
    		String taskName, Float taskDuration, Float taskActualWork, 
    		Date taskStartDate, Date taskEndDate, String nonWorkItemName, Integer periodId, String associateName, Integer associateId,
    		BigDecimal bAllocation, BigDecimal nbAllocation, BigDecimal bbAllocation, Integer pmApprovalStatus, Integer tshoursCount, String taskHierarchy
    		,Integer createdBy, Date createdDate,
    		Integer modifiedBy, Date modifiedDate) {
		
		this.tsitemId = tsitemId;
        this.timesheet = new Timesheet();
        this.timesheet.setTimesheetId(timesheetId);
        this.timesheet.setPeriodId(periodId);
        this.timesheet.setUid(associateId);
        
        this.itemType = itemType;
        this.taskId = taskId;        
        this.approvalStatus = approvalStatus;
        this.approvalNotes = approvalNotes;
        this.approvalDate = approvalDate;
        this.approvedBy = approvedBy;
        this.projectName = projectName;
        this.projectId = projectId;
        // By Default all the timesheets before the submitCutOffPeriodId defined in load constants file are considered as submitted
        if(submitted == null) submitted = false;
        if(pmApprovalStatus == null) pmApprovalStatus = 0;
        if(LoadConstant.submitCutOffPeriodId >= periodId)
        {
        	this.submitted = true;
        	this.pmApprovalStatus = 1;
        }
        else
        {
        	this.submitted = submitted;
        	this.pmApprovalStatus = pmApprovalStatus;
        }
        this.taskDuration = taskDuration;
        this.taskWork = taskWork;
        this.taskActualWork = taskActualWork;
        this.taskStartDate = taskStartDate;
        this.taskEndDate = taskEndDate;
        
        if(itemType == null) itemType = 1;
        if(itemType == 1)
        {
        	this.taskName = taskName;
        }
        else
        {
        	this.taskName = nonWorkItemName;
        }
        this.associateId = associateId;        
        this.associateName = associateName;
        this.bAllocation = bAllocation;
        this.nbAllocation = nbAllocation;
        this.bbAllocation = bbAllocation;
        
        this.tshoursCount = tshoursCount;
        this.taskHierarchy = taskHierarchy;
        
        this.createdBy = createdBy;
        this.createdDate = createdDate;
        this.modifiedBy = modifiedBy;
        this.modifiedDate = modifiedDate;
    }

	public Date getProjectAllocBillableEndDate() {
		return projectAllocBillableEndDate;
	}

	public void setProjectAllocBillableEndDate(Date projectAllocBillableEndDate) {
		this.projectAllocBillableEndDate = projectAllocBillableEndDate;
	}

	public Date getProjectAllocNonBillableEndDate() {
		return projectAllocNonBillableEndDate;
	}

	public void setProjectAllocNonBillableEndDate(Date projectAllocNonBillableEndDate) {
		this.projectAllocNonBillableEndDate = projectAllocNonBillableEndDate;
	}

	public Boolean getProjectAllocEndedForBillable() {
		return projectAllocEndedForBillable;
	}

	public void setProjectAllocEndedForBillable(boolean projectAllocEndedForBillable) {
		this.projectAllocEndedForBillable = projectAllocEndedForBillable;
	}

	public Boolean getProjectAllocEndedForNonBillable() {
		return projectAllocEndedForNonBillable;
	}

	public void setProjectAllocEndedForNonBillable(boolean projectAllocEndedForNonBillable) {
		this.projectAllocEndedForNonBillable = projectAllocEndedForNonBillable;
	}
}
