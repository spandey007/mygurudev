package com.infocepts.otc.controllers;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;


import java.util.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.infocepts.otc.entities.InfoTravelDetail;
import com.infocepts.otc.repositories.InfoTravelDetailRepository;
import com.infocepts.otc.services.TimesheetService;

@RestController
@RequestMapping(value="/infotraveldetail",headers="referer")
public class InfoTravelDetailController {

	@Autowired
	InfoTravelDetailRepository infoTravelDetailRepository;
	
	@PersistenceContext
    private EntityManager manager;
	
	@Autowired
	TimesheetService service;
	
	
	final Logger logger = Logger.getLogger(InfoTravelDetailController.class.getName());
	
	@RequestMapping(method=RequestMethod.POST)
	public InfoTravelDetail addInfoTravelDetail(@RequestBody InfoTravelDetail infoTravelDetail){
	
		infoTravelDetail.setInfoTravelDetailId(null);
			try {
				infoTravelDetailRepository.save(infoTravelDetail);
			} catch (Exception e) {
				logger.info(String.format("exception - ", e));
			}
		return infoTravelDetail;
	}
	
	@RequestMapping(method=RequestMethod.GET)
	public List<InfoTravelDetail> getInfoTravelDetail(@RequestParam(value = "infoTravelId", defaultValue = "0") Integer infoTravelId			
			,HttpServletRequest request){
		List<InfoTravelDetail> list = null;
		try{
			 if(infoTravelId != 0){
				 logger.info("here in infotravel section");
				 list = infoTravelDetailRepository.findById(infoTravelId);
			 }
			 else{
				 list = infoTravelDetailRepository.findAll();
			 }
			 
		 }
		 catch(Exception e){
			 logger.info(String.format("exception - ", e));
		 }
		return list;
	}
	
	@RequestMapping(value="/{infoTravelDetailId}",method=RequestMethod.GET)
	public InfoTravelDetail getInfoTravelDetail(@PathVariable Integer infoTravelDetailId){
		InfoTravelDetail infoTravelDetail = null;
		infoTravelDetail = infoTravelDetailRepository.findOne(infoTravelDetailId);
		return infoTravelDetail;
	}
	
	@RequestMapping(value="/{infoTravelDetailId}", method=RequestMethod.PUT)
	public InfoTravelDetail updateInfoTravelDetail(@PathVariable Integer infoTravelDetailId,  @RequestBody InfoTravelDetail updatedInfoTravelDetail){
		updatedInfoTravelDetail.setInfoTravelDetailId(infoTravelDetailId);
			infoTravelDetailRepository.save(updatedInfoTravelDetail);
		
		return updatedInfoTravelDetail;
	}
	
	@RequestMapping(value="/{infoTravelDetailId}",method=RequestMethod.DELETE)
	public void deleteInfoTravelDetail(@PathVariable Integer infoTravelDetailId){
			infoTravelDetailRepository.delete(infoTravelDetailId);
		
	}

}
