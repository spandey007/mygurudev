package com.infocepts.otc.utilities;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.VerticalAlignment;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

import com.infocepts.otc.entities.TimesheetHours;
import com.infocepts.otc.entities.TimesheetPeriods;

public abstract class AbstractTimesheetFileHandling extends Object {

	private static final String PATH_TO_TSEXCEL_TEMPLATE = "/templates/timesheet/timesheetExport.xlsx";
	private static final Logger LOGGER = Logger.getLogger(AbstractTimesheetFileHandling.class.getName());
	public static final List<File> FILE_CACHE = new UniqueArrayList<>();

	public static synchronized File exportTimesheetToExcel(List<TimesheetPeriods> timesheetPeriodsList, List<TimesheetHours> tshoursByMonth,
			List<TimesheetHours> tshoursByUser, String projectTitle, String fileNameWithExtension) {
		File file = null;
		double totalBillableHours = 0.0;
		double totalNonBillableHours = 0.0;
		double totalNonworkHours = 0.0;
		double totalBillableAllocHours = 0.0;
		double totalNonBillableAllocHours = 0.0;
		double totalOfTotal = 0.0;
		
		int tsPeriodLength = timesheetPeriodsList.size();
		if (CollectionUtils.isNotEmpty(timesheetPeriodsList) && CollectionUtils.isNotEmpty(tshoursByMonth) && CollectionUtils.isNotEmpty(tshoursByUser)) {
			InputStream inputStream = AbstractTimesheetFileHandling.class.getResourceAsStream(PATH_TO_TSEXCEL_TEMPLATE);
			Path tempPath = null;
			try {
				/* Creating a temporary file which will be a duplicate of the original template
				so that we get to edit the fresh Template always.
				*/
				tempPath = Files.createTempFile("timesheetExport1", ".xlsx");
				Files.copy(inputStream, tempPath, StandardCopyOption.REPLACE_EXISTING);
			} catch (Exception e1) {
				LOGGER.log(Level.SEVERE, "Something went wrong while copying the template excel to temporary excel.", e1);
			}
			try(Workbook workbook = WorkbookFactory.create(tempPath.toFile())) {
				Sheet sheet = workbook.getSheetAt(0);
				Row rowNum = sheet.getRow(1);
				rowNum.getCell(2).setCellValue(projectTitle);						

				Row rowNum1 = sheet.getRow(3);						
				rowNum1.getCell(9).setCellValue(timesheetPeriodsList.get(0).getOtcString());
				rowNum1.getCell(12).setCellValue(timesheetPeriodsList.get(1).getOtcString());
				rowNum1.getCell(15).setCellValue(timesheetPeriodsList.get(2).getOtcString());
				rowNum1.getCell(18).setCellValue(timesheetPeriodsList.get(3).getOtcString());
				if (timesheetPeriodsList.size() == 5) {
					rowNum1.getCell(21).setCellValue(timesheetPeriodsList.get(4).getOtcString());
				}

				int rowIndex = 5;

				CellStyle cellStyle = workbook.createCellStyle();
				cellStyle.setAlignment(HorizontalAlignment.CENTER);
				cellStyle.setVerticalAlignment(VerticalAlignment.CENTER);
				for (TimesheetHours tsHours : tshoursByMonth) {
					Row newRow = sheet.createRow(++ rowIndex);
					newRow.setHeight((short)400);
					newRow.setRowStyle(cellStyle);

					// Creating cells for every new row.
					for (int index = 0; index <= 23; index ++) {
						newRow.createCell(index).setCellStyle(cellStyle);
					}

					newRow.getCell(0).setCellValue(tshoursByMonth.indexOf(tsHours) + 1);
					newRow.getCell(1).setCellValue(tsHours.getResourceName());

					//Calculation of total hours for all type
					BigDecimal billableHrs = tsHours.getBillableHrs();
					if (billableHrs != null) {
						totalBillableHours = totalBillableHours + billableHrs.doubleValue();
					}
					
					newRow.getCell(2).setCellValue(billableHrs.doubleValue());

					BigDecimal nonBillableHrs = tsHours.getBillableHrs();
					if (nonBillableHrs != null) {
						totalNonBillableHours = totalNonBillableHours + nonBillableHrs.doubleValue();
					}
					
					newRow.getCell(3).setCellValue(nonBillableHrs.doubleValue());
					
					BigDecimal nonWorkHrs = tsHours.getBillableHrs();
					if (nonWorkHrs != null) {
						totalNonworkHours = totalNonworkHours + nonWorkHrs.doubleValue();
					}
					
					newRow.getCell(4).setCellValue(nonWorkHrs.doubleValue());
										
					double totalWorkedHours = 0.0;
					if (tsHours.getTotalWorkedHrs() != null) {
						totalWorkedHours = tsHours.getTotalWorkedHrs().doubleValue();
					}	
					
					totalOfTotal = totalOfTotal + totalWorkedHours;				
					newRow.getCell(5).setCellValue(totalWorkedHours);
										
					Float billableALcHrs = tsHours.getBillableAllocHrs();
					if (billableALcHrs != null) {
						totalBillableAllocHours = totalBillableAllocHours + billableALcHrs.doubleValue();
					}
					
					newRow.getCell(6).setCellValue(billableALcHrs);	
										
					Float nonBillableALcHrs = tsHours.getNonBillableAllocHrs();
					if (billableALcHrs != null) {
						totalNonBillableAllocHours = totalNonBillableAllocHours + nonBillableALcHrs.doubleValue();
					}	
					
					newRow.getCell(7).setCellValue(nonBillableALcHrs);
					
					//Calculation of Total Billable and Non-Billable Hours
					Float billAlcHrs = tsHours.getBillableAllocHrs();
					Float nonBillAlcHrs = tsHours.getNonBillableAllocHrs();						
					BigDecimal totalAllocatedHrs = BigDecimal.valueOf(Float.sum(billAlcHrs,nonBillAlcHrs));

					//Calculation of Total Allocated Billable and Non-Billable Hours
					BigDecimal billHrs = tsHours.getBillableHrs();
					BigDecimal nonBillHrs = tsHours.getNonBillableHrs();						
					BigDecimal actualTotalHrs = billHrs.add(nonBillHrs);														

					//Calculation of Total Difference between Allocation Hrs (B + NB) - Timesheet Hrs (B + NB) 
					BigDecimal hrsDifference = totalAllocatedHrs.subtract(actualTotalHrs);
					
					newRow.getCell(8).setCellValue(hrsDifference.doubleValue());

					/*We are doing these changes because the weekly hours are fetched in contiguous manner.
					 * However, We need to set data row wise in excel sheets so we have to make sure that
					 * we set the data week wise for every row in excel. As mentioned in below if-else statement
					 * there can be either 4 or 5 weeks in a month, So based upon the week count we will create
					 * sub lists from actual data list for each week.
					 * */
					List<TimesheetHours> subList = null;

					if (tsPeriodLength == LoadConstant.TS_FOUR_WEEKS) {
						if (tshoursByUser.size() >= LoadConstant.TS_FOUR_WEEKS) {
							subList = tshoursByUser.subList(0, 4);
						}
					} else if (tsPeriodLength == LoadConstant.TS_FIVE_WEEKS) {
						if (tshoursByUser.size() >= LoadConstant.TS_FIVE_WEEKS) {
							subList = tshoursByUser.subList(0, 5);
						}
					}
					
					if (subList == null) {
						subList = tshoursByUser;
					}
					// This is the starting cell from where we're going to set the weekly hours.
					int initCellNum = 9;
                       
					for (TimesheetHours tsHour : subList) {
						newRow.getCell(initCellNum ++).setCellValue(tsHour.getBillableHrs().doubleValue());
						newRow.getCell(initCellNum ++).setCellValue(tsHour.getNonBillableHrs().doubleValue());
						newRow.getCell(initCellNum ++).setCellValue(tsHour.getNonWorkHours());
					}
					subList.clear();
				}
				
				String hoursCal = "Diff = Allocation Hrs (B + NB) - Timesheet Hrs (B + NB)";
				
				Row row = sheet.createRow(tshoursByMonth.size() + 7);
				row.setHeight((short)400);
				row.setRowStyle(cellStyle);
				row.createCell(0).setCellValue(hoursCal);
				row.createCell(2).setCellValue(totalBillableHours);
				row.createCell(3).setCellValue(totalNonBillableHours);
				row.createCell(4).setCellValue(totalNonworkHours);
				row.createCell(5).setCellValue(totalOfTotal);
				row.createCell(6).setCellValue(totalBillableAllocHours);
				row.createCell(7).setCellValue(totalNonBillableAllocHours);
				
				try(FileOutputStream outputStream = new FileOutputStream(fileNameWithExtension)) {
					workbook.write(outputStream);
					file = new File(fileNameWithExtension);
				}
				
			} catch (Exception e) {
				LOGGER.log(Level.SEVERE, "Something went wrong while wrting excel file!", e);
			}
		}
		return file;
	}
}
