package com.infocepts.otc.controllers;

import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.mail.MessagingException;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.infocepts.otc.entities.ISow;
import com.infocepts.otc.entities.Invoices;
import com.infocepts.otc.entities.Pricing;
import com.infocepts.otc.repositories.PricingRepository;
import com.infocepts.otc.services.TimesheetService;
import com.infocepts.otc.utilities.InvoiceNoGenerator;
import com.infocepts.otc.utilities.LoadConstant;

@RestController
@RequestMapping("/pricing")
public class PricingController extends Object {
	private final Logger logger = Logger.getLogger(PricingController.class.getName());
	
	@Autowired
	TimesheetService service;
	
	@PersistenceContext(unitName="otc")
    private EntityManager entityManager;
	
	@Autowired
	private PricingRepository pricingRepository;
	
	@GetMapping
	public Pricing getAllPricing(@RequestParam(value = "cmsId", defaultValue = "0", required = false) Integer cmsId) {
			//return pricingRepository.findPricingForProject();
		Pricing pricing = null;
		 try{
			 if(cmsId != 0){
				 pricing = pricingRepository.findOne(cmsId);
			 }
		 }
		 catch(Exception e){
			 logger.log(Level.SEVERE, "Error for Pricing", e);
		 }
		 return pricing;
	}
	
	@RequestMapping(method=RequestMethod.POST)
	public Pricing addPricing(@RequestBody Pricing pricing, HttpServletRequest request) throws MessagingException{
	
		// Authorization for Admin, PMO
		
			try{
							
				pricing.setPricingId(null);
			 				pricingRepository.save(pricing);
				}catch(Exception e){
							logger.log(Level.SEVERE, "Error while saving Pricing", e); 
				}
					
		/*else
				{
					throw new IllegalArgumentException("Access Denied");
				}*/
 
		return pricing;
	}
	
	 @RequestMapping(value="/{pricingId}",method=RequestMethod.PUT)
	 public Pricing updatePricing(@RequestBody Pricing updatedPricing,@PathVariable Integer pricingId, HttpServletRequest request)throws MessagingException{
		 	  // Authorization for Admin, PMO and Legal
		    // if(service.isPmo() || service.isLegal() || service.isAdmin())
		 		//{ 
			try{
				updatedPricing.setPricingId(pricingId);
				 			pricingRepository.save(updatedPricing);  
			   }catch(Exception e){
							logger.log(Level.SEVERE, "Error while updating Pricing", e); 
			   }
			//}
		 	return updatedPricing;
	 }
}
