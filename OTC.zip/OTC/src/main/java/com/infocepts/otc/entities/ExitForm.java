package com.infocepts.otc.entities;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

import com.infocepts.otc.utilities.LoadConstant;

@Entity
@Table(catalog=LoadConstant.otc, schema="[dbo]",name="exitForm")
public class ExitForm {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	public Integer exitFormId;
	public Integer uId;
	public String supConsistentlyFair;
	public String supProvidedRecognition;
	public String supResolvedComplaints;
	public String supSensitiveToNeeds;
	public String supProvicedFeedbackOnPerformance;
	public String supReceptiveToOpenCommunication;
	public String supFollowedInfoCeptsPolicies;
	public String performanceReview;
	public String orientationProgram;
	public String compensation;
	public String careerDevelopmentPpportunities;
	public String recognitionOfWork;
	public String companyBenefits;
	public String rnrProgram;
	public String trainingAndCertification;
	public String healthAndSafety;
	public String appraisalProcess;
	public Integer brand;
	public Integer workEnvironment;
	public Integer workLocation;
	public Integer growthOpportunities;
	public Integer leadership;
	public Integer training;
	public Integer coWorkers;
	public String reApply;
	public String recommend;
	
    @Lob
	public String otherBenefits;
	public String preventFromLeaving;
	public Integer betterJobOpportunity;
	public Integer careerProgression;
	public Integer betterSalaryOutside;
	public Integer betterBenefits;
	public Integer difficultWorkRelationships;
	public Integer endOfContract;
	public Integer unsatisfactoryProbation;
	public Integer personalReasons;
	public Integer relocating;
	public Integer maternityReasons;
	public Integer familyCommitments;
	public Integer illHealth;
	public Integer redundancy;
	public Integer noOnsiteOpportunity;
	public Integer retirement;
	public Integer other;
	public Integer employeeId;
	public String title;
	public String otherState;
	
    @Lob
	public String elaborate;
	
    @Lob
    public String otherComments;
	
    @Lob
    public String commentsByHR;
	public Integer createdBy;
	public Date createdDate;

	
	public Integer getBetterJobOpportunity() {
		return betterJobOpportunity;
	}
	public void setBetterJobOpportunity(Integer betterJobOpportunity) {
		this.betterJobOpportunity = betterJobOpportunity;
	}
	public Integer getCareerProgression() {
		return careerProgression;
	}
	public void setCareerProgression(Integer careerProgression) {
		this.careerProgression = careerProgression;
	}
	public Integer getBetterSalaryOutside() {
		return betterSalaryOutside;
	}
	public void setBetterSalaryOutside(Integer betterSalaryOutside) {
		this.betterSalaryOutside = betterSalaryOutside;
	}
	public Integer getBetterBenefits() {
		return betterBenefits;
	}
	public void setBetterBenefits(Integer betterBenefits) {
		this.betterBenefits = betterBenefits;
	}
	public Integer getDifficultWorkRelationships() {
		return difficultWorkRelationships;
	}
	public void setDifficultWorkRelationships(Integer difficultWorkRelationships) {
		this.difficultWorkRelationships = difficultWorkRelationships;
	}
	public Integer getEndOfContract() {
		return endOfContract;
	}
	public void setEndOfContract(Integer endOfContract) {
		this.endOfContract = endOfContract;
	}
	public Integer getUnsatisfactoryProbation() {
		return unsatisfactoryProbation;
	}
	public void setUnsatisfactoryProbation(Integer unsatisfactoryProbation) {
		this.unsatisfactoryProbation = unsatisfactoryProbation;
	}
	public Integer getPersonalReasons() {
		return personalReasons;
	}
	public void setPersonalReasons(Integer personalReasons) {
		this.personalReasons = personalReasons;
	}
	public Integer getRelocating() {
		return relocating;
	}
	public void setRelocating(Integer relocating) {
		this.relocating = relocating;
	}
	public Integer getMaternityReasons() {
		return maternityReasons;
	}
	public void setMaternityReasons(Integer maternityReasons) {
		this.maternityReasons = maternityReasons;
	}
	public Integer getFamilyCommitments() {
		return familyCommitments;
	}
	public void setFamilyCommitments(Integer familyCommitments) {
		this.familyCommitments = familyCommitments;
	}
	public Integer getIllHealth() {
		return illHealth;
	}
	public void setIllHealth(Integer illHealth) {
		this.illHealth = illHealth;
	}
	public Integer getRedundancy() {
		return redundancy;
	}
	public void setRedundancy(Integer redundancy) {
		this.redundancy = redundancy;
	}
	public Integer getNoOnsiteOpportunity() {
		return noOnsiteOpportunity;
	}
	public void setNoOnsiteOpportunity(Integer noOnsiteOpportunity) {
		this.noOnsiteOpportunity = noOnsiteOpportunity;
	}
	public Integer getRetirement() {
		return retirement;
	}
	public void setRetirement(Integer retirement) {
		this.retirement = retirement;
	}
	public Integer getOther() {
		return other;
	}
	public void setOther(Integer other) {
		this.other = other;
	}
	public String getOtherState() {
		return otherState;
	}
	public void setOtherState(String otherState) {
		this.otherState = otherState;
	}
	public Integer getExitFormId() {
		return exitFormId;
	}
	public void setExitFormId(Integer exitFormId) {
		this.exitFormId = exitFormId;
	}
	public Integer getuId() {
		return uId;
	}
	public void setuId(Integer uId) {
		this.uId = uId;
	}
	public String getSupConsistentlyFair() {
		return supConsistentlyFair;
	}
	public void setSupConsistentlyFair(String supConsistentlyFair) {
		this.supConsistentlyFair = supConsistentlyFair;
	}
	public String getSupProvidedRecognition() {
		return supProvidedRecognition;
	}
	public void setSupProvidedRecognition(String supProvidedRecognition) {
		this.supProvidedRecognition = supProvidedRecognition;
	}
	public String getSupResolvedComplaints() {
		return supResolvedComplaints;
	}
	public void setSupResolvedComplaints(String supResolvedComplaints) {
		this.supResolvedComplaints = supResolvedComplaints;
	}
	public String getSupSensitiveToNeeds() {
		return supSensitiveToNeeds;
	}
	public void setSupSensitiveToNeeds(String supSensitiveToNeeds) {
		this.supSensitiveToNeeds = supSensitiveToNeeds;
	}
	public String getSupProvicedFeedbackOnPerformance() {
		return supProvicedFeedbackOnPerformance;
	}
	public void setSupProvicedFeedbackOnPerformance(String supProvicedFeedbackOnPerformance) {
		this.supProvicedFeedbackOnPerformance = supProvicedFeedbackOnPerformance;
	}
	public String getSupReceptiveToOpenCommunication() {
		return supReceptiveToOpenCommunication;
	}
	public void setSupReceptiveToOpenCommunication(String supReceptiveToOpenCommunication) {
		this.supReceptiveToOpenCommunication = supReceptiveToOpenCommunication;
	}
	public String getSupFollowedInfoCeptsPolicies() {
		return supFollowedInfoCeptsPolicies;
	}
	public void setSupFollowedInfoCeptsPolicies(String supFollowedInfoCeptsPolicies) {
		this.supFollowedInfoCeptsPolicies = supFollowedInfoCeptsPolicies;
	}
	public String getPerformanceReview() {
		return performanceReview;
	}
	public void setPerformanceReview(String performanceReview) {
		this.performanceReview = performanceReview;
	}
	public String getOrientationProgram() {
		return orientationProgram;
	}
	public void setOrientationProgram(String orientationProgram) {
		this.orientationProgram = orientationProgram;
	}
	public String getCompensation() {
		return compensation;
	}
	public void setCompensation(String compensation) {
		this.compensation = compensation;
	}
	public String getCareerDevelopmentPpportunities() {
		return careerDevelopmentPpportunities;
	}
	public void setCareerDevelopmentPpportunities(String careerDevelopmentPpportunities) {
		this.careerDevelopmentPpportunities = careerDevelopmentPpportunities;
	}
	public String getRecognitionOfWork() {
		return recognitionOfWork;
	}
	public void setRecognitionOfWork(String recognitionOfWork) {
		this.recognitionOfWork = recognitionOfWork;
	}
	public String getCompanyBenefits() {
		return companyBenefits;
	}
	public void setCompanyBenefits(String companyBenefits) {
		this.companyBenefits = companyBenefits;
	}
	public String getRnrProgram() {
		return rnrProgram;
	}
	public void setRnrProgram(String rnrProgram) {
		this.rnrProgram = rnrProgram;
	}
	public String getTrainingAndCertification() {
		return trainingAndCertification;
	}
	public void setTrainingAndCertification(String trainingAndCertification) {
		this.trainingAndCertification = trainingAndCertification;
	}
	public String getHealthAndSafety() {
		return healthAndSafety;
	}
	public void setHealthAndSafety(String healthAndSafety) {
		this.healthAndSafety = healthAndSafety;
	}
	public String getAppraisalProcess() {
		return appraisalProcess;
	}
	public void setAppraisalProcess(String appraisalProcess) {
		this.appraisalProcess = appraisalProcess;
	}
	public Integer getBrand() {
		return brand;
	}
	public void setBrand(Integer brand) {
		this.brand = brand;
	}
	public Integer getWorkEnvironment() {
		return workEnvironment;
	}
	public void setWorkEnvironment(Integer workEnvironment) {
		this.workEnvironment = workEnvironment;
	}
	public Integer getWorkLocation() {
		return workLocation;
	}
	public void setWorkLocation(Integer workLocation) {
		this.workLocation = workLocation;
	}
	public Integer getGrowthOpportunities() {
		return growthOpportunities;
	}
	public void setGrowthOpportunities(Integer growthOpportunities) {
		this.growthOpportunities = growthOpportunities;
	}
	public Integer getLeadership() {
		return leadership;
	}
	public void setLeadership(Integer leadership) {
		this.leadership = leadership;
	}
	public Integer getTraining() {
		return training;
	}
	public void setTraining(Integer training) {
		this.training = training;
	}
	public Integer getCoWorkers() {
		return coWorkers;
	}
	public void setCoWorkers(Integer coWorkers) {
		this.coWorkers = coWorkers;
	}
	public String getReApply() {
		return reApply;
	}
	public void setReApply(String reApply) {
		this.reApply = reApply;
	}
	public String getRecommend() {
		return recommend;
	}
	public void setRecommend(String recommend) {
		this.recommend = recommend;
	}
	public String getOtherBenefits() {
		return otherBenefits;
	}
	public void setOtherBenefits(String otherBenefits) {
		this.otherBenefits = otherBenefits;
	}
	public String getPreventFromLeaving() {
		return preventFromLeaving;
	}
	public void setPreventFromLeaving(String preventFromLeaving) {
		this.preventFromLeaving = preventFromLeaving;
	}
	public String getElaborate() {
		return elaborate;
	}
	public void setElaborate(String elaborate) {
		this.elaborate = elaborate;
	}
	public String getOtherComments() {
		return otherComments;
	}
	public void setOtherComments(String otherComments) {
		this.otherComments = otherComments;
	}
	public String getCommentsByHR() {
		return commentsByHR;
	}
	public void setCommentsByHR(String commentsByHR) {
		this.commentsByHR = commentsByHR;
	}
	public Integer getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public Integer getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}


}
