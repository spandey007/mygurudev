package com.infocepts.otc.utilities;

import java.sql.Date;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.Format;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class DateConverter {

	public static String convertTime(Timestamp period){
		Format f=new SimpleDateFormat("MM/dd/yyyy");
		return f.format(period);
	}
	
	public static Date convertToDate(Timestamp period){
		//Timestamp stamp = new Timestamp(period);
		Date date = new Date(period.getTime());
		return date;
	}
	
	public static String convertDateToString(java.util.Date createdDate){
		  DateFormat df = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
		  // Using DateFormat format method we can create a string 
		  // representation of a date with the defined format.
		  String reportDate = df.format(createdDate);

		  // Print what date is today!
		  return reportDate;
	 }
	
	public static String changeDate(java.util.Date date2){
		SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
		String date=sdf.format(date2);
		return date;
	}
	
	public static String changeDate2(java.util.Date date2){
		SimpleDateFormat sdf=new SimpleDateFormat("dd-MMM-yyyy");
		String date=sdf.format(date2);
		return date;
	}
	
	public static String monthAndYearFromDate(java.util.Date date2){
		SimpleDateFormat sdf=new SimpleDateFormat("MMM yyyy");
		String date=sdf.format(date2);
		return date;
	}
	
	public static String theMonth(int month){
	    String[] monthNames = {"0","January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};
	    return monthNames[month];
	}
	
	public static java.util.Date convertStringToDate(String date) throws ParseException{
		java.util.Date formattedDate = new SimpleDateFormat("yyyy-MM-dd").parse(date);
		return formattedDate;
	}
	
	 /*
     * Java Method to calculate difference between two dates in Java
     * without using any third party library.
     */
	public static long daysBetween(java.util.Date one, java.util.Date two) {
		long difference =  (one.getTime()-two.getTime())/86400000;
        return Math.abs(difference);
		
	}
}
