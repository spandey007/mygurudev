package com.infocepts.otc.entities;

import java.util.Date;

import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.SqlResultSetMappings;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.infocepts.otc.utilities.LoadConstant;

@Entity
@Table(catalog=LoadConstant.otc, schema="[dbo]",name="accesslock")
@SqlResultSetMappings(
		@SqlResultSetMapping(
				name = "blocked_users",
				classes = @ConstructorResult(
						targetClass = AccessLock.class,
						columns = {
								@ColumnResult(name="accessLockId", type=Integer.class),
								@ColumnResult(name="username", type=String.class),
								@ColumnResult(name="lastAttemptDate", type=Date.class),
								@ColumnResult(name="title", type=String.class),
								@ColumnResult(name="empId", type=Integer.class)
						}
				)
		)
)
@NamedNativeQueries({
		@NamedNativeQuery(
				name = "blockedUserNamedQuery",
				resultSetMapping = "blocked_users",
				query = "select a.accessLockId, a.username, a.lastAttemptDate, r.title," + " r.empid from " + LoadConstant.otc
				+ ".[dbo].[accesslock] a inner join " + LoadConstant.infomaster + ".[dbo].[resource]"
				+ " r on r.email = CONCAT(a.username, '@infocepts.com') "
				+ "where a.locked=1 order by r.title",
				resultClass=AccessLock.class
				)
	}
)
public class AccessLock {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer accessLockId;
	private String username;
	private Integer count;
	private boolean locked;
	private Date lastAttemptDate;
	@Transient
	private String title;
	@Transient
	private Integer empId;
	
	public AccessLock() {
	}
	
	public AccessLock(Integer accessLockId, String username, Date lastAttemptDate, String title, Integer empId) {
		this.accessLockId = accessLockId;
		this.username = username;
		this.lastAttemptDate = lastAttemptDate;
		this.title = title;
		this.empId = empId;
	}
	
	public Integer getAccessLockId() {
		return accessLockId;
	}
	public void setAccessLockId(Integer accessLockId) {
		this.accessLockId = accessLockId;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public Integer getCount() {
		return count;
	}
	public void setCount(Integer count) {
		this.count = count;
	}
	public boolean isLocked() {
		return locked;
	}
	public void setLocked(boolean locked) {
		this.locked = locked;
	}
	public Date getLastAttemptDate() {
		return lastAttemptDate;
	}
	public void setLastAttemptDate(Date lastAttemptDate) {
		this.lastAttemptDate = lastAttemptDate;
	}

	/**
	 * @return the title
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * @param title the title to set
	 */
	public void setTitle(String title) {
		this.title = title;
	}

	/**
	 * @return the empId
	 */
	public Integer getEmpId() {
		return empId;
	}

	/**
	 * @param empId the empId to set
	 */
	public void setEmpId(Integer empId) {
		this.empId = empId;
	}
}
