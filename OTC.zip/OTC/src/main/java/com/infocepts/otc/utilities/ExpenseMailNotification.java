/**
 * 
 */
package com.infocepts.otc.utilities;

import java.net.InetAddress;
import java.util.Arrays;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import com.infocepts.otc.entities.Expense;
import com.infocepts.otc.entities.ExpenseDetail;
import com.infocepts.otc.entities.Project;
import com.infocepts.otc.entities.Resource;
import com.infocepts.otc.repositories.ExpenseDetailRepository;
import com.infocepts.otc.repositories.ExpenseRepository;
import com.infocepts.otc.repositories.ProjectRepository;
import com.infocepts.otc.repositories.ResourceRepository;

/**
 * @author Rewatiraman Singh
 *
 */
@Service
public final class ExpenseMailNotification extends Object {

	@Autowired
    private TemplateEngine templateEngine;
	
	@Autowired
	private ExpenseRepository expenseRepository;
	
	@Autowired
	private ExpenseDetailRepository expenseDetailRepository;
	
	@Autowired
	private ProjectRepository projectRepository;
	
	@Autowired
	private ResourceRepository resourceRepository;
	
	@PersistenceContext(unitName="otc")
    private EntityManager manager;
	
	@Autowired
	private JavaMailSender javaMailSender;
	
	private static final String INFOBIZ_EMAIL_ID = LoadConstant.INFOBIZ;
	private static final String INFOBIZ_ADMIN_EMAIL_ID = LoadConstant.INFOBIZ_ADMIN ;
	private static final String TEMPLATE_NAME = "mail/expenseNotification";
	private static final Logger LOGGER = Logger.getLogger(ExpenseMailNotification.class.getName());
	
	// Enum class to ensure type safety while passing Role to approval/rejection methods defined below.
	public enum Role {
		PM,
		TRAVEL,
		FINANCE
	}
	
	
	private synchronized boolean notify(Context context, List<String> toRecipients, List<String> ccRecipients, String subject, String exceptionMessage) {
		MimeMessage mimeMessage = javaMailSender.createMimeMessage();
		String to = "";
		String cc = "";
		boolean mailSent = false;
		
		try {
			MimeMessageHelper mimeMessageHelper = new MimeMessageHelper(mimeMessage, true);
			mimeMessageHelper.setFrom(INFOBIZ_ADMIN_EMAIL_ID);
			mimeMessageHelper.setSubject(subject);
			/* This condition implies, Notification should be sent to developer's email if the host address
			doesn't belong to prod machine else it will be sent to respective stakeholders.
			*/
			if (!"infobiz-fe1".equals(InetAddress.getLocalHost().getHostName())) {
				mimeMessageHelper.setTo(INFOBIZ_EMAIL_ID);
				mimeMessageHelper.setTo("sbhole@infocepts.com");
				mimeMessageHelper.setTo("rraut@infocepts.com");
				mimeMessageHelper.setTo("hamandaogade@infocepts.com");
				mimeMessageHelper.setTo("mnikam@infocepts.com");
			} else {
				to = toRecipients.stream().collect(Collectors.joining(","));
				cc = ccRecipients.stream().collect(Collectors.joining(","));
				mimeMessageHelper.setTo(to);
				mimeMessageHelper.addCc(cc);
			}
			
			String htmlBody = templateEngine.process(TEMPLATE_NAME, context);
			// Setting "true" flag indicates that we intend to send an HTML content.
			mimeMessageHelper.setText(htmlBody, true);
			
			javaMailSender.send(mimeMessage);
			mailSent = true;
			LOGGER.info(String.format("MAIL SUCCESSFULLY SENT TO: %s", to));
			LOGGER.info(String.format("RECIPIENTS IN CC: %s", cc));
		} catch (Exception e) {
			if (StringUtils.isEmpty(exceptionMessage)) {
				LOGGER.log(Level.SEVERE, "EXPENSE: COULD NOT SEND MAIL TO: "+ to , e);
			} else {
				LOGGER.log(Level.SEVERE, exceptionMessage, e);
			}
		}
		return mailSent;
	}
	
	/**
	 * @param expense
	 * @throws MessagingException 
	 */
	public void notifySubmission(Expense expense) {
		String exceptionMessage = "COULD NOT SEND MAIL AFTER SUBMITTING THE EXPENSE!";
		Project project = projectRepository.findOne(expense.getProjectId());
		List<String> recipientList = new UniqueArrayList<>();
		List<String> toList = new UniqueArrayList<>();
		List<String> ccList = new UniqueArrayList<>();
		List<Integer> projectOwners = expenseDetailRepository.fetchProjectOwners(manager, expense.getProjectId());
		
		Resource pm = resourceRepository.findOne(expense.getApproverId());
		recipientList.add(pm.getFirstName() + " " +  pm.getLastName());
				
		projectOwners.forEach(ownerId -> {
			Resource associate = resourceRepository.findResourcebyUid(ownerId);
			recipientList.add(associate.getFirstName() + " " + associate.getLastName());
			toList.add(associate.getEmail());
		});
		
		Resource associate = resourceRepository.findResourcebyUid(expense.getUid());
		String associateName = associate.getFirstName() + " "  + associate.getLastName();
		ccList.add(associate.getEmail());

		// Remove the associate's name from recipient's list in case the associate itself is either PM, AH or PH.
		recipientList.remove(associateName);

		String headerTitle = "Expense claim by Associate - Approval Request";
		Context context = new Context();
		
		formatExpense(expense, associate, project);
		context.setVariable("headerTitle", headerTitle);
		context.setVariable("recipientNames", recipientList.stream().collect(Collectors.joining(", ")));
		context.setVariable("associateName", associateName);
		context.setVariable("expenseList", Arrays.asList(expense));
		context.setVariable("expenseSubmitted", true);
		context.setVariable("expenseDetailList", fetchExpenseDetailList(expense.getExpenseId()));
		String subject = "Infobiz | Expense | EXP00" + expense.getExpenseId() + " | Submitted | " + associateName;
		notify(context, toList, ccList, subject, exceptionMessage);
	}
	
	/**
	 * @param expense
	 */
	public boolean notifyApproval(Expense expense, Role role, Integer loggedInUid) {
		String exceptionMessage = "COULD NOT SEND MAIL WHEN APPROVED THE EXPENSE(S)!";
		String headerTitle = "Expense claim by Associate - Approved";
		Project project = projectRepository.findOne(expense.getProjectId());
		List<Integer> projectOwners = expenseDetailRepository.fetchProjectOwners(manager, expense.getProjectId());
		Context context = new Context();
		
		context.setVariable("headerTitle", headerTitle);
		List<String> toList = new UniqueArrayList<>();
		List<String> ccList = new UniqueArrayList<>();
		String recipientNames = "";
		String associateName = "";
		String approver = "";
		
		ccList.add(INFOBIZ_EMAIL_ID);
		projectOwners.forEach(ownerId -> ccList.add(resourceRepository.findOne(ownerId).getEmail()));
		
		Resource associate = resourceRepository.findOne(expense.getUid());
		
		if (associate != null) {
			associateName = associate.getFirstName() + " " + associate.getLastName();
		}
		
		Resource loggedInUser = resourceRepository.findOne(loggedInUid);
		
		if (loggedInUser != null) { 
			approver = loggedInUser.getFirstName() + " " + loggedInUser.getLastName();;
		}
		
		formatExpense(expense, loggedInUser, project);
		context.setVariable("expenseApproved", true);
		context.setVariable("expenseApprovedOrRejected", true);
		context.setVariable("expenseList", Arrays.asList(expense));
		if (role != null) {
			if (role == Role.PM) {
				
				if (expenseRepository.isPurposeTypeTravel(manager, expense.getExpenseId())) {
					toList.add(LoadConstant.TRAVEL_DESK);
					recipientNames = "Travel Desk Team";
					context.setVariable("tabName", "Travel");
				} else {
					toList.add(LoadConstant.ACCOUNTS_PAYABLE);
					recipientNames = "Accounts Payable Team";
					context.setVariable("tabName", "Finance");
				}
				ccList.add(loggedInUser.getEmail());
				context.setVariable("concerned", "Associate/Manager");
				context.setVariable("recipientNames", recipientNames);
				context.setVariable("approver", approver);
				context.setVariable("associateName", associateName);
			} else if (role == Role.TRAVEL) {
				toList.add(LoadConstant.ACCOUNTS_PAYABLE);
				recipientNames = "Accounts Payable Team";
				context.setVariable("associateName", associateName);
				context.setVariable("approver", "Travel Desk Team");
				context.setVariable("tabName", "Finance");
				context.setVariable("concerned", "Travel Desk Team");
			} else if (role == Role.FINANCE) {
				toList.add(associate.getEmail());
				context.setVariable("recipientNames", associateName);
				context.setVariable("expenseApprovedByFinance", true);
				context.setVariable("expenseApproved", false);
				context.setVariable("expenseApprovedOrRejected", true);
				context.setVariable("approver", "Accounts Payable Team");
				context.setVariable("tabName", "My Expenses");
				context.setVariable("concerned", "Accounts Payable Team");
			}
		}
		context.setVariable("expenseDetailList", fetchExpenseDetailList(expense.getExpenseId()));
		String subject = "Infobiz | Expense | EXP00" + expense.getExpenseId() + " | Approved | " + associateName;
		return notify(context, toList, ccList,  subject, exceptionMessage);
	}
	
	/**
	 * @param expense
	 */
	public boolean notifyRejection(Expense expense, Role role, Integer loggedInUid) {
		String exceptionMessage = "COULD NOT SEND MAIL WHEN REJECTED THE EXPENSE(S)!";
		String headerTitle = "Expense claim by Associate - Rejected";
		Project project = projectRepository.findOne(expense.getProjectId());
		Context context = new Context();
		List<String> toList = new UniqueArrayList<>();
		List<String> ccList = new UniqueArrayList<>();
		context.setVariable("expenseRejected", true);
		context.setVariable("expenseApprovedOrRejected", true);
		context.setVariable("headerTitle", headerTitle);
		Resource rejector = resourceRepository.findOne(loggedInUid);
		Resource associate = resourceRepository.findOne(expense.getUid());
		String rejectorName = "";
		String associateName = associate.getFirstName() + " " + associate.getLastName();
		
		toList.add(associate.getEmail());
		ccList.add(INFOBIZ_EMAIL_ID);
		
		formatExpense(expense, associate, project);
		context.setVariable("expenseList", Arrays.asList(expense));
		
		if (role != null) {
			if (role == Role.PM) {
				rejectorName = rejector.getFirstName() + " " + rejector.getLastName();
				ccList.add(rejector.getEmail());
			} else if (role == Role.TRAVEL) {
				rejectorName = "Travel Desk Team";
				ccList.add(LoadConstant.TRAVEL_DESK);
			} else if (role == Role.FINANCE) {
				rejectorName = "Accounts Payable Team";
				ccList.add(LoadConstant.ACCOUNTS_PAYABLE);
			}
			context.setVariable("rejector", rejectorName);
			context.setVariable("concerned", rejectorName);
			context.setVariable("associateName", associateName);
			context.setVariable("tabName", "My Expenses");
		}
		context.setVariable("expenseDetailList", fetchExpenseDetailList(expense.getExpenseId()));
		String subject = "Infobiz | Expense | EXP00" + expense.getExpenseId() + " | Rejected | " + associateName;
		return notify(context, toList, ccList, subject, exceptionMessage);
	}
	
	/**
	 * @param expense
	 * @return - true if mail is sent successfully, False otherwise.
	 */
	public boolean notifySettlement(Expense expense) {
		Context context = new Context();
		
		context.setVariable("headerTitle", "Expense Claim Settled by Accounts Payable Team");
		
		List<String> toList = new UniqueArrayList<>();
		List<String> ccList = new UniqueArrayList<>();
		
		
		Resource associateResource = resourceRepository.findOne(expense.getUid());
		Project project = projectRepository.findOne(expense.getProjectId());
		String associateName = associateResource.getFirstName() + " " + associateResource.getLastName();
		
		context.setVariable("headerTitle", "Expense Claim Settled by Accounts Payable Team");
		context.setVariable("isSettlement", true);
		context.setVariable("expenseApprovedOrRejected", true);
		context.setVariable("associateName", associateName);
		context.setVariable("settledBy", "Accounts Payable Team");
		context.setVariable("concerned", "Accounts Payable Team");
		context.setVariable("tabName", "My Expenses");
		
		toList.add(associateResource.getEmail());
		ccList.add(LoadConstant.ACCOUNTS_PAYABLE);
		ccList.add(INFOBIZ_EMAIL_ID);
		
		String exceptionMessage = "COULD NOT SEND MAIL WHEN SETTLED THE EXPENSE(S)!";
		String subject = "Infobiz | Expense | EXP00" + expense.getExpenseId() + " | Settled | " + associateName;
		formatExpense(expense, associateResource, project);
		context.setVariable("expenseList", Arrays.asList(expense));
		context.setVariable("expenseDetailList", fetchExpenseDetailList(expense.getExpenseId()));
		return notify(context, toList, ccList, subject, exceptionMessage);
	}
	
	public boolean notifyAssignment(Expense expense) {
		Context context = new Context();

		context.setVariable("headerTitle", "Expense Claim Assigned by Accounts Payable Team");

		List<String> toList = new UniqueArrayList<>();
		List<String> ccList = new UniqueArrayList<>();

		Resource associateResource = resourceRepository.findOne(expense.getUid());
		toList.add(associateResource.getEmail());
		ccList.add(LoadConstant.ACCOUNTS_PAYABLE);
		ccList.add(INFOBIZ_EMAIL_ID);
		
		Project project = projectRepository.findOne(expense.getProjectId());
		String associateName = associateResource.getFirstName() + " " + associateResource.getLastName();

		context.setVariable("isAssignment", true);
		context.setVariable("expenseApprovedOrRejected", true);
		context.setVariable("associateName", associateName);
		context.setVariable("assignedBy", "Accounts Payable Team");
		context.setVariable("concerned", "Accounts Payable Team");
		context.setVariable("tabName", "My Expenses");

		String exceptionMessage = "COULD NOT SEND MAIL WHEN ASSIGNING THE EXPENSE(S)!";
		String subject = "Infobiz | Expense | EXP00" + expense.getExpenseId() + " | Assigned | " + associateName;
		formatExpense(expense, associateResource, project);
		context.setVariable("expenseDetailList", fetchExpenseDetailList(expense.getExpenseId()));
		context.setVariable("expenseList", Arrays.asList(expense));
		return notify(context, toList, ccList, subject, exceptionMessage);
	}
	
	private void formatExpense(Expense expense, Resource resource, Project project) {
		String currencyCodeByUnit = resource.getUnit().getEntity().getCountry().getCurrency().getCode();
		try {
			expense.setExpenseCode("EXP00" + expense.getExpenseId());
			expense.setFormattedAmount(currencyCodeByUnit + " " + expense.getTotalAmount());
			expense.setProjectTitle(project.getTitle());
			expense.setFormattedStartDate(new java.text.SimpleDateFormat("dd MMM yyyy").format(expense.getStartDate()));
			expense.setFormattedEndDate(new java.text.SimpleDateFormat("dd MMM yyyy").format(expense.getEndDate()));
		} catch (Exception e) {
			LOGGER.log(Level.WARNING, "COULD NOT PARSE THE EXPENSE START AND END DATES!", e);
		}
	}
	
	private List<ExpenseDetail> fetchExpenseDetailList(int expenseId) {
		List<ExpenseDetail> detailList = expenseDetailRepository.findFormattedExpenseDetailByExpenseId(manager, expenseId);
		detailList.forEach(detail -> {
			detail.setFormattedStartDate(new java.text.SimpleDateFormat("dd MMM yyyy").format(detail.getStartDate()));
			detail.setFormattedEndDate(new java.text.SimpleDateFormat("dd MMM yyyy").format(detail.getEndDate()));
		});
		return detailList;
	}
}
