package com.infocepts.otc.utilities;


import java.io.File;

import java.util.ArrayList;
import java.util.List;

public class ZipCreator
{
    List<String> fileList;
   
    public ZipCreator(){
	fileList = new ArrayList<String>();
	
    }
    
    /**
     * Traverse a directory and get all files,
     * and add the file into fileList  
     * @param node file or directory
     */
    public List<String> generateFileList(File node,String SOURCE_FOLDER){
     	//add file only
	if(node.isFile()){
		fileList.add(generateZipEntry(node.getAbsoluteFile().toString(),SOURCE_FOLDER));
	}
		
	if(node.isDirectory()){
		String[] subNote = node.list();
		for(String filename : subNote){
			generateFileList(new File(node, filename),SOURCE_FOLDER);
		}
	}
	return fileList;
    }

    /**
     * Format the file path for zip
     * @param file file path
     * @return Formatted file path
     */
    private String generateZipEntry(String file, String SOURCE_FOLDER){
    	return file.substring(SOURCE_FOLDER.length()+1, file.length());
    }
}
