package com.infocepts.otc.entities;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

import com.infocepts.otc.utilities.LoadConstant;

@Entity
@Table(catalog=LoadConstant.otc, schema="[dbo]",name="reports")
public class Reports {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer reportId;
	private String title;
	private String roleAccess;
	private Integer section;
	@Lob
	private String url;	
	private Integer createdBy;
	private Date createdDate;
	private Integer modifiedBy;
	private Date modifiedDate;
	private Boolean reportType; // InfoBiz = 0 or MSTR = 1
	private Integer mstrReportType;
	@Lob
	private String reportOrDocumentId;
	@Lob
	private String projectName;
	private String evtId;
	
	
	/**
	 * @return the mstrReportType
	 */
	public Integer getMstrReportType() {
		return mstrReportType;
	}
	/**
	 * @param mstrReportType the mstrReportType to set
	 */
	public void setMstrReportType(Integer mstrReportType) {
		this.mstrReportType = mstrReportType;
	}
	/**
	 * @return the reportOrDocumentId
	 */
	public String getReportOrDocumentId() {
		return reportOrDocumentId;
	}
	/**
	 * @param reportOrDocumentId the reportOrDocumentId to set
	 */
	public void setReportOrDocumentId(String reportOrDocumentId) {
		this.reportOrDocumentId = reportOrDocumentId;
	}
	/**
	 * @return the projectName
	 */
	public String getProjectName() {
		return projectName;
	}
	/**
	 * @param projectName the projectName to set
	 */
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	/**
	 * @return the evtId
	 */
	public String getEvtId() {
		return evtId;
	}
	/**
	 * @param evtId the evtId to set
	 */
	public void setEvtId(String evtId) {
		this.evtId = evtId;
	}
	public Integer getReportId() {
		return reportId;
	}
	public void setReportId(Integer reportId) {
		this.reportId = reportId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getRoleAccess() {
		return roleAccess;
	}
	public void setRoleAccess(String roleAccess) {
		this.roleAccess = roleAccess;
	}
	public Integer getSection() {
		return section;
	}
	public void setSection(Integer section) {
		this.section = section;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public Integer getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public Integer getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public Date getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public Boolean getReportType() {
		return reportType;
	}
	public void setReportType(Boolean reportType) {
		this.reportType = reportType;
	}
	

}
