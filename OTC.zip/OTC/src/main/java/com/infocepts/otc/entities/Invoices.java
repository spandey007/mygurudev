package com.infocepts.otc.entities;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.SqlResultSetMappings;
import javax.persistence.Table;
import javax.persistence.Transient;
import com.infocepts.otc.utilities.LoadConstant;
import com.infocepts.otc.utilities.QueryConstant;


@Entity
@Table(catalog=LoadConstant.otc, schema="[dbo]",name="invoices")
@SqlResultSetMappings({
@SqlResultSetMapping(
	      name = "project_for_invoices",
	      classes = {
	          @ConstructorResult(
	              targetClass = Invoices.class,
	              columns = {
	            		  @ColumnResult(name = "invoiceId"),
	 	            	 @ColumnResult(name = "arHeaderId"),
	 	                  @ColumnResult(name = "projectId"),
	 	                  @ColumnResult(name = "clientPm"),
	 	                  @ColumnResult(name = "periodStartDate", type=Date.class),
	 	                  @ColumnResult(name = "periodEndDate", type=Date.class),
	 	                  @ColumnResult(name = "rmId"),
	 	                  @ColumnResult(name = "dmId"),
	 	                  @ColumnResult(name = "pmId"),
	 	                  @ColumnResult(name = "invoiceNo"),
	 	                  @ColumnResult(name = "finalInvoiceNo"),
	 	                  @ColumnResult(name = "arDraftDate", type=Date.class),
	 	                  @ColumnResult(name = "arInvoiceDate", type=Date.class),
	 	                  @ColumnResult(name = "arApprovalDate", type=Date.class),
	 	                  @ColumnResult(name = "arSubmitDate", type=Date.class),
	 			          @ColumnResult(name = "invoiceStatus",type=String.class),
	 	                  @ColumnResult(name = "comments"),
	 	                  @ColumnResult(name = "invoiceType"),
	 	                  @ColumnResult(name = "subtotal", type=BigDecimal.class),
	 	                  @ColumnResult(name = "flatDiscountPer", type=BigDecimal.class),
	 	                  @ColumnResult(name = "discountAmt", type=BigDecimal.class),
	 	                  @ColumnResult(name = "netSubTotal", type=BigDecimal.class),
	 	                  @ColumnResult(name = "total", type=BigDecimal.class),
	 	                  @ColumnResult(name = "approvedRejectedBy"),
	 	                  @ColumnResult(name = "approveRejectComment"),
	 	                  @ColumnResult(name = "endClientInvoiceNo"),
	 	                  @ColumnResult(name = "endClientProjectId"),
	 					  @ColumnResult(name = "modifiedBy"),
	 	                  @ColumnResult(name = "modifiedDate", type=Date.class),
	 	                  @ColumnResult(name = "createdBy"),
	 	                  @ColumnResult(name = "invoices"),
	 	                  @ColumnResult(name = "flatdiscountPer2", type=BigDecimal.class),
	 	                  @ColumnResult(name = "sbcTax", type=BigDecimal.class),
	 	                  @ColumnResult(name = "sbcTaxAmt", type=BigDecimal.class),
	 	                  @ColumnResult(name = "tax", type=BigDecimal.class),
	 	                  @ColumnResult(name = "taxAmt", type=BigDecimal.class),
	 	                  @ColumnResult(name = "roundOff"),
	 	                  @ColumnResult(name = "kkTax", type=BigDecimal.class),
	 	                  @ColumnResult(name = "kkTaxAmt", type=BigDecimal.class),
	 	                  @ColumnResult(name = "vat", type=BigDecimal.class),
	 	                  @ColumnResult(name = "vatAmt", type=BigDecimal.class),
	 	                  @ColumnResult(name = "gstRegNo"),
	 	                  @ColumnResult(name = "typeSupply"),
	 	                  @ColumnResult(name = "cgst", type=BigDecimal.class),
	 	                  @ColumnResult(name = "cgstAmt", type=BigDecimal.class),
	 	                  @ColumnResult(name = "sgst", type=BigDecimal.class),
	 	                  @ColumnResult(name = "sgstAmt", type=BigDecimal.class),
	 	                  @ColumnResult(name = "igst", type=BigDecimal.class),
	 	                  @ColumnResult(name = "igstAmt", type=BigDecimal.class),
	 	                  @ColumnResult(name = "utgst", type=BigDecimal.class),
	 	                  @ColumnResult(name = "utgstAmt", type=BigDecimal.class),
	 	                  @ColumnResult(name = "sgdGst", type=BigDecimal.class),
	 	                  @ColumnResult(name = "sgdGstAmt", type=BigDecimal.class),
		            	  @ColumnResult(name = "filePath"),	 	                  
	 	                  @ColumnResult(name = "zeroRatedSupplyFlag",type=Boolean.class),
	 	                  @ColumnResult(name = "submitted",type=Boolean.class),
	 	                  @ColumnResult(name = "exchangeRate", type=BigDecimal.class),
	 	                  @ColumnResult(name = "exchangecurrencyId"),
	 	                  @ColumnResult(name = "clientPO"),
	 	                  @ColumnResult(name = "currencyId"),
	 	                  @ColumnResult(name = "unbilledReason"),
	 	                  @ColumnResult(name = "billingUnit"),
	 	                  @ColumnResult(name = "uomId"),
	 	                  @ColumnResult(name = "amountInwords"),
	 	                  @ColumnResult(name = "ahId"),
	 	                  @ColumnResult(name = "invoiceFromUnit"),
	 	                  @ColumnResult(name = "invoiceToUnit"),
	 	                  @ColumnResult(name = "billingAccountId"),
	 	                  @ColumnResult(name = "shippingAccountId"),
	 	                /*Transient start*/
	 	                  @ColumnResult(name = "itemId"),
	 	                  @ColumnResult(name = "projectName"),
	 	                  @ColumnResult(name = "accountId"),
	 	                  @ColumnResult(name = "accountName"),
	 	                  @ColumnResult(name = "billingEntity"),
	 	                  @ColumnResult(name = "billingType"),
	 	                  @ColumnResult(name = "pmApprovalStatus"),
	 	                  @ColumnResult(name = "otherInvoicesCount"),
	 	                  @ColumnResult(name = "CrDrCount"),
	 	                  @ColumnResult(name = "internalInvoiceNo"),
	 	                  @ColumnResult(name = "endClientProjName"),
	 	                  @ColumnResult(name = "currSign"),
	 	                  @ColumnResult(name = "country"),
	 	                  @ColumnResult(name = "currency"),
	 	                  @ColumnResult(name = "onShoreDevTotal", type=BigDecimal.class),
	 	                  @ColumnResult(name = "offShoreDevTotal", type=BigDecimal.class),
	 	                  @ColumnResult(name = "projectType"),
	 	                  @ColumnResult(name = "unitId"),
	 	                  @ColumnResult(name = "interUnitCount")
	 	                   /*Transient end*/
	                 
	                }
	          )
	      }
	),
@SqlResultSetMapping(
	      name = "internal_invoices_result",
	      classes = {
	          @ConstructorResult(
	              targetClass = Invoices.class,
	              columns = {
	            		//Transient start
	            		  @ColumnResult(name = "finalInvoiceNo", type=String.class),
	            		  @ColumnResult(name = "itemId"),
	            		  @ColumnResult(name = "projectName", type=String.class),   
	  		          	 //Transient end
	                }
	          )
	      }),
@SqlResultSetMapping(
	      name = "report_timesheet_result",
	      classes = {
	          @ConstructorResult(
	              targetClass = Invoices.class,
	              columns = {
	            		//Transient start
	            		  @ColumnResult(name = "accountName"),
	            		  @ColumnResult(name = "projectName", type=String.class),
	            		  @ColumnResult(name = "resourceName", type=String.class),
	            		  @ColumnResult(name = "countryName", type=String.class), 
	            		  @ColumnResult(name = "billableRate", type=BigDecimal.class),
	            		  @ColumnResult(name = "currency"),
	 	                  @ColumnResult(name = "tsHrs", type=BigDecimal.class),
	            		  @ColumnResult(name = "uom", type=String.class),
	            		  @ColumnResult(name = "sowNo", type=String.class)
	            		//Transient end
	                }
	          )
	      }),
@SqlResultSetMapping(
	      name = "report_invoices_result",
	      classes = {
	          @ConstructorResult(
	              targetClass = Invoices.class,
	              columns = {
	            		//Transient start
	            		  @ColumnResult(name = "accountName"),
	            		  @ColumnResult(name = "projectName", type=String.class),
	            		  @ColumnResult(name = "clientPO"),
	            		  @ColumnResult(name = "finalInvoiceNo", type=String.class),
	            		  @ColumnResult(name = "invoiceType"),
	            		  @ColumnResult(name = "endClientInvoiceNo"), 
	            		  @ColumnResult(name = "endClientProjName", type=String.class),
	            		  @ColumnResult(name = "arInvoiceDate", type=Date.class),
	            		  @ColumnResult(name = "currency"),
	            		  @ColumnResult(name = "netSubTotal", type=BigDecimal.class),
	            		  @ColumnResult(name = "cgstAmt", type=BigDecimal.class),
	 	                  @ColumnResult(name = "sgstAmt", type=BigDecimal.class),
	 	                  @ColumnResult(name = "igstAmt", type=BigDecimal.class),
	 	                  @ColumnResult(name = "utgstAmt", type=BigDecimal.class),
	 	                  @ColumnResult(name = "sgdGstAmt", type=BigDecimal.class),
	 	                  @ColumnResult(name = "total", type=BigDecimal.class)
	            		//Transient end
	                }
	          )
	      }),
@SqlResultSetMapping(
	      name = "invoices_count_result",
	      classes = {
	          @ConstructorResult(
	              targetClass = Invoices.class,
	              columns = {
	            		//Transient start
	            		  @ColumnResult(name = "invoiceCount"),
	            		  @ColumnResult(name = "invoiceStatus",type=String.class),
	            		//Transient end
	                }
	          )
	      })
})
	@NamedNativeQueries({
		
	    @NamedNativeQuery(
	            name    =   "getLastInvoice",
	            query   =    "	SELECT Top 1 i.*," +
						" p.itemId as itemId," +
						" cast(p.title as varchar(MAX)) as projectName," +
						" p.accountId as accountId," +
						" '' as currSign," +
						" (Select title from " +LoadConstant.infomaster+ ".[dbo].accounts where itemId = p.accountId) as accountName," +
						" u.name as billingUnit," +
						" u.unitName as billingEntity," +
						" cast(b.name as varchar) as billingType," +
						" 0 as pmApprovalStatus," +
						" 0 as otherInvoicesCount," +
						" 0 as CrDrCount, " +
						" '0' as internalInvoiceNo, " +
						" '' as endClientProjName, " +
						" '' as country," +
						" '' as currency, " +
						" 0 as onShoreDevTotal, " +
						" 0 as offShoreDevTotal, " +
						" '' as projectType, " +
						" u.unitId, " +
						" 0 as interUnitCount " +
						" FROM " +LoadConstant.infomaster+ ".[dbo].project p" +
						" LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[unit] u on u.unitId = p.billingUnitId "+
						" LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[entities] e on e.entityId = u.entityId "+
						" LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[billingType] b on b.billingTypeId = p.billingTypeId " +
						" left join " +LoadConstant.otc+".[dbo].invoices i on p.itemid = i.projectId  " +
							//" where p.state = 'Active'" + 
						" where  b.name <> 'None'" + // Where billing type is 'None'
						" and u.name = :billingUnit" +
						" and i.invoiceType!='Credit Note'" +
						" order by i.invoiceId desc",
	                      resultClass=Invoices.class, resultSetMapping = "project_for_invoices"                       		
	    ),
	    @NamedNativeQuery(
	            name    =   "getLastInvoice_CreditNote",
	            query   =    "	SELECT Top 1 i.*," +
						" p.itemId as itemId," +
						" cast(p.title as varchar(MAX)) as projectName," +
						" p.accountId as accountId," +
						" '' as currSign," +
						" (Select title from " +LoadConstant.infomaster+ ".[dbo].accounts where itemId = p.accountId) as accountName," +
						" u.name as billingUnit," +
						" u.unitName as billingEntity," +
						" cast(b.name as varchar) as billingType," +
						" 0 as pmApprovalStatus," +
						" 0 as otherInvoicesCount," +
						" 0 as CrDrCount, " +
						" '0' as internalInvoiceNo, " +
						" '' as endClientProjName, " +
						" '' as country," +
						" '' as currency, " +
						" 0 as onShoreDevTotal, " +
						" 0 as offShoreDevTotal, " +
						" '' as projectType, " +
						" u.unitId, " +
						" 0 as interUnitCount " +
						" FROM " +LoadConstant.infomaster+ ".[dbo].project p" +
						" LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[unit] u on u.unitId = p.billingUnitId "+
						" LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[entities] e on e.entityId = u.entityId "+
						" LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[billingType] b on b.billingTypeId = p.billingTypeId " +
						" left join " +LoadConstant.otc+".[dbo].invoices i on p.itemid = i.projectId  " +
							//" where p.state = 'Active'" + 
						" where  b.name <> 'None'" + // Where billing type is 'None'
						" and u.name = :billingUnit" +
						" and i.invoiceType= :invoiceType" +
						" order by i.invoiceId desc",
	                      resultClass=Invoices.class, resultSetMapping = "project_for_invoices"                       		
	    ),
	    @NamedNativeQuery(
	            name    =   "getLastFinalInvoice",
	            query   =    "	SELECT Top 1 i.*," +
	            		" p.itemId as itemId," +
						" cast(p.title as varchar(MAX)) as projectName," +
						" p.accountId as accountId," +
						" '' as currSign," +
						" (Select title from " +LoadConstant.infomaster+ ".[dbo].accounts where itemId = p.accountId) as accountName," +
						" u.name as billingUnit," +
						" u.unitName as billingEntity," +
						" cast(b.name as varchar) as billingType," +
						" 0 as pmApprovalStatus," +
						" 0 as otherInvoicesCount," +
						" 0 as CrDrCount, " +
						" '0' as internalInvoiceNo, " +
						" '' as endClientProjName, " +
						" '' as country," +
						" '' as currency, " +
						" 0 as onShoreDevTotal, " +
						" 0 as offShoreDevTotal, " +
						" '' as projectType, " +
						" u.unitId, " +
						" 0 as interUnitCount " +
						" FROM " +LoadConstant.infomaster+".[dbo].project p" +
						" left join " +LoadConstant.otc+".[dbo].invoices i on p.itemid = i.projectId" +
						" LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[unit] u on u.unitId = p.billingUnitId "+
						" LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[entities] e on e.entityId = u.entityId "+
						" LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[billingType] b on b.billingTypeId = p.billingTypeId " +
						//" where p.state = '(2) Active'" + 
						" where  b.name <> 'None'" + // Where billing type is 'None'
						" and u.name = :billingUnit and finalInvoiceNo is not null" +
						" and invoiceType!='Credit Note'"+
						" order by i.arSubmitDate desc ",
	                      resultClass=Invoices.class, resultSetMapping = "project_for_invoices"                       		
	    ),
	    @NamedNativeQuery(
	            name    =   "getLastFinalInvoice_CreditNote",
	            query   =    "	SELECT Top 1 i.*," +
	            		" p.itemId as itemId," +
						" cast(p.title as varchar(MAX)) as projectName," +
						" p.accountId as accountId," +
						" '' as currSign," +
						" (Select title from " +LoadConstant.infomaster+ ".[dbo].accounts where itemId = p.accountId) as accountName," +
						" u.name as billingUnit," +
						" u.unitName as billingEntity," +
						" cast(b.name as varchar) as billingType," +
						" 0 as pmApprovalStatus," +
						" 0 as otherInvoicesCount," +
						" 0 as CrDrCount, " +
						" '0' as internalInvoiceNo, " +
						" '' as endClientProjName, " +
						" '' as country," +
						" '' as currency, " +
						" 0 as onShoreDevTotal, " +
						" 0 as offShoreDevTotal, " +
						" '' as projectType, " +
						" u.unitId, " +
						" 0 as interUnitCount " +
						" FROM " +LoadConstant.infomaster+".[dbo].project p" +
						" left join " +LoadConstant.otc+".[dbo].invoices i on p.itemid = i.projectId" +
						" LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[unit] u on u.unitId = p.billingUnitId "+
						" LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[entities] e on e.entityId = u.entityId "+
						" LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[billingType] b on b.billingTypeId = p.billingTypeId " +
						//" where p.state = '(2) Active'" + 
						" where  b.name <> 'None'" + // Where billing type is 'None'
						" and u.name = :billingUnit and finalInvoiceNo is not null" +
						" and invoiceType=:invoiceType"+
						" order by i.arSubmitDate desc ",
	                      resultClass=Invoices.class, resultSetMapping = "project_for_invoices"                       		
	    ),
	    @NamedNativeQuery(
	            name    =   "getFinalInvoiceNosForInternalInvoice",
	            query   =  " select distinct(finalInvoiceNo) as finalInvoiceNo, 0 as itemId, '' as projectName from  " +LoadConstant.otc+".[dbo].invoices "+
	            		" where cast(periodStartDate as DATE) >= :monthstartDate" +
						" and cast(periodStartDate as DATE) <= :monthEndDate and finalInvoiceNo is not null and projectId in" +
						" (select itemId from " + LoadConstant.infomaster +".dbo.project"  +
						" where billingTypeId = (select billingtypeId from " + LoadConstant.infomaster +".dbo.billingType" +
						" where name = 'Fixed Bid Milestone')) order by finalinvoiceNo",
	                      resultClass=Invoices.class, resultSetMapping = "internal_invoices_result"                       		
	    )
	    ,
	    @NamedNativeQuery(
	            name    =   "getEndClientProjectsForInternalInvoice",
	            query   =    "	select '' as finalInvoiceNo, itemId, cast(title as varchar(MAX)) as projectName from " + LoadConstant.infomaster +".dbo.project where billingTypeId = (select " +
	            		" billingtypeId from " + LoadConstant.infomaster +".dbo.billingType where name = 'Fixed Bid Milestone' " + 
	            		" and (cast(projectStart as DATE) <= :monthEndDate or projectStart is null) " +
	            		" and (cast(projectEnd as DATE) >= :monthstartDate or projectEnd is null)) " +
	            		" order by title",
	                      resultClass=Invoices.class, resultSetMapping = "internal_invoices_result"
	    )
	    ,
	    @NamedNativeQuery(
	            name    =   "getInvoiceRevenueYTD",
	            query   = 	QueryConstant.Query_Revenue_Invoice_YTD,
	            			resultClass=Invoices.class, resultSetMapping = "project_for_invoices"
	    )
	    ,
	    @NamedNativeQuery(
	            name    =   "getMonthlyTimesheetReport",
	            query   = 	QueryConstant.Query_Monthly_Timesheet_Report,
	            			resultClass=Invoices.class, resultSetMapping = "report_timesheet_result"
	    )
	    ,
	    @NamedNativeQuery(
	            name    =   "getMonthlyInvoiceReport",
	            query   = 	QueryConstant.Query_Monthly_Invoices_Report,
	            			resultClass=Invoices.class, resultSetMapping = "report_invoices_result"
	    )
	    ,
	    @NamedNativeQuery(
	            name    =   "getInvoiceByInvoiceNo",
	            query   = 	QueryConstant.Query_Search_By_InvoiceNo,
	            			resultClass=Invoices.class, resultSetMapping = "project_for_invoices"
	    )
})
public class Invoices {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer invoiceId;
	
	private String arHeaderId;
	
	private Integer projectId;
	
	private String clientPm;
	
	private Date periodStartDate;
	
    private Date periodEndDate;
	
	private String rmId;
	
	private String dmId;
	
	private Integer pmId;
	
	private Integer billingAccountId;
	private Integer shippingAccountId;
	
	@Transient
	private Integer  itemId;
	
	@Transient
	private String projectName;
	
	@Transient
	private Integer accountId;
	
	@Transient
	private String accountName;
	
	@Transient
	private String billingUnit;
	
	@Transient
	private String billingEntity;
	
	@Transient
	private String billingType;
	
	@Transient 
	private Integer pmApprovalStatus;
	
	@Transient 
	private Integer otherInvoicesCount;
	
	@Transient 
	private Integer CrDrCount;
	
	@Transient
	private String internalInvoiceNo;
	
	@Transient
	private String endClientProjName;
	
	@Transient
	private String  country;
	
	@Transient
	private String currency;
	
	@Transient
	private BigDecimal onShoreDevTotal;
	
	@Transient
	private BigDecimal offShoreDevTotal;
	
	@Transient
	private String currSign;
	 
	@Transient
	private String resourceName;
	 
	@Transient
	private String countryName;
	 
	@Transient
	private BigDecimal billableRate;
	 
	@Transient
	private BigDecimal tsHrs;
	  
	@Transient
	private String uom;
	
	@Transient
	private String sowNo;
	
	@Transient
	private String projectType;
	
	@Transient
	private Integer unitId;
	
    @Transient
	private Integer invoiceCount;
    
	@Transient 
	private Integer interUnitCount;
	
	private String invoiceNo;
	
	private String finalInvoiceNo;
	
	private Date arDraftDate; // Date on which the draft invoice is created by Invoices Team
	
	private Date arInvoiceDate; //the standard cut off Date for Invoicing
	
	private Date arApprovalDate; // Date on which the draft invoice is approved is approved by PM/DM
	
	private Date arSubmitDate; // Date on which the approved invoice is submitted by Invoices Team to client
	
	private String invoiceStatus; // Invoice status - Draft/Approved/Rejected/Cancelled (from the invoice status master)
	
	@Lob
	private String 	comments;
	
	private String invoiceType;
	
	@Column(precision=12,scale=2)
	private BigDecimal subtotal; 
	
	@Column(precision=6,scale=2)
	private BigDecimal flatDiscountPer;
	
	@Column(precision=12,scale=2)
	private BigDecimal discountAmt;  
	
	@Column(precision=12,scale=2)
	private BigDecimal netSubTotal;
	
	@Column(precision=12,scale=2)
	private BigDecimal total;
	
	private String approvedRejectedBy;
	
	@Lob
	private String approveRejectComment;
	
	private String endClientInvoiceNo;
	
	private Integer endClientProjectId;
  
	private Integer modifiedBy;
	private Date modifiedDate;    
	private Integer createdBy;
	
	private String invoices;
	
	@Column(precision=6,scale=2)
	private BigDecimal flatdiscountPer2;
	
	@Column(precision=6,scale=2)
	private BigDecimal sbcTax;
	
	@Column(precision=12,scale=2)
	private BigDecimal sbcTaxAmt;
	
	@Column(precision=6,scale=2)
	private BigDecimal tax;
	
	@Column(precision=12,scale=2)
	private BigDecimal taxAmt;
	
	private String roundOff;
	
	@Column(precision=6,scale=2)
	private BigDecimal kkTax;
	
	@Column(precision=12,scale=2)
	private BigDecimal kkTaxAmt;
	
	@Column(precision=6,scale=2)
	private BigDecimal vat;
	
	@Column(precision=12,scale=2)
	private BigDecimal vatAmt;
	
	private String gstRegNo;
	
	private String typeSupply;
	
	private String filePath;
	
	@Column(precision=6,scale=2)
	private BigDecimal cgst;
	
	@Column(precision=12,scale=2)
	private BigDecimal cgstAmt;
	
	@Column(precision=6,scale=2)
	private BigDecimal sgst;
	
	@Column(precision=12,scale=2)
	private BigDecimal sgstAmt;
	
	@Column(precision=6,scale=2)
	private BigDecimal igst;
	
	@Column(precision=12,scale=2)
	private BigDecimal igstAmt;
	
	@Column(precision=6,scale=2)
	private BigDecimal utgst;
	
	@Column(precision=12,scale=2)
	private BigDecimal utgstAmt;
	
	@Column(precision=6,scale=2)
	private BigDecimal sgdGst;
	
	@Column(precision=12,scale=2)
	private BigDecimal sgdGstAmt;
	
	private Boolean zeroRatedSupplyFlag;
	
	private Boolean submitted;
	
	@Column(precision=12,scale=5)
	private BigDecimal exchangeRate;
	
    private Integer exchangecurrencyId;
    
    private String clientPO;
    
    private Integer currencyId;
    
    private String unbilledReason;
    
    private Integer uomId;
	
    @Lob
    private String amountInwords;
    
    @Transient
    private List<WeeklyHours> weeklyhours;
    
    
    private Integer ahId;
    
	
	private Integer invoiceToUnit;
	
	private Integer invoiceFromUnit;
    
	public Integer getInvoiceId() {
		return invoiceId;
	}



	public void setInvoiceId(Integer invoiceId) {
		this.invoiceId = invoiceId;
	}



	public String getArHeaderId() {
		return arHeaderId;
	}



	public void setArHeaderId(String arHeaderId) {
		this.arHeaderId = arHeaderId;
	}



	public Integer getProjectId() {
		return projectId;
	}



	public void setProjectId(Integer projectId) {
		this.projectId = projectId;
	}



	public String getClientPm() {
		return clientPm;
	}



	public void setClientPm(String clientPm) {
		this.clientPm = clientPm;
	}



	public Date getPeriodStartDate() {
		return periodStartDate;
	}



	public void setPeriodStartDate(Date periodStartDate) {
		this.periodStartDate = periodStartDate;
	}



	public Date getPeriodEndDate() {
		return periodEndDate;
	}



	public void setPeriodEndDate(Date periodEndDate) {
		this.periodEndDate = periodEndDate;
	}



	public String getRmId() {
		return rmId;
	}



	public void setRmId(String rmId) {
		this.rmId = rmId;
	}



	public String getDmId() {
		return dmId;
	}



	public void setDmId(String dmId) {
		this.dmId = dmId;
	}



	public Integer getPmId() {
		return pmId;
	}



	public void setPmId(Integer pmId) {
		this.pmId = pmId;
	}



	public Integer getItemId() {
		return itemId;
	}



	public void setItemId(Integer itemId) {
		this.itemId = itemId;
	}



	public String getProjectName() {
		return projectName;
	}



	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}



	public Integer getAccountId() {
		return accountId;
	}



	public void setAccountId(Integer accountId) {
		this.accountId = accountId;
	}



	public String getAccountName() {
		return accountName;
	}



	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}



	public String getBillingEntity() {
		return billingEntity;
	}



	public void setBillingEntity(String billingEntity) {
		this.billingEntity = billingEntity;
	}



	public String getBillingType() {
		return billingType;
	}



	public void setBillingType(String billingType) {
		this.billingType = billingType;
	}

	

	public String getInternalInvoiceNo() {
		return internalInvoiceNo;
	}



	public void setInternalInvoiceNo(String internalInvoiceNo) {
		this.internalInvoiceNo = internalInvoiceNo;
	}



	public String getEndClientProjName() {
		return endClientProjName;
	}


	
	
	public void setEndClientProjName(String endClientProjName) {
		this.endClientProjName = endClientProjName;
	}

	public String getCurrSign() {
		return currSign;
	}
	
	public void setCurrSign(String currSign) {
		this.currSign=currSign;
	}

	public String getBillingUnit() {
		return billingUnit;
	}



	public void setBillingUnit(String billingUnit) {
		this.billingUnit = billingUnit;
	}



	public String getFilePath() {
		return filePath;
	}



	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}



	public Integer getPmApprovalStatus() {
		return pmApprovalStatus;
	}



	public void setPmApprovalStatus(Integer pmApprovalStatus) {
		this.pmApprovalStatus = pmApprovalStatus;
	}

    

	public Integer getOtherInvoicesCount() {
		return otherInvoicesCount;
	}



	public void setOtherInvoicesCount(Integer otherInvoicesCount) {
		this.otherInvoicesCount = otherInvoicesCount;
	}



	public Integer getCrDrCount() {
		return CrDrCount;
	}



	public void setCrDrCount(Integer crDrCount) {
		CrDrCount = crDrCount;
	}



	public String getInvoiceNo() {
		return invoiceNo;
	}



	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}

	

	public String getFinalInvoiceNo() {
		return finalInvoiceNo;
	}



	public void setFinalInvoiceNo(String finalInvoiceNo) {
		this.finalInvoiceNo = finalInvoiceNo;
	}



	public Date getArDraftDate() {
		return arDraftDate;
	}



	public void setArDraftDate(Date arDraftDate) {
		this.arDraftDate = arDraftDate;
	}

	

	public Date getArInvoiceDate() {
		return arInvoiceDate;
	}



	public void setArInvoiceDate(Date arInvoiceDate) {
		this.arInvoiceDate = arInvoiceDate;
	}



	public Date getArApprovalDate() {
		return arApprovalDate;
	}



	public void setArApprovalDate(Date arApprovalDate) {
		this.arApprovalDate = arApprovalDate;
	}



	public Date getArSubmitDate() {
		return arSubmitDate;
	}



	public void setArSubmitDate(Date arSubmitDate) {
		this.arSubmitDate = arSubmitDate;
	}



	public String getInvoiceStatus() {
		return invoiceStatus;
	}



	public void setInvoiceStatus(String invoiceStatus) {
		this.invoiceStatus = invoiceStatus;
	}



	public String getComments() {
		return comments;
	}



	public void setComments(String comments) {
		this.comments = comments;
	}



	public String getInvoiceType() {
		return invoiceType;
	}



	public void setInvoiceType(String invoiceType) {
		this.invoiceType = invoiceType;
	}



	public BigDecimal getSubtotal() {
		return subtotal;
	}



	public void setSubtotal(BigDecimal subtotal) {
		this.subtotal = subtotal;
	}



	public BigDecimal getFlatDiscountPer() {
		return flatDiscountPer;
	}



	public void setFlatDiscountPer(BigDecimal flatDiscountPer) {
		this.flatDiscountPer = flatDiscountPer;
	}



	public BigDecimal getDiscountAmt() {
		return discountAmt;
	}



	public void setDiscountAmt(BigDecimal discountAmt) {
		this.discountAmt = discountAmt;
	}



	public BigDecimal getNetSubTotal() {
		return netSubTotal;
	}



	public void setNetSubTotal(BigDecimal netSubTotal) {
		this.netSubTotal = netSubTotal;
	}



	public BigDecimal getTotal() {
		return total;
	}



	public void setTotal(BigDecimal total) {
		this.total = total;
	}


	public String getApprovedRejectedBy() {
		return approvedRejectedBy;
	}



	public void setApprovedRejectedBy(String approvedRejectedBy) {
		this.approvedRejectedBy = approvedRejectedBy;
	}



	public String getApproveRejectComment() {
		return approveRejectComment;
	}



	public void setApproveRejectComment(String approveRejectComment) {
		this.approveRejectComment = approveRejectComment;
	}



	public String getEndClientInvoiceNo() {
		return endClientInvoiceNo;
	}



	public void setEndClientInvoiceNo(String endClientInvoiceNo) {
		this.endClientInvoiceNo = endClientInvoiceNo;
	}

	

	public Integer getEndClientProjectId() {
		return endClientProjectId;
	}



	public void setEndClientProjectId(Integer endClientProjectId) {
		this.endClientProjectId = endClientProjectId;
	}



	public Integer getModifiedBy() {
		return modifiedBy;
	}



	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}



	public Date getModifiedDate() {
		return modifiedDate;
	}



	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}



	public Integer getCreatedBy() {
		return createdBy;
	}



	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}



	public String getInvoices() {
		return invoices;
	}



	public void setInvoices(String invoices) {
		this.invoices = invoices;
	}



	public BigDecimal getFlatdiscountPer2() {
		return flatdiscountPer2;
	}



	public void setFlatdiscountPer2(BigDecimal flatdiscountPer2) {
		this.flatdiscountPer2 = flatdiscountPer2;
	}



	public BigDecimal getSbcTax() {
		return sbcTax;
	}



	public void setSbcTax(BigDecimal sbcTax) {
		this.sbcTax = sbcTax;
	}



	public BigDecimal getSbcTaxAmt() {
		return sbcTaxAmt;
	}



	public void setSbcTaxAmt(BigDecimal sbcTaxAmt) {
		this.sbcTaxAmt = sbcTaxAmt;
	}



	public BigDecimal getTax() {
		return tax;
	}



	public void setTax(BigDecimal tax) {
		this.tax = tax;
	}



	public BigDecimal getTaxAmt() {
		return taxAmt;
	}



	public void setTaxAmt(BigDecimal taxAmt) {
		this.taxAmt = taxAmt;
	}



	public String getRoundOff() {
		return roundOff;
	}



	public void setRoundOff(String roundOff) {
		this.roundOff = roundOff;
	}



	public BigDecimal getKkTax() {
		return kkTax;
	}



	public void setKkTax(BigDecimal kkTax) {
		this.kkTax = kkTax;
	}



	public BigDecimal getKkTaxAmt() {
		return kkTaxAmt;
	}



	public void setKkTaxAmt(BigDecimal kkTaxAmt) {
		this.kkTaxAmt = kkTaxAmt;
	}



	public BigDecimal getVat() {
		return vat;
	}



	public void setVat(BigDecimal vat) {
		this.vat = vat;
	}



	public BigDecimal getVatAmt() {
		return vatAmt;
	}



	public void setVatAmt(BigDecimal vatAmt) {
		this.vatAmt = vatAmt;
	}



	public String getGstRegNo() {
		return gstRegNo;
	}



	public void setGstRegNo(String gstRegNo) {
		this.gstRegNo = gstRegNo;
	}



	public String getTypeSupply() {
		return typeSupply;
	}



	public void setTypeSupply(String typeSupply) {
		this.typeSupply = typeSupply;
	}



	public BigDecimal getCgst() {
		return cgst;
	}



	public void setCgst(BigDecimal cgst) {
		this.cgst = cgst;
	}



	public BigDecimal getCgstAmt() {
		return cgstAmt;
	}



	public void setCgstAmt(BigDecimal cgstAmt) {
		this.cgstAmt = cgstAmt;
	}



	public BigDecimal getSgst() {
		return sgst;
	}



	public void setSgst(BigDecimal sgst) {
		this.sgst = sgst;
	}



	public BigDecimal getSgstAmt() {
		return sgstAmt;
	}



	public void setSgstAmt(BigDecimal sgstAmt) {
		this.sgstAmt = sgstAmt;
	}



	public BigDecimal getIgst() {
		return igst;
	}



	public void setIgst(BigDecimal igst) {
		this.igst = igst;
	}



	public BigDecimal getIgstAmt() {
		return igstAmt;
	}



	public void setIgstAmt(BigDecimal igstAmt) {
		this.igstAmt = igstAmt;
	}



	public BigDecimal getUtgst() {
		return utgst;
	}



	public void setUtgst(BigDecimal utgst) {
		this.utgst = utgst;
	}



	public BigDecimal getUtgstAmt() {
		return utgstAmt;
	}



	public void setUtgstAmt(BigDecimal utgstAmt) {
		this.utgstAmt = utgstAmt;
	}

	

	public BigDecimal getSgdGst() {
		return sgdGst;
	}



	public void setSgdGst(BigDecimal sgdGst) {
		this.sgdGst = sgdGst;
	}



	public BigDecimal getSgdGstAmt() {
		return sgdGstAmt;
	}



	public void setSgdGstAmt(BigDecimal sgdGstAmt) {
		this.sgdGstAmt = sgdGstAmt;
	}



	public Boolean getZeroRatedSupplyFlag() {
		return zeroRatedSupplyFlag;
	}
	
	
	public void setZeroRatedSupplyFlag(Boolean zeroRatedSupplyFlag) {
		this.zeroRatedSupplyFlag = zeroRatedSupplyFlag;
	}


	public Boolean getSubmitted() {
		return submitted;
	}



	public void setSubmitted(Boolean submitted) {
		this.submitted = submitted;
	}

	



	public BigDecimal getExchangeRate() {
		return exchangeRate;
	}



	public void setExchangeRate(BigDecimal exchangeRate) {
		this.exchangeRate = exchangeRate;
	}



	public Integer getExchangecurrencyId() {
		return exchangecurrencyId;
	}



	public void setExchangecurrencyId(Integer exchangecurrencyId) {
		this.exchangecurrencyId = exchangecurrencyId;
	}

	

	public String getClientPO() {
		return clientPO;
	}



	public void setClientPO(String clientPO) {
		this.clientPO = clientPO;
	}



	public Integer getCurrencyId() {
		return currencyId;
	}



	public void setCurrencyId(Integer currencyId) {
		this.currencyId = currencyId;
	}

	

	public String getUnbilledReason() {
		return unbilledReason;
	}



	public void setUnbilledReason(String unbilledReason) {
		this.unbilledReason = unbilledReason;
	}

    

	public Integer getUomId() {
		return uomId;
	}



	public void setUomId(Integer uomId) {
		this.uomId = uomId;
	}

	

	public String getAmountInwords() {
		return amountInwords;
	}



	public void setAmountInwords(String amountInwords) {
		this.amountInwords = amountInwords;
	}

	

	public Integer getAhId() {
		return ahId;
	}

	public void setAhId(Integer ahId) {
		this.ahId = ahId;
	}
	
	
	/**
	 * @return the country
	 */
	public String getCountry() {
		return country;
	}



	/**
	 * @param country the country to set
	 */
	public void setCountry(String country) {
		this.country = country;
	}



	/**
	 * @return the currency
	 */
	public String getCurrency() {
		return currency;
	}



	/**
	 * @param currency the currency to set
	 */
	public void setCurrency(String currency) {
		this.currency = currency;
	}



	/**
	 * @return the onShoreDevTotal
	 */
	public BigDecimal getOnShoreDevTotal() {
		return onShoreDevTotal;
	}



	/**
	 * @param onShoreDevTotal the onShoreDevTotal to set
	 */
	public void setOnShoreDevTotal(BigDecimal onShoreDevTotal) {
		this.onShoreDevTotal = onShoreDevTotal;
	}



	/**
	 * @return the offShoreDevTotal
	 */
	public BigDecimal getOffShoreDevTotal() {
		return offShoreDevTotal;
	}



	/**
	 * @param offShoreDevTotal the offShoreDevTotal to set
	 */
	public void setOffShoreDevTotal(BigDecimal offShoreDevTotal) {
		this.offShoreDevTotal = offShoreDevTotal;
	}



	/**
	 * @return the resourceName
	 */
	public String getResourceName() {
		return resourceName;
	}



	/**
	 * @param resourceName the resourceName to set
	 */
	public void setResourceName(String resourceName) {
		this.resourceName = resourceName;
	}



	/**
	 * @return the countryName
	 */
	public String getCountryName() {
		return countryName;
	}



	/**
	 * @param countryName the countryName to set
	 */
	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}



	/**
	 * @return the billableRate
	 */
	public BigDecimal getBillableRate() {
		return billableRate;
	}



	/**
	 * @param billableRate the billableRate to set
	 */
	public void setBillableRate(BigDecimal billableRate) {
		this.billableRate = billableRate;
	}



	/**
	 * @return the tsHrs
	 */
	public BigDecimal getTsHrs() {
		return tsHrs;
	}



	/**
	 * @param tsHrs the tsHrs to set
	 */
	public void setTsHrs(BigDecimal tsHrs) {
		this.tsHrs = tsHrs;
	}



	/**
	 * @return the uom
	 */
	public String getUom() {
		return uom;
	}
	


	
	/**
	 * @param uom the uom to set
	 */
	public void setUom(String uom) {
		this.uom = uom;
	}

	
	/**
	 * @return the invoiceCount
	 */
	public Integer getInvoiceCount() {
		return invoiceCount;
	}



	/**
	 * @param invoiceCount the invoiceCount to set
	 */
	public void setInvoiceCount(Integer invoiceCount) {
		this.invoiceCount = invoiceCount;
	}
/**
	 * @return the projectType
	 */
	public String getProjectType() {
		return projectType;
	}



	/**
	 * @param projectType the projectType to set
	 */
	public void setProjectType(String projectType) {
		this.projectType = projectType;
	}
	
	/**
	 * @return the unitId
	 */
	public Integer getUnitId() {
		return unitId;
	}



	/**
	 * @param unitId the unitId to set
	 */
	public void setUnitId(Integer unitId) {
		this.unitId = unitId;
	}



	public Integer getInterUnitCount() {
		return interUnitCount;
	}



	public void setInterUnitCount(Integer interUnitCount) {
		this.interUnitCount = interUnitCount;
	}




	public Integer getInvoiceToUnit() {
		return invoiceToUnit;
	}



	public void setInvoiceToUnit(Integer invoiceToUnit) {
		this.invoiceToUnit = invoiceToUnit;
	}



	public Integer getInvoiceFromUnit() {
		return invoiceFromUnit;
	}



	public void setInvoiceFromUnit(Integer invoiceFromUnit) {
		this.invoiceFromUnit = invoiceFromUnit;
	}



	/**
	 * @return the billingAccountId
	 */
	public Integer getBillingAccountId() {
		return billingAccountId;
	}



	/**
	 * @param billingAccountId the billingAccountId to set
	 */
	public void setBillingAccountId(Integer billingAccountId) {
		this.billingAccountId = billingAccountId;
	}



	/**
	 * @return the shippingAccountId
	 */
	public Integer getShippingAccountId() {
		return shippingAccountId;
	}



	/**
	 * @param shippingAccountId the shippingAccountId to set
	 */
	public void setShippingAccountId(Integer shippingAccountId) {
		this.shippingAccountId = shippingAccountId;
	}



	/**
	 * @return the sowNo
	 */
	public String getSowNo() {
		return sowNo;
	}



	/**
	 * @param sowNo the sowNo to set
	 */
	public void setSowNo(String sowNo) {
		this.sowNo = sowNo;
	}



	public Invoices() {
	}
	
	public Invoices(Integer invoiceId, String arHeaderId, Integer projectId, String clientPm, Date periodStartDate,
			Date periodEndDate, String rmId, String dmId, Integer pmId, String invoiceNo, String finalInvoiceNo, Date arDraftDate, Date arInvoiceDate, Date arApprovalDate, Date arSubmitDate, String invoiceStatus,
			String comments, String invoiceType, BigDecimal subtotal, BigDecimal flatDiscountPer, BigDecimal discountAmt,
			BigDecimal netSubTotal, BigDecimal total, String approvedRejectedBy,
			String approveRejectComment, String endClientInvoiceNo,Integer endClientProjectId, Integer modifiedBy, Date modifiedDate,
			Integer createdBy, String invoices, BigDecimal flatdiscountPer2, BigDecimal sbcTax, BigDecimal sbcTaxAmt, BigDecimal tax,
			BigDecimal taxAmt, String roundOff, BigDecimal kkTax, BigDecimal kkTaxAmt, BigDecimal vat, BigDecimal vatAmt, String gstRegNo,
			String typeSupply, BigDecimal cgst, BigDecimal cgstAmt, BigDecimal sgst, BigDecimal sgstAmt, BigDecimal igst, BigDecimal igstAmt,
			BigDecimal utgst, BigDecimal utgstAmt, BigDecimal sgdGst,BigDecimal sgdGstAmt,String filePath, Boolean zeroRatedSupplyFlag, Boolean submitted, BigDecimal exchangeRate, Integer exchangecurrencyId, 
			String clientPO,Integer currencyId,String unbilledReason,String billingUnit, Integer uomId,String amountInwords, Integer ahId, Integer invoiceFromUnit, Integer invoiceToUnit,Integer billingAccountId, Integer shippingAccountId,  Integer itemId, String projectName,Integer accountId, String accountName, String billingEntity, 
			 String billingType,Integer pmApprovalStatus, Integer otherInvoicesCount,
			Integer CrDrCount, String internalInvoiceNo, String endClientProjName,String currSign,String country,String currency,BigDecimal onShoreDevTotal,BigDecimal offShoreDevTotal, String projectType, Integer unitId, Integer interUnitCount) {
		super();
		this.invoiceId = invoiceId;
		this.arHeaderId = arHeaderId;
		if(projectId == null)
		{
			this.projectId = itemId;
		}
		else
		{
			this.projectId = projectId;
		}
		this.clientPm = clientPm;
		this.periodStartDate = periodStartDate;
		this.periodEndDate = periodEndDate;
		this.rmId = rmId;
		this.dmId = dmId;
		this.pmId = pmId;
		this.invoiceNo = invoiceNo;
		this.finalInvoiceNo = finalInvoiceNo;
		this.arDraftDate = arDraftDate;
		this.arInvoiceDate = arInvoiceDate;
		this.arApprovalDate = arApprovalDate;
		this.arSubmitDate = arSubmitDate;
		this.invoiceStatus = invoiceStatus;
		this.comments = comments;
		this.invoiceType = invoiceType;
		this.subtotal = subtotal;
		this.flatDiscountPer = flatDiscountPer;
		this.discountAmt = discountAmt;
		this.netSubTotal = netSubTotal;
		this.total = total;
		this.approvedRejectedBy = approvedRejectedBy;
		this.approveRejectComment = approveRejectComment;
		this.endClientInvoiceNo = endClientInvoiceNo;
		this.endClientProjectId = endClientProjectId;
		this.modifiedBy = modifiedBy;
		this.modifiedDate = modifiedDate;
		this.createdBy = createdBy;
		this.invoices = invoices;
		this.flatdiscountPer2 = flatdiscountPer2;
		this.sbcTax = sbcTax;
		this.sbcTaxAmt = sbcTaxAmt;
		this.tax = tax;
		this.taxAmt = taxAmt;
		this.roundOff = roundOff;
		this.kkTax = kkTax;
		this.kkTaxAmt = kkTaxAmt;
		this.vat = vat;
		this.vatAmt = vatAmt;
		this.gstRegNo = gstRegNo;
		this.typeSupply = typeSupply;
		this.cgst = cgst;
		this.cgstAmt = cgstAmt;
		this.sgst = sgst;
		this.sgstAmt = sgstAmt;
		this.igst = igst;
		this.igstAmt = igstAmt;
		this.utgst = utgst;
		this.utgstAmt = utgstAmt;
		this.sgdGst=sgdGst;
		this.sgdGstAmt=sgdGstAmt;
		this.filePath = filePath;
		this.zeroRatedSupplyFlag = zeroRatedSupplyFlag;
		this.submitted = submitted;
		this.exchangeRate = exchangeRate;
		this.exchangecurrencyId = exchangecurrencyId;
		this.clientPO = clientPO;
		this.currencyId = currencyId;
		this.unbilledReason=unbilledReason;
		this.billingUnit = billingUnit;
		this.uomId = uomId;
		this.amountInwords=amountInwords;
		this.ahId = ahId;
		this.invoiceFromUnit = invoiceFromUnit;
		this.invoiceToUnit = invoiceToUnit;
		this.billingAccountId = billingAccountId;
		this.shippingAccountId = shippingAccountId;
		this.itemId = itemId;
		this.projectName = projectName;
		this.accountId = accountId;
		this.accountName = accountName;
		this.billingUnit = billingUnit;
		this.billingEntity = billingEntity;
		this.billingType = billingType;
		this.pmApprovalStatus = pmApprovalStatus;
		this.otherInvoicesCount = otherInvoicesCount;
		this.CrDrCount = CrDrCount;
		this.internalInvoiceNo=internalInvoiceNo;
		this.endClientProjName = endClientProjName;
		this.currSign=currSign;
		this.country = country;
		this.currency = currency;
		this.onShoreDevTotal = onShoreDevTotal;
		this.offShoreDevTotal = offShoreDevTotal;
		this.projectType = projectType;
		this.unitId = unitId;
		this.interUnitCount = interUnitCount;

	}
	
   
	


	public Invoices( String finalInvoiceNo,Integer itemId, String projectName) {
		super();
		this.finalInvoiceNo = finalInvoiceNo;
		this.itemId = itemId;
		this.projectName = projectName;
	}



	public List<WeeklyHours> getWeeklyhours() {
		return weeklyhours;
	}



	public void setWeeklyhours(List<WeeklyHours> weeklyhours) {
		this.weeklyhours = weeklyhours;
	}

	public Invoices(String accountName,String projectName,String resourceName, String countryName,BigDecimal billableRate,String currency,  
			 BigDecimal tsHrs, String uom, String sowNo) {
		super();
		this.accountName = accountName;
		this.projectName = projectName;
		this.resourceName = resourceName;
		this.countryName = countryName;
		this.billableRate = billableRate;
		this.currency = currency;
		this.tsHrs = tsHrs;
		this.uom = uom;
		this.sowNo = sowNo;
	}

	public Invoices(String accountName,String projectName,String clientPO,String finalInvoiceNo,String invoiceType,String endClientInvoiceNo,String endClientProjName, 
			Date arInvoiceDate, String currency, BigDecimal netSubTotal, BigDecimal cgstAmt,  BigDecimal sgstAmt,  BigDecimal igstAmt,
			 BigDecimal utgstAmt, BigDecimal sgdGstAmt ,BigDecimal total) {
		super();
		this.accountName = accountName;
		this.projectName = projectName;
		this.clientPO = clientPO;
		this.finalInvoiceNo = finalInvoiceNo;
		this.invoiceType = invoiceType;
		this.endClientInvoiceNo = endClientInvoiceNo;
		this.endClientProjName = endClientProjName;
		this.arInvoiceDate = arInvoiceDate;
		this.currency = currency;
		this.netSubTotal = netSubTotal;
		this.cgstAmt = cgstAmt;
		this.sgstAmt = sgstAmt;
		this.igstAmt = igstAmt;
		this.utgstAmt = utgstAmt;
		this.sgdGstAmt=sgdGstAmt;
		this.total = total;
	}
	
	

	public Invoices(Integer invoiceCount, String invoiceStatus) {
		super();
		this.invoiceCount = invoiceCount;
		this.invoiceStatus = invoiceStatus;
	}



	@Override
	public String toString() {
		return "Invoices [invoiceId=" + invoiceId + ", arHeaderId=" + arHeaderId + ", projectId=" + projectId
				+ ", clientPm=" + clientPm + ", periodStartDate=" + periodStartDate + ", periodEndDate=" + periodEndDate
				+ ", rmId=" + rmId + ", dmId=" + dmId + ", pmId=" + pmId + ", itemId=" + itemId + ", projectName="
				+ projectName + ", accountId=" + accountId + ", accountName=" + accountName + ", billingUnit=" + billingUnit + ", billingEntity=" + billingEntity
				+ ", billingType=" + billingType + ", pmApprovalStatus=" + pmApprovalStatus + ", otherInvoicesCount="
				+ otherInvoicesCount + ", CrDrCount=" + CrDrCount + ", internalInvoiceNo=" + internalInvoiceNo 
				+", endClientProjName=" + endClientProjName +", invoiceNo=" + invoiceNo + ", finalInvoiceNo=" 
				+ finalInvoiceNo + ", arDraftDate=" + arDraftDate + ", arInvoiceDate=" + arInvoiceDate + ", arApprovalDate=" + arApprovalDate
				+ ", arSubmitDate=" + arSubmitDate + ", invoiceStatus=" + invoiceStatus + ", comments=" + comments
				+ ", invoiceType=" + invoiceType + ", subtotal=" + subtotal + ", flatDiscountPer=" + flatDiscountPer
				+ ", discountAmt=" + discountAmt + ", netSubTotal=" + netSubTotal + ", total=" + total
				 + ", approvedRejectedBy=" + approvedRejectedBy
				+ ", approveRejectComment=" + approveRejectComment + ", endClientInvoiceNo=" + endClientInvoiceNo
				+ ", modifiedBy=" + modifiedBy + ", modifiedDate=" + modifiedDate + ", createdBy=" + createdBy
				+ ", invoices=" + invoices + ", flatdiscountPer2=" + flatdiscountPer2 + ", sbcTax=" + sbcTax
				+ ", sbcTaxAmt=" + sbcTaxAmt + ", tax=" + tax + ", taxAmt=" + taxAmt + ", roundOff=" + roundOff
				+ ", kkTax=" + kkTax + ", kkTaxAmt=" + kkTaxAmt + ", vat=" + vat + ", vatAmt=" + vatAmt + ", gstRegNo="
				+ gstRegNo + ", typeSupply=" + typeSupply + ", filePath=" + filePath + ", cgst=" + cgst + ", cgstAmt="
				+ cgstAmt + ", sgst=" + sgst + ", sgstAmt=" + sgstAmt + ", igst=" + igst + ", igstAmt=" + igstAmt
				+ ", utgst=" + utgst + ", utgstAmt=" + utgstAmt + ", zeroRatedSupplyFlag=" + zeroRatedSupplyFlag
				+ ", submitted=" + submitted + ", exchangeRate=" + exchangeRate + ", exchangecurrencyId="
				+ exchangecurrencyId + ", clientPO=" + clientPO +  ", unbilledReason="+ unbilledReason +
				", billingUnit="+ billingUnit +", amountInwords="+ amountInwords+"]"; 
	} 
}
