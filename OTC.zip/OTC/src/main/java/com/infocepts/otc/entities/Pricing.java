package com.infocepts.otc.entities;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;

import com.infocepts.otc.utilities.LoadConstant;
@Entity
@Table(catalog=LoadConstant.otc, schema="[dbo]", name="pricing")
public class Pricing {
	// Entity Columns
    // --------------------------------------------------------------------------------
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Integer pricingId; 
    
    private Integer cmsId;
    @Column(precision=18,scale=2)
    private BigDecimal bufferCost;
    @Column(precision=18,scale=2)
    private BigDecimal payrollOffshore;
    @Column(precision=18,scale=2)
    private BigDecimal payrollOnshore;
    @Column(precision=18,scale=2)
    private BigDecimal revenueOffshore;
    @Column(precision=18,scale=2)
    private BigDecimal revenueOnshore;
    @Column(precision=18,scale=2)
    private BigDecimal totalPayroll;
    @Column(precision=18,scale=2)
    private BigDecimal totalRevenue;
    @Column(precision=18,scale=2)
    private BigDecimal managerCostApportionment;
    @Column(precision=18,scale=2)
    private BigDecimal attritionCost;
    @Column(precision=18,scale=2)
    private BigDecimal attritionPercent;
    @Column(precision=18,scale=2)
    private BigDecimal travelBusiness;
    @Column(precision=18,scale=2)
    private BigDecimal cabForShift;
    @Column(precision=18,scale=2)
    private BigDecimal travelDeputation;
    @Column(precision=18,scale=2)
    private BigDecimal otherCost;
    @Column(precision=18,scale=2)
    private BigDecimal teamEngagement;
    @Column(precision=18,scale=2)
    private BigDecimal customerEngagement;
    @Column(precision=18,scale=2)
    private BigDecimal totalNonPayrollCost;
    @Column(precision=18,scale=2)
    private BigDecimal contingency;
    @Column(precision=18,scale=2)
    private BigDecimal contingencyPercent;
    @Column(precision=18,scale=2)//
    private BigDecimal exchangeAdder;
    @Column(precision=18,scale=2)//
    private BigDecimal exchangeAdderOnshore;
    @Column(precision=18,scale=2)
    private BigDecimal exchangeAdderOffshore;
    @Column(precision=18,scale=2)
    private BigDecimal exchangeAdderOnshorePercent;
    @Column(precision=18,scale=2)
    private BigDecimal exchangeAdderOffshorePercent;
    @Column(precision=18,scale=2)
    private BigDecimal paymentAdder;
    @Column(precision=18,scale=2)
    private BigDecimal paymentAdderPercent;
    @Column(precision=18,scale=2)
    private BigDecimal sgaOffshore;
    @Column(precision=18,scale=2)
    private BigDecimal sgaOnshore;
    @Column(precision=18,scale=2)
    private BigDecimal totalSGA;
    @Column(precision=18,scale=2)
    private BigDecimal operatingIncome;
    @Column(precision=18,scale=2)
    private BigDecimal finalTotalCost;
    @Column(precision=18,scale=2)
    private BigDecimal contributionMargin;
    @Column(precision=18,scale=2)
    private BigDecimal payrollCost;
    @Column(precision=18,scale=2)
    private BigDecimal revenuByGuidance;
    @Column(precision=18,scale=2)
    private BigDecimal onshoreCst;
    @Column(precision=18,scale=2)
    private BigDecimal offshoreCst;
    /* Audit Trail columns */
    // --------------------------------------------------------------------------------
    private Date createdDate;
    private Integer createdBy;
    private Date modifiedDate;
    private Integer modifiedBy;
    // Transient Variables
    // --------------------------------------------------------------------------------
	/**
	 * @return the pricingId
	 */
	public Integer getPricingId() {
		return pricingId;
	}
	/**
	 * @param pricingId the pricingId to set
	 */
	public void setPricingId(Integer pricingId) {
		this.pricingId = pricingId;
	}
	/**
	 * @return the cmsId
	 */
	public Integer getCmsId() {
		return cmsId;
	}
	/**
	 * @param cmsId the cmsId to set
	 */
	public void setCmsId(Integer cmsId) {
		this.cmsId = cmsId;
	}
	
	/**
	 * @return the bufferCost
	 */
	public BigDecimal getBufferCost() {
		return bufferCost;
	}
	/**
	 * @param bufferCost the bufferCost to set
	 */
	public void setBufferCost(BigDecimal bufferCost) {
		this.bufferCost = bufferCost;
	}
	/**
	 * @return the payrollOffshore
	 */
	public BigDecimal getPayrollOffshore() {
		return payrollOffshore;
	}
	/**
	 * @param payrollOffshore the payrollOffshore to set
	 */
	public void setPayrollOffshore(BigDecimal payrollOffshore) {
		this.payrollOffshore = payrollOffshore;
	}
	/**
	 * @return the payrollOnshore
	 */
	public BigDecimal getPayrollOnshore() {
		return payrollOnshore;
	}
	/**
	 * @param payrollOnshore the payrollOnshore to set
	 */
	public void setPayrollOnshore(BigDecimal payrollOnshore) {
		this.payrollOnshore = payrollOnshore;
	}
	/**
	 * @return the revenueOffshore
	 */
	public BigDecimal getRevenueOffshore() {
		return revenueOffshore;
	}
	/**
	 * @param revenueOffshore the revenueOffshore to set
	 */
	public void setRevenueOffshore(BigDecimal revenueOffshore) {
		this.revenueOffshore = revenueOffshore;
	}
	/**
	 * @return the revenueOnshore
	 */
	public BigDecimal getRevenueOnshore() {
		return revenueOnshore;
	}
	/**
	 * @param revenueOnshore the revenueOnshore to set
	 */
	public void setRevenueOnshore(BigDecimal revenueOnshore) {
		this.revenueOnshore = revenueOnshore;
	}
	/**
	 * @return the totalPayroll
	 */
	public BigDecimal getTotalPayroll() {
		return totalPayroll;
	}
	/**
	 * @param totalPayroll the totalPayroll to set
	 */
	public void setTotalPayroll(BigDecimal totalPayroll) {
		this.totalPayroll = totalPayroll;
	}
	/**
	 * @return the totalRevenue
	 */
	public BigDecimal getTotalRevenue() {
		return totalRevenue;
	}
	/**
	 * @param totalRevenue the totalRevenue to set
	 */
	public void setTotalRevenue(BigDecimal totalRevenue) {
		this.totalRevenue = totalRevenue;
	}
	/**
	 * @return the managerCostApportionment
	 */
	public BigDecimal getManagerCostApportionment() {
		return managerCostApportionment;
	}
	/**
	 * @param managerCostApportionment the managerCostApportionment to set
	 */
	public void setManagerCostApportionment(BigDecimal managerCostApportionment) {
		this.managerCostApportionment = managerCostApportionment;
	}
	/**
	 * @return the attritionCost
	 */
	public BigDecimal getAttritionCost() {
		return attritionCost;
	}
	/**
	 * @param attritionCost the attritionCost to set
	 */
	public void setAttritionCost(BigDecimal attritionCost) {
		this.attritionCost = attritionCost;
	}
	/**
	 * @return the attritionPercent
	 */
	public BigDecimal getAttritionPercent() {
		return attritionPercent;
	}
	/**
	 * @param attritionPercent the attritionPercent to set
	 */
	public void setAttritionPercent(BigDecimal attritionPercent) {
		this.attritionPercent = attritionPercent;
	}
	/**
	 * @return the travelBusiness
	 */
	public BigDecimal getTravelBusiness() {
		return travelBusiness;
	}
	/**
	 * @param travelBusiness the travelBusiness to set
	 */
	public void setTravelBusiness(BigDecimal travelBusiness) {
		this.travelBusiness = travelBusiness;
	}
	/**
	 * @return the cabForShift
	 */
	public BigDecimal getCabForShift() {
		return cabForShift;
	}
	/**
	 * @param cabForShift the cabForShift to set
	 */
	public void setCabForShift(BigDecimal cabForShift) {
		this.cabForShift = cabForShift;
	}
	/**
	 * @return the travelDeputation
	 */
	public BigDecimal getTravelDeputation() {
		return travelDeputation;
	}
	/**
	 * @param travelDeputation the travelDeputation to set
	 */
	public void setTravelDeputation(BigDecimal travelDeputation) {
		this.travelDeputation = travelDeputation;
	}
	/**
	 * @return the otherCost
	 */
	public BigDecimal getOtherCost() {
		return otherCost;
	}
	/**
	 * @param otherCost the otherCost to set
	 */
	public void setOtherCost(BigDecimal otherCost) {
		this.otherCost = otherCost;
	}
	/**
	 * @return the teamEngagement
	 */
	public BigDecimal getTeamEngagement() {
		return teamEngagement;
	}
	/**
	 * @param teamEngagement the teamEngagement to set
	 */
	public void setTeamEngagement(BigDecimal teamEngagement) {
		this.teamEngagement = teamEngagement;
	}
	/**
	 * @return the customerEngagement
	 */
	public BigDecimal getCustomerEngagement() {
		return customerEngagement;
	}
	/**
	 * @param customerEngagement the customerEngagement to set
	 */
	public void setCustomerEngagement(BigDecimal customerEngagement) {
		this.customerEngagement = customerEngagement;
	}
	/**
	 * @return the totalNonPayrollCost
	 */
	public BigDecimal getTotalNonPayrollCost() {
		return totalNonPayrollCost;
	}
	/**
	 * @param totalCost the totalCost to set
	 */
	public void setTotalNonPayrollCost(BigDecimal totalNonPayrollCost) {
		this.totalNonPayrollCost = totalNonPayrollCost;
	}
	
	/**
	 * @return the payrollCost
	 */
	public BigDecimal getPayrollCost() {
		return payrollCost;
	}
	/**
	 * @param payrollCost the payrollCost to set
	 */
	public void setPayrollCost(BigDecimal payrollCost) {
		this.payrollCost = payrollCost;
	}
	/**
	 * @return the contingency
	 */
	public BigDecimal getContingency() {
		return contingency;
	}
	/**
	 * @param contingency the contingency to set
	 */
	public void setContingency(BigDecimal contingency) {
		this.contingency = contingency;
	}
	/**
	 * @return the contingencyPercent
	 */
	public BigDecimal getContingencyPercent() {
		return contingencyPercent;
	}
	/**
	 * @param contingencyPercent the contingencyPercent to set
	 */
	public void setContingencyPercent(BigDecimal contingencyPercent) {
		this.contingencyPercent = contingencyPercent;
	}
	
	/**
	 * @return the exchangeAdder
	 */
	public BigDecimal getExchangeAdder() {
		return exchangeAdder;
	}
	/**
	 * @param exchangeAdder the exchangeAdder to set
	 */
	public void setExchangeAdder(BigDecimal exchangeAdder) {
		this.exchangeAdder = exchangeAdder;
	}
	/**
	 * @return the exchangeAdderOnshore
	 */
	public BigDecimal getExchangeAdderOnshore() {
		return exchangeAdderOnshore;
	}
	/**
	 * @param exchangeAdderOnshore the exchangeAdderOnshore to set
	 */
	public void setExchangeAdderOnshore(BigDecimal exchangeAdderOnshore) {
		this.exchangeAdderOnshore = exchangeAdderOnshore;
	}
	/**
	 * @return the exchangeAdderOffshore
	 */
	public BigDecimal getExchangeAdderOffshore() {
		return exchangeAdderOffshore;
	}
	/**
	 * @param exchangeAdderOffshore the exchangeAdderOffshore to set
	 */
	public void setExchangeAdderOffshore(BigDecimal exchangeAdderOffshore) {
		this.exchangeAdderOffshore = exchangeAdderOffshore;
	}
	/**
	 * @return the exchangeAdderOnshorePercent
	 */
	public BigDecimal getExchangeAdderOnshorePercent() {
		return exchangeAdderOnshorePercent;
	}
	/**
	 * @param exchangeAdderOnshorePercent the exchangeAdderOnshorePercent to set
	 */
	public void setExchangeAdderOnshorePercent(BigDecimal exchangeAdderOnshorePercent) {
		this.exchangeAdderOnshorePercent = exchangeAdderOnshorePercent;
	}
	/**
	 * @return the exchangeAdderOffshorePercent
	 */
	public BigDecimal getExchangeAdderOffshorePercent() {
		return exchangeAdderOffshorePercent;
	}
	/**
	 * @param exchangeAdderOffshorePercent the exchangeAdderOffshorePercent to set
	 */
	public void setExchangeAdderOffshorePercent(BigDecimal exchangeAdderOffshorePercent) {
		this.exchangeAdderOffshorePercent = exchangeAdderOffshorePercent;
	}
	/**
	 * @return the paymentAdder
	 */
	public BigDecimal getPaymentAdder() {
		return paymentAdder;
	}
	/**
	 * @param paymentAdder the paymentAdder to set
	 */
	public void setPaymentAdder(BigDecimal paymentAdder) {
		this.paymentAdder = paymentAdder;
	}
	/**
	 * @return the paymentAdderPercent
	 */
	public BigDecimal getPaymentAdderPercent() {
		return paymentAdderPercent;
	}
	/**
	 * @param paymentAdderPercent the paymentAdderPercent to set
	 */
	public void setPaymentAdderPercent(BigDecimal paymentAdderPercent) {
		this.paymentAdderPercent = paymentAdderPercent;
	}
	/**
	 * @return the sgaOffshore
	 */
	public BigDecimal getSgaOffshore() {
		return sgaOffshore;
	}
	/**
	 * @param sgaOffshore the sgaOffshore to set
	 */
	public void setSgaOffshore(BigDecimal sgaOffshore) {
		this.sgaOffshore = sgaOffshore;
	}
	/**
	 * @return the sgaOnshore
	 */
	public BigDecimal getSgaOnshore() {
		return sgaOnshore;
	}
	/**
	 * @param sgaOnshore the sgaOnshore to set
	 */
	public void setSgaOnshore(BigDecimal sgaOnshore) {
		this.sgaOnshore = sgaOnshore;
	}
	/**
	 * @return the totalSGA
	 */
	public BigDecimal getTotalSGA() {
		return totalSGA;
	}
	/**
	 * @param totalSGA the totalSGA to set
	 */
	public void setTotalSGA(BigDecimal totalSGA) {
		this.totalSGA = totalSGA;
	}
	/**
	 * @return the operatingIncome
	 */
	public BigDecimal getOperatingIncome() {
		return operatingIncome;
	}
	/**
	 * @param operatingIncome the operatingIncome to set
	 */
	public void setOperatingIncome(BigDecimal operatingIncome) {
		this.operatingIncome = operatingIncome;
	}
	/**
	 * @return the finalTotalCost
	 */
	public BigDecimal getFinalTotalCost() {
		return finalTotalCost;
	}
	/**
	 * @param finalTotalCost the finalTotalCost to set
	 */
	public void setFinalTotalCost(BigDecimal finalTotalCost) {
		this.finalTotalCost = finalTotalCost;
	}
	/**
	 * @return the contributionMargin
	 */
	public BigDecimal getContributionMargin() {
		return contributionMargin;
	}
	/**
	 * @param contributionMargin the contributionMargin to set
	 */
	public void setContributionMargin(BigDecimal contributionMargin) {
		this.contributionMargin = contributionMargin;
	}
	
	/**
	 * @return the revenuByGuidance
	 */
	public BigDecimal getRevenuByGuidance() {
		return revenuByGuidance;
	}
	/**
	 * @param revenuByGuidance the revenuByGuidance to set
	 */
	public void setRevenuByGuidance(BigDecimal revenuByGuidance) {
		this.revenuByGuidance = revenuByGuidance;
	}
	/**
	 * @return the createdDate
	 */
	public Date getCreatedDate() {
		return createdDate;
	}
	/**
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	/**
	 * @return the createdBy
	 */
	public Integer getCreatedBy() {
		return createdBy;
	}
	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}
	/**
	 * @return the modifiedDate
	 */
	public Date getModifiedDate() {
		return modifiedDate;
	}
	/**
	 * @param modifiedDate the modifiedDate to set
	 */
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	/**
	 * @return the modifiedBy
	 */
	public Integer getModifiedBy() {
		return modifiedBy;
	}
	/**
	 * @param modifiedBy the modifiedBy to set
	 */
	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	
	/**
	 * @return the onshoreCst
	 */
	public BigDecimal getOnshoreCst() {
		return onshoreCst;
	}
	/**
	 * @param onshoreCst the onshoreCst to set
	 */
	public void setOnshoreCst(BigDecimal onshoreCst) {
		this.onshoreCst = onshoreCst;
	}
	/**
	 * @return the offshoreCst
	 */
	public BigDecimal getOffshoreCst() {
		return offshoreCst;
	}
	/**
	 * @param offshoreCst the offshoreCst to set
	 */
	public void setOffshoreCst(BigDecimal offshoreCst) {
		this.offshoreCst = offshoreCst;
	}
	public Pricing() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Pricing(Integer pricingId, Integer cmsId, BigDecimal bufferCost, BigDecimal payrollOffshore,
			BigDecimal payrollOnshore, BigDecimal revenueOffshore, BigDecimal revenueOnshore, BigDecimal totalPayroll,
			BigDecimal totalRevenue, BigDecimal managerCostApportionment, BigDecimal attritionCost,
			BigDecimal attritionPercent, BigDecimal travelBusiness, BigDecimal cabForShift, BigDecimal travelDeputation,
			BigDecimal otherCost, BigDecimal teamEngagement, BigDecimal customerEngagement,
			BigDecimal totalNonPayrollCost, BigDecimal contingency, BigDecimal contingencyPercent,
			BigDecimal exchangeAdder, BigDecimal exchangeAdderOnshore, BigDecimal exchangeAdderOffshore,
			BigDecimal exchangeAdderOnshorePercent, BigDecimal exchangeAdderOffshorePercent, BigDecimal paymentAdder,
			BigDecimal paymentAdderPercent, BigDecimal sgaOffshore, BigDecimal sgaOnshore, BigDecimal totalSGA,
			BigDecimal operatingIncome, BigDecimal finalTotalCost, BigDecimal contributionMargin,
			BigDecimal payrollCost,BigDecimal revenuByGuidance,BigDecimal onshoreCst, BigDecimal offshoreCst,  Date createdDate, Integer createdBy, Date modifiedDate
			, Integer modifiedBy) {
		super();
		this.pricingId = pricingId;
		this.cmsId = cmsId;
		this.bufferCost = bufferCost;
		this.payrollOffshore = payrollOffshore;
		this.payrollOnshore = payrollOnshore;
		this.revenueOffshore = revenueOffshore;
		this.revenueOnshore = revenueOnshore;
		this.totalPayroll = totalPayroll;
		this.totalRevenue = totalRevenue;
		this.managerCostApportionment = managerCostApportionment;
		this.attritionCost = attritionCost;
		this.attritionPercent = attritionPercent;
		this.travelBusiness = travelBusiness;
		this.cabForShift = cabForShift;
		this.travelDeputation = travelDeputation;
		this.otherCost = otherCost;
		this.teamEngagement = teamEngagement;
		this.customerEngagement = customerEngagement;
		this.totalNonPayrollCost = totalNonPayrollCost;
		this.contingency = contingency;
		this.contingencyPercent = contingencyPercent;
		this.exchangeAdder = exchangeAdder;
		this.exchangeAdderOnshore = exchangeAdderOnshore;
		this.exchangeAdderOffshore = exchangeAdderOffshore;
		this.exchangeAdderOnshorePercent = exchangeAdderOnshorePercent;
		this.exchangeAdderOffshorePercent = exchangeAdderOffshorePercent;
		this.paymentAdder = paymentAdder;
		this.paymentAdderPercent = paymentAdderPercent;
		this.sgaOffshore = sgaOffshore;
		this.sgaOnshore = sgaOnshore;
		this.totalSGA = totalSGA;
		this.operatingIncome = operatingIncome;
		this.finalTotalCost = finalTotalCost;
		this.contributionMargin = contributionMargin;
		this.payrollCost = payrollCost;
		this.revenuByGuidance = revenuByGuidance;
		this.onshoreCst = onshoreCst;
		this.offshoreCst = offshoreCst;
		this.createdDate = createdDate;
		this.createdBy = createdBy;
		this.modifiedDate = modifiedDate;
		this.modifiedBy = modifiedBy;
	}
	
	
   
}
