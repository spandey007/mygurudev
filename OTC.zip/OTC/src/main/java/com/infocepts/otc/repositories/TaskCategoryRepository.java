package com.infocepts.otc.repositories;

import com.infocepts.otc.entities.TaskCategory;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface TaskCategoryRepository extends CrudRepository<TaskCategory, Integer> {

    @Override
    List<TaskCategory> findAll();
}
