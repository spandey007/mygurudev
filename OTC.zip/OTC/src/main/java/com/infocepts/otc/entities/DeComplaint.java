/**
* Filename: /src/main/java/com/infocepts/otc/entities/DecomplaintId.java
* @author  SHRI
* @version 1.0
* @since   2018-11-28 
*/
package com.infocepts.otc.entities;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.persistence.*;
import javax.validation.constraints.NotNull;

import com.infocepts.otc.utilities.LoadConstant;
@Entity
@Table(catalog=LoadConstant.otc, schema="[dbo]", name="deComplaint")

@SqlResultSetMappings({
        @SqlResultSetMapping(
                name = "list_all_deComplaint",
                classes = {
                        @ConstructorResult(
                                targetClass = DeComplaint.class,
                                columns = {
                                		@ColumnResult(name = "complaintId"),
                                        @ColumnResult(name = "projectId"), 
										@ColumnResult(name = "complaintTo", type = String.class),
										@ColumnResult(name = "month", type = Date.class),
										@ColumnResult(name = "filepath", type = String.class),
										@ColumnResult(name = "createdBy"),	
										@ColumnResult(name = "createdDate", type = Date.class),
										@ColumnResult(name = "modifiedBy"),
										@ColumnResult(name = "modifiedDate", type = Date.class),	
										@ColumnResult(name = "status", type = String.class),	
										@ColumnResult(name = "comments", type = String.class),	
										@ColumnResult(name = "actionFilepath", type = String.class),	
										@ColumnResult(name = "actionDescription", type = String.class),
										@ColumnResult(name = "projectName", type = String.class),
										@ColumnResult(name = "itemId"),
										@ColumnResult(name = "ahId"),
										@ColumnResult(name = "projectManagersId"),
                                        @ColumnResult(name = "accountName", type = String.class),
										@ColumnResult(name = "portfolioId"),
                                        @ColumnResult(name = "portfolioName", type = String.class),
                                        @ColumnResult(name = "createdByName", type = String.class)

                                }
                        )
                }
        )
})
@NamedNativeQueries({
        @NamedNativeQuery(
                name    =   "getAllDeComplaintData",   
                query 	=   "Select da.*, p.title as projectName,p.itemId, a.ahId, p.projectManagersId, p.portfolioId, a.accountShortName as accountName, po.title as portfolioName, r.title as createdByName"+
							" from " + LoadConstant.otc + ".[dbo].[deComplaint] as da"+
							" Left JOIN " + LoadConstant.infomaster + ".[dbo].[project] p on p.itemId = da.projectId"+
							" Left JOIN " + LoadConstant.infomaster + ".[dbo].[accounts] as a on p.accountId = a.itemId"+
							" Left JOIN " + LoadConstant.infomaster + ".[dbo].[portfolio] as po on a.portfolioId = po.itemId"+
							" Left JOIN " + LoadConstant.infomaster + ".[dbo].[resource] as r on da.createdBy = r.uid"+
							" WHERE p.state = 'Active' AND p.parentProjectId is NULL AND "+
		            		"(('pm' = :view and p.projectManagersId = :uid ) "+
		            		"or "+
		            		"('ph' = :view and po.ownerId = :uid ) "+
		            		"or "+
		            		"('pmo' = :view ) "+
		            		"or "+
		            		"('cep' = :view and a.rmId = :uid ) "+
		            		"or "+
		            		"('dh' = :view ) "+
		            		"or "+
		            		"('de' = :view )) order by da.complaintId asc",
							
							resultClass=DeComplaint.class, resultSetMapping = "list_all_deComplaint"
        )        
})
		//  AND p.deProjectType is not NULL- to cover only de projects

public class DeComplaint {

	// Entity Columns
    // --------------------------------------------------------------------------------
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Integer complaintId; 
	private Integer projectId;    
	private String complaintTo;
	private Date month;
	private String filepath;
	private Integer createdBy;    
    private Date createdDate;
    private Integer modifiedBy;
    private Date modifiedDate;
	private String status;

	@Lob
	private String comments;

	private String actionFilepath;

	@Lob
	private String actionDescription;

	@Transient
	private String projectName;
	
	@Transient
	private Integer itemId;

	@Transient
	private Integer ahId;
	
	@Transient
	private Integer projectManagersId;
	
	@Transient
	private String accountName;

	@Transient
	private Integer portfolioId;
	
	@Transient
	private String portfolioName;
	
	@Transient
	private String createdByName;


	public Integer getComplaintId() {
		return complaintId;
	}

	public void setComplaintId(Integer complaintId) {
		this.complaintId = complaintId;
	}

	public String getComplaintTo() {
		return complaintTo;
	}

	public void setComplaintTo(String complaintTo) {
		this.complaintTo = complaintTo;
	}

	public Integer getProjectId() {
		return projectId;
	}

	public void setProjectId(Integer projectId) {
		this.projectId = projectId;
	}

	public Date getMonth() {
		return month;
	}

	public void setMonth(Date month) {
		this.month = month;
	}

	public String getFilepath() {
		return filepath;
	}

	public void setFilepath(String filepath) {
		this.filepath = filepath;
	}

	public Integer getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Integer getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public Integer getItemId() {
		return itemId;
	}

	public void setItemId(Integer itemId) {
		this.itemId = itemId;
	}

	public Integer getAhId() {
		return ahId;
	}

	public void setAhId(Integer ahId) {
		this.ahId = ahId;
	}

	public Integer getProjectManagersId() {
		return projectManagersId;
	}

	public void setProjectManagersId(Integer projectManagersId) {
		this.projectManagersId = projectManagersId;
	}

	public Integer getPortfolioId() {
		return portfolioId;
	}

	public void setPortfolioId(Integer portfolioId) {
		this.portfolioId = portfolioId;
	}

	public String getPortfolioName() {
		return portfolioName;
	}

	public void setPortfolioName(String portfolioName) {
		this.portfolioName = portfolioName;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	
	public String getActionFilepath() {
		return actionFilepath;
	}

	public void setActionFilepath(String actionFilepath) {
		this.actionFilepath = actionFilepath;
	}

	public String getActionDescription() {
		return actionDescription;
	}

	public void setActionDescription(String actionDescription) {
		this.actionDescription = actionDescription;
	}
	
	public String getCreatedByName() {
		return createdByName;
	}

	public void setCreatedByName(String createdByName) {
		this.createdByName = createdByName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
	//Introducing the dummy constructor
    public DeComplaint() {
    }

	public DeComplaint(Integer complaintId, Integer projectId, String complaintTo, Date month, String filepath,
			Integer createdBy, Date createdDate, Integer modifiedBy, Date modifiedDate, String status, String comments,
			String actionFilepath, String actionDescription, String projectName, Integer itemId, Integer ahId,
			Integer projectManagersId, String accountName, Integer portfolioId, String portfolioName,
			String createdByName) {
		super();
		this.complaintId = complaintId;
		this.projectId = projectId;
		this.complaintTo = complaintTo;
		this.month = month;
		this.filepath = filepath;
		this.createdBy = createdBy;
		this.createdDate = createdDate;
		this.modifiedBy = modifiedBy;
		this.modifiedDate = modifiedDate;
		this.status = status;
		this.comments = comments;
		this.actionFilepath = actionFilepath;
		this.actionDescription = actionDescription;
		this.projectName = projectName;
		this.itemId = itemId;
		this.ahId = ahId;
		this.projectManagersId = projectManagersId;
		this.accountName = accountName;
		this.portfolioId = portfolioId;
		this.portfolioName = portfolioName;
		this.createdByName = createdByName;
	}

	



}
