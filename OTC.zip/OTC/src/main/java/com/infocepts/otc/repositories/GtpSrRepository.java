/**
* Filename: /src/main/java/com/infocepts/otc/repositories/<ModuleName>Repository.java
* @author  AA
* @version 1.0
* @since   2019-08-30
*/
package com.infocepts.otc.repositories;

import java.util.List;
import org.springframework.data.repository.CrudRepository;
import com.infocepts.otc.entities.GtpSr;

public interface GtpSrRepository extends CrudRepository<GtpSr,Integer>{

	@Override
	public List<GtpSr> findAll();	
		
	
	
}


