/**
 * 
 */
package com.infocepts.otc.entities;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.infocepts.otc.utilities.LoadConstant;

/**
 * @author Rewatiraman Singh
 *
 */
@Entity
@Table(catalog=LoadConstant.infomaster, schema="[dbo]",name="expensePurpose")
public class ExpensePurpose implements Serializable {

	/**
	 */
	private static final long serialVersionUID = 3673002755855061963L;
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer purposeId;	
	
	private String purposeName;	
	private Byte status;	
	private Integer entityId;	
	private String description;	
	private Integer maxLimit;
	
	
	public ExpensePurpose() {
	}

	public Integer getPurposeId() {
		return purposeId;
	}

	public void setPurposeId(Integer purposeId) {
		this.purposeId = purposeId;
	}

	public String getPurposeName() {
		return purposeName;
	}

	public void setPurposeName(String purposeName) {
		this.purposeName = purposeName;
	}

	public Byte getStatus() {
		return status;
	}

	public void setStatus(Byte status) {
		this.status = status;
	}

	public Integer getEntityId() {
		return entityId;
	}

	public void setEntityId(Integer entityId) {
		this.entityId = entityId;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Integer getMaxLimit() {
		return maxLimit;
	}

	public void setMaxLimit(Integer maxLimit) {
		this.maxLimit = maxLimit;
	}
}
