/**
* Filename: /src/main/java/com/infocepts/otc/entities/DeAppreciation.java
* @author  SHRI
* @version 1.0
* @since   2018-11-28 
*/
package com.infocepts.otc.entities;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.persistence.*;
import javax.validation.constraints.NotNull;

import com.infocepts.otc.utilities.LoadConstant;
@Entity
@Table(catalog=LoadConstant.otc, schema="[dbo]", name="deAppreciation")

@SqlResultSetMappings({
        @SqlResultSetMapping(
                name = "list_all_deAppreciation",
                classes = {
                        @ConstructorResult(
                                targetClass = DeAppreciation.class,
                                columns = {
                                		@ColumnResult(name = "appreciationId"),
                                        @ColumnResult(name = "projectId"), 
										@ColumnResult(name = "appreciationTo", type = String.class),
										@ColumnResult(name = "month", type = Date.class),
										@ColumnResult(name = "filepath", type = String.class),
										@ColumnResult(name = "status", type = String.class),
										@ColumnResult(name = "createdBy"),	
										@ColumnResult(name = "createdDate", type = Date.class),
										@ColumnResult(name = "modifiedBy"),
										@ColumnResult(name = "modifiedDate", type = Date.class),	
										@ColumnResult(name = "comments", type = String.class),	
										@ColumnResult(name = "pmoComments", type = String.class),	
										@ColumnResult(name = "projectName", type = String.class),
										@ColumnResult(name = "itemId "),
										@ColumnResult(name = "ahId"),
										@ColumnResult(name = "projectManagersId"),
                                        @ColumnResult(name = "accountName", type = String.class),
										@ColumnResult(name = "portfolioId"),
                                        @ColumnResult(name = "portfolioName", type = String.class),
                                        @ColumnResult(name = "createdByName", type = String.class)
                                }
                        )
                }
        )
})
@NamedNativeQueries({
        @NamedNativeQuery(
                name    =   "getAllDeAppreciationData",
                query 	=   "Select da.*, p.title as projectName,p.itemId, a.ahId, p.projectManagersId, p.portfolioId, a.accountShortName as accountName, po.title as portfolioName, r.title as createdByName"+
							" from " + LoadConstant.otc + ".[dbo].[deAppreciation] as da"+
							" Left JOIN " + LoadConstant.infomaster + ".[dbo].[project] p on p.itemId = da.projectId"+
							" Left JOIN " + LoadConstant.infomaster + ".[dbo].[accounts] as a on p.accountId = a.itemId"+
							" Left JOIN " + LoadConstant.infomaster + ".[dbo].[portfolio] as po on a.portfolioId = po.itemId"+
							" Left JOIN " + LoadConstant.infomaster + ".[dbo].[resource] as r on da.createdBy = r.uid"+
							" WHERE p.state = 'Active' AND p.parentProjectId is NULL AND "+
		            		"(('pm' = :view and p.projectManagersId = :uid ) "+
		            		"or "+
		            		"('ph' = :view and po.ownerId = :uid ) "+
		            		"or "+
		            		"('pmo' = :view ) "+
		            		"or "+
		            		"('cep' = :view and a.rmId = :uid ) "+
		            		"or "+
		            		"('dh' = :view ) "+
		            		"or "+
		            		"('de' = :view )) order by da.appreciationId desc",
							
							resultClass=DeAppreciation.class, resultSetMapping = "list_all_deAppreciation"
        )        
})
		//  AND p.deProjectType is not NULL- to cover only de projects

public class DeAppreciation {

	// Entity Columns
    // --------------------------------------------------------------------------------
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Integer appreciationId; 
	private Integer projectId;    
	private String appreciationTo;    
	private Date month;
	private String filepath;
	private String status;

	private Integer createdBy;    
    private Date createdDate;
    private Integer modifiedBy;
    private Date modifiedDate;
    
	@Lob
	private String comments;
	
	@Lob
	private String pmoComments;

	@Transient
	private String projectName;
	
	@Transient
	private Integer itemId;

	@Transient
	private Integer ahId;
	
	@Transient
	private Integer projectManagersId;
	
	@Transient
	private String accountName;

	@Transient
	private Integer portfolioId;
	
	@Transient
	private String portfolioName;

	@Transient
	private String createdByName;
	
	public Integer getAppreciationId() {
		return appreciationId;
	}

	public void setAppreciationId(Integer appreciationId) {
		this.appreciationId = appreciationId;
	}

	public String getAppreciationTo() {
		return appreciationTo;
	}

	public void setAppreciationTo(String appreciationTo) {
		this.appreciationTo = appreciationTo;
	}

	public Integer getProjectId() {
		return projectId;
	}

	public void setProjectId(Integer projectId) {
		this.projectId = projectId;
	}

	public Date getMonth() {
		return month;
	}

	public void setMonth(Date month) {
		this.month = month;
	}

	public String getFilepath() {
		return filepath;
	}

	public void setFilepath(String filepath) {
		this.filepath = filepath;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Integer getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Integer getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public Integer getItemId() {
		return itemId;
	}

	public void setItemId(Integer itemId) {
		this.itemId = itemId;
	}

	public Integer getAhId() {
		return ahId;
	}

	public void setAhId(Integer ahId) {
		this.ahId = ahId;
	}

	public Integer getProjectManagersId() {
		return projectManagersId;
	}

	public void setProjectManagersId(Integer projectManagersId) {
		this.projectManagersId = projectManagersId;
	}

	public Integer getPortfolioId() {
		return portfolioId;
	}

	public void setPortfolioId(Integer portfolioId) {
		this.portfolioId = portfolioId;
	}

	public String getPortfolioName() {
		return portfolioName;
	}

	public void setPortfolioName(String portfolioName) {
		this.portfolioName = portfolioName;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public String getPmoComments() {
		return pmoComments;
	}

	public void setPmoComments(String pmoComments) {
		this.pmoComments = pmoComments;
	}

	public String getCreatedByName() {
		return createdByName;
	}

	public void setCreatedByName(String createdByName) {
		this.createdByName = createdByName;
	}

	//Introducing the dummy constructor
    public DeAppreciation() {
    }

	public DeAppreciation(Integer appreciationId, Integer projectId, String appreciationTo, Date month, String filepath,
			String status, Integer createdBy, Date createdDate, Integer modifiedBy, Date modifiedDate, String comments,
			String pmoComments, String projectName, Integer itemId, Integer ahId, Integer projectManagersId,
			String accountName, Integer portfolioId, String portfolioName,String createdByName) {
		super();
		this.appreciationId = appreciationId;
		this.projectId = projectId;
		this.appreciationTo = appreciationTo;
		this.month = month;
		this.filepath = filepath;
		this.status = status;
		this.createdBy = createdBy;
		this.createdDate = createdDate;
		this.modifiedBy = modifiedBy;
		this.modifiedDate = modifiedDate;
		this.comments = comments;
		this.pmoComments = pmoComments;
		this.projectName = projectName;
		this.itemId = itemId;
		this.ahId = ahId;
		this.projectManagersId = projectManagersId;
		this.accountName = accountName;
		this.portfolioId = portfolioId;
		this.portfolioName = portfolioName;
		this.createdByName = createdByName;

	}



	



}
