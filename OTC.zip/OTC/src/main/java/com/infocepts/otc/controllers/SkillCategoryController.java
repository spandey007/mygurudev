package com.infocepts.otc.controllers;

import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.infocepts.otc.entities.SkillCategory;
import com.infocepts.otc.repositories.SkillCategoryRepository;
import com.infocepts.otc.services.TimesheetService;

@RequestMapping(value="/skillcategory",headers="referer")
@RestController
public class SkillCategoryController {
	
	final Logger logger = Logger.getLogger(SkillCategoryController.class);
	
	@Autowired
	SkillCategoryRepository repository;
	
	@Autowired
	TimesheetService service;
	
	@RequestMapping(method=RequestMethod.POST)
	public void saveSkillCategory(@RequestBody SkillCategory skillcategory){
		try{
			if(service.isAMG()){
				skillcategory.setSkillCategoryId(null);
				repository.save(skillcategory);
			}
		}
		catch(Exception e){
			logger.error(e);
		}
	}
	
	@RequestMapping(method=RequestMethod.GET)
	public List<SkillCategory> getSkillCategory(){
		List<SkillCategory> skillcategorylist=null;
		try{
			skillcategorylist = repository.findAll();
		}
		catch(Exception e){
			logger.error(e);
		}
		return skillcategorylist;
	}
	
	@RequestMapping(value="/{skillCategoryId}",method=RequestMethod.PUT)
	public void updateSkillCategory(@PathVariable Integer skillCategoryId,@RequestBody SkillCategory updatedskillcategory){
		try{
			if(service.isAMG()){
				updatedskillcategory.setSkillCategoryId(skillCategoryId);
				repository.save(updatedskillcategory);
			}
		}
		catch(Exception e){
			logger.error(e);
		}
	}
	
	@RequestMapping(value="/{skillCategoryId}",method=RequestMethod.DELETE)
	public void deleteSkillCategory(@PathVariable Integer skillCategoryId){
		try{
			if(service.isAMG()){
				repository.delete(skillCategoryId);
			}
		}
		catch(Exception e){
			logger.error(e);
		}
	}
}
