package com.infocepts.otc.entities;

import com.infocepts.otc.utilities.LoadConstant;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(catalog = LoadConstant.otc, schema = "[dbo]", name = "taskCenter")

@SqlResultSetMappings({
	@SqlResultSetMapping(

	      name = "alc_or_non_alc_tasks",
	      classes = {
	          @ConstructorResult(
	              targetClass = ProjectTask.class,
	              columns = {
	                  @ColumnResult(name = "taskId", type=Integer.class),
	                  @ColumnResult(name = "title", type=String.class),
	                  @ColumnResult(name = "startDate", type=Date.class),
	                  @ColumnResult(name = "dueDate", type=Date.class),
	                  @ColumnResult(name = "taskCompleted", type= Boolean.class),
	                  @ColumnResult(name = "assignedToId", type=String.class),
	                  @ColumnResult(name = "timesheet", type=Boolean.class),
	                  @ColumnResult(name = "projectName", type=String.class),
	                  @ColumnResult(name = "projectId", type=Integer.class),
	                  @ColumnResult(name = "assignedAssociate", type=String.class),
					  @ColumnResult(name = "isGeneric", type=Boolean.class)
	                  
	              }
	          )
	      }
	),
@SqlResultSetMapping(
	      name = "getTaskByProject",
	      classes = {
	          @ConstructorResult(
	              targetClass = ProjectTask.class,
	              columns = {
	                  @ColumnResult(name = "taskId", type=Integer.class),
	                  @ColumnResult(name = "title", type=String.class),
	                  @ColumnResult(name = "isGeneric", type=Boolean.class)
	                  
	   
	                  
	              }
	          )
	      }
	)
})
	@NamedNativeQueries({    
	    @NamedNativeQuery(
	            name    =   "getNonAllocatedTasksForUser",
	            query   =   "select t.taskId, t.[title] as title, t.startDate as startDate, t.dueDate as dueDate, t.taskCompleted as taskCompleted, t.[assignedToID] as assignedToId,t.[Timesheet] as timesheet, p.title as projectName, t.[ProjectID] as projectId,t.assignedAssociate as assignedAssociate, t.isGeneric as isGeneric" +
		            		" from " + LoadConstant.otc + ".[dbo].[taskCenter] t" +
		            		" left join " + LoadConstant.infomaster + ".[dbo].[project] p on p.itemId = t.projectId" +
		            		" LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[billingType] b on b.billingTypeId = p.billingTypeId " +
		            		" where t.title is not null" +
		            		" and p.state = 'Active'" + // only for active projects
		            		" and ((t.assignedToID is null) or (t.assignedToID = ''))" + // Generic tasks are never assigned to anyone
		            		" and t.taskCompleted != 1" + // tasks that are not completed
		            		" and t.timesheet=1" +
		            		" and b.name = 'None'" + // Where billing type is 'None'
//		            		" and t.taskId not in" +
//		            		" (select tsi.taskId from  " + LoadConstant.otc + ".[dbo].[tsitem] tsi" +
//		        			" left join  " + LoadConstant.otc + ".[dbo].[tstimesheet] ts on ts.timesheetId = tsi.timesheetId)" +
//		        			" where ts.uid = :uid and ts.periodId = :periodId)" +
		        			" order by p.title;",						             
	                        resultClass=ProjectTask.class,  resultSetMapping = "alc_or_non_alc_tasks"  
	                        
	    ),
	    @NamedNativeQuery(
	    		  name    =   "getProjectTasksForUserNotInCurrentTs",
		            query   = "select t.taskId,t.[Title] as title, t.StartDate as startDate, t.DueDate as dueDate, t.taskCompleted as taskCompleted, t.[AssignedToID] as assignedToId,t.[Timesheet] as timesheet, p.title as projectName, t.[ProjectID] as projectId,t.assignedAssociate as assignedAssociate,t.isGeneric as isGeneric" +
		            			" from " + LoadConstant.otc + ".[dbo].[taskCenter] t" +
		            			" left join " + LoadConstant.infomaster + ".[dbo].[project] p on p.itemId = t.projectId" +
		            			" where ((t.AssignedToID like :assignedToUid) or (t.AssignedToID like concat('%,',:assignedToUid,',%')) or (t.AssignedToID like concat(:assignedToUid,',%'))or (t.AssignedToID like concat('%,',:assignedToUid)))" +
		            			" and t.Timesheet=1" +
		            			" and t.taskCompleted != 1" +	// task status is not set as completed
			        			" and t.taskId not in" +
			        			" (select tsi.taskId from  " + LoadConstant.otc + ".[dbo].[tsitem] tsi" +
			        			" left join  " + LoadConstant.otc + ".[dbo].[tstimesheet] ts on ts.timesheetId = tsi.timesheetId" +
			        			" where ts.uid = :uid and ts.periodId = :periodId)" +
			        			" and p.state = 'Active'" +
			        			//" AND ((t.StartDate <= :periodStartDate AND t.DueDate >= :periodStartDate) OR (t.StartDate >= :periodStartDate AND t.StartDate <= :periodEndDate))" + // Only tasks assigned within the period start and end date date are copied
			        			" order by p.title;",			
			        			resultClass=ProjectTask.class,  resultSetMapping = "alc_or_non_alc_tasks"                      
	                        
	    ),
	    @NamedNativeQuery(
	    		  name    =   "getActiveProjectTasksForUser",
		            query   = "select t.taskId,t.[Title] as title, t.StartDate as startDate, t.DueDate as dueDate, t.taskCompleted as taskCompleted, t.[AssignedToID] as assignedToId,t.[Timesheet] as timesheet, p.title as projectName, t.[ProjectID] as projectId,t.assignedAssociate as assignedAssociate,t.isGeneric as isGeneric" +
		            			" from " + LoadConstant.otc + ".[dbo].[taskCenter] t" +
		            			" left join " + LoadConstant.infomaster + ".[dbo].[project] p on p.itemId = t.projectId" +
		            			" where ((t.AssignedToID like :assignedToUid) or (t.AssignedToID like concat('%,',:assignedToUid,',%')) or (t.AssignedToID like concat(:assignedToUid,',%'))or (t.AssignedToID like concat('%,',:assignedToUid)))" +
			        			" and t.Timesheet=1" +
			        			" and p.state = 'Active'" + 	// project is active
			        			" and t.taskCompleted != 1" +	// task status is not set as completed
			        			" order by p.title;",			
			        			resultClass=ProjectTask.class,  resultSetMapping = "alc_or_non_alc_tasks"                      
	                        
	    ),
	    @NamedNativeQuery(
	    		  name    =   "getInActiveProjectTasksForUser",
		            query   = "select t.taskId,t.[Title] as title, t.StartDate as startDate, t.DueDate as dueDate, t.taskCompleted as taskCompleted, t.[AssignedToID] as assignedToId,t.[Timesheet] as timesheet, p.title as projectName, t.[ProjectID] as projectId,t.assignedAssociate as assignedAssociate,t.isGeneric as isGeneric" +
		            			" from " + LoadConstant.otc + ".[dbo].[taskCenter] t" +
		            			" left join " + LoadConstant.infomaster + ".[dbo].[project] p on p.itemId = t.projectId" +
		            			" where ((t.AssignedToID like :assignedToUid) or (t.AssignedToID like concat('%,',:assignedToUid,',%')) or (t.AssignedToID like concat(:assignedToUid,',%'))or (t.AssignedToID like concat('%,',:assignedToUid)))" +
			        			" and t.Timesheet=1" +
			        			" and p.state = 'Active'" +		// project is active
			        			" and t.taskCompleted != 1" +	// task status is not set as completed
			        			" order by p.title;",			
			        			resultClass=ProjectTask.class,  resultSetMapping = "alc_or_non_alc_tasks"                      
	                        
	    ),
	    @NamedNativeQuery(
	    		  name    =   "getAllProjectTasksByProjectDropdown",
		            query   = "select t.taskId,t.[Title] as title,t.isGeneric as isGeneric"
		            			+ " from " + LoadConstant.otc + ".[dbo].[taskCenter] t"
		            		    + " left join " + LoadConstant.infomaster + ".[dbo].[project] p on p.itemId = t.projectId"
		            			+ " where (p.itemId = :projId) and (t.isGeneric = 1) order by t.title ",
		                        resultClass=ProjectTask.class,  resultSetMapping = "getTaskByProject"                      
	                        
	    ),
	    
	    @NamedNativeQuery(
	    		  name    =   "getAllProjectTasks",
		            query   = "select t.taskId,t.[Title] as title, t.StartDate as startDate, t.DueDate as dueDate, t.taskCompleted as taskCompleted, t.[AssignedToID] as assignedToId,t.[Timesheet] as timesheet, p.title as projectName, t.[ProjectID] as projectId,t.assignedAssociate as assignedAssociate,t.isGeneric as isGeneric"
		            			+ " from " + LoadConstant.otc + ".[dbo].[taskCenter] t"
		            			+ " left join " + LoadConstant.infomaster + ".[dbo].[project] p on p.itemId = t.projectId"
		            			+ " where p.itemId = :pid",
		                        resultClass=ProjectTask.class,  resultSetMapping = "alc_or_non_alc_tasks"                      
	                        
	    )
	})
public class ProjectTask implements Cloneable {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)

	private Integer taskId;

    @Column(columnDefinition = "varchar(MAX)")
	private String title;

    private Integer projectId;

    private String infoCeptsTaskType; // to track the task type or category (Development, Design, Traninig, etc.)

    @Column(columnDefinition = "varchar(MAX)")
	private String assignedToId;

    @Column(columnDefinition = "varchar(MAX)")
    private String assignedToText;

    private Float duration;

    private Date startDate;

	private Date dueDate;

    private Float percentComplete;

    private String wbs;

    private Boolean summary;

    private Integer taskOrder;

    private Date lastPublished;

    private Float actualWork;

    private Date created;

    private Integer authorId;

    private Date modified;

    private Integer editorId;

	private Boolean timesheet; // Variable to track if the task is added in timesheet or not

    private Boolean milestone;

    private Boolean taskCompleted;

    private Boolean taskDisabled;
    
    private String assignedAssociate;
    private Boolean isGeneric;

	public Boolean getIsGeneric() {
		return isGeneric;
	}

	public void setIsGeneric(Boolean isGeneric) {
		this.isGeneric = isGeneric;
	}

	@Transient
	private String projectName;	
	
	@Transient
	private Integer overDueStatus;

    // Default project task constructor
    public ProjectTask() {
    }

    public Integer getTaskId() {
        return taskId;
    }

    public void setTaskId(Integer taskId) {
        this.taskId = taskId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Integer getProjectId() {
        return projectId;
    }

    public void setProjectId(Integer projectId) {
        this.projectId = projectId;
    }

    public String getInfoCeptsTaskType() {
        return infoCeptsTaskType;
    }

    public void setInfoCeptsTaskType(String infoCeptsTaskType) {
        this.infoCeptsTaskType = infoCeptsTaskType;
    }

    public String getAssignedToId() {
        return assignedToId;
    }

    public void setAssignedToId(String assignedToId) {
        this.assignedToId = assignedToId;
    }

    public String getAssignedToText() {
        return assignedToText;
    }

    public void setAssignedToText(String assignedToText) {
        this.assignedToText = assignedToText;
    }

    public Float getDuration() {
        return duration;
    }

    public void setDuration(Float duration) {
        this.duration = duration;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getDueDate() {
        return dueDate;
    }

    public void setDueDate(Date dueDate) {
        this.dueDate = dueDate;
    }

    public Float getPercentComplete() {
        return percentComplete;
    }

    public void setPercentComplete(Float percentComplete) {
        this.percentComplete = percentComplete;
    }

    public String getWbs() {
        return wbs;
    }

    public void setWbs(String wbs) {
        this.wbs = wbs;
    }

    public Boolean getSummary() {
        return summary;
    }

    public void setSummary(Boolean summary) {
        this.summary = summary;
    }

    public Integer getTaskOrder() {
        return taskOrder;
    }

    public void setTaskOrder(Integer taskOrder) {
        this.taskOrder = taskOrder;
    }

    public Date getLastPublished() {
        return lastPublished;
    }

    public void setLastPublished(Date lastPublished) {
        this.lastPublished = lastPublished;
    }

    public Float getActualWork() {
        return actualWork;
    }

    public void setActualWork(Float actualWork) {
        this.actualWork = actualWork;
    }

    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }

    public Integer getAuthorId() {
        return authorId;
    }

    public void setAuthorId(Integer authorId) {
        this.authorId = authorId;
    }

    public Date getModified() {
        return modified;
    }

    public void setModified(Date modified) {
        this.modified = modified;
    }

    public Integer getEditorId() {
        return editorId;
    }

    public void setEditorId(Integer editorId) {
        this.editorId = editorId;
    }

    public Boolean getTimesheet() {
        return timesheet;
    }

    public void setTimesheet(Boolean timesheet) {
        this.timesheet = timesheet;
    }

    public Boolean getMilestone() {
        return milestone;
    }

    public void setMilestone(Boolean milestone) {
        this.milestone = milestone;
    }

    public Boolean getTaskCompleted() {
        return taskCompleted;
    }

    public void setTaskCompleted(Boolean taskCompleted) {
        this.taskCompleted = taskCompleted;
    }

    public void setOverDueStatus(Integer overDueStatus) {
        this.overDueStatus = overDueStatus;
    }

    public Boolean getTaskDisabled() {
        return taskDisabled;
    }

    public void setTaskDisabled(Boolean taskDisabled) {
        this.taskDisabled = taskDisabled;
    }

    /* ------------------------------ Transient Variables -------------------------------*/
	@Transient
	public String getProjectName() {
		return projectName;
	}	
	
	@Transient
	public Integer getOverDueStatus() {
		return overDueStatus;
	}

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public ProjectTask(Integer taskId) {
        this.taskId = taskId;
    }
	public String getAssignedAssociate() {
		return assignedAssociate;
	}

	public void setAssignedAssociate(String assignedAssociate) {
		this.assignedAssociate = assignedAssociate;
	}
    public ProjectTask(Integer taskId, String title, Date startDate, Date dueDate, Boolean taskCompleted, String assignedToId, Boolean timesheet,
                       String projectName, Integer projectId, String assignedAssociate, Boolean isGeneric) {
		
		this.taskId = taskId;
		this.title = title;
		this.startDate = startDate;
		this.dueDate = dueDate;
		this.taskCompleted = taskCompleted;
		this.assignedToId = assignedToId;
		this.timesheet = timesheet;
		this.projectName = projectName;
		this.projectId = projectId;
		this.assignedAssociate = assignedAssociate;		
		this.isGeneric = isGeneric;
	}

    public ProjectTask(Integer taskId, String title,Boolean isGeneric) {
		super();
		this.taskId = taskId;
		this.title = title;
		this.isGeneric = isGeneric;
	}

	@Override
    public ProjectTask clone() throws CloneNotSupportedException {
        return (ProjectTask) super.clone();
    }
}