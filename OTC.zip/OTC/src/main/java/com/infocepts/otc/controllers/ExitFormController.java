package com.infocepts.otc.controllers;

import java.util.List;

import javax.mail.MessagingException;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.infocepts.otc.entities.ExitForm;
import com.infocepts.otc.repositories.ExitFormRepository;
import com.infocepts.otc.services.TimesheetService;

@RestController
@RequestMapping(value="/exitform",headers="referer")
public class ExitFormController {

	@Autowired
	ExitFormRepository repository;
	
	@Autowired
	TimesheetService service;
	
	
	final Logger logger = Logger.getLogger(UnitController.class);
	
	@RequestMapping(method=RequestMethod.GET)
	public List<ExitForm> getExitform(@RequestParam(name="uid",defaultValue="0") Integer uid){
		List<ExitForm> ExitFormList=null;
		Boolean isAValidCall = false;
		if(service.isHR() || service.isAdmin()){
			isAValidCall = true;
		}
	try{
		if(isAValidCall) {
			ExitFormList = repository.findAll();
		}else if(uid!=null && uid!=0) {
			ExitFormList = repository.findByUid(uid);
		}
	}catch(Exception e){
		 logger.error(e);
	 }
		return ExitFormList;
	}
	
	
	
	 @RequestMapping(value="/{exitFormId}",method=RequestMethod.GET)
	 public ExitForm getExitFormById(@PathVariable Integer exitFormId){
		 
		 ExitForm exitForm=null;
		 try{		
			 exitForm = repository.findOne(exitFormId);
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return exitForm;
	 }
	 
	
	@RequestMapping(method=RequestMethod.POST)
	public ExitForm addExitForm(@RequestBody ExitForm exitForm, HttpServletRequest request) throws MessagingException
	{
		try{
			exitForm.setExitFormId(null);
			repository.save(exitForm);	
			service.sendExitFormNotification(exitForm, "add", request);																	

		}catch(Exception e){
			logger.error(e);
		}
		return exitForm;
	}	


//	@RequestMapping(value="/{exitFormId}",method=RequestMethod.DELETE)
//	 public void deleteExitForm(@PathVariable Integer exitFormId){
//		 try{
//			 //if(service.isAR()){
//				 repository.delete(exitFormId);
//			 //}
//		 }
//		 catch(Exception e){
//			 logger.error(e);
//		 }
//	 }	 
//	
	 @RequestMapping(value="/{exitFormId}",method=RequestMethod.PUT)
	 public ExitForm updateExitForm(@RequestBody ExitForm updatedExitForm,@PathVariable Integer exitFormId){
		 System.out.print("exit form ID is here");
		 try{
				 updatedExitForm.setExitFormId(exitFormId);
				 repository.save(updatedExitForm);
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return updatedExitForm;
	 }
	
}
