/**
 * 
 */
package com.infocepts.otc.utilities;

import java.net.InetAddress;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.mail.MessagingException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

/**
 * @author vibhusha v chimankar
 *
 */

@Component //to autowire the class 
public final class InfoTravelUtil extends Object {

	@Autowired
    TemplateEngine templateEngine;
	
    @Autowired
    private JavaMailSender javaMailSender;
    
    private static final String INFOBIZ_MAIL_ID = LoadConstant.INFOBIZ;    
    

    public void send(String from, String to, String subject, String templateName, Context context, String ccEmails) throws MessagingException {
        final Logger logger = Logger.getLogger(InfoTravelUtil.class.getName());
       
		
        try {
        	logger.info("from Address: "+from);	
        	logger.info("to Address: "+to);	
        	logger.info("subject Address: "+subject);	
        	logger.info("templateName Address: "+templateName);	
        	logger.info("ccEmails Address: "+ccEmails);
        	
        	
            MimeMessage message = javaMailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, true);    // true indicates
            String body = templateEngine.process(templateName, context);
           
            helper.setSubject(subject);
            
            // Env check
        	InetAddress ip2;
    		ip2 = InetAddress.getLocalHost();
    		
    		logger.info("inside InfoTravelUtil class. printing logger");
    	    logger.info("Your current IP2 address : " + ip2);
    		logger.info("IP2 Host Name: "+ip2.getHostName());
    		logger.info("IP2 Address: "+ip2.getHostAddress());	
    		
    		if (!("infobiz-fe1").equals(ip2.getHostName())) {//cron to run only on fe1
    			helper.setTo(INFOBIZ_MAIL_ID);
                logger.log(Level.WARNING, "COULD NOT SEND CRON EMAIL ON NON PROD ENV!");
    		}
    		else {
                if(!"".equals(to)) {                 	
	                String[] toEmail = to.split(",");
	                InternetAddress[] toAddress = new InternetAddress[toEmail.length];
	                for (int i = 0; i < toAddress.length; i++) {
	                    if(toEmail[i].equals("sgarg@infocepts.com") || toEmail[i].equals("rbhayana@infocepts.com")) {
	                    	toEmail[i] = LoadConstant.INFOBIZ;
	                    }
	                    toAddress[i] = new InternetAddress(toEmail[i]);
	                }
	
	                helper.setTo(toAddress);
                }
                helper.addBcc(LoadConstant.INFOBIZ);

                if(!"".equals(ccEmails)) {
                	
	                String[] ccEmail = ccEmails.split(",");
	                InternetAddress[] address = new InternetAddress[ccEmail.length];
	                for (int i = 0; i < ccEmail.length; i++) {
	                    if(ccEmail[i].equals("sgarg@infocepts.com") || ccEmail[i].equals("rbhayana@infocepts.com")) {
	                    	ccEmail[i] = LoadConstant.INFOBIZ;
	                    }
	                    address[i] = new InternetAddress(ccEmail[i]);
	                }
	
	                if (ccEmails != LoadConstant.INFOBIZ_ADMIN) {
	                    helper.setCc(address);
	                }
                }
            }
            helper.setText(body, true);
            if(!"".equals(from)) {
            	 helper.setFrom(from);
            }
           
            javaMailSender.send(message);
            logger.info("Mail successfully send to - " + to);
        } catch (Exception e) {
        	logger.log(Level.SEVERE, "exceptn msg", e);
        }
    }
}
