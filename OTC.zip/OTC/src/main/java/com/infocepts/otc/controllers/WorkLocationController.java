package com.infocepts.otc.controllers;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.infocepts.otc.entities.AssociateSkills;
import com.infocepts.otc.entities.WorkLocation;
import com.infocepts.otc.repositories.WorkLocationRepository;
import com.infocepts.otc.services.TimesheetService;

@RestController
@RequestMapping(value="/worklocation",headers="referer")
public class WorkLocationController {

	@Autowired 
	WorkLocationRepository workLocationRepository;
	
	@Autowired
	TimesheetService service;
	
	@PersistenceContext(unitName="otc")
    private EntityManager manager;
	
	@RequestMapping(method=RequestMethod.POST)
	public WorkLocation addWorkLocation(@RequestBody WorkLocation workLocation) {
		workLocation.setWorkLocationId(null);
		Boolean isAValidCall = false;
		if(service.isTravel())
		{
			isAValidCall = true;
		}
		if(isAValidCall) {
			
			workLocationRepository.save(workLocation);
		}
		return workLocation;
	}
	
	@RequestMapping(method=RequestMethod.GET)
	public List<WorkLocation> getWorkLocation(@RequestParam(value = "status", defaultValue = "false") Boolean status) {
		List<WorkLocation> list=null;
		Boolean isAValidCall = false;
		if(service.isTravel())
		{
			isAValidCall = true;
		}
		//if(isAValidCall) {
			if(status) {
				System.out.println("inside status"+status);
				list = manager.createNamedQuery("getCity_WorkLocation",WorkLocation.class)
						  .getResultList();
			}
			else {
				list=workLocationRepository.findAll();
			}
			
		//}
		return list;
	}
	
	@RequestMapping(value="/{workLocationId}",method=RequestMethod.GET)
	public WorkLocation getWorkLocation(@PathVariable Integer workLocationId){
		WorkLocation workLocation = null;
		Boolean isAValidCall = false;
		if(service.isTravel())
		{
			isAValidCall = true;
		}
		if(isAValidCall) {
			
			workLocation = workLocationRepository.findOne(workLocationId);
		}
		return workLocation;
	}
	
	@RequestMapping(value="/{workLocationId}",method=RequestMethod.PUT)
	public WorkLocation updateWorkLocation(@PathVariable Integer workLocationId,@RequestBody WorkLocation updatedWorkLocation) {
		updatedWorkLocation.setWorkLocationId(workLocationId);
		Boolean isAValidCall = false;
		if(service.isTravel())
		{
			isAValidCall = true;
		}
		if(isAValidCall) {
			
			workLocationRepository.save(updatedWorkLocation);
		}
		return updatedWorkLocation;
	}
	
	@RequestMapping(value="/{workLocationId}",method=RequestMethod.DELETE)
	public void deleteWorkLocation(@PathVariable Integer workLocationId) {
		Boolean isAValidCall = false;
		if(service.isTravel())
		{
			isAValidCall = true;
		}
		if(isAValidCall) {
			
			workLocationRepository.delete(workLocationId);
		}
	}
}
