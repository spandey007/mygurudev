package com.infocepts.otc.controllers;

import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.infocepts.otc.entities.InvoicesReceipt;
import com.infocepts.otc.repositories.InvoicesReceiptRepository;
import com.infocepts.otc.services.TimesheetService;

@RestController
@RequestMapping(value="/invoicesReceipt",headers="referer")
public class InvoicesReceiptController {
	
	@Autowired
	InvoicesReceiptRepository repository;
	
	@Autowired
	TimesheetService service;
	
	final Logger logger = Logger.getLogger(InvoicesReceiptController.class);
	
	@RequestMapping(method=RequestMethod.POST)
	public InvoicesReceipt addInvoicesReceipt(@RequestBody InvoicesReceipt invoicesReceipt)
	{
		try{
			if(service.isAR()){
				invoicesReceipt.setInvoiceReceiptID(null);
				repository.save(invoicesReceipt);	
			}
		}catch(Exception e){
			logger.error(e);
		}
		return invoicesReceipt;
	}	
	
	 @GetMapping("getAllInvoicesReceipts")
	 public List<InvoicesReceipt> getAllInvoicesReceipts(@RequestParam(value = "invoiceId", defaultValue = "0") Integer invoiceId){
		 List<InvoicesReceipt> listInvoicesReceipt=null;
		 try{
			 if(service.isAR()){
				 if(invoiceId != 0){
					 listInvoicesReceipt = repository.findByInvoiceId(invoiceId);
				 }
				 else{
					 listInvoicesReceipt = repository.findAll();
				 }
				 
			 }
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return listInvoicesReceipt;
	 }

	@GetMapping("getInvoicesReceiptbyId")
	 public InvoicesReceipt getInvoicesReceipt(@PathVariable Integer invoiceReceiptID){
		 InvoicesReceipt invoicesReceipt=null;
		 try{
			 if(service.isAR()){
				 invoicesReceipt = repository.findOne(invoiceReceiptID);
			 }
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return invoicesReceipt;
	 }
	
	 @RequestMapping(value="/{invoiceReceiptID}",method=RequestMethod.PUT)
	 public InvoicesReceipt updateInvoicesReceipt(@RequestBody InvoicesReceipt updatedInvoicesReceipt,@PathVariable Integer invoiceReceiptID){
		 try{
			 if(service.isAR()){
				 updatedInvoicesReceipt.setInvoiceReceiptID(invoiceReceiptID);
				 repository.save(updatedInvoicesReceipt);
			 }
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return updatedInvoicesReceipt;
	 }
	 
	 @RequestMapping(value="/{invoiceReceiptID}",method=RequestMethod.DELETE)
	 public void deleteInvoicesReceipt(@PathVariable Integer invoiceReceiptID){
		 try{
			 if(service.isAR()){
				 repository.delete(invoiceReceiptID);
			 }
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
	 }	 
}
