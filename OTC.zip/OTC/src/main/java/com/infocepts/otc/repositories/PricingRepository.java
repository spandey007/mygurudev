package com.infocepts.otc.repositories;

import java.io.Serializable;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.infocepts.otc.entities.ExpenseCategory;
import com.infocepts.otc.entities.Pricing;

@Repository
public interface PricingRepository extends JpaRepository<Pricing, Serializable>{
	
	@Query("select p FROM Pricing p where p.cmsId = :cmsId")
	public Pricing findOne(@Param("cmsId") Integer cmsId);
}
