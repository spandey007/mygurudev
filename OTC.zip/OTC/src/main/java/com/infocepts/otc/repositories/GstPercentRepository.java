package com.infocepts.otc.repositories;

import java.util.List;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import com.infocepts.otc.entities.GstPercent;
import java.lang.String;

public interface GstPercentRepository extends CrudRepository<GstPercent,Integer>{

	@Override
	public List<GstPercent> findAll();
	
	@Query("from GstPercent where title=:title")
	public GstPercent findByTitle(@Param("title") String title);
}
