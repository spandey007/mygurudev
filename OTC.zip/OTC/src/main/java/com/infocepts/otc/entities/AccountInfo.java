package com.infocepts.otc.entities;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.SqlResultSetMappings;
import javax.persistence.Column;
import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import com.infocepts.otc.utilities.LoadConstant;

@Entity
@Table(catalog=LoadConstant.otc,schema="[dbo]",name="accountInfo")
@SqlResultSetMappings({
    @SqlResultSetMapping(
            name = "get_all_account_info",
            classes = {
                    @ConstructorResult(
                            targetClass = AccountInfo.class,
                            columns = {
                            		@ColumnResult(name = "accountInfoId"),									
                                    @ColumnResult(name = "accountId"),  
                                    @ColumnResult(name = "staffingPartnerId"),
                                    @ColumnResult(name = "accountShortName", type = String.class),  
                                    @ColumnResult(name = "accountTitle",type = String.class),
									@ColumnResult(name = "staffingPartnerName",type = String.class),
									@ColumnResult(name = "createdBy"),
                                    @ColumnResult(name = "createdDate", type = Date.class),
									@ColumnResult(name = "modifiedBy"),
                                    @ColumnResult(name = "modifiedDate", type = Date.class),
                                    @ColumnResult(name = "faMappingId"),
                                    @ColumnResult(name = "faName",type = String.class),
                            }
                    )
            }
    )
})
@NamedNativeQueries({
    @NamedNativeQuery(
            name    =   "getAllAccountInfo",   
            query 	=   "Select ai.*, a.accountShortName as accountShortName, a.title as accountTitle, r.title as staffingPartnerName, rr.title as faName"+
            			" from " + LoadConstant.otc + ".[dbo].accountInfo as ai"+
            			" LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[accounts] a on a.itemId = ai.accountId"+
            			" LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[resource] r on r.uid = ai.staffingPartnerId "+	
            			" LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[resource] rr on rr.uid = ai.faMappingId "+	
						" order by a.accountShortName",
						 
						resultClass=AccountInfo.class, resultSetMapping = "get_all_account_info"
    )        
})
public class AccountInfo {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer accountInfoId;
	
	private Integer staffingPartnerId;
	
	private Integer accountId;
	
	private Integer faMappingId;
	
	@Transient
	private String accountShortName;
	
	@Transient
	private String accountTitle ;
	
	@Transient
	private String staffingPartnerName ;
	
	@Transient
	private String faName ;
	
	private Integer createdBy;
    private Date createdDate;
    private Integer modifiedBy;
    private Date modifiedDate;
   
	public Integer getAccountInfoId() {
		return accountInfoId;
	}
	public void setAccountInfoId(Integer accountInfoId) {
		this.accountInfoId = accountInfoId;
	}
	public Integer getStaffingPartnerId() {
		return staffingPartnerId;
	}
	public void setStaffingPartnerId(Integer staffingPartnerId) {
		this.staffingPartnerId = staffingPartnerId;
	}
	public Integer getAccountId() {
		return accountId;
	}
	public void setAccountId(Integer accountId) {
		this.accountId = accountId;
	}
	public String getAccountShortName() {
		return accountShortName;
	}
	public void setAccountShortName(String accountShortName) {
		this.accountShortName = accountShortName;
	}
	public String getAccountTitle() {
		return accountTitle;
	}
	public void setAccountTitle(String accountTitle) {
		this.accountTitle = accountTitle;
	}
	public String getStaffingPartnerName() {
		return staffingPartnerName;
	}
	public void setStaffingPartnerName(String staffingPartnerName) {
		this.staffingPartnerName = staffingPartnerName;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public Integer getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}
	public Date getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public Integer getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	
	/**
	 * @return the faMappingId
	 */
	public Integer getFaMappingId() {
		return faMappingId;
	}
	/**
	 * @param faMappingId the faMappingId to set
	 */
	public void setFaMappingId(Integer faMappingId) {
		this.faMappingId = faMappingId;
	}
	
	/**
	 * @return the faName
	 */
	public String getFaName() {
		return faName;
	}
	/**
	 * @param faName the faName to set
	 */
	public void setFaName(String faName) {
		this.faName = faName;
	}
	public AccountInfo() {
		//super();
		// TODO Auto-generated constructor stub
	}
	
	public AccountInfo(Integer accountInfoId, Integer accountId, Integer staffingPartnerId, String accountShortName,
			String accountTitle, String staffingPartnerName,Integer createdBy, Date createdDate, Integer modifiedBy,
			Date modifiedDate, Integer faMappingId, String faName
			) {
		//super();
		this.accountInfoId = accountInfoId;		
		this.accountId = accountId;
		this.staffingPartnerId = staffingPartnerId;
		this.accountShortName = accountShortName;
		this.accountTitle = accountTitle;
		this.staffingPartnerName = staffingPartnerName;
		this.createdBy = createdBy;
		this.createdDate = createdDate;
		this.modifiedBy = modifiedBy;
		this.modifiedDate = modifiedDate;
		this.faMappingId = faMappingId;
		this.faName = faName;
	}

	

	
}
