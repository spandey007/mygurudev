package com.infocepts.otc;

import java.io.IOException;
import java.net.InetAddress;
import java.text.ParseException;

import java.util.logging.Logger;

import javax.mail.MessagingException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.infocepts.otc.services.TimesheetService;
import com.infocepts.otc.utilities.InfoTravelUtil;
import com.infocepts.otc.utilities.SchedulerTask;

@Component
public class ScheduledTasks {
	
	 @Autowired
	 private SchedulerTask schedulerTask;
	 
	 @Autowired
	private TimesheetService service;
	 
	 @Autowired
	 private InfoTravelUtil infoTravelUtil;
	
	final Logger logger = Logger.getLogger(ScheduledTasks.class.getName());
	
	//**************************START: Job to copy GTP data from last date to current date at 1 AM night****************************/	
	@Scheduled(cron = "0 30 22 ? * *") 	
	public void scheduleTaskForGtpDataLoadForCurrentDate() throws IOException, ParseException {			
		InetAddress ip2;
		ip2 = InetAddress.getLocalHost();
		

		logger.info("inside ScheduledTasks class. printing logger");
	    logger.info("Your current IP2 address : " + ip2);
		logger.info("IP2 Host Name: "+ip2.getHostName());
		logger.info("IP2 Address: "+ip2.getHostAddress());	
		
	    long now = System.currentTimeMillis() / 1000;
	    System.out.println("Cronjob: scheduleTaskForGtpDataLoadForCurrentDate Method executed at 11PM - " + now);
		
		if(("infobiz-fe1").equals(ip2.getHostName())){ 
			schedulerTask.gtpUploadLastData();	   
	    }
	
		if(("infobizstage1").equals(ip2.getHostName())){ 
	    	schedulerTask.gtpUploadLastData();	   
	    }
	      
		if(("infobizdev").equals(ip2.getHostName())){ 
	    	schedulerTask.gtpUploadLastData();	   
	    }
	}
	//**************************END: Job to copy GTP data from last date to current date at 1 AM night**************************************************/
	
	 //second, minute, hour, day, month, weekday
	 @Scheduled(cron = "0 0 */2 * * 1-5")//fianance cron - every 2 hours monday to friday	
	 public void sendInfoTravelFinanceCronNotification() throws IOException, ParseException, MessagingException {
		
		InetAddress ip2; 
		ip2 = InetAddress.getLocalHost(); 
		if (("infobiz-fe1").equals(ip2.getHostName()))
		  {//cron to run only on fe1
			  service.sendInfoTravelFinanceCronNotification(); 
			  
		  }
	  }
	 	
	  @Scheduled(cron = "0 0 */4 * * 1-5") //approval cron - every 4 hours monday to friday
	  public void scheduleTaskForInfoTravel() throws IOException, ParseException, MessagingException { 
		  
		  InetAddress ip2;
		  ip2 = InetAddress.getLocalHost(); 
		  if(("infobiz-fe1").equals(ip2.getHostName())) 
		  {//cron to run only on fe1
			  service.sendInfoTravelApproverCronNotification(); 
		  }
	  }
	 
	
	  @Scheduled(cron = "0 0 */12 * * 1-5") //travel desk cron - every 12hrs days monday to friday | 72hrs	
	  public void sendInfoTravelDeskDomesticEsc1CronNotification() throws IOException, ParseException, MessagingException {
		
		InetAddress ip2; 
		ip2 = InetAddress.getLocalHost(); 
		if (("infobiz-fe1").equals(ip2.getHostName()))
		  {//cron to run only on fe1
			service.sendInfoTravelDeskDomesticEsc1CronNotification();
		  } 
	  }
	 
	  @Scheduled(cron = "0 0 */24 * * 1-5") //travel desk cron - every 12hrs days monday to friday | 120hrs	
	  public void sendInfoTravelDeskInternationalEsc1CronNotification() throws IOException, ParseException, MessagingException {
		
		InetAddress ip2; 
		ip2 = InetAddress.getLocalHost(); 
		if (("infobiz-fe1").equals(ip2.getHostName()))
		  {//cron to run only on fe1
			service.sendInfoTravelDeskInternationalEsc1CronNotification();
		  } 
	  }
	
	 @Scheduled(cron = "0 0 */36 * * 1-5") //travel desk cron - every 4 days monday to friday | 96hrs	
	 public void sendInfoTravelDeskDomesticEsc2CronNotification() throws IOException, ParseException, MessagingException {
		
		InetAddress ip2; 
		ip2 =InetAddress.getLocalHost(); 
		if (("infobiz-fe1").equals(ip2.getHostName()))
		  {//cron to run only on fe1
		  service.sendInfoTravelDeskDomesticEsc2CronNotification(); 
		  } 
	}
	 
	
	@Scheduled(cron = "0 0 */48 * * 1-5") //travel desk cron - every 7 days monday to friday | 168hrs
	public void sendInfoTravelDeskInternationalEsc2CronNotification() throws IOException, ParseException, MessagingException {
	   
	   InetAddress ip2;
	   ip2 = InetAddress.getLocalHost(); 
	   if (("infobiz-fe1").equals(ip2.getHostName()))
		  {//cron to run only on fe1
		  service.sendInfoTravelDeskInternationalEsc2CronNotification();
		  }
	   }
	 
	
	@Scheduled(cron = "0 0 */48 * * 1-5") //auto reject cron - every 2 days monday to friday | 48hrs
	public void sendInfoTravelAutoRejectionNotification() throws IOException, ParseException, MessagingException {
		  
	  InetAddress ip2; 
	  ip2 = InetAddress.getLocalHost(); 
	  if (("infobiz-fe1").equals(ip2.getHostName()))
		  {//cron to run only on fe1
			  service.sendInfoTravelAutoRejectionNotification();
		  }
	  }
	
	@Scheduled(cron = "0 0 */24 * * 1-5") //survey reminder notification crons - monday to friday at 12pm
	public void sendSurveyReminderNotifications() throws IOException, ParseException, MessagingException {
		  
	  InetAddress ip2; 
	  ip2 = InetAddress.getLocalHost(); 
	  if (("infobiz-fe1").equals(ip2.getHostName()))
		  {//cron to run only on fe1
			  service.sendSurveyReminderNotifications();
		  }
	  }
	 
	
}