package com.infocepts.otc.controllers;
import java.util.logging.Level;
import java.util.logging.Logger;
import com.infocepts.otc.entities.ExchangeRate;
import com.infocepts.otc.repositories.ExchangeRateRepository;
import com.infocepts.otc.services.TimesheetService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import javax.mail.MessagingException;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.List;

@RestController
@RequestMapping(value="/exchangerate", headers="referer")
public class ExchangeRateController {
	final Logger logger = Logger.getLogger(ExchangeRateController.class.getName());

    @Autowired
    ExchangeRateRepository repository;
    
    @Autowired
    HttpSession session;

    @PersistenceContext(unitName = "otc") 
    private EntityManager manager;
			
	@Autowired
	TimesheetService service;


    /**
     * This method is add row in moduleName entity
     * 
     */
    @RequestMapping(method=RequestMethod.POST)
	public ExchangeRate addExchangeRate(@RequestBody ExchangeRate exchangeRate, HttpServletRequest request) throws MessagingException {
		// Authorization for XYZ role
		if(service.isTVF() || service.isAdmin())
		{
			try{
				exchangeRate.setRateId(null);
				repository.save(exchangeRate);
			}
			catch(Exception e){
				 logger.info(String.format("exception - ", e));
			}
		}
		else 
		{
			service.sendTamperedMail("Exchange Rate Save", 0, 0, request);
		}
		
		return exchangeRate;
	}
    
    /**
     * This method is update row in moduleName entity
     * based on primaryKey Of Module Table 
     */
    @RequestMapping(value="/{rateId}",method=RequestMethod.PUT)
	 public ExchangeRate updateExchangeRate(@RequestBody ExchangeRate updatedExchangeRate,@PathVariable Integer rateId,HttpServletRequest request) throws MessagingException{
        // Authorization for XYZ role
		if(service.isTVF() || service.isAdmin())
		{	
			try{
				updatedExchangeRate.setRateId(rateId);
				 repository.save(updatedExchangeRate);
			}
			catch(Exception e){
				 logger.info(String.format("exception - ", e));
			}
		}
		else
		{
			service.sendTamperedMail("Exchange Rate Save", 0, 0, request);
		}
		 return updatedExchangeRate;
	 }
      //Get exchangerate for previous month
    @GetMapping("/getExchangeRateByPrevMonth")
	public Object getExchangeRateByPrevMonth(@RequestParam(value = "prevMonthNo", defaultValue = "0")Integer prevMonthNo,
			  @RequestParam(value = "currYear", defaultValue = "")String currYear,
			
			HttpServletRequest request) {
		List<ExchangeRate> exchangeRateList = null;
		  try {
      		
				if(service.isTVF() || service.isAdmin() )
				{
		if(prevMonthNo!=0)
		{
		exchangeRateList = manager.createNamedQuery("getExchangeRateForPrevMonth", ExchangeRate.class)                        
                .setParameter("prevMonthNo", prevMonthNo)
                .setParameter("currYear", currYear)
                .getResultList();
		}
				}
		
		} catch (Exception e) {
			logger.log(Level.SEVERE, "exceptn msg", e);
		}
		return exchangeRateList;
	}
    //Get exchangerate for month month
    @GetMapping("/getExchangeRateByMonth")
	public Object getExchangeRateByMonth(@RequestParam(value = "monthEndDate", defaultValue = "")String monthEndDate,
	                                     @RequestParam(value = "monthStartDate", defaultValue = "")String monthStartDate,
			
			HttpServletRequest request) {
		List<ExchangeRate> exchangeRateList = null;
		  try {
      		
				if(service.isTVF() || service.isAdmin() )
				{
		
			exchangeRateList = manager.createNamedQuery("getExchangeRateForaMonth", ExchangeRate.class)                        
                    .setParameter("monthStartDate", monthStartDate)
                    .setParameter("monthEndDate", monthEndDate)
                    .getResultList();	
				}
		
		} catch (Exception e) {
			logger.log(Level.SEVERE, "exceptn msg", e);
		}
		return exchangeRateList;
	}
  
}
