package com.infocepts.otc.utilities;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.CodeSource;
import java.sql.Date;
import java.text.NumberFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.RandomUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.docx4j.Docx4jProperties;
import org.docx4j.model.structure.PageSizePaper;
import org.docx4j.openpackaging.contenttype.ContentType;
import org.docx4j.openpackaging.packages.WordprocessingMLPackage;
import org.docx4j.openpackaging.parts.PartName;
import org.docx4j.openpackaging.parts.WordprocessingML.AlternativeFormatInputPart;
import org.docx4j.relationships.Relationship;
import org.docx4j.wml.CTAltChunk;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;
import org.springframework.web.multipart.MultipartFile;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;
import com.infocepts.otc.controllers.ResourceController;
import com.infocepts.otc.entities.Account;
import com.infocepts.otc.entities.BankDetails;
import com.infocepts.otc.entities.Country;
import com.infocepts.otc.entities.Currency;
import com.infocepts.otc.entities.DeAppreciation;
import com.infocepts.otc.entities.DeComplaint;
import com.infocepts.otc.entities.DeMsr;
import com.infocepts.otc.entities.DePhUpdate;
import com.infocepts.otc.entities.DeValueAdd;
import com.infocepts.otc.entities.DeWsr;
import com.infocepts.otc.entities.ISow;
import com.infocepts.otc.entities.ISowDetail;
import com.infocepts.otc.entities.ISowMilestone;
import com.infocepts.otc.entities.InvoiceInfo;
import com.infocepts.otc.entities.Invoices;
import com.infocepts.otc.entities.InvoicesDetail;
import com.infocepts.otc.entities.Portfolio;
import com.infocepts.otc.entities.Project;
import com.infocepts.otc.entities.ProjectTerms;
import com.infocepts.otc.entities.Sow;
import com.infocepts.otc.entities.State;
import com.infocepts.otc.entities.TermCondition;
import com.infocepts.otc.entities.Unit;
import com.infocepts.otc.entities.Uom;
import com.infocepts.otc.entities.WeeklyHours;
import com.infocepts.otc.repositories.AccountRepository;
import com.infocepts.otc.repositories.BankDetailsRepository;
import com.infocepts.otc.repositories.CountryRepository;
import com.infocepts.otc.repositories.CurrencyRepository;
import com.infocepts.otc.repositories.DeAppreciationRepository;
import com.infocepts.otc.repositories.DeComplaintRepository;
import com.infocepts.otc.repositories.DeMsrRepository;
import com.infocepts.otc.repositories.DePhUpdateRepository;
import com.infocepts.otc.repositories.DeValueAddRepository;
import com.infocepts.otc.repositories.DeWsrRepository;
import com.infocepts.otc.repositories.EntitiesRepository;
import com.infocepts.otc.repositories.InvoiceInfoRepository;
import com.infocepts.otc.repositories.ProjectTermsRepository;
import com.infocepts.otc.repositories.SowRepository;
import com.infocepts.otc.repositories.StateRepository;
import com.infocepts.otc.repositories.TermConditionRepository;
import com.infocepts.otc.repositories.UnitRepository;
import com.infocepts.otc.repositories.UomRepository;

@Component
public class ExportUtil {

	private static final Logger logger = Logger.getLogger(ExportUtil.class.getName());

	@Autowired
	private TemplateEngine templateEngine;

	@PersistenceContext(unitName = "otc")
	private EntityManager manager;

	@Value("${spring.host.envurl}")
	private String infobizenvhost;

	@Value("${spring.host.localdrive}")
	private String localdrive;

	@Autowired
	public InvoiceInfoRepository invoiceInfoRepository;

	@Autowired
	public BankDetailsRepository bankDetail;

	@Autowired
	public EntitiesRepository EntitiesDetail;

	@Autowired
	public ProjectTermsRepository projectTerms;

	@Autowired
	TermConditionRepository repository;

	@Autowired
	ResourceController resourceController;

	@Autowired
	public UnitRepository unitRepository;

	@Autowired
	public StateRepository stateRepository;

	@Autowired
	public CountryRepository countryRepository;

	@Autowired
	public CurrencyRepository currencyRepository;

	@Autowired
	AccountRepository accountRepository;
	
	@Autowired
	SowRepository sowRepository;
	
	@Autowired
	UomRepository uomRepository;
	
	@Autowired
	public DeWsrRepository deWsrRepository;
	
	@Autowired
	public DeAppreciationRepository deAppreciationRepository;
	
	@Autowired
	public DeValueAddRepository deValueAddRepository;
	
	@Autowired
	public DeComplaintRepository deComplaintRepository;
	
	@Autowired
	public DeMsrRepository deMsrRepository;

	@Autowired
	public DePhUpdateRepository dePhUpdateRepository;

	
	File home = null;
	File outputFile = null;
	FileOutputStream os = null;

	File rootPath = null;
	String pathSeparator="/";

	public String createInvoiceWord(String templateName, Invoices invoice, List<InvoicesDetail> invoicesDetails,
			HttpServletRequest request) throws Exception {

		home = checkPath(request);

		Map<String, String> map = new HashMap<String, String>();

		InvoiceInfo invoiceInfo = null;
		BankDetails bankDetails = null;
		String bankType = "";
		Unit unit = null;
		Country country = null;
		Country shippingCountry = null;
		State state = null;
		State shippingState = null;
		Currency currency = null;
		Currency exchangeCurrency = null;
		BigDecimal exchangeRate = BigDecimal.ZERO;
		BigDecimal discountPercent = BigDecimal.ZERO;
		BigDecimal dicountAmount = BigDecimal.ZERO;
		BigDecimal netSubTotal = BigDecimal.ZERO;
		BigDecimal total = BigDecimal.ZERO;
		String amountInWord = "";
		String currencyCode = "";
		String exchangeCurrencyCode = "";
		String billing = "";
		BigDecimal cgst = BigDecimal.ZERO;
		BigDecimal sgst = BigDecimal.ZERO;
		BigDecimal igst = BigDecimal.ZERO;
		BigDecimal utgst = BigDecimal.ZERO;
		BigDecimal cgstAmount = BigDecimal.ZERO;
		BigDecimal sgstAmount = BigDecimal.ZERO;
		BigDecimal igstAmount = BigDecimal.ZERO;
		BigDecimal iniatialIgstAmount = BigDecimal.ZERO;
		BigDecimal iniatialUtgstAmount = BigDecimal.ZERO;
		BigDecimal iniatialSgstAmount = BigDecimal.ZERO;
		BigDecimal iniatialCgstAmount = BigDecimal.ZERO;
		BigDecimal iniatialAmount = BigDecimal.ZERO;
		BigDecimal utgstAmount = BigDecimal.ZERO;
		BigDecimal sgdgst = BigDecimal.ZERO;
		BigDecimal sgdgstAmount = BigDecimal.ZERO;
		String invoiceType = "";
		BigDecimal subTotal = BigDecimal.ZERO;
		BigDecimal iniatialBuildAmount = BigDecimal.ZERO;
		BigDecimal iniatialBuildAmountTotal = BigDecimal.ZERO;
		BigDecimal quantityHoursTotal = BigDecimal.ZERO;
		BigDecimal discountAmountTotal = BigDecimal.ZERO;
		BigDecimal iniatialNetTotalAmount = BigDecimal.ZERO;
		BigDecimal iniatialdiscountAmountTotal = BigDecimal.ZERO;
		BigDecimal gstPercent = BigDecimal.ZERO;
		BigDecimal gstiniatialAmount = BigDecimal.ZERO;		
		BigDecimal gstTotal = BigDecimal.ZERO;		
		
		BigDecimal iniatialSgdGstAmount = BigDecimal.ZERO;
		BigDecimal iniatialTotal = BigDecimal.ZERO;
		String infoCeptsRole = "";
		String clientRole = "";
		String resourceName = "";
		String sDate = "";
		String eDate = "";
		BigDecimal billableRate = BigDecimal.ZERO;
		BigDecimal tsHrs = BigDecimal.ZERO;
		BigDecimal amount = BigDecimal.ZERO;
		BigDecimal subtotal = BigDecimal.ZERO;
		BigDecimal discountAmount = BigDecimal.ZERO;
		BigDecimal totalAmount = BigDecimal.ZERO;
		String roundOff = "0";
		String role = "";
		String projectName = "";
		String purposeExpense = "";
		String expStartDate = "";
		String expEndDate = "";
		String comments = "";
		BigDecimal discountAmt = BigDecimal.ZERO;
		BigDecimal taxAmt = BigDecimal.ZERO;
		BigDecimal taxPercent = BigDecimal.ZERO;
		BigDecimal iniatialTaxAmount = BigDecimal.ZERO;		
		String description = "";
		Integer billingUnitId = 0;
		String currencySign = "";
		String exchangeCurrencySign = "";
		BigDecimal initialBilledAmount = BigDecimal.ZERO;
		StringBuilder billingDetail = new StringBuilder();
		StringBuilder itplBillingDetail = new StringBuilder();
		StringBuilder itplGSTCalculation = new StringBuilder();
		StringBuilder itplFBBillingDetail = new StringBuilder();
		StringBuilder itplFBGSTCalculation = new StringBuilder();
		StringBuilder itplEXPBillingDetail = new StringBuilder();
		StringBuilder itplEXPGSTCalculation = new StringBuilder();
		StringBuilder weeklyBillingDetail = new StringBuilder();
		StringBuilder itplFBMilestoneDetail = new StringBuilder();
		StringBuilder itplInternalInvoiceFooter = new StringBuilder();
		StringBuilder pteExpenseDetail = new StringBuilder();

		Integer endClientbillingUnitId = null;
		Integer endClientProjectId=null;
		Project project = null;
		Account account= null;
		BigDecimal NoOfManDays = BigDecimal.ZERO;
		Integer previousUserId = 0;
		BigDecimal weeklyTotal = BigDecimal.ZERO;
		BigDecimal tsHours = BigDecimal.ZERO;
		BigDecimal grandTotal = BigDecimal.ZERO;
		
		BigDecimal onsiteHrsTotal = BigDecimal.ZERO;
		BigDecimal offshoreHrsTotal = BigDecimal.ZERO;
		BigDecimal onsiteAmountTotal = BigDecimal.ZERO;
		BigDecimal offshoreAmountTotal = BigDecimal.ZERO;
		Integer offshoreCount = 0;
		String infoCeptsClientRole = "";
		String clientPOAndTitle = "";
		String projectTitle = "";
		String hoursMonthlyTitle = "Hour";
		String associateNameRoleLabel = "Associate Name";
		String associateNameRoleTitle = "";
		

		StringBuilder offshoreRecords = new StringBuilder();
		StringBuilder onsiteRecords = new StringBuilder();
		StringBuilder onsiteRecordsCount = new StringBuilder();

		if (invoice != null) {
			
			if (invoice.getBillingType() != null) {
				billing = invoice.getBillingType();
			}
			
			if (invoice.getEndClientProjectId() != null){
				endClientProjectId = invoice.getEndClientProjectId();
			}

			if (invoice.getCurrencyId() != null) {
				currency = currencyRepository.findOne(invoice.getCurrencyId());
				if(currency!=null){
					currencyCode = currency.getCode();
					currencySign = currency.getSign();
				}
			}

			if (invoice.getExchangecurrencyId() != null) {
				exchangeCurrency = currencyRepository.findOne(invoice.getExchangecurrencyId());
				if(exchangeCurrency!=null){
				exchangeCurrencyCode = exchangeCurrency.getCode();
				exchangeCurrencySign = exchangeCurrency.getSign();
				}
			}
			
			if (invoice.getInvoiceType() != null) {
				invoiceType = invoice.getInvoiceType();
				map.put("type", invoiceType);
			}

			if (invoice.getProjectId() != null) {
				invoiceInfo = invoiceInfoRepository.findByProjectId(invoice.getProjectId());
				if (invoiceInfo != null) {
					if (invoiceInfo.getBillingGSTNo() != null) {
						map.put("gstNo", invoiceInfo.getBillingGSTNo());
					}

					if (invoiceInfo.getBillingAddress() != null) {
						map.put("clientAddress", invoiceInfo.getBillingAddress());
					}
					if (invoiceInfo.getShippingAddress() != null) {
						map.put("clientShippingAddress", invoiceInfo.getShippingAddress());
					}

					if (invoiceInfo.getBillingGSTNo() != null) {
						map.put("bGSTNo", invoiceInfo.getBillingGSTNo());
					}
					if (invoiceInfo.getShippingGSTNo() != null) {
						map.put("shippingGSTNo", invoiceInfo.getShippingGSTNo());
					}

					if (invoiceInfo.getBankDetailsId() != null) {
						bankDetails = bankDetail.findOne(invoiceInfo.getBankDetailsId());
						if (bankDetails != null) {
							if (bankDetails.getBankName() != null) {
								map.put("bankName", bankDetails.getBankName());
							}

							if (bankDetails.getBankAccountNo() != null) {
								map.put("bankAccountNo", String.valueOf(bankDetails.getBankAccountNo()));
							}

							if (bankDetails.getBankAddress() != null) {
								map.put("bankAddress", bankDetails.getBankAddress());
							}

							if (bankDetails.getRoutingNo() != null) {
								map.put("routingNo", bankDetails.getRoutingNo().toString());
							}
							if (bankDetails.getBeneficiaryName() != null) {
								map.put("beneficiaryName", bankDetails.getBeneficiaryName());
							}

							if (bankDetails.getSwiftCode() != null) {
								map.put("swiftCode", bankDetails.getSwiftCode());
							}
							
							if (bankDetails.getIfscCode() != null) {
								map.put("ifscCode", bankDetails.getIfscCode());
							}

							if (bankDetails.getBankType() != null) {
								bankType = bankDetails.getBankType();
							}
						}
					}

					if (invoiceInfo.getBillingstateId() != null) {
						state = stateRepository.findOne(invoiceInfo.getBillingstateId());
						if (state != null) {
							if (state.getStateName() != null) {
								map.put("bstate", state.getStateName());
							}
							if (state.getStateCode() != null) {
								map.put("bstateCode", state.getStateCode());
							}
						}
					}
					if (invoiceInfo.getShippingstateId() != null) {
						shippingState = stateRepository.findOne(invoiceInfo.getShippingstateId());
						if (shippingState != null) {
							if (shippingState.getStateId() != null) {
								map.put("shippingState", shippingState.getStateName());
							}
							if (shippingState.getStateCode() != null) {
								map.put("shippingStateCode", shippingState.getStateCode());
							}
						}
					}

					if (invoiceInfo.getBillingcountryId() != null) {
						country = countryRepository.findOne(invoiceInfo.getBillingcountryId());
						if(country!=null){
							if (country.getCountryName() != null) {
								map.put("bcountry", country.getCountryName());
								if(invoiceType.equals("Internal Invoice")){
									map.put("bstate", country.getCountryName());
								}	
							}							
						}
					}
					
					if (invoiceInfo.getShippingcountryId() != null) {
						shippingCountry = countryRepository.findOne(invoiceInfo.getShippingcountryId());
						if(shippingCountry!=null){
							if (shippingCountry.getCountryName() != null) {
								map.put("shippingCountry", shippingCountry.getCountryName());
								if(invoiceType.equals("Internal Invoice")){
									map.put("shippingState", shippingCountry.getCountryName());
								}	
								
							}							
						}
					}
					
					if(invoiceInfo.getPanNo()!=null) {
						map.put("cpan", invoiceInfo.getPanNo());
					}
				}
			}



			if (invoice.getTypeSupply() != null) {
				map.put("supplyType", invoice.getTypeSupply());
			}

			if (invoice.getAccountName() != null) {
				map.put("name", invoice.getAccountName());
			}

			if (invoice.getFinalInvoiceNo() != null) {
				map.put("invoiceNo", invoice.getFinalInvoiceNo());				
			} else if (invoice.getInvoiceNo() != null) {
				map.put("invoiceNo", invoice.getInvoiceNo());
			}

			if (invoice.getArInvoiceDate() != null) {
				map.put("invoiceDate", DateConverter.changeDate2(invoice.getArInvoiceDate()));
			}

			if (invoice.getClientPm() != null) {
				map.put("cpm", invoice.getClientPm());
			}

			if (invoice.getNetSubTotal() != null) {
				netSubTotal = invoice.getNetSubTotal();
				map.put("netSubTotal", invoice.getNetSubTotal().toString());
			}

			if (invoice.getSubtotal() != null) {
				subTotal = invoice.getSubtotal();
				map.put("subTotal", invoice.getSubtotal().toString());
			}

			if (invoice.getFlatDiscountPer() != null) {
				discountPercent = invoice.getFlatDiscountPer();
				map.put("flatDiscountPer", discountPercent.toString());
			}

			if (invoice.getDiscountAmt() != null) {
				dicountAmount = invoice.getDiscountAmt();
			}

			if (invoice.getDiscountAmt() != null) {
				map.put("DiscountAmt", invoice.getDiscountAmt().toString());
			}

			if (invoice.getTotal() != null) {
				map.put("total", invoice.getTotal().toString());
				total = invoice.getTotal();
			}
/*			if (invoice.getGstRegNo() != null) {
				map.put("GSTRegNo", invoice.getGstRegNo());
			}*/
			if (invoice.getClientPO() != null) {
				map.put("po", invoice.getClientPO());
			}

			if (invoice.getAmountInwords() != null) {
				map.put("amountInWord", invoice.getAmountInwords());
				amountInWord = invoice.getAmountInwords();
			}

			if (invoice.getExchangeRate() != null) {
				exchangeRate = invoice.getExchangeRate();
				map.put("exchangeRate", exchangeRate.toString());
			}

			if(invoiceType.equals("Credit Note") || invoiceType.equals("Debit Note")) {
				if(invoice.getInvoices() != null && invoice.getInvoices() != ""){
					map.put("originalInvoiceTitle", "Original Invoice");
					map.put("originalInvoiceNo", invoice.getInvoices());
					map.put("seprator", ":");
				}				
			}
			
			if (invoice.getCgst() != null) {
				cgst = invoice.getCgst();
			}

			if (invoice.getCgstAmt() != null) {
				cgstAmount = invoice.getCgstAmt();
			}

			if (invoice.getSgst() != null) {
				sgst = invoice.getSgst();
			}
			if (invoice.getSgstAmt() != null) {
				sgstAmount = invoice.getSgstAmt();
			}

			if (invoice.getUtgst() != null) {
				utgst = invoice.getUtgst();
			}
			if (invoice.getUtgstAmt() != null) {
				utgstAmount = invoice.getUtgstAmt();
			}
			
			if (invoice.getIgst() != null) {
				igst = invoice.getIgst();
			}
			if (invoice.getIgstAmt() != null) {
				igstAmount = invoice.getIgstAmt();
			}

			if (invoice.getSgdGst() != null) {
				sgdgst = invoice.getSgdGst();
			}
			if (invoice.getSgdGstAmt() != null) {
				sgdgstAmount = invoice.getSgdGstAmt();
			}

			if (invoice.getProjectId() != null) {
				project = manager.createNamedQuery("getProjectById", Project.class)
						.setParameter("itemId", invoice.getProjectId()).getSingleResult();
			}

			if (project != null) {
				if (invoice.getEndClientProjectId() != null){
					endClientbillingUnitId = endClientProjectId(invoice.getEndClientProjectId());
				}
				
				if(endClientbillingUnitId!=null){
					unit = unitRepository.findOne(endClientbillingUnitId);

					if(unit!=null){
						map.put("servicesClientName", unit.getUnitName());

					}
				}else{
					
					if (project.getAccountId() != null) {
						account = accountRepository.findOne(project.getAccountId());
						if (account != null) {
							String accountName[] = account.getTitle().split("-",2);
							if (accountName.length == 2) {
								map.put("servicesClientName", accountName[1]);
							}else {
								map.put("servicesClientName", account.getTitle());

							}
						}
					}
					
						if (invoice.getBillingAccountId() != null) {
							account = accountRepository.findOne(invoice.getBillingAccountId());
							if (account != null) {
								String accountName[] = account.getTitle().split("-",2);
								if (accountName.length == 2) {
									map.put("billingAccountName", accountName[1]);
								}else {
									map.put("billingAccountName", account.getTitle());
								}
							}
						}
						
						if (invoice.getShippingAccountId() != null) {
							account = accountRepository.findOne(invoice.getShippingAccountId());
							if (account != null) {
								String accountName[] = account.getTitle().split("-",2);
								if (accountName.length == 2) {
									map.put("shippingAccountName", accountName[1]);
								}else {
									map.put("shippingAccountName", account.getTitle());
								}								
							}							
						}
					
				}
				
				if (project.getTitle() != null) {
					map.put("projectName", project.getTitle());
					projectTitle = project.getTitle();
					
				}
				
				if (project.getBillingUnitId() != null) {
					
					billingUnitId = project.getBillingUnitId(); 
					unit = unitRepository.findOne(billingUnitId);
					if (unit != null) {
						if (unit.getUnitName() != null) {
							map.put("unitName", unit.getUnitName());
						}

						if (unit.getAddress() != null) {
							map.put("unitAddress", unit.getAddress());
						}

						if (unit.getCin() != null) {
							map.put("unitCIN", unit.getCin());
						}

						if (unit.getIecCode() != null) {
							map.put("unitIEC", unit.getIecCode().toString());
						}

						if (unit.getPan() != null) {
							map.put("unitPAN", unit.getPan());
						}

						if (unit.getEmail() != null) {
							map.put("unitEmail", unit.getEmail());
						}

						if (unit.getPhoneNo() != null) {
							map.put("unitPhone", unit.getPhoneNo());
						}

						if (unit.getIsp() != null) {
							map.put("unitIsp", unit.getIsp());
						}
						
						if (unit.getGstNo() != null){
							map.put("unitGstNo", unit.getGstNo());
						}
						if(unit.getLutNo()!=null) {
							map.put("lutNo", unit.getLutNo());							
						}

						if (unit.getStateId() != null) {
							state = stateRepository.findOne(unit.getStateId());
							if (state != null) {
								if (state.getStateName() != null) {
									map.put("state", state.getStateName());
								}

								if (state.getStateCode() != null) {
									map.put("stateCode", state.getStateCode());
								}
							}
						}
					}
				}

				if (project.getAccountName() != null) {
					map.put("clientName", project.getAccountName());
				}



				if (project.getOwnerName() != null) {
					map.put("dm", project.getOwnerName());
				}

				if (project.getPmName() != null) {
					map.put("pm", project.getPmName());
				}

				if (project.getRmName() != null) {
					map.put("rm", project.getRmName());
				}
			}

		}
		
		Iterator<InvoicesDetail> it = invoicesDetails.iterator();
		Iterator<InvoicesDetail> billingDet = invoicesDetails.iterator();
		StringBuilder buf = new StringBuilder();

		/* T&M code start */
		if (invoice.getProjectId() != null) {
			List<ProjectTerms> projectTermlist = projectTerms.findByProjectId(invoice.getProjectId());
			if (projectTermlist != null) {
				StringBuilder termsValue = new StringBuilder();
				termsValue.append("<span>");
				Iterator<ProjectTerms> val = projectTermlist.iterator();
				while (val.hasNext()) {
					ProjectTerms projectTerms = val.next();
					if (projectTerms.getTermCondition().getTermId() != null) {
						List<TermCondition> termconditionlist = repository
								.findByTermId(projectTerms.getTermCondition().getTermId());
						Iterator<TermCondition> iterms = termconditionlist.iterator();
						while (iterms.hasNext()) {
							TermCondition termCondition = iterms.next();
							String termsName = termCondition.getTerms();

							termsValue.append("<li style='margin:bottom:0px !important'>").append(termsName)
									.append("</li>");
						}
					}
				}
				termsValue.append("</span>");
				String terms = termsValue.toString();
				map.put("terms", terms);
			}
		}
		
		
		
		/* T&M code end */
		if (billingUnitId == 1 || billingUnitId == 4 || billingUnitId == 21 || billingUnitId == 22) {
			BigDecimal inialtialSubTotalAmount = BigDecimal.ZERO;
			BigDecimal iniatialDiscountAmount = BigDecimal.ZERO;
			BigDecimal inialtialNetSubTotalAmount = BigDecimal.ZERO;
			if (invoiceType.equals("Services Invoice") || invoiceType.equals("Internal Invoice") || invoiceType.equals("License Invoice")  || invoiceType.equals("Credit Note") || invoiceType.equals("Debit Note")) {
				
				billingDetail.append("<table name='date-table' style='width:99.7%'  cellpadding='0' cellspacing='0'>"
						+ "<thead>" + "<tr>"
						+ "<td colspan='9' style='border-top:solid gray 1.0pt;border-left:solid gray 1.0pt; border-bottom:none;border-right:none;  background:#0065A4;padding:0cm 0cm 0cm 0cm'>"
						+ "<p style='margin:0px !important; font-size:9pt' align='center' ><b><span style='font-size:9.0pt;color:#FFFFFF'>Billing Summary</span></b></p>"
						+ "</td>" + "</tr>" + "</thead>" + "<tr>"
						+ "<td class='gridHeaderRow' align='center'><p style='margin:0px !important; width:100px'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Role&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p></td>");
				if(invoiceInfo.getReplaceAssociateNameWithRoleTitle()==null || invoiceInfo.getReplaceAssociateNameWithRoleTitle()==false) {
					billingDetail.append("<td class='gridHeaderRow' align='center'><p style='margin:0px !important; width:100px;'>&nbsp;&nbsp;&nbsp;&nbsp;Associate&nbsp;Name&nbsp;&nbsp;&nbsp;&nbsp;</p></td>");
				}

				billingDetail.append("<td class='gridHeaderRow' align='center' colspan='2'><p style='margin:0px !important; width:150px !important;'>Period</p>"
						+ "<table style='width:100%'><tr>"
						+ "<td class='fromPeriodColumn' style='width: 50%;'><p style='margin:0px !important;'>From</p></td>"
						+ "<td class='toPeriodColumn'><p style='margin:0px !important;'>To</p></td>"
						+ "</tr></table>" + "</td>"
						+ "<td class='gridHeaderRow' align='center' width='10%'><p style='margin:0px !important; width:100px;'>&nbsp;&nbsp;Rate&nbsp;&nbsp;<br/>&nbsp;&nbsp;&nbsp;&nbsp;(In&nbsp;"+currencyCode+")&nbsp;&nbsp;&nbsp;&nbsp;</p></td>"
						+ "<td class='gridHeaderRow' align='center' width='10%'><p style='margin:0px !important; width:100px'>&nbsp;&nbsp;&nbsp;Quantity&nbsp;&nbsp;&nbsp; <br/>&nbsp;(In&nbsp;Day)&nbsp;&nbsp;&nbsp;</p></td>"
						+ "<td class='gridHeaderRow' align='center' width='10%'><p style='margin:0px !important; width:100px'>&nbsp;&nbsp;&nbsp;Billed&nbsp;Amount&nbsp;&nbsp;&nbsp;<br/>(In&nbsp;"+currencyCode+")</p></td>");
				
				if (exchangeRate != BigDecimal.ZERO && exchangeRate != BigDecimal.ONE){
				billingDetail.append("<td class='gridHeaderRow' align='center' width='10%'><p style='margin:0px !important; width:100px'>&nbsp;&nbsp;&nbsp;Exchange&nbsp;Rate&nbsp;&nbsp;&nbsp;</p></td>"
						+ "<td class='gridHeaderRow' align='center' width='10%'><p style='margin:0px !important; width:100px'>&nbsp;&nbsp;&nbsp;Billed&nbsp;Amount&nbsp;&nbsp;&nbsp;<br/>(In&nbsp;"+exchangeCurrencyCode+")</p></td>"							
						+ "</tr>");
				
				}
				
			BigDecimal quantityTotal = BigDecimal.ZERO;

			while (billingDet.hasNext()) {
				InvoicesDetail invoicesDetail = billingDet.next();
				if (invoicesDetail.getResNameMilestone() != null) {
					resourceName = invoicesDetail.getResNameMilestone();
				}
				
				if (invoicesDetail.getInfoCeptsRole() != null) {
					role = invoicesDetail.getInfoCeptsRole();
				}

				if (invoicesDetail.getClientRole() != null) {
					clientRole = invoicesDetail.getClientRole();
				}

				
				if (invoice.getPeriodStartDate() != null) {
					sDate = DateConverter.changeDate2(invoice.getPeriodStartDate());
				}

				if (invoice.getPeriodEndDate() != null) {
					eDate = DateConverter.changeDate2(invoice.getPeriodEndDate());
				}

				if (invoicesDetail.getBillableRate() != null) {
					billableRate = invoicesDetail.getBillableRate();
				}

				if (invoicesDetail.getSowNo() != null) {
					map.put("sowNo", invoicesDetail.getSowNo());
				}

				if (invoicesDetail.getTsHrs() != null) {
					tsHrs = invoicesDetail.getTsHrs();
					quantityTotal = quantityTotal.add(tsHrs);
				}
				
				if(invoicesDetail.getInitialBilledAmount()!=null) {
					iniatialAmount = invoicesDetail.getInitialBilledAmount();
				}
				
				if (invoicesDetail.getAmount() != null) {
					amount = invoicesDetail.getAmount();
				}

				billingDetail.append("<tr>");
				if(invoiceInfo.getReplaceAssociateNameWithRoleTitle()!=null && invoiceInfo.getReplaceAssociateNameWithRoleTitle()==true) {
					billingDetail.append("<td class='pnTrData'><p style='margin:0px !important'>").append(clientRole);
				}else{
					billingDetail.append("<td class='pnTrData'><p style='margin:0px !important'>").append(role)
					.append("</p></td><td class='trData'><p style='margin:0px !important'>")
					.append(resourceName);
				}
							
				billingDetail.append("</p></td><td class='trData' style='width:50%'><p style='margin:0px !important'>")
						.append(sDate)
						.append("</p></td><td class='trData' style='width:50%'><p style='margin:0px !important'>")
						.append(eDate).append("</p></td><td class='trRateData'><p style='margin:0px !important'>")
						.append(numberToCurrencyConverter(billableRate)+"</p>")
						.append("</td><td class='trData'><p style='margin:0px !important'>"+tsHrs+"</p>")
						.append("</td><td class='trBillAmt'><p style='margin:0px !important'>").append(numberToCurrencyConverter(iniatialAmount)+"</p></td>");
				iniatialTotal =  iniatialTotal.add(iniatialAmount);

				if (exchangeRate != BigDecimal.ZERO && exchangeRate != BigDecimal.ONE){
				billingDetail.append("<td class='trBillAmt'><p style='margin:0px !important;'>"+exchangeRate+"</p></td>")
				.append("<td class='trBillAmt'><p style='margin:0px !important;'>"+numberToCurrencyConverter(amount)+"</p></td>");
				}
			}
			if (invoice.getTotal() != null) {
				subTotal = invoice.getSubtotal();
			}
			billingDetail.append("</tr>");
			
			if(invoiceInfo.getReplaceAssociateNameWithRoleTitle()==null || invoiceInfo.getReplaceAssociateNameWithRoleTitle()==false) {
				billingDetail.append("<tr><td colspan='5' class='footerTotalBorder' style='border-left:1px solid #808080;'><p style='margin-bottom:0px !important;text-align:center;'>Total&nbsp;&nbsp;&nbsp;</p></td><td class='emptyTotalFooterBorder'><p style='text-align:center;margin-bottom:0px !important'>");
			}else {
				billingDetail.append("<tr><td colspan='4' class='footerTotalBorder' style='border-left:1px solid #808080;'><p style='margin-bottom:0px !important;text-align:center;'>Total&nbsp;&nbsp;&nbsp;</p></td><td class='emptyTotalFooterBorder'><p style='text-align:center;margin-bottom:0px !important'>");
			}
					
				billingDetail.append(quantityTotal).append("</p></td>")
					.append("<td class='trTotalFooterBackGround'>")
					.append("<p style='margin-bottom:0px !important'>"+numberToCurrencyConverter(iniatialTotal)+"</p></td>");
			
			if (exchangeRate != BigDecimal.ZERO && exchangeRate != BigDecimal.ONE){
			billingDetail.append("<td class='trTotalFooterBackGround'></td>"
					+ "<td class='trTotalFooterBackGround'><p style='margin:0px !important; width:100px'>"+numberToCurrencyConverter(subTotal)+"</p></td>");
			}				
			
			billingDetail.append("</tr></table>");
			String billableInvoiceDetail = billingDetail.toString();
			map.put("billableInvoiceDetail", billableInvoiceDetail);
				
				if (billing.equals("Fixed Bid Milestone")) {
					if (exchangeRate != BigDecimal.ZERO && exchangeRate != BigDecimal.ONE) {
						inialtialSubTotalAmount = subTotal.divide(exchangeRate,RoundingMode.HALF_UP);
						if (discountPercent != BigDecimal.ZERO) {
							iniatialDiscountAmount = inialtialSubTotalAmount.multiply(discountPercent) .divide(new BigDecimal(100)).setScale(0, BigDecimal.ROUND_HALF_UP);
							inialtialNetSubTotalAmount = inialtialSubTotalAmount.subtract(iniatialDiscountAmount).setScale(0, BigDecimal.ROUND_HALF_UP);
						}else {
							inialtialNetSubTotalAmount = inialtialSubTotalAmount.setScale(0, BigDecimal.ROUND_HALF_UP);
						}
						itplFBBillingDetail.append("<table  border='0' cellspacing='0' cellpadding='0' style='width:99.7%;'><thead><tr>"
										+ "<td width='7%'  style='width:7.0%;border:solid gray 1.0pt;background:#0065A4;'> <p style='margin:0px !important; font-size:9pt;color:#FFFFFF' align='center' ><b><span style='font-size:9.0pt;'>Sr&nbsp;No </span></b></p> </td>"
										+ "<td width='40%' style='width:40.0%;border:solid gray 1.0pt;background:#0065A4;'> <p style='margin:0px !important; font-size:9pt;color:#FFFFFF' align='center' ><b><span style='font-size:9.0pt;'>Description of Services</span></b></p> </td>"
										+ "<td width='20%' style='width:20.0%;border:solid gray 1.0pt;background:#0065A4;'> <p style='margin:0px !important; font-size:9pt;color:#FFFFFF' align='center' ><b><span style='font-size:9.0pt;'>Service Billing Details</span></b></p> </td>"
										+ "<td width='18%' style='width:18.0%;border:solid gray 1.0pt;background:#0065A4;'> <p style='margin:0px !important; font-size:9pt;color:#FFFFFF' align='center' ><b><span style='font-size:9.0pt;'>Services Accounting Code</span></b></p> </td>"
										+ "<td width='15%' style='width:15.0%;border:solid gray 1.0pt;background:#0065A4;'> <p style='margin:0px !important; font-size:9pt;color:#FFFFFF' align='center' ><b><span style='font-size:9.0pt;'>Billed Amount ("
										+ currencyCode + ")</span></b></p> </td>"
										+ "<td width='15%' style='width:15.0%;border:solid gray 1.0pt;background:#0065A4;'> <p style='margin:0px !important; font-size:9pt;color:#FFFFFF' align='center' ><b><span style='font-size:9.0pt;'>Exchange Rate</span></b></p> </td>"
										+ "<td width='15%' style='width:15.0%;border:solid gray 1.0pt;background:#0065A4;'> <p style='margin:0px !important; font-size:9pt;color:#FFFFFF' align='center' ><b><span style='font-size:9.0pt;'>Billed Amount ("
										+ exchangeCurrencyCode + ")</span></b></p> </td>" + "</tr> </thead>");
						itplFBBillingDetail.append("<tr>"
								+ "<td width='80' style='width:60.0pt;border-top:none;border-left:solid gray 1.0pt; border-bottom:solid gray 1.0pt;border-right:none; padding:1.5pt 1.5pt 1.5pt 1.5pt'><p style='margin:0px !important; font-size:9pt' align='center' ><span style='font-size:9.0pt;color:#555555'>1</span></p> </td>");
								
						if(invoiceType.equals("License Invoice")) {
							itplFBBillingDetail.append("<td width='80' style='width:60.0pt;border-top:none;border-left:solid gray 1.0pt; border-bottom:solid gray 1.0pt;border-right:none; padding:1.5pt 1.5pt 1.5pt 1.5pt'> <p style='margin:0px !important; font-size:9pt' align='center' ><span style='font-size:9.0pt;color:#555555'>Licensing services for the right to use computer software and databases</span></p> </td>");							
						}else {
							itplFBBillingDetail.append("<td width='80' style='width:60.0pt;border-top:none;border-left:solid gray 1.0pt; border-bottom:solid gray 1.0pt;border-right:none; padding:1.5pt 1.5pt 1.5pt 1.5pt'> <p style='margin:0px !important; font-size:9pt' align='center' ><span style='font-size:9.0pt;color:#555555'>Information technology (IT) design and development services</span></p> </td>");							
						}
								
						itplFBBillingDetail.append("<td width='80' style='width:60.0pt;border-top:none;border-left:solid gray 1.0pt; border-bottom:solid gray 1.0pt;border-right:none; padding:1.5pt 1.5pt 1.5pt 1.5pt'> <p style='margin:0px !important; font-size:9pt' align='center' ><span style='font-size:9.0pt;color:#555555'>As per Annexure-I</span></p> </td>");
						
						if(invoiceType.equals("License Invoice")) {
							itplFBBillingDetail.append("<td width='90' style='width:67.5pt;border-top:none;border-left:solid gray 1.0pt; border-bottom:solid gray 1.0pt;border-right:none; padding:1.5pt 1.5pt 1.5pt 1.5pt'> <p style='margin:0px !important; font-size:9pt' align='right' ><span style='font-size:9.0pt;color:#555555'>997331</span></p> </td>");
						}else{
							itplFBBillingDetail.append("<td width='90' style='width:67.5pt;border-top:none;border-left:solid gray 1.0pt; border-bottom:solid gray 1.0pt;border-right:none; padding:1.5pt 1.5pt 1.5pt 1.5pt'> <p style='margin:0px !important; font-size:9pt' align='right' ><span style='font-size:9.0pt;color:#555555'>998314</span></p> </td>");
						}		
						itplFBBillingDetail.append("<td width='90' style='width:67.5pt;border-top:none;border-left:solid gray 1.0pt; border-bottom:solid gray 1.0pt;border-right:none; padding:1.5pt 1.5pt 1.5pt 1.5pt'> <p style='margin:0px !important; font-size:9pt' align='right' ><span style='font-size:9.0pt;color:#555555'>"
								+ numberToCurrencyConverter(inialtialSubTotalAmount) + "</span></p></td>"
								+ "<td width='90' style='width:67.5pt;border-top:none;border-left:solid gray 1.0pt; border-bottom:solid gray 1.0pt;border-right:none; padding:1.5pt 1.5pt 1.5pt 1.5pt'> <p style='margin:0px !important; font-size:9pt' align='right' ><span style='font-size:9.0pt;color:#555555'>"
								+ exchangeRate + "</span></p></td>"
								+ "<td width='100' style='width:75.0pt;border:solid gray 1.0pt;border-top:none;  padding:1.5pt 1.5pt 1.5pt 1.5pt'>  <p style='margin:0px !important; font-size:9pt' align='right'><span style='font-size:9.0pt;color:#555555'>"
								+ numberToCurrencyConverter(subTotal) + "</span></p> </td></tr>");
						itplFBBillingDetail.append("<tr> "
								+ "<td style='border-top:none;border-left:solid gray 1.0pt;border-bottom:solid gray 1.0pt; border-right:none;padding:1.5pt 1.5pt 1.5pt 1.5pt'>  <p style='margin:0px !important; font-size:9pt' align='center' ><span style='font-size:9.0pt;color:#555555'>2</span></p> </td>"
								+ "<td colspan='3' style='border-top:none;border-left:solid gray 1.0pt; border-bottom:solid gray 1.0pt;border-right:none; padding:1.5pt 1.5pt 1.5pt 1.5pt'>  <p style='margin:0px !important; font-size:9pt' align='center' ><span style='font-size:9.0pt;color:#555555'>Discount Allowed @ "
								+ discountPercent + "%</span></p> </td>"
								+ "<td width='90' style='width:67.5pt;border-top:none;border-left:solid gray 1.0pt; border-bottom:solid gray 1.0pt;border-right:none; padding:1.5pt 1.5pt 1.5pt 1.5pt'> <p style='margin:0px !important; font-size:9pt' align='right' ><span style='font-size:9.0pt;color:#555555'>"
								+ numberToCurrencyConverter(iniatialDiscountAmount) + "</span></p> </td>"
								+ "<td style='border-top:none;border-left:solid gray 1.0pt;border-bottom:solid gray 1.0pt; border-right:none;padding:1.5pt 1.5pt 1.5pt 1.5pt'></td>"
								+ "<td style='border:solid gray 1.0pt;border-top:none;padding:1.5pt 1.5pt 1.5pt 1.5pt'> <p style='margin:0px !important; font-size:9pt' align='right' ><span style='font-size:9.0pt;color:#555555'>"
								+ numberToCurrencyConverter(dicountAmount) + "</span></p> </td></tr>");
						itplFBBillingDetail.append("<tr>"
								+ "<td colspan='4' style='border-top:none;border-left:solid gray 1.0pt; border-bottom:solid gray 1.0pt;border-right:none; padding:2.25pt 2.25pt 2.25pt 2.25pt'> <p style='margin:0px !important; font-size:9pt'><b><span style='font-size:9.0pt;color:#555555'>Taxable Value of Supply of Services</span></b></p> </td>"
								+ "<td style='border-top:none;border-left:solid gray 1.0pt;border-bottom:solid gray 1.0pt; border-right:none;padding:2.25pt 2.25pt 2.25pt 2.25pt'><p style='margin:0px !important; font-size:9pt' align='right' ><b><span style='font-size:9.0pt;color:#555555'>"
								+ inialtialNetSubTotalAmount + "</span></b></p> </td>"
								+ "<td style='border-top:none;border-left:solid gray 1.0pt;border-bottom:solid gray 1.0pt; border-right:none;padding:2.25pt 2.25pt 2.25pt 2.25pt'></td>"
								+ "<td style='border:solid gray 1.0pt;border-top:none;padding:2.25pt 2.25pt 2.25pt 2.25pt'> <p style='margin:0px !important; font-size:9pt' align='right' ><b><span style='font-size:9.0pt;color:#555555'>"
								+ numberToCurrencyConverter(netSubTotal) + "</span></b></p> </td></tr>" + "</table>");
						String itplFBBillingDetails = itplFBBillingDetail.toString();
						map.put("itplFBBillableInvoiceDetail", itplFBBillingDetails);

						itplFBGSTCalculation
								.append("<table  border='0' cellspacing='0' cellpadding='0' width='99%' style='width:707px;border-collapse:collapse;'>"
										+ "<tr>"
										+ "<td style='width:40%;border:solid gray 1.0pt;  padding:.75pt .75pt .75pt 3.75pt'> <p style='margin:0px !important; font-size:9pt'><span style='font-size:9.0pt;color:#555555'>Output GST Calculation</span></p> </td>"
										+ "<td style='width:60%;border:solid gray 1.0pt; padding: 0pt .75pt .75pt 0pt;'>");
						itplFBGSTCalculation
								.append("<table  border='0' cellspacing='0' cellpadding='0' width='99%' style='width:100%;border-collapse:collapse;'><tr>"
										+ "<td style='width:18.0%;border:solid gray 1.0pt;border-left: none;border-top: none; padding:.75pt .75pt .75pt 3.75pt'> <p style='margin:0px !important; font-size:9pt'><span style='font-size:9.0pt;color:#555555'>GST to be levied</span></p> </td>"
										+ "<td style='width:15.0%;border:solid gray 1.0pt;border-left: none;border-top: none; padding:.75pt .75pt .75pt 3.75pt'> <p style='margin:0px !important; font-size:9pt'><span style='font-size:9.0pt;color:#555555'>Rate of Tax</span></p> </td>"
										+ "<td style='width:15.0%;border:solid gray 1.0pt;border-left: none;border-top: none; padding:.75pt .75pt .75pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='center' ><span style='font-size:9.0pt;color:#555555'>Amount</span></p> </td>"
										+ "<td style='width:12.0%;border:solid gray 1.0pt;border-left: none;border-top: none; padding:.75pt .75pt .75pt 3.75pt'> <p style='margin:0px !important; font-size:9pt'><span style='font-size:9.0pt;color:#555555'></span></p> </td>"
										+ "<td style='width:15.0%;border:solid gray 1.0pt;border-right: none;border-top: none; padding:.75pt .75pt .75pt 3.75pt'> <p style='margin:0px !important; font-size:9pt'><span style='font-size:9.0pt;color:#555555'>Amount</span></p> </td>"
										+ "</tr>");

						Integer count = 0;
						if (cgst.compareTo(BigDecimal.ZERO) > 0) {
							count = 1;
							iniatialCgstAmount = inialtialNetSubTotalAmount.multiply(cgst).divide(new BigDecimal(100)).setScale(0, BigDecimal.ROUND_HALF_UP);
							itplFBGSTCalculation
									.append("<tr> <td width='80' style='width:60.0pt;border-top:none;border-left:none; border-right:solid gray 1.0pt;padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='center' ><span>CGST</span></p> </td>"
											+ "<td width='80' style='width:60.0pt;border-top:none;border-left:none; border-right:solid gray 1.0pt;padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='center' >"
											+ cgst + "%</p> </td>"
											+ "<td width='90' style='width:67.5pt;border-top:none;border-left:none; border-right: none;padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='right' >"
											+ numberToCurrencyConverter(iniatialCgstAmount) + "</p> </td> "
											+ "<td width='90' style='width:67.5pt;border-right:solid gray 1.0pt;border-left:solid gray 1.0pt;border-top:none;padding:1.5pt 1.5pt 1.5pt 3.75pt'> </td>"
											+ "<td width='90' style='width:67.5pt;border-top:none;border-left:none; padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='right' >"
											+ numberToCurrencyConverter(cgstAmount) + "</p> </td>" + "</tr>");
						}
						if (sgst.compareTo(BigDecimal.ZERO) > 0) {
							count = 1;
							iniatialSgstAmount = inialtialNetSubTotalAmount.multiply(sgst).divide(new BigDecimal(100)).setScale(0, BigDecimal.ROUND_HALF_UP);
							itplFBGSTCalculation
									.append("<tr> <td width='80' style='width:60.0pt;border-top:none;border-left:none; border-right:solid gray 1.0pt;padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='center' ><span>SGST</span></p> </td>"
											+ "<td width='80' style='width:60.0pt;border-top:none;border-left:none; border-right:solid gray 1.0pt;padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='center' >"
											+ sgst + "%</p> </td>"
											+ "<td width='90' style='width:67.5pt;border-top:none;border-left:none; border-right: none;padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='right' >"
											+ numberToCurrencyConverter(iniatialSgstAmount) + "</p> </td> "
											+ "<td width='90' style='width:67.5pt;border-right:solid gray 1.0pt;border-left:solid gray 1.0pt;border-top:none;padding:1.5pt 1.5pt 1.5pt 3.75pt'> </td>"
											+ "<td width='90' style='width:67.5pt;border-top:none;border-left:none; padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='right' >"
											+ numberToCurrencyConverter(sgstAmount) + "</p> </td>" + "</tr>");
						}
						if (igst.compareTo(BigDecimal.ZERO) > 0) {
							count = 1;
							iniatialIgstAmount = inialtialNetSubTotalAmount.multiply(igst).divide(new BigDecimal(100)).setScale(0, BigDecimal.ROUND_HALF_UP);
							
							itplFBGSTCalculation
									.append("<tr> <td width='80' style='width:60.0pt;border-top:none;border-left:none; border-right:solid gray 1.0pt;padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='center' ><span>IGST</span></p> </td>"
											+ "<td width='80' style='width:60.0pt;border-top:none;border-left:none; border-right:solid gray 1.0pt;padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='center' >"
											+ igst + "%</p> </td>"
											+ "<td width='90' style='width:67.5pt;border-top:none;border-left:none; border-right: none;padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='right' >"
											+ numberToCurrencyConverter(iniatialIgstAmount) + "</p> </td> "
											+ "<td width='90' style='width:67.5pt;border-right:solid gray 1.0pt;border-left:solid gray 1.0pt;border-top:none;padding:1.5pt 1.5pt 1.5pt 3.75pt'> </td>"
											+ "<td width='90' style='width:67.5pt;border-top:none;border-left:none; padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='right' >"
											+ numberToCurrencyConverter(igstAmount) + "</p> </td>" + "</tr>");
						}
						if (utgst.compareTo(BigDecimal.ZERO) > 0) {
							count = 1;
							iniatialUtgstAmount = inialtialNetSubTotalAmount.multiply(utgst).divide(new BigDecimal(100)).setScale(0, BigDecimal.ROUND_HALF_UP);;
							itplFBGSTCalculation
									.append("<tr> <td width='80' style='width:60.0pt;border-top:none;border-left:none; border-right:solid gray 1.0pt;padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='center' ><span>UTGST</span></p> </td>"
											+ "<td width='80' style='width:60.0pt;border-top:none;border-left:none; border-right:solid gray 1.0pt;padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='center' >"
											+ utgst + "%</p> </td>"
											+ "<td width='90' style='width:67.5pt;border-top:none;border-left:none; border-right: none;padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='right' >"
											+ numberToCurrencyConverter(iniatialUtgstAmount) + "</p> </td> "
											+ "<td width='90' style='width:67.5pt;border-right:solid gray 1.0pt;border-left:solid gray 1.0pt;border-top:none;padding:1.5pt 1.5pt 1.5pt 3.75pt'> </td>"
											+ "<td width='90' style='width:67.5pt;border-top:none;border-left:none; padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='right' >"
											+ numberToCurrencyConverter(utgstAmount) + "</p> </td>" + "</tr>");
						}
						 iniatialAmount = iniatialIgstAmount.add(iniatialSgstAmount).add(iniatialCgstAmount).add(iniatialUtgstAmount).add(inialtialNetSubTotalAmount);

						if (count == 0) {
							itplFBGSTCalculation
									.append("<tr> <td width='80' style='width:60.0pt;border-top:none;border-left:none; border-right:solid gray 1.0pt;padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='center' ><span>Zero Rated Supply</span></p> </td>"
											+ "<td width='80' style='width:60.0pt;border-top:none;border-left:none; border-right:solid gray 1.0pt;padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='center' ><span>0</span></p> </td>"
											+ "<td width='90' style='width:67.5pt;border-top:none;border-left:none; border-right: none;padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='right' ><span>0</span></p> </td> "
											+ "<td width='90' style='width:67.5pt;border-right:solid gray 1.0pt;border-left:solid gray 1.0pt;border-top:none;padding:1.5pt 1.5pt 1.5pt 3.75pt'> </td>"
											+ "<td width='90' style='width:67.5pt;border-top:none;border-left:none; padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='right' >0</p> </td>"
											+ "</tr>");
						}
						itplFBGSTCalculation.append("</table></td></tr>" + "<tr>"
								+ "<td style='width:35%;border:solid gray 1.0pt;  vertical-align: text-bottom; padding:0px!important;'> <p style='margin:0px !important; font-size:9pt'><span style='font-size:9.0pt;color:#555555'><b>Total Value of Supply of Services (In Figure)</b></span></p> </td>"
								+ "<td style='width:65%;border:solid gray 1.0pt;'>");
						itplFBGSTCalculation
								.append("<table  border='0' cellspacing='0' cellpadding='0' width='99%' style='width:100%;border-collapse:collapse;'><tr>"
										+ "<td style='width:18.0%;border: none;border-top: 0; padding:.75pt .75pt .75pt 3.75pt'> <p style='margin:0px !important; font-size:9pt'><span style='font-size:9.0pt;color:#555555'></span></p> </td>"
										+ "<td style='width:15.0%;border-right:solid gray 1.0pt;border-left: none;border-top: 0; padding:.75pt .75pt .75pt 3.75pt'> <p style='margin:0px !important; font-size:9pt'><span style='font-size:9.0pt;color:#555555'></span></p> </td>"
										+ "<td style='width:15.0%;border-right:solid gray 1.0pt;  padding:.75pt .75pt .75pt 3.75pt'> <p style='margin:0px !important; text-align:right; font-size:9pt' align='center' ><span style='font-size:9.0pt;color:#555555'>"
										+ numberToCurrencyConverter(iniatialAmount) + "</span></p> </td>"
										+ "<td style='width:12.0%;border-right:solid gray 1.0pt;padding:.75pt .75pt .75pt 3.75pt'> <p style='margin:0px !important; font-size:9pt'><span style='font-size:9.0pt;color:#555555'></span></p> </td>"
										+ "<td style='width:15.3%;text-align: right; padding:.75pt .75pt .75pt 3.75pt'> <p style='margin:0px !important; font-size:9pt'><span style='font-size:9.0pt;color:#555555'>"
										+ numberToCurrencyConverter(total) + "</span></p> </td>" + "</tr>");
						itplFBGSTCalculation.append("</table></td></tr>");
						itplFBGSTCalculation.append("<tr>"
								+ "<td style='border:solid gray 1.0pt;border-top:none;padding:2.25pt 2.25pt 2.25pt 3.75pt'> <p style='margin:0px !important; font-size:9pt'><b><span style='font-size:9.0pt;color:#555555'>Total Value of Supply of Services (In Words)</span></b></p> </td>"
								+ "<td style='border-top:none;border-left:none;border-bottom:solid gray 1.0pt; border-right:solid gray 1.0pt;padding:2.25pt 2.25pt 2.25pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='right' ><b>"
								+ amountInWord + "</b></p> </td>" + "</tr></table>");
						String itplFBGSTCalculations = itplFBGSTCalculation.toString();
						map.put("itplFBGSTCalculation", itplFBGSTCalculations);

						
						if(invoiceType.equals("License Invoice")) {
							itplFBMilestoneDetail.append("<table width='99%' style='width:99.7%;border-collapse:collapse;'><thead>"
										+ "<tr style='height:22.5pt'>"
										+ "<td style='width:75.0pt;border:solid gray 1.0pt;border-left: none;background:#0065A4;padding:0cm 0cm 0cm 0cm; height:22.5pt'> <p style='text-align:center'><b><span style='font-size:9.0pt;color:#FFFFFF;'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Description&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></b></p> </td> "
										+ "<td class='gridHeaderRow' align='center' colspan='2'><p style='margin:0px !important;width:150px !important;'>Period</p>"
										+ "<table style='width:100%'><tr>"
										+ "<td class='fromPeriodColumn' style='width: 50%;'><p style='margin:0px !important;' >From</p></td>"
										+ "<td class='toPeriodColumn'><p style='margin:0px !important;'>To</p></td>"
										+ "</tr></table></td>"
										+ "<td style='width:75.0pt;border:solid gray 1.0pt;border-left: none;background:#0065A4;padding:0cm 0cm 0cm 0cm; height:22.5pt'> <p style='text-align:center'><b><span style='font-size:9.0pt;color:#FFFFFF;'>&nbsp;Milestone&nbsp;Amount <br /> &nbsp;(In&nbsp;"+currencyCode+")</span></b></p> </td> "
										+ "<td style='width:75.0pt;border:solid gray 1.0pt;border-left: none;background:#0065A4;padding:0cm 0cm 0cm 0cm; height:22.5pt'> <p style='text-align:center'><b><span style='font-size:9.0pt;color:#FFFFFF;'>&nbsp;Exchange <br /> Rate</span></b></p> </td> "
										+ "<td style='width:75.0pt;border:solid gray 1.0pt;border-left: none;background:#0065A4;padding:0cm 0cm 0cm 0cm; height:22.5pt'> <p style='text-align:center'><b><span style='font-size:9.0pt;color:#FFFFFF;'>&nbsp;Billed&nbsp;Amount <br /> &nbsp;(In "+exchangeCurrencyCode+")</span></b></p> </td>"
										+ "</tr>" + "</thead>");
						while (it.hasNext()){
							InvoicesDetail invoicesDetail = it.next();
							if (invoicesDetail.getResNameMilestone() != null) {
								resourceName = invoicesDetail.getResNameMilestone();
							}
	
							if (invoicesDetail.getDescription() != null) {
								description = invoicesDetail.getDescription();
							}
	
							if (invoicesDetail.getAmount() != null) {
								amount = invoicesDetail.getAmount();
							}
	
							if (invoicesDetail.getInitialBilledAmount() != null) {
								iniatialBuildAmount = invoicesDetail.getInitialBilledAmount();
							}
	
							if (invoice.getExchangeRate() != null) {
								exchangeRate = invoice.getExchangeRate();
							}
							
							if (invoice.getPeriodStartDate() != null) {
								sDate = DateConverter.changeDate2(invoice.getPeriodStartDate());
							}

							if (invoice.getPeriodEndDate() != null) {
								eDate = DateConverter.changeDate2(invoice.getPeriodEndDate());
							}
	
							totalAmount = totalAmount.add(total);
							iniatialTotal = iniatialTotal.add(iniatialBuildAmount);
							itplFBMilestoneDetail.append("<tr>"
									+ "<td class='pnTrData' style='border-top:none;border-bottom:solid gray 1.0pt; border-right:solid gray 1.0pt;   padding:0cm 0cm 0cm 3.75pt'><p><span style='font-size:9.0pt; color:#555555'>"
									+ description + "</span></p></td>"
									+ "<td class='trData' style='width:50%'><p style='margin-bottom:0px !important'>"+sDate+"</p></td>"
									+ "<td class='trData' style='width:50%'><p style='margin:0px !important'>"+eDate+"</p></td>"
									+ "<td style='border-top:none;border-left:none;border-bottom:solid gray 1.0pt;  border-right:solid gray 1.0pt;   padding:0cm 3.75pt 0cm 3.75pt'><p   style='text-align:right'><span   style='font-size:9.0pt;color:#555555'>"
									+ iniatialBuildAmount + "</span></p></td>"
									+ "<td  style='width:75.0pt;border-top:none;border-left:none;   border-bottom:solid gray 1.0pt;border-right:solid gray 1.0pt;  padding:1.5pt 1.5pt 1.5pt 3.75pt'><p   style='text-align:right'><span  style='font-size:9.0pt;';color:#555555'>"
									+ exchangeRate + "</span></p></td>"
									+ "<td style='border-top:none;border-left:none;border-bottom:solid gray 1.0pt;   border-right:solid gray 1.0pt;padding:0cm 3.75pt 0cm 3.75pt'><p   style='text-align:right'><span style='font-size:9.0pt;';color:#555555'>"
									+ amount + "</span></p></td>" + "</tr>");
						}
						
						itplFBMilestoneDetail.append(
								"<tr>" + "<td colspan='3' style='border:solid gray 1.0pt;border-top:none;border-left:none;border-bottom:solid gray 1.0pt;border-right:solid gray 1.0pt;  padding:0cm 3.75pt 0cm 3.75pt'><p style='text-align:right'><span  style='font-size:9.0pt;color:#555555'>Total</span></p>"
										+ "</td>"
										+ "<td style='width:75.0pt;border-top:none;border-left:none;   border-bottom:solid gray 1.0pt;border-right:solid gray 1.0pt;  padding:1.5pt 1.5pt 1.5pt 3.75pt'><p   style='text-align:right'><span  style='font-size:9.0pt;color:#555555'>"+iniatialTotal+"</span></p>"
										+ "</td>"
										+ "<td style='width:75.0pt;border-top:none;border-left:none; border-bottom:solid gray 1.0pt;border-right:solid gray 1.0pt;  padding:1.5pt 1.5pt 1.5pt 3.75pt'></td>"
										+ "<td style='border-top:none;border-left:none;border-bottom:solid gray 1.0pt;  border-right:solid gray 1.0pt;   padding:0cm 3.75pt 0cm 3.75pt'><p style='text-align:right'><span  style='font-size:9.0pt;';color:#555555'>"+totalAmount+"</span></p>"
										+ "</td>" + "</tr>" + "</table>");
						String itplFBMilestoneDetails = itplFBMilestoneDetail.toString();
						map.put("itplFBMilestoneDetail", itplFBMilestoneDetails);
							}else{
							itplFBMilestoneDetail
							.append("<table  width='99%' style='width:99.7%;border-collapse:collapse;'><thead>"
									+ "<tr style='height:22.5pt'>"
									+ "<td style='width:75.0pt;border:solid gray 1.0pt;border-left: none;background:#0065A4;padding:0cm 0cm 0cm 0cm; height:22.5pt'> <p style='text-align:center'><b><span style='font-size:9.0pt;color:#FFFFFF;'>&nbsp;Milestone</span></b></p> </td> "
									+ "<td style='width:75.0pt;border:solid gray 1.0pt;border-left: none;background:#0065A4;padding:0cm 0cm 0cm 0cm; height:22.5pt'> <p style='text-align:center'><b><span style='font-size:9.0pt;color:#FFFFFF;'>&nbsp;Description</span></b></p> </td> "
									+ "<td style='width:75.0pt;border:solid gray 1.0pt;border-left: none;background:#0065A4;padding:0cm 0cm 0cm 0cm; height:22.5pt'> <p style='text-align:center'><b><span style='font-size:9.0pt;color:#FFFFFF;'>&nbsp;Milestone Amount <br /> &nbsp;(In "+currencyCode+")</span></b></p> </td> "
									+ "<td style='width:75.0pt;border:solid gray 1.0pt;border-left: none;background:#0065A4;padding:0cm 0cm 0cm 0cm; height:22.5pt'> <p style='text-align:center'><b><span style='font-size:9.0pt;color:#FFFFFF;'>&nbsp;Exchange <br /> Rate</span></b></p> </td> "
									+ "<td style='width:75.0pt;border:solid gray 1.0pt;border-left: none;background:#0065A4;padding:0cm 0cm 0cm 0cm; height:22.5pt'> <p style='text-align:center'><b><span style='font-size:9.0pt;color:#FFFFFF;'>&nbsp;Billed Amount <br /> &nbsp;(In "+exchangeCurrencyCode+")</span></b></p> </td>"
									+ "</tr>" + "</thead>");
							List<Double> totalAmountSum = new ArrayList();
							List<Double> iniatialAmountSum = new ArrayList();
							while (it.hasNext()) {
								InvoicesDetail invoicesDetail = it.next();
								if (invoicesDetail.getResNameMilestone() != null) {
									resourceName = invoicesDetail.getResNameMilestone();
								}
		
								if (invoicesDetail.getDescription() != null) {
									description = invoicesDetail.getDescription();
								}
		
								if (invoicesDetail.getAmount() != null) {
									amount = invoicesDetail.getAmount();
								}
		
								if (invoicesDetail.getInitialBilledAmount() != null) {
									iniatialBuildAmount = invoicesDetail.getInitialBilledAmount();
								}
		
								if (invoice.getExchangeRate() != null) {
									exchangeRate = invoice.getExchangeRate();
								}		
								iniatialAmountSum.add(iniatialBuildAmount.doubleValue());
								totalAmountSum.add(amount.doubleValue());
								itplFBMilestoneDetail.append("<tr>"
										+ "<td style='border:solid gray 1.0pt;border-top:none;  padding:0cm 0cm 0cm 3.75pt'><p ><span style='font-size:9.0pt;  color:#555555'>"
										+ resourceName + "</span></p></td>"
										+ "<td style='border-top:none;border-left:none;border-bottom:solid gray 1.0pt; border-right:solid gray 1.0pt;   padding:0cm 0cm 0cm 3.75pt'><p ><span style='font-size:9.0pt; color:#555555'>"
										+ description + "</span></p></td>"
										+ "<td style='border-top:none;border-left:none;border-bottom:solid gray 1.0pt;  border-right:solid gray 1.0pt;   padding:0cm 3.75pt 0cm 3.75pt'><p   style='text-align:right'><span   style='font-size:9.0pt;color:#555555'>"
										+ iniatialBuildAmount + "</span></p></td>"
										+ "<td  style='width:75.0pt;border-top:none;border-left:none;   border-bottom:solid gray 1.0pt;border-right:solid gray 1.0pt;  padding:1.5pt 1.5pt 1.5pt 3.75pt'><p   style='text-align:right'><span  style='font-size:9.0pt;';color:#555555'>"
										+ exchangeRate + "</span></p></td>"
										+ "<td style='border-top:none;border-left:none;border-bottom:solid gray 1.0pt;   border-right:solid gray 1.0pt;padding:0cm 3.75pt 0cm 3.75pt'><p   style='text-align:right'><span style='font-size:9.0pt;';color:#555555'>"
										+ amount + "</span></p></td>" + "</tr>");
							}
							
							if(!CollectionUtils.isEmpty(totalAmountSum)) {
								totalAmount = new BigDecimal(totalAmountSum.stream().mapToDouble(Double::doubleValue).sum());
							};
														
							if(!CollectionUtils.isEmpty(iniatialAmountSum)) {
								iniatialTotal = new BigDecimal(iniatialAmountSum.stream().mapToDouble(Double::doubleValue).sum());
							};
							
							
							itplFBMilestoneDetail.append(
									"<tr>" + "<td style='border:solid gray 1.0pt;border-top:none;   padding:0cm 0cm 0cm 3.75pt'></td>"
											+ "<td style='border-top:none;border-left:none;border-bottom:solid gray 1.0pt;border-right:solid gray 1.0pt;  padding:0cm 3.75pt 0cm 3.75pt'><p style='text-align:right'><span  style='font-size:9.0pt;color:#555555'>Total</span></p>"
											+ "</td>"
											+ "<td style='width:75.0pt;border-top:none;border-left:none;   border-bottom:solid gray 1.0pt;border-right:solid gray 1.0pt;  padding:1.5pt 1.5pt 1.5pt 3.75pt'><p   style='text-align:right'><span  style='font-size:9.0pt;color:#555555'>"+iniatialTotal+"</span></p>"
											+ "</td>"
											+ "<td style='width:75.0pt;border-top:none;border-left:none; border-bottom:solid gray 1.0pt;border-right:solid gray 1.0pt;  padding:1.5pt 1.5pt 1.5pt 3.75pt'></td>"
											+ "<td style='border-top:none;border-left:none;border-bottom:solid gray 1.0pt;  border-right:solid gray 1.0pt;   padding:0cm 3.75pt 0cm 3.75pt'><p style='text-align:right'><span  style='font-size:9.0pt;';color:#555555'>"+totalAmount+"</span></p>"
											+ "</td>" + "</tr>" + "</table>");
							
							itplInternalInvoiceFooter.append("<table cellspacing='0' cellpadding='0' style='width: 100.0%; border-collapse: collapse; float: left'><thead>"
									+"<tr style='height: 22.5pt'><td style='width: 10.0%; border: solid gray 1.0pt; border-left: none; background: #0065A4; padding: .75pt .75pt .75pt .75pt; height: 22.5pt'>"
									+ "<p style='margin-bottom: 37.5pt; text-align: center'>	<span><b><span style='color: #FFFFFF'>Sr</span></b></span> <b><span style='color: #FFFFFF'> No.</span></b></p></td>"
									+ "<td style='width: 70.0%; border: solid gray 1.0pt; border-left: none; background: #0065A4; padding: .75pt .75pt .75pt .75pt; height: 22.5pt'><p style='margin-bottom: 37.5pt; text-align: center'><b><span style='color: #FFFFFF'>Description</span></b></p></td>"
									+ "<td style='width: 20.0%; border: solid gray 1.0pt; border-left: none; background: #0065A4; padding: .75pt .75pt .75pt .75pt; height: 22.5pt'><p style='margin-bottom: 37.5pt; text-align: center'>	<b><span style='color: #FFFFFF'>Billed Amount</span></b></p></td>"
									+ "</tr></thead>"
									+"<tr><td style='width: 60.0pt; border: solid gray 1.0pt; border-top: none; padding: 1.5pt 1.5pt 1.5pt 3.75pt'><p style='margin-bottom: 37.5pt; text-align: center'>	<span style='font-size: 10.0pt; color: #555555'>1</span></p></td>"
									+ "<td style='border-top: none; border-left: none; border-bottom: solid gray 1.0pt; border-right: solid gray 1.0pt; padding: .75pt .75pt .75pt 3.75pt'>"
									+ "<p style='margin-bottom: 37.5pt'>	<span style='font-size: 10.0pt; color: #555555'>"+description+"</span></p></td>"
									+ "<td style='border-top: none; border-left: none; border-bottom: solid gray 1.0pt; border-right: solid gray 1.0pt; padding: .75pt .75pt .75pt 3.75pt'><p style='margin-bottom: 37.5pt; text-align: right'><span style='font-size: 10.0pt;'>"+exchangeCurrencySign+" "+numberToCurrencyConverter(total)+"</span></p></td></tr>"
									+"<tr><td colspan='2' style='border: solid gray 1.0pt; border-top: none; padding: .75pt .75pt .75pt 3.75pt' cellpadding='0' cellspacing='0'>"
									+ "<p style='margin-bottom: 37.5pt; text-align: right'>	<span style='font-size: 10.0pt; color: #555555'>Sub-Total</span></p></td>"
									+ "<td style='border-top: none; border-left: none; border-bottom: solid gray 1.0pt; border-right: solid gray 1.0pt; padding: .75pt .75pt .75pt 3.75pt'><p style='margin-bottom: 37.5pt; text-align: right'><span style='font-size: 10.0pt;'>"+exchangeCurrencySign+" "+numberToCurrencyConverter(total)+"</span></p></td></tr>"
									+"</table>");

								// footer section block for Internal invoice ITPL
								if (endClientProjectId != null) {
									String itplInternalInvoicesFooter = itplInternalInvoiceFooter.toString();
									map.put("itplInternalInvoicesFooter", itplInternalInvoicesFooter);
								}else {
									String itplFBMilestoneDetails = itplFBMilestoneDetail.toString();
									map.put("itplFBMilestoneDetail", itplFBMilestoneDetails);
								}
							
							
							
							
							
							}
					} else {
						itplFBBillingDetail
								.append("<table  border='0' cellspacing='0' cellpadding='0' style='width:708px;'><thead><tr>"
										+ "<td width='7%' style='width:7.0%;border:solid gray 1.0pt;background:#0065A4;'> <p style='margin:0px !important; font-size:9pt' align='center' ><b><span style='font-size:9.0pt;  color:#FFFFFF'>Sr&nbsp;No </span></b></p> </td>"
										+ "<td width='40%' style='width:40.0%;border:solid gray 1.0pt;background:#0065A4;'> <p style='margin:0px !important; font-size:9pt' align='center' ><b><span style='font-size:9.0pt;color:#FFFFFF'>Description</span></b></p> </td>"
										+ "<td width='20%' style='width:20.0%;border:solid gray 1.0pt;background:#0065A4;'> <p style='margin:0px !important; font-size:9pt' align='center' ><b><span style='font-size:9.0pt;color:#FFFFFF'>Service&nbsp;Billing&nbsp;Details</span></b></p> </td>"
										+ "<td width='18%' style='width:18.0%;border:solid gray 1.0pt;background:#0065A4;'> <p style='margin:0px !important; font-size:9pt' align='center' ><b><span style='font-size:9.0pt;color:#FFFFFF'>Services&nbsp;Accounting&nbsp;Code</span></b></p> </td>"
										+ "<td width='15%' style='width:15.0%;border:solid gray 1.0pt;background:#0065A4;'> <p style='margin:0px !important; font-size:9pt' align='center' ><b><span style='font-size:9.0pt;color:#FFFFFF'>Billed&nbsp;Amount&nbsp;("
										+ currencyCode+")</span></b></p> </td>" + "</tr> </thead>");
						
						
						if (endClientProjectId != null) {
							itplFBBillingDetail.append("<tr>"
									+ "<td width='80' style='width:60.0pt;border-top:none;border-left:solid gray 1.0pt; border-bottom:solid gray 1.0pt;border-right:none; padding:1.5pt 1.5pt 1.5pt 1.5pt'><p style='margin:0px !important; font-size:9pt' align='center' ><span style='font-size:9.0pt;color:#555555'>1</span></p> </td>"
									+ "<td width='80' style='width:60.0pt;border-top:none;border-left:solid gray 1.0pt; border-bottom:solid gray 1.0pt;border-right:none; padding:1.5pt 1.5pt 1.5pt 1.5pt'> <p style='margin:0px !important; font-size:9pt' align='center' ><span style='font-size:9.0pt;color:#555555'>Information technology (IT) design and development services</span></p> </td>"
									+ "<td width='80' style='width:60.0pt;border-top:none;border-left:solid gray 1.0pt; border-bottom:solid gray 1.0pt;border-right:none; padding:1.5pt 1.5pt 1.5pt 1.5pt'> <p style='margin:0px !important; font-size:9pt' align='center' ><span style='font-size:9.0pt;color:#555555'>As per Annexure-I</span></p> </td>"
									+ "<td width='90' style='width:67.5pt;border-top:none;border-left:solid gray 1.0pt; border-bottom:solid gray 1.0pt;border-right:none; padding:1.5pt 1.5pt 1.5pt 1.5pt'> <p style='margin:0px !important; font-size:9pt' align='right' ><span style='font-size:9.0pt;color:#555555'>998314</span></p> </td>"
									+ "<td width='100' style='width:67.5pt;border-top:none;border-left:solid gray 1.0pt; border-bottom:solid gray 1.0pt;border-right:solid gray 1.0pt; padding:1.5pt 1.5pt 1.5pt 1.5pt'> <p style='margin:0px !important; font-size:9pt' align='right' ><span style='font-size:9.0pt;color:#555555'>"
									+ numberToCurrencyConverter(subTotal) + "</span></p></td></tr>");
						}else if(invoiceType.equals("License Invoice")){
							itplFBBillingDetail.append("<tr>"
									+ "<td width='80' style='width:60.0pt;border-top:none;border-left:solid gray 1.0pt; border-bottom:solid gray 1.0pt;border-right:none; padding:1.5pt 1.5pt 1.5pt 1.5pt'><p style='margin:0px !important; font-size:9pt' align='center' ><span style='font-size:9.0pt;color:#555555'>1</span></p> </td>"
									+ "<td width='80' style='width:60.0pt;border-top:none;border-left:solid gray 1.0pt; border-bottom:solid gray 1.0pt;border-right:none; padding:1.5pt 1.5pt 1.5pt 1.5pt'> <p style='margin:0px !important; font-size:9pt' align='center' ><span style='font-size:9.0pt;color:#555555'>Licensing services for the right to use computer software and databases</span></p> </td>"
									+ "<td width='80' style='width:60.0pt;border-top:none;border-left:solid gray 1.0pt; border-bottom:solid gray 1.0pt;border-right:none; padding:1.5pt 1.5pt 1.5pt 1.5pt'> <p style='margin:0px !important; font-size:9pt' align='center' ><span style='font-size:9.0pt;color:#555555'>As per Annexure-I</span></p> </td>"
									+ "<td width='90' style='width:67.5pt;border-top:none;border-left:solid gray 1.0pt; border-bottom:solid gray 1.0pt;border-right:none; padding:1.5pt 1.5pt 1.5pt 1.5pt'> <p style='margin:0px !important; font-size:9pt' align='right' ><span style='font-size:9.0pt;color:#555555'>997331</span></p> </td>"
									+ "<td width='100' style='width:75.0pt;border:solid gray 1.0pt;border-top:none;  padding:1.5pt 1.5pt 1.5pt 1.5pt'>  <p style='margin:0px !important; font-size:9pt' align='right'>");
							itplFBBillingDetail.append("<span style='font-size:9.0pt;color:#555555'>"+numberToCurrencyConverter(subTotal)+"</span>");
							itplFBBillingDetail.append("</p> </td></tr>");
						}else{
							itplFBBillingDetail.append("<tr>"
									+ "<td width='80' style='width:60.0pt;border-top:none;border-left:solid gray 1.0pt; border-bottom:solid gray 1.0pt;border-right:none; padding:1.5pt 1.5pt 1.5pt 1.5pt'><p style='margin:0px !important; font-size:9pt' align='center' ><span style='font-size:9.0pt;color:#555555'>1</span></p> </td>"
									+ "<td width='80' style='width:60.0pt;border-top:none;border-left:solid gray 1.0pt; border-bottom:solid gray 1.0pt;border-right:none; padding:1.5pt 1.5pt 1.5pt 1.5pt'> <p style='margin:0px !important; font-size:9pt' align='center' ><span style='font-size:9.0pt;color:#555555'>Information technology (IT) design and development services</span></p> </td>"
									+ "<td width='80' style='width:60.0pt;border-top:none;border-left:solid gray 1.0pt; border-bottom:solid gray 1.0pt;border-right:none; padding:1.5pt 1.5pt 1.5pt 1.5pt'> <p style='margin:0px !important; font-size:9pt' align='center' ><span style='font-size:9.0pt;color:#555555'>As per Annexure-I</span></p> </td>"
									+ "<td width='90' style='width:67.5pt;border-top:none;border-left:solid gray 1.0pt; border-bottom:solid gray 1.0pt;border-right:none; padding:1.5pt 1.5pt 1.5pt 1.5pt'> <p style='margin:0px !important; font-size:9pt' align='right' ><span style='font-size:9.0pt;color:#555555'>998314</span></p> </td>"
									+ "<td width='100' style='width:75.0pt;border:solid gray 1.0pt;border-top:none;  padding:1.5pt 1.5pt 1.5pt 1.5pt'>  <p style='margin:0px !important; font-size:9pt' align='right'>");
							itplFBBillingDetail.append("<span style='font-size:9.0pt;color:#555555'>"+numberToCurrencyConverter(subTotal)+"</span>");
							itplFBBillingDetail.append("</p> </td></tr>");
						}

						itplFBBillingDetail.append("<tr> "
								+ "<td style='border-top:none;border-left:solid gray 1.0pt;border-bottom:solid gray 1.0pt; border-right:none;padding:1.5pt 1.5pt 1.5pt 1.5pt'>  <p style='margin:0px !important; font-size:9pt' align='center' ><span style='font-size:9.0pt;color:#555555'>2</span></p> </td>"
								+ "<td colspan='3' style='border-top:none;border-left:solid gray 1.0pt; border-bottom:solid gray 1.0pt;border-right:none; padding:1.5pt 1.5pt 1.5pt 1.5pt'>  <p style='margin:0px !important; font-size:9pt' align='center' ><span style='font-size:9.0pt;color:#555555'>Discount Allowed @ "
								+ discountPercent + "%</span></p> </td>"
								+ "<td style='border:solid gray 1.0pt;border-top:none;padding:1.5pt 1.5pt 1.5pt 1.5pt'> <p style='margin:0px !important; font-size:9pt' align='right' ><span style='font-size:9.0pt;color:#555555'>"
								+ numberToCurrencyConverter(dicountAmount) + "</span></p> </td></tr>");

						itplFBBillingDetail.append("<tr>"
								+ "<td colspan='4' style='border-top:none;border-left:solid gray 1.0pt; border-bottom:solid gray 1.0pt;border-right:none; padding:2.25pt 2.25pt 2.25pt 2.25pt'> <p style='margin:0px !important; font-size:9pt'><b><span style='font-size:9.0pt;color:#555555'>Taxable Value of Supply of Services</span></b></p> </td>"
								+ "<td style='border:solid gray  1.0pt;border-top:none;padding:2.25pt 2.25pt 2.25pt 2.25pt'> <p style='margin:0px !important; font-size:9pt' align='right' ><b><span style='font-size:9.0pt;color:#555555'>"
								+ numberToCurrencyConverter(netSubTotal) + "</span></b></p> </td></tr>" + "</table>");
						String itplFBBillingDetails = itplFBBillingDetail.toString();
						map.put("itplFBBillableInvoiceDetail", itplFBBillingDetails);

						itplFBGSTCalculation
								.append("<table border='0' cellspacing='0' cellpadding='0' style='width:707px; border-collapse:collapse;'>"
										+ "<tr>"
										+ "<td style='width:35%;border:solid gray 1.0pt; padding:.75pt .75pt .75pt 3.75pt'> <p style='margin:0px !important; font-size:9pt'><span style='font-size:9.0pt;color:#555555'>Output GST Calculation</span></p> </td>"
										+ "<td style='width:65%;border:solid gray 1.0pt; padding: 0pt .75pt .75pt 0pt;'>");
						itplFBGSTCalculation
								.append("<table border='0' cellspacing='0' cellpadding='0' width='99%' style='width:100%;border-collapse:collapse;'><tr>"
										+ "<td width='18%' style='width:18.0%;border:solid gray 1.0pt;border-left: none;border-top: none; padding:0pt .75pt .75pt 3.75pt'> <p style='margin:0px !important; font-size:9pt'><span style='font-size:9.0pt;color:#555555'>GST to be levied</span></p> </td>"
										+ "<td width='15%' style='width:15.0%;border:solid gray 1.0pt;border-left: none;border-top: none; padding:0pt .75pt .75pt 3.75pt'> <p style='margin:0px !important; font-size:9pt'><span style='font-size:9.0pt;color:#555555'>Rate of Tax</span></p> </td>"
										+ "<td width='15%' style='width:15.0%;border:solid gray 1.0pt;border-right: none;border-top: none; padding:0pt .75pt .75pt 3.75pt'> <p style='margin:0px !important; font-size:9pt'><span style='font-size:9.0pt;color:#555555'>Amount</span></p> </td>"
										+ "</tr>");

						Integer count = 0;
						if (cgst.compareTo(BigDecimal.ZERO) > 0) {
							count = 1;
							itplFBGSTCalculation.append("<tr> "
									+ "<td width='80' style='width:60.0pt;border-top:none;border-left:none; border-right:solid gray 1.0pt;padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='center' ><span>CGST</span></p> </td>"
									+ "<td width='80' style='width:60.0pt;border-top:none;border-left:none; border-right:solid gray 1.0pt;padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='center' >"
									+ cgst + "%</p> </td>"
									+ "<td width='90' style='width:67.5pt;border-top:none;border-left:none; padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='right' >"
									+ numberToCurrencyConverter(cgstAmount) + "</p> </td>" + "</tr>");
						}
						if (sgst.compareTo(BigDecimal.ZERO) > 0) {
							count = 1;
							itplFBGSTCalculation.append("<tr> "
									+ "<td width='80' style='width:60.0pt;border-top:none;border-left:none; border-right:solid gray 1.0pt;padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='center' ><span>SGST</span></p> </td>"
									+ "<td width='80' style='width:60.0pt;border-top:none;border-left:none; border-right:solid gray 1.0pt;padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='center' >"
									+ sgst + "%</p> </td>"
									+ "<td width='90' style='width:67.5pt;border-top:none;border-left:none; padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='right' >"
									+ numberToCurrencyConverter(sgstAmount) + "</p> </td>" + "</tr>");
						}
						if (igst.compareTo(BigDecimal.ZERO) > 0) {
							count = 1;
							itplFBGSTCalculation.append("<tr> "
									+ "<td width='80' style='width:60.0pt;border-top:none;border-left:none; border-right:solid gray 1.0pt;padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='center' ><span>IGST</span></p> </td>"
									+ "<td width='80' style='width:60.0pt;border-top:none;border-left:none; border-right:solid gray 1.0pt;padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='center' >"
									+ igst + "%</p> </td>"
									+ "<td width='90' style='width:67.5pt;border-top:none;border-left:none; padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='right' >"
									+ numberToCurrencyConverter(igstAmount) + "</p> </td>" + "</tr>");
						}
						if (utgst.compareTo(BigDecimal.ZERO) > 0) {
							count = 1;
							itplFBGSTCalculation.append("<tr> "
									+ "<td width='80' style='width:60.0pt;border-top:none;border-left:none; border-right:solid gray 1.0pt;padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='center' ><span>UTGST</span></p> </td>"
									+ "<td width='80' style='width:60.0pt;border-top:none;border-left:none; border-right:solid gray 1.0pt;padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='center' >"
									+ utgst + "%</p> </td>"
									+ "<td width='90' style='width:67.5pt;border-top:none;border-left:none; padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='right' >"
									+ numberToCurrencyConverter(utgstAmount) + "</p> </td>" + "</tr>");
						}
						if (count == 0) {
							itplFBGSTCalculation.append("<tr> "
									+ "<td width='80' style='width:60.0pt;border-top:none;border-left:none; border-right:solid gray 1.0pt;padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='center' ><span>Zero Rated Supply</span></p> </td>"
									+ "<td width='80' style='width:60.0pt;border-top:none;border-left:none; border-right:solid gray 1.0pt;padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='center' ><span>0</span></p> </td>"
									+ "<td width='90' style='width:67.5pt;border-top:none;border-left:none; padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='right' >0</p> </td>"
									+ "</tr>");
						}
						itplFBGSTCalculation.append("</table></td></tr><tr>"
								+ "<td  style='border:solid gray 1.0pt;border-top:none;padding:2.25pt 2.25pt 2.25pt 3.75pt'> <p style='margin:0px !important; font-size:9pt'><b><span style='font-size:9.0pt;color:#555555'>Total Value of Supply of Services (In Figure)</span></b></p> </td>"
								+ "<td style='border-top:none;border-left:none;border-bottom:solid gray 1.0pt; border-right:solid gray 1.0pt;padding:2.25pt 2.25pt 2.25pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='right' ><b>"
								+ numberToCurrencyConverter(total) + "</b></p> </td></tr>");
						itplFBGSTCalculation.append("<tr>"
								+ "<td style='border:solid gray 1.0pt;border-top:none;padding:2.25pt 2.25pt 2.25pt 3.75pt'> <p style='margin:0px !important; font-size:9pt'><b><span style='font-size:9.0pt;color:#555555'>Total Value of Supply of Services (In Words)</span></b></p> </td>"
								+ "<td style='border-top:none;border-left:none;border-bottom:solid gray 1.0pt; border-right:solid gray 1.0pt;padding:2.25pt 2.25pt 2.25pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='right' ><b>"
								+ amountInWord + "</b></p> </td>" + "</tr></table>");
						String itplFBGSTCalculations = itplFBGSTCalculation.toString();
						map.put("itplFBGSTCalculation", itplFBGSTCalculations);

						
						if(invoiceType.equals("License Invoice")){
							itplFBMilestoneDetail.append("<table width='99%' style='width:99.7%;border-collapse:collapse;'><thead>"
										+ "<tr style='height:22.5pt'>"
										+ "<td style='width:75.0pt;border:solid gray 1.0pt;border-left: none;background:#0065A4;padding:0cm 0cm 0cm 0cm; height:22.5pt'> <p style='text-align:center'><b><span style='font-size:9.0pt;color:#FFFFFF;'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Description&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></b></p> </td> "
										+ "<td class='gridHeaderRow' align='center' colspan='2'><p style='margin:0px !important;width:150px !important;'>Period</p>"
										+ "<table style='width:100%'><tr>"
										+ "<td class='fromPeriodColumn' style='width: 50%;'><p style='margin:0px !important;' >From</p></td>"
										+ "<td class='toPeriodColumn'><p style='margin:0px !important;'>To</p></td>"
										+ "</tr></table></td>"
										+ "<td style='width:75.0pt;border:solid gray 1.0pt;border-left: none;background:#0065A4;padding:0cm 0cm 0cm 0cm; height:22.5pt'> <p style='text-align:center'><b><span style='font-size:9.0pt;color:#FFFFFF;'>&nbsp;Milestone&nbsp;Amount <br /> &nbsp;(In&nbsp;"+currencyCode+")</span></b></p> </td> "
										+ "<td style='width:75.0pt;border:solid gray 1.0pt;border-left: none;background:#0065A4;padding:0cm 0cm 0cm 0cm; height:22.5pt'> <p style='text-align:center'><b><span style='font-size:9.0pt;color:#FFFFFF;'>&nbsp;Exchange <br /> Rate</span></b></p> </td> "
										+ "<td style='width:75.0pt;border:solid gray 1.0pt;border-left: none;background:#0065A4;padding:0cm 0cm 0cm 0cm; height:22.5pt'> <p style='text-align:center'><b><span style='font-size:9.0pt;color:#FFFFFF;'>&nbsp;Billed&nbsp;Amount <br /> &nbsp;(In "+exchangeCurrencyCode+")</span></b></p> </td>"
										+ "</tr>" + "</thead>");
						while (it.hasNext()){
							InvoicesDetail invoicesDetail = it.next();
							if (invoicesDetail.getResNameMilestone() != null) {
								resourceName = invoicesDetail.getResNameMilestone();
							}
	
							if (invoicesDetail.getDescription() != null) {
								description = invoicesDetail.getDescription();
							}
	
							if (invoicesDetail.getAmount() != null) {
								amount = invoicesDetail.getAmount();
							}
	
							if (invoicesDetail.getInitialBilledAmount() != null) {
								iniatialBuildAmount = invoicesDetail.getInitialBilledAmount();
							}
	
							if (invoice.getExchangeRate() != null) {
								exchangeRate = invoice.getExchangeRate();
							}
							
							if (invoice.getPeriodStartDate() != null) {
								sDate = DateConverter.changeDate2(invoice.getPeriodStartDate());
							}

							if (invoice.getPeriodEndDate() != null) {
								eDate = DateConverter.changeDate2(invoice.getPeriodEndDate());
							}
	
							totalAmount = totalAmount.add(total);
							iniatialTotal = iniatialTotal.add(iniatialBuildAmount);
							itplFBMilestoneDetail.append("<tr>"
									+ "<td class='pnTrData' style='border-top:none;border-bottom:solid gray 1.0pt; border-right:solid gray 1.0pt;   padding:0cm 0cm 0cm 3.75pt'><p><span style='font-size:9.0pt; color:#555555'>"
									+ description + "</span></p></td>"
									+ "<td class='trData' style='width:50%'><p style='margin-bottom:0px !important'>"+sDate+"</p></td>"
									+ "<td class='trData' style='width:50%'><p style='margin:0px !important'>"+eDate+"</p></td>"
									+ "<td style='border-top:none;border-left:none;border-bottom:solid gray 1.0pt;  border-right:solid gray 1.0pt;   padding:0cm 3.75pt 0cm 3.75pt'><p   style='text-align:right'><span   style='font-size:9.0pt;color:#555555'>"
									+ iniatialBuildAmount + "</span></p></td>"
									+ "<td  style='width:75.0pt;border-top:none;border-left:none;   border-bottom:solid gray 1.0pt;border-right:solid gray 1.0pt;  padding:1.5pt 1.5pt 1.5pt 3.75pt'><p   style='text-align:right'><span  style='font-size:9.0pt;';color:#555555'>"
									+ exchangeRate + "</span></p></td>"
									+ "<td style='border-top:none;border-left:none;border-bottom:solid gray 1.0pt;   border-right:solid gray 1.0pt;padding:0cm 3.75pt 0cm 3.75pt'><p   style='text-align:right'><span style='font-size:9.0pt;';color:#555555'>"
									+ amount + "</span></p></td>" + "</tr>");
						}
						
						itplFBMilestoneDetail.append(
								"<tr>" + "<td colspan='3' style='border:solid gray 1.0pt;border-top:none;border-left:none;border-bottom:solid gray 1.0pt;border-right:solid gray 1.0pt;  padding:0cm 3.75pt 0cm 3.75pt'><p style='text-align:right'><span  style='font-size:9.0pt;color:#555555'>Total</span></p>"
										+ "</td>"
										+ "<td style='width:75.0pt;border-top:none;border-left:none;   border-bottom:solid gray 1.0pt;border-right:solid gray 1.0pt;  padding:1.5pt 1.5pt 1.5pt 3.75pt'><p   style='text-align:right'><span  style='font-size:9.0pt;color:#555555'>"+iniatialTotal+"</span></p>"
										+ "</td>"
										+ "<td style='width:75.0pt;border-top:none;border-left:none; border-bottom:solid gray 1.0pt;border-right:solid gray 1.0pt;  padding:1.5pt 1.5pt 1.5pt 3.75pt'></td>"
										+ "<td style='border-top:none;border-left:none;border-bottom:solid gray 1.0pt;  border-right:solid gray 1.0pt;   padding:0cm 3.75pt 0cm 3.75pt'><p style='text-align:right'><span  style='font-size:9.0pt;';color:#555555'>"+totalAmount+"</span></p>"
										+ "</td>" + "</tr>" + "</table>");
						String itplFBMilestoneDetails = itplFBMilestoneDetail.toString();
						map.put("itplFBMilestoneDetail", itplFBMilestoneDetails);
							
						}else {

							
							itplFBMilestoneDetail
									.append("<table  width='99%' style='width:99.7%;border-collapse:collapse;'><thead>"
											+ "<tr style='height:22.5pt'>"
											+ "<td style='width:75.0pt;border:solid gray 1.0pt;border-left: none;background:#0065A4;padding:0cm 0cm 0cm 0cm; height:22.5pt'> <p style='text-align:center'><b><span style='font-size:9.0pt;color:#FFFFFF;'>&nbsp;Milestone</span></b></p> </td> "
											+ "<td style='width:75.0pt;border:solid gray 1.0pt;border-left: none;background:#0065A4;padding:0cm 0cm 0cm 0cm; height:22.5pt'> <p style='text-align:center'><b><span style='font-size:9.0pt;color:#FFFFFF;'>&nbsp;Description</span></b></p> </td> "
											+ "<td style='width:75.0pt;border:solid gray 1.0pt;border-left: none;background:#0065A4;padding:0cm 0cm 0cm 0cm; height:22.5pt'> <p style='text-align:center'><b><span style='font-size:9.0pt;color:#FFFFFF;'>&nbsp;Milestone Amount <br /> &nbsp;(In "+currencyCode+")</span></b></p> </td> "
											+ "<td style='width:75.0pt;border:solid gray 1.0pt;border-left: none;background:#0065A4;padding:0cm 0cm 0cm 0cm; height:22.5pt'> <p style='text-align:center'><b><span style='font-size:9.0pt;color:#FFFFFF;'>&nbsp;Exchange <br /> Rate</span></b></p> </td> "
											+ "<td style='width:75.0pt;border:solid gray 1.0pt;border-left: none;background:#0065A4;padding:0cm 0cm 0cm 0cm; height:22.5pt'> <p style='text-align:center'><b><span style='font-size:9.0pt;color:#FFFFFF;'>&nbsp;Billed Amount <br /> &nbsp;(In "+exchangeCurrencyCode+")</span></b></p> </td>"
											+ "</tr>" + "</thead>");
							List<Double> totalAmountSum = new ArrayList();
							List<Double> iniatialAmountSum = new ArrayList();

							while (it.hasNext()) {
								InvoicesDetail invoicesDetail = it.next();
								if (invoicesDetail.getResNameMilestone() != null) {
									resourceName = invoicesDetail.getResNameMilestone();
								}

								if (invoicesDetail.getDescription() != null) {
									description = invoicesDetail.getDescription();
								}
	
								if (invoicesDetail.getAmount() != null) {
									amount = invoicesDetail.getAmount();
								}
	
								if (invoicesDetail.getInitialBilledAmount() != null) {
									iniatialBuildAmount = invoicesDetail.getInitialBilledAmount();
								}
	
								if (invoice.getExchangeRate() != null) {
									exchangeRate = invoice.getExchangeRate();
								}
								
								iniatialAmountSum.add(iniatialBuildAmount.doubleValue());
								totalAmountSum.add(amount.doubleValue());
								
								itplFBMilestoneDetail.append("<tr>"
										+ "<td style='border:solid gray 1.0pt;border-top:none;  padding:0cm 0cm 0cm 3.75pt'><p ><span style='font-size:9.0pt;  color:#555555'>"
										+ resourceName + "</span></p></td>"
										+ "<td style='border-top:none;border-left:none;border-bottom:solid gray 1.0pt; border-right:solid gray 1.0pt;   padding:0cm 0cm 0cm 3.75pt'><p ><span style='font-size:9.0pt; color:#555555'>"
										+ description + "</span></p></td>"
										+ "<td style='border-top:none;border-left:none;border-bottom:solid gray 1.0pt;  border-right:solid gray 1.0pt;   padding:0cm 3.75pt 0cm 3.75pt'><p   style='text-align:right'><span   style='font-size:9.0pt;color:#555555'>"
										+ iniatialBuildAmount + "</span></p></td>"
										+ "<td  style='width:75.0pt;border-top:none;border-left:none;   border-bottom:solid gray 1.0pt;border-right:solid gray 1.0pt;  padding:1.5pt 1.5pt 1.5pt 3.75pt'><p   style='text-align:right'><span  style='font-size:9.0pt;';color:#555555'>"
										+ exchangeRate + "</span></p></td>"
										+ "<td style='border-top:none;border-left:none;border-bottom:solid gray 1.0pt;   border-right:solid gray 1.0pt;padding:0cm 3.75pt 0cm 3.75pt'><p   style='text-align:right'><span style='font-size:9.0pt;';color:#555555'>"
										+ amount + "</span></p></td>" + "</tr>");
							}
							
							if(!CollectionUtils.isEmpty(totalAmountSum)) {
								totalAmount = new BigDecimal(totalAmountSum.stream().mapToDouble(Double::doubleValue).sum());
							};
							
							
							if(!CollectionUtils.isEmpty(iniatialAmountSum)) {
								iniatialTotal = new BigDecimal(iniatialAmountSum.stream().mapToDouble(Double::doubleValue).sum());
							};

							itplFBMilestoneDetail.append(
									"<tr>" + "<td style='border:solid gray 1.0pt;border-top:none;   padding:0cm 0cm 0cm 3.75pt'></td>"
											+ "<td style='border-top:none;border-left:none;border-bottom:solid gray 1.0pt;border-right:solid gray 1.0pt;  padding:0cm 3.75pt 0cm 3.75pt'><p style='text-align:right'><span  style='font-size:9.0pt;color:#555555'>Total</span></p>"
											+ "</td>"
											+ "<td style='width:75.0pt;border-top:none;border-left:none;   border-bottom:solid gray 1.0pt;border-right:solid gray 1.0pt;  padding:1.5pt 1.5pt 1.5pt 3.75pt'><p   style='text-align:right'><span  style='font-size:9.0pt;color:#555555'>"+iniatialTotal+"</span></p>"
											+ "</td>"
											+ "<td style='width:75.0pt;border-top:none;border-left:none; border-bottom:solid gray 1.0pt;border-right:solid gray 1.0pt;  padding:1.5pt 1.5pt 1.5pt 3.75pt'></td>"
											+ "<td style='border-top:none;border-left:none;border-bottom:solid gray 1.0pt;  border-right:solid gray 1.0pt;   padding:0cm 3.75pt 0cm 3.75pt'><p style='text-align:right'><span  style='font-size:9.0pt;';color:#555555'>"+totalAmount+"</span></p>"
											+ "</td>" + "</tr>" + "</table>");

						itplInternalInvoiceFooter.append("<table cellspacing='0' cellpadding='0' style='width: 100.0%; border-collapse: collapse; float: left'><thead>"
											+"<tr style='height: 22.5pt'><td style='width: 10.0%; border: solid gray 1.0pt; border-left: none; background: #0065A4; padding: .75pt .75pt .75pt .75pt; height: 22.5pt'>"
											+ "<p style='margin-bottom: 37.5pt; text-align: center'>	<span><b><span style='color: #FFFFFF'>Sr</span></b></span> <b><span style='color: #FFFFFF'> No.</span></b></p></td>"
											+ "<td style='width: 70.0%; border: solid gray 1.0pt; border-left: none; background: #0065A4; padding: .75pt .75pt .75pt .75pt; height: 22.5pt'><p style='margin-bottom: 37.5pt; text-align: center'><b><span style='color: #FFFFFF'>Description</span></b></p></td>"
											+ "<td style='width: 20.0%; border: solid gray 1.0pt; border-left: none; background: #0065A4; padding: .75pt .75pt .75pt .75pt; height: 22.5pt'><p style='margin-bottom: 37.5pt; text-align: center'>	<b><span style='color: #FFFFFF'>Billed Amount</span></b></p></td>"
											+ "</tr></thead>"
											+"<tr><td style='width: 60.0pt; border: solid gray 1.0pt; border-top: none; padding: 1.5pt 1.5pt 1.5pt 3.75pt'><p style='margin-bottom: 37.5pt; text-align: center'>	<span style='font-size: 10.0pt; color: #555555'>1</span></p></td>"
											+ "<td style='border-top: none; border-left: none; border-bottom: solid gray 1.0pt; border-right: solid gray 1.0pt; padding: .75pt .75pt .75pt 3.75pt'>"
											+ "<p style='margin-bottom: 37.5pt'><span style='font-size: 10.0pt; color: #555555'>"+description+"</span></p></td>"
											+ "<td style='border-top: none; border-left: none; border-bottom: solid gray 1.0pt; border-right: solid gray 1.0pt; padding: .75pt .75pt .75pt 3.75pt'><p style='margin-bottom: 37.5pt; text-align: right'><span style='font-size: 10.0pt;'>"+currencySign+" "+numberToCurrencyConverter(total)+"</span></p></td></tr>"
											+"<tr><td colspan='2' style='border: solid gray 1.0pt; border-top: none; padding: .75pt .75pt .75pt 3.75pt' cellpadding='0' cellspacing='0'>"
											+ "<p style='margin-bottom: 37.5pt; text-align: right'>	<span style='font-size: 10.0pt; color: #555555'>Sub-Total</span></p></td>"
											+ "<td style='border-top: none; border-left: none; border-bottom: solid gray 1.0pt; border-right: solid gray 1.0pt; padding: .75pt .75pt .75pt 3.75pt'><p style='margin-bottom: 37.5pt; text-align: right'><span style='font-size: 10.0pt;'>"+currencySign+" "+numberToCurrencyConverter(total)+"</span></p></td></tr>"
											+"</table>");
												
						// footer section block for Internal invoice ITPL
						if (endClientProjectId != null) {
							String itplInternalInvoicesFooter = itplInternalInvoiceFooter.toString();
							map.put("itplInternalInvoicesFooter", itplInternalInvoicesFooter);
						}else {
							String itplFBMilestoneDetails = itplFBMilestoneDetail.toString();
							map.put("itplFBMilestoneDetail", itplFBMilestoneDetails);
						}
						
						}
						
					}

				} else {
					// ITPL T&M template code
					if (exchangeRate != BigDecimal.ZERO && exchangeRate != BigDecimal.ONE) {
						inialtialSubTotalAmount = subTotal.divide(exchangeRate, 0, RoundingMode.HALF_UP);
						if (discountPercent != BigDecimal.ZERO) {
							iniatialDiscountAmount = inialtialSubTotalAmount.multiply(discountPercent).divide(new BigDecimal(100)).setScale(0, BigDecimal.ROUND_HALF_UP);
							inialtialNetSubTotalAmount = inialtialSubTotalAmount.subtract(iniatialDiscountAmount).setScale(0, BigDecimal.ROUND_HALF_UP);
						}else {
							inialtialNetSubTotalAmount = inialtialSubTotalAmount.setScale(0, BigDecimal.ROUND_HALF_UP);
						}

						itplBillingDetail.append("<table  border='0' cellspacing='0' cellpadding='0' style='width:99.7%;'><thead><tr>"
										+ "<td width='7%' style='width:7.0%;border:solid gray 1.0pt;background:#0065A4;'> <p style='margin:0px !important; font-size:9pt;color:#FFFFFF' align='center' ><b><span style='font-size:9.0pt;  '>Sr&nbsp;No </span></b></p> </td>"
										+ "<td width='40%' style='width:40.0%;border:solid gray 1.0pt;background:#0065A4;'> <p style='margin:0px !important; font-size:9pt;color:#FFFFFF' align='center' ><b><span style='font-size:9.0pt;F'>Description of Services</span></b></p> </td>"
										+ "<td width='20%' style='width:20.0%;border:solid gray 1.0pt;background:#0065A4;'> <p style='margin:0px !important; font-size:9pt;color:#FFFFFF' align='center' ><b><span style='font-size:9.0pt;'>Service&nbsp;Billing&nbsp;Details</span></b></p> </td>"
										+ "<td width='18%' style='width:18.0%;border:solid gray 1.0pt;background:#0065A4;'> <p style='margin:0px !important; font-size:9pt;color:#FFFFFF' align='center' ><b><span style='font-size:9.0pt;'>Services&nbsp;Accounting&nbsp;Code</span></b></p> </td>"
										+ "<td width='15%' style='width:15.0%;border:solid gray 1.0pt;background:#0065A4;'> <p style='margin:0px !important; font-size:9pt;color:#FFFFFF' align='center' ><b><span style='font-size:9.0pt;'>Billed Amount ("
										+ currencyCode + ")</span></b></p> </td>"
										+ "<td width='15%' style='width:15.0%;border:solid gray 1.0pt;background:#0065A4;'> <p style='margin:0px !important; font-size:9pt;color:#FFFFFF' align='center' ><b><span style='font-size:9.0pt;'>Exchange Rate</span></b></p> </td>"
										+ "<td width='15%' style='width:15.0%;border:solid gray 1.0pt;background:#0065A4;'> <p style='margin:0px !important; font-size:9pt;color:#FFFFFF' align='center' ><b><span style='font-size:9.0pt;'>Billed Amount ("
										+ exchangeCurrencyCode + ")</span></b></p> </td>" + "</tr> </thead>");
						itplBillingDetail.append("<tr>"
								+ "<td width='80' style='width:60.0pt;border-top:none;border-left:solid gray 1.0pt; border-bottom:solid gray 1.0pt;border-right:none; padding:1.5pt 1.5pt 1.5pt 1.5pt'><p style='margin:0px !important; font-size:9pt' align='center' ><span style='font-size:9.0pt;color:#555555'>1</span></p> </td>"
								+ "<td width='80' style='width:60.0pt;border-top:none;border-left:solid gray 1.0pt; border-bottom:solid gray 1.0pt;border-right:none; padding:1.5pt 1.5pt 1.5pt 1.5pt'> <p style='margin:0px !important; font-size:9pt' align='center' ><span style='font-size:9.0pt;color:#555555'>Information technology (IT) design and development services</span></p> </td>"
								+ "<td width='80' style='width:60.0pt;border-top:none;border-left:solid gray 1.0pt; border-bottom:solid gray 1.0pt;border-right:none; padding:1.5pt 1.5pt 1.5pt 1.5pt'> <p style='margin:0px !important; font-size:9pt' align='center' ><span style='font-size:9.0pt;color:#555555'>As per Annexure-I</span></p> </td>"
								+ "<td width='90' style='width:67.5pt;border-top:none;border-left:solid gray 1.0pt; border-bottom:solid gray 1.0pt;border-right:none; padding:1.5pt 1.5pt 1.5pt 1.5pt'> <p style='margin:0px !important; font-size:9pt' align='right' ><span style='font-size:9.0pt;color:#555555'>998314</span></p> </td>"
								+ "<td width='90' style='width:67.5pt;border-top:none;border-left:solid gray 1.0pt; border-bottom:solid gray 1.0pt;border-right:none; padding:1.5pt 1.5pt 1.5pt 1.5pt'> <p style='margin:0px !important; font-size:9pt' align='right' ><span style='font-size:9.0pt;color:#555555'>"
								+ numberToCurrencyConverter(iniatialTotal) + "</span></p></td>"
								+ "<td width='90' style='width:67.5pt;border-top:none;border-left:solid gray 1.0pt; border-bottom:solid gray 1.0pt;border-right:none; padding:1.5pt 1.5pt 1.5pt 1.5pt'> <p style='margin:0px !important; font-size:9pt' align='right' ><span style='font-size:9.0pt;color:#555555'>"
								+ exchangeRate + "</span></p></td>"
								+ "<td width='100' style='width:75.0pt;border:solid gray 1.0pt;border-top:none;  padding:1.5pt 1.5pt 1.5pt 1.5pt'>  <p style='margin:0px !important; font-size:9pt' align='right'><span style='font-size:9.0pt;color:#555555'>"
								+ numberToCurrencyConverter(subTotal) + "</span></p> </td></tr>");
						itplBillingDetail.append("<tr> "
								+ "<td style='border-top:none;border-left:solid gray 1.0pt;border-bottom:solid gray 1.0pt; border-right:none;padding:1.5pt 1.5pt 1.5pt 1.5pt'>  <p style='margin:0px !important; font-size:9pt' align='center' ><span style='font-size:9.0pt;color:#555555'>2</span></p> </td>"
								+ "<td colspan='3' style='border-top:none;border-left:solid gray 1.0pt; border-bottom:solid gray 1.0pt;border-right:none; padding:1.5pt 1.5pt 1.5pt 1.5pt'>  <p style='margin:0px !important; font-size:9pt' align='center' ><span style='font-size:9.0pt;color:#555555'>Discount Allowed @ "
								+ discountPercent + "%</span></p> </td>"
								+ "<td width='90' style='width:67.5pt;border-top:none;border-left:solid gray 1.0pt; border-bottom:solid gray 1.0pt;border-right:none; padding:1.5pt 1.5pt 1.5pt 1.5pt'> <p style='margin:0px !important; font-size:9pt' align='right' ><span style='font-size:9.0pt;color:#555555'>"
								+ numberToCurrencyConverter(iniatialDiscountAmount) + "</span></p> </td>"
								+ "<td style='border-top:none;border-left:solid gray 1.0pt;border-bottom:solid gray 1.0pt; border-right:none;padding:1.5pt 1.5pt 1.5pt 1.5pt'></td>"
								+ "<td style='border:solid gray 1.0pt;border-top:none;padding:1.5pt 1.5pt 1.5pt 1.5pt'> <p style='margin:0px !important; font-size:9pt' align='right' ><span style='font-size:9.0pt;color:#555555'>"
								+ numberToCurrencyConverter(dicountAmount) + "</span></p> </td></tr>");
						itplBillingDetail.append("<tr>"
								+ "<td colspan='4' style='border-top:none;border-left:solid gray 1.0pt; border-bottom:solid gray 1.0pt;border-right:none; padding:2.25pt 2.25pt 2.25pt 2.25pt'> <p style='margin:0px !important; font-size:9pt'><b><span style='font-size:9.0pt;color:#555555'>Taxable Value of Supply of Services</span></b></p> </td>"
								+ "<td style='border-top:none;border-left:solid gray 1.0pt;border-bottom:solid gray 1.0pt; border-right:none;padding:2.25pt 2.25pt 2.25pt 2.25pt'><p style='margin:0px !important; font-size:9pt' align='right' ><b><span style='font-size:9.0pt;color:#555555'>"
								+ numberToCurrencyConverter(iniatialTotal) + "</span></b></p> </td>"
								+ "<td style='border-top:none;border-left:solid gray 1.0pt;border-bottom:solid gray 1.0pt; border-right:none;padding:2.25pt 2.25pt 2.25pt 2.25pt'></td>"
								+ "<td style='border:solid gray 1.0pt;border-top:none;padding:2.25pt 2.25pt 2.25pt 2.25pt'> <p style='margin:0px !important; font-size:9pt' align='right' ><b><span style='font-size:9.0pt;color:#555555'>"
								+ numberToCurrencyConverter(netSubTotal) + "</span></b></p> </td></tr>" + "</table>");
						String itplBillingDetails = itplBillingDetail.toString();
						map.put("itplBillableInvoiceDetail", itplBillingDetails);

						itplGSTCalculation
								.append("<table  border='0' cellspacing='0' cellpadding='0' width='99%' style='width:707px;border-collapse:collapse;'>"
										+ "<tr>"
										+ "<td style='width:40%;border:solid gray 1.0pt;  padding:.75pt .75pt .75pt 3.75pt'> <p style='margin:0px !important; font-size:9pt'><span style='font-size:9.0pt;color:#555555'>Output GST Calculation</span></p> </td>"
										+ "<td style='width:60%;border:solid gray 1.0pt; padding: 0pt .75pt .75pt 0pt;'>");
						itplGSTCalculation
								.append("<table  border='0' cellspacing='0' cellpadding='0' width='99%' style='width:100%;border-collapse:collapse;'><tr>"
										+ "<td style='width:18.0%;border:solid gray 1.0pt;border-left: none;border-top: none; padding:.75pt .75pt .75pt 3.75pt'> <p style='margin:0px !important; font-size:9pt'><span style='font-size:9.0pt;color:#555555'>GST to be levied</span></p> </td>"
										+ "<td style='width:15.0%;border:solid gray 1.0pt;border-left: none;border-top: none; padding:.75pt .75pt .75pt 3.75pt'> <p style='margin:0px !important; font-size:9pt'><span style='font-size:9.0pt;color:#555555'>Rate of Tax</span></p> </td>"
										+ "<td style='width:15.0%;border:solid gray 1.0pt;border-left: none;border-top: none; padding:.75pt .75pt .75pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='center' ><span style='font-size:9.0pt;color:#555555'>Amount</span></p> </td>"
										+ "<td style='width:12.0%;border:solid gray 1.0pt;border-left: none;border-top: none; padding:.75pt .75pt .75pt 3.75pt'> <p style='margin:0px !important; font-size:9pt'><span style='font-size:9.0pt;color:#555555'></span></p> </td>"
										+ "<td style='width:15.0%;border:solid gray 1.0pt;border-right: none;border-top: none; padding:.75pt .75pt .75pt 3.75pt'> <p style='margin:0px !important; font-size:9pt'><span style='font-size:9.0pt;color:#555555'>Amount</span></p> </td>"
										+ "</tr>");

						Integer count = 0;
						if (cgst.compareTo(BigDecimal.ZERO) > 0) {
							count = 1;
							iniatialCgstAmount = iniatialTotal.multiply(cgst).divide(new BigDecimal(100)).setScale(0, BigDecimal.ROUND_HALF_UP);;
							itplGSTCalculation
									.append("<tr> <td width='80' style='width:60.0pt;border-top:none;border-left:none; border-right:solid gray 1.0pt;padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='center' ><span>CGST</span></p> </td>"
											+ "<td width='80' style='width:60.0pt;border-top:none;border-left:none; border-right:solid gray 1.0pt;padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='center' >"
											+ cgst + "%</p> </td>"
											+ "<td width='90' style='width:67.5pt;border-top:none;border-left:none; border-right: none;padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='right' >"
											+ numberToCurrencyConverter(iniatialCgstAmount) + "</p> </td> "
											+ "<td width='90' style='width:67.5pt;border-right:solid gray 1.0pt;border-left:solid gray 1.0pt;border-top:none;padding:1.5pt 1.5pt 1.5pt 3.75pt'> </td>"
											+ "<td width='90' style='width:67.5pt;border-top:none;border-left:none; padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='right' >"
											+ numberToCurrencyConverter(cgstAmount) + "</p> </td>" + "</tr>");
						}
						if (sgst.compareTo(BigDecimal.ZERO) > 0) {
							count = 1;
							iniatialSgstAmount = iniatialTotal.multiply(sgst).divide(new BigDecimal(100)).setScale(0, BigDecimal.ROUND_HALF_UP);;
							itplGSTCalculation
									.append("<tr> <td width='80' style='width:60.0pt;border-top:none;border-left:none; border-right:solid gray 1.0pt;padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='center' ><span>SGST</span></p> </td>"
											+ "<td width='80' style='width:60.0pt;border-top:none;border-left:none; border-right:solid gray 1.0pt;padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='center' >"
											+ sgst + "%</p> </td>"
											+ "<td width='90' style='width:67.5pt;border-top:none;border-left:none; border-right: none;padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='right' >"
											+ numberToCurrencyConverter(iniatialSgstAmount) + "</p> </td> "
											+ "<td width='90' style='width:67.5pt;border-right:solid gray 1.0pt;border-left:solid gray 1.0pt;border-top:none;padding:1.5pt 1.5pt 1.5pt 3.75pt'> </td>"
											+ "<td width='90' style='width:67.5pt;border-top:none;border-left:none; padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='right' >"
											+ numberToCurrencyConverter(sgstAmount) + "</p> </td>" + "</tr>");
						}
						if (igst.compareTo(BigDecimal.ZERO) > 0) {
							count = 1;
							iniatialIgstAmount = iniatialTotal.multiply(igst).divide(new BigDecimal(100)).setScale(0, BigDecimal.ROUND_HALF_UP);;
							itplGSTCalculation
									.append("<tr> <td width='80' style='width:60.0pt;border-top:none;border-left:none; border-right:solid gray 1.0pt;padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='center' ><span>IGST</span></p> </td>"
											+ "<td width='80' style='width:60.0pt;border-top:none;border-left:none; border-right:solid gray 1.0pt;padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='center' >"
											+ igst + "%</p> </td>"
											+ "<td width='90' style='width:67.5pt;border-top:none;border-left:none; border-right: none;padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='right' >"
											+ numberToCurrencyConverter(iniatialIgstAmount) + "</p> </td> "
											+ "<td width='90' style='width:67.5pt;border-right:solid gray 1.0pt;border-left:solid gray 1.0pt;border-top:none;padding:1.5pt 1.5pt 1.5pt 3.75pt'> </td>"
											+ "<td width='90' style='width:67.5pt;border-top:none;border-left:none; padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='right' >"
											+ numberToCurrencyConverter(igstAmount) + "</p> </td>" + "</tr>");
						}
						if (utgst.compareTo(BigDecimal.ZERO) > 0) {
							count = 1;
							iniatialUtgstAmount = iniatialTotal.multiply(utgst).divide(new BigDecimal(100)).setScale(0, BigDecimal.ROUND_HALF_UP);;
							itplGSTCalculation
									.append("<tr> <td width='80' style='width:60.0pt;border-top:none;border-left:none; border-right:solid gray 1.0pt;padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='center' ><span>UTGST</span></p> </td>"
											+ "<td width='80' style='width:60.0pt;border-top:none;border-left:none; border-right:solid gray 1.0pt;padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='center' >"
											+ utgst + "%</p> </td>"
											+ "<td width='90' style='width:67.5pt;border-top:none;border-left:none; border-right: none;padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='right' >"
											+ numberToCurrencyConverter(iniatialUtgstAmount) + "</p> </td> "
											+ "<td width='90' style='width:67.5pt;border-right:solid gray 1.0pt;border-left:solid gray 1.0pt;border-top:none;padding:1.5pt 1.5pt 1.5pt 3.75pt'> </td>"
											+ "<td width='90' style='width:67.5pt;border-top:none;border-left:none; padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='right' >"
											+ numberToCurrencyConverter(utgstAmount) + "</p> </td>" + "</tr>");
						}
						 iniatialAmount = iniatialIgstAmount.add(iniatialSgstAmount).add(iniatialCgstAmount) .add(iniatialUtgstAmount).add(iniatialTotal);
						if (count == 0) {
							itplGSTCalculation
									.append("<tr> <td width='80' style='width:60.0pt;border-top:none;border-left:none; border-right:solid gray 1.0pt;padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='center' ><span>Zero Rated Supply</span></p> </td>"
											+ "<td width='80' style='width:60.0pt;border-top:none;border-left:none; border-right:solid gray 1.0pt;padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='center' ><span>0</span></p> </td>"
											+ "<td width='90' style='width:67.5pt;border-top:none;border-left:none; border-right: none;padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='right' ><span>0</span></p> </td> "
											+ "<td width='90' style='width:67.5pt;border-right:solid gray 1.0pt;border-left:solid gray 1.0pt;border-top:none;padding:1.5pt 1.5pt 1.5pt 3.75pt'> </td>"
											+ "<td width='90' style='width:67.5pt;border-top:none;border-left:none; padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='right' >0</p> </td>"
											+ "</tr>");
						}
						itplGSTCalculation.append("</table></td></tr>" + "<tr>"
								+ "<td style='width:35%;border:solid gray 1.0pt;  vertical-align: text-bottom; padding:0px!important;'> <p style='margin:0px !important; font-size:9pt'><span style='font-size:9.0pt;color:#555555'><b>Total Value of Supply of Services (In Figure)</b></span></p> </td>"
								+ "<td style='width:65%;border:solid gray 1.0pt; text-align:right; padding:0px;'>");
						itplGSTCalculation.append("<table border='0' cellspacing='0' cellpadding='0' width='99%' style='width:100%;border-collapse:collapse;'><tr>"
										+ "<td style='width:18.0%;border: none;border-top: 0; padding:.75pt .75pt .75pt 3.75pt'> <p style='margin:0px !important; font-size:9pt'><span style='font-size:9.0pt;color:#555555'></span></p> </td>"
										+ "<td style='width:15.0%;border-right:solid gray 1.0pt;border-left: none;border-top: 0; padding:.75pt .75pt .75pt 3.75pt'> <p style='margin:0px !important; font-size:9pt'><span style='font-size:9.0pt;color:#555555'></span></p> </td>"
										+ "<td style='width:15.0%;border-right:solid gray 1.0pt; padding:.75pt .75pt .75pt 3.75pt'> <p style='margin:0px !important; text-align:right; font-size:9pt'><span style='font-size:9.0pt;color:#555555'>"
										+ numberToCurrencyConverter(iniatialAmount) + "</span></p> </td>"
										+ "<td style='width:12.0%;border-right:solid gray 1.0pt;padding:.75pt .75pt .75pt 3.75pt'> <p style='margin:0px !important; font-size:9pt'><span style='font-size:9.0pt;color:#555555'></span></p> </td>"
										+ "<td style='width:15.3%;text-align: right; padding:.75pt .75pt .75pt 3.75pt'> <p style='margin:0px !important; font-size:9pt'><span style='font-size:9.0pt;color:#555555'>"
										+ numberToCurrencyConverter(total) + "</span></p> </td>" + "</tr>");
						itplGSTCalculation.append("</table></td></tr>");
						itplGSTCalculation.append("<tr>"
								+ "<td style='border:solid gray 1.0pt;border-top:none;padding:2.25pt 2.25pt 2.25pt 3.75pt'> <p style='margin:0px !important; font-size:9pt'><b><span style='font-size:9.0pt;color:#555555'>Total Value of Supply of Services (In Words)</span></b></p> </td>"
								+ "<td style='border-top:none;border-left:none;border-bottom:solid gray 1.0pt; border-right:solid gray 1.0pt;padding:2.25pt 2.25pt 2.25pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='right' ><b>"
								+ amountInWord + "</b></p> </td>" + "</tr></table>");
						String itplGSTCalculations = itplGSTCalculation.toString();
						map.put("itplGSTCalculation", itplGSTCalculations);
					} else {
						itplBillingDetail
								.append("<table  border='0' cellspacing='0' cellpadding='0' style='width:99.7%;'><thead><tr>"
										+ "<td width='7%' style='width:7.0%;border:solid gray 1.0pt;background:#0065A4;'> <p style='margin:0px !important; font-size:9pt' align='center' ><b><span style='font-size:9.0pt;  color:#FFFFFF'>Sr&nbsp;No </span></b></p> </td>"
										+ "<td width='40%' style='width:40.0%;border:solid gray 1.0pt;background:#0065A4;'> <p style='margin:0px !important; font-size:9pt' align='center' ><b><span style='font-size:9.0pt;color:#FFFFFF'>Description of Services</span></b></p> </td>"
										+ "<td width='20%' style='width:20.0%;border:solid gray 1.0pt;background:#0065A4;'> <p style='margin:0px !important; font-size:9pt' align='center' ><b><span style='font-size:9.0pt;color:#FFFFFF'>Service Billing Details</span></b></p> </td>"
										+ "<td width='18%' style='width:18.0%;border:solid gray 1.0pt;background:#0065A4;'> <p style='margin:0px !important; font-size:9pt' align='center' ><b><span style='font-size:9.0pt;color:#FFFFFF'>Services Accounting Code</span></b></p> </td>"
										+ "<td width='15%' style='width:15.0%;border:solid gray 1.0pt;background:#0065A4;'> <p style='margin:0px !important; font-size:9pt' align='center' ><b><span style='font-size:9.0pt;color:#FFFFFF'>Billed Amount ("
										+ currencyCode + ")</span></b></p> </td>" + "</tr> </thead>");
						itplBillingDetail.append("<tr>"
								+ "<td width='80' style='width:60.0pt;border-top:none;border-left:solid gray 1.0pt; border-bottom:solid gray 1.0pt;border-right:none; padding:1.5pt 1.5pt 1.5pt 1.5pt'><p style='margin:0px !important; font-size:9pt' align='center' ><span style='font-size:9.0pt;color:#555555'>1</span></p> </td>"
								+ "<td width='80' style='width:60.0pt;border-top:none;border-left:solid gray 1.0pt; border-bottom:solid gray 1.0pt;border-right:none; padding:1.5pt 1.5pt 1.5pt 1.5pt'> <p style='margin:0px !important; font-size:9pt' align='center' ><span style='font-size:9.0pt;color:#555555'>Information technology (IT) design and development services</span></p> </td>"
								+ "<td width='80' style='width:60.0pt;border-top:none;border-left:solid gray 1.0pt; border-bottom:solid gray 1.0pt;border-right:none; padding:1.5pt 1.5pt 1.5pt 1.5pt'> <p style='margin:0px !important; font-size:9pt' align='center' ><span style='font-size:9.0pt;color:#555555'>As per Annexure-I</span></p> </td>"
								+ "<td width='90' style='width:67.5pt;border-top:none;border-left:solid gray 1.0pt; border-bottom:solid gray 1.0pt;border-right:none; padding:1.5pt 1.5pt 1.5pt 1.5pt'> <p style='margin:0px !important; font-size:9pt' align='right' ><span style='font-size:9.0pt;color:#555555'>998314</span></p> </td>"
								+ "<td width='100' style='width:75.0pt;border:solid gray 1.0pt;border-top:none;  padding:1.5pt 1.5pt 1.5pt 1.5pt'>  <p style='margin:0px !important; font-size:9pt' align='right'>");
						itplBillingDetail.append("<span style='font-size:9.0pt;color:#555555'>"+numberToCurrencyConverter(subTotal)+"</span>");
						itplBillingDetail.append("</p></td></tr>");
						itplBillingDetail.append("<tr> "
								+ "<td style='border-top:none;border-left:solid gray 1.0pt;border-bottom:solid gray 1.0pt; border-right:none;padding:1.5pt 1.5pt 1.5pt 1.5pt'>  <p style='margin:0px !important; font-size:9pt' align='center' ><span style='font-size:9.0pt;color:#555555'>2</span></p> </td>"
								+ "<td colspan='3' style='border-top:none;border-left:solid gray 1.0pt; border-bottom:solid gray 1.0pt;border-right:none; padding:1.5pt 1.5pt 1.5pt 1.5pt'>  <p style='margin:0px !important; font-size:9pt' align='center' ><span style='font-size:9.0pt;color:#555555'>Discount Allowed @ "
								+ discountPercent + "%</span></p> </td>"
								+ "<td style='border:solid gray 1.0pt;border-top:none;padding:1.5pt 1.5pt 1.5pt 1.5pt'> <p style='margin:0px !important; font-size:9pt' align='right' ><span style='font-size:9.0pt;color:#555555'>"
								+ numberToCurrencyConverter(dicountAmount) + "</span></p> </td></tr>");

						itplBillingDetail.append("<tr>"
								+ "<td colspan='4' style='border-top:none;border-left:solid gray 1.0pt; border-bottom:solid gray 1.0pt;border-right:none; padding:2.25pt 2.25pt 2.25pt 2.25pt'> <p style='margin:0px !important; font-size:9pt'><b><span style='font-size:9.0pt;color:#555555'>Taxable Value of Supply of Services</span></b></p> </td>"
								+ "<td style='border:solid gray 1.0pt;border-top:none;padding:2.25pt 2.25pt 2.25pt 2.25pt'> <p style='margin:0px !important; font-size:9pt' align='right' ><b><span style='font-size:9.0pt;color:#555555'>"
								+ numberToCurrencyConverter(netSubTotal) + "</span></b></p> </td></tr>" + "</table>");
						String itplBillingDetails = itplBillingDetail.toString();
						map.put("itplBillableInvoiceDetail", itplBillingDetails);
						itplGSTCalculation
								.append("<table  border='0' cellspacing='0' cellpadding='0' style='width:708px;border-collapse:collapse;'>"
										+ "<tr>"
										+ "<td style='width:35%;border:solid gray 1.0pt;  padding:.75pt .75pt .75pt 3.75pt'> <p style='margin:0px !important; font-size:9pt'><span style='font-size:9.0pt;color:#555555'>Output GST Calculation</span></p> </td>"
										+ "<td style='width:65%;border:solid gray 1.0pt; padding: 0pt .75pt .75pt 0pt;'>");
						itplGSTCalculation
								.append("<table  border='0' cellspacing='0' cellpadding='0' style='width:100%;border-collapse:collapse;'><tr>"
										+ "<td width='18%' style='width:18.0%;border:solid gray 1.0pt;border-left: none;border-top: none; padding:.75pt .75pt .75pt 3.75pt'> <p style='margin:0px !important; font-size:9pt'><span style='font-size:9.0pt;color:#555555'>GST to be levied</span></p> </td>"
										+ "<td width='15%' style='width:15.0%;border:solid gray 1.0pt;border-left: none;border-top: none; padding:.75pt .75pt .75pt 3.75pt'> <p style='margin:0px !important; font-size:9pt'><span style='font-size:9.0pt;color:#555555'>Rate of Tax</span></p> </td>"
										+ "<td width='15%' style='width:15.0%;border:solid gray 1.0pt;border-right: none;border-top: none; padding:.75pt .75pt .75pt 3.75pt'> <p style='margin:0px !important; font-size:9pt'><span style='font-size:9.0pt;color:#555555'>Amount</span></p> </td>"
										+ "</tr>");
						Integer count = 0;

						if (cgst != BigDecimal.ZERO) {
							count = 1;
							itplGSTCalculation.append("<tr> "
									+ "<td width='80' style='width:60.0pt;border-top:none;border-left:none; border-right:solid gray 1.0pt;padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='center' ><span>CGST</span></p> </td>"
									+ "<td width='80' style='width:60.0pt;border-top:none;border-left:none; border-right:solid gray 1.0pt;padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='center' >"
									+ cgst + "%</p> </td>"
									+ "<td width='90' style='width:67.5pt;border-top:none;border-left:none; padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='right' >"
									+ numberToCurrencyConverter(cgstAmount) + "</p> </td>" + "</tr>");
						}

						if (sgst != BigDecimal.ZERO) {
							count = 1;
							itplGSTCalculation.append("<tr> "
									+ "<td width='80' style='width:60.0pt;border-top:none;border-left:none; border-right:solid gray 1.0pt;padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='center' ><span>SGST</span></p> </td>"
									+ "<td width='80' style='width:60.0pt;border-top:none;border-left:none; border-right:solid gray 1.0pt;padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='center' >"
									+ sgst + "%</p> </td>"
									+ "<td width='90' style='width:67.5pt;border-top:none;border-left:none; padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='right' >"
									+ numberToCurrencyConverter(sgstAmount) + "</p> </td>" + "</tr>");
						}

						if (igst != BigDecimal.ZERO) {
							count = 1;
							itplGSTCalculation.append("<tr> "
									+ "<td width='80' style='width:60.0pt;border-top:none;border-left:none; border-right:solid gray 1.0pt;padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='center' ><span>IGST</span></p> </td>"
									+ "<td width='80' style='width:60.0pt;border-top:none;border-left:none; border-right:solid gray 1.0pt;padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='center' >"
									+ igst + "%</p> </td>"
									+ "<td width='90' style='width:67.5pt;border-top:none;border-left:none; padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='right' >"
									+ numberToCurrencyConverter(igstAmount) + "</p> </td>" + "</tr>");
						}

						if (utgst != BigDecimal.ZERO) {
							count = 1;
							itplGSTCalculation.append("<tr> "
									+ "<td width='80' style='width:60.0pt;border-top:none;border-left:none; border-right:solid gray 1.0pt;padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='center' ><span>UTGST</span></p> </td>"
									+ "<td width='80' style='width:60.0pt;border-top:none;border-left:none; border-right:solid gray 1.0pt;padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='center' >"
									+ utgst + "%</p> </td>"
									+ "<td width='90' style='width:67.5pt;border-top:none;border-left:none; padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='right' >"
									+ numberToCurrencyConverter(utgstAmount) + "</p> </td>" + "</tr>");
						}
						if (count == 0) {
							itplGSTCalculation.append("<tr> "
									+ "<td width='80' style='width:60.0pt;border-top:none;border-left:none; border-right:solid gray 1.0pt;padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='center' ><span>Zero Rated Supply</span></p> </td>"
									+ "<td width='80' style='width:60.0pt;border-top:none;border-left:none; border-right:solid gray 1.0pt;padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='center' ><span>0</span></p> </td>"
									+ "<td width='90' style='width:67.5pt;border-top:none;border-left:none; padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='right' >0</p> </td>"
									+ "</tr>");
						}
						itplGSTCalculation.append("</table></td></tr><tr>"
								+ "<td  style='border:solid gray 1.0pt;border-top:none;padding:2.25pt 2.25pt 2.25pt 3.75pt'> <p style='margin:0px !important; font-size:9pt'><b><span style='font-size:9.0pt;color:#555555'>Total Value of Supply of Services (In Figure)</span></b></p> </td>"
								+ "<td style='border-top:none;border-left:none;border-bottom:solid gray 1.0pt; border-right:solid gray 1.0pt;padding:2.25pt 2.25pt 2.25pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='right' ><b>"
								+ numberToCurrencyConverter(total) + "</b></p> </td></tr>");
						itplGSTCalculation.append("<tr>"
								+ "<td style='border:solid gray 1.0pt;border-top:none;padding:2.25pt 2.25pt 2.25pt 3.75pt'> <p style='margin:0px !important; font-size:9pt'><b><span style='font-size:9.0pt;color:#555555'>Total Value of Supply of Services (In Words)</span></b></p> </td>"
								+ "<td style='border-top:none;border-left:none;border-bottom:solid gray 1.0pt; border-right:solid gray 1.0pt;padding:2.25pt 2.25pt 2.25pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='right' ><b>"
								+ amountInWord + "</b></p> </td>" + "</tr></table>");
						String itplGSTCalculations = itplGSTCalculation.toString();
						map.put("itplGSTCalculation", itplGSTCalculations);
					}
				}
				


			} else if (invoiceType.equals("Expense Invoice") || invoiceType.equals("Inter-Unit Invoice")) {

				buf.append("<table name='date-table' style='float: left; text-align: center; width:99.7%'  cellpadding='0' cellspacing='0'>"
						+ "<tr>"
						+ "<td class='gridHeaderRow' align='center' width='100'><p style='margin-bottom:0px !important'>Client Name</p></td>"
						+ "<td class='gridHeaderRow' align='center'><p style='margin-bottom:0px !important'>Purpose&nbsp;of<br />Expense</p></td>"
						+ "<td class='gridHeaderRow' align='center'><p style='margin-bottom:0px !important'>Description</p></td>"
						+ "<td class='gridHeaderRow' align='center'><p style='margin-bottom:0px !important'>Start Date</p></td>"
						+ "<td class='gridHeaderRow' align='center'><p style='margin-bottom:0px !important'>End Date</p></td>"
						+ "<td class='gridHeaderRow' align='center' width='60'><p style='margin-bottom:0px !important'>Comments</p></td>"
						+ "<td class='gridHeaderRow' align='center'><p style='margin-bottom:0px !important'>Billed Amount <br/>("+currencyCode+")</p></td>"
						+ "</tr>");

				while (it.hasNext()) {
					InvoicesDetail invoicesDetail = it.next();
					if (invoicesDetail.getDescription() != null) {
						description = invoicesDetail.getDescription();
					}
					if (project.getAccountName() != null) {
						projectName = project.getAccountName();
					}
					if (invoicesDetail.getPurposeExpense() != null) {
						purposeExpense = invoicesDetail.getPurposeExpense();
					}
					if (invoicesDetail.getExpStartDate() != null) {
						expStartDate = DateConverter.changeDate2(invoicesDetail.getExpStartDate());
					}
					if (invoicesDetail.getExpEndDate() != null) {
						expEndDate = DateConverter.changeDate2(invoicesDetail.getExpEndDate());
					}
					if (invoicesDetail.getInitialBilledAmount() != null) {
						initialBilledAmount = invoicesDetail.getInitialBilledAmount();
						iniatialNetTotalAmount = iniatialNetTotalAmount.add(initialBilledAmount);
					}
					if (invoicesDetail.getComments() != null) {
						comments = invoicesDetail.getComments();
					}

					if (invoice.getSubtotal() != null) {
						subTotal = invoice.getSubtotal();
					}

					if (invoice.getDiscountAmt() != null) {
						discountAmt = invoice.getDiscountAmt();
					}

					if (invoice.getTaxAmt() != null) {
						taxAmt = invoice.getTaxAmt();
					}

					if (invoice.getRoundOff() != null) {
						roundOff = invoice.getRoundOff();
					}

					buf.append("<tr><td class='pnTrData'><p style='margin-bottom:0px !important'>").append(projectName)
							.append("</p></td><td class='trData'><p style='margin-bottom:0px !important'>")
							.append(purposeExpense)
							.append("</p></td><td class='trData'><p style='margin-bottom:0px !important'>")
							.append(description)
							.append("</p></td><td class='trRateData'><p style='margin-bottom:0px !important'>")
							.append(expStartDate)
							.append("</p></td><td class='trRateData'><p style='margin-bottom:0px !important'>")
							.append(expEndDate)
							.append("</p></td><td class='trBillAmt'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; <p style='margin-bottom:0px !important'>")
							.append(comments)
							.append("</p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;</td><td class='trRateData'>")
							.append("<p style='margin-bottom:0px !important'>"+currencySign+" "+numberToCurrencyConverter(initialBilledAmount)+"</p>")
							.append("</td></tr>");
				}

//				buf.append( "<tr><td class='footerSubTotalBorder' style='border-left: 1px solid #808080;' colspan ='6'><p style='margin-bottom:0px !important'>Sub-Total</p></td><td class='trSubTotalFooterBackGround'><p style='margin-bottom:0px !important'>")
//						.append(numberToCurrencyConverter(subTotal)+"</p></td></tr>");
//				buf.append( "<tr><td class='footerSubTotalBorder' style='border-left: 1px solid #808080;' colspan ='6'><p style='margin-bottom:0px !important'>Discount</p></td><td class='trSubTotalFooterBackGround'><p style='margin-bottom:0px !important'>")
//						.append(numberToCurrencyConverter(discountAmt)+"</p></td></tr>");
//				buf.append( "<tr><td class='footerSubTotalBorder' style='border-left: 1px solid #808080;' colspan ='6'><p style='margin-bottom:0px !important'>Tax</p></td><td class='trSubTotalFooterBackGround'><p style='margin-bottom:0px !important'>")
//						.append(numberToCurrencyConverter(taxAmt)+"</p></td></tr>");
//				buf.append( "<tr><td class='footerSubTotalBorder' style='border-left: 1px solid #808080;' colspan ='6'><p style='margin-bottom:0px !important'>Round Off</p></td><td class='trSubTotalFooterBackGround'><p style='margin-bottom:0px !important'>")
//						.append(roundOff+"</p></td></tr>");
				buf.append( "<tr style='font-weight:bold'><td class='footerSubTotalBorder'style='border-left: 1px solid #808080;' colspan ='6'><p style='margin-bottom:0px !important'>Total</p></td><td class='trSubTotalFooterBackGround'><p style='margin-bottom:0px !important'>")
						.append(numberToCurrencyConverter(iniatialNetTotalAmount)+" </p></td></tr>");
				buf.append("</table>");
				String expInvoiceDetail = buf.toString();
				map.put("expInvoiceDetail", expInvoiceDetail);

				itplEXPBillingDetail
						.append("<table  border='0' cellspacing='0' cellpadding='0' style='width:99.7%;'><thead><tr>"
								+ "<td width='7%' style='width:7.0%;border:solid gray 1.0pt;background:#0065A4;'> <p style='margin:0px !important; font-size:9pt' align='center' ><b><span style='font-size:9.0pt;  color:#FFFFFF'>Sr&nbsp;No </span></b></p> </td>"
								+ "<td width='40%' style='width:40.0%;border:solid gray 1.0pt;background:#0065A4;'> <p style='margin:0px !important; font-size:9pt' align='center' ><b><span style='font-size:9.0pt;color:#FFFFFF'>Description</span></b></p> </td>"
								+ "<td width='20%' style='width:20.0%;border:solid gray 1.0pt;background:#0065A4;'> <p style='margin:0px !important; font-size:9pt' align='center' ><b><span style='font-size:9.0pt;color:#FFFFFF'>Service Billing Details</span></b></p> </td>"
								+ "<td width='18%' style='width:18.0%;border:solid gray 1.0pt;background:#0065A4;'> <p style='margin:0px !important; font-size:9pt' align='center' ><b><span style='font-size:9.0pt;color:#FFFFFF'>Services Accounting Code</span></b></p> </td>"
								+ "<td width='15%' style='width:15.0%;border:solid gray 1.0pt;background:#0065A4;'> <p style='margin:0px !important; font-size:9pt' align='center' ><b><span style='font-size:9.0pt;color:#FFFFFF'>Billed Amount ("
								+ currencyCode + ")</span></b></p> </td>" + "</tr> </thead>");
				itplEXPBillingDetail.append("<tr>"
						+ "<td width='80' style='width:60.0pt;border-top:none;border-left:solid gray 1.0pt; border-bottom:solid gray 1.0pt;border-right:none; padding:1.5pt 1.5pt 1.5pt 1.5pt'><p style='margin:0px !important; font-size:9pt' align='center' ><span style='font-size:9.0pt;color:#555555'>1</span></p> </td>"
						+ "<td width='80' style='width:60.0pt;border-top:none;border-left:solid gray 1.0pt; border-bottom:solid gray 1.0pt;border-right:none; padding:1.5pt 1.5pt 1.5pt 1.5pt'> <p style='margin:0px !important; font-size:9pt' align='center' ><span style='font-size:9.0pt;color:#555555'></span></p> </td>"
						+ "<td width='80' style='width:60.0pt;border-top:none;border-left:solid gray 1.0pt; border-bottom:solid gray 1.0pt;border-right:none; padding:1.5pt 1.5pt 1.5pt 1.5pt'> <p style='margin:0px !important; font-size:9pt' align='center' ><span style='font-size:9.0pt;color:#555555'>As per Annexure-I</span></p> </td>"
						+ "<td width='90' style='width:67.5pt;border-top:none;border-left:solid gray 1.0pt; border-bottom:solid gray 1.0pt;border-right:none; padding:1.5pt 1.5pt 1.5pt 1.5pt'> <p style='margin:0px !important; font-size:9pt' align='right' ><span style='font-size:9.0pt;color:#555555'>9403</span></p> </td>"
						+ "<td width='100' style='width:75.0pt;border:solid gray 1.0pt;border-top:none;  padding:1.5pt 1.5pt 1.5pt 1.5pt'>  <p style='margin:0px !important; font-size:9pt' align='right'><span style='font-size:9.0pt;color:#555555'>");
				itplEXPBillingDetail.append(numberToCurrencyConverter(subTotal));
				itplEXPBillingDetail.append("</span></p> </td></tr>");
				itplEXPBillingDetail.append("<tr> "
						+ "<td style='border-top:none;border-left:solid gray 1.0pt;border-bottom:solid gray 1.0pt; border-right:none;padding:1.5pt 1.5pt 1.5pt 1.5pt'>  <p style='margin:0px !important; font-size:9pt' align='center' ><span style='font-size:9.0pt;color:#555555'>2</span></p> </td>"
						+ "<td colspan='3' style='border-top:none;border-left:solid gray 1.0pt; border-bottom:solid gray 1.0pt;border-right:none; padding:1.5pt 1.5pt 1.5pt 1.5pt'>  <p style='margin:0px !important; font-size:9pt' align='center' ><span style='font-size:9.0pt;color:#555555'>Discount Allowed @ "
						+ discountPercent + "%</span></p> </td>"
						+ "<td style='border:solid gray 1.0pt;border-top:none;padding:1.5pt 1.5pt 1.5pt 1.5pt'> <p style='margin:0px !important; font-size:9pt' align='right' ><span style='font-size:9.0pt;color:#555555'>"
						+ numberToCurrencyConverter(dicountAmount) + "</span></p> </td></tr>");

				itplEXPBillingDetail.append("<tr>"
						+ "<td colspan='4' style='border-top:none;border-left:solid gray 1.0pt; border-bottom:solid gray 1.0pt;border-right:none; padding:2.25pt 2.25pt 2.25pt 2.25pt'> <p style='margin:0px !important; font-size:9pt'><b><span style='font-size:9.0pt;color:#555555'>Taxable Value of Supply of Services</span></b></p> </td>"
						+ "<td style='border:solid gray  1.0pt;border-top:none;padding:2.25pt 2.25pt 2.25pt 2.25pt'> <p style='margin:0px !important; font-size:9pt' align='right' ><b><span style='font-size:9.0pt;color:#555555'>"
						+ numberToCurrencyConverter(netSubTotal) + "</span></b></p> </td></tr>" + "</table>");
				String itplEXPBillingDetails = itplEXPBillingDetail.toString();

				map.put("itplEXPBillingDetails", itplEXPBillingDetails);

				itplEXPGSTCalculation
						.append("<table  border='0' cellspacing='0' cellpadding='0' style='width:707px;border-collapse:collapse;'>"
								+ "<tr>"
								+ "<td style='width:35%;border:solid gray 1.0pt;  padding:.75pt .75pt .75pt 3.75pt'> <p style='margin:0px !important; font-size:9pt'><span style='font-size:9.0pt;color:#555555'>Output GST Calculation</span></p> </td>"
								+ "<td style='width:65%;border:solid gray 1.0pt; padding: 0pt .75pt .75pt 0pt;'>");
				itplEXPGSTCalculation
						.append("<table  border='0' cellspacing='0' cellpadding='0' width='99%' style='width:100%;border-collapse:collapse;'><tr>"
								+ "<td width='18%' style='width:18.0%;border:solid gray 1.0pt;border-left: none;border-top: none; padding:.75pt .75pt .75pt 3.75pt'> <p style='margin:0px !important; font-size:9pt'><span style='font-size:9.0pt;color:#555555'>GST to be levied</span></p> </td>"
								+ "<td width='15%' style='width:15.0%;border:solid gray 1.0pt;border-left: none;border-top: none; padding:.75pt .75pt .75pt 3.75pt'> <p style='margin:0px !important; font-size:9pt'><span style='font-size:9.0pt;color:#555555'>Rate of Tax</span></p> </td>"
								+ "<td width='15%' style='width:15.0%;border:solid gray 1.0pt;border-right: none;border-top: none; padding:.75pt .75pt .75pt 3.75pt'> <p style='margin:0px !important; font-size:9pt'><span style='font-size:9.0pt;color:#555555'>Amount</span></p> </td>"
								+ "</tr>");

				Integer count = 0;
				if (cgst.compareTo(BigDecimal.ZERO) > 0) {
					count = 1;
					itplEXPGSTCalculation.append("<tr> "
							+ "<td width='80' style='width:60.0pt;border-top:none;border-left:none; border-right:solid gray 1.0pt;padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='center' ><span>CGST</span></p> </td>"
							+ "<td width='80' style='width:60.0pt;border-top:none;border-left:none; border-right:solid gray 1.0pt;padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='center' >"
							+ cgst + "%</p> </td>"
							+ "<td width='90' style='width:67.5pt;border-top:none;border-left:none; padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='right' >"
							+ numberToCurrencyConverter(cgstAmount) + "</p> </td>" + "</tr>");
				}
				if (sgst.compareTo(BigDecimal.ZERO) > 0) {
					count = 1;
					itplEXPGSTCalculation.append("<tr> "
							+ "<td width='80' style='width:60.0pt;border-top:none;border-left:none; border-right:solid gray 1.0pt;padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='center' ><span>SGST</span></p> </td>"
							+ "<td width='80' style='width:60.0pt;border-top:none;border-left:none; border-right:solid gray 1.0pt;padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='center' >"
							+ sgst + "%</p> </td>"
							+ "<td width='90' style='width:67.5pt;border-top:none;border-left:none; padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='right' >"
							+ numberToCurrencyConverter(sgstAmount) + "</p> </td>" + "</tr>");
				}
				if (igst.compareTo(BigDecimal.ZERO) > 0) {
					count = 1;
					itplEXPGSTCalculation.append("<tr> "
							+ "<td width='80' style='width:60.0pt;border-top:none;border-left:none; border-right:solid gray 1.0pt;padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='center' ><span>IGST</span></p> </td>"
							+ "<td width='80' style='width:60.0pt;border-top:none;border-left:none; border-right:solid gray 1.0pt;padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='center' >"
							+ igst + "%</p> </td>"
							+ "<td width='90' style='width:67.5pt;border-top:none;border-left:none; padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='right' >"
							+ numberToCurrencyConverter(igstAmount) + "</p> </td>" + "</tr>");
				}
				if (utgst.compareTo(BigDecimal.ZERO) > 0) {
					count = 1;
					itplEXPGSTCalculation.append("<tr> "
							+ "<td width='80' style='width:60.0pt;border-top:none;border-left:none; border-right:solid gray 1.0pt;padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='center' ><span>UTGST</span></p> </td>"
							+ "<td width='80' style='width:60.0pt;border-top:none;border-left:none; border-right:solid gray 1.0pt;padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='center' >"
							+ utgst + "%</p> </td>"
							+ "<td width='90' style='width:67.5pt;border-top:none;border-left:none; padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='right' >"
							+ numberToCurrencyConverter(utgstAmount) + "</p> </td>" + "</tr>");
				}
				if (count == 0) {
					itplEXPGSTCalculation.append("<tr> "
							+ "<td width='80' style='width:60.0pt;border-top:none;border-left:none; border-right:solid gray 1.0pt;padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='center' ><span>Zero Rated Supply</span></p> </td>"
							+ "<td width='80' style='width:60.0pt;border-top:none;border-left:none; border-right:solid gray 1.0pt;padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='center' ><span>0</span></p> </td>"
							+ "<td width='90' style='width:67.5pt;border-top:none;border-left:none; padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='right' >0</p> </td>"
							+ "</tr>");
				}
				itplEXPGSTCalculation.append("</table></td></tr><tr>"
						+ "<td  style='border:solid gray 1.0pt;border-top:none;padding:2.25pt 2.25pt 2.25pt 3.75pt'> <p style='margin:0px !important; font-size:9pt'><b><span style='font-size:9.0pt;color:#555555'>Total Value of Supply of Services (In Figure)</span></b></p> </td>"
						+ "<td style='border-top:none;border-left:none;border-bottom:solid gray 1.0pt; border-right:solid gray 1.0pt;padding:2.25pt 2.25pt 2.25pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='right' ><b>"
						+ numberToCurrencyConverter(total) + "</b></p> </td></tr>");
				itplEXPGSTCalculation.append("<tr>"
						+ "<td style='border:solid gray 1.0pt;border-top:none;padding:2.25pt 2.25pt 2.25pt 3.75pt'> <p style='margin:0px !important; font-size:9pt'><b><span style='font-size:9.0pt;color:#555555'>Total Value of Supply of Services (In Words)</span></b></p> </td>"
						+ "<td style='border-top:none;border-left:none;border-bottom:solid gray 1.0pt; border-right:solid gray 1.0pt;padding:2.25pt 2.25pt 2.25pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='right' ><b>"
						+ amountInWord + "</b></p> </td>" + "</tr></table>");
				String itplEXPGSTCalculations = itplEXPGSTCalculation.toString();

				map.put("itplEXPGSTCalculations", itplEXPGSTCalculations);

			}

		}

		if (billingUnitId == 2) {
		if(invoiceType.equals("Services Invoice") || invoiceType.equals("Credit Note") || invoiceType.equals("Debit Note") || invoiceType.equals("Internal Invoice")){
			if (billing.equals("Fixed Bid Milestone")){

				buf.append("<table name='date-table' style='float: left;width:99.7%'  cellpadding='0' cellspacing='0'>"
						+ "<tr>"
						+ "<td class='gridHeaderRow' align='center' width='100'><p style='margin-bottom:0px !important'>Milestone</p></td>"
						+ "<td class='gridHeaderRow' align='center' width='70'><p style='margin-bottom:0px !important'>Description</p></td>"
						+ "<td class='gridHeaderRow' align='center' width='70'><p style='margin-bottom:0px !important'>Milestone&nbsp;Amount <br/>(In "+currencyCode+")</p></td>");
				
					buf.append("<td class='gridHeaderRow' align='center' width='80'><p style='margin-bottom:0px !important'>Exchange Rate</p></td>");	
				buf.append("<td class='gridHeaderRow' align='center' width='60'><p style='margin-bottom:0px !important'>Billed Amount <br/>(In "+exchangeCurrencyCode+")</p></td>"
						+ "</tr>");

				while (it.hasNext()) {
					InvoicesDetail invoicesDetail = it.next();

					if (invoicesDetail.getDescription() != null) {
						description = invoicesDetail.getDescription();
					}

					if (invoicesDetail.getResNameMilestone() != null) {
						resourceName = invoicesDetail.getResNameMilestone();
					}

					if (invoicesDetail.getAmount() != null) {
						amount = invoicesDetail.getAmount();
					}

					if (invoice.getSubtotal() != null) {
						subTotal = invoice.getSubtotal();
					}

					if (invoice.getDiscountAmt() != null) {
						discountAmount = invoice.getDiscountAmt();
					}

					if (invoice.getTotal() != null) {
						totalAmount = invoice.getTotal();
					}

					if (invoicesDetail.getInitialBilledAmount() != null) {
						iniatialBuildAmount = invoicesDetail.getInitialBilledAmount();
						iniatialBuildAmountTotal = iniatialBuildAmountTotal.add(iniatialBuildAmount).setScale(2, RoundingMode.HALF_UP);;
					}

					buf.append("<tr><td class='pnTrData'><p style='margin-bottom:0px !important'>"+resourceName)
							.append("</p></td><td class='trData'><p style='margin-bottom:0px !important'>")
							.append(description)
							.append("</p></td><td class='trRateData'><p style='margin-bottom:0px !important'>")
							.append(numberToCurrencyConverter(iniatialBuildAmount))
							.append("</p></td><td class='exRateCellClass'><p style='margin-bottom:0px !important'>")
							.append(exchangeRate)
							.append("</p></td><td class='trBillAmt'><p style='margin-bottom:0px !important'>")
							.append(numberToCurrencyConverter(amount)+"</p></td></tr>");
				}

				
					iniatialdiscountAmountTotal = discountPercent.multiply(iniatialBuildAmountTotal).divide(new BigDecimal(100))
							.setScale(2, RoundingMode.HALF_UP);
					iniatialNetTotalAmount = iniatialBuildAmountTotal.subtract(iniatialdiscountAmountTotal).setScale(2,
							RoundingMode.HALF_UP);
							if(sgdgst!=BigDecimal.ZERO) {
								gstPercent = sgdgst;
								gstTotal = sgdgstAmount;
							}else if(sgst!=BigDecimal.ZERO) {
								gstPercent = sgst;
								gstTotal = sgstAmount;
							}else if(igst!=BigDecimal.ZERO) {
								gstPercent = igst;
								gstTotal = igstAmount;
							}else if(utgst!=BigDecimal.ZERO) {
								gstPercent = utgst;
								gstTotal = utgstAmount;
							}else if(cgst!=BigDecimal.ZERO) {
								gstPercent = cgst;
								gstTotal = cgstAmount;
							}
							
							
					gstiniatialAmount = gstPercent.multiply(iniatialNetTotalAmount).divide(new BigDecimal(100)) 
							.setScale(2, RoundingMode.HALF_UP);
					iniatialTotal = gstiniatialAmount.add(iniatialNetTotalAmount).setScale(2, RoundingMode.HALF_UP);
				

				buf.append(
						"<tr><td class='tdColSpanFooter'><p style='margin-bottom:0px !important'></p></td><td class='footerSubTotalBorder'><p style='margin-bottom:0px !important'>Sub-Total</p></td><td class='trSubTotalFooterBackGround'><p style='margin-bottom:0px !important'>")
						.append(numberToCurrencyConverter(iniatialBuildAmountTotal))
						.append("</p></td><td class='emptyDiscountFooterBorder'><p style='margin-bottom:0px !important'></p></td><td class='trSubTotalFooterBackGround'><p style='margin-bottom:0px !important'>")
						.append(numberToCurrencyConverter(subTotal)+"</p></td></tr>");
				buf.append(
						"<tr><td class='tdColSpanFooter'><p style='margin-bottom:0px !important'></p></td><td class='footerSubTotalBorder'><p style='margin-bottom:0px !important'>Discount "+discountPercent+"%</p></td><td class='trSubTotalFooterBackGround' align='right'>")
						.append("<p style='margin-bottom:0px !important'>"+numberToCurrencyConverter(iniatialdiscountAmountTotal)+"</p>")
						.append("</td><td class='emptyDiscountFooterBorder'><p style='margin-bottom:0px !important'></p></td><td class='trSubTotalFooterBackGround'><p style='margin-bottom:0px !important'>")
						.append(numberToCurrencyConverter(discountAmount)+"</p></td></tr>");
				buf.append(
						"<tr><td class='tdColSpanFooter'><p style='margin-bottom:0px !important'></p></td><td class='footerDiscountBorder'><p style='margin-bottom:0px !important'>Value After Discount</p></td><td class='trDiscountFooterBackGround' style='text-align:right;'>")
						.append("<p style='margin-bottom:0px !important'>"+numberToCurrencyConverter(iniatialNetTotalAmount)+"</p>")
						.append("</td><td class='emptyDiscountFooterBorder'><p style='margin-bottom:0px !important'></p></td><td class='trDiscountFooterBackGround'><p style='margin-bottom:0px !important'>")
						.append(numberToCurrencyConverter(netSubTotal)+"</p></td></tr>");
				buf.append(
						"<tr><td class='tdColSpanFooter'><p style='margin-bottom:0px !important'></p></td><td class='footerServiceTaxBorder'><p style='margin-bottom:0px !important'>GST  "
								+ gstPercent
								+ "%</p></td><td class='trServiceTaxFooterBackGround' style='text-align:right;'>")
						.append("<p style='margin-bottom:0px !important'>"+numberToCurrencyConverter(gstiniatialAmount)+"</p></td>")
						.append("<td class='emptyDiscountFooterBorder'><p style='margin-bottom:0px !important'></p></td><td class='trServiceTaxFooterBackGround'><p style='margin-bottom:0px !important'>")
						.append(numberToCurrencyConverter(gstTotal)+"</p></td></tr>");
				buf.append(
						"<tr><td class='tdColSpanFooter'><p style='margin-bottom:0px !important'></p></td><td class='footerTotalBorder'><p style='margin-bottom:0px !important'>Total</p></td><td class='trTotalFooterBackGround' style='font-weight:bold;text-align:right;'><p style='margin-bottom:0px !important'>")
						.append(numberToCurrencyConverter(iniatialTotal)+"</p></td>")
						.append("<td class='emptyTotalFooterBorder'><p style='margin-bottom:0px !important'></p></td><td class='trTotalFooterBackGround'><p style='margin-bottom:0px !important'>")
						.append(numberToCurrencyConverter(totalAmount)+"</p></td></tr>");
				buf.append("</table>");
				String mdInvoiceDetail = buf.toString();
				map.put("mdInvoiceDetail", mdInvoiceDetail);
			} else {

				if (bankType != "" && bankType.equals("Domestic")) {
					map.put("signature", "Authorised Signatory");
					map.put("for", "For InfoCepts PTE Ltd");
				}

				buf.append("<table name='date-table' style='float: left;width:99.7%'  cellpadding='0' cellspacing='0'>"
						+ "<tr>"
						+ "<td class='gridHeaderRow' align='center' width='70'><p style='margin-bottom:0px !important'>Role</p></td>"
						+ "<td class='gridHeaderRow' align='center' width='70'><p style='margin-bottom:0px !important'>&nbsp;&nbsp;Associate&nbsp;Name&nbsp;&nbsp;</p></td>"
						+ "<td class='gridHeaderRow' align='center' colspan='2' width='70'><p style='margin-bottom:0px !important'>Period</p>"
						+ "<table style='width:100%'><tr>"
						+ "<td class='fromPeriodColumn' style='width:50%'><p style='margin-bottom:0px !important;' >From</p></td>"
						+ "<td class='toPeriodColumn' style='width:50%'><p style='margin-bottom:0px !important;'>To</p></td>"
						+ "</tr></table>" + "</td>"
						+ "<td class='gridHeaderRow' align='center' width='80'><p style='margin-bottom:0px !important'>Rate <br/>&nbsp;&nbsp;&nbsp;(In&nbsp;"+currencyCode+")&nbsp;&nbsp;&nbsp;</p></td>"
						+ "<td class='gridHeaderRow' align='center' width='30'><p style='margin-bottom:0px !important'>Quantity <br/>&nbsp;&nbsp;(In&nbsp;Hours)&nbsp;&nbsp;</p></td>"
						+ "<td class='gridHeaderRow' align='center' width='50'><p style='margin-bottom:0px !important'>Billed Amount <br/>&nbsp;&nbsp;(In&nbsp;"+currencyCode+")&nbsp;&nbsp;</p></td>"
						+ "<td class='gridHeaderRow' align='center' width='50'><p style='margin-bottom:0px !important'>Exchange Rate</p></td>"
						+ "<td class='gridHeaderRow' align='center' width='60'><p style='margin-bottom:0px !important'>Billed Amount <br/>&nbsp;&nbsp;(In&nbsp;"+exchangeCurrencyCode+")&nbsp;&nbsp;</p></td>"
						+ "</tr>");

				while (it.hasNext()) {
					InvoicesDetail invoicesDetail = it.next();
					if (invoicesDetail.getInfoCeptsRole() != null) {
						infoCeptsRole = invoicesDetail.getInfoCeptsRole();
					}
					if (invoicesDetail.getClientRole() != null) {
						clientRole = invoicesDetail.getClientRole();
					}
					if (invoicesDetail.getResNameMilestone() != null) {
						resourceName = invoicesDetail.getResNameMilestone();
					}
					if (invoice.getPeriodStartDate() != null) {
						sDate = DateConverter.changeDate2(invoice.getPeriodStartDate());
					}
					if (invoice.getPeriodEndDate() != null) {
						eDate = DateConverter.changeDate2(invoice.getPeriodEndDate());
					}
					if (invoicesDetail.getBillableRate() != null) {
						billableRate = invoicesDetail.getBillableRate();
					}
					if (invoicesDetail.getTsHrs() != null) {
						tsHrs = invoicesDetail.getTsHrs();
						quantityHoursTotal = quantityHoursTotal.add(tsHrs);
					}
					if (invoicesDetail.getAmount() != null) {
						amount = invoicesDetail.getAmount();
					}
					if (invoicesDetail.getInitialBilledAmount() != null) {
						iniatialBuildAmount = invoicesDetail.getInitialBilledAmount();
						iniatialBuildAmountTotal = iniatialBuildAmountTotal.add(iniatialBuildAmount);
					}
					if (invoice.getSubtotal() != null) {
						subtotal = invoice.getSubtotal();
					}
					if (invoice.getDiscountAmt() != null) {
						discountAmount = invoice.getDiscountAmt();
					}
					if (invoice.getTotal() != null) {
						totalAmount = invoice.getTotal();
					}
					if (invoice.getNetSubTotal() != null) {
						netSubTotal = invoice.getNetSubTotal();
					}
					buf.append("<tr><td class='pnTrData'><p style='margin-bottom:0px !important'>")
							.append(clientRole)
							.append("</p></td><td class='trData'><p style='margin-bottom:0px !important'>")
							.append(resourceName)
							.append("</p></td><td class='trData' style='width:50%'><p style='margin-bottom:0px !important'>")
							.append(sDate)
							.append("</p></td><td class='trData' style='width:50%'><p style='margin-bottom:0px !important'>")
							.append(eDate)
							.append("</p></td><td class='trRateData'><p style='margin-bottom:0px !important'>")
							.append(billableRate)
							.append("</p></td><td class='trData'><p style='margin-bottom:0px !important'>")
							.append(tsHrs)
							.append("</p></td><td class='trBillAmt'>")
							.append("<p style='margin-bottom:0px !important'>"+numberToCurrencyConverter(iniatialBuildAmount)+"</p>")
							.append("</td><td class='exRateCellClass'><p style='margin-bottom:0px !important'>")
							.append(exchangeRate)
							.append("</p></td><td class='trBillAmt'><p style='margin-bottom:0px !important'>")
							.append(numberToCurrencyConverter(amount)+"</p></td></tr>");
				}

				discountAmountTotal = discountPercent.multiply(iniatialBuildAmountTotal).divide(new BigDecimal(100))
						.setScale(2, RoundingMode.HALF_UP);
				iniatialNetTotalAmount = iniatialBuildAmountTotal.subtract(discountAmountTotal).setScale(2,
						RoundingMode.HALF_UP);
				if(sgdgst!=BigDecimal.ZERO) {
					gstPercent = sgdgst;
					gstTotal = sgdgstAmount;
				}else if(sgst!=BigDecimal.ZERO) {
					gstPercent = sgst;
					gstTotal = sgstAmount;
				}else if(igst!=BigDecimal.ZERO) {
					gstPercent = igst;
					gstTotal = igstAmount;
				}else if(utgst!=BigDecimal.ZERO) {
					gstPercent = utgst;
					gstTotal = utgstAmount;
				}else if(cgst!=BigDecimal.ZERO) {
					gstPercent = cgst;
					gstTotal = cgstAmount;
				}
				
				
		gstiniatialAmount = gstPercent.multiply(iniatialNetTotalAmount).divide(new BigDecimal(100)) 
				.setScale(2, RoundingMode.HALF_UP);
		iniatialTotal = gstiniatialAmount.add(iniatialNetTotalAmount).setScale(2, RoundingMode.HALF_UP);
				
				buf.append(
						"<tr><td colspan='4' class='tdColSpanFooter'><p style='margin-bottom:0px !important'></p></td><td class='footerSubTotalBorder'><p style='margin-bottom:0px !important'>Sub-Total</p></td>")
						.append("<td class='emptySubTotalFooterBorder'>")
						.append("<p style='margin-bottom:0px !important'>"+quantityHoursTotal+"</p>")
						.append("</td><td class='trSubTotalFooterBackGround'>")
						.append("<p style='margin-bottom:0px !important'>"+numberToCurrencyConverter(iniatialBuildAmountTotal)+"</p>")
						.append("</td><td class='emptyDiscountFooterBorder'><p style='margin-bottom:0px !important'></p></td>")
						.append("<td class='trSubTotalFooterBackGround'>")
						.append("<p style='margin-bottom:0px !important'>"+numberToCurrencyConverter(subtotal)+"</p></td></tr>");
				buf.append(
						"<tr><td colspan='4' class='tdColSpanFooter'><p style='margin-bottom:0px !important'></p></td><td class='footerSubTotalBorder'><p style='margin-bottom:0px !important'>Discount "
								+ discountPercent
								+ "%</p></td><td class='emptySubTotalFooterBorder'><p style='margin-bottom:0px !important'>")
						.append("</p></td><td class='trSubTotalFooterBackGround' align='right'>")
						.append("<p style='margin-bottom:0px !important'>"+numberToCurrencyConverter(discountAmountTotal)+"</p>")
						.append("</td><td class='emptyDiscountFooterBorder'><p style='margin-bottom:0px !important'></p></td>")
						.append("<td class='trSubTotalFooterBackGround'><p style='margin-bottom:0px !important'>")
						.append(numberToCurrencyConverter(discountAmount)+"</p></td></tr>");
				buf.append(
						"<tr><td colspan='4' class='tdColSpanFooter'><p style='margin-bottom:0px !important'></p></td><td class='footerSubTotalBorder'><p style='margin-bottom:0px !important'>Value After Discount</p></td><td class='emptySubTotalFooterBorder'><p style='margin-bottom:0px !important'>")
						.append("</p></td><td class='trSubTotalFooterBackGround' align='right'>")
						.append("<p style='margin-bottom:0px !important'>"+numberToCurrencyConverter(iniatialNetTotalAmount)+"</p>")
						.append("</td><td class='emptyDiscountFooterBorder'><p style='margin-bottom:0px !important'></p></td>")
						.append("<td class='trSubTotalFooterBackGround'>")
						.append("<p style='margin-bottom:0px !important'>"+numberToCurrencyConverter(netSubTotal)+"</p></td></tr>");
				buf.append(
						"<tr><td colspan='4' class='tdColSpanFooter'><p style='margin-bottom:0px !important'></p></td><td class='footerDiscountBorder'><p style='margin-bottom:0px !important'>GST "
								+ gstPercent
								+ "%</p></td><td class='emptyDiscountFooterBorder'><p style='margin-bottom:0px !important'>")
						.append("</p></td><td class='trDiscountFooterBackGround' style='text-align:right;'>")
						.append("<p style='margin-bottom:0px !important'>"+numberToCurrencyConverter(gstiniatialAmount)+"</p>")
						.append("</td><td class='emptyDiscountFooterBorder'><p style='margin-bottom:0px !important'></p></td>")
						.append("<td class='trDiscountFooterBackGround'><p style='margin-bottom:0px !important'>")
						.append(numberToCurrencyConverter(gstTotal)+"</p></td></tr>");
				buf.append(
						"<tr><td colspan='4' class='tdColSpanFooter'><p style='margin-bottom:0px !important'></p></td><td class='footerTotalBorder'><p style='margin-bottom:0px !important'>Total</p></td><td class='emptyTotalFooterBorder'><p style='margin-bottom:0px !important'>")
						.append("</p></td><td class='trTotalFooterBackGround' style='text-align:right;'>")
						.append("<p style='margin-bottom:0px !important'>"+numberToCurrencyConverter(iniatialTotal)+"</p>")
						.append("</td><td class='emptyTotalFooterBorder'><p style='margin-bottom:0px !important'></p></td>")
						.append("<td class='trTotalFooterBackGround'><p style='margin-bottom:0px !important'>")
						.append(numberToCurrencyConverter(totalAmount)+"</p></td></tr>");
				buf.append("</table>");
				String invoiceDetail = buf.toString();
				map.put("invoiceDetail", invoiceDetail);

			}
		}else if(invoiceType.equals("Expense Invoice")) {
				pteExpenseDetail.append("<table name='date-table' style='float: left;width:99.7%'  cellpadding='0' cellspacing='0'>"
						+ "<tr>"
						+ "<td class='gridHeaderRow' align='center' width='100'><p style='margin-bottom:0px !important'>Client Name</p></td>"
						+ "<td class='gridHeaderRow' align='center'><p style='margin-bottom:0px !important'>Purpose&nbsp;of<br />Expense</p></td>"
						+ "<td class='gridHeaderRow' align='center'><p style='margin-bottom:0px !important'>Description</p></td>"
						+ "<td class='gridHeaderRow' align='center'><p style='margin-bottom:0px !important'>Start Date</p></td>"
						+ "<td class='gridHeaderRow' align='center'><p style='margin-bottom:0px !important'>End Date</p></td>"
						+"<td class='gridHeaderRow' align='center' width='60'><p style='margin-bottom:0px !important'>Comments</p></td>");
						
				if (exchangeRate != BigDecimal.ZERO && exchangeRate != BigDecimal.ONE) {
				pteExpenseDetail.append("<td class='gridHeaderRow' align='center'><p style='margin-bottom:0px !important'>Billed Amount <br/>("+currencyCode+")</p></td>"
						+"<td class='gridHeaderRow' align='center'><p style='margin-bottom:0px !important'>Exchange Rate</p></td>");
						}
				pteExpenseDetail.append("<td class='gridHeaderRow' align='center' width='60'><p style='margin-bottom:0px !important'>Billed Amount <br/>("+exchangeCurrencyCode+")</p></td>"
						+ "</tr>");

				while (it.hasNext()) {
					InvoicesDetail invoicesDetail = it.next();
					if (invoicesDetail.getDescription() != null) {
						description = invoicesDetail.getDescription();
					}

					if (project.getAccountName() != null) {
						projectName = project.getAccountName();
					}
					if (invoicesDetail.getPurposeExpense() != null) {
						purposeExpense = invoicesDetail.getPurposeExpense();
					}
					if (invoicesDetail.getExpStartDate() != null) {
						expStartDate = DateConverter.changeDate2(invoicesDetail.getExpStartDate());
					}
					if (invoicesDetail.getExpEndDate() != null) {
						expEndDate = DateConverter.changeDate2(invoicesDetail.getExpEndDate());
					}
					if (invoicesDetail.getAmount() != null) {
						amount = invoicesDetail.getAmount();
					}
					if (invoicesDetail.getComments() != null) {
						comments = invoicesDetail.getComments();
					}

					if (invoicesDetail.getInitialBilledAmount() != null) {
						initialBilledAmount = invoicesDetail.getInitialBilledAmount();
					}

					if (invoice.getSubtotal() != null) {
						subTotal = invoice.getSubtotal();
					}

					if (invoice.getDiscountAmt() != null) {
						discountAmt = invoice.getDiscountAmt();
					}

					if(invoice.getFlatDiscountPer()!=null) {
						discountPercent = invoice.getFlatDiscountPer();
					}
					
					if (invoice.getTax() != null) {
						taxPercent = invoice.getTax();
					}
					
					if (invoice.getTaxAmt() != null) {
						taxAmt = invoice.getTaxAmt();
					}

					if (invoice.getTotal() != null) {
						total = invoice.getTotal();
					}
					pteExpenseDetail.append("<tr><td class='pnTrData'><p style='margin-bottom:0px !important'>").append(projectName)
							.append("</p></td><td class='trData'><p style='margin-bottom:0px !important'>")
							.append(purposeExpense)
							.append("</p></td><td class='trData'><p style='margin-bottom:0px !important'>"+description)
							.append("</p></td><td class='trRateData'><p style='margin-bottom:0px !important'>"+expStartDate)
							.append("</p></td><td class='trRateData'><p style='margin-bottom:0px !important'>"+expEndDate)
							.append("</p></td><td class='trBillAmt'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;<p style='margin-bottom:0px !important'>"+comments).append("</p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;</td>");
					
					if (exchangeRate != BigDecimal.ZERO && exchangeRate != BigDecimal.ONE) {
						initialBilledAmount = amount.divide(exchangeRate,2, RoundingMode.HALF_UP);
						iniatialTotal = iniatialTotal.add(initialBilledAmount);
					pteExpenseDetail.append("</p></td><td class='trData'><p style='margin-bottom:0px !important'>"+currencySign+""+numberToCurrencyConverter(initialBilledAmount))
						.append("</p></td><td class='trData'><p style='margin-bottom:0px !important'>"+exchangeRate);
					}
					pteExpenseDetail.append("</p></td><td class='trData'><p style='margin-bottom:0px !important'>"+exchangeCurrencySign+""+numberToCurrencyConverter(amount))
							.append("</tr>");
				}
				if(exchangeRate != BigDecimal.ZERO && exchangeRate != BigDecimal.ONE) {
					if(discountPercent!=null){
						discountAmountTotal = iniatialTotal.multiply(discountPercent).divide(new BigDecimal(100), RoundingMode.HALF_UP);
					}
					if(taxPercent!=null){
						iniatialTaxAmount = iniatialTotal.multiply(taxPercent).divide(new BigDecimal(100), RoundingMode.HALF_UP);
					}
					iniatialNetTotalAmount = iniatialTotal.subtract(discountAmountTotal).add(iniatialTaxAmount);
				pteExpenseDetail.append("<tr><td class='footerSubTotalBorder' colspan ='6'><p style='margin-bottom:0px !important'>Sub-Total</p></td><td class='trSubTotalFooterBackGround'><p style='margin-bottom:0px !important'>")
					.append(currencySign+""+numberToCurrencyConverter(iniatialTotal)+"</p></td><td class='trSubTotalFooterBackGround'></td>")
					.append("<td class='trSubTotalFooterBackGround'><p style='margin-bottom:0px !important'>")
					.append(exchangeCurrencySign+""+numberToCurrencyConverter(subTotal)+"</p></td></tr>");
				pteExpenseDetail.append(
					"<tr><td class='footerSubTotalBorder' colspan ='6'><p style='margin-bottom:0px !important'>Discount "+discountPercent+"%</p></td><td class='trSubTotalFooterBackGround'><p style='margin-bottom:0px !important'>")
					.append(currencySign+""+numberToCurrencyConverter(discountAmountTotal)+"</p></td><td class='trSubTotalFooterBackGround'></td>")
					.append("<td class='trSubTotalFooterBackGround'><p style='margin-bottom:0px !important'>")
					.append(exchangeCurrencySign+""+numberToCurrencyConverter(discountAmt)+"</p></td></tr>");
				pteExpenseDetail.append(
					"<tr><td class='footerSubTotalBorder' colspan ='6'><p style='margin-bottom:0px !important'>Tax</p></td><td class='trSubTotalFooterBackGround'><p style='margin-bottom:0px !important'>")
					.append(currencySign+""+numberToCurrencyConverter(iniatialTaxAmount)+"</p></td><td class='trSubTotalFooterBackGround'></td>")
					.append("<td class='trSubTotalFooterBackGround'><p style='margin-bottom:0px !important'>")
					.append(exchangeCurrencySign+""+numberToCurrencyConverter(taxAmt)+"</p></td></tr>");
				pteExpenseDetail.append(
					"<tr style='font-weight:bold'><td class='footerDiscountBorder' colspan ='6'><p style='margin-bottom:0px !important'>Total</p></td><td class='trSubTotalFooterBackGround'><p style='margin-bottom:0px !important'>")
					.append(currencySign+""+numberToCurrencyConverter(iniatialNetTotalAmount)+"</p></td><td class='trSubTotalFooterBackGround'></td>")
					.append("<td class='trSubTotalFooterBackGround'><p style='margin-bottom:0px !important'>")
					.append(exchangeCurrencySign+""+numberToCurrencyConverter(total)+"</p></td></tr>");
				}else{
				pteExpenseDetail.append("<tr><td class='footerSubTotalBorder' colspan ='6'><p style='margin-bottom:0px !important'>Sub-Total</p></td>")
					.append("<td class='trSubTotalFooterBackGround'><p style='margin-bottom:0px !important'>")
					.append(currencySign+""+numberToCurrencyConverter(subTotal)+"</p></td></tr>");
				pteExpenseDetail.append(
					"<tr><td class='footerSubTotalBorder' colspan ='6'><p style='margin-bottom:0px !important'>Discount "+discountPercent+"%</p></td>")
					.append("<td class='trSubTotalFooterBackGround'><p style='margin-bottom:0px !important'>")
					.append(currencySign+""+numberToCurrencyConverter(discountAmt)+"</p></td></tr>");
				pteExpenseDetail.append(
					"<tr><td class='footerSubTotalBorder' colspan ='6'><p style='margin-bottom:0px !important'>Tax</p></td>")
					.append("<td class='trSubTotalFooterBackGround'><p style='margin-bottom:0px !important'>")
					.append(currencySign+""+numberToCurrencyConverter(taxAmt)+"</p></td></tr>");
				pteExpenseDetail.append(
					"<tr style='font-weight:bold'><td class='footerDiscountBorder' colspan ='6'><p style='margin-bottom:0px !important'>Total</p></td>")
					.append("<td class='trSubTotalFooterBackGround'><p style='margin-bottom:0px !important'>")
					.append(currencySign+""+numberToCurrencyConverter(total)+"</p></td></tr>");
				}
				pteExpenseDetail.append("</table>");
				String expInvoiceDetail = pteExpenseDetail.toString();
				map.put("expInvoiceDetail", expInvoiceDetail);
			} else if(invoiceType.equals("License Invoice")){				

				buf.append("<table name='date-table' style='float: left;width:99.7%'  cellpadding='0' cellspacing='0'>"
						+ "<tr>"
						+ "<td class='gridHeaderRow' align='center' width='70'><p style='margin-bottom:0px !important'>Description</p></td>"
						+ "<td class='gridHeaderRow' align='center' colspan='2'><p style='margin:0px !important;width:150px !important;'>Period</p>"
						+ "<table style='width:100%'><tr>"
						+ "<td class='fromPeriodColumn' style='width: 50%;'><p style='margin:0px !important;' >From</p></td>"
						+ "<td class='toPeriodColumn'><p style='margin:0px !important;'>To</p></td>"
						+ "</tr></table>" + "</td>"
						+ "<td class='gridHeaderRow' align='center' width='70'><p style='margin-bottom:0px !important'>Milestone&nbsp;Amount <br/>(In "+currencyCode+")</p></td>");
					buf.append("<td class='gridHeaderRow' align='center' width='80'><p style='margin-bottom:0px !important'>Exchange Rate</p></td>");	
				
				
				buf.append("<td class='gridHeaderRow' align='center' width='60'><p style='margin-bottom:0px !important'>Billed Amount <br/>(In "+exchangeCurrencyCode+")</p></td>"
						+ "</tr>");

				while (it.hasNext()) {
					InvoicesDetail invoicesDetail = it.next();

					if (invoicesDetail.getDescription() != null) {
						description = invoicesDetail.getDescription();
					}

					if (invoicesDetail.getResNameMilestone() != null) {
						resourceName = invoicesDetail.getResNameMilestone();
					}

					if (invoicesDetail.getAmount() != null) {
						amount = invoicesDetail.getAmount();
					}
					
					if(invoicesDetail.getTsHrs() != null) {
						tsHrs = invoicesDetail.getTsHrs();
					}
					
					if (invoice.getSubtotal() != null) {
						subTotal = invoice.getSubtotal();
					}
					
					if (invoice.getPeriodStartDate() != null) {
						sDate = DateConverter.changeDate2(invoice.getPeriodStartDate());
					}

					if (invoice.getPeriodEndDate() != null) {
						eDate = DateConverter.changeDate2(invoice.getPeriodEndDate());
					}

					if (invoice.getDiscountAmt() != null) {
						discountAmount = invoice.getDiscountAmt();
					}

					if (invoice.getTotal() != null) {
						totalAmount = invoice.getTotal();
					}

					if (invoicesDetail.getInitialBilledAmount() != null) {
						iniatialBuildAmount = invoicesDetail.getInitialBilledAmount();
						iniatialBuildAmountTotal = iniatialBuildAmountTotal.add(iniatialBuildAmount);
					}

					buf.append("<tr><td class='pnTrData'><p style='margin-bottom:0px !important'>")
							.append(description)
							.append("</p></td><td class='trData' style='width:50%'><p style='margin-bottom:0px !important'>")
							.append(sDate)
							.append("</p></td><td class='trData' style='width:50%'><p style='margin:0px !important'>")
							.append(eDate)
							.append("</p></td><td class='trRateData'><p style='margin-bottom:0px !important'>")
							.append(iniatialBuildAmount)
							.append("</p></td><td class='exRateCellClass'><p style='margin-bottom:0px !important'>");
					buf.append(exchangeRate);
					buf.append("</p></td><td class='trBillAmt'><p style='margin-bottom:0px !important'>")
							.append(numberToCurrencyConverter(amount)+"</p></td></tr>");
				}

				
					iniatialdiscountAmountTotal = discountPercent.multiply(iniatialBuildAmountTotal).divide(new BigDecimal(100))
							.setScale(2, RoundingMode.HALF_UP);
					iniatialNetTotalAmount = iniatialBuildAmountTotal.subtract(iniatialdiscountAmountTotal).setScale(2,
							RoundingMode.HALF_UP);
					iniatialSgdGstAmount = sgdgst.multiply(iniatialNetTotalAmount).divide(new BigDecimal(100))
							.setScale(2, RoundingMode.HALF_UP);
					iniatialTotal = iniatialSgdGstAmount.add(iniatialNetTotalAmount).setScale(2, RoundingMode.HALF_UP);
				

				buf.append(
						"<tr><td class='tdColSpanFooter' colspan='2'><p style='margin-bottom:0px !important'></p></td><td class='footerSubTotalBorder'><p style='margin-bottom:0px !important'>Sub-Total</p></td><td class='trSubTotalFooterBackGround'><p style='margin-bottom:0px !important'>")
						.append(numberToCurrencyConverter(iniatialBuildAmountTotal))
						.append("</p></td><td class='emptyDiscountFooterBorder'><p style='margin-bottom:0px !important'></p></td><td class='trSubTotalFooterBackGround'><p style='margin-bottom:0px !important'>")
						.append(numberToCurrencyConverter(subTotal)+"</p></td></tr>");
				buf.append(
						"<tr><td class='tdColSpanFooter' colspan='2'><p style='margin-bottom:0px !important'></p></td><td class='footerSubTotalBorder'><p style='margin-bottom:0px !important'>Discount "+discountPercent+"%</p></td><td class='trSubTotalFooterBackGround' align='right'>")
						.append("<p style='margin-bottom:0px !important'>"+numberToCurrencyConverter(iniatialdiscountAmountTotal)+"</p>")
						.append("</td><td class='emptyDiscountFooterBorder'><p style='margin-bottom:0px !important'></p></td><td class='trSubTotalFooterBackGround'><p style='margin-bottom:0px !important'>")
						.append(numberToCurrencyConverter(discountAmount)+"</p></td></tr>");
				buf.append(
						"<tr><td class='tdColSpanFooter' colspan='2'><p style='margin-bottom:0px !important'></p></td><td class='footerDiscountBorder'><p style='margin-bottom:0px !important'>Value After Discount</p></td><td class='trDiscountFooterBackGround' style='text-align:right;'>")
						.append("<p style='margin-bottom:0px !important'>"+numberToCurrencyConverter(iniatialNetTotalAmount)+"</p>")
						.append("</td><td class='emptyDiscountFooterBorder'><p style='margin-bottom:0px !important'></p></td><td class='trDiscountFooterBackGround'><p style='margin-bottom:0px !important'>")
						.append(numberToCurrencyConverter(netSubTotal)+"</p></td></tr>");
				buf.append(
						"<tr><td class='tdColSpanFooter' colspan='2'><p style='margin-bottom:0px !important'></p></td><td class='footerServiceTaxBorder'><p style='margin-bottom:0px !important'>GST "
								+ sgdgst
								+ "%</p></td><td class='trServiceTaxFooterBackGround' style='text-align:right;'>")
						.append("<p style='margin-bottom:0px !important'>"+numberToCurrencyConverter(iniatialSgdGstAmount)+"</p></td>")
						.append("<td class='emptyDiscountFooterBorder'><p style='margin-bottom:0px !important'></p></td><td class='trServiceTaxFooterBackGround'><p style='margin-bottom:0px !important'>")
						.append(numberToCurrencyConverter(sgdgstAmount)+"</p></td></tr>");
				buf.append(
						"<tr><td class='tdColSpanFooter' colspan='2'><p style='margin-bottom:0px !important'></p></td><td class='footerTotalBorder'><p style='margin-bottom:0px !important'>Total</p></td><td class='trTotalFooterBackGround' style='font-weight:bold;text-align:right;'><p style='margin-bottom:0px !important'>")
						.append(numberToCurrencyConverter(iniatialTotal)+"</p></td>")
						.append("<td class='emptyTotalFooterBorder'><p style='margin-bottom:0px !important'></p></td><td class='trTotalFooterBackGround'><p style='margin-bottom:0px !important'>")
						.append(numberToCurrencyConverter(totalAmount)+"</p></td></tr>");
				buf.append("</table>");
				String mdInvoiceDetail = buf.toString();
				map.put("mdInvoiceDetail", mdInvoiceDetail);
			}
			/* FB project end */

		}

		if (billingUnitId == 3) {

			if (invoice.getInvoiceType().equals("Expense Invoice")) {

				if (project.getAccountName() != null) {
					projectName = project.getAccountName();
				}

				buf.append("<table name='date-table' style='float: left;width:99.7%'  cellpadding='0' cellspacing='0'>"
						+ "<tr><td class='pnTrData' style='vertical-align:top; padding: 0px;'><table name='date-table' style='float: left; width:100%'  cellpadding='0' cellspacing='0'><tr>")
						.append("<td class='gridHeaderRow' align='center' style='width: 100%;'><p style='margin-bottom:0px !important'>&nbsp;&nbsp;Client&nbsp;&nbsp;Name&nbsp;&nbsp;<br>&nbsp;</p></td></tr><tr><td style='text-align: center'>")
						.append(projectName)
						.append("<td></tr></table></td><td class='pnTrData' style='padding: 0px; border: 0px;'><table name='date-table' style='float: left; width:100%;'  cellpadding='0' cellspacing='0'>");
				buf.append(
						"<tr>" + "<td class='gridHeaderRow' align='center'><p style='margin-bottom:0px !important'>&nbsp;&nbsp;Purpose&nbsp;&nbsp;&nbsp;of<br />Expense</p></td>"
								+ "<td class='gridHeaderRow' align='center'><p style='margin-bottom:0px !important'>Description&nbsp;</p></td>"
								+ "<td class='gridHeaderRow' align='center'><p style='margin-bottom:0px !important'>Start&nbsp;Date&nbsp;</p></td>"
								+ "<td class='gridHeaderRow' align='center'><p style='margin-bottom:0px !important'>End&nbsp;Date&nbsp;</p></td>"
								+ "<td class='gridHeaderRow' align='center' style='width:110px;' width='60'><p style='margin-bottom:0px !important'>Comments&nbsp;<br/></p></td>"
								+ "<td class='gridHeaderRow' align='center' style='width:70px;'><p style='margin-bottom:0px !important'>&nbsp;&nbsp;Billed&nbsp;Amount</p></td>"
								+ "</tr>");
				while (it.hasNext()) {
					InvoicesDetail invoicesDetail = it.next();
					if (invoicesDetail.getDescription() != null) {
						description = invoicesDetail.getDescription();
					}

					if (invoicesDetail.getPurposeExpense() != null) {
						purposeExpense = invoicesDetail.getPurposeExpense();
					}
					if (invoicesDetail.getExpStartDate() != null) {
						expStartDate = DateConverter.changeDate2(invoicesDetail.getExpStartDate());
					}
					if (invoicesDetail.getExpEndDate() != null) {
						expEndDate = DateConverter.changeDate2(invoicesDetail.getExpEndDate());
					}
					if (invoicesDetail.getInitialBilledAmount() != null) {
						initialBilledAmount = invoicesDetail.getInitialBilledAmount();
					}
					if (invoicesDetail.getComments() != null) {
						comments = invoicesDetail.getComments();
					}

					if (invoice.getSubtotal() != null) {
						subTotal = invoice.getSubtotal();
					}

					if (invoice.getDiscountAmt() != null) {
						discountAmt = invoice.getDiscountAmt();
					}

					if (invoice.getTaxAmt() != null) {
						taxAmt = invoice.getTaxAmt();
					}

					if (invoice.getTotal() != null) {
						total = invoice.getTotal();
					}

					buf.append("<tr><td class='trData'><p style='margin-bottom:0px !important; text-align:center;'>").append(purposeExpense)
							.append("<br ><br ><br ></p></td><td class='trData'><p style='margin-bottom:0px !important; text-align:center;'>")
							.append(description)
							.append("<br ><br ><br ></p></td><td class='trRateData'><p style='margin-bottom:0px !important; text-align:center;'>")
							.append(expStartDate)
							.append("<br ><br ><br ></p></td><td class='trRateData'><p style='margin-bottom:0px !important; text-align:center;'>")
							.append(expEndDate)
							.append("<br ><br ><br ></p></td><td class='trRateData'><p style='margin-bottom:0px !important; text-align:center;'>")
							.append(comments+"<br ><br ><br ></p></td><td class='trBillAmt'><p style='margin-bottom:0px !important ; text-align:center;'>")
							.append(currencySign+" "+numberToCurrencyConverter(initialBilledAmount)+"<br ><br ><br ></p></td>").append("</td></tr>");
				}

				buf.append(
						"</table></tr><tr><td class='footerSubTotalBorder' colspan='2'><table style='width:100%' cellspacing='0'><tr><td>&nbsp;&nbsp;&nbsp;</td><td style='width:110px;'>&nbsp;&nbsp;&nbsp;</td><td>&nbsp;&nbsp;&nbsp;</td><td>&nbsp;&nbsp;&nbsp;</td><td class='footerDiscountBorder'><p style='margin-bottom:0px !important'>Sub-Total</p></td><td class='trSubTotalFooterBackGround' style='width: 100px;'><p style='margin-bottom:0px !important'>")
						.append(currencySign+""+numberToCurrencyConverter(subTotal)+"</p></td></tr>");
				buf.append(
						"<tr><td>&nbsp;&nbsp;&nbsp;</td><td>&nbsp;&nbsp;&nbsp;</td><td>&nbsp;&nbsp;&nbsp;</td><td style='width:110px;'>&nbsp;&nbsp;&nbsp;</td><td class='footerDiscountBorder'><p style='margin-bottom:0px !important'>Discount "+discountPercent+"%</p></td><td class='trSubTotalFooterBackGround' style='width: 100px;'><p style='margin-bottom:0px !important'>")
						.append(currencySign+""+numberToCurrencyConverter(discountAmt)+"</p></td></tr>");
				buf.append(
						"<tr><td>&nbsp;&nbsp;&nbsp;</td><td>&nbsp;&nbsp;&nbsp;</td><td>&nbsp;&nbsp;&nbsp;</td><td style='width:110px;'>&nbsp;&nbsp;&nbsp;</td><td class='footerDiscountBorder'><p style='margin-bottom:0px !important'>Tax</p></td><td class='trSubTotalFooterBackGround' style='width: 100px;'><p style='margin-bottom:0px !important'>")
						.append(currencySign+""+numberToCurrencyConverter(taxAmt)+"</p></td></tr>");
				buf.append(
						"<tr style='font-weight:bold'><td>&nbsp;&nbsp;&nbsp;</td><td>&nbsp;&nbsp;&nbsp;</td><td style='width:110px;'>&nbsp;&nbsp;&nbsp;</td><td>&nbsp;&nbsp;&nbsp;</td><td class='footerDiscountBorder'><p style='margin-bottom:0px !important'>Total</p></td><td class='trSubTotalFooterBackGround' style='width: 100px;'><p style='margin-bottom:0px !important'>")
						.append(currencySign+""+numberToCurrencyConverter(total)+"</p></td></tr></table></td></tr>");
				buf.append("</table>");
				String expInvoiceDetail = buf.toString();
				map.put("expInvoiceDetail", expInvoiceDetail);

			} else if(invoiceType.equals("License Invoice")){

				buf.append(
						"<table name='date-table' style='float: left;width:99.7%'  cellpadding='0' cellspacing='0'><tr>");
					buf.append("<td class='gridHeaderRow' align='center' width='70'><p style='margin-bottom:0px !important'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Description&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p></td>"
							+ "<td class='gridHeaderRow' align='center' colspan='2'><p style='margin:0px !important;width:150px !important;'>Period</p>"
							+ "<table style='width:100%'><tr>"
							+ "<td class='fromPeriodColumn' style='width: 50%;'><p style='margin:0px !important;' >From</p></td>"
							+ "<td class='toPeriodColumn'><p style='margin:0px !important;'>To</p></td>"
							+ "</tr></table>" + "</td>"
								+ "<td class='gridHeaderRow' align='center' width='70'><p style='margin-bottom:0px !important'>Rate <br/>&nbsp;(In&nbsp;"+currencyCode+")&nbsp;</p></td>");	
				buf.append("<td class='gridHeaderRow' align='center' width='60'><p style='margin-bottom:0px !important'>&nbsp;Billed&nbsp;Amount&nbsp; <br/>(In&nbsp;"+currencyCode+")</p></td>"
								+ "</tr>");

				while (it.hasNext()) {
					InvoicesDetail invoicesDetail = it.next();
					if (invoicesDetail.getDescription() != null) {
						description = invoicesDetail.getDescription();
					}
				
					if (invoicesDetail.getInitialBilledAmount() != null) {
						iniatialBuildAmount = invoicesDetail.getInitialBilledAmount();
					}
					if(invoicesDetail.getTsHrs() != null) {
						tsHrs = invoicesDetail.getTsHrs();
					}
					
					if (invoice.getSubtotal() != null) {
						subTotal = invoice.getSubtotal();
					}

					if (invoice.getDiscountAmt() != null) {
						discountAmt = invoice.getDiscountAmt();
					}

					if (invoice.getPeriodStartDate() != null) {
						sDate = DateConverter.changeDate2(invoice.getPeriodStartDate());
					}

					if (invoice.getPeriodEndDate() != null) {
						eDate = DateConverter.changeDate2(invoice.getPeriodEndDate());
					}
					
					if (invoice.getRoundOff() != null) {
						roundOff = invoice.getRoundOff();
					}
					if (invoice.getTotal() != null) {
						total = invoice.getTotal();
					}
					
					buf.append("<tr>");
					buf.append("<td class='pnTrData'><p style='margin-bottom:0px !important'>")
							.append(description)
							.append("</p></td><td class='trData' style='width:50%'><p style='margin:0px !important'>")
							.append(sDate)
							.append("</p></td><td class='trData' style='width:50%'><p style='margin:0px !important'>")
							.append(eDate)
							.append("</p></td><td class='trRateData'><p style='margin-bottom:0px !important'>")
							.append(numberToCurrencyConverter(iniatialBuildAmount));
							buf.append("</p></td><td class='trBillAmt'><p style='margin-bottom:0px !important'>")
							.append(numberToCurrencyConverter(iniatialBuildAmount)+"</p></td></tr>");
				}
				buf.append(
						"<tr><td colspan='3' class='tdColSpanFooter'><p style='margin-bottom:0px !important'></p></td><td class='footerSubTotalBorder'><p style='margin-bottom:0px !important'>Sub-Total</p></td><td class='trSubTotalFooterBackGround'><p style='margin-bottom:0px !important'>")
						.append(numberToCurrencyConverter(subTotal)+"</p></td>").append("</tr>");
				buf.append(
						"<tr><td colspan='3' class='tdColSpanFooter'><p style='margin-bottom:0px !important'></p></td><td class='footerSubTotalBorder'><p style='margin-bottom:0px !important'>Discount "+discountPercent+"%</p></td><td class='trSubTotalFooterBackGround' align='right'><p style='margin-bottom:0px !important'>")
						.append(numberToCurrencyConverter(discountAmt)+"</p></td>").append("</tr>");
				buf.append(
						"<tr><td colspan='3' class='tdColSpanFooter'><p style='margin-bottom:0px !important'></p></td><td class='footerServiceTaxBorder'><p style='margin-bottom:0px !important'>Round Off</p></td><td class='trServiceTaxFooterBackGround' style='text-align:right;'><p style='margin-bottom:0px !important'>")
						.append(roundOff+"</p></td>").append("</tr>");
				buf.append(
						"<tr><td colspan='3' class='tdColSpanFooter'><p style='margin-bottom:0px !important'></p></td><td class='footerTotalBorder'><p style='margin-bottom:0px !important'>Total</p></td><td class='trTotalFooterBackGround' style='text-align:right;'><p style='margin-bottom:0px !important'>")
						.append(numberToCurrencyConverter(total)+"</p></tr>");
				buf.append("</table>");
				String mdInvoiceDetail = buf.toString();
				map.put("mdInvoiceDetail", mdInvoiceDetail);
			}else if(invoiceType.equals("Services Invoice") || invoiceType.equals("Credit Note") || invoiceType.equals("Debit Note") || invoiceType.equals("Internal Invoice")){
				if (billing.equals("Fixed Bid Milestone")) {
					if(exchangeRate != BigDecimal.ZERO && exchangeRate != BigDecimal.ONE){
						buf.append("<table name='date-table' style='float: left;width:99.7%'  cellpadding='0' cellspacing='0'>"
								+ "<tr>"
								+ "<td class='gridHeaderRow' align='center' width='100'><p style='margin-bottom:0px !important'>Milestone</p></td>"
								+ "<td class='gridHeaderRow' align='center' width='70'><p style='margin-bottom:0px !important'>Description</p></td>"
								+ "<td class='gridHeaderRow' align='center' width='70'><p style='margin-bottom:0px !important'>Milestone&nbsp;Amount <br/>(In "+currencyCode+")</p></td>");
						buf.append("<td class='gridHeaderRow' align='center' width='60'><p style='margin-bottom:0px !important'>Billed Amount <br/>(In "+currencyCode+")</p></td>");
						buf.append("<td class='gridHeaderRow' align='center' width='80'><p style='margin-bottom:0px !important'>Exchange Rate</p></td>");
						buf.append("<td class='gridHeaderRow' align='center' width='80'><p style='margin-bottom:0px !important'>Billed Amount <br/>(In "+exchangeCurrencyCode+")</p></td>"
								+ "</tr>");

						while (it.hasNext()) {
							InvoicesDetail invoicesDetail = it.next();

							if (invoicesDetail.getDescription() != null) {
								description = invoicesDetail.getDescription();
							}

							if (invoicesDetail.getResNameMilestone() != null) {
								resourceName = invoicesDetail.getResNameMilestone();
							}

							if (invoicesDetail.getAmount() != null) {
								amount = invoicesDetail.getAmount();
							}

							if (invoice.getSubtotal() != null) {
								subTotal = invoice.getSubtotal();
							}

							if (invoice.getDiscountAmt() != null) {
								discountAmount = invoice.getDiscountAmt();
							}

							if (invoice.getTotal() != null) {
								totalAmount = invoice.getTotal();
							}

							if (invoicesDetail.getInitialBilledAmount() != null) {
								iniatialBuildAmount = invoicesDetail.getInitialBilledAmount();
								iniatialBuildAmountTotal = iniatialBuildAmountTotal.add(iniatialBuildAmount);
							}

							buf.append("<tr><td class='pnTrData'><p style='margin-bottom:0px !important'>"+resourceName)
									.append("</p></td><td class='trData'>")
									.append("<p style='margin-bottom:0px !important'>"+description+"</p>")
									.append("</td><td class='trRateData'>")
									.append("<p style='margin-bottom:0px !important'>"+iniatialBuildAmount+"</p>")
									.append("</td><td class='exRateCellClass'>")
									.append("<p style='margin-bottom:0px !important'>"+numberToCurrencyConverter(iniatialBuildAmount)+"</p>")
									.append("</td><td class='trBillAmt'>")
									.append("<p style='margin-bottom:0px !important'>"+exchangeRate+"</p></td>")
									.append("<td class='trBillAmt'><p style='margin-bottom:0px !important'>")
									.append(numberToCurrencyConverter(amount)+"</p></td>"
											+ "</tr>");
						}

							iniatialdiscountAmountTotal = discountPercent.multiply(iniatialBuildAmountTotal).divide(new BigDecimal(100))
									.setScale(0, RoundingMode.HALF_UP);
							iniatialNetTotalAmount = iniatialBuildAmountTotal.subtract(iniatialdiscountAmountTotal).setScale(0,
									RoundingMode.HALF_UP);
							iniatialSgdGstAmount = sgdgst.multiply(iniatialNetTotalAmount).divide(new BigDecimal(100))
									.setScale(0, RoundingMode.HALF_UP);
							iniatialTotal = iniatialSgdGstAmount.add(iniatialNetTotalAmount).setScale(0, RoundingMode.HALF_UP);
						

						buf.append("<tr><td colspan='2' class='tdColSpanFooter'><p style='margin-bottom:0px !important'></p></td><td class='footerSubTotalBorder'><p style='margin-bottom:0px !important'>Sub-Total</p></td><td class='trSubTotalFooterBackGround'><p style='margin-bottom:0px !important'>")
								.append(numberToCurrencyConverter(iniatialBuildAmountTotal))
								.append("</p></td><td class='footerSubTotalBorder'><p style='margin-bottom:0px !important'></p></td><td class='trSubTotalFooterBackGround'><p style='margin-bottom:0px !important'>")
								.append(numberToCurrencyConverter(subTotal)+"</p></td></tr>");
						buf.append("<tr><td colspan='2' class='tdColSpanFooter'><p style='margin-bottom:0px !important'></p></td><td class='footerSubTotalBorder'><p style='margin-bottom:0px !important'>Discount "+discountPercent+"%</p></td><td class='trSubTotalFooterBackGround' align='right'>")
								.append("<p style='margin-bottom:0px !important'>"+numberToCurrencyConverter(iniatialdiscountAmountTotal)+"</p>")
								.append("</td><td class='footerSubTotalBorder'><p style='margin-bottom:0px !important'></p></td><td class='trSubTotalFooterBackGround'><p style='margin-bottom:0px !important'>")
								.append(numberToCurrencyConverter(discountAmount)+"</p></td></tr>");
						buf.append("<tr><td colspan='2' class='tdColSpanFooter'><p style='margin-bottom:0px !important'></p></td><td class='footerDiscountBorder'><p style='margin-bottom:0px !important'>Round Off</p></td><td class='trDiscountFooterBackGround' style='text-align:right;'>")
								.append("<p style='margin-bottom:0px !important'>"+numberToCurrencyConverter(iniatialNetTotalAmount)+"</p>")
								.append("</td><td class='footerSubTotalBorder'><p style='margin-bottom:0px !important'></p></td><td class='trDiscountFooterBackGround'><p style='margin-bottom:0px !important'>")
								.append(numberToCurrencyConverter(netSubTotal)+"</p></td></tr>");
						buf.append(
								"<tr><td colspan='2' class='tdColSpanFooter'><p style='margin-bottom:0px !important'></p></td><td class='footerTotalBorder'><p style='margin-bottom:0px !important'>Total</p></td><td class='trTotalFooterBackGround' style='font-weight:bold;text-align:right;'><p style='margin-bottom:0px !important'>")
								.append(numberToCurrencyConverter(iniatialTotal)+"</p></td>")
								.append("<td class='footerSubTotalBorder'><p style='margin-bottom:0px !important'></p></td><td class='trTotalFooterBackGround'><p style='margin-bottom:0px !important'>")
								.append(numberToCurrencyConverter(totalAmount)+"</p></td></tr>");
						buf.append("</table>");
						String mdInvoiceDetail = buf.toString();
						map.put("mdInvoiceDetail", mdInvoiceDetail);
						
					}else{
					
					buf.append("<table name='date-table' style='float: left;width:99.7%'  cellpadding='0' cellspacing='0'>"
								+ "<tr>");
					buf.append("<td class='gridHeaderRow' align='center' width='100'><p style='margin-bottom:0px !important'>Milestone</p></td>");
					buf.append("<td class='gridHeaderRow' align='center' width='70'><p style='margin-bottom:0px !important'>&nbsp;&nbsp;&nbsp;Description&nbsp;&nbsp;&nbsp;</p></td>"
								+ "<td class='gridHeaderRow' align='center' width='70'><p style='margin-bottom:0px !important'>Milestone&nbsp;Amount <br/>(In "+currencyCode+")</p></td>");
				if(invoiceType.equals("License Invoice")){
					buf.append("<td class='gridHeaderRow' align='center' width='60'><p style='margin-bottom:0px !important'>Quantity<br/>(No's)</p></td>");
				}
				buf.append("<td class='gridHeaderRow' align='center' width='60'><p style='margin-bottom:0px !important'>Billed Amount <br/>(In "+currencyCode+")</p></td>"
								+ "</tr>");

				while (it.hasNext()) {
					InvoicesDetail invoicesDetail = it.next();
					if (invoicesDetail.getDescription() != null) {
						description = invoicesDetail.getDescription();
					}
					
					if (invoicesDetail.getResNameMilestone() != null) {
						resourceName = invoicesDetail.getResNameMilestone();
					}
					if (invoicesDetail.getInitialBilledAmount() != null) {
						iniatialBuildAmount = invoicesDetail.getInitialBilledAmount();
					}

					if (invoice.getSubtotal() != null) {
						subTotal = invoice.getSubtotal();
					}

					if (invoice.getDiscountAmt() != null) {
						discountAmt = invoice.getDiscountAmt();
					}

					if (invoice.getRoundOff() != null) {
						roundOff = invoice.getRoundOff();
					}
					if (invoice.getTotal() != null) {
						total = invoice.getTotal();
					}
					
					buf.append("<tr>");
					buf.append("<td class='pnTrData'><p style='margin-bottom:0px !important'>")
							.append(resourceName)
							.append("</p></td>");
					buf.append("<td class='trData'><p style='margin-bottom:0px !important'>")
							.append(description)
							.append("</p></td><td class='trRateData'><p style='margin-bottom:0px !important'>")
							.append(numberToCurrencyConverter(iniatialBuildAmount));
							if(invoiceType.equals("License Invoice")) {
							buf.append("</p></td><td class='trRateData'><p style='margin-bottom:0px !important'>")
								.append(numberToCurrencyConverter(tsHrs));
							}
							buf.append("</p></td><td class='trBillAmt'><p style='margin-bottom:0px !important'>")
							.append(numberToCurrencyConverter(iniatialBuildAmount)+"</p></td></tr>");
				}
				buf.append(
						"<tr><td colspan='2' class='tdColSpanFooter'><p style='margin-bottom:0px !important'></p></td><td class='footerSubTotalBorder'><p style='margin-bottom:0px !important'>Sub-Total</p></td><td class='trSubTotalFooterBackGround'><p style='margin-bottom:0px !important'>")
						.append(numberToCurrencyConverter(subTotal)+"</p></td>").append("</tr>");
				buf.append(
						"<tr><td colspan='2' class='tdColSpanFooter'><p style='margin-bottom:0px !important'></p></td><td class='footerSubTotalBorder'><p style='margin-bottom:0px !important'>Discount "+discountPercent+"%</p></td><td class='trSubTotalFooterBackGround' align='right'><p style='margin-bottom:0px !important'>")
						.append(numberToCurrencyConverter(discountAmt)+"</p></td>").append("</tr>");
				buf.append(
						"<tr><td colspan='2' class='tdColSpanFooter'><p style='margin-bottom:0px !important'></p></td><td class='footerServiceTaxBorder'><p style='margin-bottom:0px !important'>Round Off</p></td><td class='trServiceTaxFooterBackGround' style='text-align:right;'><p style='margin-bottom:0px !important'>")
						.append(roundOff+"</p></td>").append("</tr>");
				buf.append(
						"<tr><td colspan='2' class='tdColSpanFooter'><p style='margin-bottom:0px !important'></p></td><td class='footerTotalBorder'><p style='margin-bottom:0px !important'>Total</p></td><td class='trTotalFooterBackGround' style='text-align:right;'><p style='margin-bottom:0px !important'>")
						.append(numberToCurrencyConverter(total)+"</p></tr>");
				buf.append("</table>");
				String mdInvoiceDetail = buf.toString();
				map.put("mdInvoiceDetail", mdInvoiceDetail);
			
						
					}

					} else {
					
						if(billing.equals("Fixed Bid Monthly")) {
							hoursMonthlyTitle = "Monthly";
						}
						
					if(exchangeRate != BigDecimal.ZERO && exchangeRate != BigDecimal.ONE) {
						buf.append("<table name='date-table' style='float: left;width:99.7%'  cellpadding='0' cellspacing='0'>"
								+ "<tr>"
								+ "<td class='gridHeaderRow' align='center' width='70'><p style='margin-bottom:0px !important'>Role</p></td>");
						if(invoiceInfo.getReplaceAssociateNameWithRoleTitle() == null || invoiceInfo.getReplaceAssociateNameWithRoleTitle() == false) {							
							buf.append("<td class='gridHeaderRow' align='center' width='70'><p style='margin-bottom:0px !important'>&nbsp;&nbsp;Associate&nbsp;Name&nbsp;&nbsp;</p></td>");
						}
								
						buf.append("<td class='gridHeaderRow' align='center' colspan='2' width='70'><p style='margin-bottom:0px !important'>Period</p>"
								+ "<table style='width:100%'><tr>"
								+ "<td class='fromPeriodColumn' style='width:50%'><p style='margin-bottom:0px !important;' >From</p></td>"
								+ "<td class='toPeriodColumn' style='width:50%'><p style='margin-bottom:0px !important;'>To</p></td>"
								+ "</tr></table>" + "</td>"
								+ "<td class='gridHeaderRow' align='center' width='80'><p style='margin-bottom:0px !important'>Rate <br/>&nbsp;&nbsp;&nbsp;(In&nbsp;"+currencyCode+")&nbsp;&nbsp;&nbsp;</p></td>"
								+ "<td class='gridHeaderRow' align='center' width='30'><p style='margin-bottom:0px !important'>Quantity <br/>&nbsp;&nbsp;(In&nbsp;"+hoursMonthlyTitle+")&nbsp;&nbsp;</p></td>"
								+ "<td class='gridHeaderRow' align='center' width='50'><p style='margin-bottom:0px !important'>Billed Amount <br/>&nbsp;&nbsp;(In&nbsp;"+currencyCode+")&nbsp;&nbsp;</p></td>"
								+ "<td class='gridHeaderRow' align='center' width='50'><p style='margin-bottom:0px !important'>Exchange Rate</p></td>"
								+ "<td class='gridHeaderRow' align='center' width='60'><p style='margin-bottom:0px !important'>Billed Amount <br/>&nbsp;&nbsp;(In&nbsp;"+exchangeCurrencyCode+")&nbsp;&nbsp;</p></td>"
								+ "</tr>");

						while (it.hasNext()) {
							InvoicesDetail invoicesDetail = it.next();
							if (invoicesDetail.getInfoCeptsRole() != null) {
								infoCeptsRole = invoicesDetail.getInfoCeptsRole();
							}
							if (invoicesDetail.getClientRole() != null) {
								clientRole = invoicesDetail.getClientRole();
							}
							if (invoicesDetail.getResNameMilestone() != null) {
								resourceName = invoicesDetail.getResNameMilestone();
							}
							if (invoice.getPeriodStartDate() != null) {
								sDate = DateConverter.changeDate2(invoice.getPeriodStartDate());
							}
							if (invoice.getPeriodEndDate() != null) {
								eDate = DateConverter.changeDate2(invoice.getPeriodEndDate());
							}
							if (invoicesDetail.getBillableRate() != null) {
								billableRate = invoicesDetail.getBillableRate();
							}
							if (invoicesDetail.getTsHrs() != null) {
								tsHrs = invoicesDetail.getTsHrs();
								quantityHoursTotal = quantityHoursTotal.add(tsHrs);
							}
							if (invoicesDetail.getAmount() != null) {
								amount = invoicesDetail.getAmount();
							}
							if (invoicesDetail.getInitialBilledAmount() != null) {
								iniatialBuildAmount = invoicesDetail.getInitialBilledAmount();
								iniatialBuildAmountTotal = iniatialBuildAmountTotal.add(iniatialBuildAmount);
							}
							if (invoice.getSubtotal() != null) {
								subtotal = invoice.getSubtotal();
							}
							if (invoice.getDiscountAmt() != null) {
								discountAmount = invoice.getDiscountAmt();
							}
							if (invoice.getTotal() != null) {
								totalAmount = invoice.getTotal();
							}
							if (invoice.getNetSubTotal() != null) {
								netSubTotal = invoice.getNetSubTotal();
							}
							
							if (invoice.getRoundOff() != null) {
								roundOff = invoice.getRoundOff();
							}
							
							buf.append("<tr><td class='pnTrData'>")
									.append("<p style='margin-bottom:0px !important'>"+clientRole+"</p>")
									.append("</td>");
							if(invoiceInfo.getReplaceAssociateNameWithRoleTitle()==null || invoiceInfo.getReplaceAssociateNameWithRoleTitle()== false){
								buf.append("<td class='trData'><p style='margin-bottom:0px !important'>"+resourceName+"</p></td>");								
							}
							
							buf.append("<td class='trData' style='width:50%'>")
									.append("<p style='margin-bottom:0px !important'>"+sDate+"</p>")
									.append("</td><td class='trData' style='width:50%'>")
									.append("<p style='margin-bottom:0px !important'>"+eDate+"</p>")
									.append("</td><td class='trRateData'>")
									.append("<p style='margin-bottom:0px !important'>"+billableRate+"</p>")
									.append("</td><td class='trData'>")
									.append("<p style='margin-bottom:0px !important'>"+tsHrs+"</p>")
									.append("</td><td class='trBillAmt'>")
									.append("<p style='margin-bottom:0px !important'>"+numberToCurrencyConverter(iniatialBuildAmount)+"</p>")
									.append("</td><td class='exRateCellClass'>")
									.append("<p style='margin-bottom:0px !important'>"+exchangeRate+"</p>")
									.append("</td><td class='trBillAmt'><p style='margin-bottom:0px !important'>")
									.append(numberToCurrencyConverter(amount)+"</p></td></tr>");
						}

						buf.append("<tr>");
						if(invoiceInfo.getReplaceAssociateNameWithRoleTitle()==null || invoiceInfo.getReplaceAssociateNameWithRoleTitle() == false){
							buf.append("<td colspan='4' class='tdColSpanFooter'><p style='margin-bottom:0px !important'></p></td><td class='footerSubTotalBorder'><p style='margin-bottom:0px !important'>Sub-Total</p></td>");							
						}else {
							buf.append("<td colspan='3' class='tdColSpanFooter'><p style='margin-bottom:0px !important'></p></td><td class='footerSubTotalBorder'><p style='margin-bottom:0px !important'>Sub-Total</p></td>");							
						}

						buf.append("<td class='emptySubTotalFooterBorder'>")
								.append("<p style='margin-bottom:0px !important'>"+quantityHoursTotal+"</p>")
								.append("</td><td class='trSubTotalFooterBackGround'>")
								.append("<p style='margin-bottom:0px !important'>"+numberToCurrencyConverter(iniatialBuildAmountTotal)+"</p>")
								.append("</td><td class='emptyDiscountFooterBorder'><p style='margin-bottom:0px !important'></p></td>")
								.append("<td class='trSubTotalFooterBackGround'>")
								.append("<p style='margin-bottom:0px !important'>"+numberToCurrencyConverter(subtotal)+"</p></td></tr>");
						buf.append("<tr>");
						
						if(invoiceInfo.getReplaceAssociateNameWithRoleTitle()==null || invoiceInfo.getReplaceAssociateNameWithRoleTitle() == false){
							buf.append("<td colspan='4' class='tdColSpanFooter'><p style='margin-bottom:0px !important'></p></td>");
						}else {
							buf.append("<td colspan='3' class='tdColSpanFooter'><p style='margin-bottom:0px !important'></p></td>");
						}

						buf.append("<td class='footerSubTotalBorder'><p style='margin-bottom:0px !important'>Discount "
										+ discountPercent
										+ "%</p></td><td class='emptySubTotalFooterBorder'><p style='margin-bottom:0px !important'>")
								.append("</p></td><td class='trSubTotalFooterBackGround' align='right'>")
								.append("<p style='margin-bottom:0px !important'> </p>")
								.append("</td><td class='emptyDiscountFooterBorder'><p style='margin-bottom:0px !important'></p></td>")
								.append("<td class='trSubTotalFooterBackGround'><p style='margin-bottom:0px !important'>")
								.append(numberToCurrencyConverter(discountAmount)+"</p></td></tr>");
						buf.append("<tr>");
						
						if(invoiceInfo.getReplaceAssociateNameWithRoleTitle()==null || invoiceInfo.getReplaceAssociateNameWithRoleTitle() == false){
							buf.append("<td colspan='4' class='tdColSpanFooter'><p style='margin-bottom:0px !important'></p></td>");
						}else {
							buf.append("<td colspan='3' class='tdColSpanFooter'><p style='margin-bottom:0px !important'></p></td>");
						}
					
					buf.append("<td class='footerSubTotalBorder'><p style='margin-bottom:0px !important'>Round Off</p></td><td class='emptySubTotalFooterBorder'><p style='margin-bottom:0px !important'>")
								.append("</p></td><td class='trSubTotalFooterBackGround' align='right'>")
								.append("<p style='margin-bottom:0px !important'> </p>")
								.append("</td><td class='emptyDiscountFooterBorder'><p style='margin-bottom:0px !important'></p></td>")
								.append("<td class='trSubTotalFooterBackGround'>")
								.append("<p style='margin-bottom:0px !important'>"+roundOff+"</p></td></tr>");

						buf.append("<tr>");
						
						if(invoiceInfo.getReplaceAssociateNameWithRoleTitle()==null || invoiceInfo.getReplaceAssociateNameWithRoleTitle() == false){
							buf.append("<td colspan='4' class='tdColSpanFooter'><p style='margin-bottom:0px !important'></p></td>");
						}else {
							buf.append("<td colspan='3' class='tdColSpanFooter'><p style='margin-bottom:0px !important'></p></td>");
						}					 
						buf.append("<td class='footerTotalBorder'><p style='margin-bottom:0px !important'>Total</p></td><td class='emptyTotalFooterBorder'><p style='margin-bottom:0px !important'>")
								.append("</p></td><td class='trTotalFooterBackGround' style='text-align:right;'>")
								.append("<p style='margin-bottom:0px !important'> </p>")
								.append("</td><td class='emptyTotalFooterBorder'><p style='margin-bottom:0px !important'></p></td>")
								.append("<td class='trTotalFooterBackGround'><p style='margin-bottom:0px !important'>")
								.append(numberToCurrencyConverter(totalAmount)+"</p></td></tr>");
						buf.append("</table>");
						String invoiceDetail = buf.toString();
						map.put("LLCinvoiceDetail", invoiceDetail);

					
					}else{
						buf.append("<table name='date-table' style='float: left;width:99.7%'  cellpadding='0' cellspacing='0'>"
										+ "<tr>"
										+ "<td class='gridHeaderRow' align='center'><p style='margin:0px !important; width:100px'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Role&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p></td>");
						if(invoiceInfo.getReplaceAssociateNameWithRoleTitle()==null || invoiceInfo.getReplaceAssociateNameWithRoleTitle() == false){						
							buf.append("<td class='gridHeaderRow' align='center'><p style='margin:0px !important; width:100px;'>&nbsp;&nbsp;&nbsp;&nbsp;Associate&nbsp;Name&nbsp;&nbsp;&nbsp;&nbsp;</p></td>");
						}						/* Onsite and Offshore check,  add Description column*/
						if(invoiceInfo.getOnsiteOffShoreSplit() != null && invoiceInfo.getOnsiteOffShoreSplit() == true) {
							buf.append("<td class='gridHeaderRow' align='center'><p style='margin:0px !important; width:100px;'>&nbsp;&nbsp;&nbsp;&nbsp;Description&nbsp;&nbsp;&nbsp;&nbsp;</p></td>");													
						}

						buf.append("<td class='gridHeaderRow' align='center' colspan='2'><p style='margin:0px !important;width:150px !important;'>Period</p>"
										+ "<table style='width:100%'><tr>"
										+ "<td class='fromPeriodColumn' style='width: 50%;'><p style='margin:0px !important;' >From</p></td>"
										+ "<td class='toPeriodColumn'><p style='margin:0px !important;'>To</p></td>"
										+ "</tr></table>" + "</td>"
										+ "<td class='gridHeaderRow' align='center' width='10%'><p style='margin:0px !important; width:100px;'>&nbsp;&nbsp;Rate&nbsp;&nbsp;<br/>&nbsp;&nbsp;&nbsp;&nbsp;(In&nbsp;"+currencyCode+")&nbsp;&nbsp;&nbsp;&nbsp;</p></td>"
										+ "<td class='gridHeaderRow' align='center' width='10%'><p style='margin:0px !important; width:100px'>&nbsp;&nbsp;&nbsp;Quantity&nbsp;&nbsp;&nbsp; <br/>&nbsp;(In&nbsp;"+hoursMonthlyTitle+")&nbsp;&nbsp;&nbsp;</p></td>"
										+ "<td class='gridHeaderRow' align='center' width='10%'><p style='margin:0px !important; width:100px'>&nbsp;&nbsp;&nbsp;Billed&nbsp;Amount&nbsp;&nbsp;&nbsp;<br/>(In&nbsp;"+currencyCode+")</p></td>"
										+ "</tr>");

						while (it.hasNext()) {
							InvoicesDetail invoicesDetail = it.next();

							if (invoicesDetail.getInfoCeptsRole() != null) {
								infoCeptsRole = invoicesDetail.getInfoCeptsRole();
							}
							if (invoicesDetail.getClientRole() != null) {
								clientRole = invoicesDetail.getClientRole();
							}
							if (invoicesDetail.getResNameMilestone() != null) {
								resourceName = invoicesDetail.getResNameMilestone();
							}

							if (invoice.getPeriodStartDate() != null) {
								sDate = DateConverter.changeDate2(invoice.getPeriodStartDate());
							}

							if (invoice.getPeriodEndDate() != null) {
								eDate = DateConverter.changeDate2(invoice.getPeriodEndDate());
							}

							if (invoicesDetail.getBillableRate() != null) {
								billableRate = invoicesDetail.getBillableRate();
							}

							if (invoicesDetail.getTsHrs() != null) {
								tsHrs = invoicesDetail.getTsHrs();
								quantityHoursTotal = quantityHoursTotal.add(tsHrs);
							}

							if (invoicesDetail.getAmount() != null) {
								amount = invoicesDetail.getAmount();
							}

							if (invoice.getSubtotal() != null) {
								subtotal = invoice.getSubtotal();
							}

							if (invoice.getDiscountAmt() != null) {
								discountAmount = invoice.getDiscountAmt();
							}

							if (invoice.getTotal() != null) {
								totalAmount = invoice.getTotal();
							}

							if (invoice.getRoundOff() != null) {
								roundOff = invoice.getRoundOff();
							}
							
							if (invoicesDetail.getClientRole() != null) {
								infoCeptsClientRole = invoicesDetail.getClientRole();
							}

							// onsiteOffshore = invoiceInfo.getOnsiteOffShoreSplit();
							/* Onsite and Offshore check  */
							if(invoiceInfo.getOnsiteOffShoreSplit() != null && invoiceInfo.getOnsiteOffShoreSplit() == true) {
								
								if(projectTitle !=null && invoice.getClientPO()!=null) {
									clientPOAndTitle = invoice.getClientPO()+" - "+projectTitle;
								}								
								/*  Country check for Onsite and Offshore projects */
								if(invoicesDetail.getCountryId() != 101) {  
									 onsiteHrsTotal = onsiteHrsTotal.add(tsHrs);
									 onsiteAmountTotal  =  onsiteAmountTotal.add(amount);
									 
									 if(clientPOAndTitle!=null) {
										 clientPOAndTitle = clientPOAndTitle+" Onsite";
									 }
									 
									 onsiteRecords.append("<tr><td class='pnTrData'><p style='margin:0px !important'>").append(infoCeptsClientRole)
									.append("</p></td><td class='trData'>")
									.append("<p style='margin:0px !important'>"+resourceName+"</p>")
									.append("</td><td class='trData'>")
									.append("<p style='margin:0px !important'>"+clientPOAndTitle+"</p>")
									.append("</td><td class='trData' style='width:50%'>")
									.append("<p style='margin:0px !important'>"+sDate+"</p>")
									.append("</td><td class='trData' style='width:50%'>")
									.append("<p style='margin:0px !important'>"+eDate+"</p>")
									.append("</td><td class='trRateData'><p style='margin:0px !important'>")
									.append(numberToCurrencyConverter(billableRate)+"</p></td><td class='trData'>")
									.append("<p style='margin:0px !important'>"+tsHrs+"</p>")
									.append("</td><td class='trBillAmt'><p style='margin:0px !important'>")
									.append(numberToCurrencyConverter(amount)+"</p></td></tr>");		
								}else {
									 if(clientPOAndTitle!=null) {
										 clientPOAndTitle = clientPOAndTitle+" Offshore";
									 }
									 offshoreHrsTotal = offshoreHrsTotal.add(tsHrs);
									 offshoreAmountTotal = offshoreAmountTotal.add(amount);
									 offshoreRecords.append("<tr><td class='pnTrData'><p style='margin:0px !important'>").append(infoCeptsClientRole)
									.append("</p></td><td class='trData'>")
									.append("<p style='margin:0px !important'>"+resourceName+"</p>")
									.append("</td><td class='trData'>")
									.append("<p style='margin:0px !important'>"+clientPOAndTitle+"</p>")
									.append("</td><td class='trData' style='width:50%'>")
									.append("<p style='margin:0px !important'>"+sDate+"</p>")
									.append("</td><td class='trData' style='width:50%'>")
									.append("<p style='margin:0px !important'>"+eDate+"</p>")
									.append("</td><td class='trRateData'><p style='margin:0px !important'>")
									.append(numberToCurrencyConverter(billableRate)+"</p></td><td class='trData'>")
									.append("<p style='margin:0px !important'>"+tsHrs+"</p>")
									.append("</td><td class='trBillAmt'><p style='margin:0px !important'>")
									.append(numberToCurrencyConverter(amount)+"</p></td></tr>");
								}
							}
							
							if(invoiceInfo.getOnsiteOffShoreSplit() == null || invoiceInfo.getOnsiteOffShoreSplit() == false) {
								buf.append("<tr><td class='pnTrData'><p style='margin:0px !important'>").append(clientRole)
								.append("</p></td>");
								if(invoiceInfo.getReplaceAssociateNameWithRoleTitle()==null || invoiceInfo.getReplaceAssociateNameWithRoleTitle() == false){
								buf.append("<td class='trData'><p style='margin:0px !important'>"+resourceName+"</p></td>");
								}
								buf.append("<td class='trData' style='width:50%'>")
								.append("<p style='margin:0px !important'>"+sDate+"</p>")
								.append("</td><td class='trData' style='width:50%'>")
								.append("<p style='margin:0px !important'>"+eDate+"</p>")
								.append("</td><td class='trRateData'><p style='margin:0px !important'>")
								.append(numberToCurrencyConverter(billableRate)+"</p></td><td class='trData'>")
								.append("<p style='margin:0px !important'>"+tsHrs+"</p>")
								.append("</td><td class='trBillAmt'><p style='margin:0px !important'>")
								.append(numberToCurrencyConverter(amount)+"</p></td></tr>");	
							}
						}
						
						if(invoiceInfo.getOnsiteOffShoreSplit()!=null && invoiceInfo.getOnsiteOffShoreSplit() == true) {
							
							onsiteRecordsCount.append("<tr><td class='pnTrData'><p style='margin:0px !important'>&nbsp;</p></td><td class='trData'>")
							.append("<p style='margin:0px !important'>&nbsp;</p>")
							.append("</td><td colspan='3' class='trData footerTotalBorder' style='width:50%'>")
							.append("<p style='margin:0px !important;font-weight: bold;'> Onsite Sub-Total (A)</p>")
							.append("</td><td class='trRateData'><p style='margin:0px !important'>&nbsp;</p></td><td class='trData footerTotalBorder'>")
							.append("<p style='margin:0px !important;font-weight: bold;'>"+onsiteHrsTotal+"</p>")
							.append("</td><td class='trBillAmt footerTotalBorder'><p style='margin:0px !important;font-weight: bold;'>")
							.append(numberToCurrencyConverter(onsiteAmountTotal)+"</p></td></tr>");										
							buf.append(onsiteRecords);
							buf.append(onsiteRecordsCount);
							buf.append(offshoreRecords);							
							buf.append("<tr><td class='pnTrData'><p style='margin:0px !important'>&nbsp;</p></td><td class='trData'>")
							.append("<p style='margin:0px !important'>&nbsp;</p>")
							.append("</td><td colspan='3' class='trData footerTotalBorder' style='width:50%'>")
							.append("<p style='margin:0px !important;font-weight: bold;'> Offshore Sub-Total(B)</p>")
							.append("</td><td class='trRateData'><p style='margin:0px !important'>&nbsp;</p></td> <td class='trData '>")
							.append("<p style='margin:0px !important;font-weight: bold;'>"+offshoreHrsTotal+"</p>")
							.append("</td><td class='trBillAmt footerTotalBorder'><p style='margin:0px !important;font-weight: bold;'>")
							.append(numberToCurrencyConverter(offshoreAmountTotal)+"</p></td></tr>");
							
							buf.append("<tr><td colspan='5' class='tdColSpanFooter'><p style='margin-bottom:0px !important'></p></td><td class='footerSubTotalBorder'><p style='margin-bottom:0px !important'>Sub-Total</p></td><td class='emptySubTotalFooterBorder'>"
											+"<p style='margin-bottom:0px !important'>"+quantityHoursTotal + "</p></td>")
									.append("<td class='trSubTotalFooterBackGround'><p style='margin-bottom:0px !important'>")
									.append(numberToCurrencyConverter(subtotal)+"</p></td></tr>");
							buf.append("<tr><td colspan='5' class='tdColSpanFooter'><p style='margin-bottom:0px !important'></p></td><td class='footerSubTotalBorder'><p style='margin-bottom:0px !important'>Discount "+discountPercent+"%</p></td><td class='emptySubTotalFooterBorder'><p style='margin-bottom:0px !important'>")
									.append("</p></td>")
									.append("<td class='trSubTotalFooterBackGround'><p style='margin-bottom:0px !important'>")
									.append(numberToCurrencyConverter(discountAmount)+"</p></td></tr>");
							buf.append(
									"<tr><td colspan='5' class='tdColSpanFooter'><p style='margin-bottom:0px !important'></p></td><td class='footerServiceTaxBorder'><p style='margin-bottom:0px !important'>Round Off</p></td><td class='emptyServiceTaxFooterBorder'><p style='margin-bottom:0px !important'>")
									.append("</p></td>")
									.append("<td class='trServiceTaxFooterBackGround'><p style='margin-bottom:0px !important'><b>")
									.append(roundOff+"</b></p></td></tr>");
							buf.append(
									"<tr><td colspan='5' class='tdColSpanFooter'><p style='margin-bottom:0px !important'></p></td><td class='footerTotalBorder'><p style='margin-bottom:0px !important'>Total</p></td><td class='emptyTotalFooterBorder'><p style='margin-bottom:0px !important'>")
									.append("</p></td>")
									.append("<td class='trTotalFooterBackGround'><p style='margin-bottom:0px !important'>")
									.append(numberToCurrencyConverter(totalAmount)+"</p></td></tr>");
							
							
						}else {
							
							buf.append("<tr>");
							if(invoiceInfo.getReplaceAssociateNameWithRoleTitle()==null || invoiceInfo.getReplaceAssociateNameWithRoleTitle() == false){
								buf.append("<td colspan='4' class='tdColSpanFooter'><p style='margin-bottom:0px !important'></p></td>");								
							}else {
								buf.append("<td colspan='3' class='tdColSpanFooter'><p style='margin-bottom:0px !important'></p></td>");								
							}
							
							buf.append("<td class='footerSubTotalBorder'><p style='margin-bottom:0px !important'>Sub-Total</p></td><td class='emptySubTotalFooterBorder'>"
											+"<p style='margin-bottom:0px !important'>"+quantityHoursTotal + "</p></td>")
									.append("<td class='trSubTotalFooterBackGround'><p style='margin-bottom:0px !important'>")
									.append(numberToCurrencyConverter(subtotal)+"</p></td></tr>");
							buf.append("<tr>");
							if(invoiceInfo.getReplaceAssociateNameWithRoleTitle()==null || invoiceInfo.getReplaceAssociateNameWithRoleTitle() == false){
								buf.append("<td colspan='4' class='tdColSpanFooter'><p style='margin-bottom:0px !important'></p></td>");								
							}else {
								buf.append("<td colspan='3' class='tdColSpanFooter'><p style='margin-bottom:0px !important'></p></td>");								
							}
							buf.append("<td class='footerSubTotalBorder'><p style='margin-bottom:0px !important'>Discount "+discountPercent+"%</p></td><td class='emptySubTotalFooterBorder'><p style='margin-bottom:0px !important'>")
									.append("</p></td>")
									.append("<td class='trSubTotalFooterBackGround'><p style='margin-bottom:0px !important'>")
									.append(numberToCurrencyConverter(discountAmount)+"</p></td></tr>");
							buf.append("<tr>");
							if(invoiceInfo.getReplaceAssociateNameWithRoleTitle()==null || invoiceInfo.getReplaceAssociateNameWithRoleTitle() == false){
								buf.append("<td colspan='4' class='tdColSpanFooter'><p style='margin-bottom:0px !important'></p></td>");								
							}else {
								buf.append("<td colspan='3' class='tdColSpanFooter'><p style='margin-bottom:0px !important'></p></td>");								
							}
							buf.append("<td class='footerServiceTaxBorder'><p style='margin-bottom:0px !important'>Round Off</p></td><td class='emptyServiceTaxFooterBorder'><p style='margin-bottom:0px !important'>")
									.append("</p></td>")
									.append("<td class='trServiceTaxFooterBackGround'><p style='margin-bottom:0px !important'><b>")
									.append(roundOff+"</b></p></td></tr>");
							buf.append("<tr>");
							if(invoiceInfo.getReplaceAssociateNameWithRoleTitle()==null || invoiceInfo.getReplaceAssociateNameWithRoleTitle() == false){
								buf.append("<td colspan='4' class='tdColSpanFooter'><p style='margin-bottom:0px !important'></p></td>");								
							}else {
								buf.append("<td colspan='3' class='tdColSpanFooter'><p style='margin-bottom:0px !important'></p></td>");								
							}
							buf.append("<td class='footerTotalBorder'><p style='margin-bottom:0px !important'>Total</p></td><td class='emptyTotalFooterBorder'><p style='margin-bottom:0px !important'>")
									.append("</p></td>")
									.append("<td class='trTotalFooterBackGround'><p style='margin-bottom:0px !important'>")
									.append(numberToCurrencyConverter(totalAmount)+"</p></td></tr>");
														
						}

						buf.append("</table>");
						String llcInvoiceDetail = buf.toString();
						map.put("LLCinvoiceDetail", llcInvoiceDetail);
						
					}

				}
			}
		}
		
		if(invoiceInfo.getReplaceAssociateNameWithRoleTitle()!=null && invoiceInfo.getReplaceAssociateNameWithRoleTitle()==true) {
			associateNameRoleLabel = "Role";	
		}
		
		/* Weekly billing detail code */
		weeklyBillingDetail.append("<table  border='0' cellspacing='0' cellpadding='0' style='width:99.8%;border-collapse:collapse;'><tr>"
						+ "<td width='100' style='width:75.0pt;border:solid gray 1.0pt;background:#0065A4;padding:0cm 0cm 0cm 0cm'>"
						+ "<p style='margin:0px !important; font-size:9pt' align='center' ><b><span style='font-size:9.0pt;color:#FFFFFF'>"+associateNameRoleLabel+"</span></b></p></td>"
						+ "<td colspan='5' style='border:solid gray 1.0pt;border-left:none;background:#0065A4;padding:0cm 0cm 0cm 0cm'>"
						+ "<p style='margin:0px !important; font-size:9pt' align='center' ><b><span style='font-size:9.0pt;color:#FFFFFF'>Hours Billable(Week Ending) </span></b></p>"
						+ "<div align='center' class='weeklyTable'>");
		weeklyBillingDetail.append(
				"<table  border='0' cellpadding='0' width='100%' style='width:100.8%;'><tr>");
		Integer userId = 0;
		List<WeeklyHours> li = invoice.getWeeklyhours();
		List<Date> periodEnddate = new ArrayList<>();

		for (WeeklyHours weeklyHours : invoice.getWeeklyhours()) {
			if (!periodEnddate.contains(weeklyHours.getPeriodEnd())) {
				periodEnddate.add(weeklyHours.getPeriodEnd());
			}
		}
		Collections.sort(periodEnddate);
		for(Date date : periodEnddate) {
			weeklyBillingDetail.append("<td style='width:10.0%;border-top:solid gray 1.0pt; border-left:none;border-bottom:none;border-right:solid gray 1.0pt; background:#0065A4;padding:.75pt .75pt .75pt .75pt'> <p style='margin:0px !important; font-size:9pt' align='center' ><b><span style='font-size:9.0pt;color:#FFFFFF'>"
					+ DateConverter.changeDate2(date) + "</span></b></p> </td>");
		}
		weeklyBillingDetail.append("</tr></table></div></td>");
		weeklyBillingDetail
				.append("<td width='100' style='width:75.0pt;border:solid gray 1.0pt;border-left:none;  background:#0065A4;padding:0cm 0cm 0cm 0cm'> <p style='margin:0px !important; font-size:9pt' align='center' ><b><span style='font-size:9.0pt;color:#FFFFFF'>Total</span></b></p> </td>"
						+ "<td width='100' style='width:75.0pt;border:solid gray 1.0pt;border-left:none;  background:#0065A4;padding:0cm 0cm 0cm 0cm'> <p style='margin:0px !important; font-size:9pt' align='center' ><b><span style='font-size:9.0pt;color:#FFFFFF'>No. of Man Days</span></b></p> </td>"
						+ "</tr>");
		Boolean loopEnd = false;
		Boolean loopStart = true;
		for (WeeklyHours weeklyHour : li) {
			
			weeklyTotal = BigDecimal.ZERO;
			if(invoiceInfo.getReplaceAssociateNameWithRoleTitle()!=null && invoiceInfo.getReplaceAssociateNameWithRoleTitle()==true) {
				associateNameRoleTitle = weeklyHour.getInfoCeptsRole();
			}else {
				associateNameRoleTitle = weeklyHour.getResourceName();
			}
			
			if (Integer.parseInt(previousUserId.toString()) == 0 || Integer
					.parseInt(previousUserId.toString()) != Integer.parseInt(weeklyHour.getUid().toString())) {
				weeklyBillingDetail
						.append("<tr><td style='width:20.0%;border:solid gray 1.0pt;border-top:none; padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='center' ><span style='font-size:9.0pt;'>"
								+ associateNameRoleTitle + "</span></p> </td>"
								+ "<td colspan='5' style='border:solid gray 1.0pt;border-left:none;padding:0cm 0cm 0cm 0cm'><div align='center' class='weeklyTable'> <table  border='0' cellspacing='0' cellpadding='0' width='100%' style='width:100.8%;'><tr>");
					
					for (WeeklyHours weeklyHours : invoice.getWeeklyhours()) {
						for (Date date : periodEnddate) {
						String periodDate = DateConverter.convertDateToString(date);
						String weeklydate = DateConverter.convertDateToString(weeklyHours.getPeriodEnd());
						// user check to get correct timesheet hours
						if (Integer.parseInt(weeklyHours.getUid().toString()) == Integer.parseInt(weeklyHour.getUid().toString())) {
							// current period end date is available or not in weekly hours array
							if(weeklyHours.getPeriodEnd().after(date) && (loopEnd || loopStart)) {
								weeklyBillingDetail.append(	"<td style='width:10.0%;border-left:none;border-bottom:none;border-right:solid gray 1.0pt;padding:.75pt .75pt .75pt .75pt'> <p style='margin:0px !important; font-size:9pt' align='center'><span>0</span></p> </td>");
								loopStart = false;
							}
							// compare the weekly and period End date
							if (weeklydate.compareTo(periodDate) == 0) {
								tsHours = weeklyHours.getTsHrs();
								weeklyBillingDetail.append(
										"<td style='width:10.0%;border-left:none;border-bottom:none;border-right:solid gray 1.0pt;padding:.75pt .75pt .75pt .75pt'> <p style='margin:0px !important; font-size:9pt' align='center'><span>"
												+ tsHours + "</span></p> </td>");
								weeklyTotal = weeklyTotal.add(tsHours);
								loopEnd = false;
								loopStart = false;
								break;
							}
						}else {
							loopEnd = true;
							loopStart = false;
						}
					}
				}
				previousUserId = weeklyHour.getUid();
				weeklyBillingDetail.append("</tr></table></div></td>");
				NoOfManDays = weeklyTotal.divide(new BigDecimal(8), 2, RoundingMode.HALF_UP);
				weeklyBillingDetail
						.append("<td style='width:10.0%;border:none; border-bottom:solid gray 1.0pt;border-right:solid gray 1.0pt;padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='center' ><span style='font-size:9.0pt;'>"
								+ weeklyTotal + "</span></p> </td>"
								+ "<td style='width:10.0%;border:none; border-bottom:solid gray 1.0pt;border-right:solid gray 1.0pt;padding:1.5pt 1.5pt 1.5pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='center' ><span style='font-size:9.0pt;'>"
								+ NoOfManDays + "</span></p> </td></tr>");
				grandTotal = grandTotal.add(NoOfManDays);
			}
		}
		weeklyBillingDetail
				.append("<tr><td colspan='7' style='border:solid gray 1.0pt;border-top:none;adding:1.5pt 1.5pt 3.0pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='center' ><b><span style='font-size:9.0pt;'>Grand Total</span></b></p> </td>"
						+ "<td style='border:none;border-bottom:solid gray 1.0pt; border-right:solid gray 1.0pt; padding:1.5pt 1.5pt 3.0pt 3.75pt'> <p style='margin:0px !important; font-size:9pt' align='center' ><span style='font-size:9.0pt;'>"
						+ grandTotal + "</span></p> </td>" + "</tr></table>");
		String weeklyBillingDetails = weeklyBillingDetail.toString();
		map.put("weeklyBillingDetail", weeklyBillingDetails);
		

		try {

		     LocalDate localDate = invoice.getArInvoiceDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
		     int year  = localDate.getYear();
		     int month = localDate.getMonthValue();
	         String updatedInvoiceNo = "";
	         String accountName = "";
	         String monthName = "";
			 monthName = DateConverter.theMonth(month);
			 accountName = project.getAccountName().replaceAll("[+.^:,~]", "");
			 Assert.notNull(templateName, "The templateName can not be null");

			 String statusCompleted = "Completed";
			 String FileName = null;
			 if (invoice.getInvoiceStatus().equals(statusCompleted)) {
				 if(invoice.getFinalInvoiceNo()!=null) {
				updatedInvoiceNo = invoice.getFinalInvoiceNo().replaceAll("[\\s++.^:,~]", "");
				FileName = "Invoice-" + monthName + "-InfoCepts-" + accountName+ "-"+updatedInvoiceNo;
				 }
			 } else {
				updatedInvoiceNo = invoice.getInvoiceNo().replaceAll("[\\s++.^:,~]", "");
				FileName = "Invoice-" + monthName + "-InfoCepts-" + accountName+"-"+updatedInvoiceNo;
			 }

			Context ctx = new Context();
			if (map != null) {
				Iterator itMap = map.entrySet().iterator();
				while (itMap.hasNext()) {
					Map.Entry pair = (Map.Entry) itMap.next();
					ctx.setVariable(pair.getKey().toString(), pair.getValue());
				}
			}

			String processedHtml = templateEngine.process(templateName, ctx);
			WordprocessingMLPackage wordMLPackage = null;
			if (invoice.getInvoiceType().equals("Expense Invoice") || invoice.getInvoiceType().equals("Inter-Unit Invoice")) {
			
				if(billingUnitId == 2 || billingUnitId == 3) {
					
					String landscapeString = Docx4jProperties.getProperties().getProperty("docx4j.PageOrientationLandscape", "true");
					boolean landscape = Boolean.parseBoolean(landscapeString);
					wordMLPackage = WordprocessingMLPackage.createPackage(PageSizePaper.valueOf("A4"), landscape);				
				}else {
					wordMLPackage = WordprocessingMLPackage.createPackage(PageSizePaper.valueOf("A4"), false);
				}
			} else {
				if(invoiceInfo.getOnsiteOffShoreSplit()!=null && invoiceInfo.getOnsiteOffShoreSplit() == true) {
					String landscapeString = Docx4jProperties.getProperties().getProperty("docx4j.PageOrientationLandscape", "true");
					boolean landscape = Boolean.parseBoolean(landscapeString);
					wordMLPackage = WordprocessingMLPackage.createPackage(PageSizePaper.valueOf("A4"), landscape);				
				}else {
					wordMLPackage = WordprocessingMLPackage.createPackage(PageSizePaper.valueOf("A4"), false);					
				}
			}

			AlternativeFormatInputPart afiPart = new AlternativeFormatInputPart(new PartName("/html.html"));
			afiPart.setBinaryData(processedHtml.getBytes());
			afiPart.setContentType(new ContentType("text/html"));
			Relationship altChunkRel = wordMLPackage.getMainDocumentPart().addTargetPart(afiPart);
			CTAltChunk ac = org.docx4j.jaxb.Context.getWmlObjectFactory().createCTAltChunk();
			ac.setId(altChunkRel.getId());
			wordMLPackage.getMainDocumentPart().addObject(ac);

			if (home.exists() && home.isDirectory()) {
				String completedStatus = "Completed";
				if (invoice.getInvoiceStatus().equals(completedStatus)) {
					if (home.equals(new File(localdrive))) {
						Files.createDirectories(Paths.get(home + "/usr/home/Download/invoices/" + year + "/" + month + "/" + invoiceType + "/"));
						wordMLPackage.save(new java.io.File(home + "/usr/home/Download/invoices/" + year + "/" + month + "/"+ invoiceType + "/" + FileName + ".docx"));
						logger.info("file created");
					} else {
						if (Files.isDirectory(Paths.get(home + "/usr/home/Download/invoices/" + year + "/"))) {
							if (Files.isDirectory(Paths.get(home + "/usr/home/Download/invoices/" + year + "/" + month + "/" + invoiceType + "/"))) {
								wordMLPackage.save(new java.io.File(home + "/usr/home/Download/invoices/" + year + "/" + month + "/"+ invoiceType + "/" + FileName + ".docx"));
							} else {
								Files.createDirectories(Paths.get(home + "/usr/home/Download/invoices/" + year + "/" + month + "/" + invoiceType + "/"));
								wordMLPackage.save(new java.io.File(home + "/usr/home/Download/invoices/" + year + "/" + month + "/" + invoiceType + "/"+ FileName + ".docx"));
							}
						} else {
							Files.createDirectories(Paths.get(home + "/usr/home/Download/invoices/" + year + "/" + month + "/" + invoiceType + "/"));
							wordMLPackage.save(new java.io.File(home + "/usr/home/Download/invoices/" + year + "/" + month + "/" + invoiceType + "/"+ FileName + ".docx"));
						}
					}
				} else {
					if (home.equals(new File(localdrive))) {
						Files.createDirectories(Paths.get(home + "/usr/temp/Download/invoices/" + year + "/" + month + "/" + invoiceType + "/"));
						wordMLPackage.save(new java.io.File(home + "/usr/temp/Download/invoices/" + year + "/" + month + "/" + invoiceType + "/"+  FileName + ".docx"));
						logger.info("file created");
					} else {
						if (Files.isDirectory(Paths.get(home + "/usr/temp"))) {
							Files.createDirectories(Paths.get(home + "/usr/temp/Download/invoices/" + year + "/" + month + "/" + invoiceType + "/"));
							wordMLPackage.save(new java.io.File(home + "/usr/temp/Download/invoices/" + year + "/" + month + "/" + invoiceType + "/"+ FileName + ".docx"));
						}
					}
				}
			}

		} catch (NullPointerException e) {
			// TODO Auto-generated catch block
			logger.log(Level.SEVERE, "exceptn msg", e);
		} finally {
			if (os != null) {
				try {
					os.close();
				} catch (IOException e) {
					/* ignore */ }
			}
		}
		return outputFile.getAbsolutePath();

	}

	public String createISowPDF(String templateName, ISow isow, List<ISowDetail> isowdetail, List<ISowMilestone> isowMilestone,HttpServletRequest request) throws Exception {
				home = checkPath(request);
		        String sowNumber = "";
		        Unit unit = null;
		        Uom uom = null;
				Map<String,String> map = new HashMap<String,String>();
	    		BigDecimal billableRate = BigDecimal.ZERO;
	    		String Role = "";
	    		String Milestone = "";
				BigDecimal billableRateInUSD = BigDecimal.ZERO;
				BigDecimal expectedBillability = BigDecimal.ZERO;
				BigDecimal conversionRate = BigDecimal.ZERO;
				BigDecimal rateInSGD = BigDecimal.ZERO;
				Sow sow = null;
				String commercials = "";
				String completionDate = "";
				StringBuilder ISowDetail = new StringBuilder();
	        	StringBuilder ISowMilestone = new StringBuilder();
	        	String rateStructure = "";
	        	String roleStartDate = "";
	        	String roleEndDate = "";
	        	String LetterOfApprovalNo = "";
	    		StringBuilder LetterOfApprovalNoString = new StringBuilder();
	    		String LetterOfApprovalNoStrings = "";

				if(isow != null) {
		        	
					if (isow.getSow() != null) {
						sow = sowRepository.findOne(isow.getSow().getSowId());
						if(sow !=null) {
							map.put("SowNo", sow.getSowNo());
						}
					}	
					
					if (isow.getIsowNo() != null) {
						map.put("ISowNo", isow.getIsowNo());
					}		        						
					if (isow.getClientName() != null) {
						map.put("ClientName", isow.getClientName());
					}		        	
					if (isow.getInternalServiceProvider() != null) {
						map.put("ServiceProvider", isow.getInternalServiceProvider());
					}		        	
					if (isow.getConsultingAgrDate() != null) {
						map.put("ConsultingAgrDate", DateConverter.changeDate2(isow.getConsultingAgrDate()));
					}		        	
					if (isow.getScopeOfWork() != null) {
						map.put("ScopeOfWork", isow.getScopeOfWork());
					}		        	
					if (isow.getProjectName() != null) {
						map.put("ProjectName", isow.getProjectName());
					}		        	
					if (isow.getSowStartDate() != null) {
						map.put("SowStartDate", DateConverter.changeDate2(isow.getSowStartDate()));
					}		        	
					if (isow.getSowEndDate() != null) {
						map.put("SowEndDate", DateConverter.changeDate2(isow.getSowEndDate()));
					}							
					if (isow.getPaymentTermDays() != null) {
						map.put("PaymentTermDays", isow.getPaymentTermDays().toString());
					}							
					if (isow.getOutOfPocketExpense() != null) {
						map.put("OutOfPocketExpense", isow.getOutOfPocketExpense());
					}							
					if (isow.getBillingUnitId() != null) {
						unit = unitRepository.findOne(isow.getBillingUnitId());
						if(unit!=null){
							map.put("BillingUnitName", unit.getUnitName());
							map.put("UnitName", unit.getName());

						}												
						if (unit.getAddress() != null) {
							map.put("billingUnitAddress", unit.getAddress());
						}
					}		
					if (isow.getExecutionUnitId() != null) {
						unit = unitRepository.findOne(isow.getExecutionUnitId());
						if(unit!=null){
							map.put("ExecutionUnit", unit.getUnitName());
							map.put("exeUnitName", unit.getName());

							if (unit.getAddress() != null) {
								map.put("executionUnitAddress", unit.getAddress());
							}
						}						
						map.put("Execution", isow.getExecutionUnit());
						LetterOfApprovalNo = unit.getLetterOfApprovalNo();
						
						if(LetterOfApprovalNo!=null) {
							LetterOfApprovalNoString.append("<tr class='trLineHeight'> <td class='tdCode'><p>Letter Of Approval No</p></td><td class='tdCodeCollon'><p>:</p></td>"  
									+" <td class='tdCodeDescription'> <p>"+LetterOfApprovalNo+"</p> </td> </tr>");							
						}
						

						LetterOfApprovalNoStrings = LetterOfApprovalNoString.toString();
						map.put("LetterOfApprovalNoStrings", LetterOfApprovalNoStrings);
						
					}		
					if (isow.getName1() != null) {
						map.put("Name1", isow.getName1());
					}		
					if (isow.getName2() != null) {
						map.put("Name2", isow.getName2());
					}											
					if (isow.getPartyTitle1() != null) {
						map.put("PartyTitle1", isow.getPartyTitle1());
					}	
					if (isow.getPartyTitle2() != null) {
						map.put("PartyTitle2", isow.getPartyTitle2());
					}	
					if (isow.getPartyDate() != null) {
						map.put("PartyDate", DateConverter.changeDate2(isow.getPartyDate()));
					}	

					if (isow.getConversionRate() != null) {
						conversionRate = isow.getConversionRate();
					}
					
						map.put("Notes", "Associates may be on boarded and off boarded as mutually agreed.");
										
		        }
				if(!isowMilestone.isEmpty()) {

		        	Iterator<ISowMilestone> it = isowMilestone.iterator();
		        	ISowMilestone.append("<table name='date-table' style='float: left;width:99.7%'  cellpadding='0' cellspacing='0'>"
							+ "<tr>"
							+ "<td class='gridHeaderRow' align='center' width='100'><p style='margin-bottom:0px !important'>&nbsp;Milestones&nbsp;</p></td>"
							+ "<td class='gridHeaderRow' align='center'><p style='margin-bottom:0px !important'>&nbsp;Completion&nbsp;Date&nbsp;</p></td>"
							+ "<td class='gridHeaderRow' align='center'><p style='margin-bottom:0px !important'>&nbsp;Rate&nbsp;Structure (Hrly/Daily/Monthly)&nbsp;</p></td>"
							+ "<td class='gridHeaderRow' align='center'><p style='margin-bottom:0px !important'>&nbsp;Rate&nbsp;</p></td>"
							+ "<td class='gridHeaderRow' align='center'><p style='margin-bottom:0px !important'>&nbsp;Billability&nbsp;(%)&nbsp;</p></td>");
		        	
		        	if(conversionRate != null && conversionRate != BigDecimal.ZERO) {
		        		ISowMilestone.append("<td class='gridHeaderRow' align='center'><p style='margin-bottom:0px !important'>&nbsp;Conversion&nbsp;Rate&nbsp;</p></td>"
								+"<td class='gridHeaderRow' align='center' width='60'><p style='margin-bottom:0px !important'>&nbsp;Rate(SGD)&nbsp;</p></td>");
		        	}
		        	
		    		while (it.hasNext()) {
		    			ISowMilestone isowMilestones = it.next();
						
						if (isowMilestones.getDescription() != null) {
							Milestone = isowMilestones.getDescription();
						}
						if (isowMilestones.getUom() != null) {
							Role = isowMilestones.getUom();
						}
						if (isowMilestones.getAmount() != null) {
							billableRateInUSD = isowMilestones.getAmount();
						}
						
						if (isowMilestones.getExpectedBillability() != null) {
							expectedBillability = isowMilestones.getExpectedBillability();
						}
						
						if (isowMilestones.getMilestoneEndDate() != null) {
							completionDate = DateConverter.changeDate2(isowMilestones.getMilestoneEndDate());
						}
						
						if (isowMilestones.getRateInSGD() != null) {
							rateInSGD = isowMilestones.getRateInSGD();
						}
						
						ISowMilestone.append("<tr><td class='pnTrData'><p style='margin-bottom:0px !important'>").append(Milestone)
								.append("</p></td><td class='trData'><p style='margin-bottom:0px !important'>").append(completionDate)
								.append("</p></td><td class='trData'><p style='margin-bottom:0px !important'>"+Role)
								.append("</p></td><td class='trData'><p style='margin-bottom:0px !important'>"+billableRateInUSD)
								.append("</p></td><td class='trData'><p style='margin-bottom:0px !important'>"+expectedBillability);
						if(conversionRate != null && conversionRate != BigDecimal.ZERO) {
							ISowMilestone.append("</p></td><td class='trData'><p style='margin-bottom:0px !important'>"+conversionRate)
								.append("</p></td><td class='trData'><p style='margin-bottom:0px !important'>"+rateInSGD);
							}
						ISowMilestone.append("</tr>");
					}
		    		ISowMilestone.append("</table>");
					commercials = ISowMilestone.toString();
				}
		        
		        if(!isowdetail.isEmpty()) {
	        	
		        	uom =  uomRepository.findOne(isow.getUomId());

		        	if("Day".equals(uom.getName())){
		        		rateStructure = "Daily";
		        	}else if("Hour".equals(uom.getName())){
		        		rateStructure = "Hourly";
		        	}else if("Week".equals(uom.getName())){
		        		rateStructure = "Weekly";
		        	}else if("Month".equals(uom.getName())){
		        		rateStructure = "Monthly";
		        	}
		        	
		        	Iterator<ISowDetail> it = isowdetail.iterator();
		        	ISowDetail.append("<table name='date-table' style='float: left;width:99.7%'  cellpadding='0' cellspacing='0'>"
							+ "<tr>"
							+ "<td class='gridHeaderRow' align='center' width='100'><p style='margin-bottom:0px !important'>&nbsp;Role&nbsp;</p></td>"
							+ "<td class='gridHeaderRow' align='center'><p style='margin-bottom:0px !important'>&nbsp;Role Start&nbsp;Date&nbsp;</p></td>"
							+ "<td class='gridHeaderRow' align='center'><p style='margin-bottom:0px !important'>&nbsp;Role End&nbsp;Date&nbsp;</p></td>"
							+ "<td class='gridHeaderRow' align='center'><p style='margin-bottom:0px !important'>&nbsp;Rate&nbsp;Structure (Hrly/Daily/Monthly)&nbsp;</p></td>"
							+ "<td class='gridHeaderRow' align='center'><p style='margin-bottom:0px !important'>&nbsp;Rate(USD)&nbsp;</p></td>"
							+ "<td class='gridHeaderRow' align='center'><p style='margin-bottom:0px !important'>&nbsp;Billability&nbsp;(%)&nbsp;</p></td>");
							
		        	if(conversionRate != null && conversionRate != BigDecimal.ZERO) {
						ISowDetail.append("<td class='gridHeaderRow' align='center'><p style='margin-bottom:0px !important'>&nbsp;Conversion&nbsp;Rate&nbsp;</p></td>"
								+"<td class='gridHeaderRow' align='center' width='60'><p style='margin-bottom:0px !important'>&nbsp;Rate(SGD)&nbsp;</p></td>");
		        	}

		    		while (it.hasNext()) {
						ISowDetail ISowdetail = it.next();
						
						if (ISowdetail.getBillableRate() != null) {
							billableRate = ISowdetail.getBillableRate();
						}
						
						if (ISowdetail.getClientRole() != null) {
							Role = ISowdetail.getClientRole();
						}
						
						if (ISowdetail.getBillableRate() != null) {
							billableRateInUSD = ISowdetail.getBillableRate();
						}
						
						if (ISowdetail.getExpectedBillability() != null) {
							expectedBillability = ISowdetail.getExpectedBillability();
						}

						if (ISowdetail.getRateInSGD() != null) {
							rateInSGD = ISowdetail.getRateInSGD();
						}
						
						if (ISowdetail.getSowRoleStartDate() != null) {
							roleStartDate = DateConverter.changeDate2(ISowdetail.getSowRoleStartDate());
						}
						
						if (ISowdetail.getSowRoleEndDate() != null) {
							roleEndDate = DateConverter.changeDate2(ISowdetail.getSowRoleEndDate());
						}

						
						ISowDetail.append("<tr><td class='pnTrData'><p style='margin-bottom:0px !important'>").append(Role)
								.append("</p></td><td class='trData'><p style='margin-bottom:0px !important'>").append(roleStartDate)
								.append("</p></td><td class='trData'><p style='margin-bottom:0px !important'>").append(roleEndDate)
								.append("</p></td><td class='trData'><p style='margin-bottom:0px !important'>").append(rateStructure)
								.append("</p></td><td class='trData'><p style='margin-bottom:0px !important'>"+billableRateInUSD)
								.append("</p></td><td class='trData'><p style='margin-bottom:0px !important'>"+expectedBillability);
						if(conversionRate != null && conversionRate != BigDecimal.ZERO) {
						ISowDetail.append("</p></td><td class='trData'><p style='margin-bottom:0px !important'>"+conversionRate)
								.append("</p></td><td class='trData'><p style='margin-bottom:0px !important'>"+rateInSGD);
						}
						ISowDetail.append("</tr>");
					}
		    		
		    		ISowDetail.append("</table>");
					commercials = ISowDetail.toString();
		        }
		    		map.put("commercials", commercials);
		    		
		    		
		    		

				try {
					 Assert.notNull(templateName, "The templateName can not be null");
					 String FileName = isow.getIsowNo()+"";
					 Context ctx = new Context();
					 if (map != null) {
						Iterator itMap = map.entrySet().iterator();
						while (itMap.hasNext()) {
							Map.Entry pair = (Map.Entry) itMap.next();
							ctx.setVariable(pair.getKey().toString(), pair.getValue());
						}
					 }
					 String processedHtml = templateEngine.process(templateName, ctx);
					 WordprocessingMLPackage wordMLPackage = null;
					 wordMLPackage = WordprocessingMLPackage.createPackage(PageSizePaper.valueOf("A4"), false);
					 AlternativeFormatInputPart afiPart = new AlternativeFormatInputPart(new PartName("/html.html"));
					 afiPart.setBinaryData(processedHtml.getBytes());
					 afiPart.setContentType(new ContentType("text/html"));
					 Relationship altChunkRel = wordMLPackage.getMainDocumentPart().addTargetPart(afiPart);
					 CTAltChunk ac = org.docx4j.jaxb.Context.getWmlObjectFactory().createCTAltChunk();
					 ac.setId(altChunkRel.getId());
					 wordMLPackage.getMainDocumentPart().addObject(ac);
				     LocalDate localDate = isow.getConsultingAgrDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
				     int year  = localDate.getYear();
				     int month = localDate.getMonthValue();
				     
					 if(home.exists() && home.isDirectory()) {
						if (home.equals(new File(localdrive))) {
							Files.createDirectories(Paths.get(home + "/usr/home/Download/isow/" + year + "/" + month + "/"));
							wordMLPackage.save(new java.io.File(home + "/usr/home/Download/isow/" + year + "/" + month + "/"+  FileName + ".docx"));
						} else {	
							Files.createDirectories(Paths.get(home + "/usr/home/Download/isow/" + year + "/" + month + "/"));
							wordMLPackage.save(new java.io.File(home + "/usr/home/Download/isow/" + year + "/" + month + "/" + FileName + ".docx"));
						}
					}
				} catch (NullPointerException e) {
					logger.log(Level.SEVERE, "exceptn msg", e);
				} finally {
					if (os != null) {
						try {
							os.close();
						} catch (IOException e) {
							/* ignore */ }
					}
				}
				return outputFile.getAbsolutePath();
	}
	
	
	public File checkPath(HttpServletRequest request) throws URISyntaxException, IOException {
		String pathSeparator=null;String finalStr=null;
		if (request.getServerName().equals("localhost")) {
			home = new File(localdrive);
		} else {
			if (!infobizenvhost.equals("")) {
				CodeSource codeSource = this.getClass().getProtectionDomain().getCodeSource();
				rootPath = new File(codeSource.getLocation().toURI().getPath());
				String path = rootPath.getCanonicalPath();
				logger.info("path" + path);//returns /usr/share/tomcat8
				char c;
				c=path.charAt(0);
				String separator=File.separator;
				if(Character.toString(c).equals(separator)){
					//pathSeparator="/";
//					int firstIndex=path.indexOf(separator);
//					String substr=path.substring(firstIndex+1);//returns usr/share/tomcat8
//					int nextIndex=substr.indexOf(separator);
//					finalStr=substr.substring(0,nextIndex);// returns usr
//					finalStr=separator+finalStr;//returns /usr
					finalStr=separator;
				}
				else{
//					String s=Character.toString(c);
//					String colonPathSeparator=":";
//					//pathSeparator="\\";
//					s=s.concat(colonPathSeparator);
//					finalStr=s.concat(separator);
					int index=path.indexOf(separator);
					finalStr=path.substring(0,index);
				}
				home = new File(finalStr);
			}
		}
		return home;
	}

	public String getPath(MultipartFile file, HttpServletRequest request,Integer sowId) {
		File outputFile = null;String path=null;
		try {
			if (!file.isEmpty()) {
				home = checkPath(request);
				if (home.exists() && home.isDirectory()) {
					if (home.equals(new File(localdrive))) {
						path=File.separator+"usr"+File.separator+"home"+File.separator+"Download"+File.separator+"sow"+File.separator;
						if (Files.isDirectory(Paths.get(home + path))){
							outputFile = new File(home + path + sowId+"-"+file.getOriginalFilename());
							writeToFile(file, outputFile);
						}
						else{
							Files.createDirectories(Paths.get(home + path));
							outputFile = new File(home + path + sowId+"-"+file.getOriginalFilename());
							writeToFile(file, outputFile);
						}
						
					} else {
//						String path=home.getPath();
//						char c=path.charAt(0);
//						if(c=='/'){
//							pathSeparator="/";
//						}
//						else{
//							pathSeparator="\\";
//						}
						String separator=File.separator;
						path=home.getPath();
						if(path.equals(separator)){
							path="usr"+File.separator+"home"+File.separator+"Download";
						}
						else{
							path=File.separator+"usr"+File.separator+"home"+File.separator+"Download";
						}
						if (Files.isDirectory(Paths.get(home + path))) {
							path=home.getPath();
							if(path.equals(separator)){
								path="usr"+File.separator+"home"+File.separator+"Download"+File.separator+"sow"+File.separator;
							}
							else{
								path=File.separator+"usr"+File.separator+"home"+File.separator+"Download"+File.separator+"sow"+File.separator;
							}
							
							if (Files.isDirectory(Paths.get(home + path))) {
								outputFile = new File(home + path + sowId+"-"+file.getOriginalFilename());
								writeToFile(file, outputFile);
							} else {
								//pathSeparator="\\";
								//path="usr"+File.separator+"home"+File.separator+"Download"+File.separator+"sow"+File.separator;
								Files.createDirectories(Paths.get(home + path));
								outputFile = new File(home + path +sowId+"-"+file.getOriginalFilename());
								writeToFile(file, outputFile);
							}
						}
					}
				}
			}
		} catch (Exception e) {
			logger.log(Level.SEVERE, "exceptn msg", e);
		} finally {
			if (os != null) {
				try {
					// os.flush();
					os.close();
				} catch (IOException e) {
					/* ignore */ }
			}
		}
		return outputFile.getAbsolutePath();
	}
	// to get end client Unit ID for internal invoices
	public Integer endClientProjectId(Integer endClientId) {
		Project endClientProject = null;
		Integer endClientbillingUnitId = null;
		endClientProject = manager.createNamedQuery("getProjectById", Project.class)
				.setParameter("itemId", endClientId).getSingleResult();
		endClientbillingUnitId = endClientProject.getBillingUnitId();
		return endClientbillingUnitId;
	}
	public void writeToFile(MultipartFile file, File outputFile) throws IOException {
		FileOutputStream stream = null;
		try {
			byte[] bytes = file.getBytes();
			stream = new FileOutputStream(outputFile);
			stream.write(bytes);
		} finally {
			stream.close();
		}
	}
	
	   public String numberToCurrencyConverter(BigDecimal number) {
		   if(number==null) {
			   number = BigDecimal.ZERO;
		   }
		      NumberFormat numberFormat = NumberFormat.getNumberInstance(Locale.US);
		      String numberAsString = numberFormat.format(number);
			return numberAsString;
		   }
	   
	   
	   public String getTravelDocPath(MultipartFile file, HttpServletRequest request,Integer infoTravelId) {
			File outputFile = null;String path=null;
			try {
				if (!file.isEmpty()) {
					home = checkPath(request);
					if (home.exists() && home.isDirectory()) {
						if (home.equals(new File(localdrive))) {
							path=File.separator+"usr"+File.separator+"home"+File.separator+"Download"+File.separator+"infotravel"+File.separator;
							if (Files.isDirectory(Paths.get(home + path))){
								outputFile = new File(home + path + infoTravelId+"-"+file.getOriginalFilename());
								writeToFile(file, outputFile);
							}
							else{
								Files.createDirectories(Paths.get(home + path));
								outputFile = new File(home + path + infoTravelId+"-"+file.getOriginalFilename());
								writeToFile(file, outputFile);
							}
							
						} else {
//							String path=home.getPath();
//							char c=path.charAt(0);
//							if(c=='/'){
//								pathSeparator="/";
//							}
//							else{
//								pathSeparator="\\";
//							}
							String separator=File.separator;
							path=home.getPath();
							if(path.equals(separator)){
								path="usr"+File.separator+"home"+File.separator+"Download";
							}
							else{
								path=File.separator+"usr"+File.separator+"home"+File.separator+"Download";
							}
							if (Files.isDirectory(Paths.get(home + path))) {
								path=home.getPath();
								if(path.equals(separator)){
									path="usr"+File.separator+"home"+File.separator+"Download"+File.separator+"infotravel"+File.separator;
								}
								else{
									path=File.separator+"usr"+File.separator+"home"+File.separator+"Download"+File.separator+"infotravel"+File.separator;
								}
								
								if (Files.isDirectory(Paths.get(home + path))) {
									outputFile = new File(home + path + infoTravelId+"-"+file.getOriginalFilename());
									writeToFile(file, outputFile);
								} else {
									//pathSeparator="\\";
									//path="usr"+File.separator+"home"+File.separator+"Download"+File.separator+"sow"+File.separator;
									Files.createDirectories(Paths.get(home + path));
									outputFile = new File(home + path +infoTravelId+"-"+file.getOriginalFilename());
									writeToFile(file, outputFile);
								}
							}
						}
					}
				}
			} catch (Exception e) {
				logger.log(Level.SEVERE, "exceptn msg", e);
			} finally {
				if (os != null) {
					try {
						// os.flush();
						os.close();
					} catch (IOException e) {
						/* ignore */ }
				}
			}
			return outputFile.getAbsolutePath();
		}
	   
	   
	   public String getDeFilePath(MultipartFile file, HttpServletRequest request,Integer Id, String type) {
			File outputFile = null;String path=null;
			try {
				
				
				
				if (!file.isEmpty()) {
					home = checkPath(request);
					DeWsr deWsr = null;
					DeMsr deMsr = null;
					DeAppreciation deAppreciation = null;
					DeComplaint deComplaint = null;
					DeValueAdd deValueAdd = null;
					DePhUpdate dePhUpdate = null;

					Project project = null;
					Portfolio portfolio = null;
					String projectName = "";
					if(type.equals("appreciation")) {
						deAppreciation = deAppreciationRepository.findOne(Id);
						if(deAppreciation.getProjectId() != null) {
							project = manager.createNamedQuery("getProjectById", Project.class).setParameter("itemId", deAppreciation.getProjectId()).getSingleResult();
							projectName = project.getTitle();
						}
					}else if(type.equals("dewsr")){
						deWsr = deWsrRepository.findOne(Id);	
						if(deWsr.getProjectId() != null) {
							project = manager.createNamedQuery("getProjectById", Project.class).setParameter("itemId", deWsr.getProjectId()).getSingleResult();
							projectName = project.getTitle();
						}
					}else if(type.equals("complaints")){
						deComplaint = deComplaintRepository.findOne(Id);	
						if(deComplaint.getProjectId() != null) {
							project = manager.createNamedQuery("getProjectById", Project.class).setParameter("itemId", deComplaint.getProjectId()).getSingleResult();
							projectName = project.getTitle();
						}
					}else if(type.equals("valueAdd")){
						deValueAdd = deValueAddRepository.findOne(Id);	
						if(deValueAdd.getProjectId() != null) {
							project = manager.createNamedQuery("getProjectById", Project.class).setParameter("itemId", deValueAdd.getProjectId()).getSingleResult();
							projectName = project.getTitle();
						}
					}else if(type.equals("demsr")){
						deMsr = deMsrRepository.findOne(Id);	
						if(deMsr.getProjectId() != null) {
							project = manager.createNamedQuery("getProjectById", Project.class).setParameter("itemId", deMsr.getProjectId()).getSingleResult();
							projectName = project.getTitle();
						}
					}else if(type.equals("phupdate")){
						dePhUpdate = dePhUpdateRepository.findOne(Id);	
						if(dePhUpdate.getPortfolioId() != null) {
							portfolio = manager.createNamedQuery("getPortfolioById", Portfolio.class).setParameter("itemId", dePhUpdate.getPortfolioId()).getSingleResult();
							projectName = portfolio.getTitle();
						}
					}
					
					if (home.exists() && home.isDirectory()) {
						if (home.equals(new File(localdrive))) {
							path=File.separator+"usr"+File.separator+"home"+File.separator+"Download"+File.separator+"dePmoReview"+File.separator;
							if (Files.isDirectory(Paths.get(home + path))){
								outputFile = new File(home + path + Id+"-"+projectName+"-"+file.getOriginalFilename());
								writeToFile(file, outputFile);
							}
							else{
								Files.createDirectories(Paths.get(home + path));
								outputFile = new File(home + path + Id+"-"+projectName+"-"+file.getOriginalFilename());
								writeToFile(file, outputFile);
							}						
						} else {
							String separator=File.separator;
							path=home.getPath();
							if(path.equals(separator)){
								path="usr"+File.separator+"home"+File.separator+"Download";
							}
							else{
								path=File.separator+"usr"+File.separator+"home"+File.separator+"Download";
							}
							if (Files.isDirectory(Paths.get(home + path))) {
								path=home.getPath();
								if(path.equals(separator)){
									path="usr"+File.separator+"home"+File.separator+"Download"+File.separator+"dePmoReview"+File.separator;
								}else{
									path=File.separator+"usr"+File.separator+"home"+File.separator+"Download"+File.separator+"dePmoReview"+File.separator;
								}
								
								if (Files.isDirectory(Paths.get(home + path))) {
									outputFile = new File(home + path + Id+"-"+projectName+"-"+file.getOriginalFilename());
									writeToFile(file, outputFile);
								} else {
									//pathSeparator="\\";
									//path="usr"+File.separator+"home"+File.separator+"Download"+File.separator+"sow"+File.separator;
									Files.createDirectories(Paths.get(home + path));
									outputFile = new File(home + path +Id+"-"+projectName+"-"+file.getOriginalFilename());

									writeToFile(file, outputFile);
								}

							}
						}
					}
				}
			} catch (Exception e) {
				logger.log(Level.SEVERE, "exceptn msg", e);
			} finally {
				if (os != null) {
					try {
						// os.flush();
						os.close();
					} catch (IOException e) {
						/* ignore */ }
				}
			}
			return outputFile.getAbsolutePath();
		}
	   
	   
	   public String getTravelDeskDocPath(MultipartFile file, HttpServletRequest request,Integer infoTravelDeskId) {
			File outputFile = null;String path=null;
			try {
				if (!file.isEmpty()) {
					home = checkPath(request);
					if (home.exists() && home.isDirectory()) {
						if (home.equals(new File(localdrive))) {
							path=File.separator+"usr"+File.separator+"home"+File.separator+"Download"+File.separator+"infotravel"+File.separator;
							if (Files.isDirectory(Paths.get(home + path))){
								outputFile = new File(home + path + infoTravelDeskId+"-"+file.getOriginalFilename());
								writeToFile(file, outputFile);
							}
							else{
								Files.createDirectories(Paths.get(home + path));
								outputFile = new File(home + path + infoTravelDeskId+"-"+file.getOriginalFilename());
								writeToFile(file, outputFile);
							}
							
						} else {
							String separator=File.separator;
							path=home.getPath();
							if(path.equals(separator)){
								path="usr"+File.separator+"home"+File.separator+"Download";
							}
							else{
								path=File.separator+"usr"+File.separator+"home"+File.separator+"Download";
							}
							if (Files.isDirectory(Paths.get(home + path))) {
								path=home.getPath();
								if(path.equals(separator)){
									path="usr"+File.separator+"home"+File.separator+"Download"+File.separator+"infotravel"+File.separator;
								}
								else{
									path=File.separator+"usr"+File.separator+"home"+File.separator+"Download"+File.separator+"infotravel"+File.separator;
								}
								
								if (Files.isDirectory(Paths.get(home + path))) {
									outputFile = new File(home + path + infoTravelDeskId+"-"+file.getOriginalFilename());
									writeToFile(file, outputFile);
								} else {
									Files.createDirectories(Paths.get(home + path));
									outputFile = new File(home + path +infoTravelDeskId+"-"+file.getOriginalFilename());
									writeToFile(file, outputFile);
								}
							}
						}
					}
				}
			} catch (Exception e) {
				logger.log(Level.SEVERE, "exceptn msg", e);
			} finally {
				if (os != null) {
					try {
						// os.flush();
						os.close();
					} catch (IOException e) {
						/* ignore */ }
				}
			}
			return outputFile.getAbsolutePath();
		}
	   
	   
	   /**
	     * This method is generate file path for file uploaded for specific row in goal entity
	     * based on primaryKey Of pmsGoal Table 
	   */	
	   public String getPmsGoalDocPath(MultipartFile file, HttpServletRequest request,Integer goalId) {
			File outputFile = null;String path=null;
			try {
				if (!file.isEmpty()) {
					home = checkPath(request);
					if (home.exists() && home.isDirectory()) {
						if (home.equals(new File(localdrive))) {
							path=File.separator+"usr"+File.separator+"home"+File.separator+"Download"+File.separator+"pmsgoal"+File.separator;
							if (Files.isDirectory(Paths.get(home + path))){
								outputFile = new File(home + path + goalId+"-"+file.getOriginalFilename());
								writeToFile(file, outputFile);
							}
							else{
								Files.createDirectories(Paths.get(home + path));
								outputFile = new File(home + path + goalId+"-"+file.getOriginalFilename());
								writeToFile(file, outputFile);
							}
							
						} else {
							String separator=File.separator;
							path=home.getPath();
							if(path.equals(separator)){
								path="usr"+File.separator+"home"+File.separator+"Download";
							}
							else{
								path=File.separator+"usr"+File.separator+"home"+File.separator+"Download";
							}
							if (Files.isDirectory(Paths.get(home + path))) {
								path=home.getPath();
								if(path.equals(separator)){
									path="usr"+File.separator+"home"+File.separator+"Download"+File.separator+"pmsgoal"+File.separator;
								}
								else{
									path=File.separator+"usr"+File.separator+"home"+File.separator+"Download"+File.separator+"pmsgoal"+File.separator;
								}
								
								if (Files.isDirectory(Paths.get(home + path))) {
									outputFile = new File(home + path + goalId+"-"+file.getOriginalFilename());
									writeToFile(file, outputFile);
								} else {
									
									Files.createDirectories(Paths.get(home + path));
									outputFile = new File(home + path +goalId+"-"+file.getOriginalFilename());
									writeToFile(file, outputFile);
								}
							}
						}
					}
				}
			} catch (Exception e) {
				logger.log(Level.SEVERE, "exceptn msg", e);
			} finally {
				if (os != null) {
					try {
						// os.flush();
						os.close();
					} catch (IOException e) {
						/* ignore */ }
				}
			}
			return outputFile.getAbsolutePath();
		}
	   
	   /**
	 * @param fileName - Name of the file using which the excel file will be created.
	 * @param Hashtable - Sheet name as a key and column header as values.
	 * @param sheetNamesAndDataMap - Sheet name as a key and List of object array as a value.
	 * @return - Export file object.
	 */
	public static synchronized File excelExport(String fileName, Hashtable<String, List<String>> columnTable,
			Hashtable<String, List<Object[]>> sheetNamesAndDataTable) {
		Path projectFolderPath = Paths.get("").toAbsolutePath();
		StringBuilder filePath = new StringBuilder("");
		File exportedFile = null;
		// This object creates one excel file.
		try (XSSFWorkbook excel = new XSSFWorkbook()) {

			if (StringUtils.isEmpty(fileName)) {
				fileName = "exported_" + RandomUtils.nextLong(1, 999999999999999999L);
				filePath.append(projectFolderPath.toFile().getAbsolutePath().concat(fileName.concat(".xlsx")));
			} else {
				filePath.append(projectFolderPath.toFile().getAbsolutePath().concat(fileName.concat(".xlsx")));
			}

			if (MapUtils.isEmpty(columnTable)) {
				throw new UnsupportedOperationException("CAN NOT CREATE A SHEET WITHOUT COLUMN HEADERS!");
			}

			Set<Entry<String, List<Object[]>>> entrySet = sheetNamesAndDataTable.entrySet();

			for (Entry<String, List<Object[]>> entry : entrySet) {
				XSSFSheet sheet = excel.createSheet(entry.getKey());
				List<Object[]> dataList = entry.getValue();
				// Header row.
				XSSFRow headerRow = sheet.createRow(0);
				// Names in below list will be used as column header for the respective sheet.
				List<String> colList = columnTable.get(entry.getKey());

				if (CollectionUtils.isEmpty(colList) && colList.stream().anyMatch(StringUtils::isEmpty)) {
					throw new UnsupportedOperationException("CAN NOT CREATE HEADER WITH BLANK/NULL COLUMN NAMES!");
				}
				// Header cells are created here.
				colList.forEach(header -> headerRow.createCell(colList.indexOf(header), CellType.STRING));
				int dataListSize = dataList.size();
				for (int count = 0; count < dataListSize; count++) {
					Object[] data = dataList.get(count);
					XSSFRow row = sheet.createRow(++count);
					for (int index = 0; index < data.length; index++) {
						if (data[index] instanceof String) {
							row.createCell(index, CellType.STRING).setCellValue((String) data[index]);
						} else if (data[index] instanceof Number) {
							row.createCell(index, CellType.NUMERIC).setCellValue((Double) data[index]);
						} else if (data[index] instanceof Date) {
							row.createCell(index, CellType.STRING).setCellValue((Date) data[index]);
						}
					}
				}
			}
			exportedFile = new File(filePath.toString());
			try (FileOutputStream outputStream = new FileOutputStream(exportedFile)) {
				excel.write(outputStream);
			} catch (IOException e) {
				logger.log(Level.SEVERE, "ERROR WHILE WRITING FILE: \n " + filePath.toString(), e);
			}
		} catch (IOException ex) {
			logger.log(Level.SEVERE, "ERROR WHILE EXPORTING FILE: \n " + filePath.toString(), ex);
		}
		return exportedFile;
	}
}
