package com.infocepts.otc.controllers;

import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.infocepts.otc.entities.BillingType;
import com.infocepts.otc.repositories.BillingTypeRepository;
import com.infocepts.otc.services.TimesheetService;

@RestController
@RequestMapping(value="/billingtype",headers="referer")
public class BillingTypeController {

	final Logger logger = Logger.getLogger(BillingTypeController.class);
	
	@Autowired
	BillingTypeRepository repository;
	
	@Autowired
	TimesheetService service;
	
	@RequestMapping(method=RequestMethod.POST)
	public BillingType addBillingType(@RequestBody BillingType billingtype)
	{
		try{
			if(service.isAdmin()){
				billingtype.setBillingTypeId(null);
				repository.save(billingtype);
			}
		}catch(Exception e){
			logger.error(e);
		}
		return billingtype;
	}	
 
	 @RequestMapping(method=RequestMethod.GET)
	 public List<BillingType> getAllBillingTypes(){
		 List<BillingType> billingtypelist=null;
		 try{
			 billingtypelist = repository.findAll();
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return billingtypelist;
	 }

	@RequestMapping(value="/{billingTypeId}",method=RequestMethod.GET)
	 public BillingType getBillingType(@PathVariable Integer billingTypeId){
		 BillingType billingtype=null;
		 try{
			 billingtype = repository.findOne(billingTypeId);
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return billingtype;
	 }
	 
	@RequestMapping(value="/{billingTypeId}",method=RequestMethod.PUT)
	 public BillingType updateBillingType(@RequestBody BillingType updatedBillingType,@PathVariable Integer billingTypeId){
		 try{
			 if(service.isAdmin()){
				 updatedBillingType.setBillingTypeId(billingTypeId);
				 repository.save(updatedBillingType);
			 }
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return updatedBillingType;
	 }
	 
	 @RequestMapping(value="/{billingTypeId}",method=RequestMethod.DELETE)
	 public void deleteBillingType(@PathVariable Integer billingTypeId){
		 try{
			 if(service.isAdmin()){
				 repository.delete(billingTypeId);
			 }
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
	 }	 
	
}
