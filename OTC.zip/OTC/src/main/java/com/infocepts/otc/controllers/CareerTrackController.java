package com.infocepts.otc.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.infocepts.otc.entities.CareerTrack;
import com.infocepts.otc.repositories.CareerTrackRepository;
import com.infocepts.otc.services.TimesheetService;

@RestController
@RequestMapping(value="/careertrack",headers="referer")
public class CareerTrackController {
	@Autowired
	CareerTrackRepository careerTrackRepository;
	
	@Autowired
	TimesheetService service;
	
	@RequestMapping(method=RequestMethod.POST)
	public CareerTrack addCareerTrack(@RequestBody CareerTrack careerTrack){
		careerTrack.setCareerTrackId(null);
		Boolean isAValidCall = false;
		if(service.isAdmin())
		{
			isAValidCall = true;
		}
		if(isAValidCall) {
			
			careerTrackRepository.save(careerTrack);
		}
		return careerTrack;
	}
	
	@RequestMapping(method=RequestMethod.GET)
	public List<CareerTrack> getCareerTrack(){
		List<CareerTrack> list = null;
		Boolean isAValidCall = false;
		if(service.isAdmin())
		{
			isAValidCall = true;
		}
		//if(isAValidCall) {
			list = careerTrackRepository.findAll();
		//}
		return list;
	}
	
	@RequestMapping(value="/{careerTrackId}",method=RequestMethod.GET)
	public CareerTrack getCareerTrack(@PathVariable Integer careerTrackId){
		CareerTrack careerTrack = null;
		Boolean isAValidCall = false;
		if(service.isAdmin())
		{
			isAValidCall = true;
		}
		if(isAValidCall) {
			
			careerTrack = careerTrackRepository.findOne(careerTrackId);
		}
		return careerTrack;
	}
	
	@RequestMapping(value="/{careerTrackId}", method=RequestMethod.PUT)
	public CareerTrack updateCareerTrack(@PathVariable Integer careerTrackId,  @RequestBody CareerTrack updatedCareerTrack){
		updatedCareerTrack.setCareerTrackId(careerTrackId);
		Boolean isAValidCall = false;
		if(service.isAdmin())
		{
			isAValidCall = true;
		}
		if(isAValidCall) {
		careerTrackRepository.save(updatedCareerTrack);
		}
		return updatedCareerTrack;
	}
	
	@RequestMapping(value="/{careerTrackId}",method=RequestMethod.DELETE)
	public void deleteCareerTrack(@PathVariable Integer careerTrackId){
		Boolean isAValidCall = false;
		if(service.isAdmin())
		{
			isAValidCall = true;
		}
		if(isAValidCall) {
		careerTrackRepository.delete(careerTrackId);
		}
	}
}
