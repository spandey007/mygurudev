/**
* Filename: /src/main/java/com/infocepts/otc/controllers/PmsCycleController.java
* @author  RKJ
* @version 1.0
* @since   2018-10-31 
*/

package com.infocepts.otc.controllers;

import java.util.logging.Level;
import java.util.logging.Logger;
import com.infocepts.pms.entities.PmsCycle;
import com.infocepts.pms.repositories.PmsCycleRepository;
import com.infocepts.otc.services.PmsService;
import com.infocepts.otc.services.TimesheetService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.mail.MessagingException;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import java.util.List;

@RestController
@RequestMapping(value="/api/pms/cycle", headers="referer")
public class PmsCycleController {

    final Logger logger = Logger.getLogger(PmsCycleController.class.getName());

    @Autowired
    PmsCycleRepository repository;
    
    @Autowired
    HttpSession session;

    @PersistenceContext(unitName = "pms") 
    private EntityManager manager;
			
	@Autowired
	TimesheetService service;
	
	@Autowired
	PmsService pmsService;

	/**
   * This method is used to find results set from module entity
   * based on params passed from JS file
   */
    @RequestMapping(method = RequestMethod.GET)
    public List<PmsCycle> findAllPmsCycle(@RequestParam(value = "isActive", defaultValue = "0") Integer isActive
            						, HttpServletRequest request){
        List<PmsCycle> pmsCycleList = null;
        //Integer loggedInUid = (Integer) session.getAttribute("loggedInUid");
        
        try {
        	/* ------------------------- Authorization start ------------------------------------ */
			// Authorization for all the associates hence no check
//			if(!service.isHR())
//			{
//				service.sendTamperedMail("PmsCycle view all", 0, 0, request);
//				return pmsCycleList;
//			}
			/* ------------------------- Authorization ends ------------------------------------ */
			
        	if (isActive == 1) {
			
        		pmsCycleList = manager.createNamedQuery("getActiveCycle", PmsCycle.class)
                        .getResultList();
        					
        	} else {
			
        		pmsCycleList = manager.createNamedQuery("getAllCycles", PmsCycle.class)
                        .getResultList();
			}
			
         } 
		catch (Exception e){
			logger.log(Level.SEVERE, "exceptn msg", e);
        }
        return pmsCycleList;

    }
    
    /**
     * This method is add row in moduleName entity
     * 
     */
    @RequestMapping(method=RequestMethod.POST)
	public PmsCycle addPmsCycle(@RequestBody PmsCycle pmsCycle, HttpServletRequest request) throws MessagingException {
		// Authorization for Admin role
		if(service.isHRPms() || service.isHRPmsAdmin())
		{
			try{
				pmsCycle.setCycleId(null);
				repository.save(pmsCycle);
			    pmsService.sendCycleNotification(pmsCycle, "add", request);        						

			}
			catch(Exception e){
				 logger.info(String.format("exception - ", e));
			}
		}
		else 
		{
			service.sendTamperedMail("PmsCycle Save", 0, 0, request);
		}
		
		return pmsCycle;
	}
    
    /**
     * This method is update row in moduleName entity
     * based on primaryKey Of Module Table 
     */
    @RequestMapping(value="/{cycleId}",method=RequestMethod.PUT)
	 public PmsCycle updatePmsCycle(@RequestBody PmsCycle updatedPmsCycle,@PathVariable Integer cycleId,HttpServletRequest request) throws MessagingException{
        // Authorization for Admin role
		if(service.isHRPms() || service.isHRPmsAdmin())
		{	
			try{
				 updatedPmsCycle.setCycleId(cycleId);
				 repository.save(updatedPmsCycle);
				    pmsService.sendCycleNotification(updatedPmsCycle, "update", request);        						
			}
			catch(Exception e){
				 logger.info(String.format("exception - ", e));
			}
		}
		else
		{
			service.sendTamperedMail("PmsCycle Save", 0, 0, request);
		}
		 return updatedPmsCycle;
	 }
    
    /**
     * This method is get data for specific row in moduleName entity
     * based on primaryKey Of Module Table 
     */
    @RequestMapping(value="/{cycleId}",method=RequestMethod.GET)
	 public PmsCycle getPmsCycle(@PathVariable Integer cycleId, HttpServletRequest request) throws MessagingException{
    	
    	PmsCycle pmsCycle = null;
    	// Authorization for all the associates hence no check
		//if(service.isHRPms())
		{
			try{
				 pmsCycle = manager.createNamedQuery("getCycleById", PmsCycle.class)
						 .setParameter("cycleId", cycleId)
						 .getSingleResult();
			 }
			 catch(Exception e){
				 logger.log(Level.SEVERE, "exceptn msg", e);
			 }
		}
//		else 
//		{
//			service.sendTamperedMail("PmsCycle Get", 0, 0, request);
//		}
		 
		 return pmsCycle;
	 }
	 
    
    /**
     * This method is delete data for specific row in moduleName entity
     * based on primaryKey Of Module Table 
     */	 
	@RequestMapping(value="/{cycleId}",method=RequestMethod.DELETE)
	public void deletePmsCycle(@PathVariable Integer cycleId, HttpServletRequest request)  throws MessagingException {
		// Authorization for Admin role
		if(service.isHRPms() || service.isHRPmsAdmin())
		{
			try{
			repository.delete(cycleId);
			}
			catch(Exception e){
				 logger.info(String.format("exception - ", e));
			}
		}
		else
		{
			service.sendTamperedMail("PmsCycle Delete", 0, 0, request);
		}		 
	}
	
  
   
}
