/**
* Filename: /src/main/java/com/infocepts/otc/controllers/AccessCardController.java
* @author  SHRI
* @version 1.0
* @since   2018-09-25 
*/

package com.infocepts.otc.controllers;

import java.util.logging.Logger;
import com.infocepts.otc.entities.AccessCard;
import com.infocepts.otc.repositories.AccessCardRepository;
import com.infocepts.otc.utilities.DateConverter;
import com.infocepts.otc.services.TimesheetService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.mail.MessagingException;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@RestController
@RequestMapping(value="/accesscard",headers="referer")
public class AccessCardController {

    final Logger logger = Logger.getLogger(AccessCardController.class.getName());

    @Autowired
    AccessCardRepository accessCardrepository;
    
    @Autowired
    HttpSession session;

    @PersistenceContext(unitName = "otc") 
    private EntityManager manager;
			
	@Autowired
	TimesheetService service;

	/**
   * This method is used to find results set from module entity
   * based on params passed from JS file
   */
    @RequestMapping(method = RequestMethod.GET)
    public List<AccessCard> findAll(@RequestParam(value = "uid", defaultValue = "0") Integer uid
            						,HttpServletRequest request) throws MessagingException{
        List<AccessCard> AccessCardList = null;
        Integer loggedInUid = (Integer) session.getAttribute("loggedInUid");
        
//        logger.info("--------------------in <ModuleName> controller------------------");	
       // logger.info("uid="+uid);logger.info("busPassId="+busPassId);

		
        try {
        	/* ------------------------- Authorization start ------------------------------------ */
			// Authorization for XYZ role
//			if(!service.isXYZ()) // isXYZ() needs implementation in declaration  in TimesheetService Class & implementation in TimesheetServiceImpl Class
//			{
//				service.sendTamperedMail("<ModuleName> view all", 0, 0, request);
//				return moduleNameList;
//			}
//			
			/* ------------------------- Authorization ends ------------------------------------ */
			
//        	if (uid != 0) {
//			
//        		//option 1 to get moduleNameList using namedQuery		
        		AccessCardList = manager.createNamedQuery("getAllAccessCard", AccessCard.class).getResultList();
//        					
//        	} else {
			
        		//option 2 to get moduleNameList using repository functions		
        		//AccessCardList = accessCardrepository.findAll();
			//}
			
         } 
		catch (Exception e){
			e.printStackTrace();
			 logger.info(String.format("exception - ", e));
        }
        
        return AccessCardList;

    }
    
    /**
     * This method is add row in moduleName entity
     * 
     */
    @RequestMapping(method=RequestMethod.POST)
	public AccessCard addAccessCard(@RequestBody AccessCard access, HttpServletRequest request) {
		// Authorization for XYZ role
//		if(service.isXYZ())
//		{
			try{
				access.setAccessId(null);
				accessCardrepository.save(access);
			}
			catch(Exception e){
				 logger.info(String.format("exception - ", e));
			}
//		}
//		else 
//		{
//			service.sendTamperedMail("<ModuleName> Save", 0, 0, request);
//		}
		
		return access;
	}
//    
    /**
     * This method is update row in moduleName entity
     * based on primaryKey Of Module Table 
     */
//    @RequestMapping(value="/{<primaryKeyOfModuleNameTable>}",method=RequestMethod.PUT)
//	 public <ModuleName> update<ModuleName>(@RequestBody <ModuleName> updated<ModuleName>,@PathVariable Integer <primaryKeyOfModuleNameTable>,HttpServletRequest request){
//        // Authorization for XYZ role
//		if(service.isXYZ())
//		{	
//			try{
//				 updated<ModuleName>.set<PrimaryKeyOfModuleNameTable>(<primaryKeyOfModuleNameTable>);
//				 repository.save(updated<ModuleName>);
//			}
//			catch(Exception e){
//				 logger.info(String.format("exception - ", e));
//			}
//		}
//		else
//		{
//			service.sendTamperedMail("<ModuleName> Save", 0, 0, request);
//		}
//		 return updated<ModuleName>;
//	 }
    
    /**
     * This method is get data for specific row in moduleName entity
     * based on primaryKey Of Module Table 
     */
//    @RequestMapping(value="/{<primaryKeyOfModuleNameTable>}",method=RequestMethod.GET)
//	 public List<<ModuleName>> get<ModuleName>(@PathVariable Integer <primaryKeyOfModuleNameTable>, HttpServletRequest request){
//    	
//    	List<<ModuleName>> someVariable=null;
//		// Authorization for XYZ role
//		if(service.isXYZ())
//		{
//			try{
//				 someVariable = manager.createNamedQuery("nameOfNamedQuery", <ModuleName>.class)
//						 .setParameter("<primaryKeyOfModuleNameTable>", <primaryKeyOfModuleNameTable>)
//						 .getResultList();
//			 }
//			 catch(Exception e){
//				 logger.info(String.format("exception - ", e));
//			 }
//		}
//		else 
//		{
//			service.sendTamperedMail("Module Name Get", 0, 0, request);
//		}
//		 
//		 return someVariable;
//	 }
	 
    
    /**
     * This method is delete data for specific row in moduleName entity
     * based on primaryKey Of Module Table 
     */	 
//	@RequestMapping(value="/{<primaryKeyOfModuleNameTable>}",method=RequestMethod.DELETE)
//	public void delete<ModuleName>(@PathVariable Integer <primaryKeyOfModuleNameTable>, HttpServletRequest request) {
//		// Authorization for XYZ role
//		if(service.isXYZ())
//		{
//			try{
//			repository.delete(<primaryKeyOfModuleNameTable>);
//			}
//			catch(Exception e){
//				 logger.info(String.format("exception - ", e));
//			}
//		}
//		else
//		{
//			service.sendTamperedMail("Module Name delete", 0, 0, request);
//		}		 
//	}
	
  
   
}
