/**
* Filename: /src/main/java/com/infocepts/otc/controllers/PmsGoalClusterController.java
* @author  SRA
* @version 1.0
* @since   2018-08-01 
*/

package com.infocepts.otc.controllers;

import java.util.logging.Logger;

import com.infocepts.pms.entities.PmsGoalCluster;
import com.infocepts.pms.entities.PmsDepartmentMapping;
import com.infocepts.pms.entities.PmsGradeMapping;
import com.infocepts.pms.entities.PmsPerformance;
import com.infocepts.pms.repositories.PmsGradeMappingRepository;
import com.infocepts.pms.repositories.PmsPerformanceRepository;
import com.infocepts.pms.repositories.PmsDepartmentMappingRepository;
import com.infocepts.pms.repositories.PmsGoalClusterRepository;
import com.infocepts.otc.services.PmsService;
import com.infocepts.otc.services.TimesheetService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.mail.MessagingException;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import java.util.List;

@RestController
@RequestMapping(value="/api/pms/goalCluster", headers="referer")
public class PmsGoalClusterController {

    final Logger logger = Logger.getLogger(PmsGoalClusterController.class.getName());

    @Autowired
    PmsGoalClusterRepository repository;
    
    @Autowired
    PmsPerformanceRepository pmsPerformanceRepository;
    
    @Autowired
    PmsGradeMappingRepository gradeMappingRepository;
    
    @Autowired
    PmsDepartmentMappingRepository departmentMappingRepository;
    
    @Autowired
    HttpSession session;

    @PersistenceContext(unitName = "pms") 
    private EntityManager manager;
			
	@Autowired
	TimesheetService service;
	
	@Autowired
	PmsService PmsService;

	/**
   * This method is used to find results set from module entity
   * based on params passed from JS file
   */
    @RequestMapping(method = RequestMethod.GET)
    public List<PmsGoalCluster> findAllPmsGoalCluster(@RequestParam(value = "status", defaultValue = "2") String status //1:Active, 0: In Active, 2:All
    												 ,@RequestParam(value = "byUserGradeAndDepartment", defaultValue = "false") Boolean byUserGradeAndDepartment
    												 ,@RequestParam(value = "performanceId", defaultValue = "0") Integer performanceId 
            						,HttpServletRequest request){
        List<PmsGoalCluster> pmsGoalClusterList = null;
        PmsPerformance pmsPerformanceObj = null;
        Integer uid=(Integer)session.getAttribute("loggedInUid");
        
        try {
        	/* ------------------------- Authorization start ------------------------------------ */
        	// Authorization for all the associates hence no check
//        	if(!service.isAdmin() && !service.isHRPms())
//			{
//				service.sendTamperedMail("PmsGoalCluster view all", 0, 0, request);
//				return pmsGoalClusterList;
//			}
			/* ------------------------- Authorization ends ------------------------------------ */
        	if(byUserGradeAndDepartment){
        		pmsGoalClusterList = manager.createNamedQuery("getAllGoalClusterByUser", PmsGoalCluster.class)   				
        				.setParameter("uid", uid)
                        .getResultList();
			}			
			else if (performanceId != 0) {		
				
				pmsPerformanceObj = pmsPerformanceRepository.findOne(performanceId);
				
				// if user has just saved the form without data in all clusters, show all clusters on edit page to complete form
				if(pmsPerformanceObj.getFormStatusGoalsetting() == 5){					
					pmsGoalClusterList = manager.createNamedQuery("getAllGoalClusterByUser", PmsGoalCluster.class)   				
	        				.setParameter("uid", pmsPerformanceObj.getUid())
	                        .getResultList();
				}
				else
				{	
					// else on form Submit - show form from performance object
					pmsGoalClusterList = manager.createNamedQuery("getGoalClustersByPerformanceId", PmsGoalCluster.class)   
	        				.setParameter("performanceId", performanceId)
	                        .getResultList();
				}
        	} 
			else if (!status.equals("")) {
	
        		pmsGoalClusterList = manager.createNamedQuery("getAllGoalClusters", PmsGoalCluster.class)   
        				.setParameter("status", status)
                        .getResultList();
        					
        	} 
			else {
	
        		pmsGoalClusterList = repository.findAll();
			}
			
         } 
		catch (Exception e){
			 logger.info(String.format("exception - ", e.getMessage()));
        }
        return pmsGoalClusterList;

    }
    
    /**
     * This method is add row in moduleName entity
     * 
     */
    @RequestMapping(method=RequestMethod.POST)
	public PmsGoalCluster addPmsGoalCluster(@RequestBody PmsGoalCluster pmsGoalCluster, HttpServletRequest request) throws MessagingException {
		// Authorization for XYZ role
    	if(service.isHRPms() || service.isHRPmsAdmin())
		{
			List<PmsGradeMapping> gradeMapping = pmsGoalCluster.getGradeMapping();
			List<PmsDepartmentMapping> departmentMapping = pmsGoalCluster.getDepartmentMapping();
			
			try{
				pmsGoalCluster.setGoalClusterId(null);
				repository.save(pmsGoalCluster);
				
				 
				//Save the mapping tables
					
				//Set the id in mapping list
				for (PmsGradeMapping pmsGradeMapping : gradeMapping) {
					pmsGradeMapping.setTypeId(pmsGoalCluster.getGoalClusterId());
				}
				
				gradeMappingRepository.save(gradeMapping);
				
				//Set the id in mapping list
				for (PmsDepartmentMapping pmsDepartmentMapping : departmentMapping) {
					pmsDepartmentMapping.setTypeId(pmsGoalCluster.getGoalClusterId());
				}
				
				departmentMappingRepository.save(departmentMapping);
			}
			catch(Exception e){
				 logger.info(String.format("exception - ", e.getMessage()));
			}
		}
		else 
		{
			service.sendTamperedMail("PmsGoalCluster Save", 0, 0, request);
		}
		
		return pmsGoalCluster;
	}
    
    /**
     * This method is update row in moduleName entity
     * based on primaryKey Of Module Table 
     */
    @RequestMapping(value="/{goalClusterId}",method=RequestMethod.PUT)
	 public PmsGoalCluster updatePmsGoalCluster(@RequestBody PmsGoalCluster updatedPmsGoalCluster,@PathVariable Integer goalClusterId,HttpServletRequest request) throws MessagingException{
        // Authorization for XYZ role
    	if(service.isHRPms() || service.isHRPmsAdmin())
		{		
			List<PmsGradeMapping> gradeMapping = updatedPmsGoalCluster.getGradeMapping();
			List<PmsDepartmentMapping> departmentMapping = updatedPmsGoalCluster.getDepartmentMapping();
						
			try{
				 updatedPmsGoalCluster.setGoalClusterId(goalClusterId);
				 repository.save(updatedPmsGoalCluster);
					
				//Delete the existing mapping
				gradeMappingRepository.deleteGradeMapping(goalClusterId, 2);
				
				gradeMappingRepository.save(gradeMapping);
				
				//Delete the existing mapping
				departmentMappingRepository.deleteDepartmentMapping(goalClusterId, 2);
				
				departmentMappingRepository.save(departmentMapping);
			}
			catch(Exception e){
				 logger.info(String.format("exception - ", e.getMessage()));
			}
		}
		else
		{
			service.sendTamperedMail("PmsGoalCluster Save", 0, 0, request);
		}
		 return updatedPmsGoalCluster;
	 }
    
    /**
     * This method is get data for specific row in moduleName entity
     * based on primaryKey Of Module Table 
     */
    @RequestMapping(value="/{goalClusterId}",method=RequestMethod.GET)
	 public PmsGoalCluster getPmsGoalCluster(@PathVariable Integer goalClusterId, HttpServletRequest request) throws MessagingException{
    	
    	PmsGoalCluster pmsGoalCluster = null;
		
		try{
			pmsGoalCluster = manager.createNamedQuery("getGoalClusterById", PmsGoalCluster.class)
					 .setParameter("goalClusterId", goalClusterId)
					 .getSingleResult();
			
			 //Get Grade mapping
			 List<PmsGradeMapping> gradeMapping = gradeMappingRepository.findByTypeId(goalClusterId, 2);
			 
			 //Set Grade mapping
			 pmsGoalCluster.setGradeMapping(gradeMapping);
			 
			 //Get Department mapping
			 List<PmsDepartmentMapping> departmentMapping = departmentMappingRepository.findByTypeId(goalClusterId, 2);
			 
			 //Set Department mapping
			 pmsGoalCluster.setDepartmentMapping(departmentMapping);
		 }
		 catch(Exception e){
			 logger.info(String.format("exception - ", e.getMessage()));
		 }
		
		 
		 return pmsGoalCluster;
	 }
	 
    
    /**
     * This method is delete data for specific row in moduleName entity
     * based on primaryKey Of Module Table 
     */	 
	@RequestMapping(value="/{goalClusterId}",method=RequestMethod.DELETE)
	public void deletePmsGoalCluster(@PathVariable Integer goalClusterId, HttpServletRequest request)  throws MessagingException {
		// Authorization for XYZ role
		if(service.isHRPms() || service.isHRPmsAdmin())
		{
			try{
				 //Delete all grade and dep allocation rows first
				PmsService.DeleteGradeMapping(goalClusterId);
				PmsService.DeleteDepartmentMapping(goalClusterId);
				 
				 repository.delete(goalClusterId);
			}
			catch(Exception e){
				 logger.info(String.format("exception - ", e.getMessage()));
			}
		}
		else
		{
			service.sendTamperedMail("PmsGoalCluster Delete", 0, 0, request);
		}		 
	}
	
  
   
}
