/**
 * 
 */
package com.infocepts.otc.controllers;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Date;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.infocepts.otc.entities.Currency;
import com.infocepts.otc.entities.Expense;
import com.infocepts.otc.entities.ExpenseCategory;
import com.infocepts.otc.entities.ExpenseDetail;
import com.infocepts.otc.entities.ExpensePurpose;
import com.infocepts.otc.entities.Resource;
import com.infocepts.otc.repositories.CurrencyRepository;
import com.infocepts.otc.repositories.ExchangeRateRepository;
import com.infocepts.otc.repositories.ExpenseCategoryRepository;
import com.infocepts.otc.repositories.ExpenseDetailRepository;
import com.infocepts.otc.repositories.ExpensePurposeRepository;
import com.infocepts.otc.repositories.ExpenseRepository;
import com.infocepts.otc.repositories.ProjectRepository;
import com.infocepts.otc.repositories.ResourceRepository;
import com.infocepts.otc.services.TimesheetService;
import com.infocepts.otc.utilities.AbstractExpenseFileHandling;
import com.infocepts.otc.utilities.ExpenseMailNotification;
import com.infocepts.otc.utilities.ExpenseMailNotification.Role;
import com.infocepts.otc.utilities.LoadConstant;

/**
 * @author Rewatiraman Singh
 *
 */
@RestController
@RequestMapping("/expenseDetail")
public class ExpenseDetailController extends Object {

	private final Logger logger = Logger.getLogger(ExpenseDetailController.class.getName());
	
	@Autowired
	private ExpenseDetailRepository expenseDetailRepository;
	
	@Autowired
	private ResourceRepository resourceRepository;
	
	@Autowired
	private ExpensePurposeRepository expensePurposeRepository;
	
	@Autowired
	private ExpenseCategoryRepository expenseCategoryRepository;
	
	@Autowired
	private ProjectRepository projectRepository;
	
	@Autowired
	private ExchangeRateRepository exchangeRateRepository;
	
	@Autowired
	private CurrencyRepository currencyRepository;
	
	@Autowired
	private ExpenseRepository expenseRepository;
	
	@PersistenceContext(unitName="otc")
    private EntityManager entityManager;
	
	@Autowired
	private ExpenseMailNotification mailNotification;
	
	@Autowired
	private TimesheetService timesheetService;

	/**
	 * @return - Map containing allocated projects, purpose types, purposes and categories.
	 * NOTE : If no user id is sent from client side to this method then everything except allocated projects
	 * and resource object will be sent back to client side.
	 */
	@GetMapping("/getDependentObjects")
	public Object getDependentObjects(HttpServletRequest request) {
		Integer uid = (Integer) request.getSession().getAttribute("loggedInUid");
		Boolean isFinance = Boolean.valueOf(request.getParameter("isFinance"));
		Boolean isAssignExpense = Boolean.valueOf(request.getParameter("isAssignExpense"));
		Map<String, List<?>> dependentObjectMap = new HashMap<>();
		List<ExpensePurpose> purpose = expensePurposeRepository.findActiveExpensePurposes();
		List<ExpenseCategory> categories = expenseCategoryRepository.findActiveExpenseCategories();
		if (isFinance || isAssignExpense) {
			List<Map<String, String>> allProjects = projectRepository.getProjectsMap();
			dependentObjectMap.put("projects", allProjects);
		} else {
			// Fetch all the allocated projects for the user with the given user id.
			List<Map<Object, String>> allocatedProjects = projectRepository.getAllocatedProjectsByUid(entityManager, uid);
			// Fetch all the unallocated i.e. Generic project tasks as well.
			List<Map<Object, String>> genericProjects = projectRepository.getGenericProjects(entityManager);
			allocatedProjects.addAll(genericProjects);
			dependentObjectMap.put("projects", allocatedProjects);
		}

		List<Currency> currencyList = currencyRepository.findAllActive();

		/* Fetch the resource instance by the given user id to show the Employeed name in the grid for PM, Finance or Travel
		desk.
		*/
		Resource resource = resourceRepository.findResourcebyUid(uid);

		dependentObjectMap.put("resource", Arrays.asList(resource));
		dependentObjectMap.put("purposes", purpose);
		dependentObjectMap.put("categories", categories);
		dependentObjectMap.put("currencies", currencyList);
		
		return dependentObjectMap;
	}
	
	@PostMapping
	public Object saveExpenseDetail(@RequestBody List<ExpenseDetail> expenseDetailList, HttpServletRequest request) {
		boolean isSubmitted = NumberUtils.toInt(request.getParameter("isSubmitted")) > 0;
		boolean isAssignedExpense = NumberUtils.toInt(request.getParameter("isAssignedExpense")) > 0;
		boolean isFinanceView = NumberUtils.toInt(request.getParameter("isFinanceView")) > 0;
		Integer uid = (Integer) request.getSession().getAttribute("loggedInUid");
		List<ExpenseDetail> emptyExpenseDetailList = new ArrayList<>();
		Map<String, List<ExpenseDetail>> expenseDetailMap = new HashMap<>();
		Expense expense = null;
		final List<Expense> expenseList = new ArrayList<>();
		
		if (CollectionUtils.isNotEmpty(expenseDetailList)) {
			Expense exp = expenseDetailList.get(0).getExpense();
			/* Set the logged-in user in expense only if an associate is saving/submitting the expense, Else
			 * when Finance Team is assigning expense to an associate then use the User id sent from client side.
			*/
			if (isAssignedExpense || isFinanceView) {
				exp.setUid(exp.getUid());
			} else {
                exp.setUid(uid);
            }
			
			if (exp.getExpenseId() == null) {
				exp.setCreatedBy(uid);
			} else {
				/* Below logic is executed in a scenario where user have submitted multiple claims and later it decides to
				delete one of the claims and saves the record then we'll have to delete that claim from db as well.
				*/
				List<ExpenseDetail> expDetailList = expenseDetailRepository.findExpenseDetailByExpenseId(exp.getExpenseId());
				if (org.apache.commons.collections4.CollectionUtils.isNotEmpty(expDetailList)) {
					expenseDetailRepository.deleteInBatch(expDetailList);
				}
			}
			exp.setModifiedBy(uid);
			expense = expenseRepository.save(exp);
			expense.setApproverId(exp.getApproverId());
			expense.setExpenseCode("EXP00" + expense.getExpenseId());
			expenseList.add(expense);
		}
		
	
		
		
		for (ExpenseDetail expenseDetail : expenseDetailList) {
			try {
				expenseDetail.setExpense(expense);
				expenseDetail.setExpenseDetailId(null);
				expenseDetail.setCreatedBy(uid);
				expenseDetail.setModifiedBy(uid);
				emptyExpenseDetailList.add(expenseDetailRepository.save(expenseDetail));
				expenseDetailMap.put("expenseDetails", emptyExpenseDetailList);
			} catch (Exception ex) {
				logger.log(Level.SEVERE, "ERROR WHILE SAVING/UPDATING EXPENSE DETAIL WITH expenseDetail ID: "
						+ expenseDetail.getExpenseDetailId(), ex);
			}
		}
		
		if (isSubmitted) {
			new Thread(() -> mailNotification.notifySubmission(expenseList.get(0))).start();
		}
		
		if (isAssignedExpense) {
			new Thread(() -> mailNotification.notifyAssignment(expenseList.get(0))).start();
		}
		
		return expenseDetailMap;
	}

	@GetMapping("/getExpenseDetailByExpenseId")
	public List<ExpenseDetail> getExpenseDetailByExpenseId(HttpServletRequest request) {
		Integer expenseId = NumberUtils.toInt(request.getParameter("expenseId"));
		List<ExpenseDetail> expenseDetailList = new ArrayList<>();
		if (expenseId != 0) {
			expenseDetailRepository.findExpenseDetailByExpenseId(expenseId).forEach(expenseDetail -> {
				Expense expense = expenseDetail.getExpense();
				expense.setExpenseCode("EXP00" + expense.getExpenseId());
				expenseDetail.setExpense(expense);
				expenseDetailList.add(expenseDetail);
			});
		}
		return expenseDetailList;
	}

	@DeleteMapping("/{expenseDetailId}")
	public void deleteExpenseDetailById(@PathVariable(value = "expenseDetailId") Integer expenseDetailId) {
		try {
			expenseDetailRepository.delete(expenseDetailId);
		} catch (Exception e) {
			logger.log(Level.WARNING, "COULD NOT DELETE AN EXPENSE RECORD BY EXPENSE DETAIL ID: " + expenseDetailId, e);
		} 
	}
	
	@GetMapping("/getConvertedAmount")
	public  Object getConvertedAmount(HttpServletRequest request) {
		Integer currencyFromId = NumberUtils.toInt(request.getParameter("currencyFromId"));
		Integer currencyToId = NumberUtils.toInt(request.getParameter("currencyToId"));
		final String CONVERTED_AMOUNT = "convertedAmount";
		Double amount = NumberUtils.toDouble(request.getParameter("amount"));
		Map<String, Double> conversionMap = new HashMap<>();
		conversionMap.put(CONVERTED_AMOUNT, 0.0);
		
		// If default currency is same as the currency choosen from dropdown then return the exact same value.
		if (currencyFromId == currencyToId) {
			conversionMap.put(CONVERTED_AMOUNT, amount);
			return conversionMap;
		}
		
		java.util.Date expenseStartDate = null;
		Double convertedAmount = null;
		
		try {
			expenseStartDate = DateUtils.parseDate(request.getParameter("expenseStartDate"), "yyyy-MM-dd");
			double conversionRate = exchangeRateRepository.getConversionRate(entityManager, currencyFromId, currencyToId, expenseStartDate);
			convertedAmount = amount * conversionRate;
			conversionMap.put(CONVERTED_AMOUNT, convertedAmount);
		} catch (Exception e) {
			logger.log(Level.WARNING, "COULD NOT FIND EXCHANGE RATE WITH THE GIVEN INPUTS!", e);
		} 
		
		return conversionMap;
	}
	
	@PostMapping(value = "/fileUpload/{expenseAndDetailId}", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	public Object uploadExpenseDocument(@RequestPart("file") MultipartFile multipartFile,
			@PathVariable("expenseAndDetailId") String expenseAndDetailId) {
		String[] split = expenseAndDetailId.split("_");
		Integer expenseId = NumberUtils.toInt(split[0]);
		Integer expenseDetailId = NumberUtils.toInt(split[1]);
		try {
			File uploadedFile = AbstractExpenseFileHandling.upload(multipartFile, "expense", "EXP00" + expenseId + "/" + expenseDetailId);
			if (uploadedFile.exists()) {
				ExpenseDetail expenseDetail = expenseDetailRepository.findOne(expenseDetailId);
				if (StringUtils.isNotBlank(expenseDetail.getFilePath())) {
					expenseDetail.setFilePath(expenseDetail.getFilePath() + "," + uploadedFile.toString());
				} else {
					expenseDetail.setFilePath(uploadedFile.toString());
				}
				expenseDetailRepository.saveAndFlush(expenseDetail);
				return true;
			}
		} catch (Exception e) {
			logger.log(Level.SEVERE, String.format("FAILED TO UPLOAD :%s", multipartFile.getOriginalFilename()), e );
		}
		return false;
	}
	
	@GetMapping(value = "/fileDownload/{expenseDetailId}")
	public Object downloadExpenseDocument(HttpServletRequest request, HttpServletResponse response , @PathVariable("expenseDetailId") Integer expenseDetailId) {
		ExpenseDetail expenseDetail = expenseDetailRepository.findOne(expenseDetailId);
		List<String> fileList = Arrays.asList(expenseDetail.getFilePath().split(","));
		try {
			File file = null;
			if (fileList.size() == 1) {
				file = new File(fileList.get(0));
			} else {
				file = AbstractExpenseFileHandling.zipFiles(fileList, 
						String.format("Expense_%s_", expenseDetail.getExpense().getExpenseId()));
			}
			
			Path path = Paths.get(file.toString());
		    response.addHeader(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename="+file.getName());
		    Files.copy(path, response.getOutputStream());
		    response.getOutputStream().flush();
		} catch (IOException e) {
			logger.log(Level.SEVERE, "COULD NOT DOWNLOAD FILE FOR EXPENSE DETAIL ID: " + expenseDetailId, e);
		}

		return null;
	}
	
	/**
	 * @param expenseDetailList - Expense Details to be approved/rejected.
	 * @param request
	 * @return - Expense Detail objects with Approved/Rejected statuses.
	 */
	@PostMapping("/approval/{status}")
	public Object approval(HttpServletRequest request, @RequestBody List<ExpenseDetail> expenseDetailList, @PathVariable("status") String status) {
		boolean approved = "approve".equalsIgnoreCase(status);
		boolean rejected = "reject".equalsIgnoreCase(status);
		List<ExpenseDetail> updatedList = new ArrayList<>();
		Map<String, List<ExpenseDetail>> updatedMap = new HashMap<>();
		Integer uid = (Integer) request.getSession().getAttribute("loggedInUid");
		
		Boolean isTravel = Boolean.valueOf(request.getParameter("isTravel"));
		Boolean isFinance = Boolean.valueOf(request.getParameter("isFinance"));
		Integer expenseId = 0; 
		List<String> mailStatus = new ArrayList<>();
		
		for (ExpenseDetail expenseDetail : expenseDetailList) {
			ExpenseDetail expenseDetail1 = null;
			try {
				java.util.Date currentDate = Date.from(LocalDate.now().atStartOfDay().atZone(ZoneId.systemDefault()).toInstant());
				expenseDetail1 = expenseDetailRepository.findOne(expenseDetail.getExpenseDetailId());
				
				if (expenseDetail1 != null) {
					final Expense expense = expenseDetail.getExpense();
					
					if (isTravel != null && isTravel) {
						if (approved) {
							expense.setTravelStatus(LoadConstant.EXPENSE_STATUS_APPROVED);
							expense.setTdApprovalDate(currentDate);
							expense.setFinanceStatus(LoadConstant.EXPENSE_STATUS_PENDING_APPROVAL);
							if (mailStatus.isEmpty()) {
								new Thread(() -> mailNotification.notifyApproval(expense, Role.TRAVEL, uid)).start();
								mailStatus.add("sent");
							}
						} else if (rejected) {
							expense.setTravelStatus(LoadConstant.EXPENSE_STATUS_REJECTED);
							if (mailStatus.isEmpty()) {
								new Thread(() -> mailNotification.notifyRejection(expense, Role.TRAVEL, uid)).start();
								mailStatus.add("sent");
							}
						}
						expenseDetail1.setTdComments(expenseDetail.getTdComments());
					} else if (isFinance != null && isFinance) {
						if (approved) {
							expense.setFinanceStatus(LoadConstant.EXPENSE_STATUS_APPROVED);
							expense.setFaApprovalDate(currentDate);

							if (mailStatus.isEmpty()) {
								new Thread(() -> mailNotification.notifyApproval(expense, Role.FINANCE, uid)).start();
								mailStatus.add("sent");
							}

						} else if (rejected) {
							expense.setFinanceStatus(LoadConstant.EXPENSE_STATUS_REJECTED);
							if (mailStatus.isEmpty()) {
								new Thread(() -> mailNotification.notifyRejection(expense, Role.FINANCE, uid)).start();
								mailStatus.add("sent");
							}
						}
						expenseDetail1.setFaComments(expenseDetail.getFaComments());
					} 
					// This condition will work for PM/AH/PH role.
					else {
						if (approved) {
							
							expense.setStatus(LoadConstant.EXPENSE_STATUS_APPROVED);
							expense.setPmApprovalDate(currentDate);

							/* When PM approves the expense then it's Travel status should be changed to Pending so
							that it can move further to travel desk for approvals. 
							*/
							if (expenseRepository.isPurposeTypeTravel(entityManager, expense.getExpenseId())) {
								expense.setTravelStatus(LoadConstant.EXPENSE_STATUS_PENDING_APPROVAL);
							} else {
								expense.setFinanceStatus(LoadConstant.EXPENSE_STATUS_PENDING_APPROVAL);
							}
							if (mailStatus.isEmpty()) {
								new Thread(() -> mailNotification.notifyApproval(expense, Role.PM, uid)).start();
								mailStatus.add("sent");
							}
							
						} else {
							expense.setStatus(LoadConstant.EXPENSE_STATUS_REJECTED);
							if (mailStatus.isEmpty()) {
								new Thread(() -> mailNotification.notifyRejection(expense, Role.PM, uid)).start();
								mailStatus.add("sent");
							}
						}
						expenseDetail1.setPmComments(expenseDetail.getPmComments());
					}
					
					expense.setModifiedBy(uid);
					expense.setModifiedDate(currentDate);
					expenseDetail1.setExpense(expenseRepository.save(expense));
					
					
					expenseDetail1.setModifiedBy(uid);
					expenseDetail1.setModifiedDate(currentDate);
					ExpenseDetail saved = expenseDetailRepository.save(expenseDetail1);
					if (saved != null) {
						expenseId = saved.getExpense().getExpenseId();
					}
				}
			} catch (Exception e) {
				if (expenseDetail1 != null) {
					logger.log(Level.SEVERE, "COULD NOT SET APPROVAL/REJECTION STATUS FOR EXPENSE DETAIL WITH ID: "
							+ expenseDetail1.getExpenseDetailId(), e);
				} else {
					logger.log(Level.SEVERE, "COULD NOT SET APPROVAL/REJECTION STATUS FOR EXPENSE DETAIL WITH ID: null");
				}
			}
		}
		List<ExpenseDetail> formattedList = expenseDetailRepository.findFormattedExpenseDetailByExpenseId(entityManager, expenseId);
		updatedList.addAll(formattedList);
		updatedMap.putIfAbsent("updatedList", updatedList);
		/* This predicate confirms whether all the records with given PKs are updated or not.
		 * NOTE : This boolean can also be used to display a prompt on browser like "Something went wrong while approval/rejection".
		 */
		return updatedMap;
	}
	
	/**
	 * @param request
	 * @return List of Resource objects of PM, DM, AH, PH etc.
	 */
	@GetMapping("/fetchProjectOwners")
	public Object fetchProjectOwners(HttpServletRequest request) {
		Integer loggedInUid = (Integer) request.getSession().getAttribute("loggedInUid");
		String gradeNo = resourceRepository.findOne(loggedInUid).getGrade().getGradeNo();
		Integer projectId = NumberUtils.toInt(request.getParameter("projectId"));
		List<Integer> owners = expenseDetailRepository.fetchProjectOwners(entityManager, projectId);
		List<Map<String, Object>> ownerList = new ArrayList<>();
		owners.forEach(uid -> {
			List<Map<String, String>> resourceList = resourceRepository.getResourceMap(entityManager, uid);
			Map<String, String> resourceMap = null;
			if(CollectionUtils.isNotEmpty(resourceList)) {
				resourceMap = resourceList.get(0);
			}
			Map<String, Object> ownerMap = new HashMap<>();
			if (MapUtils.isNotEmpty(resourceMap)) {
				if (!owners.contains(loggedInUid)) {
					ownerMap.putIfAbsent("uid", resourceMap.get("0"));
					ownerMap.putIfAbsent("ownerName", resourceMap.get("1"));
					ownerList.add(ownerMap);
				}
			}
		});
		if (NumberUtils.toInt(gradeNo) >= 9 && loggedInUid != 512 
				&& !ownerList.toString().contains(512 + "")) {
			Map<String, Object> ownerMap = new HashMap<>();
			// Putting Aditya's uid and title in the approver list for the users having grade 10 and above.
			ownerMap.putIfAbsent("uid", 512);
			ownerMap.putIfAbsent("ownerName", "Aditya Joshi");
			ownerList.add(ownerMap);
		}
		
		if (timesheetService.isLeadership() && !ownerList.toString().contains(113 + "")) {
			Map<String, Object> ownerMap = new HashMap<>();
			// Putting Shashank's uid and title in the approver list for the leadership team members.
			ownerMap.putIfAbsent("uid", 113);
			ownerMap.putIfAbsent("ownerName", "Shashank Garg");
			ownerList.add(ownerMap);
		}
		return  ownerList;
	}
	
	@GetMapping(value = "/downloadAll/{expenseId}")
	public void downloadAllAttachments(HttpServletRequest request, HttpServletResponse response, @PathVariable("expenseId") Integer expenseId) {
		List<ExpenseDetail> expenseDetailList = expenseDetailRepository.findExpenseDetailByExpenseId(expenseId);
		List<String> fileList = new ArrayList<>();
		expenseDetailList.forEach(expDetail -> {
			String filePath = expDetail.getFilePath();
			if (StringUtils.isNotBlank(filePath)) {
				File file = new File(filePath);
				if (file.exists()) {
					fileList.add(filePath);
				}
			}
		});
		if (fileList.size() > 0) {
			File zippedFile = AbstractExpenseFileHandling.zipFiles(fileList, "EXP00" + expenseId);
			try {
				Path path = Paths.get(zippedFile.toString());
				response.addHeader(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + zippedFile.getName());
				Files.copy(path, response.getOutputStream());
				response.getOutputStream().flush();
			} catch (IOException e) {
				logger.log(Level.SEVERE, "COULD NOT DOWNLOAD ALL ATTACHMENTS FOR EXPENSE ID: " + expenseId, e);
			}
		}
	}
}
