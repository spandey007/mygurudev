/**
 * 
 */
package com.infocepts.otc.controllers;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.infocepts.otc.entities.ExpenseCategory;
import com.infocepts.otc.repositories.ExpenseCategoryRepository;
import com.infocepts.otc.utilities.LoadConstant;

/**
 * @author Rewatiraman Singh
 *
 */
@RestController
@RequestMapping("/expenseCategory")
public class ExpenseCategoryController extends Object {

	private final Logger logger = Logger.getLogger(ExpenseCategoryController.class.getName());
	
	@PersistenceContext(unitName="otc")
    private EntityManager entityManager;
	
	@Autowired
	private ExpenseCategoryRepository expenseCategoryRepository;
	
	@GetMapping
	public List<ExpenseCategory> getAllExpenseCategories(@RequestParam(value = "status", defaultValue = "0", required = false) Integer status) {
		if (status == LoadConstant.EXPENSE_PURPOSE_ACTIVE) {
			return expenseCategoryRepository.findActiveExpenseCategories();
		}
		return expenseCategoryRepository.findAll();
	}
	
	@PostMapping
	public Object saveExpenseCategory(@RequestBody List<ExpenseCategory> expenseCategoryList) {
		List<ExpenseCategory> emptyExpenseCategoryList = new ArrayList<>();
		Map<String, List<ExpenseCategory>> expenseCategoryMap = new HashMap<>();
		
		for (ExpenseCategory expenseCategory: expenseCategoryList) {
			try {
				emptyExpenseCategoryList.add(expenseCategoryRepository.save(expenseCategory));
				expenseCategoryMap.put("categories", emptyExpenseCategoryList);
			} catch (Exception ex) {
				logger.log(Level.SEVERE, "ERROR WHILE SAVING/UPDATING EXPENSE CATEGORY WITH EXPENSE CATEGORY ID: " + expenseCategory.getExpenseCategoryId()
				+ " AND CATEGORY NAME: " + expenseCategory.getCategoryName(), ex);
			}
		}
		
		return expenseCategoryMap;
	}
	
	@DeleteMapping
	public Object deleteExpenseCategory(@RequestBody List<ExpenseCategory> expenseCategoryList) {
		List<ExpenseCategory> deletedCategoryList = new ArrayList<>(); 
		Map<String, List<ExpenseCategory>> deletedCategoryMap = new HashMap<>();
		
		for (ExpenseCategory expenseCategory : expenseCategoryList) {
			try {
				expenseCategoryRepository.delete(expenseCategory);
				deletedCategoryList.add(expenseCategory);
				deletedCategoryMap.put("expenseCategories", deletedCategoryList);
			} catch (Exception ex) {
				logger.log(Level.SEVERE, "ERROR WHILE DELETING EXPENSE PURPOSE TYPE WITH EXPENSE PURPOSE TYPE ID: " + expenseCategory.getExpenseCategoryId()
				+ " AND PURPOSE TYPE NAME: " + expenseCategory.getCategoryName(), ex);
			}
		}
		return deletedCategoryMap;
	}
	
	@GetMapping("/{expenseCategoryId}")
	public ExpenseCategory getExpenseCategory(@RequestParam("expenseCategoryId") Integer expenseCategoryId) {
		ExpenseCategory expenseCategory  = null;
		if (expenseCategoryId != 0) {
			expenseCategory = expenseCategoryRepository.findExpenseCategory(expenseCategoryId);
		}
		
		if (expenseCategory == null) {
			logger.info("COULD NOT FIND THE EXPENSE PURPOSE TYPE WITH ID: " + expenseCategoryId);
		}
		return expenseCategory;
	}
}
