/**
 * 
 */
package com.infocepts.otc.repositories;

import java.util.logging.Level;
import java.util.logging.Logger;

import javax.persistence.EntityManager;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.infocepts.otc.entities.ExpenseSettlement;

/**
 * @author Rewatiraman Singh
 *
 */
@Repository
public interface ExpenseSettlementRepository  extends JpaRepository<ExpenseSettlement, Integer> {

	/**
	 * @param manager
	 * @param expenseId - For which settlement record is to be fetched.
	 * @return - ExpenseSettlement with given expense id if found, null otherwise.
	 */
	default ExpenseSettlement findByExpenseId(EntityManager manager, Integer expenseId) {
		final Logger logger = Logger.getLogger(ExpenseSettlementRepository.class.getName());
		ExpenseSettlement expenseSettlement = null;
		String queryString = "from ExpenseSettlement es where es.expense.expenseId=:expenseId";
		try {
			expenseSettlement = manager.createQuery(queryString, ExpenseSettlement.class)
					.setParameter("expenseId", expenseId)
					.getSingleResult();
		} catch (Exception e) {
			logger.log(Level.SEVERE, "UNABLE TO FIND SETTLEMENT RECORD FOR EXPENSE ID: " + expenseId, e);
		}
		return expenseSettlement;
	}
}
