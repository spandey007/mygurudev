/**
 * 
 */
package com.infocepts.otc.repositories;

import java.io.Serializable;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.infocepts.otc.entities.ExpenseCategory;

/**
 * @author Rewatiraman Singh
 *
 */
@Repository
public interface ExpenseCategoryRepository extends JpaRepository<ExpenseCategory, Serializable> {

	@Query("FROM ExpenseCategory WHERE expenseCategoryId = :expenseCategoryId")
	public ExpenseCategory findExpenseCategory(@Param("expenseCategoryId") int expenseCategoryId);
	
	@Query("FROM ExpenseCategory ec WHERE status = 0 order by ec.categoryName")
	public List<ExpenseCategory> findActiveExpenseCategories();
}
