package com.infocepts.otc.repositories;

import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.infocepts.otc.entities.Holidays;
import com.infocepts.otc.entities.Month;
import com.infocepts.otc.utilities.LoadConstant;


public interface HolidaysRepository extends JpaRepository<Holidays,Integer>{

	@Override
	public List<Holidays> findAll();
	
	@Query(value= "SELECT CONVERT(varchar,month(date))+'-'+convert(varchar,year(date))+'|'+convert(varchar,count(date)) as str "+
			"FROM "+LoadConstant.infomaster+".dbo.holiday h "+
			"WHERE (h.date between :startDate and :endDate) "+
			"AND holidayscheduleId = (SELECT HolidayScheduleID FROM " + LoadConstant.infomaster + ".dbo.resource "+
			"WHERE uid = :uid) group by Month(date),year(date)", nativeQuery = true)
	public List<String> getHolidayCountByMonthWithinStartAndEndDate(@Param(value = "startDate") Date startDate,@Param(value = "endDate") Date endDate,@Param(value = "uid") Integer uid);
}

