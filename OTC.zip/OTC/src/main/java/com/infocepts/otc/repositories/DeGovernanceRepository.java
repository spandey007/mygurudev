package com.infocepts.otc.repositories;

import com.infocepts.otc.entities.DeGovernance;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public interface DeGovernanceRepository extends JpaRepository <DeGovernance, Integer>{

	@Transactional
	@Modifying
	@Query( value = "exec spDEGovernanceTool :projectId,:date,:accountNotes,:portfolioNotes,:deliveryNotes", nativeQuery = true)
	void InsertUpdateComments(@Param("projectId") Integer projectId,
							  @Param("date") Date date,
							  @Param("accountNotes") String accountNotes,
							  @Param("portfolioNotes") String portfolioNotes,
							  @Param("deliveryNotes") String deliveryNotes
			);
	
//	@Query( value = "select sum(projectedRevenueForMonth) as projectedRevenueForMonth,sum(percentageRevenueAchievedForMonth) as percentageRevenueAchievedForMonth,sum(effortVariance) as effortVariance,sum(defectLeakage) as defectLeakage,sum(defectDensity) as defectDensity,sum(percentageScheduleOverrun) as percentageScheduleOverrun,sum(percentageEffortOverrun) as percentageEffortOverrun,sum(responseSLA) as responseSLA,sum(resolutionSLA) as resolutionSLA,sum(capacityUtilization) as capacityUtilization,sum(avgTimeToResolve) as avgTimeToResolve,sum(firstTimeRight) as firstTimeRight,sum(backlogIndex) as backlogIndex,sum(avgTimeToStaff) as avgTimeToStaff,sum(noInterviewsbeforefinalisation) as noInterviewsbeforefinalisation,sum(ratioOfPositionStaffedVsOpen) as ratioOfPositionStaffedVsOpen  FROM deGovernance where projectId=:projectId and year(projectMetricsForDate)=:year", nativeQuery = true)
//	List<DeGovernance> findByProjectIdAndMonth(@Param("projectId") Integer projectId,
//							     @Param("year") Integer year);
	
}
