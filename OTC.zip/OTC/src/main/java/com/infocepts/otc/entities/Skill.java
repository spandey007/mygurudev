package com.infocepts.otc.entities;

import java.util.Date;

import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.SqlResultSetMappings;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.infocepts.otc.utilities.LoadConstant;

@SqlResultSetMappings({
    @SqlResultSetMapping(
            name = "skillList",
            classes = {
                    @ConstructorResult(
                            targetClass = Skill.class,
                            columns = {
                            		@ColumnResult(name = "skillId"),
                            		
                                    @ColumnResult(name = "skillName", type = String.class),   
                                    @ColumnResult(name = "isOrgSpecific", type = Boolean.class),
                                    @ColumnResult(name = "createdBy"),
                                    @ColumnResult(name = "createdDate", type = Date.class),
									@ColumnResult(name = "modifiedBy"),
                                    @ColumnResult(name = "modifiedDate", type = Date.class),
                                    @ColumnResult(name = "coeId", type = Integer.class),
                                    @ColumnResult(name = "coeName", type = String.class),
                                    @ColumnResult(name = "skillCategoryId", type = Integer.class),
                                    @ColumnResult(name = "status", type = String.class),
                                    @ColumnResult(name = "skillType", type = String.class),
                                    @ColumnResult(name = "coe", type = String.class),
                                    @ColumnResult(name = "skillCategoryName", type = String.class),
                                    @ColumnResult(name = "ownerId", type = String.class),
                                    @ColumnResult(name = "coeLead", type = String.class),
                                    @ColumnResult(name = "rejectionComments", type = String.class)
                            		
                            }
                    )
            }
    )
})

@NamedNativeQueries({
    @NamedNativeQuery(
            name    =   "SkillQuery",   
            query 	=   "Select sk. *,c.coeName as coeName,c.ownerId as ownerId, sc.skillCategoryName as skillCategoryName, r.title as coeLead "+
						" from " + LoadConstant.infomaster + ".[dbo].Skill as sk"+
						" LEFT JOIN " + LoadConstant.otc + ".[dbo].Coe c on sk.coeId = c.coeId "+
						" LEFT JOIN " + LoadConstant.infomaster + ".[dbo].SkillCategory sc on sk.skillCategoryId = sc.skillCategoryId "+
						" LEFT JOIN " + LoadConstant.infomaster + ".[dbo].resource r on r.uid = c.ownerId "+
						" where sk.status = 'Active'",
						resultClass=Skill.class, resultSetMapping = "skillList"
    )  ,
    @NamedNativeQuery(
            name    =   "SkillByNameQuery",   
            query 	=   "Select sk. *,c.coeName as coeName ,c.ownerId as ownerId,sc.skillCategoryName as skillCategoryName, r.title as coeLead "+
						" from " + LoadConstant.infomaster + ".[dbo].Skill as sk"+
						" LEFT JOIN " + LoadConstant.otc + ".[dbo].Coe c on sk.coeId = c.coeId "+
						" LEFT JOIN " + LoadConstant.infomaster + ".[dbo].SkillCategory sc on sk.skillCategoryId = sc.skillCategoryId "+
						" LEFT JOIN " + LoadConstant.infomaster + ".[dbo].resource r on r.uid = c.ownerId "+
						" where sk.skillName = :skillName",
						
						resultClass=Skill.class, resultSetMapping = "skillList"
    ) ,
    @NamedNativeQuery(
            name    =   "SkillByCoEOwner",   
            query 	= "Select sk. *,c.coeName as coeName,c.ownerId as ownerId, sc.skillCategoryName as skillCategoryName, r.title as coeLead "+
					" from " + LoadConstant.infomaster + ".[dbo].Skill as sk"+
					" LEFT JOIN " + LoadConstant.otc + ".[dbo].Coe c on sk.coeId = c.coeId "+
					" LEFT JOIN " + LoadConstant.infomaster + ".[dbo].SkillCategory sc on sk.skillCategoryId = sc.skillCategoryId "+
					" LEFT JOIN " + LoadConstant.infomaster + ".[dbo].resource r on r.uid = c.ownerId ",
					
					resultClass=Skill.class, resultSetMapping = "skillList"
						)
})

@Entity
@Table(catalog=LoadConstant.infomaster,schema="[dbo]",name="skill")
public class Skill {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer skillId;
	private String skillName;
	private Boolean isOrgSpecific;
	private Integer createdBy;
	private Date createdDate;
	private Integer modifiedBy;
	private Date modifiedDate;
	private Integer coeId;
	private String rejectionComments;
	
	@Transient
	private String coeName;
	@Transient
	private String skillCategoryName;
	@Transient
	private String ownerId;
	
	@Transient
	private String coeLead;

	public String getOwnerId() {
		return ownerId;
	}
	public void setOwnerId(String ownerId) {
		this.ownerId = ownerId;
	}
	public String getSkillCategoryName() {
		return skillCategoryName;
	}
	public void setSkillCategoryName(String skillCategoryName) {
		this.skillCategoryName = skillCategoryName;
	}
	public String getCoeName() {
		return coeName;
	}
	public void setCoeName(String coeName) {
		this.coeName = coeName;
	}
	public Integer getCoeId() {
		return coeId;
	}
	public void setCoeId(Integer coeId) {
		this.coeId = coeId;
	}
	@ManyToOne
	@JoinColumn(name="skillCategoryId")
	private SkillCategory skillCategory;
	
	private String status;
	private String skillType;
	private String coe;
	
	public Integer getSkillId() {
		return skillId;
	}
	public void setSkillId(Integer skillId) {
		this.skillId = skillId;
	}
	public String getSkillName() {
		return skillName;
	}
	public void setSkillName(String skillName) {
		this.skillName = skillName;
	}
	
	public Boolean getIsOrgSpecific() {
		return isOrgSpecific;
	}
	public void setIsOrgSpecific(Boolean isOrgSpecific) {
		this.isOrgSpecific = isOrgSpecific;
	}
	public Integer getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public Integer getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public Date getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public SkillCategory getSkillCategory() {
		return skillCategory;
	}
	public void setSkillCategory(SkillCategory skillCategory) {
		this.skillCategory = skillCategory;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getSkillType() {
		return skillType;
	}
	public void setSkillType(String skillType) {
		this.skillType = skillType;
	}
	public String getCoe() {
		return coe;
	}
	public void setCoe(String coe) {
		this.coe = coe;
	}	
	
	public String getCoeLead() {
		return coeLead;
	}
	public void setCoeLead(String coeLead) {
		this.coeLead = coeLead;
	}
	
		public String getRejectionComments() {
		return rejectionComments;
	}
	public void setRejectionComments(String rejectionComments) {
		this.rejectionComments = rejectionComments;
	}
		// Constructor
		// ---------------------------------------------------------------------------------
		public Skill() {
			//super();
			// TODO Auto-generated constructor stub
		}
		public Skill(Integer skillId, String skillName, Boolean isOrgSpecific, Integer createdBy, Date createdDate,
				Integer modifiedBy, Date modifiedDate, Integer coeId, String coeName, Integer skillCategoryId,
				String status, String skillType, String coe, String skillCategoryName, String ownerId, 
				String coeLead, String rejectionComments) {
			super();
			this.skillId = skillId;
			this.skillName = skillName;
			this.isOrgSpecific = isOrgSpecific;
			this.createdBy = createdBy;
			this.createdDate = createdDate;
			this.modifiedBy = modifiedBy;
			this.modifiedDate = modifiedDate;
			this.coeId = coeId;
			this.coeName = coeName;
			if(skillCategoryId!=null) {
				this.skillCategory = new SkillCategory();
				this.skillCategory.setSkillCategoryId(skillCategoryId);
				this.skillCategory.setSkillCategoryName(skillCategoryName);
			}
			
			this.status = status;
			this.skillType = skillType;
			this.coe = coe;
			this.ownerId =  ownerId;
			this.coeLead = coeLead;
			this.rejectionComments = rejectionComments;
		}

		
	
	
}
