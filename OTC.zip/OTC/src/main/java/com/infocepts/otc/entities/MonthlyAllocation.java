package com.infocepts.otc.entities;

import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;

import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.SqlResultSetMapping;

import com.infocepts.otc.repositories.AmgRolesRepository;
import com.infocepts.otc.repositories.SowDetailRepository;
import com.infocepts.otc.utilities.LoadConstant;

@Entity
@Table(catalog=LoadConstant.otc, schema="[dbo]", name="monthly_allocation")

@SqlResultSetMapping(
	      name = "monthly_alc_with_project",
	      classes = {
	    	@ConstructorResult(
	              targetClass = MonthlyAllocation.class,
	              columns = {
	                  @ColumnResult(name = "monthlyAlcId"),
	                  @ColumnResult(name = "projectId"),
	                  @ColumnResult(name = "uid"),	                  
	                  @ColumnResult(name = "alcStartDate", type=Date.class),
	                  @ColumnResult(name = "alcEndDate", type=Date.class),
	                  @ColumnResult(name = "alcType"),
	                  @ColumnResult(name = "alcHrs", type=BigDecimal.class),
	                  @ColumnResult(name = "alcFte", type=BigDecimal.class),	                  
	                  @ColumnResult(name = "prdId"),
	                  @ColumnResult(name = "prdName", type=String.class),
	                  @ColumnResult(name = "prdMonth"),
	                  @ColumnResult(name = "prdYear"),	                  
	                  @ColumnResult(name = "sowDetailId"),
	                  @ColumnResult(name = "requisitionId"),
	                  @ColumnResult(name = "comments", type=String.class),
	                  @ColumnResult(name = "createdBy"),	
	                  @ColumnResult(name = "createdDate", type=Date.class),
	                  @ColumnResult(name = "modifiedBy"),	
	                  @ColumnResult(name = "modifiedDate", type=Date.class),
	                  @ColumnResult(name = "bucketId"),
	                  //@ColumnResult(name = "resSowRole"),
	                  //@ColumnResult(name = "resUnit"),	
	                  @ColumnResult(name = "projectName", type=String.class),
            		  @ColumnResult(name = "resourceName", type=String.class)	                  
	              }
	          )
	      }
	)
@NamedNativeQueries({
	@NamedNativeQuery(
	            name    	=   "getAllMonthlyAllocation",
	            query   	=   "select al.*, cast(p.title as varchar) as projectName, r.Title as resourceName"+
	            				" FROM " + LoadConstant.otc + " .[dbo].monthly_allocation al"+
	            				" left join " + LoadConstant.infomaster + ".[dbo].project p on p.itemId=al.projectId"+
	            				" left join " + LoadConstant.infomaster + ".[dbo].resource r on r.uid=al.uid",
	            resultClass = MonthlyAllocation.class ,  resultSetMapping = "monthly_alc_with_project"                          
    ),
    @NamedNativeQuery(
	            name    	=   "getMonthlyAllocationById",
	            query   	=   "select al.*, cast(p.title as varchar) as projectName, r.Title as resourceName"+
        						" FROM " + LoadConstant.otc + " .[dbo].monthly_allocation al"+
	            				" left join " + LoadConstant.infomaster + ".[dbo].project p on p.itemId=al.projectId"+
	            				" left join " + LoadConstant.infomaster + ".[dbo].resource r on r.uid=al.uid"+
            					" WHERE al.monthlyAlcId = :monthlyAlcId",
	            resultClass	=	MonthlyAllocation.class , resultSetMapping = "monthly_alc_with_project"
    ),
    @NamedNativeQuery(
            name    	=   "getMonthlyAllocationsForProject",
            query   	=   "select al.*, cast(p.title as varchar) as projectName, r.Title as resourceName"+
    						" FROM " + LoadConstant.otc + " .[dbo].monthly_allocation al"+
            				" left join " + LoadConstant.infomaster + ".[dbo].project p on p.itemId=al.projectId"+
            				" left join " + LoadConstant.infomaster + ".[dbo].resource r on r.uid=al.uid"+
        					" WHERE al.projectId = :projectId"+
            				" AND ( ((:alcType > 0 and :alcType < 20) and (al.alcType = :alcType))"+ // Specific type of allocation (billable or non-billable)
        							" OR ((:alcType = 20) and ((al.alcType = 2 OR al.alcType = 3)))"+ // All types of non-billable
        							" OR (:alcType = 0))",
            resultClass	=	MonthlyAllocation.class , resultSetMapping = "monthly_alc_with_project"
	)
   
})

public class MonthlyAllocation {
	
	@Transient
	@Autowired
	SowDetailRepository repository;

	@Transient
	@Autowired
	AmgRolesRepository amgRepository;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)		
	private Integer monthlyAlcId;
	
	@ManyToOne
	@JoinColumn(name="alcId")
	private Allocation allocation;
		
	//@NotNull - Removed not null, In case of soft allocation there will be no project
	private Integer projectId;
		
	@NotNull
	private Integer uid;		
		
	
	private Date alcStartDate;
	private Date alcEndDate;	
	
	@NotNull
	private Integer alcType; // value should be 1 (Billable), 2 (Non Billable), 3 (Non Billable Trainee), 4 (Billed Buffer)
	
	@Transient
	private String allocationType;
	
	@NotNull
	private BigDecimal alcFte; // Allocation fte for the selected month
	
	@NotNull
	private Integer prdId;
	
	@NotNull
	private String prdName; // Allocation period (month), e.g. Apr 2017
	
	@NotNull
	private Integer prdMonth; // Allocation period (month) in number, e.g. For Apr 2017 - 4
	
	@NotNull
	private Integer prdYear; // Allocation period (year) in number, e.g. For Apr 2017 - 2017
			
	@NotNull
	private BigDecimal alcHrs; // For the selected month. This should be calculated based on formula -> total work days - holidays in that month
	
	private Integer sowDetailId;//used to map with SOW. keeping optional now

	private String requisitionId;//need to be mandatory but keep optional for migration

	//private BigDecimal billableAlc;//currently all values are 1	===== NOT REQUIRED
	
	private String comments;

	private Integer createdBy;	
	private Date createdDate;	
	private Integer modifiedBy;
	private Date modifiedDate;
	private Integer bucketId;
	
	
	
	@Transient
	private Integer resSowRole;
	
	@Transient
	private Integer resUnit;
	
	@Transient
	private String projectName;
	
	@Transient
	private String resourceName;
	
	@Transient
	private String sowRoleName;

	
	/************************Getter Setter Functions******************************************************/
	public Integer getMonthlyAlcId() {
		return monthlyAlcId;
	}

	public void setMonthlyAlcId(Integer monthlyAlcId) {
		this.monthlyAlcId = monthlyAlcId;
	}

	public Integer getProjectId() {
		return projectId;
	}

	public void setProjectId(Integer projectId) {
		this.projectId = projectId;
	}

	public Integer getUid() {
		return uid;
	}

	public void setUid(Integer uid) {
		this.uid = uid;
	}

	public Date getAlcStartDate() {
		return alcStartDate;
	}

	public void setAlcStartDate(Date alcStartDate) {
		this.alcStartDate = alcStartDate;
	}

	public Date getAlcEndDate() {
		return alcEndDate;
	}

	public void setAlcEndDate(Date alcEndDate) {
		this.alcEndDate = alcEndDate;
	}

	public Integer getAlcType() {
		return alcType;
	}

	public void setAlcType(Integer alcType) {
		this.alcType = alcType;
	}

	public BigDecimal getAlcHrs() {
		return alcHrs;
	}

	public void setAlcHrs(BigDecimal alcHrs) {
		this.alcHrs = alcHrs;
	}

	public BigDecimal getAlcFte() {
		return alcFte;
	}

	public void setAlcFte(BigDecimal alcFte) {
		this.alcFte = alcFte;
	}

	public Integer getPrdId() {
		return prdId;
	}

	public void setPrdId(Integer prdId) {
		this.prdId = prdId;
	}

	public String getPrdName() {
		return prdName;
	}

	public void setPrdName(String prdName) {
		this.prdName = prdName;
	}

	public Integer getPrdMonth() {
		return prdMonth;
	}

	public void setPrdMonth(Integer prdMonth) {
		this.prdMonth = prdMonth;
	}

	public Integer getPrdYear() {
		return prdYear;
	}

	public void setPrdYear(Integer prdYear) {
		this.prdYear = prdYear;
	}

	public Integer getSowDetailId() {
		return sowDetailId;
	}

	public void setSowDetailId(Integer sowDetailId) {
		this.sowDetailId = sowDetailId;
	}

	public String getRequisitionId() {
		return requisitionId;
	}

	public void setRequisitionId(String requisitionId) {
		this.requisitionId = requisitionId;
	}	

	public Integer getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Integer getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	
	public Integer getBucketId() {
		return bucketId;
	}

	public void setBucketId(Integer bucketId) {
		this.bucketId = bucketId;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	@Transient
	public Integer getResSowRole() {
		return resSowRole;
	}

	public void setResSowRole(Integer resSowRole) {
		this.resSowRole = resSowRole;
	}

	@Transient
	public Integer getResUnit() {
		return resUnit;
	}

	public void setResUnit(Integer resUnit) {
		this.resUnit = resUnit;
	}
		
	@Transient
	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	
	@Transient
	public String getResourceName() {
		return resourceName;
	}

	public void setResourceName(String resourceName) {
		this.resourceName = resourceName;
	}
	
	@Transient
	public String getAllocationType() {
		return allocationType;
	}

	public void setAllocationType(String allocationType) {
		this.allocationType = allocationType;
	}
	
	@Transient
	public String getSowRoleName() {
		return sowRoleName;
	}

	public void setSowRoleName(String sowRoleName) {
		this.sowRoleName = sowRoleName;
	}
	
	public Allocation getAllocation() {
		return allocation;
	}

	public void setAllocation(Allocation allocation) {
		this.allocation = allocation;
	}

	/************************Constructor Functions******************************************************/
	
	public MonthlyAllocation() {
	}
	
	public MonthlyAllocation(Integer monthlyAlcId, Integer projectId, Integer uid, Date alcStartDate, Date alcEndDate,
			Integer alcType, BigDecimal alcHrs, BigDecimal alcFte, Integer prdId, String prdName, Integer prdMonth, Integer prdYear, 
			Integer sowDetailId, String requisitionId, String comments,
			Integer createdBy, Date createdDate, Integer modifiedBy, Date modifiedDate, Integer bucketId,
			//Integer resSowRole, Integer resUnit,
			String projectName, String resourceName) {
		super();
		this.monthlyAlcId = monthlyAlcId;
		this.projectId = projectId;
		this.uid = uid;
		this.alcStartDate = alcStartDate;
		this.alcEndDate = alcEndDate;
		
		this.alcType = alcType;
		if(alcType == 1) this.allocationType = "Billable";
		if(alcType == 2) this.allocationType = "Non Billable";
		if(alcType == 3) this.allocationType = "Non Billable Trainee";
		if(alcType == 4) this.allocationType = "Billed Buffer";
		
		this.alcHrs = alcHrs;
		this.alcFte = alcFte;
		this.prdId = prdId;
		this.prdName = prdName;
		this.prdMonth = prdMonth;
		this.prdYear = prdYear;
		this.sowDetailId = sowDetailId;
		if(sowDetailId != null)
		{
			SowDetail sowDetail = repository.findOne(sowDetailId);
			
			AmgRoles amgRole = amgRepository.findOne(sowDetail.getRoleId());
			sowRoleName = amgRole.getAmgRoleName();
		
		}
		this.requisitionId = requisitionId;
		this.comments = comments;
		this.createdBy = createdBy;
		this.createdDate = createdDate;
		this.modifiedBy = modifiedBy;
		this.modifiedDate = modifiedDate;
		this.bucketId = bucketId;
		
		//this.resSowRole = resSowRole;
		//this.resUnit = resUnit;
		
		this.projectName = projectName;
		this.resourceName = resourceName;
	}	
}
