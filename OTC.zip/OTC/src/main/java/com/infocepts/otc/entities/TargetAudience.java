/**
* Filename: /src/main/java/com/infocepts/otc/entities/TargetAudience.java
* @author  Anjali S. Kalbande
* @version 1.0
* @since   2019-06-10 
*/
package com.infocepts.otc.entities;

import java.util.Date;
import java.util.List;

import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.SqlResultSetMappings;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.infocepts.otc.utilities.LoadConstant;
@Entity
@Table(catalog=LoadConstant.otc, schema="[dbo]", name="targetAudience")

@SqlResultSetMappings({
        @SqlResultSetMapping(
                name = "targetAudienceList",
                classes = {
                        @ConstructorResult(
                                targetClass = TargetAudience.class,
                                columns = {
                                		@ColumnResult(name = "targetAudienceId"),
                                		@ColumnResult(name = "surveyId"),
										@ColumnResult(name = "targetAudienceName", type = String.class),                                    
										@ColumnResult(name = "employeeId"),
										@ColumnResult(name = "employeeEmail", type = String.class),										
										@ColumnResult(name = "createdBy"),
										@ColumnResult(name = "createdDate", type = Date.class),
										@ColumnResult(name = "modifiedBy"),
										@ColumnResult(name = "modifiedDate", type = Date.class),
										@ColumnResult(name = "createdByName", type = String.class),
										@ColumnResult(name = "surveyName", type = String.class),
										@ColumnResult(name = "uid"),
										@ColumnResult(name = "email", type = String.class),
										@ColumnResult(name = "title", type = String.class),
										@ColumnResult(name = "designation", type = String.class),
										@ColumnResult(name = "gradeName", type = String.class),
                                        @ColumnResult(name = "bandName", type = String.class),
                                        @ColumnResult(name = "departmentName", type = String.class),
                                        @ColumnResult(name = "employeeName", type = String.class),
                                        @ColumnResult(name = "targetDelete", type = Boolean.class)
                                        
										
                                }
                        )
                }
        )
})
@NamedNativeQueries({
        @NamedNativeQuery(
                name    =   "getTargetAudienceOnSurveyChange",   
                query 	=   "Select tra.* ,"+ "ra.title as createdByName, sr.title as surveyName, 0 as uid, '' as email, '' as title, '' as designation, '' as gradeName, '' as bandName, '' as departmentName, rc.title as employeeName, 1 as targetDelete"+
							" from " + LoadConstant.otc + ".[dbo].TargetAudience as tra " +
							" left join " + LoadConstant.infomaster +".[dbo].[resource] ra on ra.uid = tra.createdBy " +
							" left join " + LoadConstant.infomaster +".[dbo].[resource] rc on rc.uid = tra.employeeId " +
							" left join " + LoadConstant.otc +".[dbo].[survey] sr on sr.surveyId = tra.surveyId"+
							" where tra.surveyId = :surveyId order by tra.surveyId",
							resultClass=TargetAudience.class, resultSetMapping = "targetAudienceList"
        ),
        @NamedNativeQuery(
        		name    =   "getTargetAudienceBySurveyId",   
        		query 	=   "Select tra.*,"+ " r.title as createdByName, sr.title as surveyName, r.uid, r.email, r.title, g.designation, g.grade as gradeName, b.band as bandName, d.departmentName, '' as employeeName, 1 as targetDelete"+
        					" from " + LoadConstant.infomaster + ".[dbo].resource as r " +
        					" left join " + LoadConstant.otc +".[dbo].[targetaudience] tra on tra.employeeId = r.uid and tra.surveyId = :surveyId" +
        					" left join " + LoadConstant.otc +".[dbo].[survey] sr on sr.surveyId = tra.surveyId " +
        					" left join " + LoadConstant.infomaster +".[dbo].[grade] g on g.gradeId = r.gradeId " +
        					" left join " + LoadConstant.infomaster +".[dbo].[band] b on b.bandId = r.bandId " +
        					" left join " + LoadConstant.infomaster + ".[dbo].[department] d on d.departmentId = r.departmentId" +
        					" order by tra.employeeId desc",
        					resultClass=TargetAudience.class, resultSetMapping = "targetAudienceList"
        )    
})

public class TargetAudience implements Cloneable {

	// Entity Columns
	@Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Integer targetAudienceId; 	
	
	private Integer surveyId;
	private String targetAudienceName;
	private Integer employeeId;
	private String employeeEmail;
	
	private Integer createdBy;
	private Date createdDate;
	private Integer modifiedBy;
	private Date modifiedDate;
	
	@Transient
	private String createdByName;
	
	@Transient
	private String surveyName;
	
	@Transient
	private List<String> resourcePKList;
	
	@Transient
	private Integer uid;
	
	@Transient
	private String email;
	
	@Transient
	private String title;
	
	@Transient
	private String designation;
	
	@Transient
	private String gradeName;
	
	@Transient
	private String bandName;
	
	@Transient
	private String departmentName;
	
	@Transient
	private String employeeName;
	
	@Transient
	private Boolean targetDelete;
	
	// Getter setter	
		
	public List<String> getResourcePKList() {
		return resourcePKList;
	}
	public void setResourcePKList(List<String> resourcePKList) {
		this.resourcePKList = resourcePKList;
	}
	public Integer getTargetAudienceId() {
		return targetAudienceId;
	}
	public void setTargetAudienceId(Integer targetAudienceId) {
		this.targetAudienceId = targetAudienceId;
	}
	public Integer getSurveyId() {
		return surveyId;
	}
	public void setSurveyId(Integer surveyId) {
		this.surveyId = surveyId;
	}
	public String getTargetAudienceName() {
		return targetAudienceName;
	}
	public void setTargetAudienceName(String targetAudienceName) {
		this.targetAudienceName = targetAudienceName;
	}
	public Integer getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployeeEmail() {
		return employeeEmail;
	}
	public void setEmployeeEmail(String employeeEmail) {
		this.employeeEmail = employeeEmail;
	}
	public Integer getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public Integer getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public Date getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public String getCreatedByName() {
		return createdByName;
	}
	public void setCreatedByName(String createdByName) {
		this.createdByName = createdByName;
	}
	public String getSurveyName() {
		return surveyName;
	}
	public void setSurveyName(String surveyName) {
		this.surveyName = surveyName;
	}
	public Integer getUid() {
		return uid;
	}
	public void setUid(Integer uid) {
		this.uid = uid;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}	
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getGradeName() {
		return gradeName;
	}
	public void setGradeName(String gradeName) {
		this.gradeName = gradeName;
	}
	public String getBandName() {
		return bandName;
	}
	public void setBandName(String bandName) {
		this.bandName = bandName;
	}
	public String getDepartmentName() {
		return departmentName;
	}
	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}	
	public Boolean getTargetDelete() {
		return targetDelete;
	}
	public void setTargetDelete(Boolean targetDelete) {
		this.targetDelete = targetDelete;
	}
	
	// Constructor
	public TargetAudience() {		
	}
	
	// Constructor using fields
	public TargetAudience(Integer targetAudienceId, Integer surveyId, String targetAudienceName, Integer employeeId,
			String employeeEmail, Integer createdBy, Date createdDate, Integer modifiedBy, Date modifiedDate,
			String createdByName, String surveyName, Integer uid, String email, String title, String designation, String gradeName, String bandName, String departmentName, String employeeName, Boolean targetDelete) {
	
		this.targetAudienceId = targetAudienceId;
		this.surveyId = surveyId;
		this.targetAudienceName = targetAudienceName;
		this.employeeId = employeeId;
		this.employeeEmail = employeeEmail;
		this.createdBy = createdBy;
		this.createdDate = createdDate;
		this.modifiedBy = modifiedBy;
		this.modifiedDate = modifiedDate;
		this.createdByName = createdByName;
		this.surveyName = surveyName;
		this.uid = uid;
		this.email = email;
		this.title=title;
		this.designation = designation;
		this.gradeName = gradeName;
		this.bandName = bandName;
		this.departmentName = departmentName;
		this.employeeName = employeeName;
		this.targetDelete = targetDelete;
	}		
	
	@Override
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}
	
}
