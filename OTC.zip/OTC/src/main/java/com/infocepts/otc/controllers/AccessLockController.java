package com.infocepts.otc.controllers;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infocepts.otc.entities.AccessLock;
import com.infocepts.otc.repositories.AccessLockRepository;
import com.infocepts.otc.services.TimesheetService;

@RestController
@RequestMapping("/accesslock")
public class AccessLockController {
	
	final Logger logger = Logger.getLogger(AccessLockController.class);

	@Autowired
	AccessLockRepository repository;
	@Autowired
	private TimesheetService timesheetService;
	@PersistenceContext(unitName="otc")
    private EntityManager entityManager;
	
	@PostMapping
	public AccessLock addAccessLock(@RequestBody AccessLock accesslock)
	{
		try{
			accesslock.setAccessLockId(null);
			repository.save(accesslock);	
		}catch(Exception e){
			logger.error(e);
		}
		return accesslock;
	}	
 
	 @GetMapping
	 public List<AccessLock> getAllAccessLock(){
		 List<AccessLock> accessLockList=null;
		 try{
			 // Return blocked user accounts only when user type is Admin.
			 accessLockList = this.timesheetService.isAdmin() ? this.entityManager.createNamedQuery("blockedUserNamedQuery", AccessLock.class).getResultList() : null;
		 }
		 catch(Exception e){
			 this.logger.error("Something went wrong while fetching blocked user accounts!", e);
		 }
		 return accessLockList;
	 }
	 
	 @GetMapping(value="/{username}")
	 public AccessLock getAccessLock(@PathVariable String username){
		 AccessLock accesslock=null;
		 try{
			 accesslock = repository.findUsername(username);
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return accesslock;
	 }
	 
	 
	 @PutMapping(value="/{accessLockId}")
	 public AccessLock updateAccessLock(@RequestBody AccessLock updatedAccessLock,@PathVariable Integer accessLockId){
		 try{
			 updatedAccessLock.setAccessLockId(accessLockId);
			 repository.save(updatedAccessLock);
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return updatedAccessLock;
	 }
	 
	 @DeleteMapping(value="/{accessLockId}")
	 public void deleteAccessLock(@PathVariable Integer accessLockId){
		 try{
			 repository.delete(accessLockId);
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
	 }
}
