package com.infocepts.otc.controllers;

import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.infocepts.otc.entities.Region;
import com.infocepts.otc.repositories.RegionRepository;


@RestController
@RequestMapping(value="/region",headers="referer")
public class RegionController {
	
	final Logger logger = Logger.getLogger(RegionController.class);

	@Autowired
	RegionRepository repository;
	
	@RequestMapping(method=RequestMethod.POST)
	public Region addRegion(@RequestBody Region region)
	{
		try{
			region.setRegionId(null);
			repository.save(region);	
		}catch(Exception e){
			logger.error(e);
		}
		return region;
	}	
 
	 @RequestMapping(method=RequestMethod.GET)
	 public List<Region> getAllRegions(){
		 List<Region> regionlist=null;
		 try{
			 regionlist = repository.findAll();
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return regionlist;
	 }

	@RequestMapping(value="/{regionId}",method=RequestMethod.GET)
	 public Region getRegion(@PathVariable Integer regionId){
		 Region region=null;
		 try{
			 region = repository.findOne(regionId);
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return region;
	 }
	 
	 
	 
	 
	 @RequestMapping(value="/{regionId}",method=RequestMethod.PUT)
	 public Region updateRegion(@RequestBody Region updatedRegion,@PathVariable Integer regionId){
		 try{
			 updatedRegion.setRegionId(regionId);
			 repository.save(updatedRegion);
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return updatedRegion;
	 }
	 
	 @RequestMapping(value="/{regionId}",method=RequestMethod.DELETE)
	 public void deleteRegion(@PathVariable Integer regionId){
		 try{
			 repository.delete(regionId);
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
	 }	 
}
