package com.infocepts.otc.controllers;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.infocepts.otc.entities.Configuration;
import com.infocepts.otc.repositories.ConfigurationRepository;

@RestController
@RequestMapping(value="/configuration",headers="referer")
public class ConfigurationController {
	
	@Autowired
	ConfigurationRepository repository;
	
    final Logger logger = Logger.getLogger(ConfigurationController.class);

	@RequestMapping(method=RequestMethod.GET)
	 public Configuration getConfig(@RequestParam(value = "name",defaultValue = "") String name){
		Configuration cofig =null;
		 try{
			 cofig = repository.findByTitle(name);
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return cofig;
	 }
}
