package com.infocepts.otc.entities;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import javax.persistence.Lob;

import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.SqlResultSetMappings;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.infocepts.otc.utilities.LoadConstant;

@Entity
@Table(catalog=LoadConstant.otc, schema="[dbo]",name="infoTravel")
@SqlResultSetMappings({
@SqlResultSetMapping(
  name = "last_tour_code",
	      classes = {
	          @ConstructorResult(
	              targetClass = InfoTravel.class,
	              columns = {
	            		  @ColumnResult(name = "tourCode"),
	            		  @ColumnResult(name = "createdDate", type=Date.class),
	                }
	          )
	      }),

@SqlResultSetMapping(
		  name = "get_Allinfotravel",
			      classes = {
			          @ConstructorResult(
			              targetClass = InfoTravel.class,
			              columns = {
			            		  @ColumnResult(name = "infoTravelId" ),
			            		  @ColumnResult(name = "tourCode", type=String.class),
			            		  @ColumnResult(name = "uid" ),
			            		  @ColumnResult(name = "travelType", type=String.class),
			            		  @ColumnResult(name = "travelWay", type=String.class),
			            		  @ColumnResult(name = "travelMode" , type=String.class),
			            		  @ColumnResult(name = "returnDate", type=Date.class),
			            		  @ColumnResult(name = "adultCount"),
			            		  @ColumnResult(name = "childCount"),
			            		  @ColumnResult(name = "infantCount"),
			            		  @ColumnResult(name = "unit"),
			            		  @ColumnResult(name = "associateUnit"),
			            		  @ColumnResult(name = "invoiceUnit"),
			            		  @ColumnResult(name = "projectId"),
			            		  @ColumnResult(name = "pmName" , type=String.class),
			            		  @ColumnResult(name = "approverId"),
			            		  @ColumnResult(name = "financeId"),			            		  
			            		  @ColumnResult(name = "typeOfTravel", type=String.class),
			            		  @ColumnResult(name =  "travelPurpose" , type=String.class),
			            		  @ColumnResult(name =  "travelCost"),
			            		  @ColumnResult(name = "nomineeName" , type=String.class),
			            		  @ColumnResult(name =  "nomineeRelation", type=String.class),
			            		  @ColumnResult(name =  "emergencyContact", type=String.class),
			            		  @ColumnResult(name =  "visaRequired"),
			            		  @ColumnResult(name = "visaCategory", type=String.class),
			            		  @ColumnResult(name = "accomodation"),
			            		  @ColumnResult(name = "checkin", type=Date.class),
			            		  @ColumnResult(name =  "checkout", type=Date.class),
			            		  @ColumnResult(name = "address", type=String.class),
			            		  @ColumnResult(name = "travellerDoc", type=String.class),
			            		  @ColumnResult(name = "travellerRemarks", type=String.class),
			            		  @ColumnResult(name = "approvalRemarks", type=String.class),
			            		  @ColumnResult(name = "travelDeskClosureRemarks", type=String.class),
			            		  @ColumnResult(name = "rating"),
			            		  @ColumnResult(name = "ratingComments", type=String.class),
			            		  @ColumnResult(name = "createdDate", type=Date.class),
			            		  @ColumnResult(name = "modifiedBy"),
			            		  @ColumnResult(name = "modifiedDate", type=Date.class),
			            		  @ColumnResult(name = "submittedDate", type=Date.class),
			            		  @ColumnResult(name = "submissionStatus"),
			            		  @ColumnResult(name = "approvalStatus"),
			            		  @ColumnResult(name = "approvalDate", type=Date.class),
			            		  @ColumnResult(name = "validatedDate", type=Date.class),
			            		  @ColumnResult(name = "acknowledgedDate", type=Date.class),
			            		  @ColumnResult(name = "travelDeskClosureStatus"),
			            		  @ColumnResult(name = "reasonForCancellation", type=String.class),
			            		  @ColumnResult(name = "cancelledDate", type=Date.class),
			            		  @ColumnResult(name = "closedDate", type=Date.class),
			            		  @ColumnResult(name = "recovery", type=String.class),
			            		  @ColumnResult(name = "recoveryComments", type=String.class),
			            		  @ColumnResult(name = "isMigrated", type=Boolean.class),
			            		  @ColumnResult(name = "projectMigrated", type=String.class),			            		  
			            		  @ColumnResult(name = "isGuest", type=Boolean.class),			            		  
			            		  @ColumnResult(name = "costSavingAmount", type=BigDecimal.class),
			            		  @ColumnResult(name = "cancellationCost", type=BigDecimal.class),
			            		  @ColumnResult(name = "reissueCost", type=BigDecimal.class),
			            		  @ColumnResult(name = "projectManagerName", type=String.class),
				                  @ColumnResult(name = "projectName", type=String.class),
				                  @ColumnResult(name = "unitName", type=String.class),
				                  @ColumnResult(name = "associateName", type=String.class),
				                  @ColumnResult(name = "associateUnitName", type=String.class),
				                  @ColumnResult(name = "invoiceUnitName", type=String.class),
								  
				                //InfoTravel Details
								  @ColumnResult(name = "origin", type=String.class),
								  @ColumnResult(name = "destination", type=String.class),
								  @ColumnResult(name = "departureDate", type=Date.class),
								  
								//InfoTraveller
								  @ColumnResult(name = "givenName", type=String.class),
								  @ColumnResult(name = "surname", type=String.class),
								  @ColumnResult(name = "dob", type=Date.class),
								  @ColumnResult(name = "gender", type=String.class),
								  @ColumnResult(name = "mobileOrigin", type=String.class),
								  @ColumnResult(name = "mobileDestination", type=String.class),
								  @ColumnResult(name = "passportNo", type=String.class),
								  @ColumnResult(name = "nationality", type=String.class),		                  
								  @ColumnResult(name = "empId"),
								  @ColumnResult(name = "seat", type=String.class),
								  @ColumnResult(name = "email", type=String.class),
								  @ColumnResult(name = "alternateEmail", type=String.class),
								  @ColumnResult(name = "meal", type=String.class),
								  @ColumnResult(name = "frequentFlyerNo", type=String.class),
								  @ColumnResult(name = "airline", type=String.class),
								  
								  // InfoTravel Desk						  
								  
								  @ColumnResult(name = "infoTravelDeskId"),
								  @ColumnResult(name = "requestDate", type=Date.class),
								  @ColumnResult(name = "transactionDate", type=Date.class),
								  @ColumnResult(name = "location", type=String.class),
								  @ColumnResult(name = "sector", type=String.class),
								  @ColumnResult(name = "service", type=String.class),
								  @ColumnResult(name = "serviceType", type=String.class),
								  @ColumnResult(name = "onwardDate", type=Date.class),
								  @ColumnResult(name = "returnDateTravel", type=Date.class),
								  @ColumnResult(name = "serviceProvider", type=String.class),
								  @ColumnResult(name = "confirmationNo", type=String.class),
								  @ColumnResult(name = "ticketNo", type=String.class),
								  @ColumnResult(name = "remarks", type=String.class),
								  @ColumnResult(name = "confirmedCost", type=BigDecimal.class),
								  @ColumnResult(name = "highestCost", type=BigDecimal.class),
								  @ColumnResult(name = "lowestCost", type=BigDecimal.class),
								  @ColumnResult(name = "recoveryTravel", type=BigDecimal.class),
								  @ColumnResult(name = "vendor", type=String.class),
								  @ColumnResult(name = "exceptionalApproval"),
								  @ColumnResult(name = "reasonForExceptionalApproval", type=String.class),
								  @ColumnResult(name = "reissueService", type=String.class),
								  @ColumnResult(name = "reissueCostTravel", type=BigDecimal.class),
								  @ColumnResult(name = "cancellationCostTravel", type=BigDecimal.class),
								  @ColumnResult(name = "cancellationApprover"),
								  @ColumnResult(name = "reasonForChange", type=String.class),
								  @ColumnResult(name = "cancellationReasonForChange", type=String.class),
								  @ColumnResult(name = "cancellationStatus", type=String.class),
								  @ColumnResult(name = "invoiceDate", type=Date.class),
								  @ColumnResult(name = "invoiceNo", type=String.class),
								  @ColumnResult(name = "basicFare", type=BigDecimal.class),
								  @ColumnResult(name = "yQTax", type=BigDecimal.class),
								  @ColumnResult(name = "others", type=BigDecimal.class),
								  @ColumnResult(name = "discount", type=BigDecimal.class),
								  @ColumnResult(name = "agentFee", type=BigDecimal.class),
								  @ColumnResult(name = "sGST", type=BigDecimal.class),
								  @ColumnResult(name = "cGST", type=BigDecimal.class),
								  @ColumnResult(name = "iGST", type=BigDecimal.class),
								  @ColumnResult(name = "invoiceAmount", type=BigDecimal.class),
								  @ColumnResult(name = "invoiceStatus", type=String.class),
								  
								  //grades
			            		  @ColumnResult(name = "associateGrade", type=String.class),
			            		  @ColumnResult(name = "approverGrade", type=String.class),
			            		  @ColumnResult(name = "managerGrade", type=String.class),
			            		  @ColumnResult(name = "validatorGrade", type=String.class),
			            		  @ColumnResult(name = "modifiedName", type=String.class),
			            		  @ColumnResult(name = "validatorName", type=String.class),
			            		  @ColumnResult(name = "managerEmpId"),
			            		  @ColumnResult(name = "approverEmpId"),
			            		  @ColumnResult(name = "validatorEmpId")            		  

			            		  
			                }
			          )
			      }),

@SqlResultSetMapping(
		  name = "get_infotravel",
			      classes = {
			          @ConstructorResult(
			              targetClass = InfoTravel.class,
			              columns = {
			            		  @ColumnResult(name = "infoTravelId" ),
			            		  @ColumnResult(name = "tourCode", type=String.class),
			            		  @ColumnResult(name = "uid" ),
			            		  @ColumnResult(name = "travelType", type=String.class),
			            		  @ColumnResult(name = "travelWay", type=String.class),
			            		  @ColumnResult(name = "travelMode" , type=String.class),
			            		  @ColumnResult(name = "returnDate", type=Date.class),
			            		  @ColumnResult(name = "adultCount"),
			            		  @ColumnResult(name = "childCount"),
			            		  @ColumnResult(name = "infantCount"),
			            		  @ColumnResult(name = "unit"),
			            		  @ColumnResult(name = "associateUnit"),
			            		  @ColumnResult(name = "invoiceUnit"),
			            		  @ColumnResult(name = "projectId"),
			            		  @ColumnResult(name = "pmName", type=String.class),
			            		  @ColumnResult(name = "approverId"),
			            		  @ColumnResult(name = "financeId"),			            		  
			            		  @ColumnResult(name = "typeOfTravel", type=String.class),
			            		  @ColumnResult(name =  "travelPurpose" , type=String.class),
			            		  @ColumnResult(name =  "travelCost"),
			            		  @ColumnResult(name = "nomineeName" , type=String.class),
			            		  @ColumnResult(name =  "nomineeRelation", type=String.class),
			            		  @ColumnResult(name =  "emergencyContact", type=String.class),
			            		  @ColumnResult(name =  "visaRequired"),
			            		  @ColumnResult(name = "visaCategory", type=String.class),
			            		  @ColumnResult(name = "accomodation"),
			            		  @ColumnResult(name = "checkin", type=Date.class),
			            		  @ColumnResult(name =  "checkout", type=Date.class),
			            		  @ColumnResult(name = "address", type=String.class),
			            		  @ColumnResult(name = "travellerDoc", type=String.class),
			            		  @ColumnResult(name = "travellerRemarks", type=String.class),
			            		  @ColumnResult(name = "approvalRemarks", type=String.class),
			            		  @ColumnResult(name = "travelDeskClosureRemarks", type=String.class),
			            		  @ColumnResult(name = "rating"),
			            		  @ColumnResult(name = "ratingComments", type=String.class),
			            		  @ColumnResult(name = "createdDate", type=Date.class),
			            		  @ColumnResult(name = "modifiedBy"),
			            		  @ColumnResult(name = "modifiedDate", type=Date.class),
			            		  @ColumnResult(name = "submittedDate", type=Date.class),
			            		  @ColumnResult(name = "submissionStatus"),
			            		  @ColumnResult(name = "approvalStatus"),
			            		  @ColumnResult(name = "approvalDate", type=Date.class),
			            		  @ColumnResult(name = "validatedDate", type=Date.class),
			            		  @ColumnResult(name = "acknowledgedDate", type=Date.class),
			            		  @ColumnResult(name = "travelDeskClosureStatus"),
			            		  @ColumnResult(name = "reasonForCancellation", type=String.class),
			            		  @ColumnResult(name = "cancelledDate", type=Date.class),
			            		  @ColumnResult(name = "closedDate", type=Date.class),
			            		  @ColumnResult(name = "recovery", type=String.class),
			            		  @ColumnResult(name = "recoveryComments", type=String.class),
			            		  @ColumnResult(name = "isMigrated", type=Boolean.class),
			            		  @ColumnResult(name = "projectMigrated", type=String.class),			            		  
			            		  @ColumnResult(name = "isGuest", type=Boolean.class),			            		  
			            		  @ColumnResult(name = "costSavingAmount", type=BigDecimal.class),
			            		  @ColumnResult(name = "cancellationCost", type=BigDecimal.class),
			            		  @ColumnResult(name = "reissueCost", type=BigDecimal.class),
			            		  @ColumnResult(name = "projectManagerName", type=String.class),
				                  @ColumnResult(name = "projectName", type=String.class),
				                  @ColumnResult(name = "unitName", type=String.class),
				                  @ColumnResult(name = "associateName", type=String.class),
				                  @ColumnResult(name = "associateUnitName", type=String.class),
				                  @ColumnResult(name = "invoiceUnitName", type=String.class),
			                }
			          )
			      })
})
@NamedNativeQueries({	
    @NamedNativeQuery(
            name    =   "getLastTourCode",
            query   =    "SELECT Top 1 rr.tourCode as tourCode, rr.createdDate as createdDate FROM " + LoadConstant.otc + ".[dbo].[infoTravel] rr order by rr.infotravelId desc",
                      resultClass=InfoTravel.class, resultSetMapping = "last_tour_code"                       		
    ),
	   @NamedNativeQuery (
			   name    =   "getInfoTravel_by_Uid",
	            query   =   "SELECT IT.infoTravelId as infoTravelId, IT.tourCode as tourCode, IT.uid as uid, IT.travelType as travelType,   IT.travelWay as travelWay, IT.travelMode as travelMode, " + 
	            		"IT.returnDate as returnDate, IT.adultCount as adultCount, IT.childCount as childCount, IT.infantCount as infantCount, IT.unit as unit, IT.associateUnit as associateUnit, IT.invoiceUnit as invoiceUnit, IT.projectId as  projectId, IT.pmName as pmName, IT.approverId as  approverId, IT.financeId as financeId,  IT.typeOfTravel as typeOfTravel, " + 
	            		"IT.travelPurpose as travelPurpose, IT.travelCost as travelCost, IT.nomineeName as nomineeName, IT.nomineeRelation as nomineeRelation, IT.emergencyContact as emergencyContact, IT.visaCategory as visaCategory, IT.visaRequired as visaRequired, IT.accomodation as accomodation,IT.checkin as checkin, " + 
	            		"IT.checkout as checkout, IT.address as address, IT.travellerDoc as travellerDoc,IT.travellerRemarks as travellerRemarks, IT.approvalRemarks as approvalRemarks, IT.travelDeskClosureRemarks as travelDeskClosureRemarks, IT.rating as rating, IT.ratingComments as ratingComments, " + 
	            		"IT.createdDate as createdDate, IT.modifiedBy as modifiedBy, IT.modifiedDate as modifiedDate, IT.submittedDate AS submittedDate, IT.submissionStatus as submissionStatus, IT.approvalStatus as approvalStatus," + 
	            		"IT.approvalDate as approvalDate, IT.validatedDate as validatedDate, IT.acknowledgedDate as acknowledgedDate, IT.travelDeskClosureStatus as travelDeskClosureStatus, IT.reasonForCancellation as reasonForCancellation, IT.cancelledDate as cancelledDate, IT.closedDate as closedDate, IT.recovery as recovery, IT.recoveryComments as recoveryComments, IT.isMigrated as isMigrated, IT.projectMigrated as projectMigrated, IT.isGuest as isGuest, IT.costSavingAmount as costSavingAmount, IT.cancellationCost as cancellationCost, IT.reissueCost as reissueCost, rr.title as projectManagerName, p.title as projectName, u.unitName as unitName,un.unitName as associateUnitName, unt.unitName as invoiceUnitName, rs.title as associateName FROM  " + LoadConstant.otc + ".[dbo].[infoTravel] IT " +
	            		"  left join " + LoadConstant.infomaster + ".[dbo].[resource] rr on rr.uid=IT.approverId " +
	            		"  left join " + LoadConstant.infomaster + ".[dbo].[resource] rs on rs.uid=IT.uid " +
	            		"  left join " + LoadConstant.infomaster + " .[dbo].[project] p on p.itemId = IT.projectId "+
	            		" left join " + LoadConstant.infomaster + " .[dbo].[unit] u on u.unitId = IT.unit " +
	            		" left join " + LoadConstant.infomaster + " .[dbo].[unit] un on un.unitId = IT.associateUnit " +
	            		" left join " + LoadConstant.infomaster + " .[dbo].[unit] unt on unt.unitId = IT.invoiceUnit " +
	            		"where IT.uid = :uid order by IT.infoTravelId desc",
	                       resultClass=InfoTravel.class, resultSetMapping = "get_infotravel"
	   ),
	   @NamedNativeQuery (
			   name    =   "getInfoTravel_by_Id",
	            query   =   "SELECT IT.infoTravelId as infoTravelId, IT.tourCode as tourCode, IT.uid as uid, IT.travelType as travelType,   IT.travelWay as travelWay, IT.travelMode as travelMode, " + 
	            		"IT.returnDate as returnDate, IT.adultCount as adultCount, IT.childCount as childCount, IT.infantCount as infantCount, IT.unit as unit, IT.associateUnit as associateUnit, IT.invoiceUnit as invoiceUnit, IT.projectId as  projectId, IT.pmName as pmName, IT.approverId as  approverId, IT.financeId as financeId, IT.typeOfTravel as typeOfTravel, " + 
	            		"IT.travelPurpose as travelPurpose, IT.travelCost as travelCost, IT.nomineeName as nomineeName, IT.nomineeRelation as nomineeRelation, IT.emergencyContact as emergencyContact, IT.visaCategory as visaCategory, IT.visaRequired as visaRequired, IT.accomodation as accomodation,IT.checkin as checkin, " + 
	            		"IT.checkout as checkout, IT.address as address, IT.travellerDoc as travellerDoc, IT.travellerRemarks as travellerRemarks, IT.approvalRemarks as approvalRemarks, IT.travelDeskClosureRemarks as travelDeskClosureRemarks, IT.rating as rating, IT.ratingComments as ratingComments," + 
	            		"IT.createdDate as createdDate, IT.modifiedBy as modifiedBy, IT.modifiedDate as modifiedDate,IT.submittedDate AS submittedDate, IT.submissionStatus as submissionStatus, IT.approvalStatus as approvalStatus," + 
	            		"IT.approvalDate as approvalDate, IT.validatedDate as validatedDate, IT.acknowledgedDate as acknowledgedDate, IT.travelDeskClosureStatus as travelDeskClosureStatus, IT.reasonForCancellation as reasonForCancellation, IT.cancelledDate as cancelledDate, IT.closedDate as closedDate, IT.recovery as recovery, IT.recoveryComments as recoveryComments, IT.isMigrated as isMigrated, IT.projectMigrated as projectMigrated, IT.isGuest as isGuest, IT.costSavingAmount as costSavingAmount, IT.cancellationCost as cancellationCost, IT.reissueCost as reissueCost, rr.title as projectManagerName, p.title as projectName, u.unitName as unitName, un.unitName as associateUnitName, unt.unitName as invoiceUnitName, rs.title as associateName FROM  " + LoadConstant.otc + ".[dbo].[infoTravel] IT " +
	            		"  left join " + LoadConstant.infomaster + ".[dbo].[resource] rr on rr.uid=IT.approverId " +
	            		"  left join " + LoadConstant.infomaster + ".[dbo].[resource] rs on rs.uid=IT.uid " +
	            		"  left join " + LoadConstant.infomaster + " .[dbo].[project] p on p.itemId = IT.projectId "+
	            		" left join " + LoadConstant.infomaster + " .[dbo].[unit] u on u.unitId = IT.unit " +
	            		" left join " + LoadConstant.infomaster + " .[dbo].[unit] un on un.unitId = IT.associateUnit " +
	            		" left join " + LoadConstant.infomaster + " .[dbo].[unit] unt on unt.unitId = IT.invoiceUnit " +
	            		"where IT.infoTravelId = :infoTravelId order by IT.infoTravelId desc",
	                       resultClass=InfoTravel.class, resultSetMapping = "get_infotravel"
	   ),
	   @NamedNativeQuery (
			   name    =   "getInfoTravel_by_All",
	            query   =   "SELECT IT.infoTravelId as infoTravelId, IT.tourCode as tourCode, IT.uid as uid, IT.travelType as travelType,   IT.travelWay as travelWay, IT.travelMode as travelMode, " + 
	            		"IT.returnDate as returnDate, IT.adultCount as adultCount, IT.childCount as childCount, IT.infantCount as infantCount, IT.unit as unit, IT.associateUnit as associateUnit, IT.invoiceUnit as invoiceUnit, IT.projectId as  projectId, IT.pmName as pmName, IT.approverId as  approverId, IT.financeId as financeId, IT.typeOfTravel as typeOfTravel, " + 
	            		"IT.travelPurpose as travelPurpose, IT.travelCost as travelCost, IT.nomineeName as nomineeName, IT.nomineeRelation as nomineeRelation, IT.emergencyContact as emergencyContact, IT.visaCategory as visaCategory, IT.visaRequired as visaRequired, IT.accomodation as accomodation,IT.checkin as checkin, " + 
	            		"IT.checkout as checkout, IT.address as address, IT.travellerDoc as travellerDoc, IT.travellerRemarks as travellerRemarks, IT.approvalRemarks as approvalRemarks, IT.travelDeskClosureRemarks as travelDeskClosureRemarks, IT.rating as rating, IT.ratingComments as ratingComments," + 
	            		"IT.createdDate as createdDate, IT.modifiedBy as modifiedBy, IT.modifiedDate as modifiedDate,IT.submittedDate AS submittedDate, IT.submissionStatus as submissionStatus, IT.approvalStatus as approvalStatus," + 
	            		"IT.approvalDate as approvalDate, IT.validatedDate as validatedDate, IT.acknowledgedDate as acknowledgedDate, IT.travelDeskClosureStatus as travelDeskClosureStatus, IT.reasonForCancellation as reasonForCancellation, IT.cancelledDate as cancelledDate, IT.closedDate as closedDate, IT.recovery as recovery, IT.recoveryComments as recoveryComments, IT.isMigrated as isMigrated, IT.projectMigrated as projectMigrated, IT.isGuest as isGuest, IT.costSavingAmount as costSavingAmount, IT.cancellationCost as cancellationCost, IT.reissueCost as reissueCost, rr.title as projectManagerName, p.title as projectName, u.unitName as unitName, un.unitName as associateUnitName, unt.unitName as invoiceUnitName, rs.title as associateName FROM  " + LoadConstant.otc + ".[dbo].[infoTravel] IT " +
	            		"  left join " + LoadConstant.infomaster + ".[dbo].[resource] rr on rr.uid=IT.approverId " +
	            		"  left join " + LoadConstant.infomaster + ".[dbo].[resource] rs on rs.uid=IT.uid " +
	    	            "  left join " + LoadConstant.infomaster + " .[dbo].[project] p on p.itemId = IT.projectId " +
	    	            " left join " + LoadConstant.infomaster + " .[dbo].[unit] u on u.unitId = IT.unit " +
	    	            " left join " + LoadConstant.infomaster + " .[dbo].[unit] un on un.unitId = IT.associateUnit " +
	            		" left join " + LoadConstant.infomaster + " .[dbo].[unit] unt on unt.unitId = IT.invoiceUnit order by IT.infoTravelId desc" ,
	                      resultClass=InfoTravel.class, resultSetMapping = "get_infotravel"
	   ),
	   @NamedNativeQuery (
			   name    =   "getInfoTravel_by_PMSubmission",
	            query   =   "SELECT IT.infoTravelId as infoTravelId, IT.tourCode as tourCode, IT.uid as uid, IT.travelType as travelType,   IT.travelWay as travelWay, IT.travelMode as travelMode, " + 
	            		"IT.returnDate as returnDate, IT.adultCount as adultCount, IT.childCount as childCount, IT.infantCount as infantCount, IT.unit as unit, IT.associateUnit as associateUnit, IT.invoiceUnit as invoiceUnit, IT.projectId as  projectId, IT.pmName as pmName, IT.approverId as  approverId, IT.financeId as financeId, IT.typeOfTravel as typeOfTravel, " + 
	            		"IT.travelPurpose as travelPurpose, IT.travelCost as travelCost, IT.nomineeName as nomineeName, IT.nomineeRelation as nomineeRelation, IT.emergencyContact as emergencyContact, IT.visaCategory as visaCategory, IT.visaRequired as visaRequired, IT.accomodation as accomodation,IT.checkin as checkin, " + 
	            		"IT.checkout as checkout, IT.address as address, IT.travellerDoc as travellerDoc, IT.travellerRemarks as travellerRemarks, IT.approvalRemarks as approvalRemarks, IT.travelDeskClosureRemarks as travelDeskClosureRemarks, IT.rating as rating, IT.ratingComments as ratingComments," + 
	            		"IT.createdDate as createdDate, IT.modifiedBy as modifiedBy, IT.modifiedDate as modifiedDate, IT.submittedDate AS submittedDate,  IT.submissionStatus as submissionStatus, IT.approvalStatus as approvalStatus," + 
	            		"IT.approvalDate as approvalDate, IT.validatedDate as validatedDate, IT.acknowledgedDate as acknowledgedDate, IT.travelDeskClosureStatus as travelDeskClosureStatus, IT.reasonForCancellation as reasonForCancellation, IT.cancelledDate as cancelledDate, IT.closedDate as closedDate, IT.recovery as recovery, IT.recoveryComments as recoveryComments, IT.isMigrated as isMigrated, IT.projectMigrated as projectMigrated, IT.isGuest as isGuest, IT.costSavingAmount as costSavingAmount, IT.cancellationCost as cancellationCost, IT.reissueCost as reissueCost, rr.title as projectManagerName, p.title as projectName, u.unitName as unitName, un.unitName as associateUnitName, unt.unitName as invoiceUnitName, rs.title as associateName FROM  " + LoadConstant.otc + ".[dbo].[infoTravel] IT " + 
	            		"  left join " + LoadConstant.infomaster + ".[dbo].[resource] rr on rr.uid=IT.approverId " +
	            		"  left join " + LoadConstant.infomaster + ".[dbo].[resource] rs on rs.uid=IT.uid " +
	            		"  left join " + LoadConstant.infomaster + " .[dbo].[project] p on p.itemId = IT.projectId "+
	            		" left join " + LoadConstant.infomaster + " .[dbo].[unit] u on u.unitId = IT.unit " +
	            		" left join " + LoadConstant.infomaster + " .[dbo].[unit] un on un.unitId = IT.associateUnit " +
	            		" left join " + LoadConstant.infomaster + " .[dbo].[unit] unt on unt.unitId = IT.invoiceUnit " +
	            		"where IT.submissionStatus >= 1 and IT.approverId = :uid order by IT.infoTravelId desc",
	                      resultClass=InfoTravel.class, resultSetMapping = "get_infotravel"
	   ),
	   @NamedNativeQuery (
			   name    =   "getInfoTravel_by_PMUid",
	            query   =   "SELECT IT.infoTravelId as infoTravelId, IT.tourCode as tourCode, IT.uid as uid, IT.travelType as travelType,   IT.travelWay as travelWay, IT.travelMode as travelMode, " + 
	            		"IT.returnDate as returnDate, IT.adultCount as adultCount, IT.childCount as childCount, IT.infantCount as infantCount, IT.unit as unit, IT.associateUnit as associateUnit, IT.invoiceUnit as invoiceUnit, IT.projectId as  projectId, IT.pmName as pmName, IT.approverId as  approverId, IT.financeId as financeId, IT.typeOfTravel as typeOfTravel, " + 
	            		"IT.travelPurpose as travelPurpose, IT.travelCost as travelCost, IT.nomineeName as nomineeName, IT.nomineeRelation as nomineeRelation, IT.emergencyContact as emergencyContact, IT.visaCategory as visaCategory, IT.visaRequired as visaRequired, IT.accomodation as accomodation,IT.checkin as checkin, " + 
	            		"IT.checkout as checkout, IT.address as address, IT.travellerDoc as travellerDoc, IT.travellerRemarks as travellerRemarks, IT.approvalRemarks as approvalRemarks, IT.travelDeskClosureRemarks as travelDeskClosureRemarks, IT.rating as rating, IT.ratingComments as ratingComments," + 
	            		"IT.createdDate as createdDate, IT.modifiedBy as modifiedBy, IT.modifiedDate as modifiedDate, IT.submittedDate AS submittedDate,  IT.submissionStatus as submissionStatus, IT.approvalStatus as approvalStatus," + 
	            		"IT.approvalDate as approvalDate, IT.validatedDate as validatedDate, IT.acknowledgedDate as acknowledgedDate, IT.travelDeskClosureStatus as travelDeskClosureStatus, IT.reasonForCancellation as reasonForCancellation, IT.cancelledDate as cancelledDate, IT.closedDate as closedDate, IT.recovery as recovery, IT.recoveryComments as recoveryComments, IT.isMigrated as isMigrated, IT.projectMigrated as projectMigrated, IT.isGuest as isGuest, IT.costSavingAmount as costSavingAmount, IT.cancellationCost as cancellationCost, IT.reissueCost as reissueCost, rr.title as projectManagerName, p.title as projectName, u.unitName as unitName, un.unitName as associateUnitName, unt.unitName as invoiceUnitName, rs.title as associateName FROM  " + LoadConstant.otc + ".[dbo].[infoTravel] IT " + 
	            		"  left join " + LoadConstant.infomaster + ".[dbo].[resource] rr on rr.uid=IT.approverId " +
	            		"  left join " + LoadConstant.infomaster + ".[dbo].[resource] rs on rs.uid=IT.uid " +
	            		"  left join " + LoadConstant.infomaster + " .[dbo].[project] p on p.itemId = IT.projectId "+
	            		" left join " + LoadConstant.infomaster + " .[dbo].[unit] u on u.unitId = IT.unit " +
	            		" left join " + LoadConstant.infomaster + " .[dbo].[unit] un on un.unitId = IT.associateUnit " +
	            		" left join " + LoadConstant.infomaster + " .[dbo].[unit] unt on unt.unitId = IT.invoiceUnit " +
	            		"where IT.approverId = :uid order by IT.infoTravelId desc",
	                      resultClass=InfoTravel.class, resultSetMapping = "get_infotravel"
	   ),
	   @NamedNativeQuery (
			   name    =   "getInfoTravel_financeSubmission",
	            query   =   "SELECT IT.infoTravelId as infoTravelId, IT.tourCode as tourCode, IT.uid as uid, IT.travelType as travelType,   IT.travelWay as travelWay, IT.travelMode as travelMode, " + 
	            		"IT.returnDate as returnDate, IT.adultCount as adultCount, IT.childCount as childCount, IT.infantCount as infantCount, IT.unit as unit, IT.associateUnit as associateUnit, IT.invoiceUnit as invoiceUnit, IT.projectId as  projectId, IT.pmName as pmName, IT.approverId as  approverId, IT.financeId as financeId, IT.typeOfTravel as typeOfTravel, " + 
	            		"IT.travelPurpose as travelPurpose, IT.travelCost as travelCost, IT.nomineeName as nomineeName, IT.nomineeRelation as nomineeRelation, IT.emergencyContact as emergencyContact, IT.visaCategory as visaCategory, IT.visaRequired as visaRequired, IT.accomodation as accomodation,IT.checkin as checkin, " + 
	            		"IT.checkout as checkout, IT.address as address, IT.travellerDoc as travellerDoc, IT.travellerRemarks as travellerRemarks, IT.approvalRemarks as approvalRemarks, IT.travelDeskClosureRemarks as travelDeskClosureRemarks, IT.rating as rating, IT.ratingComments as ratingComments," + 
	            		"IT.createdDate as createdDate, IT.modifiedBy as modifiedBy, IT.modifiedDate as modifiedDate, IT.submittedDate AS submittedDate,  IT.submissionStatus as submissionStatus, IT.approvalStatus as approvalStatus," + 
	            		"IT.approvalDate as approvalDate, IT.validatedDate as validatedDate, IT.acknowledgedDate as acknowledgedDate, IT.travelDeskClosureStatus as travelDeskClosureStatus, IT.reasonForCancellation as reasonForCancellation, IT.cancelledDate as cancelledDate, IT.closedDate as closedDate, IT.recovery as recovery, IT.recoveryComments as recoveryComments, IT.isMigrated as isMigrated, IT.projectMigrated as projectMigrated, IT.isGuest as isGuest, IT.costSavingAmount as costSavingAmount, IT.cancellationCost as cancellationCost, IT.reissueCost as reissueCost, rr.title as projectManagerName, p.title as projectName, u.unitName as unitName, un.unitName as associateUnitName, unt.unitName as invoiceUnitName, rs.title as associateName FROM  " + LoadConstant.otc + ".[dbo].[infoTravel] IT " + 
	            		"  left join " + LoadConstant.infomaster + ".[dbo].[resource] rr on rr.uid=IT.approverId " +
	            		"  left join " + LoadConstant.infomaster + ".[dbo].[resource] rs on rs.uid=IT.uid " +
	            		"  left join " + LoadConstant.infomaster + " .[dbo].[project] p on p.itemId = IT.projectId "+
	            		" left join " + LoadConstant.infomaster + " .[dbo].[unit] u on u.unitId = IT.unit " +
	            		" left join " + LoadConstant.infomaster + " .[dbo].[unit] un on un.unitId = IT.associateUnit " +
	            		" left join " + LoadConstant.infomaster + " .[dbo].[unit] unt on unt.unitId = IT.invoiceUnit " +
	            		"where IT.submissionStatus >= 4 and IT.submissionStatus != 5 order by IT.infoTravelId desc",
	                      resultClass=InfoTravel.class, resultSetMapping = "get_infotravel"
	   ),
	   @NamedNativeQuery (
			   name    =   "getInfoTravel_travelTeam",
	            query   =   "SELECT IT.infoTravelId as infoTravelId, IT.tourCode as tourCode, IT.uid as uid, IT.travelType as travelType,   IT.travelWay as travelWay, IT.travelMode as travelMode, " + 
	            		"IT.returnDate as returnDate, IT.adultCount as adultCount, IT.childCount as childCount, IT.infantCount as infantCount, IT.unit as unit, IT.associateUnit as associateUnit, IT.invoiceUnit as invoiceUnit, IT.projectId as  projectId, IT.pmName as pmName, IT.approverId as  approverId, IT.financeId as financeId, IT.typeOfTravel as typeOfTravel, " + 
	            		"IT.travelPurpose as travelPurpose, IT.travelCost as travelCost, IT.nomineeName as nomineeName, IT.nomineeRelation as nomineeRelation, IT.emergencyContact as emergencyContact, IT.visaCategory as visaCategory, IT.visaRequired as visaRequired, IT.accomodation as accomodation,IT.checkin as checkin, " + 
	            		"IT.checkout as checkout, IT.address as address, IT.travellerDoc as travellerDoc, IT.travellerRemarks as travellerRemarks, IT.approvalRemarks as approvalRemarks, IT.travelDeskClosureRemarks as travelDeskClosureRemarks, IT.rating as rating, IT.ratingComments as ratingComments, " + 
	            		"IT.createdDate as createdDate, IT.modifiedBy as modifiedBy, IT.modifiedDate as modifiedDate, IT.submittedDate AS submittedDate,  IT.submissionStatus as submissionStatus, IT.approvalStatus as approvalStatus," + 
	            		"IT.approvalDate as approvalDate, IT.validatedDate as validatedDate, IT.acknowledgedDate as acknowledgedDate, IT.travelDeskClosureStatus as travelDeskClosureStatus, IT.reasonForCancellation as reasonForCancellation, IT.cancelledDate as cancelledDate, IT.closedDate as closedDate, IT.recovery as recovery, IT.recoveryComments as recoveryComments, IT.isMigrated as isMigrated, IT.projectMigrated as projectMigrated, IT.isGuest as isGuest, IT.costSavingAmount as costSavingAmount, IT.cancellationCost as cancellationCost, IT.reissueCost as reissueCost, rr.title as projectManagerName, p.title as projectName, u.unitName as unitName, un.unitName as associateUnitName, unt.unitName as invoiceUnitName, rs.title as associateName FROM  " + LoadConstant.otc + ".[dbo].[infoTravel] IT " + 
	            		"  left join " + LoadConstant.infomaster + ".[dbo].[resource] rr on rr.uid=IT.approverId " +
	            		"  left join " + LoadConstant.infomaster + ".[dbo].[resource] rs on rs.uid=IT.uid " +
	            		"  left join " + LoadConstant.infomaster + " .[dbo].[project] p on p.itemId = IT.projectId "+
	            		" left join " + LoadConstant.infomaster + " .[dbo].[unit] u on u.unitId = IT.unit " +
	            		" left join " + LoadConstant.infomaster + " .[dbo].[unit] un on un.unitId = IT.associateUnit " +
	            		" left join " + LoadConstant.infomaster + " .[dbo].[unit] unt on unt.unitId = IT.invoiceUnit " +
	            		"where IT.submissionStatus >= 6 order by IT.infoTravelId desc",
	                      resultClass=InfoTravel.class, resultSetMapping = "get_infotravel"
	   ),
	   @NamedNativeQuery (
			   name    =   "getInfoTravel_submittedRequest",
	            query   =   "SELECT IT.infoTravelId as infoTravelId, IT.tourCode as tourCode, IT.uid as uid, IT.travelType as travelType,   IT.travelWay as travelWay, IT.travelMode as travelMode, " + 
	            		"IT.returnDate as returnDate, IT.adultCount as adultCount, IT.childCount as childCount, IT.infantCount as infantCount, IT.unit as unit, IT.associateUnit as associateUnit, IT.invoiceUnit as invoiceUnit, IT.projectId as  projectId, IT.pmName as pmName, IT.approverId as  approverId, IT.financeId as financeId, IT.typeOfTravel as typeOfTravel, " + 
	            		"IT.travelPurpose as travelPurpose, IT.travelCost as travelCost, IT.nomineeName as nomineeName, IT.nomineeRelation as nomineeRelation, IT.emergencyContact as emergencyContact, IT.visaCategory as visaCategory, IT.visaRequired as visaRequired, IT.accomodation as accomodation,IT.checkin as checkin, " + 
	            		"IT.checkout as checkout, IT.address as address, IT.travellerDoc as travellerDoc, IT.travellerRemarks as travellerRemarks, IT.approvalRemarks as approvalRemarks, IT.travelDeskClosureRemarks as travelDeskClosureRemarks, IT.rating as rating, IT.ratingComments as ratingComments, " + 
	            		"IT.createdDate as createdDate, IT.modifiedBy as modifiedBy, IT.modifiedDate as modifiedDate, IT.submittedDate AS submittedDate,  IT.submissionStatus as submissionStatus, IT.approvalStatus as approvalStatus," + 
	            		"IT.approvalDate as approvalDate, IT.validatedDate as validatedDate,  IT.acknowledgedDate as acknowledgedDate, IT.travelDeskClosureStatus as travelDeskClosureStatus, IT.reasonForCancellation as reasonForCancellation, IT.cancelledDate as cancelledDate, IT.closedDate as closedDate, IT.recovery as recovery, IT.recoveryComments as recoveryComments, IT.isMigrated as isMigrated, IT.projectMigrated as projectMigrated, IT.isGuest as isGuest, IT.costSavingAmount as costSavingAmount, IT.cancellationCost as cancellationCost, IT.reissueCost as reissueCost, rr.title as projectManagerName, p.title as projectName, u.unitName as unitName, un.unitName as associateUnitName, unt.unitName as invoiceUnitName, rs.title as associateName FROM  " + LoadConstant.otc + ".[dbo].[infoTravel] IT " + 
	            		"  left join " + LoadConstant.infomaster + ".[dbo].[resource] rr on rr.uid=IT.approverId " +
	            		"  left join " + LoadConstant.infomaster + ".[dbo].[resource] rs on rs.uid=IT.uid " +
	            		"  left join " + LoadConstant.infomaster + " .[dbo].[project] p on p.itemId = IT.projectId "+
	            		" left join " + LoadConstant.infomaster + " .[dbo].[unit] u on u.unitId = IT.unit " +
	            		" left join " + LoadConstant.infomaster + " .[dbo].[unit] un on un.unitId = IT.associateUnit " +
	            		" left join " + LoadConstant.infomaster + " .[dbo].[unit] unt on unt.unitId = IT.invoiceUnit " +
	            		"where IT.submissionStatus = :submissionStatus order by IT.infoTravelId desc",
	                      resultClass=InfoTravel.class, resultSetMapping = "get_infotravel"
	   ),
	   @NamedNativeQuery (
			   name    =   "fetchAllInfoTravel",
	            query   =   "SELECT IT.infoTravelId as infoTravelId, IT.tourCode as tourCode, IT.uid as uid, IT.travelType as travelType,   IT.travelWay as travelWay, IT.travelMode as travelMode, " + 
	            		"IT.returnDate as returnDate, IT.adultCount as adultCount, IT.childCount as childCount, IT.infantCount as infantCount, IT.unit as unit, IT.associateUnit as associateUnit, IT.invoiceUnit as invoiceUnit, IT.projectId as  projectId, IT.pmName as pmName, IT.approverId as  approverId, IT.financeId as financeId, IT.typeOfTravel as typeOfTravel, " + 
	            		"IT.travelPurpose as travelPurpose, IT.travelCost as travelCost, IT.nomineeName as nomineeName, IT.nomineeRelation as nomineeRelation, IT.emergencyContact as emergencyContact, IT.visaCategory as visaCategory, IT.visaRequired as visaRequired, IT.accomodation as accomodation,IT.checkin as checkin, " + 
	            		"IT.checkout as checkout, IT.address as address, IT.travellerDoc as travellerDoc, IT.travellerRemarks as travellerRemarks, IT.approvalRemarks as approvalRemarks, IT.travelDeskClosureRemarks as travelDeskClosureRemarks, IT.rating as rating, IT.ratingComments as ratingComments," + 
	            		"IT.createdDate as createdDate, IT.modifiedBy as modifiedBy, IT.modifiedDate as modifiedDate,IT.submittedDate AS submittedDate, IT.submissionStatus as submissionStatus, IT.approvalStatus as approvalStatus," + 
	            		"IT.approvalDate as approvalDate, IT.validatedDate as validatedDate, IT.acknowledgedDate as acknowledgedDate, IT.travelDeskClosureStatus as travelDeskClosureStatus, IT.reasonForCancellation as reasonForCancellation, IT.cancelledDate as cancelledDate, IT.closedDate as closedDate, IT.recovery as recovery, IT.recoveryComments as recoveryComments, IT.isMigrated as isMigrated, IT.projectMigrated as projectMigrated, IT.isGuest as isGuest, IT.costSavingAmount as costSavingAmount, IT.cancellationCost as cancellationCost, IT.reissueCost as reissueCost, rr.title as projectManagerName, p.title as projectName, u.unitName as unitName, un.unitName as associateUnitName, unt.unitName as invoiceUnitName, rs.title as associateName, itd.origin as origin, itd.destination as destination, itd.departureDate as departureDate, itr.givenName as givenName, itr.surname as surname, itr.dob as dob, itr.gender as gender, itr.mobileOrigin as mobileOrigin, itr.mobileDestination as mobileDestination, itr.passportNo as passportNo, itr.nationality as nationality, itr.empId as empId, itr.seat as seat, itr.email as email, itr.alternateEmail as alternateEmail, itr.meal as meal, itr.frequentFlyerNo as frequentFlyerNo, itr. airline as airline, td.infoTravelDeskId as infoTravelDeskId, td.requestDate as requestDate, td.transactionDate as transactionDate,td.location as location,td.sector as sector,td.service as service,td.serviceType as serviceType, td.onwardDate as onwardDate, td.returnDate as returnDateTravel, td.serviceProvider as serviceProvider, td.confirmationNo as confirmationNo,td.ticketNo as ticketNo, td.remarks as remarks, td.confirmedCost as confirmedCost, td.highestCost as highestCost, td.lowestCost as lowestCost, td.recovery as recoveryTravel, td.vendor as vendor, td.exceptionalApproval as exceptionalApproval, td.reasonForExceptionalApproval as reasonForExceptionalApproval,  td.reissueService as reissueService, td.reissueCost as reissueCostTravel, td.cancellationCost as cancellationCostTravel, td.cancellationApprover as cancellationApprover, td.reasonForChange as reasonForChange, td.cancellationReasonForChange as cancellationReasonForChange, td.cancellationStatus as cancellationStatus, td.invoiceDate as invoiceDate, td.invoiceNo as invoiceNo,td.basicFare as basicFare, td.yQTax as yQTax, td.others as others, td.discount as discount, td.agentFee as agentFee, td.sGST as sGST,td.cGST as cGST, td.iGST as iGST, td.invoiceAmount as invoiceAmount, td.invoiceStatus as invoiceStatus,g1.grade as associateGrade,g2.grade as approverGrade,"+
	            		"(select top 1 grade from  " + LoadConstant.otc + ".[dbo].[infoTravel] ITP " + 
	            		" left join " + LoadConstant.infomaster + ".[dbo].[resource] rp on rp.title=ITP.pmName" + 
	            		" left join " + LoadConstant.infomaster + ".[dbo].[grade] gpm on gpm.gradeId=rp.gradeId" + 
	            		" where rp.title=IT.pmName ) as managerGrade, "+
	            		" g3.grade as validatorGrade, rm.title as modifiedName, ra.title as validatorName, rm.empId as managerEmpId, rr.empId as approverEmpId, ra.empId as validatorEmpId FROM  " + LoadConstant.otc + ".[dbo].[infoTravel] IT " +
	            		"  left join " + LoadConstant.infomaster + ".[dbo].[resource] rr on rr.uid=IT.approverId " +
	            		"  left join " + LoadConstant.infomaster + ".[dbo].[resource] rs on rs.uid=IT.uid " +
	    	            "  left join " + LoadConstant.infomaster + " .[dbo].[project] p on p.itemId = IT.projectId " +
	    	            " left join " + LoadConstant.infomaster + " .[dbo].[unit] u on u.unitId = IT.unit " +
	    	            " left join " + LoadConstant.infomaster + " .[dbo].[unit] un on un.unitId = IT.associateUnit " +
	            		" left join " + LoadConstant.infomaster + " .[dbo].[unit] unt on unt.unitId = IT.invoiceUnit" +
	    	            " left join " + LoadConstant.otc + ".[dbo].[infoTravelDetail] itd on itd.infoTravelId = iT.infoTravelId "+
	    	            " left join " + LoadConstant.otc + ".[dbo].[infoTraveller] itr on itr.infoTravelId = iT.infoTravelId "+
	    	            " left join " + LoadConstant.otc + ".[dbo].[infoTravelDesk] td on td.infoTravelId = iT.infoTravelId "+
	            		"  left join " + LoadConstant.infomaster + ".[dbo].[resource] ra on ra.uid=IT.financeId " +
	            		" left join " + LoadConstant.infomaster + " .[dbo].[grade] g1 on g1.gradeId = rs.gradeId "+
	            		" left join " + LoadConstant.infomaster + " .[dbo].[grade] g2 on g2.gradeId = rr.gradeId "+
	            		" left join " + LoadConstant.infomaster + " .[dbo].[grade] g3 on g3.gradeId = ra.gradeId "+
	            		"  left join " + LoadConstant.infomaster + ".[dbo].[resource] rm on rm.uid=IT.modifiedBy " +
	            		" where IT.submissionStatus > 1 order by IT.infoTravelId desc" ,
	                      resultClass=InfoTravel.class, resultSetMapping = "get_Allinfotravel"
	   )
    
})
public class InfoTravel {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer infoTravelId;
	private String tourCode;
	
	//travel details section
	private Integer uid;
	private String travelType;
	private String travelWay;
	private String travelMode;
	private Date returnDate;
	private Integer adultCount;
	private Integer childCount;
	private Integer infantCount;

	//travel checklist section
	private Integer unit;
	private Integer associateUnit;
	private Integer invoiceUnit;
	private Integer projectId;
	private String pmName;
	private Integer approverId;
	private Integer financeId;
	private String typeOfTravel;
	private String travelPurpose;
	private String travelCost;
	
	//Nominee Details Section
	private String nomineeName;
	private String nomineeRelation;
	private String emergencyContact;
	
	//Visa Details Section
	private String visaRequired;
	private String visaCategory;
	
	//Accomodation Section
	private String accomodation;
	private Date checkin;
	private Date checkout;
	
	@Lob
	private String address;
	
	//Attachments Section
	@Lob
	private String travellerDoc;
	
	//Remarks Section
	@Lob
	private String travellerRemarks;
	
	@Lob
	private String approvalRemarks;
	
	@Lob
	private String travelDeskClosureRemarks;
	
	//Ratings Feedback
		private Integer rating;
		
		@Lob
		private String ratingComments;
	
	//audit trail columns	
	private Date createdDate;
	private Integer modifiedBy;
	private Date modifiedDate;
	private Date submittedDate;
	
	//other columns
	private Integer submissionStatus;
	private Integer approvalStatus;
	private Date approvalDate;
	private Date validatedDate;
	private Date acknowledgedDate;
	private Integer travelDeskClosureStatus;
	private String reasonForCancellation;
	private Date cancelledDate;
	private Date closedDate;
	private String recovery;
	private String recoveryComments;
	private Boolean isMigrated;
	private String projectMigrated;
	private Boolean isGuest;
	
	@Column(precision=12,scale=2)
	private BigDecimal costSavingAmount;
	
	@Column(precision=12,scale=2)
	private BigDecimal cancellationCost;
	
	@Column(precision=12,scale=2)
	private BigDecimal reissueCost;
	
	@Transient
	private String projectManagerName;
	
	@Transient
	private String projectName;
	
	@Transient
	private String unitName;
	
	@Transient
	private String associateName;
	
	@Transient
	private String associateUnitName;
	
	@Transient
	private String invoiceUnitName;
	
	//to get export info travel detail
	
	@Transient
	private String origin;
	
	@Transient
	private String destination;
	
	@Transient
	private Date departureDate;
	
	//to get export info traveller
	
	@Transient
	private String givenName;
	
	@Transient
	private String surname;
	
	@Transient
	private Date dob;
	
	@Transient
	private String gender;
	
	@Transient
	private String mobileOrigin;
	
	@Transient
	private String mobileDestination;
	
	@Transient
	private String passportNo;
	
	@Transient
	private String nationality;
	
	@Transient
	private Integer empId;
	
	@Transient
	private String seat;
	
	@Transient
	private String email;
	
	@Transient
	private String alternateEmail;
	
	@Transient
	private String meal;
	
	@Transient
	private String frequentFlyerNo;
	
	@Transient
	private String airline;
	
	//to get export info traveller
	@Transient
	private Integer infoTravelDeskId;
	
	@Transient
	private Date requestDate;	

	@Transient
	private Date transactionDate;

	@Transient
	private String location;	
	
	@Transient
	private String sector;

	@Transient
	private String service;
	
	@Transient
	private String serviceType;

	@Transient
	private Date onwardDate;

	@Transient
	private Date returnDateTravel;

	@Transient
	private String serviceProvider;

	@Transient
	private String confirmationNo;
	
	@Transient
	private String ticketNo;

	@Transient
	private String remarks;

	@Transient
	private BigDecimal confirmedCost;
	
	@Transient
	private BigDecimal highestCost;

	@Transient
	private BigDecimal lowestCost;

	@Transient
	private BigDecimal recoveryTravel;

	@Transient
	private String vendor;

	@Transient
	private Integer exceptionalApproval;

	@Transient
	private String reasonForExceptionalApproval;

	@Transient
	private String reissueService;
	
	@Transient
	private BigDecimal reissueCostTravel;

	@Transient
	private BigDecimal cancellationCostTravel;
	
	@Transient
	private Integer cancellationApprover;
	
	@Transient
	private String reasonForChange;
	
	@Transient
	private String cancellationReasonForChange;
	
	@Transient
	private String cancellationStatus;
	
	@Transient
	private Date invoiceDate;
	
	@Transient
	private String invoiceNo;
	
	@Transient
	private BigDecimal basicFare;

	@Transient
	private BigDecimal yQTax;

	@Transient
	private BigDecimal others;

	@Transient
	private BigDecimal discount;

	@Transient
	private BigDecimal agentFee;

	@Transient
	private BigDecimal sGST;

	@Transient
	private BigDecimal cGST;

	@Transient
	private BigDecimal iGST;

	@Transient
	private BigDecimal invoiceAmount;
	
	@Transient
	private String invoiceStatus;
	
	
	@Transient
	private String associateGrade;
	
	@Transient
	private String approverGrade;
	
	@Transient
	private String managerGrade;
	
	@Transient
	private String validatorGrade;
	
	@Transient
	private String modifiedName;
	
	@Transient
	private String validatorName;
	
	@Transient
	private Integer managerEmpId;
	
	@Transient
	private Integer approverEmpId;
	
	@Transient
	private Integer validatorEmpId;
	
	
	//Getter and Setter
	
	
	public Integer getInfoTravelId() {
		return infoTravelId;
	}


	public void setInfoTravelId(Integer infoTravelId) {
		this.infoTravelId = infoTravelId;
	}


	public String getTourCode() {
		return tourCode;
	}


	public void setTourCode(String tourCode) {
		this.tourCode = tourCode;
	}


	public Integer getUid() {
		return uid;
	}


	public void setUid(Integer uid) {
		this.uid = uid;
	}


	public String getTravelType() {
		return travelType;
	}


	public void setTravelType(String travelType) {
		this.travelType = travelType;
	}


	public String getTravelWay() {
		return travelWay;
	}


	public void setTravelWay(String travelWay) {
		this.travelWay = travelWay;
	}


	public String getTravelMode() {
		return travelMode;
	}


	public void setTravelMode(String travelMode) {
		this.travelMode = travelMode;
	}


	public Date getReturnDate() {
		return returnDate;
	}


	public void setReturnDate(Date returnDate) {
		this.returnDate = returnDate;
	}


	public Integer getAdultCount() {
		return adultCount;
	}


	public void setAdultCount(Integer adultCount) {
		this.adultCount = adultCount;
	}


	public Integer getChildCount() {
		return childCount;
	}


	public void setChildCount(Integer childCount) {
		this.childCount = childCount;
	}


	public Integer getInfantCount() {
		return infantCount;
	}


	public void setInfantCount(Integer infantCount) {
		this.infantCount = infantCount;
	}


	public Integer getUnit() {
		return unit;
	}


	public void setUnit(Integer unit) {
		this.unit = unit;
	}


	public Integer getAssociateUnit() {
		return associateUnit;
	}


	public void setAssociateUnit(Integer associateUnit) {
		this.associateUnit = associateUnit;
	}


	public Integer getInvoiceUnit() {
		return invoiceUnit;
	}


	public void setInvoiceUnit(Integer invoiceUnit) {
		this.invoiceUnit = invoiceUnit;
	}


	public Integer getProjectId() {
		return projectId;
	}


	public void setProjectId(Integer projectId) {
		this.projectId = projectId;
	}


	public String getPmName() {
		return pmName;
	}


	public void setPmName(String pmName) {
		this.pmName = pmName;
	}


	public Integer getApproverId() {
		return approverId;
	}


	public void setApproverId(Integer approverId) {
		this.approverId = approverId;
	}


	public Integer getFinanceId() {
		return financeId;
	}


	public void setFinanceId(Integer financeId) {
		this.financeId = financeId;
	}


	public String getTypeOfTravel() {
		return typeOfTravel;
	}


	public void setTypeOfTravel(String typeOfTravel) {
		this.typeOfTravel = typeOfTravel;
	}


	public String getTravelPurpose() {
		return travelPurpose;
	}


	public void setTravelPurpose(String travelPurpose) {
		this.travelPurpose = travelPurpose;
	}


	public String getTravelCost() {
		return travelCost;
	}


	public void setTravelCost(String travelCost) {
		this.travelCost = travelCost;
	}


	public String getNomineeName() {
		return nomineeName;
	}


	public void setNomineeName(String nomineeName) {
		this.nomineeName = nomineeName;
	}


	public String getNomineeRelation() {
		return nomineeRelation;
	}


	public void setNomineeRelation(String nomineeRelation) {
		this.nomineeRelation = nomineeRelation;
	}

	

	public String getEmergencyContact() {
		return emergencyContact;
	}


	public void setEmergencyContact(String emergencyContact) {
		this.emergencyContact = emergencyContact;
	}


	public String getVisaRequired() {
		return visaRequired;
	}


	public void setVisaRequired(String visaRequired) {
		this.visaRequired = visaRequired;
	}


	public String getVisaCategory() {
		return visaCategory;
	}


	public void setVisaCategory(String visaCategory) {
		this.visaCategory = visaCategory;
	}


	public String getAccomodation() {
		return accomodation;
	}


	public void setAccomodation(String accomodation) {
		this.accomodation = accomodation;
	}


	public Date getCheckin() {
		return checkin;
	}


	public void setCheckin(Date checkin) {
		this.checkin = checkin;
	}


	public Date getCheckout() {
		return checkout;
	}


	public void setCheckout(Date checkout) {
		this.checkout = checkout;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}


	public String getTravellerDoc() {
		return travellerDoc;
	}


	public void setTravellerDoc(String travellerDoc) {
		this.travellerDoc = travellerDoc;
	}


	public String getTravellerRemarks() {
		return travellerRemarks;
	}


	public void setTravellerRemarks(String travellerRemarks) {
		this.travellerRemarks = travellerRemarks;
	}


	public String getApprovalRemarks() {
		return approvalRemarks;
	}


	public void setApprovalRemarks(String approvalRemarks) {
		this.approvalRemarks = approvalRemarks;
	}


	public String getTravelDeskClosureRemarks() {
		return travelDeskClosureRemarks;
	}


	public void setTravelDeskClosureRemarks(String travelDeskClosureRemarks) {
		this.travelDeskClosureRemarks = travelDeskClosureRemarks;
	}


	public Integer getRating() {
		return rating;
	}


	public void setRating(Integer rating) {
		this.rating = rating;
	}


	public String getRatingComments() {
		return ratingComments;
	}


	public void setRatingComments(String ratingComments) {
		this.ratingComments = ratingComments;
	}


	public Date getCreatedDate() {
		return createdDate;
	}


	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}


	public Integer getModifiedBy() {
		return modifiedBy;
	}


	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}


	public Date getModifiedDate() {
		return modifiedDate;
	}


	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}


	public Date getSubmittedDate() {
		return submittedDate;
	}


	public void setSubmittedDate(Date submittedDate) {
		this.submittedDate = submittedDate;
	}


	public Integer getSubmissionStatus() {
		return submissionStatus;
	}


	public void setSubmissionStatus(Integer submissionStatus) {
		this.submissionStatus = submissionStatus;
	}


	public Integer getApprovalStatus() {
		return approvalStatus;
	}


	public void setApprovalStatus(Integer approvalStatus) {
		this.approvalStatus = approvalStatus;
	}


	public Date getApprovalDate() {
		return approvalDate;
	}


	public void setApprovalDate(Date approvalDate) {
		this.approvalDate = approvalDate;
	}

	
	

	public Date getValidatedDate() {
		return validatedDate;
	}


	public void setValidatedDate(Date validatedDate) {
		this.validatedDate = validatedDate;
	}


	public Date getAcknowledgedDate() {
		return acknowledgedDate;
	}


	public void setAcknowledgedDate(Date acknowledgedDate) {
		this.acknowledgedDate = acknowledgedDate;
	}


	public Integer getTravelDeskClosureStatus() {
		return travelDeskClosureStatus;
	}


	public void setTravelDeskClosureStatus(Integer travelDeskClosureStatus) {
		this.travelDeskClosureStatus = travelDeskClosureStatus;
	}


	public String getReasonForCancellation() {
		return reasonForCancellation;
	}


	public void setReasonForCancellation(String reasonForCancellation) {
		this.reasonForCancellation = reasonForCancellation;
	}


	public Date getCancelledDate() {
		return cancelledDate;
	}


	public void setCancelledDate(Date cancelledDate) {
		this.cancelledDate = cancelledDate;
	}


	public Date getClosedDate() {
		return closedDate;
	}


	public void setClosedDate(Date closedDate) {
		this.closedDate = closedDate;
	}


	public String getRecovery() {
		return recovery;
	}


	public void setRecovery(String recovery) {
		this.recovery = recovery;
	}


	public String getRecoveryComments() {
		return recoveryComments;
	}


	public void setRecoveryComments(String recoveryComments) {
		this.recoveryComments = recoveryComments;
	}
	
	
	public Boolean getIsMigrated() {
		return isMigrated;
	}


	public void setIsMigrated(Boolean isMigrated) {
		this.isMigrated = isMigrated;
	}
	
	public String getProjectMigrated() {
		return projectMigrated;
	}


	public void setProjectMigrated(String projectMigrated) {
		this.projectMigrated = projectMigrated;
	}	


	public Boolean getIsGuest() {
		return isGuest;
	}


	public void setIsGuest(Boolean isGuest) {
		this.isGuest = isGuest;
	}


	public BigDecimal getCostSavingAmount() {
		return costSavingAmount;
	}


	public void setCostSavingAmount(BigDecimal costSavingAmount) {
		this.costSavingAmount = costSavingAmount;
	}


	public BigDecimal getCancellationCost() {
		return cancellationCost;
	}


	public void setCancellationCost(BigDecimal cancellationCost) {
		this.cancellationCost = cancellationCost;
	}


	public BigDecimal getReissueCost() {
		return reissueCost;
	}


	public void setReissueCost(BigDecimal reissueCost) {
		this.reissueCost = reissueCost;
	}


	public String getProjectManagerName() {
		return projectManagerName;
	}


	public void setProjectManagerName(String projectManagerName) {
		this.projectManagerName = projectManagerName;
	}


	public String getProjectName() {
		return projectName;
	}


	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}


	public String getUnitName() {
		return unitName;
	}


	public void setUnitName(String unitName) {
		this.unitName = unitName;
	}


	public String getAssociateName() {
		return associateName;
	}


	public void setAssociateName(String associateName) {
		this.associateName = associateName;
	}


	public String getAssociateUnitName() {
		return associateUnitName;
	}


	public void setAssociateUnitName(String associateUnitName) {
		this.associateUnitName = associateUnitName;
	}


	public String getInvoiceUnitName() {
		return invoiceUnitName;
	}


	public void setInvoiceUnitName(String invoiceUnitName) {
		this.invoiceUnitName = invoiceUnitName;
	}
	
	public String getOrigin() {
		return origin;
	}


	public void setOrigin(String origin) {
		this.origin = origin;
	}


	public String getDestination() {
		return destination;
	}


	public void setDestination(String destination) {
		this.destination = destination;
	}


	public Date getDepartureDate() {
		return departureDate;
	}


	public void setDepartureDate(Date departureDate) {
		this.departureDate = departureDate;
	}

	

		public String getGivenName() {
		return givenName;
	}


	public void setGivenName(String givenName) {
		this.givenName = givenName;
	}


	public String getSurname() {
		return surname;
	}


	public void setSurname(String surname) {
		this.surname = surname;
	}


	public Date getDob() {
		return dob;
	}


	public void setDob(Date dob) {
		this.dob = dob;
	}


	public String getGender() {
		return gender;
	}


	public void setGender(String gender) {
		this.gender = gender;
	}


	public String getMobileOrigin() {
		return mobileOrigin;
	}


	public void setMobileOrigin(String mobileOrigin) {
		this.mobileOrigin = mobileOrigin;
	}


	public String getMobileDestination() {
		return mobileDestination;
	}


	public void setMobileDestination(String mobileDestination) {
		this.mobileDestination = mobileDestination;
	}


	public String getPassportNo() {
		return passportNo;
	}


	public void setPassportNo(String passportNo) {
		this.passportNo = passportNo;
	}


	public String getNationality() {
		return nationality;
	}


	public void setNationality(String nationality) {
		this.nationality = nationality;
	}


	public Integer getEmpId() {
		return empId;
	}


	public void setEmpId(Integer empId) {
		this.empId = empId;
	}


	public String getSeat() {
		return seat;
	}


	public void setSeat(String seat) {
		this.seat = seat;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getAlternateEmail() {
		return alternateEmail;
	}


	public void setAlternateEmail(String alternateEmail) {
		this.alternateEmail = alternateEmail;
	}


	public String getMeal() {
		return meal;
	}


	public void setMeal(String meal) {
		this.meal = meal;
	}


	public String getFrequentFlyerNo() {
		return frequentFlyerNo;
	}


	public void setFrequentFlyerNo(String frequentFlyerNo) {
		this.frequentFlyerNo = frequentFlyerNo;
	}


	public String getAirline() {
		return airline;
	}


	public void setAirline(String airline) {
		this.airline = airline;
	}
	

	
		public Integer getInfoTravelDeskId() {
		return infoTravelDeskId;
	}


	public void setInfoTravelDeskId(Integer infoTravelDeskId) {
		this.infoTravelDeskId = infoTravelDeskId;
	}


		public Date getRequestDate() {
		return requestDate;
	}


	public void setRequestDate(Date requestDate) {
		this.requestDate = requestDate;
	}


	public Date getTransactionDate() {
		return transactionDate;
	}


	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = transactionDate;
	}


	public String getLocation() {
		return location;
	}


	public void setLocation(String location) {
		this.location = location;
	}


	public String getSector() {
		return sector;
	}


	public void setSector(String sector) {
		this.sector = sector;
	}


	public String getService() {
		return service;
	}


	public void setService(String service) {
		this.service = service;
	}


	public String getServiceType() {
		return serviceType;
	}


	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}


	public Date getOnwardDate() {
		return onwardDate;
	}


	public void setOnwardDate(Date onwardDate) {
		this.onwardDate = onwardDate;
	}
	

	public Date getReturnDateTravel() {
		return returnDateTravel;
	}


	public void setReturnDateTravel(Date returnDateTravel) {
		this.returnDateTravel = returnDateTravel;
	}


	public String getServiceProvider() {
		return serviceProvider;
	}


	public void setServiceProvider(String serviceProvider) {
		this.serviceProvider = serviceProvider;
	}


	public String getConfirmationNo() {
		return confirmationNo;
	}


	public void setConfirmationNo(String confirmationNo) {
		this.confirmationNo = confirmationNo;
	}


	public String getTicketNo() {
		return ticketNo;
	}


	public void setTicketNo(String ticketNo) {
		this.ticketNo = ticketNo;
	}


	public String getRemarks() {
		return remarks;
	}


	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}


	public BigDecimal getConfirmedCost() {
		return confirmedCost;
	}


	public void setConfirmedCost(BigDecimal confirmedCost) {
		this.confirmedCost = confirmedCost;
	}
	

	public BigDecimal getHighestCost() {
		return highestCost;
	}


	public void setHighestCost(BigDecimal highestCost) {
		this.highestCost = highestCost;
	}


	public BigDecimal getLowestCost() {
		return lowestCost;
	}


	public void setLowestCost(BigDecimal lowestCost) {
		this.lowestCost = lowestCost;
	}


	public BigDecimal getRecoveryTravel() {
		return recoveryTravel;
	}


	public void setRecoveryTravel(BigDecimal recoveryTravel) {
		this.recoveryTravel = recoveryTravel;
	}


	public String getVendor() {
		return vendor;
	}


	public void setVendor(String vendor) {
		this.vendor = vendor;
	}


	public Integer getExceptionalApproval() {
		return exceptionalApproval;
	}


	public void setExceptionalApproval(Integer exceptionalApproval) {
		this.exceptionalApproval = exceptionalApproval;
	}


	public String getReasonForExceptionalApproval() {
		return reasonForExceptionalApproval;
	}


	public void setReasonForExceptionalApproval(String reasonForExceptionalApproval) {
		this.reasonForExceptionalApproval = reasonForExceptionalApproval;
	}


	public String getReissueService() {
		return reissueService;
	}


	public void setReissueService(String reissueService) {
		this.reissueService = reissueService;
	}


	public BigDecimal getReissueCostTravel() {
		return reissueCostTravel;
	}


	public void setReissueCostTravel(BigDecimal reissueCostTravel) {
		this.reissueCostTravel = reissueCostTravel;
	}


	public BigDecimal getCancellationCostTravel() {
		return cancellationCostTravel;
	}


	public void setCancellationCostTravel(BigDecimal cancellationCostTravel) {
		this.cancellationCostTravel = cancellationCostTravel;
	}


	public Integer getCancellationApprover() {
		return cancellationApprover;
	}


	public void setCancellationApprover(Integer cancellationApprover) {
		this.cancellationApprover = cancellationApprover;
	}


	public String getReasonForChange() {
		return reasonForChange;
	}


	public void setReasonForChange(String reasonForChange) {
		this.reasonForChange = reasonForChange;
	}


	public String getCancellationReasonForChange() {
		return cancellationReasonForChange;
	}


	public void setCancellationReasonForChange(String cancellationReasonForChange) {
		this.cancellationReasonForChange = cancellationReasonForChange;
	}


	public String getCancellationStatus() {
		return cancellationStatus;
	}


	public void setCancellationStatus(String cancellationStatus) {
		this.cancellationStatus = cancellationStatus;
	}


	public Date getInvoiceDate() {
		return invoiceDate;
	}


	public void setInvoiceDate(Date invoiceDate) {
		this.invoiceDate = invoiceDate;
	}


	public String getInvoiceNo() {
		return invoiceNo;
	}


	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}
	
	public BigDecimal getBasicFare() {
		return basicFare;
	}


	public void setBasicFare(BigDecimal basicFare) {
		this.basicFare = basicFare;
	}


	public BigDecimal getyQTax() {
		return yQTax;
	}


	public void setyQTax(BigDecimal yQTax) {
		this.yQTax = yQTax;
	}


	public BigDecimal getOthers() {
		return others;
	}


	public void setOthers(BigDecimal others) {
		this.others = others;
	}


	public BigDecimal getDiscount() {
		return discount;
	}


	public void setDiscount(BigDecimal discount) {
		this.discount = discount;
	}


	public BigDecimal getAgentFee() {
		return agentFee;
	}


	public void setAgentFee(BigDecimal agentFee) {
		this.agentFee = agentFee;
	}

	public BigDecimal getsGST() {
		return sGST;
	}


	public void setsGST(BigDecimal sGST) {
		this.sGST = sGST;
	}


	public BigDecimal getcGST() {
		return cGST;
	}


	public void setcGST(BigDecimal cGST) {
		this.cGST = cGST;
	}


	public BigDecimal getiGST() {
		return iGST;
	}


	public void setiGST(BigDecimal iGST) {
		this.iGST = iGST;
	}


	public BigDecimal getInvoiceAmount() {
		return invoiceAmount;
	}


	public void setInvoiceAmount(BigDecimal invoiceAmount) {
		this.invoiceAmount = invoiceAmount;
	}


	public String getInvoiceStatus() {
		return invoiceStatus;
	}


	public void setInvoiceStatus(String invoiceStatus) {
		this.invoiceStatus = invoiceStatus;
	}
	
	
	public String getAssociateGrade() {
		return associateGrade;
	}


	public void setAssociateGrade(String associateGrade) {
		this.associateGrade = associateGrade;
	}


	public String getApproverGrade() {
		return approverGrade;
	}


	public void setApproverGrade(String approverGrade) {
		this.approverGrade = approverGrade;
	}


	public String getManagerGrade() {
		return managerGrade;
	}


	public void setManagerGrade(String managerGrade) {
		this.managerGrade = managerGrade;
	}


	public String getValidatorGrade() {
		return validatorGrade;
	}


	public void setValidatorGrade(String validatorGrade) {
		this.validatorGrade = validatorGrade;
	}


	public String getModifiedName() {
		return modifiedName;
	}


	public void setModifiedName(String modifiedName) {
		this.modifiedName = modifiedName;
	}


	public String getValidatorName() {
		return validatorName;
	}


	public void setValidatorName(String validatorName) {
		this.validatorName = validatorName;
	}


	public Integer getManagerEmpId() {
		return managerEmpId;
	}


	public void setManagerEmpId(Integer managerEmpId) {
		this.managerEmpId = managerEmpId;
	}


	public Integer getApproverEmpId() {
		return approverEmpId;
	}


	public void setApproverEmpId(Integer approverEmpId) {
		this.approverEmpId = approverEmpId;
	}


	public Integer getValidatorEmpId() {
		return validatorEmpId;
	}


	public void setValidatorEmpId(Integer validatorEmpId) {
		this.validatorEmpId = validatorEmpId;
	}


		// constructor
		public InfoTravel(){
			
		}
	// constructor using fields
	public InfoTravel(Integer infoTravelId, String tourCode, Integer uid, String travelType, String travelWay,
			String travelMode, Date returnDate, Integer adultCount, Integer childCount, Integer infantCount,
			Integer unit, Integer associateUnit, Integer invoiceUnit, Integer projectId, String pmName, Integer approverId, Integer financeId, String typeOfTravel, String travelPurpose,
			String travelCost, String nomineeName, String nomineeRelation, String emergencyContact, String visaRequired, String visaCategory,
			String accomodation, Date checkin, Date checkout, String address, String travellerDoc,
			String travellerRemarks, String approvalRemarks, String travelDeskClosureRemarks, Integer rating, String ratingComments, Date createdDate,
			Integer modifiedBy, Date modifiedDate, Date submittedDate, Integer submissionStatus, Integer approvalStatus, Date approvalDate, Date validatedDate, Date acknowledgedDate,
			Integer travelDeskClosureStatus, String reasonForCancellation, Date cancelledDate, Date closedDate, String recovery, String recoveryComments, Boolean isMigrated, String projectMigrated, Boolean isGuest, BigDecimal costSavingAmount, BigDecimal cancellationCost, BigDecimal reissueCost,  
			String projectManagerName, String projectName, String unitName, String associateName, String associateUnitName, String invoiceUnitName) {
		this.infoTravelId = infoTravelId;
		this.tourCode = tourCode;
		this.uid = uid;
		this.travelType = travelType;
		this.travelWay = travelWay;
		this.travelMode = travelMode;
		this.returnDate = returnDate;
		this.adultCount = adultCount;
		this.childCount = childCount;
		this.infantCount = infantCount;
		this.unit = unit;
		this.associateUnit = associateUnit;
		this.invoiceUnit = invoiceUnit;
		this.projectId = projectId;
		this.pmName = pmName;
		this.approverId = approverId;
		this.financeId = financeId;
		this.typeOfTravel = typeOfTravel;
		this.travelPurpose = travelPurpose;
		this.travelCost = travelCost;
		this.nomineeName = nomineeName;
		this.nomineeRelation = nomineeRelation;
		this.emergencyContact = emergencyContact;
		this.visaRequired = visaRequired;
		this.visaCategory = visaCategory;
		this.accomodation = accomodation;
		this.checkin = checkin;
		this.checkout = checkout;
		this.address = address;
		this.travellerDoc = travellerDoc;
		this.travellerRemarks = travellerRemarks;
		this.approvalRemarks = approvalRemarks;
		this.travelDeskClosureRemarks = travelDeskClosureRemarks;
		this.rating = rating;
		this.ratingComments = ratingComments;
		this.createdDate = createdDate;
		this.modifiedBy = modifiedBy;
		this.modifiedDate = modifiedDate;
		this.submittedDate = submittedDate;
		this.submissionStatus = submissionStatus;
		this.approvalStatus = approvalStatus;
		this.approvalDate = approvalDate;
		this.validatedDate = validatedDate;
		this.acknowledgedDate = acknowledgedDate;
		this.travelDeskClosureStatus = travelDeskClosureStatus;
		this.reasonForCancellation = reasonForCancellation;
		this.cancelledDate = cancelledDate;
		this.closedDate = closedDate;
		this.recovery = recovery;
		this.recoveryComments = recoveryComments;
		this.isMigrated = isMigrated;
		this.projectMigrated = projectMigrated;
		this.isGuest = isGuest;
		this.costSavingAmount = costSavingAmount;
		this.cancellationCost = cancellationCost;
		this.reissueCost = reissueCost;
		this.projectManagerName = projectManagerName;
		this.projectName = projectName;
		this.unitName = unitName;
		this.associateName = associateName;
		this.associateUnitName = associateUnitName;
		this.invoiceUnitName = invoiceUnitName;
	}
	
	
	public InfoTravel(String tourCode, Date createdDate) {
		super();
		this.tourCode = tourCode;
		this.createdDate = createdDate;
	}


	public InfoTravel(Integer infoTravelId, String tourCode, Integer uid, String travelType, String travelWay,
			String travelMode, Date returnDate, Integer adultCount, Integer childCount, Integer infantCount,
			Integer unit, Integer associateUnit, Integer invoiceUnit, Integer projectId, String pmName,
			Integer approverId, Integer financeId, String typeOfTravel, String travelPurpose, String travelCost,
			String nomineeName, String nomineeRelation, String emergencyContact, String visaRequired,
			String visaCategory, String accomodation, Date checkin, Date checkout, String address, String travellerDoc,
			String travellerRemarks, String approvalRemarks, String travelDeskClosureRemarks, Integer rating,
			String ratingComments, Date createdDate, Integer modifiedBy, Date modifiedDate, Date submittedDate,
			Integer submissionStatus, Integer approvalStatus, Date approvalDate,Date validatedDate, Date acknowledgedDate,
			Integer travelDeskClosureStatus, String reasonForCancellation, Date cancelledDate, Date closedDate,
			String recovery, String recoveryComments, Boolean isMigrated, String projectMigrated, Boolean isGuest,
			BigDecimal costSavingAmount, BigDecimal cancellationCost, BigDecimal reissueCost, String projectManagerName,
			String projectName, String unitName, String associateName, String associateUnitName, String invoiceUnitName,
			String origin, String destination, Date departureDate, String givenName, String surname, Date dob,
			String gender, String mobileOrigin, String mobileDestination, String passportNo, String nationality,
			Integer empId, String seat, String email, String alternateEmail, String meal, String frequentFlyerNo,
			String airline, Integer infoTravelDeskId, Date requestDate, Date transactionDate, String location, String sector, String service,
			String serviceType, Date onwardDate, Date returnDateTravel, String serviceProvider, String confirmationNo,
			String ticketNo, String remarks, BigDecimal confirmedCost, BigDecimal highestCost, BigDecimal lowestCost,
			BigDecimal recoveryTravel, String vendor, Integer exceptionalApproval, String reasonForExceptionalApproval,
			String reissueService, BigDecimal reissueCostTravel, BigDecimal cancellationCostTravel,
			Integer cancellationApprover, String reasonForChange, String cancellationReasonForChange,
			String cancellationStatus, Date invoiceDate, String invoiceNo, BigDecimal basicFare, BigDecimal yQTax,
			BigDecimal others, BigDecimal discount, BigDecimal agentFee, BigDecimal sGST, BigDecimal cGST,
			BigDecimal iGST, BigDecimal invoiceAmount, String invoiceStatus, String associateGrade,
			String approverGrade, String managerGrade, String validatorGrade, String modifiedName, String validatorName,
			Integer managerEmpId, Integer approverEmpId, Integer validatorEmpId) {
		super();
		this.infoTravelId = infoTravelId;
		this.tourCode = tourCode;
		this.uid = uid;
		this.travelType = travelType;
		this.travelWay = travelWay;
		this.travelMode = travelMode;
		this.returnDate = returnDate;
		this.adultCount = adultCount;
		this.childCount = childCount;
		this.infantCount = infantCount;
		this.unit = unit;
		this.associateUnit = associateUnit;
		this.invoiceUnit = invoiceUnit;
		this.projectId = projectId;
		this.pmName = pmName;
		this.approverId = approverId;
		this.financeId = financeId;
		this.typeOfTravel = typeOfTravel;
		this.travelPurpose = travelPurpose;
		this.travelCost = travelCost;
		this.nomineeName = nomineeName;
		this.nomineeRelation = nomineeRelation;
		this.emergencyContact = emergencyContact;
		this.visaRequired = visaRequired;
		this.visaCategory = visaCategory;
		this.accomodation = accomodation;
		this.checkin = checkin;
		this.checkout = checkout;
		this.address = address;
		this.travellerDoc = travellerDoc;
		this.travellerRemarks = travellerRemarks;
		this.approvalRemarks = approvalRemarks;
		this.travelDeskClosureRemarks = travelDeskClosureRemarks;
		this.rating = rating;
		this.ratingComments = ratingComments;
		this.createdDate = createdDate;
		this.modifiedBy = modifiedBy;
		this.modifiedDate = modifiedDate;
		this.submittedDate = submittedDate;
		this.submissionStatus = submissionStatus;
		this.approvalStatus = approvalStatus;
		this.approvalDate = approvalDate;
		this.validatedDate = validatedDate;
		this.acknowledgedDate = acknowledgedDate;
		this.travelDeskClosureStatus = travelDeskClosureStatus;
		this.reasonForCancellation = reasonForCancellation;
		this.cancelledDate = cancelledDate;
		this.closedDate = closedDate;
		this.recovery = recovery;
		this.recoveryComments = recoveryComments;
		this.isMigrated = isMigrated;
		this.projectMigrated = projectMigrated;
		this.isGuest = isGuest;
		this.costSavingAmount = costSavingAmount;
		this.cancellationCost = cancellationCost;
		this.reissueCost = reissueCost;
		this.projectManagerName = projectManagerName;
		this.projectName = projectName;
		this.unitName = unitName;
		this.associateName = associateName;
		this.associateUnitName = associateUnitName;
		this.invoiceUnitName = invoiceUnitName;
		this.origin = origin;
		this.destination = destination;
		this.departureDate = departureDate;
		this.givenName = givenName;
		this.surname = surname;
		this.dob = dob;
		this.gender = gender;
		this.mobileOrigin = mobileOrigin;
		this.mobileDestination = mobileDestination;
		this.passportNo = passportNo;
		this.nationality = nationality;
		this.empId = empId;
		this.seat = seat;
		this.email = email;
		this.alternateEmail = alternateEmail;
		this.meal = meal;
		this.frequentFlyerNo = frequentFlyerNo;
		this.airline = airline;
		this.infoTravelDeskId = infoTravelDeskId;
		this.requestDate = requestDate;
		this.transactionDate = transactionDate;
		this.location = location;
		this.sector = sector;
		this.service = service;
		this.serviceType = serviceType;
		this.onwardDate = onwardDate;
		this.returnDateTravel = returnDateTravel;
		this.serviceProvider = serviceProvider;
		this.confirmationNo = confirmationNo;
		this.ticketNo = ticketNo;
		this.remarks = remarks;
		this.confirmedCost = confirmedCost;
		this.highestCost = highestCost;
		this.lowestCost = lowestCost;
		this.recoveryTravel = recoveryTravel;
		this.vendor = vendor;
		this.exceptionalApproval = exceptionalApproval;
		this.reasonForExceptionalApproval = reasonForExceptionalApproval;
		this.reissueService = reissueService;
		this.reissueCostTravel = reissueCostTravel;
		this.cancellationCostTravel = cancellationCostTravel;
		this.cancellationApprover = cancellationApprover;
		this.reasonForChange = reasonForChange;
		this.cancellationReasonForChange = cancellationReasonForChange;
		this.cancellationStatus = cancellationStatus;
		this.invoiceDate = invoiceDate;
		this.invoiceNo = invoiceNo;
		this.basicFare = basicFare;
		this.yQTax = yQTax;
		this.others = others;
		this.discount = discount;
		this.agentFee = agentFee;
		this.sGST = sGST;
		this.cGST = cGST;
		this.iGST = iGST;
		this.invoiceAmount = invoiceAmount;
		this.invoiceStatus = invoiceStatus;
		this.associateGrade = associateGrade;
		this.approverGrade = approverGrade;
		this.managerGrade = managerGrade;
		this.validatorGrade = validatorGrade;
		this.modifiedName = modifiedName;
		this.validatorName = validatorName;
		this.managerEmpId = managerEmpId;
		this.approverEmpId = approverEmpId;
		this.validatorEmpId = validatorEmpId;
	}

	
	

	
}
