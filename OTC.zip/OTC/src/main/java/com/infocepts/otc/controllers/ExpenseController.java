/**
 * 
 */
package com.infocepts.otc.controllers;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.infocepts.otc.repositories.ResourceRepository;
import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infocepts.otc.entities.Expense;
import com.infocepts.otc.entities.ExpenseDetail;
import com.infocepts.otc.repositories.ExpenseDetailRepository;
import com.infocepts.otc.repositories.ExpenseRepository;
import com.infocepts.otc.repositories.ProjectRepository;
import com.infocepts.otc.services.TimesheetService;
import com.infocepts.otc.utilities.AbstractExpenseFileHandling;

/**
 * @author Rewatiraman Singh
 *
 */
@RestController
@RequestMapping("/expense")
public class ExpenseController extends Object {

	private final Logger logger = Logger.getLogger(ExpenseDetailController.class.getName());
	
	@Autowired
	private ExpenseRepository expenseRepository;
	
	@Autowired
	private TimesheetService timesheetService;

	@PersistenceContext(unitName="otc")
    private EntityManager entityManager;
	
	@Autowired
	private ProjectRepository projectRepository;
	
	@Autowired
	private ExpenseDetailRepository expenseDetailRepository;

	@Autowired
	private ResourceRepository resourceRepository;

	@GetMapping
	public List<Expense> getAllExpenses() {
		return expenseRepository.findAll();
	}

	@PostMapping
	public Object saveExpense(@RequestBody List<Expense> expenseList) {
		List<Expense> emptyExpenseList = new ArrayList<>();
		Map<String, List<Expense>> expenseMap = new HashMap<>();
		
		for (Expense expense : expenseList) {
			try {
				emptyExpenseList.add(expenseRepository.save(expense));
				expenseMap.put("expenses", emptyExpenseList);
			} catch (Exception ex) {
				logger.log(Level.SEVERE, "ERROR WHILE SAVING/UPDATING EXPENSE PURPOSE WITH EXPENSE PURPOSE ID: "
						+ expense.getExpenseId(), ex);
			}
		}

		return expenseMap;
	}

	@GetMapping("/getApprovalList")
	public Object getApprovalList(HttpServletRequest request) {
		Integer uid = (Integer) request.getSession().getAttribute("loggedInUid");
		List<Expense> expenseList = new ArrayList<>();
		boolean isAdmin = timesheetService.isAdmin();
		boolean isPM = projectRepository.getProjectCountForPM(uid) > 0;
		boolean isPH = timesheetService.isPH();
		boolean isAH = ExpenseRepository.isAH(entityManager, uid);
		Boolean forTravel = Boolean.valueOf(request.getParameter("forTravel"));
		Boolean forFinance = Boolean.valueOf(request.getParameter("forFinance"));
		Boolean isSettlement = Boolean.valueOf(request.getParameter("isSettlement"));
		Boolean showModal = Boolean.valueOf(request.getParameter("showModal"));
		Integer expenseId = NumberUtils.toInt(request.getParameter("expenseId"));
		
		// Expense detail records to be shown on modal window.
		if (showModal && expenseId != 0) {
			return expenseDetailRepository.findFormattedExpenseDetailByExpenseId(entityManager,expenseId);
		}
		
		// Approval tab should be visible to any of below mentioned roles.
		if (isAdmin || isPM || isPH || isAH) {
			try {
				expenseList.addAll(ExpenseRepository.getApprovalList(entityManager, uid, ExpenseRepository.ApprovalFor.PM_AH_PH));
				return expenseList;
			} catch (Exception e) {
				logger.log(Level.SEVERE, "SOMETHING WENT WRONG WHILE FETCHING PM/AH/PH EXPENSE APPROVAL LIST FOR TAB!", e);
			}
		} else if (forTravel) {
			try {
				expenseList.addAll(ExpenseRepository.getApprovalList(entityManager, uid, ExpenseRepository.ApprovalFor.TRAVEL));
				return expenseList;
			} catch (Exception e) {
				logger.log(Level.SEVERE, "SOMETHING WENT WRONG WHILE FETCHING TRAVEL EXPENSE APPROVAL LIST FOR TAB!", e);
			}
		} else if (forFinance && isSettlement) {
			try {
				expenseList.addAll(ExpenseRepository.getApprovalList(entityManager, uid, ExpenseRepository.ApprovalFor.SETTLEMENT));
				return expenseList;
			} catch (Exception e) {
				logger.log(Level.SEVERE, "SOMETHING WENT WRONG WHILE FETCHING FINANCE SETTLEMENT LIST FOR TAB!", e);
			}
		} else if (forFinance) {
			try {
				expenseList.addAll(ExpenseRepository.getApprovalList(entityManager, uid, ExpenseRepository.ApprovalFor.FINANCE));
				return expenseList;
			} catch (Exception e) {
				logger.log(Level.SEVERE, "SOMETHING WENT WRONG WHILE FETCHING FINANCE EXPENSE APPROVAL LIST FOR TAB!", e);
			}
		} 
		
		return expenseList;
	}
	
	@GetMapping("/getResourceRoles")
	public Object getResourceRoles(HttpServletRequest request) {
		Integer uid = (Integer) request.getSession().getAttribute("loggedInUid");
		List<String> roleList = new ArrayList<>();
		try {
			/* Below roles are used for "Finance" that is why we are putting a check for both of them 
			 * and considering it as a single role.
			*/
			if (timesheetService.isTVF()) {
				roleList.add("Finance");
			}
			
			if (timesheetService.isTravel()) {
				roleList.add("Travel");
			}
			
			if (projectRepository.getProjectCountForPM(uid) > 0) {
				roleList.add("PM");
			}
			
			if (timesheetService.isPH()) {
				roleList.add("PH");
			}
			
			if (ExpenseRepository.isAH(entityManager, uid)) {
				roleList.add("AH");
			}
			
			/* Collect all the resource roles assigned to the respective user.
			 This will be used to check the roles at client side and hide the tabs accordingly for expense page.
			*/
//			resourceRoles.forEach(role -> roleList.addAll(Stream.of(role.getRoles()).map(Roles::getRole).collect(Collectors.toList())));
		} catch (Exception e) {
			logger.log(Level.SEVERE, "ERROR WHILE FETCHING RESOURCE ROLES FOR UID: " + uid, e);
		}
		return roleList;
	}
	
	@GetMapping("/getExpensesByUid")
	public List<Expense> getExpensesByUid(HttpServletRequest request) {
		Integer uid = NumberUtils.toInt(request.getSession().getAttribute("loggedInUid").toString());
		List<Expense> expList = new ArrayList<>();
		if (uid != 0) {
			return ExpenseRepository.findExpenseByUserId(entityManager, uid);
		}
		return expList;
	}

	@DeleteMapping("/deleteExpenseById")
	public void deleteExpenseById(HttpServletRequest request) {
		Integer expenseId = NumberUtils.toInt(request.getParameter("expenseId"));
		try {
			if (expenseId != 0) {
				expenseRepository.delete(expenseId);;
			}
		} catch (Exception e) {
			logger.log(Level.WARNING, "COULD NOT DELETE AN EXPENSE RECORD BY EXPENSE ID: " + expenseId, e);
		} 	
	}

	@DeleteMapping("/deleteExpenseByUserId")
	public void deleteExpenseByUserId(HttpServletRequest request) {
		Integer uid = NumberUtils.toInt(request.getParameter("expenseId"));
		try {
			expenseRepository.deleteExpenseByUserId(uid);
		} catch (Exception e) {
			logger.log(Level.WARNING, "COULD NOT DELETE AN EXPENSE RECORD BY USER ID: " + uid, e);
		} 
	}
	
	@GetMapping("/customizedExcelExport/{expenseId}/{fileName}")
	public void export(HttpServletRequest request, HttpServletResponse response,
			@PathVariable("expenseId") int expenseId, @PathVariable("fileName") String fileName) {
		try {
			Expense expense = ExpenseRepository.findFormattedExpenseByExpenseId(entityManager, expenseId);
			List<ExpenseDetail> expDetailList = expenseDetailRepository
					.findFormattedExpenseDetailByExpenseId(entityManager, expenseId);
			expense.setEmpId(resourceRepository.findEmpIdByUid(expense.getUid()));
			File toExcel = AbstractExpenseFileHandling.exportExpenseToExcel(expense, expDetailList, fileName + ".xlsx");
			Path path = Paths.get(toExcel.toString());
			response.addHeader(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + fileName + ".xlsx");
			Files.copy(path, response.getOutputStream());
			response.getOutputStream().flush();
			Files.deleteIfExists(path);
		} catch (Exception e) {
			logger.log(Level.SEVERE, "COULD NOT EXPORT EXCEL FOR EXPENSE ID: " + expenseId, e);
		}
	}
}
