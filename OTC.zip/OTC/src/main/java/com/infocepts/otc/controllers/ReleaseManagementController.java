/**
* Filename: /src/main/java/com/infocepts/otc/controllers/ReleaseManagementController.java
* @author  Anjali S. Kalbande
* @version 1.0
* @since   2018-01-08 
*/

package com.infocepts.otc.controllers;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.infocepts.otc.entities.ReleaseManagement;
import com.infocepts.otc.repositories.ReleaseManagementRepository;
import com.infocepts.otc.services.TimesheetService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.mail.MessagingException;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

@RestController
@RequestMapping(value = "/releaseManagement", headers = "referer")
public class ReleaseManagementController {

	final Logger logger = Logger.getLogger(ReleaseManagementController.class.getName());

	@Autowired
	ReleaseManagementRepository repository;

	@Autowired
	HttpSession session;

	@PersistenceContext(unitName = "otc")
	private EntityManager manager;
	
	@Autowired
	TimesheetService service;
	
	
	@GetMapping("/findAllReleaseManagement")
    public Object findAllReleaseManagement(HttpServletRequest request){        
		List<ReleaseManagement> releaseManagementList = null;
        try{
        	releaseManagementList = manager.createNamedQuery("getRelease_ReleaseManagement_All", ReleaseManagement.class)
					.getResultList();	
        }catch(Exception e){
        	logger.info(String.format("error in fetching release list - ", e.getMessage()));
			e.printStackTrace();
        }
        return releaseManagementList;
    }
	
	@GetMapping("/getReleaseManagementById")
	public Object getReleaseManagementById(@RequestParam(value = "releaseId", defaultValue = "0") Integer releaseId,
			  HttpServletRequest request){
		ReleaseManagement releaseManagement = null;
		if( service.isAdmin()) {
			try {
				releaseManagement = repository.findOne(releaseId);
			} catch (Exception e) {
				logger.log(Level.SEVERE, "exceptn msg", e);
			}
		}
		return releaseManagement;
	}
	
	@RequestMapping(method = RequestMethod.POST)
	public ReleaseManagement addReleaseManagement(@RequestBody ReleaseManagement releasemanagement,
			HttpServletRequest request) throws MessagingException {
		if( service.isAdmin()) {
		try {
			releasemanagement.setReleaseId(null);
			repository.save(releasemanagement);

		} catch (Exception e) {
			logger.info(String.format("exception - ", e));
		}
		}
		return releasemanagement;
	}
	

	@RequestMapping(value = "/{releaseId}", method = RequestMethod.PUT)
	public ReleaseManagement updateReleaseManagement(@RequestBody ReleaseManagement updatedReleaseManagement,
			@PathVariable Integer releaseId, HttpServletRequest request) throws MessagingException {
		if( service.isAdmin()) {
		try {
			updatedReleaseManagement.setReleaseId(releaseId);
			repository.save(updatedReleaseManagement);
			
		} catch (Exception e) {
			logger.info(String.format("exception - ", e));
		}
		}
		return updatedReleaseManagement;
	}


	@RequestMapping(value = "/{releaseId}", method = RequestMethod.DELETE)
	public void deleteReleaseManagement(@PathVariable Integer releaseId) {
		if( service.isAdmin()) {
		try {
			repository.delete(releaseId);
		} catch (Exception e) {
			logger.info(String.format("exception - ", e));
		}
		}
	}

}
