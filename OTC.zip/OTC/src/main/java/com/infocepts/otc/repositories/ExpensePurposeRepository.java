/**
 * 
 */
package com.infocepts.otc.repositories;

import java.io.Serializable;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.infocepts.otc.entities.ExpensePurpose;

/**
 * @author Rewatiraman Singh
 *
 */
@Repository
public interface ExpensePurposeRepository extends JpaRepository<ExpensePurpose, Serializable>{

	@Query("FROM ExpensePurpose WHERE expensePurposeId = :expensePurposeId")
	public ExpensePurpose findExpensePurpose(@Param("expensePurposeId") int expensePurposeId);
	
	@Query("FROM ExpensePurpose ep WHERE status = 0 order by ep.purposeName")
	public List<ExpensePurpose> findActiveExpensePurposes();
}
