package com.infocepts.otc.security;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.LockedException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.stereotype.Component;

import com.infocepts.otc.entities.AccessLock;
import com.infocepts.otc.entities.Resource;
import com.infocepts.otc.repositories.AccessLockRepository;
import com.infocepts.otc.repositories.ResourceRepository;

@Component
public class CustomAuthenticationProvider implements AuthenticationProvider {

	@Autowired
	ResourceRepository resourcerepository;
	
	@Autowired
	AccessLockRepository accesslockrepository;
	
	@Autowired
	HttpServletResponse response;
	
	@Autowired
	HttpServletRequest request;
	
	
	private static final Logger log = LoggerFactory.getLogger(CustomAuthenticationProvider.class);
	
	@Override
	public  Authentication authenticate(Authentication authentication)
      throws AuthenticationException {
		Boolean setException = false;
		String username = request.getParameter("username");
		Resource resource = resourcerepository.findResourceByUsername(username);
		/**Check if the username is valid or not**/
		if(resource == null){
		  try {
			  response.sendRedirect("/login?error");
			  setException = true;
			  log.info("Account does not exist"); 
		  } catch (IOException e) {
		e.printStackTrace();
		  }  
		}else{
			AccessLock user = accesslockrepository.findUsername(username);
			if(user != null){
				Boolean lock = user.isLocked();
				if(lock.booleanValue() == true){
					try {
						response.sendRedirect("/login?blocked");
	   					log.info("Account is blocked"); 
	   					setException = true;
	   				} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
		}
		/**Throw the Locked Exception to stop the flow here itself rather than going 
		 * for Ldap authentication for the accounts that are blocked**/
		if(setException){
		throw new LockedException("Account is blocked") ;
		}
		throw new BadCredentialsException("Bad Authentication");
	}

  @Override
  public boolean supports(Class<?> authentication) {
    return authentication.equals(UsernamePasswordAuthenticationToken.class);

  }
}
