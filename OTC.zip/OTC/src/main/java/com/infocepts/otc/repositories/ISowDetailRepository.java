/**
* Filename: /src/main/java/com/infocepts/otc/controllers/ISowDetailRepository.java
* @author  JV
* @version 1.0
* @since   2018-10-31 
*/
package com.infocepts.otc.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.infocepts.otc.entities.ISowDetail;
import com.infocepts.otc.entities.InvoicesDetail;

public interface ISowDetailRepository extends JpaRepository<ISowDetail,Integer>{

	@Override
	public List<ISowDetail> findAll();
	
	@Query("from ISowDetail i where i.isow.isowId=:isowId")
	public List<ISowDetail> findByIsowId(@Param("isowId") Integer isowId);
}