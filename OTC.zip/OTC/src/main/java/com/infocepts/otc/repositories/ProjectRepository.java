package com.infocepts.otc.repositories;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.persistence.EntityManager;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.infocepts.otc.entities.Project;
import com.infocepts.otc.utilities.LoadConstant;



@Repository
public interface ProjectRepository extends JpaRepository<Project,Integer>{

	@Override
    List<Project> findAll();
	
	
	
	@Query("select accountId from Project where itemId = :projectId")
	int getAccountIdByProjectId(@Param("projectId") Integer projectId);
	
	@Transactional
	@Modifying
	@Query(value = "update " + LoadConstant.otc + ".dbo.treq set accountId = :newAccountId where treqId in (:treqIdList)", nativeQuery = true)
	void updateAccountIdForTreq(@Param(value = "newAccountId") Integer newAccountId, @Param(value = "treqIdList") List treqIdList);

	@Query("select infoCeptsProjectCode from Project where itemId = (select max(itemId) from Project )")
	String getLastInfoceptsProjectCode();
	
	@Query("SELECT COUNT(*) FROM Project WHERE state = 'Active' AND projectManagersId = :userId")
	Integer getProjectCountForPM(@Param("userId") Integer userId);
	
	@Query("SELECT COUNT(*) FROM Project WHERE state = 'Active' AND " + "(plannersId like :userId)"
					+ " or (plannersId like concat('%,',:userId,',%'))"
					+ " or (plannersId like concat(:userId,',%'))" 
					+ " or (plannersId like concat('%,',:userId))")
	Integer getProjectCountForPlanner(@Param("userId") String userId);
	
	@SuppressWarnings("unchecked")
	default List<Map<Object, String>> getAllocatedProjectsByUid(EntityManager manager, int uid) {
		final Logger logger = Logger.getLogger(ProjectRepository.class.getName());
		String queryString = "select distinct p.itemId as projectId, p.title as projectName from " + LoadConstant.infomaster + 
				".[dbo].[project] p inner join " + LoadConstant.otc + ".[dbo].[allocation] a "
				+ " on a.projectId = p.itemId where a.uid = :uid order by p.title";
		List<Map<Object, String>> projectList = new ArrayList<>();
		try {
			javax.persistence.Query projectQuery = manager.createNativeQuery(queryString, "fetchProjects");
			projectQuery.setParameter("uid", uid);
			List<Object[]> resultList = projectQuery.getResultList();
			resultList.forEach(object -> {
				Map<Object, String> map = new HashMap<>();
				Integer projectId = (Integer) object[0];
				String projectName = (String) object[1];
				map.putIfAbsent("projectId", projectId + "");
				map.putIfAbsent("projectName", projectName);
				projectList.add(map);
			});
		} catch (Exception e) {
			logger.log(Level.SEVERE, "SOMETHING WENT WRONG WHILE FETCHING THE ALLOCATED PROJECTS FOR UID: " + uid, e);
		}
		return projectList;
	}
	
	@Query("SELECT new map(p.itemId as projectId, p.title as projectName) FROM Project p where p.state='Active' order by p.title")
	public List<Map<String, String>> getProjectsMap();
	
	@Query("select p.title from Project p where p.itemId = :projectId")
	public String getProjectTitleById(@Param("projectId") int projectId);
	
	@SuppressWarnings("unchecked")
	default List<Map<Object, String>> getGenericProjects(EntityManager manager) {
		final Logger logger = Logger.getLogger(ProjectRepository.class.getName());
		String queryString = "select distinct p.itemId as projectId, p.title as projectName from "
				+ LoadConstant.infomaster + ".[dbo].[project] p where p.isGeneric = 1 order by p.title";
		List<Map<Object, String>> projectList = new ArrayList<>();
		try {
			javax.persistence.Query projectQuery = manager.createNativeQuery(queryString, "fetchProjects");
			List<Object[]> resultList = projectQuery.getResultList();
			resultList.forEach(object -> {
				Map<Object, String> map = new HashMap<>();
				Integer projectId = (Integer) object[0];
				String projectName = (String) object[1];
				map.putIfAbsent(projectId, projectName);
				projectList.add(map);
			});
		} catch (Exception e) {
			logger.log(Level.SEVERE, "SOMETHING WENT WRONG WHILE FETCHING THE GENERIC PROJECTS!", e);
		}
		return projectList;
	}
	
	@SuppressWarnings("unchecked")
	default void updateAccountInRelatedTreqs(EntityManager manager, int newAccountId, int projectId) {
		final Logger logger = Logger.getLogger(ProjectRepository.class.getName());
		final String queryString = "SELECT t.treqId FROM [otcdev].[dbo].treq t left join"
				+ " [otcdev].[dbo].allocation al on al.alcId = t.alcId left join [InfoMasters_Dev].[dbo].resource"
				+ " rc on rc.uid = t.createdBy left join [InfoMasters_Dev].[dbo].resource rm on rm.uid = t.modifiedBy"
				+ " LEFT join [InfoMasters_Dev].[dbo].resource ra on ra.uid = al.uid LEFT join"
				+ " [InfoMasters_Dev].[dbo].resource rn on rn.uid = t.existingAssociateId left join"
				+ " [InfoMasters_Dev].[dbo].accounts pa on t.accountId=pa.itemId left join"
				+ " [InfoMasters_Dev].[dbo].skill s on s.skillId = t.skillId left join"
				+ " [InfoMasters_Dev].[dbo].skill ss on ss.skillId = t.secondarySkillId WHERE"
				+ " t.sowDetailId in(select sowDetailId from [otcdev].[dbo].[sowDetail] "
				+ "where sowId in (select sowId from [otcdev].[dbo].[sow] where projectId = :projectId)) order by t.treqId DESC;";
		List treqIdList = (List<Long>) manager.createNativeQuery(queryString).setParameter("projectId", projectId).getResultList();
		try {
			updateAccountIdForTreq(newAccountId, treqIdList);
		} catch (Exception e) {
			logger.log(Level.SEVERE, "SOMETHING WENT WRONG WHILE UPDATING TREQS' ACCOUNT ID"
					+ "\n NEW ACCOUNT ID: " + newAccountId + "\n NEW ACCOUNT ID: " + treqIdList, e);
		}
	}
}
