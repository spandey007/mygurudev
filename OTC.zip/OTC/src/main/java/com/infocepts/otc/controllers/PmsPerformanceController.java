/**
* Filename: /src/main/java/com/infocepts/otc/controllers/PmsPerformanceController.java
* --------------------------------------------------------------------------
* Sr.No   Author      Version     Modified Date    Description
---------------------------------------------------------------------------
  1.    | IS Team   | 1.0     |  07-12-2018   |  Intial Version 
  2.    | Shreya A  | 1.1     |  13-04-2019   |  Unlock form irrespective of phase workflow
  --------------------------------------------------------------------------
*/

package com.infocepts.otc.controllers;

import java.util.logging.Logger;
import com.infocepts.pms.entities.PmsPerformance;
import com.infocepts.pms.entities.PmsResource;
import com.infocepts.pms.repositories.PmsPerformanceRepository;
import com.infocepts.pms.repositories.PmsResourceRepository;

import ch.qos.logback.core.net.SyslogOutputStream;

import com.infocepts.otc.services.PmsService;
import com.infocepts.otc.services.TimesheetService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.mail.MessagingException;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import java.util.HashMap;
import java.util.List;

@RestController
@RequestMapping(value="/api/pms/performance", headers="referer")
public class PmsPerformanceController {

    final Logger logger = Logger.getLogger(PmsPerformanceController.class.getName());

    @Autowired
    PmsPerformanceRepository repository;
    
    @Autowired
    PmsResourceRepository pmsResourceRepository;
    
    @Autowired
    HttpSession session;

    @PersistenceContext(unitName = "pms") 
    private EntityManager manager;
			
	@Autowired
	TimesheetService service;
	
	@Autowired
	PmsService pmsService;

	/**
   * This method is used to find results set from module entity
   * based on params passed from JS file
   */
    @RequestMapping(method = RequestMethod.GET)
    public List<PmsPerformance> findAllPmsPerformance(@RequestParam(value = "cycleId", defaultValue = "0") Integer cycleId
													 ,@RequestParam(value = "uid", defaultValue = "0") Integer uid            						
													 ,HttpServletRequest request){
        List<PmsPerformance> pmsPerformanceList = null;
                
        logger.info("--------------------in PmsPerformance controller------------------");		
		logger.info("cycleId="+cycleId);
		logger.info("uid="+uid);	
		
        try {
       
        	if (cycleId != 0 && uid != 0) {
			        	
        		pmsPerformanceList = manager.createNamedQuery("getPerformanceByCycleAndUid", PmsPerformance.class)                        
                        .setParameter("cycleId", cycleId)	
						.setParameter("uid", uid)							
                        .getResultList();        					
        	} 
			else if(cycleId != 0) {
			
				pmsPerformanceList = manager.createNamedQuery("getPerformanceByCycle", PmsPerformance.class)                        
                        .setParameter("cycleId", cycleId)					
                        .getResultList();
			}
			else {
			
				pmsPerformanceList = manager.createNamedQuery("getAllPerformance", PmsPerformance.class)                        
                        .getResultList();
        					
			}
			
         } 
		catch (Exception e){
			logger.info(String.format("exception - ", e.getMessage()));
        }
        return pmsPerformanceList;

    }
    
    /**
     * This method is add row in moduleName entity
     * 
     */
    @RequestMapping(method=RequestMethod.POST)
	public PmsPerformance addPmsPerformance(@RequestBody PmsPerformance pmsPerformanceList, HttpServletRequest request) throws MessagingException {
		
		
			try{
				pmsPerformanceList.setPerformanceId(null);
				repository.save(pmsPerformanceList);
			}
			catch(Exception e){
				  logger.info(String.format("exception - ", e.getMessage()));
			}
		
		
		return pmsPerformanceList;
	}
    
    /**
     * This method is update row in moduleName entity
     * based on primaryKey Of Module Table 
     */
    @RequestMapping(value="/{performanceId}",method=RequestMethod.PUT)
	 public PmsPerformance updatePmsPerformance(@RequestBody PmsPerformance updatedPmsPerformance,@PathVariable Integer performanceId,HttpServletRequest request) throws MessagingException{
      
    	
    	
    		String userType = "";
    		String phase = "";
    		PmsPerformance performanceObject = null;
    		PmsResource pmsResourceObj = null;
    		
    		// individual form Unlock workflow - check PmsResource object to check cycle and enable Phase
    		Boolean flagHandshake = false;
    		Boolean flagPitstop = false;
    		Boolean flagEvaluation = false;
    		
			try{
				
				Integer uid = session.getAttribute("loggedInUid") != null ? Integer.valueOf(session.getAttribute("loggedInUid").toString()) : 0;
				
				//To update the performance field as per user type
			    HashMap<String,String> typeAndPhase = pmsService.getUserTypeAndPhase(updatedPmsPerformance.getPerformanceId(),uid);
				
			    userType = typeAndPhase.get("userType");
			    phase = typeAndPhase.get("phase");
			    
			    performanceObject = repository.findOne(performanceId);
			
			    // individual form Unlock workflow - check PmsResource object to check cycle and enable Phase
			    pmsResourceObj = pmsResourceRepository.findResourceById(performanceObject.getUid());
			    	
			    if(pmsResourceObj != null) {
			    	if(pmsResourceObj.getEnableHandshake() && (pmsResourceObj.getEnableHandshakeCycle() == performanceObject.getCycle().getCycleId())) {
			    		flagHandshake = true;
			    	}
			    	else if(pmsResourceObj.getEnablePitstop() && (pmsResourceObj.getEnablePitstopCycle() == performanceObject.getCycle().getCycleId())) {
			    		flagPitstop = true;
			    	}
			    	else if(pmsResourceObj.getEnableEvaluation() && (pmsResourceObj.getEnableEvaluationCycle() == performanceObject.getCycle().getCycleId())) {
			    		flagEvaluation = true;
			    	}
			    }			 
			   
			    //Generic fields 
			    performanceObject.setModifiedBy(updatedPmsPerformance.getModifiedBy());
		    	performanceObject.setModifiedDate(updatedPmsPerformance.getModifiedDate());
		    	
		        //=====For Handshake=====
			    if(phase == "Handshake" || flagHandshake)
			    {	
			    	performanceObject.setFormStatusGoalsetting(updatedPmsPerformance.getFormStatusGoalsetting());			    	
			   
			    }
			    //=====For Pitstop=====
			    else if(phase == "Pitstop" || flagPitstop)
			    {
			    	performanceObject.setFormStatusPitstop(updatedPmsPerformance.getFormStatusPitstop());			    			    
			    	
			    }
			    //=====For Evaluation=====
			    else if(phase == "Evaluation" || flagEvaluation)
			    {
			    	performanceObject.setFormStatusEvaluation(updatedPmsPerformance.getFormStatusEvaluation());
			    
		    		//-----For Associate-----
				    if(userType == "Associate"){
				    	performanceObject.setSelfRatingCompetency(updatedPmsPerformance.getSelfRatingCompetency());
				    	performanceObject.setSelfRatingGoals(updatedPmsPerformance.getSelfRatingGoals());
				    	performanceObject.setSelfOverallRating(updatedPmsPerformance.getSelfOverallRating());
				    }
				    //-----For Manager-----
				    else if(userType == "Manager" || userType == "HR"){
				    	
				    	performanceObject.setManagersRatingCompetency(updatedPmsPerformance.getManagersRatingCompetency());
				    	performanceObject.setManagersRatingGoals(updatedPmsPerformance.getManagersRatingGoals());
				    	performanceObject.setManagersOverallRating(updatedPmsPerformance.getManagersOverallRating());
				    	
				    	performanceObject.setManagersCommentsGoals(updatedPmsPerformance.getManagersCommentsGoals());
				    	performanceObject.setManagersCommentsCompetency(updatedPmsPerformance.getManagersCommentsCompetency());
				    	performanceObject.setImprovementAreas(updatedPmsPerformance.getImprovementAreas());
				    }
				    //-----Reviewer-----
				    else if(userType == "Reviewer" || userType == "HR"){
				    	//performanceObject.setReviewersCommentsGoals(updatedPmsPerformance.getReviewersCommentsGoals());
				    	//performanceObject.setReviewersCommentsCompetency(updatedPmsPerformance.getReviewersCommentsCompetency());
				    	performanceObject.setReviewersImprovementAreas(updatedPmsPerformance.getReviewersImprovementAreas());
				    }					  
			    	
			    }

			    performanceObject.setPerformanceId(performanceId);
				repository.save(performanceObject);
			}
			catch(Exception e){
				 logger.info(String.format("exception - ", e.getMessage()));
			}
		
		 return performanceObject;
	 }
    
    /**
     * This method is get data for specific row in moduleName entity
     * based on primaryKey Of Module Table 
     */
    @RequestMapping(value="/{performanceId}",method=RequestMethod.GET)
	 public PmsPerformance getPmsPerformance(@PathVariable Integer performanceId, HttpServletRequest request) throws MessagingException{
    	
    	PmsPerformance pmsPerformance = null;
    	
    	
		try{
			pmsPerformance = manager.createNamedQuery("getPerformanceById", PmsPerformance.class)
					 .setParameter("performanceId", performanceId)
					 .getSingleResult();
		}
		catch(Exception e){
			  logger.info(String.format("exception - ", e.getMessage()));
		}
		
		/* ------------------------- Authorization start ------------------------------------ */
    	// Authorization for associate or his manager/supervisor or HR to view the form
		if(!service.isHRPms() && !service.isHRPmsAdmin() && !service.isAValidPmsCall(pmsPerformance.getUid()))
		{
			service.sendTamperedMail("Performance page", 0, 0, request);	
			pmsPerformance = null;
			throw new IllegalArgumentException("Access Denied");
		}
		/* ------------------------- Authorization ends ------------------------------------ */
		
		 
		 return pmsPerformance;
	 }
	 
    
    /**
     * This method is delete data for specific row in moduleName entity
     * based on primaryKey Of Module Table 
     */	 
	@RequestMapping(value="/{performanceId}",method=RequestMethod.DELETE)
	public void deletePmsPerformance(@PathVariable Integer performanceId, HttpServletRequest request)  throws MessagingException {
		
			try{
			//repository.delete(performanceId); Delete is not required
			}
			catch(Exception e){
				 logger.info(String.format("exception - ", e.getMessage()));
			}
				 
	}
	
	@RequestMapping(value = "/send-notification/{performanceId}", method=RequestMethod.PUT)
	public void sendPmsNotification(@PathVariable Integer performanceId,HttpServletRequest request) throws MessagingException{

		String userType = "";
		String phase = "";
		PmsPerformance performanceObject = null;
		
		Integer uid = session.getAttribute("loggedInUid") != null ? Integer.valueOf(session.getAttribute("loggedInUid").toString()) : 0;
		
		//To update the performance field as per user type
	    HashMap<String,String> typeAndPhase = pmsService.getUserTypeAndPhase(performanceId,uid);
		
	    userType = typeAndPhase.get("userType");
	    
	    phase = typeAndPhase.get("phase");
	    
	    performanceObject = repository.findOne(performanceId);
	    
	    pmsService.sendPMSNotification(performanceObject, phase, request);        						
	    
	}
   
}
