package com.infocepts.otc.repositories;

import java.util.List;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import com.infocepts.otc.entities.Configuration;
import java.lang.String;

public interface ConfigurationRepository extends CrudRepository<Configuration,Integer>{

	@Override
	public List<Configuration> findAll();
	
	@Query("from Configuration where configName=:name")
	public Configuration findByTitle(@Param("name") String name);
}
