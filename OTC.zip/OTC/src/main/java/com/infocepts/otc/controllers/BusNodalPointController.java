package com.infocepts.otc.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.infocepts.otc.entities.BusNodalPoint;
import com.infocepts.otc.repositories.BusNodalPointRepository;
import com.infocepts.otc.services.TimesheetService;

@RestController
@RequestMapping(value="/busnodalpoint",headers="referer")
public class BusNodalPointController {
	@Autowired
	BusNodalPointRepository busNodalPointRepository;
	
	@Autowired
	TimesheetService service;
	
	@RequestMapping(method=RequestMethod.POST)
	public BusNodalPoint addBusNodalPoint(@RequestBody BusNodalPoint busNodalPoint) {
		busNodalPoint.setBusNodalPointId(null);
		Boolean isAValidCall = false;
		if(service.isTravel())
		{
			isAValidCall = true;
		}
		if(isAValidCall) {
			
			busNodalPointRepository.save(busNodalPoint);
		}
		return busNodalPoint;
	}
	
	@RequestMapping(method=RequestMethod.GET)
	public List<BusNodalPoint> getBusNodalPoint(){
		List<BusNodalPoint> list = null;
		Boolean isAValidCall = false;
		if(service.isTravel())
		{
			isAValidCall = true;
		}
		//if(isAValidCall) {
			
			list = busNodalPointRepository.findByBusNodalPointNames();
		//}
		return list;
	}
	
	@RequestMapping(value="/{busNodalPointId}",method=RequestMethod.GET)
	public BusNodalPoint getBusNodalPoint(@PathVariable Integer busNodalPointId){
		BusNodalPoint busNodalPoint = null;
		Boolean isAValidCall = false;
		if(service.isTravel())
		{
			isAValidCall = true;
		}
		if(isAValidCall) {
			
			busNodalPoint = busNodalPointRepository.findOne(busNodalPointId);
		}
		return busNodalPoint;
	}
	
	@RequestMapping(value="/{busNodalPointId}", method=RequestMethod.PUT)
	public BusNodalPoint updateBusNodalPoint(@PathVariable Integer busNodalPointId,  @RequestBody BusNodalPoint updatedBusNodalPoint){
		updatedBusNodalPoint.setBusNodalPointId(busNodalPointId);
		busNodalPointRepository.save(updatedBusNodalPoint);
		return updatedBusNodalPoint;
	}
	
	@RequestMapping(value="/{busNodalPointId}",method=RequestMethod.DELETE)
	public void deleteBusPass(@PathVariable Integer busNodalPointId){
		busNodalPointRepository.delete(busNodalPointId);
}
}
