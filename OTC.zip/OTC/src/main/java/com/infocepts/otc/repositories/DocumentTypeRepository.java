package com.infocepts.otc.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.infocepts.otc.entities.DocumentType;

public interface DocumentTypeRepository extends CrudRepository<DocumentType,Integer>{

	@Override
	public List<DocumentType> findAll();
	
	@Query("from DocumentType where status = 1")
	public List<DocumentType> findAllActive();
}
