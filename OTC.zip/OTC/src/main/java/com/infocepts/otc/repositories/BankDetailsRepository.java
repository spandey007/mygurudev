package com.infocepts.otc.repositories;

import java.util.List;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import com.infocepts.otc.entities.BankDetails;

public interface BankDetailsRepository extends CrudRepository<BankDetails,Integer>{

	@Override
	public List<BankDetails> findAll();
	
	@Query("from BankDetails where entityId=:entityId and unitId=:unitId")
	public List<BankDetails> findByEntityId(@Param("entityId") Integer entityId,@Param("unitId") Integer unitId);
}

