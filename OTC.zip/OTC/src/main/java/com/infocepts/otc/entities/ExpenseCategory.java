/**
 * 
 */
package com.infocepts.otc.entities;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.infocepts.otc.utilities.LoadConstant;

/**
 * @author Rewatiraman Singh
 *
 */
@Entity
@Table(catalog=LoadConstant.infomaster, schema="[dbo]",name="expenseCategory")
public class ExpenseCategory implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 9082157625489030402L;
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer expenseCategoryId;	
	
	@ManyToOne
	@JoinColumn(name="purposeId")
	private ExpensePurpose expensePurpose;
	
	private String categoryName;
	private String description;
	private Byte status;
	private Integer maxLimit;
	
	
	public ExpenseCategory() {
	}
	
	public ExpenseCategory(Integer expenseCategoryId, ExpensePurpose expensePurpose, String categoryName, String description,
			Byte status, Integer maxLimit) {
		this.expenseCategoryId = expenseCategoryId;
		this.expensePurpose = expensePurpose;
		this.categoryName = categoryName;
		this.description = description;
		this.status = status;
		this.maxLimit = maxLimit;
	}
	
	public Integer getExpenseCategoryId() {
		return expenseCategoryId;
	}

	public void setExpenseCategoryId(Integer expenseCategoryId) {
		this.expenseCategoryId = expenseCategoryId;
	}

	public ExpensePurpose getExpensePurpose() {
		return expensePurpose;
	}

	public void setExpensePurpose(ExpensePurpose expensePurpose) {
		this.expensePurpose = expensePurpose;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Byte getStatus() {
		return status;
	}

	public void setStatus(Byte status) {
		this.status = status;
	}

	public Integer getMaxLimit() {
		return maxLimit;
	}

	public void setMaxLimit(Integer maxLimit) {
		this.maxLimit = maxLimit;
	}
}
