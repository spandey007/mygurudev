package com.infocepts.otc.repositories;

import java.util.List;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import com.infocepts.otc.entities.City;
import java.lang.String;

public interface CityRepository extends CrudRepository<City,Integer>{

	@Override
	public List<City> findAll();
	
	@Query("from City where cityName = :cityName")
	public City findByCityName(@Param("cityName") String cityName);

	@Query("from City where status = 1")
	public List<City> findAllActive();
}
