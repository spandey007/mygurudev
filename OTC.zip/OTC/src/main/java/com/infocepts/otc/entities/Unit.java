package com.infocepts.otc.entities;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import com.infocepts.otc.utilities.LoadConstant;

@Entity
@Table(catalog=LoadConstant.infomaster, schema="[dbo]",name="unit")
public class Unit{

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer unitId;
	private String name;
	private String address;
	//private Integer entityId;	
	private Boolean status;
	private Date createdDate;
	private Date modifiedDate;
	private Integer createdBy;
	private Integer modifiedBy;
	private String cin;
	private String pan;
	private String iecCode;
	private Integer hrmsId;
	
	@ManyToOne
	@JoinColumn(name="entityId")
	private Entities entity;
	
	private String unitName;
	private Integer stateId;
	private String phoneNo;
	private String email;
	private String isp;
	private String gstNo; 
	private String lutNo;
	private String letterOfApprovalNo;
	
	public Integer getUnitId() {
		return unitId;
	}
	public void setUnitId(Integer unitId) {
		this.unitId = unitId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Entities getEntity() {
		return entity;
	}
	public void setEntity(Entities entity) {
		this.entity = entity;
	}
	public Boolean getStatus() {
		return status;
	}
	public void setStatus(Boolean status) {
		this.status = status;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public Date getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public Integer getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}
	public Integer getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public String getCin() {
		return cin;
	}
	public void setCin(String cin) {
		this.cin = cin;
	}
	public String getPan() {
		return pan;
	}
	public void setPan(String pan) {
		this.pan = pan;
	}
	public String getIecCode() {
		return iecCode;
	}
	public void setIecCode(String iecCode) {
		this.iecCode = iecCode;
	}
	public String getUnitName() {
		return unitName;
	}
	public void setUnitName(String unitName) {
		this.unitName = unitName;
	}
	public Integer getStateId() {
		return stateId;
	}
	public void setStateId(Integer stateId) {
		this.stateId = stateId;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getIsp() {
		return isp;
	}
	public void setIsp(String isp) {
		this.isp = isp;
	}
	public Integer getHrmsId() {
		return hrmsId;
	}
	public void setHrmsId(Integer hrmsId) {
		this.hrmsId = hrmsId;
	}
	public String getGstNo() {
		return gstNo;
	}
	public void setGstNo(String gstNo) {
		this.gstNo = gstNo;
	}
	public String getLutNo() {
		return lutNo;
	}
	public void setLutNo(String lutNo) {
		this.lutNo = lutNo;
	}
	public String getLetterOfApprovalNo() {
		return letterOfApprovalNo;
	}
	public void setLetterOfApprovalNo(String letterOfApprovalNo) {
		this.letterOfApprovalNo = letterOfApprovalNo;
	}
	

}
