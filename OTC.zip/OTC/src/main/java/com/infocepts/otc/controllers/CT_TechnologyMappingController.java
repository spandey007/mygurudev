package com.infocepts.otc.controllers;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.infocepts.otc.entities.CT_TechnologyMapping;
import com.infocepts.otc.entities.InfoCab;
import com.infocepts.otc.repositories.CT_TechnologyMappingRepository;
import com.infocepts.otc.services.TimesheetService;

@RestController
@RequestMapping(value="/technologyMapping",headers="referer")
public class CT_TechnologyMappingController {
	
	final Logger logger = Logger.getLogger(CT_TechnologyMappingController.class.getName());
	
	@Autowired
	CT_TechnologyMappingRepository ct_TechnologyMappingRepository;
	
	@Autowired
	TimesheetService service;
	
	@PersistenceContext(unitName = "otc")
	private EntityManager manager;
	
	@RequestMapping(method=RequestMethod.POST)
	public CT_TechnologyMapping addCT_TechnologyMapping(@RequestBody CT_TechnologyMapping cT_TechnologyMapping){
		cT_TechnologyMapping.setTechnologyMappingId(null);
		Boolean isAValidCall = false;
		if(service.isHR() || service.isAdmin())
		{
			isAValidCall = true;
		}
		if(isAValidCall) {
			
			ct_TechnologyMappingRepository.save(cT_TechnologyMapping);
		}
		return cT_TechnologyMapping;
	}
	
	@RequestMapping(method=RequestMethod.GET)
	public List<CT_TechnologyMapping> getCT_TechnologyMapping(@RequestParam(value = "gradeId", defaultValue = "0") Integer gradeId	
			,@RequestParam(value = "technologyId", defaultValue = "0") Integer technologyId){
		List<CT_TechnologyMapping> list = null;
		logger.info("gradeId="+gradeId);
		logger.info("technologyId="+technologyId);
		
		if(gradeId != 0 && technologyId != 0){ // list for normal user
			list = manager.createNamedQuery("getMappingsByGradeAndRole",CT_TechnologyMapping.class)					
					.setParameter("gradeId", gradeId)
					.setParameter("technologyId", technologyId)
					.getResultList();
		}
		else 
		{
			System.out.println("inside tech mapping list");
			list = manager.createNamedQuery("getAllMapping",CT_TechnologyMapping.class)
					.getResultList();
		}
		return list;
	}
	
	@RequestMapping(value="/{technologyMappingId}",method=RequestMethod.GET)
	public CT_TechnologyMapping getCT_TechnologyMapping(@PathVariable Integer technologyMappingId){
		CT_TechnologyMapping cT_TechnologyMapping = null;
		Boolean isAValidCall = false;
		if(service.isHR() || service.isAdmin())
		{
			isAValidCall = true;
		}
		if(isAValidCall) {
			
			cT_TechnologyMapping = ct_TechnologyMappingRepository.findOne(technologyMappingId);
		}
		return cT_TechnologyMapping;
	}
	
	@RequestMapping(value="/{technologyMappingId}", method=RequestMethod.PUT)
	public CT_TechnologyMapping updateCT_TechnologyMapping(@PathVariable Integer technologyMappingId,  @RequestBody CT_TechnologyMapping updatedCT_TechnologyMapping){
		updatedCT_TechnologyMapping.setTechnologyMappingId(technologyMappingId);
		Boolean isAValidCall = false;
		if(service.isHR() || service.isAdmin())
		{
			isAValidCall = true;
		}
		if(isAValidCall) {
			ct_TechnologyMappingRepository.save(updatedCT_TechnologyMapping);
		}
		return updatedCT_TechnologyMapping;
	}
	
	@RequestMapping(value="/{technologyMappingId}",method=RequestMethod.DELETE)
	public void deleteCT_TechnologyMapping(@PathVariable Integer technologyMappingId){
		Boolean isAValidCall = false;
		if(service.isHR() || service.isAdmin())
		{
			isAValidCall = true;
		}
		if(isAValidCall) {
			ct_TechnologyMappingRepository.delete(technologyMappingId);
		}
	}
}

