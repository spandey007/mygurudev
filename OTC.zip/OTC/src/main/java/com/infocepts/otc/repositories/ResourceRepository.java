package com.infocepts.otc.repositories;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.persistence.EntityManager;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.infocepts.otc.entities.Resource;
import com.infocepts.otc.utilities.LoadConstant;


public interface ResourceRepository extends JpaRepository<Resource,Integer>{

	@Override
	public List<Resource> findAll();
	
	@Query("select r from Resource r where disabled=0")
	public List<Resource> findAllActive();

	@Query("select r.empId from Resource r where disabled=0 and uid = :uid")
	public Integer findEmpIdByUid(@Param(value = "uid")int uid);

	@Query("select r from Resource r where r.email like CONCAT(:username, '@infocepts.com') and disabled=0")
	public Resource findResourceByUsername(@Param(value = "username") String username);

	@Query("select r from Resource r where r.uid = :uid and disabled=0")
	public Resource findResourceById(@Param(value = "uid") Integer uid);
	
	@Query("select r from Resource r where r.timesheetDelegatesId = :tsDelegateId and disabled=0")
	public List<Resource> findResourceByDelegateId(@Param(value = "tsDelegateId") Integer tsDelegateId);

    @Query("select r from Resource r where r.uid = :uid and disabled=0")
    Resource findResourcebyUid(@Param(value = "uid") Integer uid);

	@Query("select r.email from Resource r where r.uid = :uid")
	String findEmailByUid(@Param(value = "uid") Integer uid);
	
	@Query("select r from Resource r where r.grade.gradeId >= :gradeId and disabled=0")
	public List<Resource> findResourceByGradeId(@Param(value = "gradeId") Integer gradeId);
	
	@Query("FROM Resource WHERE uid=:uid")
	String findResourceByUid(@Param(value = "uid") Integer uid);
	
	@Query("select r.title from Resource r where uid=:uid and disabled = :disabled")
	String findResourceNameByUid(@Param(value = "uid") Integer uid, @Param(value = "disabled") Integer disabled);
	
	@SuppressWarnings("unchecked")
	default List<Map<Integer, String>> getResourceMap(EntityManager manager) {
		final Logger logger = Logger.getLogger(ResourceRepository.class.getName());
		List<Map<Integer, String>> resourceList = new ArrayList<>();
		String queryString = "select new map(r.uid, r.title) from Resource r where r.disabled=0 order by r.title";
		try {
			javax.persistence.Query resourceQuery = manager.createQuery(queryString);
			resourceList.addAll(resourceQuery.getResultList());
		} catch (Exception e) {
			logger.log(Level.WARNING, "SOMETHING WENT WRONG WHILE FETCHING RESOURCE MAP!", e);
		}
		return resourceList;
	}
	
	@SuppressWarnings("unchecked")
	default List<Map<String, String>> getResourceMap(EntityManager manager, Integer uid) {
		final Logger logger = Logger.getLogger(ResourceRepository.class.getName());
		List<Map<String, String>> resourceList = new ArrayList<>();
		String queryString = "select new map(r.uid, r.title) from Resource r where r.disabled=0 and r.uid=:uid";
		try {
			javax.persistence.Query resourceQuery = manager.createQuery(queryString).setParameter("uid", uid);
			resourceList.addAll(resourceQuery.getResultList());
		} catch (Exception e) {
			logger.log(Level.WARNING, "SOMETHING WENT WRONG WHILE FETCHING RESOURCE MAP!", e);
		}
		return resourceList;
	}
	
	@SuppressWarnings("unchecked")
	default List<Map<Object, Object>> getApprovers(EntityManager manager, Integer gradeNo) {
		final Logger logger = Logger.getLogger(ResourceRepository.class.getName());
		List<Map<Object, Object>> resourceList = new ArrayList<>();
		String queryString = "select r.uid, r.title from " + LoadConstant.infomaster + ".[dbo].[resource] r"
				+ " inner join " + LoadConstant.infomaster + ".[dbo].[grade] g on g.gradeId = r.gradeId and convert(int, g.gradeNo) > :gradeNo order by r.title";
		try {
			javax.persistence.Query resourceQuery = manager.createNativeQuery(queryString, "getApprovers").setParameter("gradeNo", gradeNo);
			List<Object[]> resultList = resourceQuery.getResultList();
			resultList.forEach(object -> {
				Map<Object, Object> dataMap = new HashMap<>();
				dataMap.putIfAbsent("uid", (Integer) object[0]);
				dataMap.putIfAbsent("ownerName", (String) object[1]);
				resourceList.add(dataMap);
			});
		} catch (Exception e) {
			logger.log(Level.WARNING, "SOMETHING WENT WRONG WHILE FETCHING RESOURCE MAP!", e);
		}
		return resourceList;
	}
	
}
