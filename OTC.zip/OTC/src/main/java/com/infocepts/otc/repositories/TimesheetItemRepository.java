package com.infocepts.otc.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.infocepts.otc.entities.Timesheet;
import com.infocepts.otc.entities.TimesheetItem;
import com.infocepts.otc.entities.TimesheetPeriods;



@Repository
public interface TimesheetItemRepository extends JpaRepository<TimesheetItem,Integer>{

	@Override
	public List<TimesheetItem> findAll();
	
	@Query("select tsi FROM TimesheetItem tsi where tsi.timesheet.timesheetId = :timesheetId")
	public List<TimesheetItem> findTimesheetsItemByTimesheetId(@Param("timesheetId") Integer timesheetId);
	
	@Query("select tsi FROM TimesheetItem tsi where tsi.tsitemId = :tsitemId")
	public TimesheetItem findTsitemByTsitemId(@Param("tsitemId") Integer tsitemId);
	
	@Query("FROM Timesheet WHERE periodId = :periodId AND uid = :uid")
	public Timesheet findTimesheet(@Param("periodId") Integer periodId, @Param("uid") Integer uid);
	
	@Query("FROM TimesheetPeriods WHERE periodId = :periodId")
	public TimesheetPeriods findTimesheetPeriods(@Param("periodId") Integer periodId);
}
