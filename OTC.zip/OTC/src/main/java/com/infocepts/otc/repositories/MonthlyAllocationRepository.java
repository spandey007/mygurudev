package com.infocepts.otc.repositories;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.infocepts.otc.entities.City;
import com.infocepts.otc.entities.MonthlyAllocation;
import com.infocepts.otc.utilities.LoadConstant;



public interface MonthlyAllocationRepository extends JpaRepository<MonthlyAllocation, Integer>{
	
	@Override
	public List<MonthlyAllocation> findAll();
	
	@Transactional
	@Modifying
	@Query(value = "DELETE FROM monthly_allocation WHERE alcId=:alcId", nativeQuery = true)
	void deleteMonthlyAllocationByAllocationId(@Param(value = "alcId") Integer alcId);
	
	@Transactional
	@Modifying
	@Query(value =	"UPDATE monthly_allocation "+
					"SET alcHrs = (case when 1=:type then alcHrs-8 else alcHrs+8 end) "+
					"WHERE "+
					"prdMonth = month(:date) "+
					"AND "+
					"prdYear = year(:date) "+
					"AND "+
					"alcStartDate <= :date "+
					"AND "+
					"alcEndDate >= :date "+
					"AND "+
					"uid in (select uid from "+ LoadConstant.infomaster +".dbo.resource where HolidayScheduleID = :holidayScheduleId)", nativeQuery = true)
	void updateAllocatioHoursByHoliday(@Param(value = "holidayScheduleId") Integer holidayScheduleId,@Param(value = "date") Date date,@Param(value = "type") Integer type);//type: 1-Subtract 8 hours, 0 - Add 8 hours
	
}
