package com.infocepts.otc.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.SqlResultSetMappings;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.infocepts.otc.utilities.LoadConstant;

@Entity
@Table(catalog=LoadConstant.infomaster,schema="[dbo]",name="accounts")
@SqlResultSetMappings({
	@SqlResultSetMapping(
	      name = "accounts_list",
	      classes = {
	          @ConstructorResult(
	              targetClass = Account.class,
	              columns = {	
	            	  @ColumnResult(name = "itemId"),
	            	  @ColumnResult(name = "accountNo",type=String.class),
	                  @ColumnResult(name = "title",type=String.class),
	                  @ColumnResult(name = "accountShortName",type=String.class),
	                  @ColumnResult(name = "status",type=String.class),
	                  @ColumnResult(name = "dmId",type=Integer.class),
	                  @ColumnResult(name = "deliveryManager",type=String.class),
	                  @ColumnResult(name = "rmId",type=Integer.class),	                  
	                  @ColumnResult(name = "relationshipManager",type=String.class),
	                  @ColumnResult(name = "street",type=String.class),
	                  @ColumnResult(name = "street2",type=String.class),
	                  @ColumnResult(name = "city",type=String.class),
	                  @ColumnResult(name = "state",type=String.class),
	                  @ColumnResult(name = "zipCode",type=String.class),
	                  @ColumnResult(name = "country",type=String.class),
	                  @ColumnResult(name = "website",type=String.class),
	                  @ColumnResult(name = "phone",type=String.class),
	                  @ColumnResult(name = "startDate",type=Date.class),
	                  @ColumnResult(name = "endDate",type=Date.class),
	                  @ColumnResult(name = "accountType",type=String.class),
	                  @ColumnResult(name = "regionId"),
	                  @ColumnResult(name = "region",type=String.class),
	                  @ColumnResult(name = "domain",type=String.class),
	                  @ColumnResult(name = "paymentTermDays",type=Integer.class),
	                  @ColumnResult(name = "strategic",type=String.class),
	                  @ColumnResult(name = "createdBy"),
	                  @ColumnResult(name = "createdDate",type=Date.class),
	                  @ColumnResult(name = "modifiedBy"),
	                  @ColumnResult(name = "modifiedDate",type=Date.class),
	                  @ColumnResult(name = "parentId"),
	                  
	                  @ColumnResult(name = "crmId",type=String.class),
	                  @ColumnResult(name = "msaNumber"),
	                  @ColumnResult(name = "countryId"),
	                  @ColumnResult(name = "portfolioId"),
	                  @ColumnResult(name = "ahId",type=Integer.class),
	            	  @ColumnResult(name = "hubspotId",type=String.class)
	            	  
	                  
	              }
	          )
	      }
	),
	@SqlResultSetMapping(
		      name = "accounts_dropdown_list",
		      classes = {
		          @ConstructorResult(
		              targetClass = Account.class,
		              columns = {	
		            	  @ColumnResult(name = "itemId"),
		            	  @ColumnResult(name = "accountNo",type=String.class),
		                  @ColumnResult(name = "title",type=String.class),
		                  @ColumnResult(name = "accountShortName",type=String.class)
		              }
		          )
		      }
		),
	@SqlResultSetMapping(
		      name = "accounts_by_ah",
		      classes = {
		          @ConstructorResult(
		              targetClass = Account.class,
		              columns = {	
		            	  @ColumnResult(name = "ahId")
		              }
		          )
		      }
		),
		@SqlResultSetMapping(name = "fetchInternalAccounts", columns = {
				@ColumnResult(name = "accountId"),
				@ColumnResult(name = "accountName"), 
		})
})

	@NamedNativeQueries({    
	    @NamedNativeQuery(
	            name    =   "getAllAccounts",
	            query   =  	" select pa.*, rDm.title as deliveryManager, rRm.title as relationshipManager, r.regionName as region"+
						   	" from "+ LoadConstant.infomaster +".[dbo].[accounts] pa"+
						   	" LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[resource] rDm on rDm.uid = pa.dmId "+
	                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[resource] rRm on rRm.uid = pa.rmId "+
	                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[region] r on r.regionId = pa.regionId "+
						   	" where hubspotId is not null "+
	                        " order by pa.itemId DESC",	             
	                        resultClass=Account.class,  resultSetMapping = "accounts_list"  
	    				),
	    @NamedNativeQuery(
	            name    =   "getLatestAccounts",
	            query   =  	" select TOP 10 pa.*, rDm.title as deliveryManager, rRm.title as relationshipManager, r.regionName as region"+
	            			" from "+ LoadConstant.infomaster +".[dbo].[accounts] pa"+
	            			" LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[resource] rDm on rDm.uid = pa.dmId "+
	                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[resource] rRm on rRm.uid = pa.rmId "+
	                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[region] r on r.regionId = pa.regionId "+
						    " where pa.status = 'Active'"+
						    " order by pa.itemId DESC",	             
	                        resultClass=Account.class,  resultSetMapping = "accounts_list"  
	    				),
	    @NamedNativeQuery(
	            name    =   "getAccountsByItemId",
	            query   =  	" select pa.*, rDm.title as deliveryManager, rRm.title as relationshipManager, r.regionName as region"+
						    " from "+ LoadConstant.infomaster +".[dbo].[accounts] pa"+
						    " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[resource] rDm on rDm.uid = pa.dmId "+
	                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[resource] rRm on rRm.uid = pa.rmId "+
	                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[region] r on r.regionId = pa.regionId "+
						    " where pa.itemId =:itemId",	             
	                        resultClass=Account.class,  resultSetMapping = "accounts_list"  
	    				),
	    @NamedNativeQuery(
	            name    =   "getAllAccountsDropDown",
	            query   =  	" select itemId, accountNo, title, accountShortName"+ 
						    " from "+ LoadConstant.infomaster +".[dbo].[accounts]"+
						    " WHERE ((:status = '' AND status != 'Dormant') OR (status = :status))"+
						    " order by title",             
	                        resultClass=Account.class,  resultSetMapping = "accounts_dropdown_list"  
	    				)
	    ,
	    @NamedNativeQuery(
	            name    =   "getAccountbyIdforAH",
	            query   =  	" select top 1 ahId "+ 
						    " from "+ LoadConstant.infomaster +".[dbo].[accounts]"+
						    " WHERE ahId = :uid",           
	                        resultClass=Account.class,  resultSetMapping = "accounts_by_ah"  
	    				)
})
public class Account {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer itemId;
	
	private String accountNo;
	private String title;
	 
	private Integer dmId;
	private Integer rmId;
	private Integer ahId;
	

	@Column(columnDefinition = "varchar(MAX)")
	private String accountShortName;	  
	private String status;
	
	private Date startDate ;
	private Date endDate ;
	  
	@Transient
	private String deliveryManager ;
	  
	@Transient
	private String relationshipManager ;

    @Column(columnDefinition = "varchar(MAX)")
	private String street;
    @Column(columnDefinition = "varchar(MAX)")
	private String street2;
	private String city;
	private String state;
	private String zipCode;
	private String country;
    @Column(columnDefinition = "varchar(MAX)")
	private String website;
	private String phone;
	
	private Integer regionId;
	@Transient
	private String region;
	
	private String contactName; // client contact name
	private String email; // client email
	  
	private String accountType;	  
	private String domain ;
	  
	private Integer createdBy;
	private Date createdDate;
	private Integer modifiedBy;
	private Date modifiedDate;
	
	private Integer paymentTermDays; 
	private String strategic;
	
	private Integer parentId;
	
	private String crmId;
	private Integer msaNumber;
	private Integer countryId;
	private Integer portfolioId;
	private String hubspotId;
	
	//Getter and Setter
    public Integer getItemId() {
		return itemId;
	}
	public void setItemId(Integer itemId) {
		this.itemId = itemId;
	}
	
	public String getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getAccountShortName() {
		return accountShortName;
	}
	public void setAccountShortName(String accountShortName) {
		this.accountShortName = accountShortName;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
    public Integer getDmId() {
		return dmId;
	}
	public void setDmId(Integer dmId) {
		this.dmId = dmId;
	}		
    public Integer getRmId() {
		return rmId;
	}
	public void setRmId(Integer rmId) {
		this.rmId = rmId;
	}
	@Transient
	public String getDeliveryManager() {
		return deliveryManager;
	}
	public void setDeliveryManager(String deliveryManager) {
		this.deliveryManager = deliveryManager;
	}
	@Transient
	public String getRelationshipManager() {
		return relationshipManager;
	}
	public void setRelationshipManager(String relationshipManager) {
		this.relationshipManager = relationshipManager;
	}	
	
	public String getStreet() {
		return street;
	}
	public void setStreet(String street) {
		this.street = street;
	}
	public String getStreet2() {
		return street2;
	}
	public void setStreet2(String street2) {
		this.street2 = street2;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getZipCode() {
		return zipCode;
	}
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getWebsite() {
		return website;
	}
	public void setWebsite(String website) {
		this.website = website;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public Integer getRegionId() {
		return regionId;
	}
	public void setRegionId(Integer regionId) {
		this.regionId = regionId;
	}
	@Transient
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getDomain() {
		return domain;
	}
	public void setDomain(String domain) {
		this.domain = domain;
	}
	public Integer getPaymentTermDays() {
		return paymentTermDays;
	}
	public void setPaymentTermDays(Integer paymentTermDays) {
		this.paymentTermDays = paymentTermDays;
	}
	  
	public String getStrategic() {
		return strategic;
	}
	public void setStrategic(String strategic) {
		this.strategic = strategic;
	}
	public Integer getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}
	
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	};	
	
	public Integer getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public Date getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	
	
	public String getContactName() {
		return contactName;
	}
	public void setContactName(String contactName) {
		this.contactName = contactName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Integer getParentId() {
		return parentId;
	}
	public void setParentId(Integer parentId) {
		this.parentId = parentId;
	}
	
	public String getCrmId() {
		return crmId;
	}
	public void setCrmId(String crmId) {
		this.crmId = crmId;
	}
	public Integer getMsaNumber() {
		return msaNumber;
	}
	public void setMsaNumber(Integer msaNumber) {
		this.msaNumber = msaNumber;
	}
	public Integer getCountryId() {
		return countryId;
	}
	public void setCountryId(Integer countryId) {
		this.countryId = countryId;
	}
	public Integer getPortfolioId() {
		return portfolioId;
	}
	public void setPortfolioId(Integer portfolioId) {
		this.portfolioId = portfolioId;
	}

	public Integer getAhId() {
		return ahId;
	}
	public void setAhId(Integer ahId) {
		this.ahId = ahId;
	}
	
	public String getHubspotId() {
		return hubspotId;
	}
	public void setHubspotId(String hubspotId) {
		this.hubspotId = hubspotId;
	}
	//End of: Getter and Setter
	
	//Constructors
	public Account() {
	}	
	
	public Account(Integer itemId, String accountNo, String title, String accountShortName, String status, 
			Integer dmId, String deliveryManager, Integer rmId, String relationshipManager,
			String street, String street2, String city, String state, String zipCode, String country, String website,
			String phone, Date startDate, Date endDate, String accountType, Integer regionId, String region, String domain,
			Integer paymentTermDays, String strategic,
			Integer createdBy, Date createdDate, Integer modifiedBy, Date modifiedDate, Integer parentId,
			String crmId, Integer msaNumber, Integer countryId, Integer portfolioId, Integer ahId, String hubspotId)
			{
		
		this.itemId = itemId;
		this.accountNo = accountNo;
		this.title = title;
		this.accountShortName = accountShortName;
		this.status = status;
		
		this.startDate = startDate;
		this.endDate = endDate;
		
		this.dmId = dmId;		
		this.deliveryManager = deliveryManager;
		this.rmId = rmId;		
		this.relationshipManager = relationshipManager;
		
		this.street = street;
		this.street2 = street2;
		this.city = city;
		this.state = state;
		this.zipCode = zipCode;
		this.country = country;
		this.website = website;
		this.phone = phone;	
		
		this.accountType = accountType;
		this.region = region;
		this.domain = domain;
		this.paymentTermDays = paymentTermDays;
		this.strategic = strategic;
		
		this.createdBy = createdBy;
		this.createdDate = createdDate;
		this.modifiedBy = modifiedBy;
		this.modifiedDate = modifiedDate;
		this.parentId = parentId;
		this.crmId = crmId;
		this.msaNumber = msaNumber;
		this.countryId = countryId;
		this.portfolioId = portfolioId;
		this.ahId = ahId;
		this.hubspotId = hubspotId;
	}
	
	//Constructor for Account Dropdown list
	public Account(Integer itemId, String accountNo, String title, String accountShortName) {

		this.itemId = itemId;
		this.accountNo = accountNo;
		this.title = title;
		this.accountShortName = accountShortName;
	}
	//End of: Constructors

	//Constructor for AhId check
	public Account(Integer ahId) {
		this.ahId = ahId;
	}
		//End of: Constructors
}
