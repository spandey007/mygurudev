package com.infocepts.otc.controllers;

import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.infocepts.otc.entities.Holidays;
import com.infocepts.otc.repositories.HolidaysRepository;
import com.infocepts.otc.repositories.MonthlyAllocationRepository;
import com.infocepts.otc.services.TimesheetService;



@RestController
@RequestMapping(value="/holidays",headers="referer")//JV: Added 'headers' param to validate the url.
public class HolidaysController {
	
	final Logger logger = Logger.getLogger(HolidaysController.class);
	
	@Autowired
	HolidaysRepository repository;
	
	@Autowired
	MonthlyAllocationRepository monthlyAllocationRepository;
	
	@Autowired
	HttpSession session;
	
	@Autowired
	TimesheetService service;
	
	@PersistenceContext(unitName="otc")
    private EntityManager manager;
	
	@RequestMapping(method=RequestMethod.GET)
	public List<Holidays> getHolidays(@RequestParam(value = "country", defaultValue = "0") Integer country,
									  @RequestParam(value = "allItem", defaultValue = "false") boolean allItem,
									  @RequestParam(value = "uid", defaultValue = "0") Integer uid,
									  @RequestParam(value = "periodStart", defaultValue = "") String periodStart,
									  @RequestParam(value = "periodEnd", defaultValue = "") String periodEnd
									  
									  
		) {
		List<Holidays> holidayslist=null;
		try{
			if(country !=0 )
			{
				holidayslist = manager.createNamedQuery("getHolidaysByRegion", Holidays.class)		
						.setParameter("country", country)	
						.getResultList();
			}
			else if(allItem)
			{
				holidayslist = manager.createNamedQuery("getAllHolidays", Holidays.class)		
						.getResultList();
			}
			else if(uid != 0 && !("").equals(periodStart) && !("").equals(periodEnd))
			{
				holidayslist = manager.createNamedQuery("getHolidaysForUserInSelectedPeriod", Holidays.class)		
						.setParameter("uid", uid)	
						.setParameter("periodStart", periodStart)
						.setParameter("periodEnd", periodEnd)
						.getResultList();
			}
			else
			{
				//To get all the holidays
				holidayslist = repository.findAll();
			}
		}
		catch(Exception e){
			logger.error(e);
		}
		return holidayslist;
	}
	
	@RequestMapping(value="/{holidayId}",method=RequestMethod.GET)
	 public Holidays getHolidayIdById(@PathVariable Integer holidayId){
		Holidays holiday=null;
		 try{
			 holiday = repository.findOne(holidayId);
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return holiday;
	 }
	
	@RequestMapping(method=RequestMethod.POST)
	public Holidays addHolidays(@RequestBody Holidays holidays) {
		try{
			if(service.isPmo()){
				repository.save(holidays);
				
				//Update 'allocation hours' in monthly allocation table
				monthlyAllocationRepository.updateAllocatioHoursByHoliday(holidays.getHolidaySchedules().getHolidayScheduleId(),holidays.getDate(),1);
			}
			
		}
		catch(Exception e){
			logger.error(e);
		}
		return holidays;
	}
	
	@RequestMapping(value="/{holidayId}",method=RequestMethod.PUT)
	public Holidays updateHolidays(@PathVariable Integer holidayId,@RequestBody Holidays holidays) {
		try{
			if(service.isPmo()){
				holidays.setHolidayId(holidayId);
				repository.save(holidays);
			}		
		}
		catch(Exception e){
			logger.error(e);
		}
		return holidays;
		 
	}
	
	@RequestMapping(value="/{holidayId}",method=RequestMethod.DELETE)
	public void deleteHolidays(@PathVariable Integer holidayId) {
		try{
			
			if(service.isPmo()){
				//Get holiday using holidayId before deleting
				Holidays holidays = repository.getOne(holidayId);
				
				repository.delete(holidayId);
				
				//Update 'allocation hours' in monthly allocation table
				monthlyAllocationRepository.updateAllocatioHoursByHoliday(holidays.getHolidaySchedules().getHolidayScheduleId(),holidays.getDate(),0);
			}
			
		}
		catch(Exception e){
			logger.error(e);
		}
		 
	}
    
}
