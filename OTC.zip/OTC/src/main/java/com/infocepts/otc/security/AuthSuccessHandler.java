package com.infocepts.otc.security;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.SimpleUrlAuthenticationSuccessHandler;
import org.springframework.stereotype.Component;
import com.infocepts.otc.controllers.AccessLockController;
import com.infocepts.otc.entities.AccessLock;

@Component
public class AuthSuccessHandler extends SimpleUrlAuthenticationSuccessHandler{
	
	@Autowired
	AccessLockController accessLockController;
	
	@Override
	public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response,
			Authentication authentication) throws IOException, ServletException {
		
		// Retrieve the username entered
		String username=request.getParameter("username");
		
		// Check if there is already an entry in the access table for incorrect username and password
		AccessLock loggedInUser = accessLockController.getAccessLock(username);
		if(loggedInUser != null)
		{
			Boolean isLocked = loggedInUser.isLocked();			
			if(isLocked.booleanValue() == false)
			{
				try
				{
					loggedInUser.setCount(0);
					accessLockController.updateAccessLock(loggedInUser, loggedInUser.getAccessLockId());
					super.onAuthenticationSuccess(request, response, authentication);
				}
				catch(Exception e){
					logger.error(e);
				}
			}
		}else{
			super.onAuthenticationSuccess(request, response, authentication);
		}
	}

	
}
