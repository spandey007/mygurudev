package com.infocepts.otc.entities;

import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;

import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.SqlResultSetMappings;

import com.infocepts.otc.utilities.LoadConstant;

@Entity
@Table(catalog=LoadConstant.otc, schema="[dbo]", name="allocation")
@SqlResultSetMappings({
	@SqlResultSetMapping(
	      name = "alc_with_project",
	      classes = {
	    	@ConstructorResult(
	              targetClass = Allocation.class,
	              columns = {
	                  @ColumnResult(name = "alcId"),
	                  @ColumnResult(name = "projectId"),
	                  @ColumnResult(name = "uid"),	                  
	                  @ColumnResult(name = "alcStartDate", type=Date.class),
	                  @ColumnResult(name = "alcEndDate", type=Date.class),
	                  @ColumnResult(name = "alcType"),	  
	                  @ColumnResult(name = "alcFte", type=BigDecimal.class),
	                  @ColumnResult(name = "alcStatus", type=String.class),
	                  @ColumnResult(name = "requisitionId", type=String.class),	                 
	                  @ColumnResult(name = "comments", type=String.class),
	                  @ColumnResult(name = "createdBy"),	
	                  @ColumnResult(name = "createdDate", type=Date.class),
	                  @ColumnResult(name = "modifiedBy"),	
	                  @ColumnResult(name = "modifiedDate", type=Date.class),
	                  @ColumnResult(name = "bucketId", type=Integer.class),
	                  @ColumnResult(name = "sowDetailId", type=Integer.class),
	                  @ColumnResult(name = "cmsDetailId", type=Integer.class),
	                  @ColumnResult(name = "projectName", type=String.class),
            		  @ColumnResult(name = "resourceName", type=String.class),
            		  @ColumnResult(name = "sowRoleName", type=String.class),
            		  @ColumnResult(name = "sowRoleStartDate", type=Date.class),
	                  @ColumnResult(name = "sowRoleEndDate", type=Date.class),
	                  @ColumnResult(name = "accountName", type=String.class),
	                  @ColumnResult(name = "skillName", type=String.class),
	                  @ColumnResult(name = "reqStartDate", type=Date.class),
	                  @ColumnResult(name = "reqEndDate", type=Date.class),
	                  @ColumnResult(name = "priority", type=String.class),
	                  @ColumnResult(name = "treqId"),
	                  @ColumnResult(name = "treqStatus", type=String.class),
	                  @ColumnResult(name = "countryName", type=String.class),
	                  @ColumnResult(name = "unitName", type=String.class),
	                  @ColumnResult(name = "billingTypeId"),
	                  @ColumnResult(name = "sowComments", type=String.class),
	                  @ColumnResult(name = "documentTypeId"),
	                  @ColumnResult(name = "documentTypeName", type=String.class),
	                  @ColumnResult(name = "existingAssociateName", type=String.class)
	              }
	          )
	      }
	),
	@SqlResultSetMapping(
		      name = "alc_with_SowDetailId",
		      classes = {
		          @ConstructorResult(
		              targetClass = Allocation.class,
		              columns = {
		                  @ColumnResult(name = "uid"), 
		                  @ColumnResult(name = "sowDetailId"),
		                  @ColumnResult(name = "resourceName", type=String.class)
		                }
		          )
		      }
		),
	@SqlResultSetMapping(
		      name = "alc_with_allocated_hrs",
		      classes = {
		          @ConstructorResult(
		              targetClass = Allocation.class,
		              columns = {
		                  @ColumnResult(name = "alcId"),
		                  @ColumnResult(name = "alcFte", type=BigDecimal.class),
		                  @ColumnResult(name = "alcStartDate", type=Date.class),
		                  @ColumnResult(name = "alcEndDate ", type=Date.class),
		                  @ColumnResult(name = "projectName", type=String.class),
		                  @ColumnResult(name = "resourceName", type=String.class),
		                  @ColumnResult(name = "billableAllocHrs", type=BigDecimal.class),
		                  @ColumnResult(name = "nonBillableAllocHrs", type=BigDecimal.class)
		                }
		          )
		      }
		)
})
@NamedNativeQueries({
	@NamedNativeQuery(
	            name    	=   "getAllAllocation",
	            query   	=   "select al.*," +
	            				" cast(p.title as varchar) as projectName,p.billingTypeId as billingTypeId, cast(r.title as varchar) as resourceName,"+
	            				" obj_amgRoles.amgRoleName as sowRoleName, sd.sowRoleStartDate, sd.sowRoleEndDate, acc.title as accountName,"+
	            				" s.skillName as skillName, t.reqStartDate as reqStartDate, t.reqEndDate as reqEndDate, t.priority as priority, t.treqId as treqId, t.status as treqStatus,"+ 
	            				" sd.comments as sowComments,"+
	            				" c.countryName, u.name as unitName,"+
	            				" sow.documentTypeId as documentTypeId, doc.name as documentTypeName, '' as existingAssociateName"+     
	            				" FROM " + LoadConstant.otc + ".[dbo].allocation al"+
	            				" left join " + LoadConstant.infomaster + ".[dbo].project p on p.itemId=al.projectId"+
	            				" left join " + LoadConstant.infomaster + ".[dbo].accounts acc on acc.itemId=p.accountId"+
	            				" left join " + LoadConstant.infomaster + ".[dbo].resource r on r.uid=al.uid"+
	            				" left join " + LoadConstant.otc + ".[dbo].SowDetail sd on sd.sowDetailId = al.sowDetailId"+
	                            " left join " + LoadConstant.otc + ".[dbo].Sow sow on sow.sowId = sd.sowId"+
	                            " left join " + LoadConstant.infomaster + ".[dbo].documentType doc on sow.documentTypeId = doc.documentTypeId"+
	            				" left join " + LoadConstant.otc + ".[dbo].treq t on t.alcId = al.alcId"+	
	            				" left join " + LoadConstant.infomaster + ".[dbo].amgRoles obj_amgRoles on obj_amgRoles.amgRoleId=sd.roleId"+
                				" left join " + LoadConstant.infomaster + ".[dbo].skill s on s.skillId = t.skillId",
	            resultClass = Allocation.class ,  resultSetMapping = "alc_with_project"                          
    ),
    @NamedNativeQuery(
	            name    	=   "getAllocationById",
	            query   	=   "select al.*," +
	            				" cast(p.title as varchar) as projectName,p.billingTypeId as billingTypeId, cast(r.title as varchar) as resourceName,"+
	            				" obj_amgRoles.amgRoleName  as sowRoleName, sd.sowRoleStartDate, sd.sowRoleEndDate, acc.title as accountName,"+
	            				" s.skillName as skillName, t.reqStartDate as reqStartDate, t.reqEndDate as reqEndDate, t.priority as priority, t.treqId as treqId, t.status as treqStatus,"+
	            				" sd.comments as sowComments,"+
	            				" c.countryName, u.name as unitName,"+
	            				" sow.documentTypeId as documentTypeId, doc.name as documentTypeName, '' as existingAssociateName"+     
	        					" FROM " + LoadConstant.otc + ".[dbo].allocation al"+
	            				" left join " + LoadConstant.infomaster + ".[dbo].project p on p.itemId=al.projectId"+
	            				" left join " + LoadConstant.infomaster + ".[dbo].accounts acc on acc.itemId=p.accountId"+
	            				" left join " + LoadConstant.infomaster + ".[dbo].resource r on r.uid=al.uid"+
	            				" left join " + LoadConstant.otc + ".[dbo].SowDetail sd on sd.sowDetailId = al.sowDetailId"+
	                             " left join " + LoadConstant.otc + ".[dbo].Sow sow on sow.sowId = sd.sowId"+
	                             " left join " + LoadConstant.infomaster + ".[dbo].documentType doc on sow.documentTypeId = doc.documentTypeId"+
	            				" left join " + LoadConstant.infomaster + ".[dbo].country c on c.countryId = sd.countryId"+
		            		 	" left join " + LoadConstant.infomaster + ".[dbo].unit u on u.unitId = sd.unitId"+
	            				" left join " + LoadConstant.otc + ".[dbo].treq t on t.alcId = al.alcId"+	
	            				" left join " + LoadConstant.infomaster + ".[dbo].amgRoles obj_amgRoles on obj_amgRoles.amgRoleId=sd.roleId"+
	            				" left join " + LoadConstant.infomaster + ".[dbo].skill s on s.skillId = t.skillId"+
            					" WHERE al.alcId = :alcId",
	            resultClass	=	Allocation.class , resultSetMapping = "alc_with_project"
    ),
    @NamedNativeQuery(
            name    	=   "getAllocationsForProject",
            query   	=   "select al.*," +
            				" cast(p.title as varchar) as projectName,p.billingTypeId as billingTypeId, cast(r.title as varchar) as resourceName,"+
        					" obj_amgRoles.amgRoleName as sowRoleName, sd.sowRoleStartDate, sd.sowRoleEndDate, acc.title as accountName,"+
        					" s.skillName as skillName, t.reqStartDate as reqStartDate, t.reqEndDate as reqEndDate, t.priority as priority, t.treqId as treqId, t.status as treqStatus,"+
        					" sd.comments as sowComments,"+
        					" c.countryName, u.name as unitName,"+        					
        					" sow.documentTypeId as documentTypeId, doc.name as documentTypeName, rc.title as existingAssociateName"+   
    						" FROM " + LoadConstant.otc + ".[dbo].allocation al"+
            				" left join " + LoadConstant.infomaster + ".[dbo].project p on p.itemId=al.projectId"+
            				" left join " + LoadConstant.infomaster + ".[dbo].accounts acc on acc.itemId=p.accountId"+
            				" left join " + LoadConstant.infomaster + ".[dbo].resource r on r.uid=al.uid"+
                             " left join " + LoadConstant.otc + ".[dbo].SowDetail sd on sd.sowDetailId = al.sowDetailId"+
                             " left join " + LoadConstant.otc + ".[dbo].Sow sow on sow.sowId = sd.sowId"+
                             " left join " + LoadConstant.infomaster + ".[dbo].documentType doc on sow.documentTypeId = doc.documentTypeId"+            				
                            " left join " + LoadConstant.infomaster + ".[dbo].country c on c.countryId = sd.countryId"+
	            		 	" left join " + LoadConstant.infomaster + ".[dbo].unit u on u.unitId = sd.unitId"+
            				" left join " + LoadConstant.otc + ".[dbo].treq t on t.alcId = al.alcId"+	
            				" left join " + LoadConstant.infomaster + ".[dbo].amgRoles obj_amgRoles on obj_amgRoles.amgRoleId=sd.roleId"+
            				" left join " + LoadConstant.infomaster + ".[dbo].skill s on s.skillId = t.skillId"+
            				" left join " + LoadConstant.infomaster + ".[dbo].resource rc on rc.uid=t.existingAssociateId"+
        					" WHERE al.projectId = :projectId"+
            				" AND ( ((:alcType > 0 and :alcType < 20) and (al.alcType = :alcType))"+ // Specific type of allocation (billable or non-billable)
        							" OR ((:alcType = 20) and ((al.alcType = 2 OR al.alcType = 3)))"+ // All types of non-billable
        							" OR (:alcType = 0))",
            resultClass	=	Allocation.class , resultSetMapping = "alc_with_project"
	),
    @NamedNativeQuery(
            name    	=   "getSoftAllocationsForAccount",
            query   	=   "select al.*," +
            				" cms.dummyProjectName as projectName, NULL as billingTypeId, cast(r.title as varchar) as resourceName,"+
        					" obj_amgRoles.amgRoleName as sowRoleName, cd.sowRoleStartDate, cd.sowRoleEndDate, acc.title as accountName,"+ 
        					" s.skillName as skillName, t.reqStartDate as reqStartDate, t.reqEndDate as reqEndDate, t.priority as priority, t.treqId as treqId, t.status as treqStatus,"+
        					" '' as sowComments,"+
        					" c.countryName, u.name as unitName,"+
        					" 0 as documentTypeId, '' as documentTypeName, rc.title as existingAssociateName"+   
    						" FROM " + LoadConstant.otc + ".[dbo].allocation al"+
            				" left join " + LoadConstant.infomaster + ".[dbo].resource r on r.uid=al.uid"+
            				" left join " + LoadConstant.otc + ".[dbo].CmsDetail cd on cd.cmsDetailId = al.cmsDetailId"+
            				" left join " + LoadConstant.otc + ".[dbo].cms cms on cms.cmsId = cd.cmsId"+
            				" left join " + LoadConstant.infomaster + ".[dbo].country c on c.countryId = cd.countryId"+
	            		 	" left join " + LoadConstant.infomaster + ".[dbo].unit u on u.unitId = cd.unitId"+
            				" left join " + LoadConstant.infomaster + ".[dbo].accounts acc on acc.itemId = cd.accountId"+
            				" left join " + LoadConstant.otc + ".[dbo].treq t on t.alcId = al.alcId"+
            				" left join " + LoadConstant.infomaster + ".[dbo].amgRoles obj_amgRoles on obj_amgRoles.amgRoleId=cd.roleId"+
            				" left join " + LoadConstant.infomaster + ".[dbo].skill s on s.skillId = t.skillId"+
            				" left join " + LoadConstant.infomaster + ".[dbo].resource rc on rc.uid=t.existingAssociateId"+
        					" WHERE ( (:accountId != 0 and acc.itemId = :accountId) or (:accountId = 0)) "+
            				" AND cd.status != 'Active'"+
        					" AND al.alcStatus = 'InActive' and al.projectId is null"+ // Project Id will be null for all soft allocations
            				" AND ( ((:alcType > 0 and :alcType < 20) and (al.alcType = :alcType))"+ // Specific type of allocation (billable or non-billable)
        							" OR ((:alcType = 20) and ((al.alcType = 2 OR al.alcType = 3)))"+ // All types of non-billable
        							" OR (:alcType = 0))",
            resultClass	=	Allocation.class , resultSetMapping = "alc_with_project"
	),
    @NamedNativeQuery(
            name    	=   "getAllocationsBySowDetailId",
            query   	=   "select Top 1 al.uid, t.sowDetailId, cast(r.title as varchar) as resourceName"+
    						" FROM " + LoadConstant.otc + ".[dbo].allocation al"+
    						" left join " + LoadConstant.otc + ".[dbo].treq t on t.alcId=al.alcId"+
    						" left join " + LoadConstant.infomaster + ".[dbo].resource r on r.uid=al.uid"+
        					" WHERE al.sowDetailId = :sowDetailId and t.treqId < :treqId"+
    						" Order By t.treqId DESC",
            resultClass	=	Allocation.class , resultSetMapping = "alc_with_SowDetailId"
	)
	,
    @NamedNativeQuery(
            name    	=   "getAllocationsWithAllocatedHrs",
            query   	=   "select al.alcId, al.alcFte, al.alcStartDate, al.alcEndDate, p.title as projectName, r.title as resourceName,"+
            				"(SELECT a.alcHrs FROM " + LoadConstant.otc +".[dbo].[monthly_allocation] a where a.projectId= :projectId and a.uid = r.uid and a.prdmonth = :month and a.prdYear= :year  and a.alcType = 1) as billableAllocHrs, " +
            				"(SELECT a.alcHrs FROM " + LoadConstant.otc +".[dbo].[monthly_allocation] a where a.projectId= :projectId and a.uid = r.uid and a.prdmonth = :month and a.prdYear= :year  and a.alcType = 2) as nonBillableAllocHrs" +
            				" FROM " + LoadConstant.otc + ".[dbo].allocation al"+
    						" left join " + LoadConstant.infomaster + ".[dbo].project p on p.itemId=al.projectId"+
    						" left join " + LoadConstant.infomaster + ".[dbo].resource r on r.uid=al.uid"+
    						" left join " + LoadConstant.otc + ".[dbo].monthly_allocation ml on ml.alcId=al.alcId and"+
    						" ml.prdmonth = :month and ml.prdYear= :year" + 
    						" WHERE al.projectId= :projectId and ml.alcType IN (1,2) and ml.prdName is not null",
            resultClass	=	Allocation.class , resultSetMapping = "alc_with_allocated_hrs"
	)     
})

public class Allocation {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)		
	private Integer alcId;
		
	private Integer projectId;
		
	@NotNull
	private Integer uid;
	
	private Date alcStartDate;
	private Date alcEndDate;
	
	private String alcStatus;
	
	@NotNull
	private Integer alcType; // value should be 1 (Billable), 2 (Non Billable), 3 (Non Billable Trainee), 4 (Billed Buffer)
	
	@Transient
	private String alcTypeName;
	
	@NotNull
	private BigDecimal alcFte; // Allocation fte for the selected month
	
	@ManyToOne
	@JoinColumn(name="sowDetailId")
	private SowDetail sowDetail;
	
	@ManyToOne
	@JoinColumn(name="cmsDetailId")
	private CmsDetail cmsDetail;

	private String requisitionId;//need to be mandatory but keep optional for migration

	private String comments;
	
	private Integer createdBy;	
	private Date createdDate;	
	private Integer modifiedBy;
	private Date modifiedDate;
	private Integer bucketId;
	
	@Transient
	private String sowRoleName;
	@Transient
	private Date sowRoleStartDate;
	@Transient
	private Date sowRoleEndDate;
	
	@Transient
	private String unitName;
	
	@Transient
	private String countryName;
	
	@Transient
	private String accountName;
	
	@Transient
	private String projectName;
	
	@Transient
	private String resourceName; // To show account name in case of soft allocations
	
	@Transient
	private String skillName;	
	
	@Transient
	private Date reqStartDate;
	@Transient
	private Date reqEndDate;
	@Transient
	private String priority;
	
	@Transient
	private Integer treqId;
	@Transient
	private String treqStatus;
	
	@Transient
	private boolean updateMonthlyAllocation;//to restrict monthly allocation update only if start date or ebd date changes
	
	@Transient
	private Integer billingTypeId;
	
	@Transient
	private String sowComments;

	@Transient
	private Integer documentTypeId;
	
	@Transient
	private String documentTypeName;	

	@Transient
	private String existingAssociateName;

	@Transient
	private BigDecimal billableAllocHrs;
	
	@Transient
	private BigDecimal nonBillableAllocHrs;

	
	
	/************************Getter Setter Functions******************************************************/
	public Integer getAlcId() {
		return alcId;
	}

	public void setAlcId(Integer alcId) {
		this.alcId = alcId;
	}

	public Integer getProjectId() {
		return projectId;
	}

	public void setProjectId(Integer projectId) {
		this.projectId = projectId;
	}

	public Integer getUid() {
		return uid;
	}

	public void setUid(Integer uid) {
		this.uid = uid;
	}

	public Date getAlcStartDate() {
		return alcStartDate;
	}

	public void setAlcStartDate(Date alcStartDate) {
		this.alcStartDate = alcStartDate;
	}

	public Date getAlcEndDate() {
		return alcEndDate;
	}

	public void setAlcEndDate(Date alcEndDate) {
		this.alcEndDate = alcEndDate;
	}

	public String getAlcStatus() {
		return alcStatus;
	}

	public void setAlcStatus(String alcStatus) {
		this.alcStatus = alcStatus;
	}

	public Integer getAlcType() {
		return alcType;
	}

	public void setAlcType(Integer alcType) {
		this.alcType = alcType;
	}
	
	public BigDecimal getAlcFte() {
		return alcFte;
	}

	public void setAlcFte(BigDecimal alcFte) {
		this.alcFte = alcFte;
	}	

	public SowDetail getSowDetail() {
		return sowDetail;
	}

	public void setSowDetail(SowDetail sowDetail) {
		this.sowDetail = sowDetail;
	}

	public CmsDetail getCmsDetail() {
		return cmsDetail;
	}

	public void setCmsDetail(CmsDetail cmsDetail) {
		this.cmsDetail = cmsDetail;
	}

	public String getRequisitionId() {
		return requisitionId;
	}

	public void setRequisitionId(String requisitionId) {
		this.requisitionId = requisitionId;
	}	

	public Integer getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Integer getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	
	public Integer getBucketId() {
		return bucketId;
	}

	public void setBucketId(Integer bucketId) {
		this.bucketId = bucketId;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}
	
	@Transient
	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	
	@Transient
	public String getResourceName() {
		return resourceName;
	}

	public void setResourceName(String resourceName) {
		this.resourceName = resourceName;
	}
	
	@Transient	
	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}
	
	@Transient
	public String getSkillName() {
		return skillName;
	}

	public void setSkillName(String skillName) {
		this.skillName = skillName;
	}

	@Transient
	public String getAlcTypeName() {
		return alcTypeName;
	}

	public void setAlcTypeName(String alcTypeName) {
		this.alcTypeName = alcTypeName;
	}
	
	@Transient
	public String getSowRoleName() {
		return sowRoleName;
	}

	public void setSowRoleName(String sowRoleName) {
		this.sowRoleName = sowRoleName;
	}
	
	@Transient
	public Date getSowRoleStartDate() {
		return sowRoleStartDate;
	}

	public void setSowRoleStartDate(Date sowRoleStartDate) {
		this.sowRoleStartDate = sowRoleStartDate;
	}

	@Transient
	public Date getSowRoleEndDate() {
		return sowRoleEndDate;
	}

	public void setSowRoleEndDate(Date sowRoleEndDate) {
		this.sowRoleEndDate = sowRoleEndDate;
	}
	@Transient
	public Date getReqStartDate() {
		return reqStartDate;
	}

	public void setReqStartDate(Date reqStartDate) {
		this.reqStartDate = reqStartDate;
	}
	
	@Transient	
	public Date getReqEndDate() {
		return reqEndDate;
	}

	public void setReqEndDate(Date reqEndDate) {
		this.reqEndDate = reqEndDate;
	}
	@Transient
	public String getPriority() {
		return priority;
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}
	
	@Transient
	public Integer getTreqId() {
		return treqId;
	}

	public void setTreqId(Integer treqId) {
		this.treqId = treqId;
	}
	@Transient
	public String getTreqStatus() {
		return treqStatus;
	}

	public void setTreqStatus(String treqStatus) {
		this.treqStatus = treqStatus;
	}

	public String getCountryName() {
		return countryName;
	}

	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}

	public String getUnitName() {
		return unitName;
	}

	public void setUnitName(String unitName) {
		this.unitName = unitName;
	}

	@Transient
	public boolean getUpdateMonthlyAllocation() {
		return updateMonthlyAllocation;
	}

	public void setUpdateMonthlyAllocation(boolean updateMonthlyAllocation) {
		this.updateMonthlyAllocation = updateMonthlyAllocation;
	}

	
	public Integer getBillingTypeId() {
		return billingTypeId;
	}

	public void setBillingTypeId(Integer billingTypeId) {
		this.billingTypeId = billingTypeId;
	}
	
	public String getSowComments() {
		return sowComments;
	}

	public void setSowComments(String sowComments) {
		this.sowComments = sowComments;
	}
		
	public Integer getDocumentTypeId() {
		return documentTypeId;
	}

	public void setDocumentTypeId(Integer documentTypeId) {
		this.documentTypeId = documentTypeId;
	}

	public String getDocumentTypeName() {
		return documentTypeName;
	}

	public void setDocumentTypeName(String documentTypeName) {
		this.documentTypeName = documentTypeName;
	}	

	public String getExistingAssociateName() {
		return existingAssociateName;
	}

	public void setExistingAssociateName(String existingAssociateName) {
		this.existingAssociateName = existingAssociateName;
	}

	


	public BigDecimal getBillableAllocHrs() {
		return billableAllocHrs;
	}

	public void setBillableAllocHrs(BigDecimal billableAllocHrs) {
		this.billableAllocHrs = billableAllocHrs;
	}

	public BigDecimal getNonBillableAllocHrs() {
		return nonBillableAllocHrs;
	}

	public void setNonBillableAllocHrs(BigDecimal nonBillableAllocHrs) {
		this.nonBillableAllocHrs = nonBillableAllocHrs;
	}

	/************************Constructor Functions******************************************************/
	
	public Allocation() {
	} 
	 
	public Allocation(Integer alcId, Integer projectId, Integer uid, Date alcStartDate, Date alcEndDate,
						Integer alcType, BigDecimal alcFte, String alcStatus, String requisitionId, String comments,
						Integer createdBy, Date createdDate, Integer modifiedBy, Date modifiedDate, Integer bucketId,
						Integer sowDetailId, Integer cmsDetailId, String projectName, String resourceName, 
						String sowRoleName, Date sowRoleStartDate, Date sowRoleEndDate, String accountName, String skillName,
						Date reqStartDate, Date reqEndDate, String priority, Integer treqId, String treqStatus, String countryName,
						String unitName, Integer billingTypeId, String sowComments
						, Integer documentTypeId, String documentTypeName, String existingAssociateName
						) 
	{
		
		this.alcId = alcId;
		this.projectId = projectId;
		this.uid = uid;
		this.alcStartDate = alcStartDate;
		this.alcEndDate = alcEndDate;
		this.alcStatus = alcStatus;
		
		this.alcType = alcType;
		if(alcType == 1) this.alcTypeName = "Billable";
		if(alcType == 2) this.alcTypeName = "Non Billable";
		if(alcType == 3) this.alcTypeName = "Non Billable Trainee";
		if(alcType == 4) this.alcTypeName = "Billed Buffer";
		
		this.alcFte = alcFte;
		this.requisitionId = requisitionId;
		
		if(sowDetailId != null)
		{
			this.sowDetail = new SowDetail();
			this.sowDetail.setSowDetailId(sowDetailId);
		}
		if(cmsDetailId != null)
		{
			this.cmsDetail = new CmsDetail();
			this.cmsDetail.setCmsDetailId(cmsDetailId);
		}
		
		this.sowRoleName = sowRoleName;
		this.sowRoleStartDate = sowRoleStartDate;
		this.sowRoleEndDate = sowRoleEndDate;
		
		this.comments = comments;
		this.createdBy = createdBy;
		this.createdDate = createdDate;
		this.modifiedBy = modifiedBy;
		this.modifiedDate = modifiedDate;
		this.bucketId = bucketId;
		
		this.projectName = projectName;
		this.resourceName = resourceName;
		this.accountName = accountName;
		this.skillName = skillName;
		this.reqStartDate = reqStartDate;
		this.reqEndDate = reqEndDate;
		this.priority = priority;
		this.treqId = treqId;
		this.treqStatus = treqStatus;
		this.countryName = countryName;
		this.unitName = unitName;
		this.billingTypeId = billingTypeId;
		this.sowComments = sowComments;
		this.documentTypeId = documentTypeId;
		this.documentTypeName = documentTypeName;
		this.existingAssociateName = existingAssociateName;
	}

	public Allocation(Integer uid, Integer sowDetailId, String resourceName) {
		super();
		this.uid = uid;
		
		if(sowDetailId != null)
		{
		this.sowDetail = new SowDetail();
		this.sowDetail.setSowDetailId(sowDetailId);
		} 
		
		this.resourceName = resourceName;
	}

	public Allocation(Integer alcId, BigDecimal alcFte, Date alcStartDate, Date alcEndDate, String projectName, String resourceName,
			BigDecimal billableAllocHrs, BigDecimal nonBillableAllocHrs) {
		super();
		this.alcId = alcId;
		this.alcFte = alcFte;
		this.alcStartDate = alcStartDate;
		this.alcEndDate = alcEndDate;
		this.projectName = projectName;
		this.resourceName = resourceName;
		this.billableAllocHrs = billableAllocHrs;
		this.nonBillableAllocHrs = nonBillableAllocHrs;

	}

	
	
}
