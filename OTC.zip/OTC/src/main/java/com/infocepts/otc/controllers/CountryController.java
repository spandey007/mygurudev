/* 
 * Country Controller to manage Country
 * -------------------------------------------------------------------------------------------------------------------------
 * 20 Sep 2017 - EW creation of the file
 * 
*/
package com.infocepts.otc.controllers;

import java.util.List;

import javax.mail.MessagingException;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.infocepts.otc.entities.Country;
import com.infocepts.otc.entities.Currency;
import com.infocepts.otc.notification.SmtpMailSender;
import com.infocepts.otc.repositories.CountryRepository;
import com.infocepts.otc.services.TimesheetService;

@RestController
@RequestMapping(value="/country",headers="referer")
public class CountryController {

	final Logger logger = Logger.getLogger(CountryController.class);
	
	@Autowired
	CountryRepository repository;
	
	@Autowired
	TimesheetService service;
	
	@Autowired
	SmtpMailSender smtpMailSender;
	
	@RequestMapping(method=RequestMethod.POST)
	public Country addCountry(@RequestBody Country country, HttpServletRequest request) throws MessagingException{
		try{
			country.setCountryId(null);
			repository.save(country);	
			service.sendCountryNotification(country, "add", request); 
		}catch(Exception e){
			logger.error(e);
		}
		return country;
	}	
 
	 /*@RequestMapping(method=RequestMethod.GET)
	 public List<Country> getAllCountry(@RequestParam(value="status",defaultValue="false") Boolean status,
			 @RequestParam(value="countryId",defaultValue="0") Integer countryId,
			 @RequestParam(value="countryName",defaultValue="") String countryName){
		 List<Country> countrylist=null;
		 try{
			 if(status == true){
				 countrylist = repository.findByCountryStatus(true);
			 }
			 else if(countryId != 0){
				 countrylist = repository.findByCountryId(countryId);
			 }
			 else if(countryName!=""){
				 countrylist = repository.findByCountryName(countryName);
			 }
			 else{
				 countrylist = repository.findAll();
			 }
			 
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return countrylist;
	 }*/
	
	@RequestMapping(method=RequestMethod.GET)
	 public List<Country> getAllCountry(@RequestParam(value = "allItem", defaultValue = "0") Integer allItem){
		 List<Country> countrylist=null;
		 try
		 {
			 if(allItem == 1)
			 {
				 countrylist = repository.findAll();
			 }
			 else{
				 countrylist = repository.findAllActive();
			 }
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return countrylist;
	}
	 
	 @RequestMapping(value="/{countryId}",method=RequestMethod.PUT)
	 public Country updateCountry(@RequestBody Country updatedCountry,@PathVariable Integer countryId){
		 try{
			 updatedCountry.setCountryId(countryId);
			 repository.save(updatedCountry);
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return updatedCountry;
	 }
	 
	 @RequestMapping(value="/{countryId}",method=RequestMethod.DELETE)
	 public void deleteCountry(@PathVariable Integer countryId){
		 try{
			 repository.delete(countryId);
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
	 }
	 @GetMapping("/getCountries")
		public List<Country> getCountries(@RequestParam(value = "allItem", defaultValue = "0") Integer allItem) {
		 List<Country> countrylist=null;
		 try
		 {
			 if(allItem == 1)
			 {
				 countrylist = repository.findAll();
			 }
			 else{
				 countrylist = repository.findAllActive();
			 }
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return countrylist;

		}
}
