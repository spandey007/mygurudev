/**
* Filename: /src/main/java/com/infocepts/otc/controllers/PmsCompetencyController.java
* @author  SRA
* @version 1.0
* @since   2018-08-01 
*/

package com.infocepts.otc.controllers;

import java.util.logging.Logger;
import com.infocepts.pms.entities.PmsCompetency;
import com.infocepts.pms.entities.PmsPerformance;
import com.infocepts.pms.entities.PmsResource;
import com.infocepts.pms.repositories.PmsCompetencyClusterRepository;
import com.infocepts.pms.repositories.PmsCompetencyMasterRepository;
import com.infocepts.pms.repositories.PmsCompetencyRepository;
import com.infocepts.pms.repositories.PmsResourceRepository;
import com.infocepts.otc.services.PmsService;
import com.infocepts.otc.services.TimesheetService;
import com.infocepts.otc.utilities.ExportUtil;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.mail.MessagingException;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.io.File;
import java.io.FileNotFoundException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

@RestController
@RequestMapping(value="/api/pms/competency",headers="referer")
public class PmsCompetencyController {

    final Logger logger = Logger.getLogger(PmsCompetencyController.class.getName());

    @Autowired
    PmsCompetencyRepository pmsCompetencyRepository;
    
    @Autowired
    PmsCompetencyClusterRepository pmsCompetencyClusterRepository;
    
    @Autowired
    PmsCompetencyMasterRepository pmsCompetencyMasterRepository;
    
    @Autowired
    PmsResourceRepository pmsResourceRepository;
    
    @Autowired
    HttpSession session;

    @PersistenceContext(unitName = "pms") 
    private EntityManager manager;
	
	@Autowired
	TimesheetService service;
	
	@Autowired
	PmsService pmsService;
	
	@Autowired
	ExportUtil exportUtil;
	
	String path=null;
	String filepath="";	

	/**
   * This method is used to find results set from module entity
   * based on params passed from JS file
   */
    @RequestMapping(method = RequestMethod.GET)
    public List<PmsCompetency> findAllPmsCompetency(@RequestParam(value = "performanceId", defaultValue = "0") Integer performanceId ,
    												@RequestParam(value = "cycleId", defaultValue = "0") Integer cycleId,
    												@RequestParam(value = "isAssociate", defaultValue = "0") Integer isAssociate,
    												@RequestParam(value = "isManager", defaultValue = "0") Integer isManager
            						, HttpServletRequest request){
        List<PmsCompetency> pmsCompetencyList = null;
        
        logger.info("--------------------in <ModuleName> controller------------------");		
		logger.info("performanceId="+performanceId);
	
        try {
        	
        	Integer uid=(Integer)session.getAttribute("loggedInUid");
        	
        	
        	if(isAssociate != 0){
        		pmsCompetencyList = manager.createNamedQuery("getCompetencyByUserAndPerformanceId", PmsCompetency.class)                        
                        .setParameter("performanceId", performanceId)
                        .setParameter("uid", uid)
                        .getResultList();
        		
        		for (PmsCompetency pmsCompetency : pmsCompetencyList) {
        			
        			pmsCompetency.setPmsCompetencyCluster(pmsCompetencyClusterRepository.findOne(pmsCompetency.getCompetencyClusterId()));
        			pmsCompetency.setPmsCompetencyMaster(pmsCompetencyMasterRepository.findOne(pmsCompetency.getCmCompetencyMasterId()));
				}
        		
        	}
        	else if(isManager != 0){
        		pmsCompetencyList = manager.createNamedQuery("getCompetencyByManagerAndPerformanceId", PmsCompetency.class)                        
                        .setParameter("performanceId", performanceId)
                        .setParameter("uid", uid)
                        .getResultList();
        		
        		for (PmsCompetency pmsCompetency : pmsCompetencyList) {
        			
        			pmsCompetency.setPmsCompetencyCluster(pmsCompetencyClusterRepository.findOne(pmsCompetency.getCompetencyClusterId()));
        			pmsCompetency.setPmsCompetencyMaster(pmsCompetencyMasterRepository.findOne(pmsCompetency.getCmCompetencyMasterId()));
				}
        		
        	}
        	else if (performanceId != 0) {			
        	
        		pmsCompetencyList = manager.createNamedQuery("getCompetencyByPerformanceId", PmsCompetency.class)                        
                        .setParameter("performanceId", performanceId)						
                        .getResultList();
        					
        	} 
        	else {
			
        		pmsCompetencyList = manager.createNamedQuery("getAllCompetency", PmsCompetency.class)                                               					
                        .getResultList();
			}
			
         } 
		catch (Exception e){
			 logger.info(String.format("exception - ", e.getMessage()));
        }
        return pmsCompetencyList;

    }
    
    /**
     * This method is add row in ModuleNameDetail entity
     * 
     */
    @RequestMapping(method=RequestMethod.POST)
	public PmsCompetency addPmsCompetency(@RequestBody PmsCompetency user, HttpServletRequest request) {
		
			try{
				
				//Get competency master object
				
				user.setCompetencyId(null);
				pmsCompetencyRepository.save(user);
			}
			catch(Exception e){
				logger.info(String.format("exception - ", e.getMessage()));
			}
		
		return user;
	}
    
    /**
     * This method is update row in pmsCompetency entity
     * based on primaryKey Of Module detail Table 
     */
    @RequestMapping(value="/{competencyId}",method=RequestMethod.PUT)
	 public PmsCompetency updatePmsCompetency(@RequestBody PmsCompetency updatedPmsCompetency,@PathVariable Integer competencyId, HttpServletRequest request){
       	
    	String userType = "";
		String phase = "";
		PmsCompetency pmsCompetencyObject = null;
		PmsResource pmsResourceObj = null;
		
		// individual form Unlock workflow - check PmsResource object to check cycle and enable Phase
		Boolean flagHandshake = false;
		Boolean flagPitstop = false;
		Boolean flagEvaluation = false;
		
			try{
				
				Integer uid = session.getAttribute("loggedInUid") != null ? Integer.valueOf(session.getAttribute("loggedInUid").toString()) : 0;
				
				//To update the performance field as per user type
			    HashMap<String,String> typeAndPhase = pmsService.getUserTypeAndPhase(updatedPmsCompetency.getPmsPerformance().getPerformanceId(),uid);
				
			    userType = typeAndPhase.get("userType");
			    phase = typeAndPhase.get("phase");
			    
			    pmsCompetencyObject = pmsCompetencyRepository.findOne(updatedPmsCompetency.getCompetencyId());
			  
			    // individual form Unlock workflow - check PmsResource object to check cycle and enable Phase
			    pmsResourceObj = pmsResourceRepository.findResourceById(pmsCompetencyObject.getPmsPerformance().getUid());
			    	
			    if(pmsResourceObj != null) {
			    	if(pmsResourceObj.getEnableHandshake() && (pmsResourceObj.getEnableHandshakeCycle() == pmsCompetencyObject.getPmsPerformance().getCycle().getCycleId())) {
			    		flagHandshake = true;
			    	}
			    	else if(pmsResourceObj.getEnablePitstop() && (pmsResourceObj.getEnablePitstopCycle() == pmsCompetencyObject.getPmsPerformance().getCycle().getCycleId())) {
			    		flagPitstop = true;
			    	}
			    	else if(pmsResourceObj.getEnableEvaluation() && (pmsResourceObj.getEnableEvaluationCycle() == pmsCompetencyObject.getPmsPerformance().getCycle().getCycleId())) {
			    		flagEvaluation = true;
			    	}
			    }
			    //Generic fields 
			    pmsCompetencyObject.setModifiedBy(updatedPmsCompetency.getModifiedBy());
			    pmsCompetencyObject.setModifiedDate(updatedPmsCompetency.getModifiedDate());
			    
			  //=====For Handshake=====
			    if(phase == "Handshake" || flagHandshake) //No Action Required in Handshake phase
			    {
			    	//Generic fields 
			    	
			    	
			    	//-----For Associate-----
				    if(userType == "Associate"){

				    }
				    //-----For Manager-----
				    else if(userType == "Manager"){

				    }
				    //-----Reviewer-----
				    else if(userType == "Reviewer"){

				    }
			    	
			    }
			    //=====For Pitstop=====
			    else if(phase == "Pitstop" || flagPitstop)
			    {
			    	//Generic fields
			    	
			    	
			    	//-----For Associate-----
				    if(userType == "Associate"){
				    	pmsCompetencyObject.setCommentsSelfPitstop(updatedPmsCompetency.getCommentsSelfPitstop());
				    }
				    //-----For Manager-----
				    else if(userType == "Manager" || userType == "HR"){
				    	pmsCompetencyObject.setCommentsManagerPitstop(updatedPmsCompetency.getCommentsManagerPitstop());				    
				    }
				    //-----Reviewer-----
				    else if(userType == "Reviewer" || userType == "HR"){
				    
				    }
			    	
			    }
			    //=====For Evaluation=====
			    else if(phase == "Evaluation" || flagEvaluation)
			    {
			    	//Generic fields
			    	
			    	
			    	//-----For Associate-----
				    if(userType == "Associate"){
				    	pmsCompetencyObject.setCommentsSelfAnnual(updatedPmsCompetency.getCommentsSelfAnnual());
				    	pmsCompetencyObject.setSelfRating(updatedPmsCompetency.getSelfRating());
				    }
				    //-----For Manager-----
				    else if(userType == "Manager" || userType == "HR"){
				    	pmsCompetencyObject.setCommentsManagerAnnual(updatedPmsCompetency.getCommentsSelfAnnual());
				    	pmsCompetencyObject.setManagersRating(updatedPmsCompetency.getSelfRating());
				    }
				    //-----Reviewer-----
				    else if(userType == "Reviewer" || userType == "HR"){
				    	pmsCompetencyObject.setCommentsReviewerAnnual(updatedPmsCompetency.getCommentsReviewerAnnual());
				    }
			    	
			    }
			    
			    pmsCompetencyObject.setCompetencyId(competencyId);
				pmsCompetencyRepository.save(pmsCompetencyObject);
			}
			catch(Exception e){
				logger.info(String.format("exception - ", e.getMessage()));
			}
	
		 return pmsCompetencyObject;
	 }
    
    /**
     * This method is get data for specific row in moduleName entity
     * based on primaryKey Of Module Table 
     */
    @RequestMapping(value="/{competencyId}",method=RequestMethod.GET)
	 public PmsCompetency getPmsCompetency(@PathVariable Integer competencyId, HttpServletRequest request) throws MessagingException{
    	
    	PmsCompetency PmsCompetency=null;
	
			try{
				PmsCompetency = manager.createNamedQuery("getCompetencyById", PmsCompetency.class)
                     .setParameter("competencyId", competencyId)
                     .getSingleResult();
			}
			catch(Exception e){
				logger.info(String.format("exception - ", e.getMessage()));
			}
		
		return PmsCompetency;
	 }
	 
    
    /**
     * This method is delete data for specific row in moduleName entity
     * based on primaryKey Of Module Table 
     */	 
	@RequestMapping(value="/{competencyId}",method=RequestMethod.DELETE)
	public void deletePmsCompetency(@PathVariable Integer competencyId, HttpServletRequest request) {
		
			try{
				pmsCompetencyRepository.delete(competencyId);
			}
			catch(Exception e){
				logger.info(String.format("exception - ", e.getMessage()));
			}
		
		 
	}
	
	 /**
     * This method is upload file for specific row in goal entity
     * based on primaryKey Of Module Table 
     */	
	@RequestMapping(value="/upload/{docPath}/{competencyId}",method=RequestMethod.POST,consumes = {"multipart/form-data"})
    @ResponseBody
	public String uploadFile(@RequestPart("file") MultipartFile file,@PathVariable(value = "docPath") Integer docPath,@PathVariable(value = "competencyId") Integer competencyId,HttpServletRequest request)
	{
		System.out.print("docPath is here"+docPath);
		PmsCompetency pmsCompetency = pmsCompetencyRepository.findOne(competencyId);
		path= exportUtil.getPmsGoalDocPath(file,request,competencyId);		
		
		if(docPath==1){
			pmsCompetency.setDocLinkSelfAnnual(path);	
		}else{
			pmsCompetency.setDocLinkManagerAnnual(path);;				
		}
		pmsCompetencyRepository.save(pmsCompetency);
		return path;
	}
	
	
	 /**
     * This method is download file for specific row in goal entity
     * based on primaryKey Of pmsGoal Table 
     */	
	@RequestMapping(value="/download/{flag}/{competencyId}",method=RequestMethod.GET)
	public void download(@PathVariable(value = "flag") Integer flag,@PathVariable(value = "competencyId") Integer competencyId,HttpServletRequest request,HttpServletResponse response) throws ServletException, Exception {
		String path=null;
		File home=exportUtil.checkPath(request);
		String separator=File.separator;
		String Filepath = "";
		path=home.getPath();
		
		PmsCompetency pmsCompetency = pmsCompetencyRepository.findOne(competencyId);
		if(flag == 1) {
			Filepath = pmsCompetency.getDocLinkSelfAnnual();
		}else {
			Filepath = pmsCompetency.getDocLinkManagerAnnual();			
		}
		List<String> list = Arrays.asList(Filepath.split("\\s*,\\s*"));
	
		if(list.size() > 1){
		
			if (home.exists() && home.isDirectory()) {
				 logger.info("home is a directory");
				    if(path.equals(separator)){
					 	path="usr"+File.separator+"home"+File.separator+"Download";
					}
					else{
						path=File.separator+"usr"+File.separator+"home"+File.separator+"Download";
					}
				
					if (Files.isDirectory(Paths.get(home + path))) {
						if(path.equals(separator)){
							path="usr"+File.separator+"home"+File.separator+"Download"+File.separator+"pmsCompetency";
						}
						else{
							path=File.separator+"usr"+File.separator+"home"+File.separator+"Download"+File.separator+"pmsCompetency";
						}
						
						if (Files.isDirectory(Paths.get(home + path))) {
							if(path.equals(separator)){
								path="usr"+File.separator+"home"+File.separator+"Download"+File.separator+"pmsCompetency"+File.separator;
							}
							else{
								path=File.separator+"usr"+File.separator+"home"+File.separator+"Download"+File.separator+"pmsCompetency"+File.separator;
							}
							
						} 
					}	
			}
		}
		else{
			try{
				File outputFile = new File(Filepath);
				Path file = Paths.get(outputFile+"");
			    response.addHeader("Content-Disposition", "attachment; filename="+file.getFileName());
			    Files.copy(file, response.getOutputStream());
			    response.getOutputStream().flush();
			}
			catch(FileNotFoundException fe){
				fe.printStackTrace();
			}
		}
	}
  
   
}
