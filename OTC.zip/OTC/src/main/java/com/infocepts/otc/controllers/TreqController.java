package com.infocepts.otc.controllers;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;

import javax.mail.MessagingException;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.math.NumberUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.infocepts.otc.entities.Allocation;
import com.infocepts.otc.entities.CmsDetail;
import com.infocepts.otc.entities.SowDetail;
import com.infocepts.otc.entities.Treq;
import com.infocepts.otc.notification.SmtpMailSender;
import com.infocepts.otc.repositories.AccountRepository;
import com.infocepts.otc.repositories.AllocationRepository;
import com.infocepts.otc.repositories.CmsDetailRepository;
import com.infocepts.otc.repositories.ProjectRepository;
import com.infocepts.otc.repositories.SowDetailRepository;
import com.infocepts.otc.repositories.TreqRepository;
import com.infocepts.otc.services.StoredProcedureService;
import com.infocepts.otc.services.TimesheetService;

@RequestMapping("/treqs")
@RestController
public class TreqController {
	
	@Autowired
	TreqRepository repository;
	
	@PersistenceContext
    private EntityManager manager;
	
	@Autowired
	TimesheetService service;
	
	@Autowired
	ProjectRepository projectRepository;
	
	@Autowired
	ResourceController resourceController;
	
	@Autowired
	SmtpMailSender smtpMailSender;
	
	@Autowired
	SowDetailRepository sowDetailRepository;

	
	@Autowired
	AccountRepository accountRepository;
	
	@Autowired
	HttpSession session;
	
	@Autowired
	private AllocationRepository allocationRepository;
	
	@Autowired 
	private StoredProcedureService storedProcedureService;
	
	@Autowired 
	private CmsDetailRepository cmsDetailRepository;
	
	final Logger logger = Logger.getLogger(TreqController.class);
	
	@RequestMapping(method=RequestMethod.GET)
	 public List<Treq> getAllTreqs(
			 @RequestParam(value="cmsId",defaultValue="0") Integer cmsId,
			 @RequestParam(value="alcId",defaultValue="0") Integer alcId,
			 @RequestParam(value="accountId", defaultValue = "0") Integer accountId,
			 @RequestParam(value="sowDetailId",defaultValue="0") Integer sowDetailId,
			 @RequestParam(value="createdBy",defaultValue="0") Integer createdBy,
			 @RequestParam(value="filterMyList",defaultValue="0") Integer filterMyList,
			 @RequestParam(value="projectId",defaultValue="0") Integer projectId,
			 @RequestParam(value="cmsDetailId",defaultValue="0") Integer cmsDetailId){
		 
		 List<Treq> treqlist=null;
		 Integer loggedInUid = (Integer) session.getAttribute("loggedInUid");
		
		 try{
			
			if(cmsId != 0)
			 {
				 treqlist = manager.createNamedQuery("getTreqByCmsId", Treq.class)
			 				.setParameter("cmsId", cmsId)
			     			.getResultList();
			 }
			 else if (accountId != 0)
			 {
				 treqlist = manager.createNamedQuery("getTreqByAccountId", Treq.class)
			 				.setParameter("accountId", accountId)
			     			.getResultList();
			 }
			 else if(alcId != 0)
			 {
				 treqlist = manager.createNamedQuery("getTreqByAllocationId", Treq.class)
			 				.setParameter("alcId", alcId)
			     			.getResultList();
			 }
			 else if(cmsDetailId != 0)
			 {
				 treqlist = manager.createNamedQuery("getTreqByCmsDetailId", Treq.class)
			 				.setParameter("cmsDetailId", cmsDetailId)
			     			.getResultList();
			 }
			 else if(sowDetailId != 0)
			 {
				 treqlist = manager.createNamedQuery("getTreqBySowDetailId", Treq.class)
			 				.setParameter("sowDetailId", sowDetailId)
			     			.getResultList();
			 }
			 else if(filterMyList == 1)
			 {					
				 treqlist = manager.createNamedQuery("getTreqByAssociate", Treq.class)
			 				.setParameter("createdBy", loggedInUid)
			 				.setParameter("cepId", loggedInUid)
			     			.getResultList();
			 }
			 else if(projectId != 0)
			 {	
				 treqlist = manager.createNamedQuery("getTreqByProject", Treq.class)
			 				.setParameter("projectId", projectId)
			     			.getResultList();
			 }
			 else
			 {
				 treqlist =  manager.createNamedQuery("getAllTreqs", Treq.class)
						 	.getResultList();
			 }
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return treqlist;
	 }
	
	@RequestMapping(value="/{treqId}",method=RequestMethod.GET)
	 public Treq getTreqDetail(@PathVariable Integer treqId){
		 Treq treq = null;
		 try{
			 treq = manager.createNamedQuery("getTreqById", Treq.class)
		 				.setParameter("treqId", treqId)
		     			.getSingleResult();
			 Allocation allocation = treq.getAllocation();
			 if (allocation != null && allocation.getAlcId() != null) {
				 treq.setAllocation(allocationRepository.findOne(allocation.getAlcId()));
			 }
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return treq;
	 }
	
	@RequestMapping(method=RequestMethod.POST)
	public Treq addTreq(@RequestBody Treq treq, HttpServletRequest request) throws MessagingException{
		try{
			repository.save(treq);
			service.sendTreqNotification(treq, "add", request); // Allocation add / update solution											
		}
		catch(Exception e){
			logger.error(e);
		}
		return treq;
	}
	
	@RequestMapping(value="/{treqId}",method=RequestMethod.PUT)
	public Treq updateTreq(@PathVariable Integer treqId,@RequestBody Treq updatedtreq, HttpServletRequest request) throws MessagingException{
		Integer uid = NumberUtils.toInt(request.getSession().getAttribute("loggedInUid") + "");
		try{
			
			if(updatedtreq.getIsTreqPage() != null && updatedtreq.getIsTreqPage()){
				addUpdateAllocation(updatedtreq, uid);
			}
			updatedtreq.setTreqId(treqId);
			repository.save(updatedtreq);
			service.sendTreqNotification(updatedtreq, "update", request); // Allocation add / update solution											
		}
		catch(Exception e){
			logger.error(e);
		}
		return updatedtreq;
	}
	
	@RequestMapping(value="/{treqId}",method=RequestMethod.DELETE)
	public void deleteTreq(@PathVariable Integer treqId){
		try{
			repository.delete(treqId);
		}catch(Exception e){
			logger.error(e);
		}
		
	}
	
	/**
	 * @param treq
	 * @return - Save/Update allocation object before saving treq.
	 */
	private void addUpdateAllocation(Treq treq, Integer uid) {
		Allocation allocation = treq.getAllocation();
		CmsDetail cmsDetail = treq.getCmsDetail();
		SowDetail sowDetail = treq.getSowDetail();
		
		List<String> statusList = Arrays.asList("Proposed", "AMG Fulfilled");
		
		if (allocation != null && allocation.getUid() != null) {
			try {
				if (allocation.getAlcId() != null && !statusList.contains(treq.getStatus())) {
					allocation.setUid(0);
					allocation.setModifiedDate(new Date());
				} else {
					if (cmsDetail != null) {
						cmsDetail = cmsDetailRepository.findOne(cmsDetail.getCmsDetailId());
						allocation.setAlcFte(cmsDetail.getExpectedBillability());
						allocation.setAlcType(cmsDetail.getIsBillable() ? 1 : 2);
						allocation.setCmsDetail(cmsDetail);
						allocation.setAlcStartDate(cmsDetail.getSowRoleStartDate());
						allocation.setAlcEndDate(cmsDetail.getSowRoleEndDate());
					} else if (sowDetail != null) {
						sowDetail = sowDetailRepository.findOne(sowDetail.getSowDetailId());
						allocation.setAlcFte(sowDetail.getExpectedBillability());
						allocation.setAlcType(sowDetail.getIsBillable() ? 1 : 2);
						allocation.setSowDetail(sowDetail);
						allocation.setAlcStartDate(sowDetail.getSowRoleStartDate());
						allocation.setAlcEndDate(sowDetail.getSowRoleEndDate());
					}
					allocation.setCreatedBy(uid);
					allocation.setCreatedDate(new Date());
					allocation.setModifiedDate(new Date());
					allocation.setAlcStatus("InActive");
					allocation.setTreqId(treq.getTreqId());
				}
				Allocation savedAllocation = allocationRepository.save(allocation);
				storedProcedureService.GenerateMonthlyAllocation(savedAllocation.getAlcId());
				treq.setAllocation(savedAllocation);
			} catch (Exception e) {
				java.util.logging.Logger.getLogger(TreqController.class.getName())
				.log(Level.SEVERE, "ERROR WHILE SAVING/UPDATING ALLOCATION FOR USER ID: " + 
						allocation.getUid() + " AND TREQ ID: " + treq.getTreqId(), e);
			}
		}
	}
	
	@GetMapping("/findAllTreqs")
    public Object findAllTreqs(@RequestParam(value = "status", defaultValue = "") String status,
    							HttpServletRequest request){        
		List<Treq> allTreqList = null;
		System.out.println("status"+status);
        try{
        	if(status != null)
        	{
        		allTreqList = manager.createNamedQuery("getAllTreqsByTreqStatus", Treq.class)
        				.setParameter("status", status)
        				.getResultList();	
        	}       	
        }catch(Exception e){
        	logger.info(String.format("error in fetching treq list - ", e.getMessage()));
			e.printStackTrace();
        }
        return allTreqList;
    }
	
}
