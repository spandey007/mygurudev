
/**
* Filename: /src/main/java/com/infocepts/otc/repositories/<ModuleName>Repository.java
* @author  SRA
* @version 1.0
* @since   2018-08-01 
*/
package com.infocepts.otc.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import com.infocepts.otc.entities.InfoCab;

public interface InfoCabRepository extends CrudRepository<InfoCab,Integer>{

	@Override
	public List<InfoCab> findAll();	
	
}

