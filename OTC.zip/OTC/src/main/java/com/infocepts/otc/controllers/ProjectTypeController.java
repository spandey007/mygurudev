package com.infocepts.otc.controllers;

import com.infocepts.otc.entities.ProjectType;
import com.infocepts.otc.repositories.ProjectTypeRepository;
import com.infocepts.otc.services.TimesheetService;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(value = "/projecttype", headers = "referer")
public class ProjectTypeController {

    final Logger logger = Logger.getLogger(ProjectTypeController.class);

    @Autowired
    ProjectTypeRepository repository;

    @Autowired
    TimesheetService service;

    @RequestMapping(method = RequestMethod.POST)
    public ProjectType addProjectType(@RequestBody ProjectType projectType) {
        try {
            if (service.isPmo()) {
                projectType.setProjectTypeId(null);
                repository.save(projectType);
            }
        } catch (Exception e) {
            logger.error(e);
        }
        return projectType;
    }

    @RequestMapping(method = RequestMethod.GET)
    public List<ProjectType> getAllProjectTypes() {
        List<ProjectType> projectTypes = null;
        try {
            projectTypes = repository.findAll();
        } catch (Exception e) {
            logger.error(e);
        }
        return projectTypes;
    }

    @RequestMapping(value = "/{projectTypeId}", method = RequestMethod.GET)
    public ProjectType getProjectType(@PathVariable Integer projectTypeId) {
        ProjectType projectType = null;
        try {
            projectType = repository.findOne(projectTypeId);
        } catch (Exception e) {
            logger.error(e);
        }
        return projectType;
    }


    @RequestMapping(value = "/{projectTypeId}", method = RequestMethod.PUT)
    public ProjectType updateProjectType(@RequestBody ProjectType projectType, @PathVariable Integer projectTypeId) {
        try {
            if (service.isPmo()) {
                projectType.setProjectTypeId(projectTypeId);
                repository.save(projectType);
            }
        } catch (Exception e) {
            logger.error(e);
        }
        return projectType;
    }

    @RequestMapping(value = "/{projectTypeId}", method = RequestMethod.DELETE)
    public void deleteProjectType(@PathVariable Integer projectTypeId) {
        try {
            if (service.isPmo()) {
                repository.delete(projectTypeId);
            }
        } catch (Exception e) {
            logger.error(e);
        }
    }

}
