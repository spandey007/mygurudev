package com.infocepts.otc.entities;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.infocepts.otc.utilities.LoadConstant;

@Entity
@Table(catalog=LoadConstant.otc, schema="[dbo]",name="treqUpdateONInfoHireStatus")
public class TREQUpdateONInfoHireStatus {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer id;
	private Integer treqId;
	private Boolean hiringSent;
	private Boolean otherThanHiringSent;
	private Date hiringSentDate;
	private Date otherThanHiringSentDate;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getTreqId() {
		return treqId;
	}
	public void setTreqId(Integer treqId) {
		this.treqId = treqId;
	}
	public Boolean getHiringSent() {
		return hiringSent;
	}
	public void setHiringSent(Boolean hiringSent) {
		this.hiringSent = hiringSent;
	}
	public Boolean getOtherThanHiringSent() {
		return otherThanHiringSent;
	}
	public void setOtherThanHiringSent(Boolean otherThanHiringSent) {
		this.otherThanHiringSent = otherThanHiringSent;
	}
	public Date getHiringSentDate() {
		return hiringSentDate;
	}
	public void setHiringSentDate(Date hiringSentDate) {
		this.hiringSentDate = hiringSentDate;
	}
	public Date getOtherThanHiringSentDate() {
		return otherThanHiringSentDate;
	}
	public void setOtherThanHiringSentDate(Date otherThanHiringSentDate) {
		this.otherThanHiringSentDate = otherThanHiringSentDate;
	}
	
	
	//Getter and Setter
	
}
