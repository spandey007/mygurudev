package com.infocepts.otc.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.infocepts.otc.entities.Sow;


public interface SowRepository extends JpaRepository<Sow,Integer>{

	@Override
	public List<Sow> findAll();
}
