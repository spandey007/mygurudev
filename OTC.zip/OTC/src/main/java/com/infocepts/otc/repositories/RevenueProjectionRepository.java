package com.infocepts.otc.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.infocepts.otc.entities.RevenueProjection;

public interface RevenueProjectionRepository extends CrudRepository<RevenueProjection,Integer>{

	@Override
	public List<RevenueProjection> findAll();
	
}
