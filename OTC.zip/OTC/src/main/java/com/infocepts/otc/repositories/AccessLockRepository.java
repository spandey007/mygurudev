package com.infocepts.otc.repositories;

import java.util.List;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import com.infocepts.otc.entities.AccessLock;

public interface AccessLockRepository extends CrudRepository<AccessLock,Integer>{

	@Override
	public List<AccessLock> findAll();

	@Query("select a from AccessLock a where username = :username")
	public AccessLock findUsername(@Param("username") String username);
	
}
