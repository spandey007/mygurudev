package com.infocepts.otc.controllers;

import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.infocepts.otc.entities.Milestone;
import com.infocepts.otc.repositories.MilestoneRepository;

@RestController
@RequestMapping(value="/milestone",headers="referer")
public class MilestoneController {

	final Logger logger = Logger.getLogger(MilestoneController.class);
	
	@Autowired
	MilestoneRepository repository;
	
	@RequestMapping(method=RequestMethod.POST)
	public Milestone addMilestone(@RequestBody Milestone milestone)
	{
		try{
			milestone.setMilestoneId(null);
			repository.save(milestone);	
		}catch(Exception e){
			logger.error(e);
		}
		return milestone;
	}	
 
	 @RequestMapping(method=RequestMethod.GET)
	 public List<Milestone> getAllMilestone(){
		 List<Milestone> milestonelist=null;
		 try{
			 milestonelist = repository.findAll();
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return milestonelist;
	 }

	 @RequestMapping(value="/{milestoneId}",method=RequestMethod.GET)
	 public Milestone getMilestone(@PathVariable Integer milestoneId){
		 Milestone milestone=null;
		 try{
			 milestone = repository.findOne(milestoneId);
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return milestone;
	 }
	 
	 @RequestMapping(value="/{milestoneId}",method=RequestMethod.PUT)
	 public Milestone updateMilestone(@RequestBody Milestone updatedMilestone,@PathVariable Integer milestoneId){
		 try{
			 updatedMilestone.setMilestoneId(milestoneId);
			 repository.save(updatedMilestone);
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return updatedMilestone;
	 }
	 
	 @RequestMapping(value="/{milestoneId}",method=RequestMethod.DELETE)
	 public void deleteMilestone(@PathVariable Integer milestoneId){
		 try{
			 repository.delete(milestoneId);
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
	 }	
	 
	 @GetMapping("/getAllMilestones")
	 public List<Milestone> getAllMilestones(){
		 List<Milestone> milestonelist=null;
		 try{
			 milestonelist = repository.findAll();
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return milestonelist;
	 }
}
