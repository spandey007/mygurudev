/**
* Filename: /src/main/java/com/infocepts/otc/controllers/PmsCompetencyMasterController.java
* @author  MEW
* @version 1.0
* @since   2018-08-01 
*/

package com.infocepts.otc.controllers;

import java.util.logging.Logger;
import com.infocepts.pms.entities.PmsCompetencyMaster;
import com.infocepts.pms.entities.PmsDepartmentMapping;
import com.infocepts.pms.entities.PmsGradeMapping;
import com.infocepts.pms.repositories.PmsCompetencyMasterRepository;
import com.infocepts.pms.repositories.PmsDepartmentMappingRepository;
import com.infocepts.pms.repositories.PmsGradeMappingRepository;
import com.infocepts.otc.services.TimesheetService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.mail.MessagingException;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import java.util.List;

@RestController
@RequestMapping(value="/api/pms/competencyMaster", headers="referer")
public class PmsCompetencyMasterController {

    final Logger logger = Logger.getLogger(PmsCompetencyMasterController.class.getName());

    @Autowired
    PmsCompetencyMasterRepository repository;
    
    @Autowired
    HttpSession session;

    @PersistenceContext(unitName = "pms") 
    private EntityManager manager;
			
	@Autowired
	TimesheetService service;
	
	@Autowired
    PmsGradeMappingRepository gradeMappingRepository;
    
    @Autowired
    PmsDepartmentMappingRepository departmentMappingRepository;

	/**
   * This method is used to find results set from module entity
   * based on params passed from JS file
   */
    @RequestMapping(method = RequestMethod.GET)
    public List<PmsCompetencyMaster> findAllPmsCompetencyMaster(@RequestParam(value = "competencyClusterId", defaultValue = "0") Integer competencyClusterId
            						,HttpServletRequest request){
        List<PmsCompetencyMaster> pmsCompetencyMasterList = null;
        //Integer loggedInUid = (Integer) session.getAttribute("loggedInUid");
        
        try {
        	/* ------------------------- Authorization start ------------------------------------ */
			// Authorization for XYZ role
			/*if(service.isHRPms()) // isAdmin() needs implementation in declaration  in TimesheetService Class & implementation in TimesheetServiceImpl Class
			{
				service.sendTamperedMail("PmsCompetencyMaster view all", 0, 0, request);
				return pmsCompetencyMasterList;
			}*/
			/* ------------------------- Authorization ends ------------------------------------ */
			
			if (competencyClusterId != 0) {
	
				pmsCompetencyMasterList = manager.createNamedQuery("getCompetencyMastersByCluster", PmsCompetencyMaster.class) 
        				.setParameter("competencyClusterId", competencyClusterId)
                        .getResultList();
        					
        	} else {
	
        		pmsCompetencyMasterList = manager.createNamedQuery("getAllCompetencyMasters", PmsCompetencyMaster.class)   
                        .getResultList();
			}
			
         } 
		catch (Exception e){
			 logger.info(String.format("exception - ", e));
        }
        return pmsCompetencyMasterList;

    }
    
    /**
     * This method is add row in moduleName entity
     * 
     */
    @RequestMapping(method=RequestMethod.POST)
	public PmsCompetencyMaster addPmsCompetencyMaster(@RequestBody PmsCompetencyMaster pmsCompetencyMaster, HttpServletRequest request) throws MessagingException {
		// Authorization for XYZ role
		if(service.isHRPms() || service.isHRPmsAdmin())
		{
			List<PmsGradeMapping> gradeMapping = pmsCompetencyMaster.getGradeMapping();
			List<PmsDepartmentMapping> departmentMapping = pmsCompetencyMaster.getDepartmentMapping();
			
			try{
				
				pmsCompetencyMaster.setCompetencyMasterId(null);
				repository.save(pmsCompetencyMaster);
				
//Save the mapping tables
				
				//Set the id in mapping list
				for (PmsGradeMapping pmsGradeMapping : gradeMapping) {
					pmsGradeMapping.setTypeId(pmsCompetencyMaster.getCompetencyMasterId());
				}
				
				gradeMappingRepository.save(gradeMapping);
				
				//Set the id in mapping list
				for (PmsDepartmentMapping pmsDepartmentMapping : departmentMapping) {
					pmsDepartmentMapping.setTypeId(pmsCompetencyMaster.getCompetencyMasterId());
				}
				
				departmentMappingRepository.save(departmentMapping);
			}
			catch(Exception e){
				 logger.info(String.format("exception - ", e));
			}
		}
		else 
		{
			service.sendTamperedMail("PmsCompetencyMaster Save", 0, 0, request);
		}
		
		return pmsCompetencyMaster;
	}
    
    /**
     * This method is update row in moduleName entity
     * based on primaryKey Of Module Table 
     */
    @RequestMapping(value="/{competencyMasterId}",method=RequestMethod.PUT)
	 public PmsCompetencyMaster updatePmsCompetencyMaster(@RequestBody PmsCompetencyMaster updatedPmsCompetencyMaster,@PathVariable Integer competencyMasterId,HttpServletRequest request) throws MessagingException{
        // Authorization for XYZ role
		if(service.isHRPms() || service.isHRPmsAdmin())
		{	
			List<PmsGradeMapping> gradeMapping = updatedPmsCompetencyMaster.getGradeMapping();
			List<PmsDepartmentMapping> departmentMapping = updatedPmsCompetencyMaster.getDepartmentMapping();
			
			try{
				updatedPmsCompetencyMaster.setCompetencyMasterId(competencyMasterId);
				 repository.save(updatedPmsCompetencyMaster);
				 
				//Delete the existing mapping
				gradeMappingRepository.deleteGradeMapping(competencyMasterId, 4);
				
				gradeMappingRepository.save(gradeMapping);
				
				//Delete the existing mapping
				departmentMappingRepository.deleteDepartmentMapping(competencyMasterId, 4);
				
				departmentMappingRepository.save(departmentMapping);
			}
			catch(Exception e){
				 logger.info(String.format("exception - ", e));
			}
		}
		else
		{
			service.sendTamperedMail("PmsCompetencyMaster Save", 0, 0, request);
		}
		 return updatedPmsCompetencyMaster;
	 }
    
    /**
     * This method is get data for specific row in moduleName entity
     * based on primaryKey Of Module Table 
     */
    @RequestMapping(value="/{competencyMasterId}",method=RequestMethod.GET)
	 public PmsCompetencyMaster getPmsCompetencyMaster(@PathVariable Integer competencyMasterId, HttpServletRequest request) throws MessagingException{
    	
    	PmsCompetencyMaster pmsCompetencyMaster = null;
		// Authorization for XYZ role
		if(service.isHRPms() || service.isHRPmsAdmin())
		{
			try{
				pmsCompetencyMaster = manager.createNamedQuery("getCompetencyMasterById", PmsCompetencyMaster.class)
						 .setParameter("competencyMasterId", competencyMasterId)
						 .getSingleResult();
				
				//Get Grade mapping
				 List<PmsGradeMapping> gradeMapping = gradeMappingRepository.findByTypeId(competencyMasterId, 4);
				 
				 //Set Grade mapping
				 pmsCompetencyMaster.setGradeMapping(gradeMapping);
				 
				 //Get Department mapping
				 List<PmsDepartmentMapping> departmentMapping = departmentMappingRepository.findByTypeId(competencyMasterId, 4);
				 
				 //Set Department mapping
				 pmsCompetencyMaster.setDepartmentMapping(departmentMapping);
			 }
			 catch(Exception e){
				 logger.info(String.format("exception - ", e));
			 }
		}
		else 
		{
			service.sendTamperedMail("PmsCompetencyMaster Get", 0, 0, request);
		}
		 
		 return pmsCompetencyMaster;
	 }
	 
    
    /**
     * This method is delete data for specific row in moduleName entity
     * based on primaryKey Of Module Table 
     */	 
	@RequestMapping(value="/{competencyMasterId}",method=RequestMethod.DELETE)
	public void deletePmsCompetencyMaster(@PathVariable Integer competencyMasterId, HttpServletRequest request)  throws MessagingException {
		// Authorization for XYZ role
		if(service.isHRPms() || service.isHRPmsAdmin())
		{
			try{
				//Delete all grade and dep allocation rows first
				gradeMappingRepository.deleteGradeMapping(competencyMasterId, 4);
				departmentMappingRepository.deleteDepartmentMapping(competencyMasterId, 4);
				repository.delete(competencyMasterId);
			}
			catch(Exception e){
				 logger.info(String.format("exception - ", e));
			}
		}
		else
		{
			service.sendTamperedMail("PmsCompetencyMaster Delete", 0, 0, request);
		}		 
	}
	
  
   
}
