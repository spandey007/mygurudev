package com.infocepts.otc.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.infocepts.otc.entities.Allocation;



public interface AllocationRepository extends JpaRepository<Allocation, Integer>{
	@Override
	public List<Allocation> findAll();
	

	//Function to get all the Allocation Imported from Excel
	@Query("from Allocation where comments = :comments")
	public List<Allocation> findAllImportedAllocation(@Param("comments") String comments);
	
	/**
	 * @param projectId - Id of project for which project allocation is to be fetched.
	 * @param uid - Logged in user id for which project allocation is to be fetched.
	 * @return - List of Billable/Non-billable allocations by given Project and User Id.
	 */
	@Query("FROM Allocation WHERE projectId = :projectId AND uid = :uid")
	public List<Allocation> findAllocation(@Param("projectId") Integer projectId, @Param("uid") Integer uid);

}
