package com.infocepts.otc.controllers;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.lang.reflect.Array;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.infocepts.otc.entities.Sow;
import com.infocepts.otc.entities.CmsDetail;
import com.infocepts.otc.repositories.CmsDetailRepository;
import com.infocepts.otc.services.TimesheetService;


@RestController
@RequestMapping(value="/cmsdetail")
public class CmsDetailController {

	@Autowired
	CmsDetailRepository repository;
	
	@Autowired
	TimesheetService service;
	
	@PersistenceContext
    private EntityManager manager;
	
	@Autowired
	HttpSession session;
	
    final Logger logger = Logger.getLogger(CmsDetailController.class);
	
    @RequestMapping(method=RequestMethod.POST)
	public CmsDetail addCmsDetail(@RequestBody CmsDetail cmsdetail)
	{
		try{
			cmsdetail.setCmsDetailId(null);
			repository.save(cmsdetail);
		}catch(Exception e){
			logger.error(e);
		}
		return cmsdetail;
	}	
 
	@RequestMapping(method=RequestMethod.GET)
	public List<CmsDetail> getAllCmsDetail(@RequestParam(value = "cmsId", defaultValue = "0") Integer cmsId,
			 			@RequestParam(value = "accountId", defaultValue = "0") Integer accountId,
			 			@RequestParam(value = "sowId", defaultValue = "0") Integer sowId,
						@RequestParam(value = "status", defaultValue = "Active") String status,
						@RequestParam(value = "allItem", defaultValue = "0") Integer allItem,
						@RequestParam(value = "opportunityId", defaultValue = "0") Integer opportunityId,
						@RequestParam(value = "isResourcePlanning", defaultValue = "0") Integer isResourcePlanning,
						@RequestParam(value = "year", defaultValue = "0") Integer year
			 			){
		 List<CmsDetail> sowdetaillist=null;
		 	    	
			
		 try
		 {	
			//Get the user roles
			 String userRoles = session.getAttribute("userRoles") != null ? session.getAttribute("userRoles").toString() : "";
			 int uid = session.getAttribute("loggedInUid") != null ? Integer.valueOf(session.getAttribute("loggedInUid").toString()) : 0;
			 
			 Integer isPH = 0;   
			 Integer isBP = 0;  
			 
			 if(userRoles.toLowerCase().contains("ph")) isPH = 1;
			 
			 if(userRoles.toLowerCase().contains("bp") || userRoles.toLowerCase().contains("admin")) isBP = 1;
			 
			 if(cmsId != 0)
			 {
				 sowdetaillist = manager.createNamedQuery("getCmsDetailByCmsId",CmsDetail.class)
				 			.setParameter("cmsId", cmsId)
							.getResultList();
			 }
			 else if(accountId != 0) // cmsDetails are retrieved by Account and sowId for Sow page
			 {
				 if(accountId == -1) accountId = 0;// Fetch soft allocations for all accounts
			 	 			 		
				 sowdetaillist = manager.createNamedQuery("getCmsDetailsForAccount",CmsDetail.class)
				 			.setParameter("accountId", accountId)
				 			.setParameter("sowId", sowId)
							.setParameter("status", status)
							.getResultList();
			 }
			 else if(opportunityId != 0)
			 {
				 sowdetaillist = manager.createNamedQuery("getCmsDetailByOpportunityId",CmsDetail.class)
				 			.setParameter("opportunityId", opportunityId)
				 			.setParameter("status", status)
							.getResultList();
			 }
			 else if(isResourcePlanning != 0)
			 {
				 sowdetaillist = manager.createNamedQuery("getResourcePlanning",CmsDetail.class)
						 	.setParameter("isPH", isPH)
						 	.setParameter("isBP", isBP)
						 	.setParameter("uid", uid)
						 	.setParameter("year", year)
							.getResultList();
			 }
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return sowdetaillist;
	 }

	 @RequestMapping(value="/{cmsDetailId}",method=RequestMethod.GET)
	 public CmsDetail getCmsDetail(@PathVariable Integer cmsDetailId){
		 CmsDetail cmsdetail=null;
		 try{
			 cmsdetail = manager.createNamedQuery("getCmsDetailById",CmsDetail.class)
			 			.setParameter("cmsDetailId", cmsDetailId)
						.getSingleResult();
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return cmsdetail;
	 }

	 @RequestMapping(value="/{cmsDetailId}",method=RequestMethod.PUT)
	 public CmsDetail updateCmsDetail(@RequestBody CmsDetail updatedcmsdetail,@PathVariable Integer cmsDetailId){
		 try{
			 updatedcmsdetail.setCmsDetailId(cmsDetailId);
			 repository.save(updatedcmsdetail);
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return updatedcmsdetail;
	 }
	 
	 @RequestMapping(value="/{cmsDetailId}",method=RequestMethod.DELETE)
	 public void deleteCmsDetail(@PathVariable Integer cmsDetailId){
		 try{
			 repository.delete(cmsDetailId);
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
	 }	 
}
