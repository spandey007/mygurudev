/**
 * 
 */
package com.infocepts.otc.webservice;

import java.io.IOException;

import org.apache.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.web.client.ResponseErrorHandler;

/**
 * @author Rewatiraman Singh
 *
 */
public final class WebServiceExceptionHandler extends Object implements ResponseErrorHandler {
	
	private final Logger logger = Logger.getLogger(WebServiceExceptionHandler.class);

	@Override
	public boolean hasError(ClientHttpResponse response) throws IOException {
		/* If web service call doesn't return a success status then true will be returned and handleError() method will be
		 * called. 
		*/
		return response.getStatusCode() != HttpStatus.OK;		
	}

	@Override
	public void handleError(ClientHttpResponse response) throws IOException {
		this.logger.error("Something went wrong while getting the response from remote server!"
				+ "Status Code: " + response.getStatusText());
	}
}
