/**
* Filename: /src/main/java/com/infocepts/otc/controllers/SurveyController.java
* @author  Anjali S. Kalbande
* @version 1.0
* @since   2019-06-03 
*/
package com.infocepts.otc.controllers;

import java.util.logging.Logger;
import com.infocepts.otc.entities.Survey;
import com.infocepts.otc.repositories.SurveyRepository;
import com.infocepts.otc.utilities.DateConverter;
import com.infocepts.otc.services.TimesheetService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.mail.MessagingException;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

@RestController
@RequestMapping(value="/survey", headers="referer")
public class SurveyController {

	final Logger logger = Logger.getLogger(SurveyController.class.getName());

    @Autowired
    SurveyRepository repository;
    
    @Autowired
    HttpSession session;

    @PersistenceContext(unitName = "otc") 
    private EntityManager manager;
			
	@Autowired
	TimesheetService service;

    @RequestMapping(method = RequestMethod.GET)
    public List<Survey> findAllSurvey(@RequestParam(value = "state", defaultValue = "Active") String state){
    	
    	List<Survey> surveyList = null;
    	
        //Integer loggedInUid = (Integer) session.getAttribute("loggedInUid");   
        
        logger.info("--------------------in Survey controller------------------");						
       try {

					
			if(state.equals("All")) {				
        		surveyList = manager.createNamedQuery("getAllSurvey", Survey.class)
						.setParameter("status", Arrays.asList("Active", "Deactive"))
                        .getResultList();      								
			}else {
        		surveyList = manager.createNamedQuery("getAllSurvey", Survey.class)
						.setParameter("status", state)
                        .getResultList();      												
			}
         } 
		catch (Exception e){
			 logger.info(String.format("Error in fetching survey list ", e));
        }
        
        return surveyList;
    }
    
    @RequestMapping(method=RequestMethod.POST)
	public Survey addSurvey(@RequestBody Survey survey, HttpServletRequest request) throws MessagingException {
		
    	// Authorization for Admin role
		if(service.isAdmin())
		{
			try{
				survey.setSurveyId(null);
				repository.save(survey);
				// send mail notification
				
				service.sendSurveyNotification(survey, "add", request); // Survey Added										

				
			}
			catch(Exception e){
				 logger.info(String.format("Error in while saving survey details", e));
			}
		}
		else 
		{
			service.sendTamperedMail("Survey Saved", 0, 0, request);
		}
		
		return survey;
	}
    
    @RequestMapping(value="/{surveyId}",method=RequestMethod.PUT)
	 public Survey updateSurvey(@RequestBody Survey updatedSurvey,@PathVariable Integer surveyId, HttpServletRequest request) throws MessagingException{
        
    	// Authorization for Admin role
		if(service.isAdmin())
		{	
			try{
				updatedSurvey.setSurveyId(surveyId);
				 repository.save(updatedSurvey);
				// send mail notification
					
					service.sendSurveyNotification(updatedSurvey, "update", request); // Survey Updated		
			}
			catch(Exception e){
				 logger.info(String.format("Error in while updating survey details ", e));
			}
		}
		
		 return updatedSurvey;
	 }
    
    @RequestMapping(value="/{surveyId}",method=RequestMethod.GET)
	 public Survey getSurveyById(@PathVariable Integer surveyId, HttpServletRequest request) throws MessagingException{	

    	Survey survey = null;
		// Authorization for Admin role
    	if(service.isAdmin())
		{
    		try {
    			System.out.println(surveyId);
    			survey = repository.findOne(surveyId);
    		} catch (Exception e) {
    			logger.info(String.format("exception - ", e));
    		}
		}
    	
		 return survey;
	 }
	  
	@RequestMapping(value="/{surveyId}",method=RequestMethod.DELETE)
	public void deleteSurvey(@PathVariable Integer surveyId, HttpServletRequest request)  throws MessagingException {
		// Authorization for Admin role
		if(service.isAdmin())
		{
			try{
			repository.delete(surveyId);
			}
			catch(Exception e){
				 logger.info(String.format("exception - ", e));
			}
		}			 
	}
	
}
