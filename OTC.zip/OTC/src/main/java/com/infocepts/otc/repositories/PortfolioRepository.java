package com.infocepts.otc.repositories;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.infocepts.otc.entities.Portfolio;

import java.util.List;
import java.lang.Integer;

public interface PortfolioRepository extends CrudRepository<Portfolio, Integer>{

	@Query("from Portfolio where itemId=:ItemId")
	public Portfolio findOne(@Param("ItemId") Integer ItemId);

    @Query("Select portfolio from Portfolio portfolio where portfolio.state='Active' order by title")
    List<Portfolio> findAll();
   
    @Query("from Portfolio where ownerId=:ownerId order by title")
	public List<Portfolio> findByOwnerId(@Param("ownerId") Integer ownerId);

    @Query("from Portfolio where state=:status order by title")
	public List<Portfolio> findByStatus(@Param("status") String status);
    
    @Query("SELECT COUNT(*) FROM Portfolio WHERE ownerId = :userId")
	Integer getPortfolioHeadCountForUser(@Param("userId") Integer userId);
}
