package com.infocepts.otc.repositories;

import java.util.List;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import com.infocepts.otc.entities.AssociateSkills;

public interface AssociateSkillsRepository extends CrudRepository<AssociateSkills,Integer>{

	@Override
	public List<AssociateSkills> findAll();
	
	@Query("from AssociateSkills where uid=:uid")
	public List<AssociateSkills> findByUid(@Param(value = "uid") Integer uid);
}
