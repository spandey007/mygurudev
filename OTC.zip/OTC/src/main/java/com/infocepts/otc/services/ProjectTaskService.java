package com.infocepts.otc.services;

import com.infocepts.otc.entities.ProjectTask;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@Service
public interface ProjectTaskService {

    List<ProjectTask> getAllTasksForProject(final Integer projectId);

    List<ProjectTask> saveAllTasksForProject(final Integer projectId, final List<ProjectTask> taskCenterList);

    void disableTasksNotInTaskCenterList(final Integer projectId, final List<ProjectTask> taskCenterList);

    void getNewlyAssignedTaskDetails(List<ProjectTask> oldProjectTaskList, List<ProjectTask> newProjectTaskList, HttpServletRequest request);

    void sendTaskAssignmentMail(ProjectTask taskinfo, List<String> resourceIds, HttpServletRequest request);

}
