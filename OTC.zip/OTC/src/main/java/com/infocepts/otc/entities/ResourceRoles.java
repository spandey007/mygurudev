package com.infocepts.otc.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.infocepts.otc.utilities.LoadConstant;

@Entity
@Table(catalog=LoadConstant.otc,schema="[dbo]",name="resource_roles")
public class ResourceRoles {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer resourceRoleId;
	
	@ManyToOne
	@JoinColumn(name="roleId")
	private Roles roles;
	
	private Integer uid;
	
	private Boolean status;
	
	public Integer getResourceRoleId() {
		return resourceRoleId;
	}
	public void setResourceRoleId(Integer resourceRoleId) {
		this.resourceRoleId = resourceRoleId;
	}
	public Integer getUid() {
		return uid;
	}
	public void setUid(Integer uid) {
		this.uid = uid;
	}	
	public Roles getRoles() {
		return roles;
	}
	public void setRoles(Roles roles) {
		this.roles = roles;
	}	
	
	public Boolean getStatus() {
		return status;
	}
	public void setStatus(Boolean status) {
		this.status = status;
	}
	
	@Override
	public String toString() {
		return "ResourceRoles [resourceRolesId=" + resourceRoleId + ", roles=" + roles + ", uid=" + uid + "]";
	}	
	
}
