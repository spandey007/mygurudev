package com.infocepts.otc.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.infocepts.otc.entities.CT_Technology;
import com.infocepts.otc.repositories.CT_TechnologyRepository;
import com.infocepts.otc.services.TimesheetService;

@RestController
@RequestMapping(value="/technology",headers="referer")
public class CT_TechnologyController {
	@Autowired
	CT_TechnologyRepository ct_TechnologyRepository;
	
	@Autowired
	TimesheetService service;
	
	@RequestMapping(method=RequestMethod.POST)
	public CT_Technology addCT_Technology(@RequestBody CT_Technology cT_Technology){
		cT_Technology.setTechnologyId(null);
		Boolean isAValidCall = false;
		if(service.isHR() || service.isAdmin())
		{
			isAValidCall = true;
		}
		if(isAValidCall) {
			
			ct_TechnologyRepository.save(cT_Technology);
		}
		return cT_Technology;
	}
	
	@RequestMapping(method=RequestMethod.GET)
	public List<CT_Technology> getCT_Technology(){
		List<CT_Technology> list = null;
		/*Boolean isAValidCall = false;
		if(service.isHR() || service.isAdmin())
		{
			isAValidCall = true;
		}*/
		//if(isAValidCall) {
			list = ct_TechnologyRepository.findAll();
		//}
		return list;
	}
	
	@RequestMapping(value="/{technologyId}",method=RequestMethod.GET)
	public CT_Technology getCT_Technology(@PathVariable Integer technologyId){
		CT_Technology cT_Technology = null;
		Boolean isAValidCall = false;
		if(service.isHR() || service.isAdmin())
		{
			isAValidCall = true;
		}
		if(isAValidCall) {
			
			cT_Technology = ct_TechnologyRepository.findOne(technologyId);
		}
		return cT_Technology;
	}
	
	@RequestMapping(value="/{technologyId}", method=RequestMethod.PUT)
	public CT_Technology updateCT_Technology(@PathVariable Integer technologyId,  @RequestBody CT_Technology updatedCT_Technology){
		updatedCT_Technology.setTechnologyId(technologyId);
		Boolean isAValidCall = false;
		if(service.isHR() || service.isAdmin())
		{
			isAValidCall = true;
		}
		if(isAValidCall) {
			ct_TechnologyRepository.save(updatedCT_Technology);
		}
		return updatedCT_Technology;
	}
	
	@RequestMapping(value="/{technologyId}",method=RequestMethod.DELETE)
	public void deleteCT_Technology(@PathVariable Integer technologyId){
		Boolean isAValidCall = false;
		if(service.isHR() || service.isAdmin())
		{
			isAValidCall = true;
		}
		if(isAValidCall) {
			ct_TechnologyRepository.delete(technologyId);
		}
	}
}

