package com.infocepts.otc.entities;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.infocepts.otc.utilities.LoadConstant;


@SqlResultSetMapping(
		name = "get_info_traveldesk",
	      classes = {
	          @ConstructorResult(
	              targetClass = InfoTravelDesk.class,
	              columns = {
	            	//normal cols
	            		//normal cols
	            		  @ColumnResult(name = "infoTravelDeskId"),
	            		  @ColumnResult(name = "parentId"),
	            		  @ColumnResult(name = "travelDeskFlag"),
	            		  @ColumnResult(name = "requestDate", type=Date.class),
	            		  @ColumnResult(name = "transactionDate", type=Date.class),
	            		  @ColumnResult(name = "location", type=String.class),
	            		  @ColumnResult(name = "sector", type=String.class),
	            		  @ColumnResult(name = "service", type=String.class),
	            		  @ColumnResult(name = "serviceType", type=String.class),
	            		  @ColumnResult(name = "onwardDate", type=Date.class),
	            		  @ColumnResult(name = "returnDate", type=Date.class),
	            		  @ColumnResult(name = "serviceProvider", type=String.class),
	            		  @ColumnResult(name = "confirmationNo", type=String.class),
	            		  @ColumnResult(name = "ticketNo", type=String.class),
	            		  @ColumnResult(name = "remarks", type=String.class),
	            		  @ColumnResult(name = "confirmedCost", type=BigDecimal.class),
	            		  @ColumnResult(name = "highestCost", type=BigDecimal.class),
	            		  @ColumnResult(name = "lowestCost", type=BigDecimal.class),
	            		  @ColumnResult(name = "recovery", type=BigDecimal.class),
	            		  @ColumnResult(name = "vendor", type=String.class),
	            		  @ColumnResult(name = "exceptionalApproval", type=String.class),
	            		  @ColumnResult(name = "reasonForExceptionalApproval", type=String.class),
	            		  @ColumnResult(name = "attach", type=String.class),
	            		  @ColumnResult(name = "reissueService", type=String.class),
	            		  @ColumnResult(name = "reissueCost", type=BigDecimal.class),
	            		  @ColumnResult(name = "cancellationCost", type=BigDecimal.class),
	            		  @ColumnResult(name = "cancellationApprovar", type=String.class),
	            		  @ColumnResult(name = "reasonForChange", type=String.class),
	            		  @ColumnResult(name = "cancellationReasonForChange", type=String.class),
	            		  @ColumnResult(name = "cancellationStatus", type=String.class),
	            		  @ColumnResult(name = "invoiceDate", type=Date.class),
	            		  @ColumnResult(name = "invoiceNo", type=String.class),
	            		  
	            		  @ColumnResult(name = "basicFare", type=BigDecimal.class),
	            		  @ColumnResult(name = "yQTax", type=BigDecimal.class),
	            		  @ColumnResult(name = "others", type=BigDecimal.class),
	            		  @ColumnResult(name = "discount", type=BigDecimal.class),
	            		  @ColumnResult(name = "agentFee", type=BigDecimal.class),
	            		  @ColumnResult(name = "sGST", type=BigDecimal.class),
	            		  @ColumnResult(name = "cGST", type=BigDecimal.class),
	            		  @ColumnResult(name = "iGST", type=BigDecimal.class),
	            		  @ColumnResult(name = "invoiceAmount", type=BigDecimal.class),
	            		  @ColumnResult(name = "invoiceStatus", type=String.class),	            		  
	            		  
		                  @ColumnResult(name = "createdBy"),
		                  @ColumnResult(name = "createdDate", type=Date.class),
		                  @ColumnResult(name = "modifiedBy"),
		                  @ColumnResult(name = "modifiedDate", type=Date.class)
	                  }
	          )
	      }
	)
@NamedNativeQueries({
	   @NamedNativeQuery(			  
              
	            name    =   "getInfoTravelDesk",
	            query   =   " SELECT * FROM " + LoadConstant.otc + ".[dbo].[infoTravelDesk]" + 
	            			" where infoTravelId=:infoTravelId",
	                       resultClass=InfoTravelDesk.class, resultSetMapping = "get_info_traveldesk"                       		
	    )
	   
})

@Entity
@Table(catalog=LoadConstant.otc, schema="[dbo]",name="infoTravelDesk")
public class InfoTravelDesk {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer infoTravelDeskId;
	
	@ManyToOne
	@JoinColumn(name="infoTravelId")
	private InfoTravel infoTravel;
	
	private Integer parentId;
	private Integer travelDeskFlag;
	
	private Date requestDate;
	private Date transactionDate;
	private String location;
	private String sector;

	private String service;
	private String serviceType;
	private Date onwardDate;
	private Date returnDate;

	private String serviceProvider;
	private String confirmationNo;
	private String ticketNo;

	@Lob
	private String remarks;


	@Column(precision=12,scale=2)
	private BigDecimal confirmedCost;

	@Column(precision=12,scale=2)
	private BigDecimal highestCost;

	@Column(precision=12,scale=2)
	private BigDecimal lowestCost;

	@Column(precision=12,scale=2)
	private BigDecimal recovery;

	private String vendor;
	private Integer exceptionalApproval;

	@Lob
	private String reasonForExceptionalApproval;
	
	@Lob
	private String attach;

	private String reissueService;
	
	@Column(precision=12,scale=2)
	private BigDecimal reissueCost;

	@Column(precision=12,scale=2)
	private BigDecimal cancellationCost;

	private Integer cancellationApprover;
	private String reasonForChange;
	private String cancellationReasonForChange;
	private String cancellationStatus;

	private Date invoiceDate;
	private String invoiceNo;

	@Column(precision=12,scale=2)
	private BigDecimal basicFare;

	@Column(precision=12,scale=2)
	private BigDecimal yQTax;

	@Column(precision=12,scale=2)
	private BigDecimal others;

	@Column(precision=12,scale=2)
	private BigDecimal discount;

	@Column(precision=12,scale=2)
	private BigDecimal agentFee;

	@Column(precision=12,scale=2)
	private BigDecimal sGST;

	@Column(precision=12,scale=2)
	private BigDecimal cGST;

	@Column(precision=12,scale=2)
	private BigDecimal iGST;

	@Column(precision=12,scale=2)
	private BigDecimal invoiceAmount;
	
	private String invoiceStatus;

	private Integer createdBy;
	private Date createdDate;
	private Integer modifiedBy;
	private Date modifiedDate;
	
	@Transient
	private Integer isChild;
	
	
	
	
	//getter setter
	
	
	
	public Integer getIsChild() {
		return isChild;
	}

	public void setIsChild(Integer isChild) {
		this.isChild = isChild;
	}

	public Integer getParentId() {
		return parentId;
	}

	public void setParentId(Integer parentId) {
		this.parentId = parentId;
	}

	public Integer getTravelDeskFlag() {
		return travelDeskFlag;
	}

	public void setTravelDeskFlag(Integer travelDeskFlag) {
		this.travelDeskFlag = travelDeskFlag;
	}

	public Date getRequestDate() {
		return requestDate;
	}

	public void setRequestDate(Date requestDate) {
		this.requestDate = requestDate;
	}
	

	public Integer getInfoTravelDeskId() {
		return infoTravelDeskId;
	}

	public void setInfoTravelDeskId(Integer infoTravelDeskId) {
		this.infoTravelDeskId = infoTravelDeskId;
	}

	public InfoTravel getInfoTravel() {
		return infoTravel;
	}

	public void setInfoTravel(InfoTravel infoTravel) {
		this.infoTravel = infoTravel;
	}

	public Date getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = transactionDate;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getSector() {
		return sector;
	}

	public void setSector(String sector) {
		this.sector = sector;
	}

	public String getService() {
		return service;
	}

	public void setService(String service) {
		this.service = service;
	}

	public String getServiceType() {
		return serviceType;
	}

	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}

	public Date getOnwardDate() {
		return onwardDate;
	}

	public void setOnwardDate(Date onwardDate) {
		this.onwardDate = onwardDate;
	}

	public Date getReturnDate() {
		return returnDate;
	}

	public void setReturnDate(Date returnDate) {
		this.returnDate = returnDate;
	}

	public String getServiceProvider() {
		return serviceProvider;
	}

	public void setServiceProvider(String serviceProvider) {
		this.serviceProvider = serviceProvider;
	}

	public String getConfirmationNo() {
		return confirmationNo;
	}

	public void setConfirmationNo(String confirmationNo) {
		this.confirmationNo = confirmationNo;
	}

	public String getTicketNo() {
		return ticketNo;
	}

	public void setTicketNo(String ticketNo) {
		this.ticketNo = ticketNo;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public BigDecimal getConfirmedCost() {
		return confirmedCost;
	}

	public void setConfirmedCost(BigDecimal confirmedCost) {
		this.confirmedCost = confirmedCost;
	}

	public BigDecimal getHighestCost() {
		return highestCost;
	}

	public void setHighestCost(BigDecimal highestCost) {
		this.highestCost = highestCost;
	}

	public BigDecimal getLowestCost() {
		return lowestCost;
	}

	public void setLowestCost(BigDecimal lowestCost) {
		this.lowestCost = lowestCost;
	}

	public BigDecimal getRecovery() {
		return recovery;
	}

	public void setRecovery(BigDecimal recovery) {
		this.recovery = recovery;
	}

	public String getVendor() {
		return vendor;
	}

	public void setVendor(String vendor) {
		this.vendor = vendor;
	}

	

	public Integer getExceptionalApproval() {
		return exceptionalApproval;
	}

	public void setExceptionalApproval(Integer exceptionalApproval) {
		this.exceptionalApproval = exceptionalApproval;
	}

	public String getReasonForExceptionalApproval() {
		return reasonForExceptionalApproval;
	}

	public void setReasonForExceptionalApproval(String reasonForExceptionalApproval) {
		this.reasonForExceptionalApproval = reasonForExceptionalApproval;
	}

	public String getAttach() {
		return attach;
	}

	public void setAttach(String attach) {
		this.attach = attach;
	}

	
	public String getReissueService() {
		return reissueService;
	}

	public void setReissueService(String reissueService) {
		this.reissueService = reissueService;
	}

	public BigDecimal getReissueCost() {
		return reissueCost;
	}

	public void setReissueCost(BigDecimal reissueCost) {
		this.reissueCost = reissueCost;
	}

	public BigDecimal getCancellationCost() {
		return cancellationCost;
	}

	public void setCancellationCost(BigDecimal cancellationCost) {
		this.cancellationCost = cancellationCost;
	}

	

	public Integer getCancellationApprover() {
		return cancellationApprover;
	}

	public void setCancellationApprover(Integer cancellationApprover) {
		this.cancellationApprover = cancellationApprover;
	}

	public String getReasonForChange() {
		return reasonForChange;
	}

	public void setReasonForChange(String reasonForChange) {
		this.reasonForChange = reasonForChange;
	}
	
	

	public String getCancellationReasonForChange() {
		return cancellationReasonForChange;
	}

	public void setCancellationReasonForChange(String cancellationReasonForChange) {
		this.cancellationReasonForChange = cancellationReasonForChange;
	}

	public String getCancellationStatus() {
		return cancellationStatus;
	}

	public void setCancellationStatus(String cancellationStatus) {
		this.cancellationStatus = cancellationStatus;
	}

	public Date getInvoiceDate() {
		return invoiceDate;
	}

	public void setInvoiceDate(Date invoiceDate) {
		this.invoiceDate = invoiceDate;
	}

	public String getInvoiceNo() {
		return invoiceNo;
	}

	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}

	public BigDecimal getBasicFare() {
		return basicFare;
	}

	public void setBasicFare(BigDecimal basicFare) {
		this.basicFare = basicFare;
	}

	public BigDecimal getyQTax() {
		return yQTax;
	}

	public void setyQTax(BigDecimal yQTax) {
		this.yQTax = yQTax;
	}

	public BigDecimal getOthers() {
		return others;
	}

	public void setOthers(BigDecimal others) {
		this.others = others;
	}

	public BigDecimal getDiscount() {
		return discount;
	}

	public void setDiscount(BigDecimal discount) {
		this.discount = discount;
	}

	public BigDecimal getAgentFee() {
		return agentFee;
	}

	public void setAgentFee(BigDecimal agentFee) {
		this.agentFee = agentFee;
	}

	public BigDecimal getsGST() {
		return sGST;
	}

	public void setsGST(BigDecimal sGST) {
		this.sGST = sGST;
	}

	public BigDecimal getcGST() {
		return cGST;
	}

	public void setcGST(BigDecimal cGST) {
		this.cGST = cGST;
	}

	public BigDecimal getiGST() {
		return iGST;
	}

	public void setiGST(BigDecimal iGST) {
		this.iGST = iGST;
	}

	public BigDecimal getInvoiceAmount() {
		return invoiceAmount;
	}

	public void setInvoiceAmount(BigDecimal invoiceAmount) {
		this.invoiceAmount = invoiceAmount;
	}
	
	
	public String getInvoiceStatus() {
		return invoiceStatus;
	}

	public void setInvoiceStatus(String invoiceStatus) {
		this.invoiceStatus = invoiceStatus;
	}

	public Integer getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Integer getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public InfoTravelDesk() {
		//super();
		// TODO Auto-generated constructor stub
	}

	//contructor
	public InfoTravelDesk(Integer infoTravelDeskId, InfoTravel infoTravel, Integer parentId, Integer travelDeskFlag, Date requestDate, Date transactionDate,
			String location, String sector, String service, String serviceType, Date onwardDate, Date returnDate,
			String serviceProvider, String confirmationNo, String ticketNo, String remarks, BigDecimal confirmedCost,
			BigDecimal highestCost, BigDecimal lowestCost, BigDecimal recovery, String vendor,
			Integer exceptionalApproval, String reasonForExceptionalApproval, String attach, String reissueService, BigDecimal reissueCost,
			BigDecimal cancellationCost, Integer cancellationApprover, String reasonForChange, String cancellationReasonForChange,
			String cancellationStatus, Date invoiceDate, String invoiceNo, BigDecimal basicFare, BigDecimal yQTax,
			BigDecimal others, BigDecimal discount, BigDecimal agentFee, BigDecimal sGST, BigDecimal cGST,
			BigDecimal iGST, BigDecimal invoiceAmount, String invoiceStatus, Integer createdBy, Date createdDate, Integer modifiedBy,
			Date modifiedDate) {
		super();
		this.infoTravelDeskId = infoTravelDeskId;
		this.infoTravel = infoTravel;
		this.parentId = parentId;
		this.travelDeskFlag = travelDeskFlag;
		this.requestDate = requestDate;
		this.transactionDate = transactionDate;
		this.location = location;
		this.sector = sector;
		this.service = service;
		this.serviceType = serviceType;
		this.onwardDate = onwardDate;
		this.returnDate = returnDate;
		this.serviceProvider = serviceProvider;
		this.confirmationNo = confirmationNo;
		this.ticketNo = ticketNo;
		this.remarks = remarks;
		this.confirmedCost = confirmedCost;
		this.highestCost = highestCost;
		this.lowestCost = lowestCost;
		this.recovery = recovery;
		this.vendor = vendor;
		this.exceptionalApproval = exceptionalApproval;
		this.reasonForExceptionalApproval = reasonForExceptionalApproval;
		this.attach = attach;
		this.reissueService = reissueService;
		this.reissueCost = reissueCost;
		this.cancellationCost = cancellationCost;
		this.cancellationApprover = cancellationApprover;
		this.reasonForChange = reasonForChange;
		this.cancellationReasonForChange = cancellationReasonForChange;
		this.cancellationStatus = cancellationStatus;
		this.invoiceDate = invoiceDate;
		this.invoiceNo = invoiceNo;
		this.basicFare = basicFare;
		this.yQTax = yQTax;
		this.others = others;
		this.discount = discount;
		this.agentFee = agentFee;
		this.sGST = sGST;
		this.cGST = cGST;
		this.iGST = iGST;
		this.invoiceAmount = invoiceAmount;
		this.invoiceStatus =invoiceStatus;
		this.createdBy = createdBy;
		this.createdDate = createdDate;
		this.modifiedBy = modifiedBy;
		this.modifiedDate = modifiedDate;
	}
	//contructor
}
