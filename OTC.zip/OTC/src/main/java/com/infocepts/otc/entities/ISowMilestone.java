/**
* Filename: /src/main/java/com/infocepts/otc/controllers/ISowMilestone.java
* @author  JV
* @version 1.0
* @since   2018-10-31 
*/
package com.infocepts.otc.entities;

	import java.math.BigDecimal;
	import java.util.Date;

	import javax.persistence.Column;
	import javax.persistence.Entity;
	import javax.persistence.GeneratedValue;
	import javax.persistence.GenerationType;
	import javax.persistence.Id;
	import javax.persistence.JoinColumn;
	import javax.persistence.Lob;
	import javax.persistence.ManyToOne;
	import javax.persistence.Table;
	import com.infocepts.otc.utilities.LoadConstant;

	@Entity
	@Table(catalog=LoadConstant.otc, schema="[dbo]",name="isowMilestone")
	public class ISowMilestone {

		@Id
		@GeneratedValue(strategy=GenerationType.IDENTITY)
		private Integer isowMilestoneId;
		
		private Integer milestoneId;

		private Date milestoneStartDate;
		private Date milestoneEndDate;
		
		@Column(precision=18,scale=2)
		private BigDecimal amount;
		
		@Lob
		private String description;
		
	    private Date createdDate;
		private Date modifiedDate;
	
		private String uom;
		@Column(precision=6,scale=2)
		private BigDecimal expectedBillability;
		/*@Column(precision=8,scale=4)
		private BigDecimal conversionRate;*/
		@Column(precision=18,scale=2)
		private BigDecimal rateInSGD;
		
		@ManyToOne
		//@OnDelete(action=OnDeleteAction.CASCADE)
		@JoinColumn(name="isowId")
		private ISow isow;
		
		private Integer createdBy;
		private Integer modifiedBy;
		
		
		public Integer getIsowMilestoneId() {
			return isowMilestoneId;
		}
		public void setIsowMilestoneId(Integer isowMilestoneId) {
			this.isowMilestoneId = isowMilestoneId;
		}
		public Integer getMilestoneId() {
			return milestoneId;
		}
		public void setMilestoneId(Integer milestoneId) {
			this.milestoneId = milestoneId;
		}
		public Date getMilestoneStartDate() {
			return milestoneStartDate;
		}
		public void setMilestoneStartDate(Date milestoneStartDate) {
			this.milestoneStartDate = milestoneStartDate;
		}
		public Date getMilestoneEndDate() {
			return milestoneEndDate;
		}
		public void setMilestoneEndDate(Date milestoneEndDate) {
			this.milestoneEndDate = milestoneEndDate;
		}
		public BigDecimal getAmount() {
			return amount;
		}
		public void setAmount(BigDecimal amount) {
			this.amount = amount;
		}
		public ISow getIsow() {
			return isow;
		}
		public void setSow(ISow isow) {
			this.isow = isow;
		}
		public Integer getCreatedBy() {
			return createdBy;
		}
		public void setCreatedBy(Integer createdBy) {
			this.createdBy = createdBy;
		}
		public Integer getModifiedBy() {
			return modifiedBy;
		}
		public void setModifiedBy(Integer modifiedBy) {
			this.modifiedBy = modifiedBy;
		}
		public Date getCreatedDate() {
			return createdDate;
		}
		public void setCreatedDate(Date createdDate) {
			this.createdDate = createdDate;
		}
		public Date getModifiedDate() {
			return modifiedDate;
		}
		public void setModifiedDate(Date modifiedDate) {
			this.modifiedDate = modifiedDate;
		}
		public String getDescription() {
			return description;
		}
		public void setDescription(String description) {
			this.description = description;
		}
		
		/**
		 * @return the uom
		 */
		public String getUom() {
			return uom;
		}
		/**
		 * @param uom the uom to set
		 */
		public void setUom(String uom) {
			this.uom = uom;
		}
		/**
		 * @return the expectedBillability
		 */
		public BigDecimal getExpectedBillability() {
			return expectedBillability;
		}
		/**
		 * @param expectedBillability the expectedBillability to set
		 */
		public void setExpectedBillability(BigDecimal expectedBillability) {
			this.expectedBillability = expectedBillability;
		}
		/**
		 * @return the conversionRate
		 *//*
		public BigDecimal getConversionRate() {
			return conversionRate;
		}
		*//**
		 * @param conversionRate the conversionRate to set
		 *//*
		public void setConversionRate(BigDecimal conversionRate) {
			this.conversionRate = conversionRate;
		}*/
		/**
		 * @return the rateInSGD
		 */
		public BigDecimal getRateInSGD() {
			return rateInSGD;
		}
		/**
		 * @param rateInSGD the rateInSGD to set
		 */
		public void setRateInSGD(BigDecimal rateInSGD) {
			this.rateInSGD = rateInSGD;
		}
		
		
	}
