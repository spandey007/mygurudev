package com.infocepts.otc.repositories;

import java.util.List;
import org.springframework.data.repository.CrudRepository;
import com.infocepts.otc.entities.HrRoles;

public interface HrRolesRepository extends CrudRepository<HrRoles,Integer>{

	@Override
	public List<HrRoles> findAll();
}
