package com.infocepts.otc.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.infocepts.otc.entities.Unit;

public interface UnitRepository extends CrudRepository<Unit,Integer>{

	public List<Unit> findAll();
	
	@Query("from Unit u where u.status = :status")
	public List<Unit> findActiveUnits(@Param("status") boolean status);


	@Query("from Unit u where u.entity.entityId = :entityId and u.status = 1")
	public List<Unit> findByEntityId(@Param("entityId") Integer entityId);
}
