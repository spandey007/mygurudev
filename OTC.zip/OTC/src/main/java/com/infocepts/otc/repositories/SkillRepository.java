package com.infocepts.otc.repositories;

import java.util.List;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import com.infocepts.otc.entities.Skill;

public interface SkillRepository extends CrudRepository<Skill,Integer>{
	
	public List<Skill> findAll();
	
	@Query("select sk from Skill sk where status='Active' order by skillName")
	public List<Skill> findActiveStatusSkills();
	
	@Query("select sk from Skill sk where sk.skillCategory.skillCategoryId=:skillCategoryId")
	public List<Skill> findBySkillCategoryId(@Param("skillCategoryId") Integer skillCategoryId);
	
	@Query("select sk from Skill sk where sk.skillName like :skillName")
	public List<Skill> findSkillByName(@Param(value = "skillName") String skillName);
}
