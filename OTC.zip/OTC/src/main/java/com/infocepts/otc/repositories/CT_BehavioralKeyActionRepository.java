/**
* Filename: /src/main/java/com/infocepts/otc/repositories/CT_BehavioralKeyActionRepository.java
* @author  VVC
* @version 1.0
* @since   2018-12-03 
*/

package com.infocepts.otc.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import com.infocepts.otc.entities.CT_BehavioralKeyAction;

public interface CT_BehavioralKeyActionRepository extends CrudRepository<CT_BehavioralKeyAction,Integer>{

	@Override
	public List<CT_BehavioralKeyAction> findAll();
	
}

