/**
* Filename: /src/main/java/com/infocepts/otc/controllers/ISowDetailController.java
* @author  JV
* @version 1.0
* @since   2018-10-31 
*/
package com.infocepts.otc.controllers;


import java.util.List;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import javax.mail.MessagingException;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.infocepts.otc.entities.ISow;
import com.infocepts.otc.entities.ISowDetail;
import com.infocepts.otc.entities.ISowMilestone;
import com.infocepts.otc.repositories.ProjectRepository;
import com.infocepts.otc.repositories.ISowDetailRepository;
import com.infocepts.otc.repositories.ISowMilestoneRepository;
import com.infocepts.otc.repositories.ISowRepository;
import com.infocepts.otc.services.StoredProcedureService;
import com.infocepts.otc.services.TimesheetService;
import com.infocepts.otc.utilities.ExportUtil;


@RestController
@RequestMapping(value="/isowdetail",headers="referer")
public class ISowDetailController {

	@Autowired
	ISowDetailRepository repository;
	
	@Autowired
	ISowRepository isowRepository;
	
	@Autowired
	ProjectRepository projectRepository;
	
	@Autowired
	TimesheetService service;
	
	@Autowired
	HttpSession session;
	
	@Autowired
	ExportUtil exportUtil;
	
	@Autowired 
	StoredProcedureService storedProcedureService;
	
	@PersistenceContext
    private EntityManager manager;
	
	@Autowired
	ISowMilestoneRepository isowMilestoneRepository;
	
    final Logger logger = Logger.getLogger(ISowDetailController.class);
	
    @RequestMapping(method=RequestMethod.POST)
	public ISowDetail addISowDetail(@RequestBody ISowDetail isowdetail, 
			HttpServletRequest request) throws MessagingException {

		// ------------------------- Authorization start ------------------------------------ 
    	// Authorization for Admin, PMO
    	if(service.isPmo() || service.isAdmin())
 		{
			try{
				isowdetail.setIsowDetailId(null);
				repository.save(isowdetail);
			}catch(Exception e){
				logger.error(e);
			}
 		}
		return isowdetail;
	}	
 
	  @RequestMapping(method=RequestMethod.GET)
	 public List<ISowDetail> getAllSowDetail(@RequestParam(value = "sowId", defaultValue = "0") Integer sowId,
			 			@RequestParam(value = "isowId", defaultValue = "0") Integer isowId,
			 			@RequestParam(value = "sowStartDate", defaultValue = "")String sowStartDate,
			 			@RequestParam(value = "sowEndDate", defaultValue = "")String sowEndDate,
						HttpServletRequest request) throws MessagingException {
		 List<ISowDetail> isowdetaillist=null;
		 
		 /* ------------------------- Authorization start ------------------------------------ */
		// Authorization for Admin, PMO and Legal
		 if(service.isPmo() || service.isAdmin() || service.isLegal())
			{
				try
				 {		
					 if(isowId != 0) {
						 isowdetaillist = manager.createNamedQuery("getISowDetailsByISowId",ISowDetail.class)
					 				.setParameter("isowId", isowId)
					     			.getResultList();
					 }		 
				 }
				 catch(Exception e){
					 logger.error(e);
				 }
			}
		 return isowdetaillist;
	 }
	  
	  
		@RequestMapping(value="/download/{isowId}",method=RequestMethod.GET)
		public void downloadFile(@PathVariable(value = "isowId") Integer isowId, HttpServletResponse response) throws ServletException, Exception {		    
			if(isowId!=null){
				ISow ISow = isowRepository.findOne(isowId);
				String Filepath = ISow.getFilePath();
				File outputFile = new File(Filepath);
				// Authorization for Admin, PMO and Legal
				if(service.isPmo() || service.isAdmin() || service.isLegal())
				{			
					Path file = Paths.get(outputFile+"");
			        response.setContentType("application/msword");
			        response.addHeader("Content-Disposition", "attachment; filename="+file.getFileName());
			        Files.copy(file, response.getOutputStream());
			        response.getOutputStream().flush();
				}
			}
		}
	  
	  
		@RequestMapping(value="/download",method=RequestMethod.PUT)
		public void download(@RequestBody ISow isow,HttpServletRequest request) throws ServletException, Exception {
			List<ISowDetail> isowdetail = repository.findByIsowId(isow.getIsowId());
			List<ISowMilestone> isowMilestone = isowMilestoneRepository.findByISowId(isow.getIsowId());
			// Authorization for Admin, PMO and Legal
			if(service.isPmo() || service.isAdmin() || service.isLegal())
			{
				try{
					exportUtil.createISowPDF("pmo/isow/downloadTemplate/isow",isow,isowdetail,isowMilestone,request);  
	         	}
				catch(Exception e){
					 logger.info(e.getMessage()); 
				}
			}
			
			}

	 @RequestMapping(value="/{isowDetailId}",method=RequestMethod.PUT)
	 public ISowDetail updateISowDetail(@RequestBody ISowDetail updatedisowdetail,
			 							@PathVariable Integer isowDetailId, 
			 							HttpServletRequest request) throws MessagingException {
		 
		 //------------------------- Authorization start ------------------------------------
		// Authorization for Admin, PMO and Legal
		 if(service.isPmo() || service.isAdmin() || service.isLegal())
			{
				 try{
					 updatedisowdetail.setIsowDetailId(isowDetailId);
					 repository.save(updatedisowdetail);
				 }
				 catch(Exception e){
					 logger.error(e);
				 }
			}
		 return updatedisowdetail;
	 }
	 
	 @RequestMapping(value="/{isowDetailId}",method=RequestMethod.DELETE)
	 public void deleteISowDetail(@PathVariable Integer isowDetailId) {
		// Authorization for Admin, PMO
		if(service.isPmo() || service.isAdmin())
		{
			try{
				 repository.delete(isowDetailId);
			 }
			 catch(Exception e){
				 logger.error(e);
			 }
		}
	 }	
	
}
