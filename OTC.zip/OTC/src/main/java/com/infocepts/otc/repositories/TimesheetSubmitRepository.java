package com.infocepts.otc.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.infocepts.otc.entities.TimesheetSubmit;




@Repository
public interface TimesheetSubmitRepository extends JpaRepository<TimesheetSubmit,Integer>{
	
	@Override
	public List<TimesheetSubmit> findAll();
	
	@Query("select ts FROM TimesheetSubmit ts where ts.timesheet.timesheetId = :timesheetId")
	public List<TimesheetSubmit> findTimesheetSubmitByTs(@Param("timesheetId") Integer timesheetId);
	
	@Query("select ts FROM TimesheetSubmit ts where ts.projectId = :projectId AND ts.timesheet.timesheetId = :timesheetId")
	public List<TimesheetSubmit> findTimesheetSubmitByProjectAndTs(@Param("projectId") Integer projectId, @Param("timesheetId") Integer timesheetId);
}
