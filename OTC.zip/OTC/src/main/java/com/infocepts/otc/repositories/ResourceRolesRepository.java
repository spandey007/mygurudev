package com.infocepts.otc.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.infocepts.otc.entities.ResourceRoles;


public interface ResourceRolesRepository extends JpaRepository<ResourceRoles,Integer>{

	@Override
	public List<ResourceRoles> findAll();

	
	@Query("from ResourceRoles where uid=:resourceRoleId and status=1")
	public List<ResourceRoles> findResourceRoles(@Param(value="resourceRoleId") Integer resourceRoleId);
	
	@Query("from ResourceRoles where status=1")
	public List<ResourceRoles> findAllActiveResourceRoles();	
	 
	@Query("select count(rr) from ResourceRoles rr where rr.roles.roleId = :roleId")
	public List<ResourceRoles> findRoleAssignmentCount(@Param(value="roleId") Integer roleId);	
	
}
