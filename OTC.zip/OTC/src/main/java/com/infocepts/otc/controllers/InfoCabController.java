/**
* Filename: /src/main/java/com/infocepts/otc/controllers/InfoCabController.java
* @author  VVC
* @version 1.0
* @since   2018-09-03 
*/

package com.infocepts.otc.controllers;


import java.util.logging.Level;
import java.util.logging.Logger;


import com.infocepts.otc.entities.InfoCab;
import com.infocepts.otc.notification.SmtpMailSender;
import com.infocepts.otc.repositories.InfoCabRepository;
import com.infocepts.otc.utilities.DateConverter;
import com.infocepts.otc.services.TimesheetService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.mail.MessagingException;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;

@RestController
@RequestMapping(value = "/infocab", headers = "referer")
public class InfoCabController {

	final Logger logger = Logger.getLogger(InfoCabController.class.getName());

	@Autowired
	InfoCabRepository infoCabRepository;

	@Autowired
	HttpSession session;

	@PersistenceContext(unitName = "otc")
	private EntityManager manager;

	@Autowired
	TimesheetService service;
	
	@Autowired
	ResourceController resourceController;
	
	@Autowired
	private SmtpMailSender smtpMailSender;

	/**
	 * This method is used to find results set from module entity based on params
	 * passed from JS file
	 */
	@RequestMapping(method = RequestMethod.GET)
	public List<InfoCab> findAllInfoCab(@RequestParam(value = "uid", defaultValue = "0") Integer uid
			,@RequestParam(value = "infoCabId", defaultValue = "0") Integer infoCabId			
			,@RequestParam(value = "isPMPage", defaultValue = "false") Boolean isPMPage
			,@RequestParam(value = "isUserPage", defaultValue = "false") Boolean isUserPage
			,HttpServletRequest request) throws MessagingException{
			List<InfoCab> infoCablist = null;
			logger.info("uid="+uid);
			logger.info("isPMPage"+isPMPage);
			logger.info("isUserPage"+isUserPage);
			
			Integer loggedInUid = (Integer) session.getAttribute("loggedInUid");
			
			if(uid != 0){	//edit
				System.out.println("inside user page");
				infoCablist = manager.createNamedQuery("getInfoCab_by_Uid",InfoCab.class)
						.setParameter("uid", uid)
						 .getResultList();
			}
			else if(isPMPage){	//edit 	
				System.out.println("inside manager page");
				infoCablist = manager.createNamedQuery("getApprovalList_by_UId",InfoCab.class)					
						.setParameter("uid", loggedInUid)
						 .getResultList();
			}
			else if(infoCabId != 0){ // list for normal user
				System.out.println("inside infoCabId page");
				infoCablist = manager.createNamedQuery("getInfoCab_by_By_Id",InfoCab.class)					
						.setParameter("infoCabId", infoCabId)
						 .getResultList();
			}
			else { // list for travel team
				System.out.println("inside all page");
				infoCablist = manager.createNamedQuery("getInfoCab_by_All",InfoCab.class)
						.getResultList();
//				}
				/* ------------------------- Authorization ends ------------------------------------ */
				
			}
			 return infoCablist;
		}

	/**
	 * This method is add row in moduleName entity
	 * 
	 * @throws MessagingException
	 * 
	 */
	@RequestMapping(method = RequestMethod.POST)
	public InfoCab addInfoCab(@RequestBody InfoCab infoCab, HttpServletRequest request) throws MessagingException {
		// Authorization for XYZ role
			try {
				infoCab.setInfoCabId(null);
				infoCabRepository.save(infoCab);
				logger.info("inside add");
				service.sendInfoCabNotification(infoCab, "add", request);
			} catch (Exception e) {
				logger.info(String.format("exception - ", e));
			}

		return infoCab;
	}

	/**
	 * This method is update row in moduleName entity based on primaryKey Of Module
	 * Table
	 * 
	 * @throws MessagingException
	 */
	@RequestMapping(value = "/{infoCabId}", method = RequestMethod.PUT)
	public InfoCab updateInfoCab(@PathVariable Integer infoCabId,  @RequestBody InfoCab updatedInfoCab,HttpServletRequest request) {
		// Authorization for XYZ role
			try {
				updatedInfoCab.setInfoCabId(infoCabId);
				infoCabRepository.save(updatedInfoCab);
				service.sendInfoCabNotification(updatedInfoCab, "update", request);
			} catch (Exception e) {
				logger.info(String.format("exception - ", e));
			}
		
		return updatedInfoCab;
	}

	/**
	 * This method is get data for specific row in moduleName entity based on
	 * primaryKey Of Module Table
	 * 
	 * @throws MessagingException
	 */
	@RequestMapping(value = "/{infoCabId}", method = RequestMethod.GET)
	public InfoCab getInfoCab(@PathVariable Integer infoCabId, HttpServletRequest request)
			throws MessagingException {

		InfoCab infoCab = null;
		// Authorization for XYZ role
			try {
				System.out.println("inside getInfoCab"+infoCabId);
				infoCab = infoCabRepository.findOne(infoCabId);
				} catch (Exception e) {
				logger.info(String.format("exception - ", e));
			}

		return infoCab;
	}

	/**
	 * This method is delete data for specific row in moduleName entity based on
	 * primaryKey Of Module Table
	 * 
	 * @throws MessagingException
	 */
	@RequestMapping(value = "/{infoCabId}", method = RequestMethod.DELETE)
	public void deleteInfoCab(@PathVariable Integer infoCabId, HttpServletRequest request) throws MessagingException {
		// Authorization for XYZ role
		if (service.isTravel()) {
			try {
				infoCabRepository.delete(infoCabId);
			} catch (Exception e) {
				logger.info(String.format("exception - ", e));
			}
		} else {
			service.sendTamperedMail("Module Name delete", 0, 0, request);
		}
	}

	@GetMapping("/getListByUid")
	public Object getRequestListByUid(@RequestParam(value = "uid", defaultValue = "0") Integer uid,
									  HttpServletRequest request){
		List<InfoCab> list = null;
		try{
			list = manager.createNamedQuery("getInfoCab_by_Uid",InfoCab.class)
					.setParameter("uid", uid)
					.getResultList();
		}catch(Exception e){
			logger.log(Level.SEVERE, "exceptn msg", e);
		}
		return list;
	}

	@GetMapping("/getRequestById")
	public Object getRequestById(@RequestParam(value = "infoCabId", defaultValue = "0") Integer infoCabId,
									  HttpServletRequest request){
		InfoCab infoCab = null;
		try{
			infoCab = infoCabRepository.findOne(infoCabId);
		}catch(Exception e){
			logger.log(Level.SEVERE, "exceptn msg", e);
		}
		return infoCab;
	}

	@GetMapping("/getNewRequest")
    public Object getNewRequest(HttpServletRequest request){        
		List<InfoCab> list = null;
        try{
        	list = manager.createNamedQuery("getInfoCab_by_submissionStatus",InfoCab.class)
        			.getResultList();
        }catch(Exception e){
        	logger.log(Level.SEVERE, "exceptn msg", e);
        }
        return list;
    }
	
	
	@GetMapping("/getManagerApproval")
    public Object getManagerApproval(@RequestParam(value = "uid", defaultValue = "0") Integer uid,
    		HttpServletRequest request){        
		List<InfoCab> list = null;
        try{
        	list = manager.createNamedQuery("getApprovalList_by_UId",InfoCab.class)
				   .setParameter("uid", uid)
				   .getResultList();
        }catch(Exception e){
        	logger.log(Level.SEVERE, "exceptn msg", e);
        }
        return list;
    }
	
	@GetMapping("/getCabList")
	public Object getCabList(HttpServletRequest request){
		List<InfoCab> list = null;
		try{
			list = manager.createNamedQuery("getInfoCab_by_All",InfoCab.class)
					.getResultList();
		}catch(Exception e){
			logger.log(Level.SEVERE, "exceptn msg", e);
		}
		return list;
	}
	
	@GetMapping("/getApprovedList")
	public Object getApprovedList(HttpServletRequest request){
		List<InfoCab> list = null;
		try{
			list = manager.createNamedQuery("getApprovedList",InfoCab.class)
					.getResultList();
		}catch(Exception e){
			logger.log(Level.SEVERE, "exceptn msg", e);
		}
		return list;
	}

}
