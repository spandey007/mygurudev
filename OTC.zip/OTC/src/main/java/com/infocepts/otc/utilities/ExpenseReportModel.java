/**
 * 
 */
package com.infocepts.otc.utilities;

import java.util.Date;

/**
 * This class will be used to create a model object which 
 * @author Rewatiraman Singh
 *
 */
public class ExpenseReportModel extends Object {

	private Integer uid;
	private Integer projectId;
	private Date startDate;
	private Date endDate;
	private Integer status;
	private Integer travelStatus;
	private Integer financeStatus;
	private Integer entityId;
	private Integer unitId;
	private String expenseCode;
	/**
	 * @return the projectId
	 */
	public Integer getProjectId() {
		return projectId;
	}
	/**
	 * @param projectId the projectId to set
	 */
	public void setProjectId(Integer projectId) {
		this.projectId = projectId;
	}
	/**
	 * @return the startDate
	 */
	public Date getStartDate() {
		return startDate;
	}
	/**
	 * @param startDate the startDate to set
	 */
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	/**
	 * @return the endDate
	 */
	public Date getEndDate() {
		return endDate;
	}
	/**
	 * @param endDate the endDate to set
	 */
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	/**
	 * @return the status
	 */
	public Integer getStatus() {
		return status;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus(Integer status) {
		this.status = status;
	}
	/**
	 * @return the travelStatus
	 */
	public Integer getTravelStatus() {
		return travelStatus;
	}
	/**
	 * @param travelStatus the travelStatus to set
	 */
	public void setTravelStatus(Integer travelStatus) {
		this.travelStatus = travelStatus;
	}
	/**
	 * @return the financeStatus
	 */
	public Integer getFinanceStatus() {
		return financeStatus;
	}
	/**
	 * @param financeStatus the financeStatus to set
	 */
	public void setFinanceStatus(Integer financeStatus) {
		this.financeStatus = financeStatus;
	}
	/**
	 * @return the entityId
	 */
	public Integer getEntityId() {
		return entityId;
	}
	/**
	 * @param entityId the entityId to set
	 */
	public void setEntityId(Integer entityId) {
		this.entityId = entityId;
	}
	/**
	 * @return the unitId
	 */
	public Integer getUnitId() {
		return unitId;
	}
	/**
	 * @param unitId the unitId to set
	 */
	public void setUnitId(Integer unitId) {
		this.unitId = unitId;
	}
	/**
	 * @return the uid
	 */
	public Integer getUid() {
		return uid;
	}
	/**
	 * @param uid the uid to set
	 */
	public void setUid(Integer uid) {
		this.uid = uid;
	}

	public String getExpenseCode() {
		return expenseCode;
	}

	public void setExpenseCode(String expenseCode) {
		this.expenseCode = expenseCode;
	}
}
