package com.infocepts.otc.controllers;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.mail.MessagingException;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.infocepts.otc.entities.BusPass;
import com.infocepts.otc.notification.SmtpMailSender;
import com.infocepts.otc.repositories.BusPassRepository;
import com.infocepts.otc.services.TimesheetService;

@RestController
@RequestMapping(value="/buspass",headers="referer")
public class BusPassController {

	final Logger logger = Logger.getLogger(BusPassController.class.getName());
	 
	@Autowired
	BusPassRepository busPassRepository;
	
	@Autowired
	HttpSession session;
	
	@Autowired
	TimesheetService service;
	
	@PersistenceContext(unitName="otc")
    private EntityManager manager;
	
	@Autowired
	ResourceController resourceController;
	
	@Autowired
	private SmtpMailSender smtpMailSender;
	
	@RequestMapping(method=RequestMethod.GET)
	public List<BusPass> findAll(@RequestParam(value = "uid", defaultValue = "0") Integer uid
							,@RequestParam(value = "busPassId", defaultValue = "0") Integer busPassId
							,@RequestParam(value = "cardNo", defaultValue = "0") Integer cardNo
							,HttpServletRequest request) throws MessagingException{
		
		List<BusPass> list = null;	
		
		
	
		logger.info("uid="+uid);logger.info("busPassId="+busPassId);logger.info("cardNo="+cardNo);
		if(cardNo != 0){	//edit 	
			list = busPassRepository.findIfCardNoAssigned(cardNo);
		}
		else if(busPassId != 0){	//edit 	
			list = manager.createNamedQuery("getRoutes_BusPass_By_Id",BusPass.class)					
					.setParameter("busPassId", busPassId)
					 .getResultList();
		}
		else if(uid != 0){ // list for normal user
			list = manager.createNamedQuery("getRoutes_BusPass_By_Uid",BusPass.class)
					.setParameter("uid", uid)
					 .getResultList();
		}
		else { // list for travel team
			/* ------------------------- Authorization start ------------------------------------ */
			// Authorization for travel role
//			if(!service.isTravel() && !service.isAdmin())
//			{
//				service.sendTamperedMail("bus pass view all", 0, 0, request);
//				return list;
//			}else {
				list = manager.createNamedQuery("getRoutes_BusPass_All",BusPass.class)
						.getResultList();
//			}
			/* ------------------------- Authorization ends ------------------------------------ */
			
		}
		
		return list;
	}
	
	@RequestMapping(value="/{busPassId}",method=RequestMethod.GET)
	public BusPass getBusPassById(@PathVariable Integer busPassId){
		BusPass busPass = null;		
		try{
			busPass = manager.createNamedQuery("getRoutes_BusPass_By_Id",BusPass.class)					
					.setParameter("busPassId", busPassId)
					.getSingleResult();
		 }
		 catch(Exception e){
			 logger.info(String.format("exception - ", e));
		 }		
		return busPass;
	}

	
	@RequestMapping(method=RequestMethod.POST)
	public BusPass saveBusPass(@RequestBody BusPass busPass,HttpServletRequest request) throws MessagingException{
			
		try{
			busPass.setBusPassId(null);			
			busPassRepository.save(busPass);
			service.sendBuspassNotification(busPass, "add", request);
		}
		 catch(Exception e){
			 logger.info(String.format("exception - ", e));
		 }	
		return busPass;
	}
	
	@RequestMapping(value="/{busPassId}", method=RequestMethod.PUT)
	public BusPass updateBusPass(@PathVariable Integer busPassId,  @RequestBody BusPass updatedBusPass,HttpServletRequest request){
		try{
			updatedBusPass.setBusPassId(busPassId);			
			updatedBusPass = busPassRepository.save(updatedBusPass);
			logger.info("INSIDE UPDATE");
			service.sendBuspassNotification(updatedBusPass, "update", request);			
			
		 }
		 catch(Exception e){
			 logger.info(String.format("exception - ", e));
		 }
		
		return updatedBusPass;
	}
	
	@RequestMapping(value="/{busPassId}",method=RequestMethod.DELETE)
	public void deleteBusPass(@PathVariable Integer busPassId){
		try{
			busPassRepository.delete(busPassId);			
		 }
		 catch(Exception e){
			 logger.info(String.format("exception - ", e));
		 }
		
	}
	
	@GetMapping("/getBusPass")
    public Object getBusPass(@RequestParam(value = "busPassId", defaultValue = "0") Integer busPassId,
            HttpServletRequest request){
        
        BusPass busPass = null;
        try{
            busPass = manager.createNamedQuery("getRoutes_BusPass_By_Id",BusPass.class)                    
                    .setParameter("busPassId", busPassId)
                    .getSingleResult();
        }catch(Exception e){
            logger.log(Level.SEVERE, "exceptn msg", e);
        }
        return busPass;
    }
}
