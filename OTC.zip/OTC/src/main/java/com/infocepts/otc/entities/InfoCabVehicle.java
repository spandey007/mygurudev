package com.infocepts.otc.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.infocepts.otc.utilities.LoadConstant;

@Entity
@Table(catalog=LoadConstant.otc, schema="[dbo]",name="infocabvehicle")
public class InfoCabVehicle {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer infoCabVehicleId;
	private String vehicleName;
	private String vehicleNumber;
	public Integer getInfoCabVehicleId() {
		return infoCabVehicleId;
	}
	public void setInfoCabVehicleId(Integer infoCabVehicleId) {
		this.infoCabVehicleId = infoCabVehicleId;
	}
	public String getVehicleName() {
		return vehicleName;
	}
	public void setVehicleName(String vehicleName) {
		this.vehicleName = vehicleName;
	}
	public String getVehicleNumber() {
		return vehicleNumber;
	}
	public void setVehicleNumber(String vehicleNumber) {
		this.vehicleNumber = vehicleNumber;
	}
	
	
	
}
