package com.infocepts.otc.entities;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.SqlResultSetMappings;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.infocepts.otc.utilities.LoadConstant;

@Entity
@Table(catalog=LoadConstant.otc, schema="[dbo]",name="exitAccess")

@SqlResultSetMappings({
    @SqlResultSetMapping(
            name = "list_all_Resources",
            classes = {
                    @ConstructorResult(
                            targetClass = ExitAccess.class,
                            columns = {
                            		@ColumnResult(name = "exitAccessId"),
									@ColumnResult(name = "createdBy"),	
									@ColumnResult(name = "createdDate", type = Date.class),
                                    @ColumnResult(name = "uId"), 	
                                    @ColumnResult(name = "title", type = String.class),
                                    @ColumnResult(name = "createdByTitle", type = String.class),
                                    @ColumnResult(name = "permMobNumber", type = String.class),
                                    @ColumnResult(name = "workExtension", type = String.class)
                                    
                            }
                    )
            }
    )
})
@NamedNativeQueries({
    @NamedNativeQuery(
            name    =   "getAllResourceData",   
            query 	=   "select e.*,r.title,rr.title as createdByTitle,r.permMobNumber,r.workExtension"+
						" FROM " + LoadConstant.otc + ".[dbo].[exitAccess] e"+
						" Left JOIN " + LoadConstant.infomaster + ".[dbo].[resource] as r on e.uid = r.uid "+						
						" Left JOIN " + LoadConstant.infomaster + ".[dbo].[resource] as rr on e.createdBy=rr.uid order by e.exitAccessId desc",						
						resultClass=ExitAccess.class, resultSetMapping = "list_all_Resources"
    )        
})


public class ExitAccess {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	public Integer exitAccessId;
	public Integer uId;
	public Integer createdBy;
	public Date createdDate;
	
    @Transient
    private String title;
    
    @Transient
    private String createdByTitle;
    
    @Transient
    private String permMobNumber;
    
    @Transient
    private String workExtension;
	
	public Integer getExitAccessId() {
		return exitAccessId;
	}
	public void setExitAccessId(Integer exitAccessId) {
		this.exitAccessId = exitAccessId;
	}
	
	public Integer getuId() {
		return uId;
	}
	public void setuId(Integer uId) {
		this.uId = uId;
	}
	
	public Integer getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	
	public String getCreatedByTitle() {
		return createdByTitle;
	}
	public void setCreatedByTitle(String createdByTitle) {
		this.createdByTitle = createdByTitle;
	}


	public String getPermMobNumber() {
		return permMobNumber;
	}
	public void setPermMobNumber(String permMobNumber) {
		this.permMobNumber = permMobNumber;
	}
	public String getWorkExtension() {
		return workExtension;
	}
	public void setWorkExtension(String workExtension) {
		this.workExtension = workExtension;
	}
	public ExitAccess() {
		
    }
	public ExitAccess(Integer exitAccessId, Integer createdBy, Date createdDate, Integer uId, String title,
			String createdByTitle, String permMobNumber, String workExtension) {
		super();
		this.exitAccessId = exitAccessId;
		this.createdBy = createdBy;
		this.createdDate = createdDate;
		this.uId = uId;
		this.title = title;
		this.createdByTitle = createdByTitle;
		this.permMobNumber = permMobNumber;
		this.workExtension = workExtension;
	}




}
