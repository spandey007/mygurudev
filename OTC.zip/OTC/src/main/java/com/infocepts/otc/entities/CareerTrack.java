package com.infocepts.otc.entities;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.infocepts.otc.utilities.LoadConstant;

@Entity
@Table(catalog=LoadConstant.otc, schema="[dbo]",name="careerTrack")
public class CareerTrack {


	// Entity Columns
    // --------------------------------------------------------------------------------
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Integer careerTrackId;
    private Integer gradeId;
    private Integer departmentId;
    private Integer skillId;
    private Integer roleId;
    private Integer proficiencyLevelId;
    
    @ManyToOne
	@JoinColumn(name="functionalKeyActionId")
	private CT_FunctionalKeyAction functionalKeyAction;

    
    @ManyToOne
	@JoinColumn(name="functionalTrainingId")
	private CT_FunctionalTraining functionalTraining;

    @ManyToOne
	@JoinColumn(name="behavioralKeyActionId")
	private CT_BehavioralKeyAction behavioralKeyAction;
    
    @ManyToOne
	@JoinColumn(name="behavioralTrainingId")
	private CT_BehavioralTraining behavioralTraining;   
    
    @ManyToOne
	@JoinColumn(name="competencyId")
	private CT_Competency competency;
    
    private Integer uid;
    private Integer createdBy;
	private Date createdDate;
	private Integer modifiedBy;
	private Date modifiedDate;
	
	 // Getter setter
 	// --------------------------------------------------------------------------------
	
	public Integer getCareerTrackId() {
		return careerTrackId;
	}
	public void setCareerTrackId(Integer careerTrackId) {
		this.careerTrackId = careerTrackId;
	}
	public Integer getGradeId() {
		return gradeId;
	}
	public void setGradeId(Integer gradeId) {
		this.gradeId = gradeId;
	}
	public Integer getDepartmentId() {
		return departmentId;
	}
	public void setDepartmentId(Integer departmentId) {
		this.departmentId = departmentId;
	}
	public Integer getSkillId() {
		return skillId;
	}
	public void setSkillId(Integer skillId) {
		this.skillId = skillId;
	}
	public Integer getRoleId() {
		return roleId;
	}
	public void setRoleId(Integer roleId) {
		this.roleId = roleId;
	}
	public Integer getProficiencyLevelId() {
		return proficiencyLevelId;
	}
	public void setProficiencyLevelId(Integer proficiencyLevelId) {
		this.proficiencyLevelId = proficiencyLevelId;
	}
	public CT_FunctionalKeyAction getFunctionalKeyAction() {
		return functionalKeyAction;
	}
	public void setFunctionalKeyAction(CT_FunctionalKeyAction functionalKeyAction) {
		this.functionalKeyAction = functionalKeyAction;
	}
	public CT_FunctionalTraining getFunctionalTraining() {
		return functionalTraining;
	}
	public void setFunctionalTraining(CT_FunctionalTraining functionalTraining) {
		this.functionalTraining = functionalTraining;
	}
	public CT_BehavioralKeyAction getBehavioralKeyAction() {
		return behavioralKeyAction;
	}
	public void setBehavioralKeyAction(CT_BehavioralKeyAction behavioralKeyAction) {
		this.behavioralKeyAction = behavioralKeyAction;
	}
	public CT_BehavioralTraining getBehavioralTraining() {
		return behavioralTraining;
	}
	public void setBehavioralTraining(CT_BehavioralTraining behavioralTraining) {
		this.behavioralTraining = behavioralTraining;
	}
	public CT_Competency getCompetency() {
		return competency;
	}
	public void setCompetency(CT_Competency competency) {
		this.competency = competency;
	}
	public Integer getUid() {
		return uid;
	}
	public void setUid(Integer uid) {
		this.uid = uid;
	}
	public Integer getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public Integer getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public Date getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	
	
    
    
    
}
