/**
* Filename: /src/main/java/com/infocepts/otc/controllers/DeValueAddController.java
* @author  SHRI
* @version 1.0
* @since   2018-11-28 
*/

package com.infocepts.otc.controllers;

import java.util.logging.Logger;
import com.infocepts.otc.entities.DeGovernance;
import com.infocepts.otc.entities.DeValueAdd;
import com.infocepts.otc.entities.ISow;
import com.infocepts.otc.repositories.DeValueAddRepository;
import com.infocepts.otc.utilities.DateConverter;
import com.infocepts.otc.utilities.ExportUtil;
import com.infocepts.otc.services.TimesheetService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.mail.MessagingException;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.io.File;
import java.io.FileNotFoundException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

@RestController
@RequestMapping(value="/valueadd",headers="referer")
public class DeValueAddController {

    final Logger logger = Logger.getLogger(DeValueAddController.class.getName());

    @Autowired
    DeValueAddRepository deValueAddRepository;
    
    @Autowired
    HttpSession session;

    @PersistenceContext(unitName = "otc") 
    private EntityManager manager;
			
	@Autowired
	ExportUtil exportUtil;
	
	@Autowired
	TimesheetService service;
	String path=null;
	String filepath="";
	
    @RequestMapping(method = RequestMethod.GET)
    public List<DeValueAdd> findAll(@RequestParam(value = "view", defaultValue = "0") String view ,HttpServletRequest request) throws MessagingException{
         List<DeValueAdd> DeValueAddList = null;
         Integer loggedInUid = (Integer) session.getAttribute("loggedInUid");
		 boolean isDEMember = false;
		 boolean isPMOMember = false;
		 //Get the user roles
		 String userRoles = session.getAttribute("userRoles") != null ? session.getAttribute("userRoles").toString() : "";
		 int uid = session.getAttribute("loggedInUid") != null ? Integer.valueOf(session.getAttribute("loggedInUid").toString()) : 0;
		 if(userRoles.toLowerCase().contains("de")) isDEMember = true;
		 if(userRoles.toLowerCase().contains("pmo")) isPMOMember = true;
		 
        try {
	   		 if( (view.equals("de") && isDEMember) || (view.equals("pmo") && isPMOMember) || (view.equals("dh") && uid == 512)){
	
	   			DeValueAddList = manager.createNamedQuery("getAllDeValueAddData", DeValueAdd.class)
		 				.setParameter("uid", uid)
	    				.setParameter("view", view)
		 				.getResultList();
	        }else if(view.equals("pm") || view.equals("ph") || view.equals("cep") ){
	        		DeValueAddList = manager.createNamedQuery("getAllDeValueAddData", DeValueAdd.class)
			 				.setParameter("uid", uid)
	        				.setParameter("view", view)
			 				.getResultList();
		 	}

         } 
		catch (Exception e){
			e.printStackTrace();
			 logger.info(String.format("exception - ", e));
        }
        
        return DeValueAddList;

    }
    
    

	   @RequestMapping(value = "/{valueAddId}", method=RequestMethod.GET)
	    public DeValueAdd findDeValueAddId(@PathVariable("valueAddId") Integer valueAddId){
	        return this.deValueAddRepository.findOne(valueAddId);
	    }
    
    /**
     * This method is add row in moduleName entity
     * 
     */
    @RequestMapping(method=RequestMethod.POST)
	public DeValueAdd addDeValueAdd(@RequestBody DeValueAdd deValueAdd, HttpServletRequest request) {
		// Authorization for XYZ role
			try{
				deValueAdd.setValueAddId(null);
				deValueAddRepository.save(deValueAdd);
				service.sendDeValueAddNotification(deValueAdd, "add", request);
			}
			catch(Exception e){
				 logger.info(String.format("exception - ", e));
			}
		
		return deValueAdd;
	}
//    
    
	@RequestMapping(value="/upload/{valueAddId}",method=RequestMethod.POST,consumes = {"multipart/form-data"})
    @ResponseBody
	public String uploadFile(@RequestPart("file") MultipartFile file,@PathVariable(value = "valueAddId") Integer valueAddId,HttpServletRequest request)
	{	
		DeValueAdd devalueadd = deValueAddRepository.findOne(valueAddId);
		String type ="valueAdd";
		path=exportUtil.getDeFilePath(file,request,valueAddId,type);		
		devalueadd.setFilepath(path);				
		deValueAddRepository.save(devalueadd);
		return path;
	}
	
	@RequestMapping(value="/download/{valueAddId}",method=RequestMethod.GET)
	public void download(@PathVariable(value = "valueAddId") Integer valueAddId,HttpServletRequest request,HttpServletResponse response) throws ServletException, Exception {
		String path=null;
		File home=exportUtil.checkPath(request);
		String separator=File.separator;
		String Filepath = "";
		path=home.getPath();
		
		DeValueAdd deAppreciation =deValueAddRepository.findOne(valueAddId);


			Filepath = deAppreciation.getFilepath();

		
		List<String> list = Arrays.asList(Filepath.split("\\s*,\\s*"));
	
		if(list.size() > 1){
		
			if (home.exists() && home.isDirectory()) {
				 logger.info("home is a directory");
				    if(path.equals(separator)){
					 	path="usr"+File.separator+"home"+File.separator+"Download";
					}
					else{
						path=File.separator+"usr"+File.separator+"home"+File.separator+"Download";
					}
				
					if (Files.isDirectory(Paths.get(home + path))) {
						if(path.equals(separator)){
							path="usr"+File.separator+"home"+File.separator+"Download"+File.separator+"infotravel";
						}
						else{
							path=File.separator+"usr"+File.separator+"home"+File.separator+"Download"+File.separator+"infotravel";
						}
						
						if (Files.isDirectory(Paths.get(home + path))) {
							if(path.equals(separator)){
								path="usr"+File.separator+"home"+File.separator+"Download"+File.separator+"infotravel"+File.separator;
							}
							else{
								path=File.separator+"usr"+File.separator+"home"+File.separator+"Download"+File.separator+"infotravel"+File.separator;
							}
							
						} 
					}
				
			}
			
			
		}
		else{
			try{
				File outputFile = new File(Filepath);
				Path file = Paths.get(outputFile+"");
			    response.addHeader("Content-Disposition", "attachment; filename="+file.getFileName());
			    Files.copy(file, response.getOutputStream());
			    response.getOutputStream().flush();
			}
			catch(FileNotFoundException fe){
				fe.printStackTrace();
			}
		}
	}
	
	
//    
    /**
     * This method is update row in moduleName entity
     * based on primaryKey Of Module Table 
     */
	
    @RequestMapping(value="/{valueAddId}",method=RequestMethod.PUT)
	 public DeValueAdd updateDeValueAdd(@RequestBody DeValueAdd DeValueAdd,@PathVariable Integer valueAddId,HttpServletRequest request){
	
			try{
				 DeValueAdd.setValueAddId(valueAddId);
				 deValueAddRepository.save(DeValueAdd);
			}
			catch(Exception e){
				 logger.info(String.format("exception - ", e));
			}
		 return DeValueAdd;
	 }

    
    /**
     * This method is delete data for specific row in moduleName entity
     * based on primaryKey Of Module Table 
     */	 
	@RequestMapping(value= "/{valueAddId}",method=RequestMethod.DELETE)
	public void deleteDeMsr(@PathVariable Integer valueAddId, HttpServletRequest request) {
			try{
				if(valueAddId!=null) {
					DeValueAdd deValueAdd = deValueAddRepository.findOne(valueAddId);
					service.sendDeValueAddNotification(deValueAdd, "delete", request);
					deValueAddRepository.delete(valueAddId);						
				}
			}
			catch(Exception e){
				 logger.info(String.format("exception - ", e));
			}
	}
	
  
   
}
