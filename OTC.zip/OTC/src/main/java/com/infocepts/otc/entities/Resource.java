package com.infocepts.otc.entities;

import java.util.Date;
import javax.persistence.*;

import com.infocepts.otc.utilities.LoadConstant;
import com.infocepts.otc.utilities.QueryConstant;
@Entity
@Table(catalog = LoadConstant.infomaster, schema = "[dbo]", name = "resource")
@SqlResultSetMappings({
        @SqlResultSetMapping(
                name = "resources_list",
                classes = {
                        @ConstructorResult(
                                targetClass = Resource.class,
                                columns = {
                                        @ColumnResult(name = "uid"),
                                        @ColumnResult(name = "hrmsId"),
                                        @ColumnResult(name = "empId"),
                                        @ColumnResult(name = "title", type = String.class),
                                        @ColumnResult(name = "email", type = String.class),
                                        @ColumnResult(name = "firstName"),
                                        @ColumnResult(name = "middleName"),
                                        @ColumnResult(name = "lastName"),
                                        @ColumnResult(name = "birthdate", type = Date.class),
                                        @ColumnResult(name = "gender", type = String.class),
                                        @ColumnResult(name = "unitId"),
                                        @ColumnResult(name = "drivingLicense", type = String.class),
                                        @ColumnResult(name = "drivingLicenseExpiry", type = Date.class),
                                        @ColumnResult(name = "empTypeId"),
                                        @ColumnResult(name = "disabled", type = Boolean.class),
                                        @ColumnResult(name = "hrRoleId"),
                                        @ColumnResult(name = "gradeId"),
                                        @ColumnResult(name = "bandId"),
                                        @ColumnResult(name = "amgRoleId"),
                                        @ColumnResult(name = "departmentId"),
                                        @ColumnResult(name = "departmentName", type = String.class),
                                        @ColumnResult(name = "workstationId", type = String.class),
                                        @ColumnResult(name = "permStreet1", type = String.class),
                                        @ColumnResult(name = "permStreet2", type = String.class),
                                        @ColumnResult(name = "cityId"),
                                        @ColumnResult(name = "permZipCode", type = String.class),
                                        @ColumnResult(name = "permTelephoneNo", type = String.class),
                                        @ColumnResult(name = "permMobNumber", type = String.class),
                                        @ColumnResult(name = "empOtherEmail", type = String.class),
                                        @ColumnResult(name = "joiningDate", type = Date.class),
                                        @ColumnResult(name = "lastDate", type = Date.class),
                                        @ColumnResult(name = "terminatedDate", type = Date.class),
                                        @ColumnResult(name = "terminatedReason", type = String.class),
                                        @ColumnResult(name = "terminationComment", type = String.class),
                                        @ColumnResult(name = "panNo", type = String.class),
                                        @ColumnResult(name = "aadharNo", type = String.class),
                                        @ColumnResult(name = "workExtension", type = String.class),
                                        @ColumnResult(name = "skypeId", type = String.class),
                                        @ColumnResult(name = "accessCardNo", type = String.class),
                                        @ColumnResult(name = "marriageDate", type = Date.class),
                                        @ColumnResult(name = "tempStreet1", type = String.class),
                                        @ColumnResult(name = "tempStreet2", type = String.class),
                                        @ColumnResult(name = "tempCityId"),
                                        @ColumnResult(name = "tempZipCode", type = String.class),
                                        @ColumnResult(name = "tempTelephoneNo", type = String.class),
                                        @ColumnResult(name = "tempMobNo", type = String.class),
                                        @ColumnResult(name = "bloodGroup", type = String.class),
                                        @ColumnResult(name = "timesheetDelegatesId"),
                                        @ColumnResult(name = "timesheetManagersId"),
                                        @ColumnResult(name = "pSkillId"),
                                        @ColumnResult(name = "sSkillId"),
                                        @ColumnResult(name = "baseLocationId"),
                                        @ColumnResult(name = "currentLocationId"),
                                        @ColumnResult(name = "reportingManagerId"),
                                        @ColumnResult(name = "holidayScheduleId"),
                                        @ColumnResult(name = "createdBy", type = Integer.class),
                                        @ColumnResult(name = "createdDate", type = Date.class),
                                        @ColumnResult(name = "modifiedBy", type = Integer.class),
                                        @ColumnResult(name = "modifiedDate", type = Date.class),
                                        @ColumnResult(name = "availableFrom", type = Date.class),
                                        @ColumnResult(name = "availableTo", type = Date.class),
                                        @ColumnResult(name = "bandName", type = String.class),
                                        @ColumnResult(name = "gradeName", type = String.class),
                                        @ColumnResult(name = "designation", type = String.class),
                                        @ColumnResult(name = "gradeNo", type = String.class),
                                        @ColumnResult(name = "pSkillName", type = String.class),
                                        @ColumnResult(name = "sSkillName", type = String.class),
                                        @ColumnResult(name = "location", type = String.class),
                                        @ColumnResult(name = "employmentType", type = String.class),
                                        @ColumnResult(name = "roles", type = String.class),
                                        @ColumnResult(name = "skills", type = String.class),
                                        @ColumnResult(name = "uidInfoHire"),
                                        @ColumnResult(name = "coe", type = String.class),
                                        @ColumnResult(name = "domain", type = String.class),
                                        @ColumnResult(name = "currLocEffectiveDate", type = Date.class)
                                        
                                }
                        )
                }
        ),
        @SqlResultSetMapping(
                name = "resource_dropdown_list",
                classes = {
                        @ConstructorResult(
                                targetClass = Resource.class,
                                columns = {
                                        @ColumnResult(name = "uid"),
                                        @ColumnResult(name = "title", type = String.class),
                                        @ColumnResult(name = "gradeId"),
                                        @ColumnResult(name = "gradeNo", type = String.class),
                                        @ColumnResult(name = "firstName", type = String.class),
                                        @ColumnResult(name = "lastName", type = String.class),
                                        @ColumnResult(name = "email", type = String.class),   
                                        @ColumnResult(name = "gradeName", type = String.class),
                                        @ColumnResult(name = "designation", type = String.class),                                                                                                              
                                        @ColumnResult(name = "bandName", type = String.class),
                                        @ColumnResult(name = "departmentName", type = String.class)
                                }
                        )
                }
        ),
        @SqlResultSetMapping(
                name = "resource_dropdown_list_by_role",
                classes = {
                        @ConstructorResult(
                                targetClass = Resource.class,
                                columns = {
                                        @ColumnResult(name = "uid"),
                                        @ColumnResult(name = "title", type = String.class)
                                        
                                }
                        )
                }
        ),
        @SqlResultSetMapping(
                name = "find_resource_joining_date_diffrance",
                classes = {
                        @ConstructorResult(
                                targetClass = Resource.class,
                                columns = {
                                        @ColumnResult(name = "uid"),
                                        @ColumnResult(name = "surveyId"),
                                        @ColumnResult(name = "dateDiff"),
                                        @ColumnResult(name = "email", type = String.class)
                                }
                        )
                }
        )
})
@NamedNativeQueries({
        @NamedNativeQuery(
                name    =   "getAllResources",
                query = "select *, b.band as bandName, g.grade as gradeName, g.designation, g.gradeNo, ps.skillName as pSkillName, ss.skillName as sSkillName, city.cityName as location, empType.empTypeName as  employmentType, d.departmentName, " +
                        "cast(stuff((select ',' + role from " + LoadConstant.otc + ".[dbo].[resource_roles] s " +
                        "left join " + LoadConstant.otc + ".[dbo].[roles] r1 on s.roleId = r1.roleId " +
                        "where s.uid = r.uid and s.status = 1 for XML PATH('')),1,1,'') as varchar ) as roles, " +
                        "stuff((select ',' + skillName from " + LoadConstant.otc + ".[dbo].[associateSkills] aas " +
                        "left join " + LoadConstant.infomaster + ".[dbo].[skill] s on s.skillId = aas.skillId " +
                        "where aas.uid = r.uid for XML PATH('')),1,1,'') as skills " +
                        " FROM " + LoadConstant.infomaster + ".[dbo].resource r" +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[grade] g on g.gradeId = r.gradeId" +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[band] b on b.bandId = r.bandId" +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[department] d on d.departmentId = r.departmentId" +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[skill] ps on ps.skillId = r.pSkillId" +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[skill] ss on ss.skillId = r.sSkillId" +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[city] city on city.cityId = r.currentLocationId" +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[empType] empType on empType.empTypeId = r.empTypeId" +
                        " where r.disabled = :disabled"+
                        " and r.email is not null",
                resultClass=Resource.class, resultSetMapping = "resources_list"
        ),
        @NamedNativeQuery(
                name    =   "getAllResourcesBySearch",
                query = "select *, b.band as bandName, g.grade as gradeName, g.designation, g.gradeNo, ps.skillName as pSkillName, ss.skillName as sSkillName, city.cityName as location, empType.empTypeName as  employmentType, d.departmentName, " +
                        "cast(stuff((select ',' + role from " + LoadConstant.otc + ".[dbo].[resource_roles] s " +
                        "left join " + LoadConstant.otc + ".[dbo].[roles] r1 on s.roleId = r1.roleId " +
                        "where s.uid = r.uid and s.status = 1 for XML PATH('')),1,1,'') as varchar ) as roles, " +
                        "stuff((select ',' + skillName from " + LoadConstant.otc + ".[dbo].[associateSkills] aas " +
                        "left join " + LoadConstant.infomaster + ".[dbo].[skill] s on s.skillId = aas.skillId " +
                        "where aas.uid = r.uid for XML PATH('')),1,1,'') as skills " +
                        " FROM " + LoadConstant.infomaster + ".[dbo].resource r" +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[grade] g on g.gradeId = r.gradeId" +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[band] b on b.bandId = r.bandId" +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[department] d on d.departmentId = r.departmentId" +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[skill] ps on ps.skillId = r.pSkillId" +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[skill] ss on ss.skillId = r.sSkillId" +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[city] city on city.cityId = r.currentLocationId" +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[empType] empType on empType.empTypeId = r.empTypeId" +
                        " where r.disabled = :disabled and r.title like concat('%',:searchStr,'%')"+
                        " and r.email is not null",
                resultClass=Resource.class, resultSetMapping = "resources_list"
        ),
        @NamedNativeQuery(
                name    =   "getAllResourcesDropDown",
                query = "select r.uid, r.title, r.gradeId,"+
                        "g.gradeNo, r.firstName, r.lastName, r.email, g.grade as gradeName, g.designation, b.band as bandName, d.departmentName" +
                        " FROM " + LoadConstant.infomaster + ".[dbo].resource r" +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[grade] g on g.gradeId = r.gradeId" +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[band] b on b.bandId = r.bandId" +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[department] d on d.departmentId = r.departmentId" +
                        " where r.disabled = :disabled"+
                        " AND g.gradeNo >= :aboveGrade"+
                        " AND r.unitId <> :unitId"+
                        " order by r.title",
                resultClass=Resource.class, resultSetMapping = "resource_dropdown_list"
        ),
        @NamedNativeQuery(
                name    =   "getAllResourcesDropDownByUnit",
                query = "select r.uid, r.email, r.title, r.gradeId,"+
                		"g.gradeNo, r.firstName, r.lastName, r.email, g.grade as gradeName, g.designation, b.band as bandName, d.departmentName" +
                        " FROM " + LoadConstant.infomaster + ".[dbo].resource r" +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[grade] g on g.gradeId = r.gradeId" +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[band] b on b.bandId = r.bandId" +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[department] d on d.departmentId = r.departmentId" +
                        " where r.disabled = :disabled"+
                        " AND g.gradeNo >= :aboveGrade"+
                        " AND r.unitId IN (:unitId , :billingUnitId) order by r.title",
                resultClass=Resource.class, resultSetMapping = "resource_dropdown_list"
        ),
        @NamedNativeQuery(
                name    =   "findResourceByUsername",
                query = "select *, b.band as bandName, g.grade as gradeName, g.designation, g.gradeNo, ps.skillName as pSkillName, ss.skillName as sSkillName, null as location, null as employmentType, '' as departmentName, null as roles, null as skills" +
                        " FROM " + LoadConstant.infomaster + ".[dbo].resource r " +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[grade] g on g.gradeId = r.gradeId" +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[band] b on b.bandId = r.bandId" +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[skill] ps on ps.skillId = r.pSkillId" +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[skill] ss on ss.skillId = r.sSkillId" +
                        " where r.email like CONCAT(:username, '@infocepts.com')",
                resultClass=Resource.class, resultSetMapping = "resources_list"
        ),
        @NamedNativeQuery(
                name    =   "findResourceByUid",
                query = "select *, b.band as bandName, g.grade as gradeName, g.designation, g.gradeNo, ps.skillName as pSkillName, ss.skillName as sSkillName, city.cityName as location, null as employmentType, d.departmentName as departmentName, null as roles, null as skills" +
                        " FROM " + LoadConstant.infomaster + ".[dbo].resource r " +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[grade] g on g.gradeId = r.gradeId" +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[band] b on b.bandId = r.bandId" +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[skill] ps on ps.skillId = r.pSkillId" +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[skill] ss on ss.skillId = r.sSkillId" +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[city] city on city.cityId = r.currentLocationId" +
                        //added new  to fetch department of selected resource in allocation list page                                         
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[department] d on d.departmentId = r.departmentId" +
                        " where r.uid = :uid",
                resultClass=Resource.class, resultSetMapping = "resources_list"
        ),
        @NamedNativeQuery(
                name    =   "findResourceByTitle",
                query = "select *, b.band as bandName, g.grade as gradeName, g.designation, g.gradeNo, ps.skillName as pSkillName, ss.skillName as sSkillName, NULL as location, null as employmentType, '' as departmentName, null as roles, null as skills" +
                        " FROM " + LoadConstant.infomaster + ".[dbo].resource r " +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[grade] g on g.gradeId = r.gradeId" +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[band] b on b.bandId = r.bandId" +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[skill] ps on ps.skillId = r.pSkillId" +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[skill] ss on ss.skillId = r.sSkillId" +
                        " where r.firstName like :name% and ((:pskill != '' and r.primarySkill = :pskill) || (:pskill == ''))",
                resultClass=Resource.class, resultSetMapping = "resources_list"
        ),
        @NamedNativeQuery(
                name = "findResourceInProject",
                query = "select *, b.band as bandName, g.grade as gradeName, g.designation, g.gradeNo, ps.skillName as pSkillName, ss.skillName as sSkillName , NULL as location, null as employmentType, '' as departmentName, null as roles, null as skills" +
                        " FROM " + LoadConstant.infomaster + ".[dbo].resource r " +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[grade] g on g.gradeId = r.gradeId" +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[band] b on b.bandId = r.bandId" +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[skill] ps on ps.skillId = r.pSkillId" +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[skill] ss on ss.skillId = r.sSkillId" +
                        " where r.uid in (" + "select alloc.uid from " + LoadConstant.otc + ".[dbo].allocation as alloc" + " where alloc.projectId = :projectId AND alloc.alcStatus = 'Active'" + ")",
                resultClass = Resource.class, resultSetMapping = "resources_list"
        ),
        @NamedNativeQuery(
                name = "findResourcesByBfirmBucket",
                query = "select DISTINCT r.*, ba.band as bandName, g.grade as gradeName, g.designation, g.gradeNo, ps.skillName as pSkillName, ss.skillName as sSkillName, city.cityName as location, empType.empTypeName as employmentType, '' as departmentName, null as roles, null as skills" +
                		QueryConstant.Query_Resources_By_Bfirm_Bucket,
                resultClass = Resource.class, resultSetMapping = "resources_list"
        ),
        @NamedNativeQuery(
                name = "findResourcesByBriskBucket",
                query = "select DISTINCT r.*, ba.band as bandName, g.grade as gradeName, g.designation, g.gradeNo, ps.skillName as pSkillName, ss.skillName as sSkillName, city.cityName as location, empType.empTypeName as employmentType, '' as departmentName, null as roles, null as skills" +
                		QueryConstant.Query_Resources_By_Brisk_Bucket,
                resultClass = Resource.class, resultSetMapping = "resources_list"
        ),
        @NamedNativeQuery(
                name = "findResourcesByNBbufferBucket",
                query = "select DISTINCT r.*, ba.band as bandName, g.grade as gradeName, g.designation, g.gradeNo, ps.skillName as pSkillName, ss.skillName as sSkillName, city.cityName as location, empType.empTypeName as employmentType, '' as departmentName, null as roles, null as skills" +
                		QueryConstant.Query_Resources_By_NBbuffer_Bucket,
                resultClass = Resource.class, resultSetMapping = "resources_list"
        ),
        @NamedNativeQuery(
                name = "findResourcesByNBpoolBucket",
                query = "select DISTINCT r.*, ba.band as bandName, g.grade as gradeName, g.designation, g.gradeNo, ps.skillName as pSkillName, ss.skillName as sSkillName, city.cityName as location, empType.empTypeName as employmentType, '' as departmentName, null as roles, null as skills" +
                		QueryConstant.Query_Resources_By_NBpool_Bucket,
                resultClass = Resource.class, resultSetMapping = "resources_list"
        ),
        @NamedNativeQuery(
                name = "findResourcesByBucketName",
                query = "select DISTINCT r.*, ba.band as bandName, g.grade as gradeName, g.designation, g.gradeNo, ps.skillName as pSkillName, ss.skillName as sSkillName, city.cityName as location, empType.empTypeName as employmentType '' as departmentName, null as roles, null as skills" +
                		QueryConstant.Query_Resources_By_Bucket_Name,
                resultClass = Resource.class, resultSetMapping = "resources_list"
        ),
        @NamedNativeQuery(
                name = "findResourcesByRoleId",
                query = "SELECT Distinct rr.uid as uid, r.title as title"+
                		" from " + LoadConstant.infomaster + ".[dbo].[resource] r"+
                		" left join  " + LoadConstant.otc + ".[dbo].[resource_roles] rr on r.uid = rr.uid"+
                		" where rr.roleId = :roleId and rr.status = 1 and rr.uid is not null and r.disabled = 0",
                resultClass = Resource.class, resultSetMapping = "resource_dropdown_list_by_role"
        ),
        @NamedNativeQuery(
                name = "findResourcesJoiningDateDiffrance",
                query = "SELECT s.surveyId, r.uid,r.title,r.email, DATEDIFF(dd,r.joiningDate,getdate()) AS dateDiff"+
                		" from " + LoadConstant.infomaster + ".[dbo].[resource] r"+
                		" left join " + LoadConstant.otc + ".[dbo].[surveyResponse] s on r.email=s.email"+
                		" and ('30' = :dateDiff and s.surveyId not in(2,3) or '60' = :dateDiff and s.surveyId not in(1,3) or '90' = :dateDiff and s.surveyId not in(1,2)) "+
                		" where r.disabled=0 and r.joiningDate > '2019-01-01' and"+
	            		" (('30' = :dateDiff and DATEDIFF(dd,joiningDate,getdate()) <60 and DATEDIFF(dd,joiningDate,getdate()) >=30)"+
	            		" or"+
	            		" ('60' = :dateDiff and DATEDIFF(dd,joiningDate,getdate()) <90 and DATEDIFF(dd,joiningDate,getdate()) >=60)"+
	            		" or"+
	            		" ('90' = :dateDiff and DATEDIFF(dd,joiningDate,getdate()) <120 and DATEDIFF(dd,joiningDate,getdate()) >=90))"+
                		" and s.surveyId is null  and r.unitId IN (1,4) and r.empTypeId IN (4) order by r.joiningDate desc",
                resultClass = Resource.class, resultSetMapping = "find_resource_joining_date_diffrance"
        )
})
public class Resource {

    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Integer uid;

    private String email;
    private String title;
    private Integer hrmsId;
    private Integer empId;
    private String firstName;
    private String middleName;
    private String lastName;
    private Date birthdate;
    private String gender;

    @ManyToOne()
    @JoinColumn(name = "unitId")
    private Unit unit;

    private String drivingLicense;
    private Date drivingLicenseExpiry;

    @ManyToOne()
    @JoinColumn(name = "empTypeId")
    private EmployeeType empType;

    private Boolean disabled;
    private Integer hrRoleId;

    @ManyToOne()
    @JoinColumn(name = "gradeId")
    private Grade grade;

    @ManyToOne()
    @JoinColumn(name = "bandId")
    private Band band;

    @ManyToOne()
    @JoinColumn(name = "amgRoleId")
    private AmgRoles amgRoles;

    @ManyToOne()
    @JoinColumn(name = "departmentId")
    private Department department;

    private String workstationId;
    @Column(columnDefinition = "varchar(MAX)")
    private String permStreet1;
    @Column(columnDefinition = "varchar(MAX)")
    private String permStreet2;

    @ManyToOne()
    @JoinColumn(name = "cityId")
    private City permCity;

    private String permZipCode;
    private String permTelephoneNo;
    private String permMobNumber;

    private Date joiningDate;
    private String empOtherEmail;
    private Date terminatedDate;
    @Column(columnDefinition = "varchar(MAX)")
    private String terminatedReason;
    private Date lastDate;
    @Column(columnDefinition = "varchar(MAX)")
    private String terminationComment;
    private String panNo;
    private String aadharNo;
    private String workExtension;
    private String skypeId;
    private String accessCardNo;
    private Date marriageDate;
    @Column(columnDefinition = "varchar(MAX)")
    private String tempStreet1;
    @Column(columnDefinition = "varchar(MAX)")
    private String tempStreet2;
    private Integer tempCityId;
    private String tempZipCode;
    private String tempTelephoneNo;
    private String tempMobNo;
    private String bloodGroup;
    private Integer timesheetDelegatesId;
    private Integer timesheetManagersId;

    @ManyToOne()
    @JoinColumn(name = "pSkillId", referencedColumnName = "skillId")
    private Skill pSkill;

    @ManyToOne()
    @JoinColumn(name = "sSkillId", referencedColumnName = "skillId")
    private Skill sSkill;

    @ManyToOne()
    @JoinColumn(name = "baseLocationId", referencedColumnName = "cityId")
    private City baseLocation;

    @ManyToOne()
    @JoinColumn(name = "currentLocationId", referencedColumnName = "cityId")
    private City currentLocation;

    private Integer reportingManagerId;
    private Integer holidayScheduleId;

    private Date createdDate;
    private Integer createdBy;
    private Date modifiedDate;
    private Integer modifiedBy;

    private Date availableFrom;
    private Date availableTo;
    
    private Integer uidInfoHire;
    private String domain;
    private String coe;
    
    private Date currLocEffectiveDate;


    // Transient Variables
    // --------------------------------------------------------------------------------
    @Transient
    private String roles; // OTC roles added in the resource list
    @Transient
    private String skills;
    @Transient
    private String location;
    @Transient
    private String reportingManagerText;

    @Transient
    private String employmentType;

    @Transient
    private String designation;
    
    @Transient
    private String gradeName;
    
    @Transient
    private String bandName;
    
    @Transient
    private String departmentName;
    
    @Transient
    private Integer dateDiff;

    @Transient
    private Integer surveyId;
    

    public Resource(Integer uid, Integer hrmsId, Integer empId, String title, String email, String firstName, String middleName, String lastName,
                    Date birthdate, String gender, Integer unitId, String drivingLicense, Date drivingLicenseExpiry, Integer empTypeId,
                    Boolean disabled, Integer hrRoleId, Integer gradeId, Integer bandId, Integer amgRoleId, Integer departmentId, String departmentName, String workstationId,
                    String permStreet1, String permStreet2, Integer cityId, String permZipCode, String permTelephoneNo, String permMobNumber,
                    String empOtherEmail, Date joiningDate, Date lastDate, Date terminatedDate, String terminatedReason, String terminationComment,
                    String panNo, String aadharNo, String workExtension, String skypeId, String accessCardNo, Date marriageDate, String tempStreet1, String tempStreet2,
                    Integer tempCityId, String tempZipCode, String tempTelephoneNo, String tempMobNo, String bloodGroup, Integer timesheetDelegatesId,
                    Integer timesheetManagersId, Integer pSkillId, Integer sSkillId, Integer baseLocationId, Integer currentLocationId,
                    Integer reportingManagerId, Integer holidayScheduleId,
                    Integer createdBy, Date createdDate, Integer modifiedBy, Date modifiedDate, Date availableFrom, Date availableTo,
                    String bandName, String gradeName, String designation, String gradeNo, String pSkillName, String sSkillName, String location, String employmentType, 
                    String roles, String skills, Integer uidInfoHire, String coe, String domain, Date currLocEffectiveDate) {

        this.uid = uid;        
        this.empId = empId;

        this.title = title;
        this.email = email;
        this.firstName = firstName;
        this.middleName = middleName;
        this.lastName = lastName;
        this.birthdate = birthdate;
        this.gender = gender;

        if(null != unitId)
        {
        	this.unit = new Unit();
        	this.unit.setUnitId(unitId);
        }

        if(empTypeId != null)
        {
        	this.empType = new EmployeeType();
        	this.empType.setEmpTypeId(empTypeId);
        }

        this.disabled = disabled;
        this.hrRoleId = hrRoleId;

        if(gradeId != null)
        {
        	this.grade = new Grade();
        	this.grade.setGradeId(gradeId);
        	this.grade.setGrade(gradeName);
        	this.grade.setDesignation(designation);
        	this.grade.setGradeNo(gradeNo);
        }

        if(bandId != null)
        {
        	this.band = new Band();
        	this.band.setBandId(bandId);
        	this.band.setBand(bandName);
        }

        if(amgRoleId != null)
        {
        	this.amgRoles = new AmgRoles();
        	this.amgRoles.setAmgRoleId(amgRoleId);
        }

        if(departmentId != null)
        {
        	this.department = new Department();
        	this.department.setDepartmentId(departmentId);
        	this.department.setDepartmentName(departmentName);
        }

        this.workstationId = workstationId;
        this.permStreet1 = permStreet1;
        this.permStreet2 = permStreet2;

        if(cityId != null)
        {
        	this.permCity = new City();
        	this.permCity.setCityId(cityId);
        }

        this.permZipCode = permZipCode;
        this.permTelephoneNo = permTelephoneNo;
        this.permMobNumber = permMobNumber;

        this.empOtherEmail = empOtherEmail;
        this.joiningDate = joiningDate;
        
        this.workExtension = workExtension;
        this.skypeId = skypeId;
        
        this.marriageDate = marriageDate;
        this.tempStreet1 = tempStreet1;
        this.tempStreet2 = tempStreet2;

        this.timesheetManagersId = timesheetManagersId;

        if(pSkillId != null)
        {
        	this.pSkill = new Skill();
        	this.pSkill.setSkillId(pSkillId);
        	this.pSkill.setSkillName(pSkillName);
        }

        if(sSkillId != null)
        {
        	this.sSkill = new Skill();
        	this.sSkill.setSkillId(sSkillId);
        	this.sSkill.setSkillName(sSkillName);
        }

        if(baseLocationId != null)
        {
        	this.baseLocation = new City();
        	this.baseLocation.setCityId(baseLocationId);
        }

        if(currentLocationId != null)
        {
        	this.currentLocation = new City();
        	this.currentLocation.setCityId(currentLocationId);
        }

        this.reportingManagerId = reportingManagerId;
        this.holidayScheduleId = holidayScheduleId;

        this.createdBy = createdBy;
        this.createdDate = createdDate;
        this.modifiedBy = modifiedBy;
        this.modifiedDate = modifiedDate;
        this.location = location;
        this.designation = designation;
        this.employmentType = employmentType;
        this.roles = roles;
        this.skills = skills;
        this.availableTo = availableTo;
        this.availableFrom = availableFrom;
        this.uidInfoHire = uidInfoHire;
        this.coe = coe;
        this.domain = domain;
        this.currLocEffectiveDate = currLocEffectiveDate;
        
        // Sensitive data should not be returned in this call
        //this.hrmsId = hrmsId;
        //this.drivingLicense = drivingLicense;
        //this.drivingLicenseExpiry = drivingLicenseExpiry;
        //this.lastDate = lastDate;
        //this.terminatedDate = terminatedDate;
        //this.terminatedReason = terminatedReason;
        //this.terminationComment = terminationComment;
        //this.panNo = panNo;
        //this.aadharNo = aadharNo;
        //this.accessCardNo = accessCardNo;
        //this.bloodGroup = bloodGroup;
    }

    public Resource(Integer uid, String title, Integer gradeId, String gradeNo, String firstName, String lastName, String email, String gradeName, String designation, String bandName, String departmentName)
    {
        this.uid = uid;
        this.title = title;             
        
        if(gradeId != null)
        {
        	this.grade = new Grade();
        	this.grade.setGradeId(gradeId);       	
        	this.grade.setGradeNo(gradeNo);        	
        }

        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        
        this.gradeName = gradeName;
        this.designation = designation;
        this.bandName = bandName;
        this.departmentName = departmentName;      

    }
    
    public Resource(Integer uid, String title)
    {
        this.uid = uid;
        this.title = title;
    }

    public Resource(Integer uid, Integer surveyId, Integer dateDiff, String email)
    {
        this.uid = uid;
        this.surveyId = surveyId;
        this.dateDiff = dateDiff;
        this.email = email;
    }
    
    
    public Date getAvailableFrom() {
        return availableFrom;
    }

    public void setAvailableFrom(Date availableFrom) {
        this.availableFrom = availableFrom;
    }

    public Date getAvailableTo() {
        return availableTo;
    }

    public void setAvailableTo(Date availableTo) {
        this.availableTo = availableTo;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public String getEmploymentType() {
        return employmentType;
    }

    public Integer getUid() {
        return uid;
    }

    public void setUid(Integer uid) {
        this.uid = uid;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Integer getHrmsId() {
        return hrmsId;
    }

    public void setHrmsId(Integer hrmsId) {
        this.hrmsId = hrmsId;
    }

    public Integer getEmpId() {
        return empId;
    }

    public void setEmpId(Integer empId) {
        this.empId = empId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public Date getBirthdate() {
        return birthdate;
    }

    public void setBirthdate(Date birthdate) {
        this.birthdate = birthdate;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }


    public String getDrivingLicense() {
        return drivingLicense;
    }

    public void setDrivingLicense(String drivingLicense) {
        this.drivingLicense = drivingLicense;
    }

    public Date getDrivingLicenseExpiry() {
        return drivingLicenseExpiry;
    }

    public void setDrivingLicenseExpiry(Date drivingLicenseExpiry) {
        this.drivingLicenseExpiry = drivingLicenseExpiry;
    }

    public EmployeeType getEmpType() {
        return empType;
    }

    public void setEmpType(EmployeeType empType) {
        this.empType = empType;
    }

    public void setHolidayScheduleId(Integer holidayScheduleId) {
        this.holidayScheduleId = holidayScheduleId;
    }

    public Boolean getDisabled() {
        return disabled;
    }

    public void setDisabled(Boolean disabled) {
        this.disabled = disabled;
    }

    public Integer getHrRoleId() {
        return hrRoleId;
    }

    public void setHrRoleId(Integer hrRoleId) {
        this.hrRoleId = hrRoleId;
    }

    public Grade getGrade() {
        return grade;
    }

    public void setGrade(Grade grade) {
        this.grade = grade;
    }

    public Band getBand() {
        return band;
    }

    public void setBand(Band band) {
        this.band = band;
    }

    public City getPermCity() {
        return permCity;
    }

    public void setPermCity(City permCity) {
        this.permCity = permCity;
    }

    public Unit getUnit() {
        return unit;
    }

    public void setUnit(Unit unit) {
        this.unit = unit;
    }

    public AmgRoles getAmgRoles() {
        return amgRoles;
    }

    public void setAmgRoles(AmgRoles amgRoles) {
        this.amgRoles = amgRoles;
    }

    public Department getDepartment() {
        return department;
    }

    public void setDepartment(Department department) {
        this.department = department;
    }

    public Skill getpSkill() {
        return pSkill;
    }

    public void setpSkill(Skill pSkill) {
        this.pSkill = pSkill;
    }

    public Skill getsSkill() {
        return sSkill;
    }

    public void setsSkill(Skill sSkill) {
        this.sSkill = sSkill;
    }

    public String getWorkstationId() {
        return workstationId;
    }

    public void setWorkstationId(String workstationId) {
        this.workstationId = workstationId;
    }

    public String getPermStreet1() {
        return permStreet1;
    }

    public void setPermStreet1(String permStreet1) {
        this.permStreet1 = permStreet1;
    }

    public String getPermStreet2() {
        return permStreet2;
    }

    public void setPermStreet2(String permStreet2) {
        this.permStreet2 = permStreet2;
    }

    public String getPermZipCode() {
        return permZipCode;
    }

    public void setPermZipCode(String permZipCode) {
        this.permZipCode = permZipCode;
    }

    public String getPermTelephoneNo() {
        return permTelephoneNo;
    }

    public void setPermTelephoneNo(String permTelephoneNo) {
        this.permTelephoneNo = permTelephoneNo;
    }

    public String getPermMobNumber() {
        return permMobNumber;
    }

    public void setPermMobNumber(String permMobNumber) {
        this.permMobNumber = permMobNumber;
    }

    public void setTempTelephoneNo(String tempTelephoneNo) {
        this.tempTelephoneNo = tempTelephoneNo;
    }

    public void setTempMobNo(String tempMobNo) {
        this.tempMobNo = tempMobNo;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Date getJoiningDate() {
        return joiningDate;
    }

    public void setJoiningDate(Date joiningDate) {
        this.joiningDate = joiningDate;
    }

    public String getEmpOtherEmail() {
        return empOtherEmail;
    }

    public void setEmpOtherEmail(String empOtherEmail) {
        this.empOtherEmail = empOtherEmail;
    }

    public Date getTerminatedDate() {
        return terminatedDate;
    }

    public void setTerminatedDate(Date terminatedDate) {
        this.terminatedDate = terminatedDate;
    }

    public String getTerminatedReason() {
        return terminatedReason;
    }

    public void setTerminatedReason(String terminatedReason) {
        this.terminatedReason = terminatedReason;
    }

    public Date getLastDate() {
        return lastDate;
    }

    public void setLastDate(Date lastDate) {
        this.lastDate = lastDate;
    }

    public String getTerminationComment() {
        return terminationComment;
    }

    public void setTerminationComment(String terminationComment) {
        this.terminationComment = terminationComment;
    }

    public String getPanNo() {
        return panNo;
    }

    public void setPanNo(String panNo) {
        this.panNo = panNo;
    }

    public String getAadharNo() {
        return aadharNo;
    }

    public void setAadharNo(String aadharNo) {
        this.aadharNo = aadharNo;
    }

    public String getWorkExtension() {
        return workExtension;
    }

    public void setWorkExtension(String workExtension) {
        this.workExtension = workExtension;
    }

    public String getSkypeId() {
        return skypeId;
    }

    public void setSkypeId(String skypeId) {
        this.skypeId = skypeId;
    }

    public String getAccessCardNo() {
        return accessCardNo;
    }

    public void setAccessCardNo(String accessCardNo) {
        this.accessCardNo = accessCardNo;
    }

    public Date getMarriageDate() {
        return marriageDate;
    }

    public void setMarriageDate(Date marriageDate) {
        this.marriageDate = marriageDate;
    }

    public String getTempStreet1() {
        return tempStreet1;
    }

    public void setTempStreet1(String tempStreet1) {
        this.tempStreet1 = tempStreet1;
    }

    public String getTempStreet2() {
        return tempStreet2;
    }

    public void setTempStreet2(String tempStreet2) {
        this.tempStreet2 = tempStreet2;
    }

    public Integer getTempCityId() {
        return tempCityId;
    }

    public void setTempCityId(Integer tempCityId) {
        this.tempCityId = tempCityId;
    }

    public String getTempZipCode() {
        return tempZipCode;
    }

    public void setTempZipCode(String tempZipCode) {
        this.tempZipCode = tempZipCode;
    }

    public String getBloodGroup() {
        return bloodGroup;
    }

    public void setBloodGroup(String bloodGroup) {
        this.bloodGroup = bloodGroup;
    }

    public String getTempTelephoneNo() {
        return tempTelephoneNo;
    }

    public String getTempMobNo() {
        return tempMobNo;
    }

    public Integer getTimesheetDelegatesId() {
        return timesheetDelegatesId;
    }

    public void setTimesheetDelegatesId(Integer timesheetDelegatesId) {
        this.timesheetDelegatesId = timesheetDelegatesId;
    }

    public Integer getTimesheetManagersId() {
        return timesheetManagersId;
    }

    public void setTimesheetManagersId(Integer timesheetManagersId) {
        this.timesheetManagersId = timesheetManagersId;
    }

    public void setEmploymentType(String employmentType) {
        this.employmentType = employmentType;
    }

    public City getBaseLocation() {
        return baseLocation;
    }

    public void setBaseLocation(City baseLocation) {
        this.baseLocation = baseLocation;
    }

    public City getCurrentLocation() {
        return currentLocation;
    }

    public Integer getReportingManagerId() {
        return reportingManagerId;
    }

    public void setReportingManagerId(Integer reportingManagerId) {
        this.reportingManagerId = reportingManagerId;
    }


    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public Integer getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(Integer createdBy) {
        this.createdBy = createdBy;
    }

    public Date getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(Date modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    public Integer getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(Integer modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    public String getRoles() {
        return roles;
    }

    public void setRoles(String roles) {
        this.roles = roles;
    }

    public String getSkills() {
		return skills;
	}

	public void setSkills(String skills) {
		this.skills = skills;
	}

	public Integer getHolidayScheduleId() {
        return holidayScheduleId;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getReportingManagerText() {
        return reportingManagerText;
    }

    public void setReportingManagerText(String reportingManagerText) {
        this.reportingManagerText = reportingManagerText;
    }
    
    public void setCurrentLocation(City currentLocation) {
        this.currentLocation = currentLocation;
    }

	public Integer getUidInfoHire() {
		return uidInfoHire;
	}

	public void setUidInfoHire(Integer uidInfoHire) {
		this.uidInfoHire = uidInfoHire;
	}
	
	public String getDomain() {
		return domain;
	}

	public void setDomain(String domain) {
		this.domain = domain;
	}

	public String getCoe() {
		return coe;
	}

	public void setCoe(String coe) {
		this.coe = coe;
	}

	
	public Date getCurrLocEffectiveDate() {
		return currLocEffectiveDate;
	}

	public void setCurrLocEffectiveDate(Date currLocEffectiveDate) {
		this.currLocEffectiveDate = currLocEffectiveDate;
	}			

	public String getGradeName() {
		return gradeName;
	}

	public void setGradeName(String gradeName) {
		this.gradeName = gradeName;
	}

	public String getBandName() {
		return bandName;
	}

	public void setBandName(String bandName) {
		this.bandName = bandName;
	}

	public String getDepartmentName() {
		return departmentName;
	}

	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}

	public Integer getDateDiff() {
		return dateDiff;
	}

	public void setDateDiff(Integer dateDiff) {
		this.dateDiff = dateDiff;
	}

	public Integer getSurveyId() {
		return surveyId;
	}

	public void setSurveyId(Integer surveyId) {
		this.surveyId = surveyId;
	}	
	

	public Resource() {

    }

    
    

}
