package com.infocepts.otc.repositories;

import java.util.List;
import org.springframework.data.repository.CrudRepository;
import com.infocepts.otc.entities.Region;

public interface RegionRepository extends CrudRepository<Region,Integer>{

	@Override
	public List<Region> findAll();
}
