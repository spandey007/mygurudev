package com.infocepts.otc.entities;

import java.util.Date;

import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.SqlResultSetMappings;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.infocepts.otc.utilities.LoadConstant;


@Entity
@Table(catalog=LoadConstant.otc, schema="[dbo]",name="associateCertifications")
@SqlResultSetMappings({
	@SqlResultSetMapping(
		      name = "get_CertificationsDetails",
		      classes = {
		          @ConstructorResult(
		              targetClass = AssociateCertifications.class,
		              columns = {
		                  @ColumnResult(name = "associateCertificationsId"),
		                  @ColumnResult(name = "certificateName",type=String.class),
		                  @ColumnResult(name = "certificateDate",type=Date.class),
		                  @ColumnResult(name = "certifiedBy", type=String.class),
		                  @ColumnResult(name = "issueDate", type=Date.class),
		                  @ColumnResult(name = "createdBy", type = Integer.class),
		                  @ColumnResult(name = "createdDate", type=Date.class),
		                  @ColumnResult(name = "modifiedBy",type = Integer.class),
		                  @ColumnResult(name = "modifiedDate", type=Date.class),
		                  @ColumnResult(name = "uid", type =Integer.class),
		                  @ColumnResult(name = "validTill",type=Date.class),	                  
		                  @ColumnResult(name = "certificateType",type=String.class),
		                  @ColumnResult(name = "resourceName",type=String.class),
		                  @ColumnResult(name = "employeeId",type =Integer.class),
		                  @ColumnResult(name = "departmentName",type=String.class)
		                }
		          )
		      }
	)
})
@NamedNativeQueries({
	    @NamedNativeQuery(
	            name    =   "getCertificationsList_Associates",
	            query   =   "select s.*,r.empId as employeeId,r.title as resourceName,d.departmentName"+
	            			" FROM " + LoadConstant.otc + ".[dbo].[associateCertifications] s"+
	            			" left join " + LoadConstant.infomaster + ".[dbo].[resource] r on r.uid=s.uid"+	   
	            		 	" left join " + LoadConstant.infomaster + ".[dbo].[department] d on r.departmentId=d.departmentId",	            		
	                        resultClass=AssociateCertifications.class, resultSetMapping = "get_CertificationsDetails"   

	    )
})



public class AssociateCertifications {

	public AssociateCertifications() {
		super();
		// TODO Auto-generated constructor stub
	}


	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer associateCertificationsId;
	private String certificateName;
	private Date certificateDate;
	private String certifiedBy;
	private Date issueDate;
	private Integer createdBy;
	private Date createdDate;
	private Integer modifiedBy;
	private Date modifiedDate;
	private Integer uid;
	private Date validTill;
	private String certificateType;
	
	@Transient
	private String resourceName;
	
	@Transient
	private Integer employeeId;
	
	@Transient
	private String departmentName;
	
	
	public Integer getAssociateCertificationsId() {
		return associateCertificationsId;
	}
	public void setAssociateCertificationsId(Integer associateCertificationsId) {
		this.associateCertificationsId = associateCertificationsId;
	}
	public String getCertificateName() {
		return certificateName;
	}
	public void setCertificateName(String certificateName) {
		this.certificateName = certificateName;
	}
	public Date getCertificateDate() {
		return certificateDate;
	}
	public void setCertificateDate(Date certificateDate) {
		this.certificateDate = certificateDate;
	}
	public String getCertifiedBy() {
		return certifiedBy;
	}
	public void setCertifiedBy(String certifiedBy) {
		this.certifiedBy = certifiedBy;
	}
	public Date getIssueDate() {
		return issueDate;
	}
	public void setIssueDate(Date issueDate) {
		this.issueDate = issueDate;
	}
	public Integer getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public Integer getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public Date getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public Integer getUid() {
		return uid;
	}
	public void setUid(Integer uid) {
		this.uid = uid;
	}
	public Date getValidTill() {
		return validTill;
	}
	public void setValidTill(Date validTill) {
		this.validTill = validTill;
	}
	public String getCertificateType() {
		return certificateType;
	}
	public void setCertificateType(String certificateType) {
		this.certificateType = certificateType;
	}
	public String getResourceName() {
		return resourceName;
	}
	public void setResourceName(String resourceName) {
		this.resourceName = resourceName;
	}
	public Integer getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}
	public String getDepartmentName() {
		return departmentName;
	}
	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}
	
	
	public AssociateCertifications(Integer associateCertificationsId, String certificateName, Date certificateDate,
			String certifiedBy, Date issueDate, Integer createdBy, Date createdDate, Integer modifiedBy,
			Date modifiedDate, Integer uid, Date validTill, String certificateType, String resourceName,
			Integer employeeId,String departmentName) {
		super();
		this.associateCertificationsId = associateCertificationsId;
		this.certificateName = certificateName;
		this.certificateDate = certificateDate;
		this.certifiedBy = certifiedBy;
		this.issueDate = issueDate;
		this.createdBy = createdBy;
		this.createdDate = createdDate;
		this.modifiedBy = modifiedBy;
		this.modifiedDate = modifiedDate;
		this.uid = uid;
		this.validTill = validTill;
		this.certificateType = certificateType;
		this.resourceName = resourceName;
		this.employeeId = employeeId;
		this.departmentName = departmentName;
	}
	
}
