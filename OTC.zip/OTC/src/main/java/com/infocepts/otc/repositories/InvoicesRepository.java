package com.infocepts.otc.repositories;

	import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.infocepts.otc.entities.Invoices;


	public interface InvoicesRepository  extends CrudRepository<Invoices,Integer>{

		@Override
		public List<Invoices> findAll();
		
		@Query("select inv FROM Invoices inv where inv.endClientInvoiceNo = :endClientNo")
		public Invoices findInternalInvoiceByEndClientInvoiceNo(@Param("endClientNo") String endClientNo);
	}


