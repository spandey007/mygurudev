package com.infocepts.otc.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.infocepts.otc.entities.Shuttle;

public interface ShuttleRepository extends CrudRepository<Shuttle,Integer>{

	@Override
	public List<Shuttle> findAll();

}
