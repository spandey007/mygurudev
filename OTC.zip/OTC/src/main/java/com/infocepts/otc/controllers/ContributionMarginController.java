package com.infocepts.otc.controllers;

import java.util.List;

import javax.mail.MessagingException;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.infocepts.otc.entities.ContributionMargin;
import com.infocepts.otc.repositories.ContributionMarginRepository;
import com.infocepts.otc.services.TimesheetService;

@RestController
@RequestMapping("/contributionmargin")
public class ContributionMarginController {
	
	final Logger logger = Logger.getLogger(ContributionMarginController.class);

	@Autowired
	ContributionMarginRepository repository;
	
	@Autowired
	TimesheetService service;
	
	@RequestMapping(method=RequestMethod.POST)
	public ContributionMargin addContributionMargin(@RequestBody ContributionMargin contributionmargin)
	{
		try{
			contributionmargin.setContributionMarginId(null);
			repository.save(contributionmargin);	
		}catch(Exception e){
			logger.error(e);
		}
		return contributionmargin;
	}	
 
	 @RequestMapping(method=RequestMethod.GET)
	 public List<ContributionMargin> getAllContributionMargins(@RequestParam(value = "projectId", defaultValue = "0") Integer projectId,
																HttpServletRequest request) throws MessagingException {
		 List<ContributionMargin> contributionmarginlist=null;
		 // Authorization for passed projectId			
		 if(projectId != 0)
		 {
			Boolean isAValidCall = service.isAValidSOWCall(projectId, 0, "All CM By Project", request);
			if(isAValidCall == false)
			{	
				return contributionmarginlist;
			}
		 }
			 
		 try{
			 if(projectId != 0)
			 {
				 // RKJ add code to get contribution margin by project Id
				 //contributionmarginlist = repository.findAll(); 
			 }
			 else
			 {
				 contributionmarginlist = repository.findAll();
			 }
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return contributionmarginlist;
	 }

	@RequestMapping(value="/{contributionMarginId}",method=RequestMethod.GET)
	 public ContributionMargin getContributionMargin(@PathVariable Integer contributionMarginId){
		 ContributionMargin contributionmargin=null;
	 	 try{
			 contributionmargin = repository.findOne(contributionMarginId);
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return contributionmargin;
	 }
	 
	 
	 
	 
	 @RequestMapping(value="/{contributionMarginId}",method=RequestMethod.PUT)
	 public ContributionMargin updateContributionMargin(@RequestBody ContributionMargin updatedContributionMargin,@PathVariable Integer contributionMarginId){
		 try{
			 updatedContributionMargin.setContributionMarginId(contributionMarginId);
			 repository.save(updatedContributionMargin);
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return updatedContributionMargin;
	 }
	 
	 @RequestMapping(value="/{contributionMarginId}",method=RequestMethod.DELETE)
	 public void deleteContributionMargin(@PathVariable Integer contributionMarginId){
		 try{
			 repository.delete(contributionMarginId);
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
	 }	 
	
}
