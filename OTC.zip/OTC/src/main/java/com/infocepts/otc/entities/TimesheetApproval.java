package com.infocepts.otc.entities;

import java.lang.reflect.Array;
import java.util.Date;
import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.SqlResultSetMappings;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.apache.commons.lang.StringUtils;

import com.infocepts.otc.utilities.LoadConstant;




@Entity
@Table(catalog=LoadConstant.otc,schema="[dbo]",name="tsapproval")
@SqlResultSetMappings({
	@SqlResultSetMapping(
      name = "tsapproval_by_pmdm_month",
      classes = {
          @ConstructorResult(
              targetClass = TimesheetApproval.class,
              columns = {	                  
            		   @ColumnResult(name = "tsapprovalId"), 
            		   @ColumnResult(name = "projectId"),
            		   @ColumnResult(name = "year"),
                       @ColumnResult(name = "month"),
                       @ColumnResult(name = "pmApprovalDate", type=Date.class),
                       @ColumnResult(name = "pmApprovalNotes", type=String.class),
                       @ColumnResult(name = "pmApprovalStatus"),
                       @ColumnResult(name = "pmApprovedBy"),  
                       @ColumnResult(name = "dmApprovalDate", type=Date.class),
                       @ColumnResult(name = "dmApprovalNotes", type=String.class),
                       @ColumnResult(name = "dmApprovalStatus"),
                       @ColumnResult(name = "dmApprovedBy"),  
                       @ColumnResult(name = "createdDate", type=Date.class),
            		   @ColumnResult(name = "createdBy"),
            		   @ColumnResult(name = "modifiedDate", type=Date.class),
            		   @ColumnResult(name = "modifiedBy"),
                       @ColumnResult(name = "projectName"),
                       @ColumnResult(name = "pmApprovedByName"),
                       @ColumnResult(name = "pid"), // Required in the case when listing the projects for approval when no approval object is present
                       @ColumnResult(name = "billableHrs", type=Float.class),
 	                   @ColumnResult(name = "nonBillableHrs", type=Float.class),
            		   @ColumnResult(name = "billableAllocHrs", type=Float.class),
            		   @ColumnResult(name = "nonBillableAllocHrs", type=Float.class),
            		   @ColumnResult(name = "isDraftInvoice"),
            		   @ColumnResult(name = "billingType"),
            		   @ColumnResult(name = "timesheetunlock")
              }
          )
      }
  )	
})
  // this method is used to retrieve timesheet hours by project on PM approval, DM approval and timesheet report by project pages 
  @NamedNativeQueries({    
	    @NamedNativeQuery(
	            name    =   "getProjectsByMonth",
   			    query   =   "select tsa.*, cast(r.title as varchar(max)) as pmApprovedByName, cast(p.title as varchar(max)) as projectName, p.itemId as pid," +
	   			    		"(select COALESCE(sum(tsh.billableHrs), 0)" +
		   			    		" from " + LoadConstant.otc + ".[dbo].[tsitemhours] tsh" +
		   			    		" left join " + LoadConstant.otc + ".[dbo].[tsitem] tsi on tsi.tsitemId = tsh.tsitemId" +
			    				" left join " + LoadConstant.otc + ".[dbo].[taskCenter] task on task.taskId = tsi.taskId" +
		   			    		" left join " + LoadConstant.otc + ".[dbo].[tssubmit] tssubmit on tssubmit.projectId = task.projectId AND tssubmit.timesheetId = tsi.timesheetId" +
		   			    		" where MONTH(tsh.itemDate) = :month AND YEAR(tsh.itemDate) = :year" +
		   			    		//" and (tssubmit.submitted = 1 or tsh.itemDate < '2016-12-01')" +	// rkj - take this date as the launch date from config, so that all the timesheets before this can be considered submitted			   
		   			    		" and task.projectId = p.itemId" +
		   			    		" group by task.projectId) as billableHrs," +
	   			    		"(select COALESCE(sum(tsh.nonBillableHrs),0)" +
		   			    		" from " + LoadConstant.otc + ".[dbo].[tsitemhours] tsh" +
		   			    		" left join " + LoadConstant.otc + ".[dbo].[tsitem] tsi on tsi.tsitemId = tsh.tsitemId" +
			    				" left join " + LoadConstant.otc + ".[dbo].[taskCenter] task on task.taskId = tsi.taskId" +
		   			    		" left join " + LoadConstant.otc + ".[dbo].[tssubmit] tssubmit on tssubmit.projectId = task.projectId AND tssubmit.timesheetId = tsi.timesheetId" +
		   			    		" where MONTH(tsh.itemDate) = :month AND YEAR(tsh.itemDate) = :year" +
		   			    		//" and (tssubmit.submitted = 1 or tsh.itemDate < '2016-12-01')" +	// rkj - take this date as the launch date from config, so that all the timesheets before this can be considered submitted			   
		   			    		" and task.projectId = p.itemId" +
		   			    		" group by task.projectId) as nonBillableHrs," +
   			    			" (SELECT COALESCE(sum(a.alcHrs), 0) from " + LoadConstant.otc + ".[dbo].[monthly_allocation] a" +
							   	" where a.projectId = p.itemId and a.prdName = :monthStr" +
							   	" and (a.alcType = 1 or a.alcType = 4)) as billableAllocHrs," +
							" (SELECT COALESCE(sum(a.alcHrs), 0) from " + LoadConstant.otc + ".[dbo].[monthly_allocation] a" +
								" where a.projectId = p.itemId and a.prdName = :monthStr" +
								" and (a.alcType != 1 and a.alcType != 4)) as nonBillableAllocHrs," +
							" (SELECT TOP 1 invoiceId from " + LoadConstant.otc + ".[dbo].invoices where  projectId =p.itemId"+
							" and MONTH(periodEndDate) = :month and YEAR(periodEndDate) = :year "+
							" and invoiceType = 'Services Invoice' and invoiceStatus != 'Cancelled') as isDraftInvoice,"+
							" (SELECT name from " + LoadConstant.infomaster + ".[dbo].[billingType] where billingTypeId = (select"+
							" billingTypeId from " + LoadConstant.infomaster + ".[dbo].[project] where itemid = p.itemId )) as billingType, "+
							" (SELECT TOP 1 timesheetUnlock from " + LoadConstant.otc + ".[dbo].invoiceInfo where  projectId =p.itemId) as timesheetunlock"+
							" FROM " + LoadConstant.infomaster + ".[dbo].project p" +
	    				" left Join " + LoadConstant.otc + ".[dbo].tsapproval tsa on tsa.projectId = p.itemId AND tsa.year = :year AND tsa.month = :month" +
	    				" left Join " +  LoadConstant.infomaster + ".[dbo].resource r on r.uid = tsa.pmApprovedBy" +
	    				" WHERE ( ((:pmUid != 0) and (p.itemId IN (SELECT itemId FROM " + LoadConstant.infomaster + ".[dbo].[project] where ProjectManagersID = :pmUid)) and (p.state not in ('Closed','Cancel')) )" + // Lists active projects under a PM
	    					 " or((:ahUid != 0) and (p.itemId IN (SELECT pr.itemId FROM " + LoadConstant.infomaster + ".[dbo].[project] pr "+
	    					 " left Join " +  LoadConstant.infomaster + ".[dbo].accounts a on a.itemId=p.accountId where a.ahId = :ahUid)))" + // Lists active projects under a AH
	    					 " or ((:dmUid != 0) and (p.itemId IN (SELECT pp1.itemId FROM " + LoadConstant.infomaster + ".[dbo].[project] pp1 left join " + LoadConstant.infomaster + ".[dbo].[portfolio] pp2 on pp1.PortfolioID = pp2.itemId where pp2.ownerId = :dmUid)))" + // Lists active projects under a DM
	    					 " or (:ppUid != 0) and (p.itemId IN (SELECT itemId FROM " + LoadConstant.infomaster + ".[dbo].[project] WHERE (',' + RTRIM(plannersId) + ',') LIKE '%,' + :ppUid + ',%' )))"+
	    					 " or ((:pmUid = 0) and (:ahUid = 0) and (:dmUid = 0) and (:ppUid = 0))" + //Lists all active projects
	    				//" and p.state = 'Active'"+
	    				" and (cast(p.projectStart as DATE) <= :monthEndDate or p.projectStart is null) "+
						" and (cast(p.projectEnd as DATE) >= :monthstartDate or p.projectEnd is null) " +
	    				" order by p.title;",                         
   			                                      
	                    resultClass=TimesheetApproval.class,  resultSetMapping = "tsapproval_by_pmdm_month"  
	                        
	    ),
	    @NamedNativeQuery(
	            name    =   "getProjectsReportByUidAndMonth",
   			    query   =   "select 0 as tsapprovalId,cast(r.title as varchar(max)) as pmApprovedByName, 0 as projectId, 0 as month, 0 as year, getdate() as pmApprovalDate, '' as pmApprovalNotes, 0 as pmApprovalStatus, 0 as pmApprovedBy," +
   			    			"getdate() as dmApprovalDate, '' as dmApprovalNotes, 0 as dmApprovalStatus, 0 as dmApprovedBy," +
   			    			"getdate() as createdDate, NULL as createdBy, getdate() as modifiedDate, NULL as modifiedBy," +
   			    			"cast(p.title as varchar(max)) as projectName, p.itemId as pid," +
	   			    		"COALESCE(sum(tshrs.billableHrs), 0) as billableHrs," +
   			    			"COALESCE(sum(tshrs.nonBillableHrs),0) as nonBillableHrs," +
							" (SELECT COALESCE(sum(a.alcHrs), 0) from " + LoadConstant.otc + ".[dbo].[monthly_allocation] a" +
								" where a.projectId = p.itemId and a.prdName = :monthStr" +
								" and (a.alcType = 1 or a.alcType = 4)) as billableAllocHrs," +
							" (SELECT COALESCE(sum(a.alcHrs), 0) from " + LoadConstant.otc + ".[dbo].[monthly_allocation] a" +
								" where a.projectId = p.itemId and a.prdName = :monthStr" +
								" and (a.alcType != 1 and a.alcType != 4)) as nonBillableAllocHrs," +
								" 0 as isDraftInvoice, '' as billingType, 0 as timesheetunlock " + 
		    			    " FROM " + LoadConstant.otc + ".[dbo].tsitemhours tshrs" +
   			    			" left join " + LoadConstant.otc + ".[dbo].tsitem tsitem on tsitem.tsitemId=tshrs.tsitemId" +
   			    			" left join " + LoadConstant.otc + ".[dbo].tstimesheet ts on ts.timesheetId=tsitem.timesheetId" +
   			    			" left join " + LoadConstant.otc + ".[dbo].taskCenter task on task.taskId=tsitem.taskId" +
   			    			" left join " + LoadConstant.infomaster + ".[dbo].project p on p.itemId=task.ProjectID" +
   			    			" left Join " + LoadConstant.otc + ".[dbo].tsapproval tsa on tsa.projectId = p.itemId AND tsa.year = :year AND tsa.month = :month" +
   			    			" left join " + LoadConstant.infomaster + ".[dbo].[resource] r on r.uid = ts.uid" +
		    			" WHERE  MONTH(tshrs.itemDate) = :month AND YEAR(tshrs.itemDate) = :year and ts.uid = :uid" +
		    			" group by r.title, r.uid, p.title , p.itemId" +
        				" order by p.itemId DESC;",	                         
   			                                      
	                    resultClass=TimesheetApproval.class,  resultSetMapping = "tsapproval_by_pmdm_month"  
	    )
	})
public class TimesheetApproval {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer tsapprovalId;
	
	private Integer projectId; // Project reference
	private Integer year;	
	private Integer month;	
	private Date pmApprovalDate;
	private String pmApprovalNotes;
	private Integer pmApprovalStatus;
	private Integer pmApprovedBy;
	private Date dmApprovalDate;
	private String dmApprovalNotes;
	private Integer dmApprovalStatus;
	private Integer dmApprovedBy;
	
	private Integer createdBy;	
	private Date createdDate;	
	private Integer modifiedBy;
	private Date modifiedDate;
	
	private Integer rejectionCount;
	
	@Transient
	private String projectName;	// Transient field for project reference 
	
	@Transient
	private String pmApprovedByName;	// Transient field for project reference
		
	@Transient
	private Float tsBillableHours; // Transient field for total submitted timesheet billable hours 
	@Transient
	private Float tsNonBillableHours; // Transient field for total submitted timesheet non-billable hours 
	
	@Transient
	private Float billableAllocHrs; // Transient field for estimated billable allocation hours 
	@Transient
	private Float nonBillableAllocHrs; // Transient field for estimated non-billable allocation hours 
	
	@Transient
	private Integer isDraftInvoice;
 	
	@Transient
	private String billingType;
	
	@Transient
	private Boolean timesheetunlock;
	
	public Integer getTsapprovalId() {
		return tsapprovalId;
	}
	public void setTsapprovalId(Integer tsapprovalId) {
		this.tsapprovalId = tsapprovalId;
	}
	public Integer getProjectId() {
		return projectId;
	}
	public void setProjectId(Integer projectId) {
		this.projectId = projectId;
	}	

	public Date getPmApprovalDate() {
		return pmApprovalDate;
	}
	public void setPmApprovalDate(Date pmApprovalDate) {
		this.pmApprovalDate = pmApprovalDate;
	}
	public String getPmApprovalNotes() {
		return pmApprovalNotes;
	}
	public void setPmApprovalNotes(String pmApprovalNotes) {
		this.pmApprovalNotes = pmApprovalNotes;
	}
	public Integer getPmApprovalStatus() {
		return pmApprovalStatus;
	}
	public void setPmApprovalStatus(Integer pmApprovalStatus) {
		this.pmApprovalStatus = pmApprovalStatus;
	}
	public Integer getPmApprovedBy() {
		return pmApprovedBy;
	}
	public void setPmApprovedBy(Integer pmApprovedBy) {
		this.pmApprovedBy = pmApprovedBy;
	}
	public Date getDmApprovalDate() {
		return dmApprovalDate;
	}
	public void setDmApprovalDate(Date dmApprovalDate) {
		this.dmApprovalDate = dmApprovalDate;
	}
	public String getDmApprovalNotes() {
		return dmApprovalNotes;
	}
	public void setDmApprovalNotes(String dmApprovalNotes) {
		this.dmApprovalNotes = dmApprovalNotes;
	}
	public Integer getDmApprovalStatus() {
		return dmApprovalStatus;
	}
	public void setDmApprovalStatus(Integer dmApprovalStatus) {
		this.dmApprovalStatus = dmApprovalStatus;
	}
	public Integer getDmApprovedBy() {
		return dmApprovedBy;
	}
	public void setDmApprovedBy(Integer dmApprovedBy) {
		this.dmApprovedBy = dmApprovedBy;
	}			
	public Integer getYear() {
		return year;
	}
	public void setYear(Integer year) {
		this.year = year;
	}
	public Integer getMonth() {
		return month;
	}
	public void setMonth(Integer month) {
		this.month = month;
	}
	/******************getter setter for Transient vars*******************************************/
	@Transient
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	@Transient
	public String getPmApprovedByName() {
		return pmApprovedByName;
	}
	public void setPmApprovedByName(String pmApprovedByName) {
		this.pmApprovedByName = pmApprovedByName;
	}
	@Transient
	public Float getTsBillableHours() {
		return tsBillableHours;
	}
	public void setTsBillableHours(Float tsBillableHours) {
		this.tsBillableHours = tsBillableHours;
	}
	@Transient
	public Float getTsNonBillableHours() {
		return tsNonBillableHours;
	}
	public void setTsNonBillableHours(Float tsNonBillableHours) {
		this.tsNonBillableHours = tsNonBillableHours;
	}
	public Float getBillableAllocHrs() {
		return billableAllocHrs;
	}
	public void setBillableAllocHrs(Float billableAllocHrs) {
		this.billableAllocHrs = billableAllocHrs;
	}
	public Float getNonBillableAllocHrs() {
		return nonBillableAllocHrs;
	}
	public void setNonBillableAllocHrs(Float nonBillableAllocHrs) {
		this.nonBillableAllocHrs = nonBillableAllocHrs;
	}
	
	public Integer getIsDraftInvoice() {
		return isDraftInvoice;
	}
	public void setIsDraftInvoice(Integer isDraftInvoice) {
		this.isDraftInvoice = isDraftInvoice;
	}
	
	public String getBillingType() {
		return billingType;
	}
	public void setBillingType(String billingType) {
		this.billingType = billingType;
	}
	
	public Boolean getTimesheetunlock() {
		return timesheetunlock;
	}
	public void setTimesheetunlock(Boolean timesheetunlock) {
		this.timesheetunlock = timesheetunlock;
	}
	public Integer getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public Integer getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public Date getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}		
	public Integer getRejectionCount() {
		return rejectionCount;
	}
	public void setRejectionCount(Integer rejectionCount) {
		this.rejectionCount = rejectionCount;
	}
	public TimesheetApproval() {
	};
			
	public TimesheetApproval(Integer tsapprovalId, Integer projectId,Integer year, Integer month, 
				Date pmApprovalDate, String pmApprovalNotes, Integer pmApprovalStatus, Integer pmApprovedBy,
				Date dmApprovalDate, String dmApprovalNotes, Integer dmApprovalStatus, Integer dmApprovedBy,
				Date createdDate, Integer createdBy, Date modifiedDate, Integer modifiedBy,
				String projectName,String pmApprovedByName, Integer pid, Float billableHrs, Float nonBillableHrs, Float billableAllocHrs, Float nonBillableAllocHrs,
				Integer isDraftInvoice, String billingType, Boolean timesheetunlock
				) 
	{
		
		this.tsapprovalId = tsapprovalId;
		if(projectId != null)
		{
			this.projectId = projectId;
		}
		else if(pid != null) // Required in the case when listing the projects for approval when no approval object is present
		{
			this.projectId = pid;
		}
		this.year = year;
		this.month = month;
		this.pmApprovalDate = pmApprovalDate;
		this.pmApprovalNotes = pmApprovalNotes;
		this.pmApprovalStatus = pmApprovalStatus;
		this.pmApprovedBy = pmApprovedBy;
		
		this.dmApprovalDate = dmApprovalDate;
		this.dmApprovalNotes = dmApprovalNotes;
		this.dmApprovalStatus = dmApprovalStatus;
		this.dmApprovedBy = dmApprovedBy;		
		
		if(projectName == null) projectName = "Leaves & Holidays";
		this.projectName = projectName;
		this.pmApprovedByName=pmApprovedByName;
		this.billableAllocHrs = billableAllocHrs;
		this.nonBillableAllocHrs = nonBillableAllocHrs;
		
		this.tsBillableHours = billableHrs;
		this.tsNonBillableHours = nonBillableHrs;
		
		 this.createdDate = createdDate;
	     this.createdBy = createdBy;	     
	     this.modifiedDate = modifiedDate;
	     this.modifiedBy = modifiedBy;
	    this.isDraftInvoice=isDraftInvoice;
	    this.billingType = billingType;
	    this.timesheetunlock = timesheetunlock;
	        
	        
    };

}
