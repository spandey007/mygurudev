package com.infocepts.otc.controllers;

public class UnauthorizedException extends Exception {
    public UnauthorizedException(String s) {
        super(s);
    }
}
