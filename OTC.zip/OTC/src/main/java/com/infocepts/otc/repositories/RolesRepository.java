package com.infocepts.otc.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.infocepts.otc.entities.Roles;



public interface RolesRepository extends JpaRepository<Roles, Integer>{

	@Override
	public List<Roles> findAll();
	
	@Query("select r FROM Roles r where r.isEnabled = true order by r.role")
	public List<Roles> findActiveRoles();
	
	@Query("select r FROM Roles r where r.role like concat('%',:role,'%')")
	public List<Roles> 	findRoleId(@Param("role") String role);
	
	
	@Query("select r.role FROM Roles r where r.roleId = :roleId")
	public List<Roles> findRoleById(@Param("roleId") Integer roleId);
	
	@Query("select r FROM Roles r where r.role = :role")
	public List<Roles> findActiveRoleId(@Param("role") String role);
	
}
