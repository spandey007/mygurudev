/**
* Filename: /src/main/java/com/infocepts/otc/repositories/DeMsrRepository.java
* @author  SHRI
* @version 1.0
* @since   2019-11-28 
*/
package com.infocepts.otc.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import com.infocepts.otc.entities.DeMsr;
import com.infocepts.otc.entities.DeWsr;

public interface DeMsrRepository extends CrudRepository<DeMsr,Integer>{

	@Override
	public List<DeMsr> findAll();	
		
	@Query("from DeMsr where projectId = :projectId order by deMsrId asc")
	List<DeMsr> findByProjectId(@Param("projectId")Integer projectId);
	
	
}