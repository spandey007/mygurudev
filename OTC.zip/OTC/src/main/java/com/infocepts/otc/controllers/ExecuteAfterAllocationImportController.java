package com.infocepts.otc.controllers;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.infocepts.otc.entities.Allocation;
import com.infocepts.otc.entities.MonthlyAllocation;
import com.infocepts.otc.repositories.AllocationRepository;
import com.infocepts.otc.services.MonthlyAllocationService;



@RestController
public class ExecuteAfterAllocationImportController {
	
	final Logger logger = Logger.getLogger(ExecuteAfterAllocationImportController.class);

	@Autowired
	AllocationRepository repository;
	
	@Autowired
	MonthlyAllocationService monthlyAllocationService;
	
	@PersistenceContext(unitName="otc")
    private EntityManager manager;
	
	@RequestMapping(value="/allocation_import_post_Process")
	public void createMonthlyAllocationForImportedAllocation(){
		
		List<Allocation> allocationlist=null;
		allocationlist = repository.findAllImportedAllocation("Imported From Excel");
		
		for (Allocation allocation : allocationlist) {
			//Populate Monthly Allocation 
			monthlyAllocationService.InsertUpdateMonthlyAllocation(allocation);
		}	
	}

	
	 
	 
	 
	 
	 
}

