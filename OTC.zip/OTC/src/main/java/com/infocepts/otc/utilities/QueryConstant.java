package com.infocepts.otc.utilities;

public class QueryConstant {
	
	/**
	 * Initializing those queries which are to be used again with additional conditions.
	 * 
	 */
	public static final String
	Query_Invoices_get_projects = "	SELECT i.*," +
								" p.itemId as itemId," +
    							" cast(p.title as varchar(MAX)) as projectName," +
								" p.accountId as accountId," +
								" (Select cast(title as varchar(MAX)) from " +LoadConstant.infomaster+ ".[dbo].accounts where itemId = p.accountId) as accountName," +
								"(select sign from " +LoadConstant.infomaster+".[dbo].[currency] where currencyId = i.exchangecurrencyId) as currSign," +
								" u.name as billingUnit," +
						        " u.unitName as billingEntity," +
								" cast(b.name as varchar) as billingType," +
								" (Select top 1 (a.pmApprovalStatus) from  " +LoadConstant.otc+".[dbo].tsapproval a "
										+ "where a.projectId= p.itemId and a.month = :month and a.year = :year order by a.pmApprovalDate desc) as pmApprovalStatus," +
								" (select count(n.invoicetype) from " +LoadConstant.otc+".[dbo].invoices n "
										+ "where ((cast(n.[periodStartDate] as DATE) between :monthstartDate and :monthEndDate) or (cast(n.[periodEndDate] as DATE) between :monthEndDate and :monthEndDate))" +
								" and n.invoicetype  = 'Expense Invoice' and n.projectId= p.itemId ) as otherInvoicesCount," +
								" (select count(n.invoicetype) from " +LoadConstant.otc+".[dbo].invoices n "
										+ "where ((cast(n.[periodStartDate] as DATE) between :monthstartDate and :monthEndDate) or (cast(n.[periodEndDate] as DATE) between :monthEndDate and :monthEndDate))" +
								" and n.invoicetype in ('Credit Note','Debit Note') and n.projectId= p.itemId and n.invoices = i.finalinvoiceno) as CrDrCount, " +
								" (Select finalInvoiceNo from  " +LoadConstant.otc+".[dbo].invoices  " + 
								" where endClientInvoiceNo = i.finalInvoiceNo and " +
								" invoicetype = 'Internal Invoice' and finalinvoiceNo is not null) as internalInvoiceNo, " +
								" (Select title from " +LoadConstant.infomaster+ ".[dbo].project where " +
								" itemid = i.endClientProjectId ) as endClientProjName, " +
								" '' as country," +
								" '' as currency, " +
								" 0 as onShoreDevTotal, " +
								" 0 as offShoreDevTotal, "  + 
								" (select name from  " +LoadConstant.otc+ ".[dbo].projectType where projectTypeId = p.projectTypeId ) as projectType,"  +
								" u.unitId, "+
								" (select count(n.invoicetype) from " +LoadConstant.otc+".[dbo].invoices n "
								+ "where ((cast(n.[periodStartDate] as DATE) between :monthstartDate and :monthEndDate) or (cast(n.[periodEndDate] as DATE) between :monthEndDate and :monthEndDate))" +
								" and n.invoicetype  = 'Inter-Unit Invoice' and n.projectId= p.itemId ) as interUnitCount " +
								" FROM " +LoadConstant.infomaster+ ".[dbo].project p" +
								" LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[unit] u on u.unitId = p.billingUnitId "+
								" LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[accounts] a on a.itemId = p.accountId "+
								" LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[entities] e on e.entityId = u.entityId "+
								" LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[billingtype] b on b.billingTypeId = p.billingTypeId " +
								" LEFT JOIN " + LoadConstant.otc + ".[dbo].[projectType] pt on pt.projectTypeId = p.projectTypeId " +
								" left join " +LoadConstant.otc+".[dbo].invoices i on p.itemid = i.projectId " +
								" and ((cast(i.periodStartDate as DATE) between :monthstartDate and :monthEndDate) " +
								" or (cast(i.periodEndDate as DATE) between :monthstartDate and :monthEndDate))";
								
	
	// Query for non-services invoices types for all months
	public static final String
	Query_Other_Invoices_get_projects = "	SELECT i.*," +
								" p.itemId as itemId," +
    							" cast(p.title as varchar(MAX)) as projectName," +
								" p.accountId as accountId," +
								" (select sign from " +LoadConstant.infomaster+".[dbo].[currency] where currencyId = i.exchangecurrencyId) as currSign,"+
								" (Select title from " +LoadConstant.infomaster+ ".[dbo].accounts where itemId = p.accountId) as accountName," +
								" u.name as billingUnit," +
								" u.unitName as billingEntity," +
								" cast(b.name as varchar) as billingType," +
								" 0 as pmApprovalStatus," +
								" 0 as otherInvoicesCount," +
								" 0 as CrDrCount, " +
								" (Select finalInvoiceNo from  " +LoadConstant.otc+".[dbo].invoices  " + 
								" where endClientInvoiceNo = i.finalInvoiceNo and " +
								" invoicetype = 'Internal Invoice' and finalinvoiceNo is not null and endclientinvoiceNo != '') as internalInvoiceNo, " +
								" (Select title from " +LoadConstant.infomaster+ ".[dbo].project where " +
								" itemid = i.endClientProjectId ) as endClientProjName ," + 
								" '' as country," + 
								" '' as currency," + 
								" 0 as onShoreDevTotal," + 
								" 0 as offShoreDevTotal, " +
								" '' as projectType, " +
								" u.unitId, " +
								" 0 as interUnitCount " +
								" FROM " +LoadConstant.infomaster+".[dbo].project p" +
								" LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[unit] u on u.unitId = p.billingUnitId "+
								" LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[entities] e on e.entityId = u.entityId "+
								" LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[billingtype] b on b.billingTypeId = p.billingTypeId " +
								" LEFT JOIN " + LoadConstant.otc + ".[dbo].[projectType] pt on pt.projectTypeId = p.projectTypeId " +
								" left join " +LoadConstant.otc+".[dbo].invoices i on p.itemid = i.projectId" +
								//" where p.state = 'Active'" + 
								" where  b.name <> 'None'"; // Where billing type is 'None'
	
	public static final String
	Query_Invoices_get_Detail_Edit = " select distinct(select cast(title as varchar) from " +LoadConstant.infomaster+".[dbo].[resource]  where uid = id.uid) as resourceName, "+
							  		" (select countryName from " +LoadConstant.infomaster+".[dbo].[country] where countryId = id.countryId) as countryName,"+
							  		" (select Top 1 alcHrs from " +LoadConstant.otc+".[dbo].[monthly_allocation] where prdMonth=MONTH(i.periodStartDate) and prdYear = YEAR(i.periodStartDate) and alcType = 1 and uid = id.uid and projectId = i.projectId) as expectedHrs, "+
							  		" (select code from " +LoadConstant.infomaster+".[dbo].[currency] where currencyId = i.currencyId) as currencyCode,"+
							  		"(select name from " +LoadConstant.infomaster+".[dbo].uom  where uomId = i.uomId) as uom, " +
							  		" i.currencyId, "+
							  		" id.* "+
									" FROM " +LoadConstant.otc+".[dbo].[invoicedetail] id "+
									" left join " +LoadConstant.otc+".[dbo].[invoices] i on i.invoiceid = id.invoiceid"+
									" WHERE id.invoiceid = :invoiceId";
	
	public static final String
	Query_Invoices_get_Detail_Add = "select " +
									" CASE WHEN m.uid is not null" +
										" THEN (select TOP 1 cast(title as varchar) from " +LoadConstant.infomaster+".[dbo].[resource] where uid = m.uid)"+
										" ELSE (select TOP 1 cast(title as varchar) from " +LoadConstant.infomaster+".[dbo].[resource] where uid = sd.sharepointAccountId)"+
									" END as resourceName, "+
								   	" CASE WHEN m.uid is not null" +
										" THEN  (select TOP 1 uid from " +LoadConstant.infomaster+".[dbo].[resource] where uid = m.uid)" +
										" ELSE (select TOP 1 sharepointAccountId from " +LoadConstant.infomaster+".[dbo].[resource] where uid = sd.sharepointAccountId)" +
								   " END as uid, " +
								   " (Select amgRoleName from " +LoadConstant.infomaster+".[dbo].[amgRoles] where amgRoleId = sd.roleId) as infoCeptsRole,s.sowNo, s.sowId,sd.countryId, (select countryName from " +LoadConstant.infomaster+".[dbo].[country] where countryId = sd.countryId) as countryName,"+
								   " sd.billableRate, m.alcHrs as expectedHrs, s.currencyId, (select code from " +LoadConstant.infomaster+".[dbo].[currency] where currencyId = s.currencyId) as currencyCode,  "+
								   "sd.sowDetailId,"+
								   " CASE WHEN m.uid is not null" +
										" THEN (SELECT COALESCE(sum(tsh.billableHrs), 0)" +
											" from " + LoadConstant.otc + ".[dbo].[tsitemhours] tsh" +
											" left join " + LoadConstant.otc + ".[dbo].[tsitem] tsi on tsi.tsitemId = tsh.tsItemId" +
											" left join " +LoadConstant.otc+".[dbo].[taskCenter] task on task.taskId = tsi.taskId" +
											" left join " + LoadConstant.otc + ".[dbo].[tstimesheet] t on t.timesheetId = tsi.timesheetId" +
											" where task.projectId = :projectId and (t.uid = m.uid)" +
											//" and MONTH(tsh.itemDate) = MONTH(:monthstartDate) AND YEAR(tsh.itemDate) = YEAR(:monthstartDate))" +
											" and tsh.itemDate >= :monthstartDate AND tsh.itemDate <= :monthEndDate)" +
										" ELSE" +
										" (SELECT COALESCE(sum(tsh.billableHrs), 0)" +
											" from " + LoadConstant.otc + ".[dbo].[tsitemhours] tsh" +
											" left join " + LoadConstant.otc + ".[dbo].[tsitem] tsi on tsi.tsitemId = tsh.tsItemId" +
											" left join " +LoadConstant.otc+".[dbo].[taskCenter] task on task.taskId = tsi.taskId" +
											" left join " + LoadConstant.otc + ".[dbo].[tstimesheet] t on t.timesheetId = tsi.timesheetId" +
											" where task.projectId = :projectId and (t.uid = sd.sharepointAccountId)" +
											//" and MONTH(tsh.itemDate) = MONTH(:monthstartDate) AND YEAR(tsh.itemDate) = YEAR(:monthstartDate))" +
											" and tsh.itemDate >= :monthstartDate AND tsh.itemDate <= :monthEndDate)" +
										" END" +
								   " as tsHrs,  (select name from " +LoadConstant.infomaster+".[dbo].uom where uomId = s.uomId) as uom, s.uomId, sd.clientRole, sd.expectedBillability as fte " +
					    		   " FROM " +LoadConstant.otc+".[dbo].sowdetail sd" +  
				    			   " LEFT JOIN " +LoadConstant.otc+".[dbo].[monthly_allocation] m on sd.sowdetailId = m.sowdetailId and m.prdMonth = MONTH(:monthstartDate) and m.prdYear = YEAR(:monthstartDate)" +								    
								   " left join " + LoadConstant.otc + ".[dbo].sow s on sd.sowId = s.sowId"+
								   " left join " +LoadConstant.infomaster+".[dbo].project p on p.itemId = s.projectId" +
								   " where p.itemId = :projectId and (sd.isBillable = 1 or (m.alcType = 1 or m.alcType =4))  " +
								   " and ( (sd.sowRoleStartDate between :monthstartDate and :monthEndDate) or " +
								   "       (sd.sowRoleEndDate between :monthstartDate and :monthEndDate) or" +
			            		   "       (sd.sowRoleStartDate < :monthstartDate and sd.sowRoleEndDate > :monthEndDate) )"+
			            		   " order by resourceName";  
								   	
//	public static final String
//	Query_Invoices_get_Detail_Add = "select distinct(select cast(title as varchar) from " +LoadConstant.infomaster+".[dbo].[resource] " +
//								   		" where uid = m.uid) as resourceName , m.uid as uid, " +
//								   " (select countryName from " +LoadConstant.infomaster+".[dbo].[country] where countryId = sd.countryId) as countryName,"+
//								   " sd.billableRate, m.alcHrs as expectedHrs, sd.infoceptsRole as infoCeptsRole, m.sowDetailId, s.sowNo,"+
//								   " (select code from " +LoadConstant.infomaster+".[dbo].[currency] where currencyId = s.currencyId) as currencyCode,"+
//								   " (SELECT COALESCE(sum(tsh.billableHrs), 0) "+
//					    				"from " + LoadConstant.otc + ".[dbo].[tsitemhours] tsh" +
//					    			   	" left join " + LoadConstant.otc + ".[dbo].[tsitem] tsi on tsi.tsitemId = tsh.tsItemId" +
//					    				" left join " + LoadConstant.otc + ".[dbo].[taskCenter] task on task.itemId = tsi.taskId" +
//					    				" left join " + LoadConstant.otc + ".[dbo].[tstimesheet] t on t.timesheetId = tsi.timesheetId" +
//					    				" where task.projectId = :projectId and t.uid = m.uid" +
//					    				" and MONTH(tsh.itemDate) = MONTH(:monthstartDate) AND YEAR(tsh.itemDate) = YEAR(:monthstartDate)) as tsHrs" +
//								   " from " +LoadConstant.otc+".[dbo].[monthly_allocation] m" + 
//								   " left join " +LoadConstant.otc+".[dbo].sowdetail sd on sd.sowdetailId = m.sowdetailId" +   
//								   " left join " + LoadConstant.otc + ".[dbo].sow s on sd.sowId = s.sowId"+
//								   " where m.alctype = 1" +  
//								   " and m.prdMonth = MONTH(:monthstartDate) and m.prdYear = YEAR(:monthstartDate) and m.projectid = :projectId";
//								   //" and (cast(m.alcStartDate as DATE) <= :monthstartDate and cast(m.alcEndDate as DATE) >= :monthEndDate)" +
//								   //" and m.projectId = (select distinct(projectId) from " +LoadConstant.otc+".[dbo].sow  where sowId = sd.sowId)" ;
//	
	public static final String
	Query_Invoices_get_Detail_Milestone_Add =  " select  s.sowNo, s.sowId, s.currencyId, (select name from " +LoadConstant.infomaster+".[dbo].uom  "+
											" where uomId = s.uomId) as uom,"+
							  				" (select code from " +LoadConstant.infomaster+".[dbo].[currency] where currencyId = s.currencyId) as currencyCode, "+
							  				" (select name from " +LoadConstant.otc+".[dbo].milestone where milestoneId = sm.milestoneId) as resNameMilestone,"+
							  				" sm.sowMilestoneId, sm.description, sm.amount as initialBilledAmount, s.uomId "+
							  				" FROM " +LoadConstant.otc+".[dbo].sow s "+
							  				" left join " +LoadConstant.otc+".[dbo].sowMilestone sm  "+
							  				" on s.sowId = sm.sowId  "+
							  				" left join  " +LoadConstant.infomaster+".[dbo].[project] p" +
							  				" on p.itemId = s.projectId "+
							  				" where s.projectId = :projectId "+
							  				" order by sm.milestoneId ";
	
	public static final String
	Query_Invoices_Present_Already =  " select distinct(select cast(title as varchar) from " +LoadConstant.infomaster+".[dbo].[resource]  where uid = id.uid) as resourceName, "+
							  		" (select countryName from " +LoadConstant.infomaster+".[dbo].[country] where countryId = id.countryId) as countryName,"+
							  		" (select Top 1 alcHrs from " +LoadConstant.otc+".[dbo].[monthly_allocation] where prdMonth=MONTH(i.periodStartDate) and prdYear = YEAR(i.periodStartDate) and alcType = 1 and uid = id.uid and projectId = i.projectId) as expectedHrs, "+
							  		" (select code from " +LoadConstant.infomaster+".[dbo].[currency] where currencyId = id.currencyId) as currencyCode,"+
							  		"(select name from " +LoadConstant.infomaster+".[dbo].uom  where uomId = i.uomId) as uom, " +
									" i.currencyId, "+
							  		" id.* "+
									" FROM " +LoadConstant.otc+".[dbo].[invoicedetail] id "+
									" left join " +LoadConstant.otc+".[dbo].[invoices] i on i.invoiceid = id.invoiceid"+
									" WHERE i.projectId = :projectId"+
									" and (cast(i.periodStartDate as DATE) = :monthstartDate and cast(i.periodEndDate as DATE) = :monthEndDate)"  + 
									" and i.invoiceStatus in ('Draft','Pending Approval','Approved','Rejected','Completed')";
	public static final String
	Query_Weekly_Billiable_hours_for_an_Invoice =  " select distinct(select cast(title as varchar) from " +LoadConstant.infomaster+".[dbo].[resource] where uid = d.uid)as resourceName, d.uid,  "+
							  					" per.period_end as periodEnd ,"+
							  					" (SELECT COALESCE(sum(tsh.billableHrs), 0)  from " +LoadConstant.otc+".[dbo].[tsitemhours] tsh " +
							  					" left join " +LoadConstant.otc+".[dbo].[tsitem] tsi on tsi.tsitemId = tsh.tsItemId  "+
							  					" left join " +LoadConstant.otc+".[dbo].[TaskCenter] task on task.taskId = tsi.taskId "+
							  					" left join " +LoadConstant.otc+".[dbo].[tstimesheet] t on t.timesheetId = tsi.timesheetId " +
							  					"  where task.projectId is not null and task.projectId =:projectId and t.uid = d.uid and t.periodId =  per.PERIOD_ID and  "+
							  					" cast(tsh.itemDate as DATE) >= :monthstartDate AND cast(tsh.itemDate as DATE) <= :monthEndDate) as tsHrs,d.infoceptsRole "+
							  					" from " +LoadConstant.otc+".[dbo].[TSPERIOD] per "+
							  					" left join " +LoadConstant.otc+".[dbo].[tstimesheet] t on t.periodId =  per.PERIOD_ID "+
							  					" left join " +LoadConstant.otc+".[dbo].[invoiceDetail] d on t.uid = d.uid "+
							  					" left join " +LoadConstant.otc+".[dbo].[invoices] i on d.invoiceId = i.invoiceId "+
							  					" WHERE i.invoiceId = :invoiceId and i.projectId = :projectId "+
							  					" and cast(per.period_start as DATE) >= :monthstartDate AND cast(per.period_end as DATE) <= :monthEndDate ";
	
	public static final String
	Query_Bulk_Invoices				=	" select i.*, p.itemId as itemId, cast(p.title as varchar(MAX)) as projectName, p.accountId as accountId,'' as currSign, " +
							  			 " (Select title from " +LoadConstant.infomaster+".[dbo].accounts where itemId = p.accountId) as accountName, u.name as billingUnit, u.unitName as billingEntity, " +
										 " cast(b.name as varchar) as billingType, " +
										 " 0 as pmApprovalStatus," +
										 " 0 as otherInvoicesCount," +
										 " 0 as CrDrCount, " +
										 " '0' as internalInvoiceNo, " +
										 " '' as endClientProjName ," + 
										 " '' as country," + 
										 " '' as currency," + 
										 " 0 as onShoreDevTotal," + 
										 " 0 as offShoreDevTotal, " +
										 " '' as projectType, "+
										 " u.unitId, " +
										 " 0 as interUnitCount " +
										 " FROM " +LoadConstant.infomaster+".[dbo].project p " +
										 " LEFT JOIN " +LoadConstant.infomaster+".[dbo].[unit] u on u.unitId = p.billingUnitId  " +
										 " LEFT JOIN " +LoadConstant.infomaster+".[dbo].[entities] e on e.entityId = u.entityId  " +
										 " LEFT JOIN " +LoadConstant.infomaster+".[dbo].[billingtype] b on b.billingTypeId = p.billingTypeId  " +
										 " LEFT JOIN " +LoadConstant.otc+".[dbo].[projectType] pt on pt.projectTypeId = p.projectTypeId  " +
										 " left join " +LoadConstant.otc+".[dbo].invoices i on p.itemid = i.projectId  " +
										 " where (cast(i.arinvoiceDate as DATE) >= :monthstartDate)  and (cast(i.arinvoiceDate as DATE) <= :monthEndDate)  " +
										 //" or (cast(i.periodEndDate as DATE) between :monthstartDate and :monthEndDate)) " +
										 " and (i.finalInvoiceNo is not null or i.finalInvoiceNo != '')    " ;
	
	public static final String
	Query_Monthly_Timesheet_Report	=	" select (Select title from " +LoadConstant.infomaster+ ".[dbo].accounts where itemId = p.accountId) as accountName," +
										" (select title from " + LoadConstant.infomaster + ".[dbo].[project] where itemId = s.projectId) as projectName ," +
										" CASE WHEN m.uid is not null THEN (select TOP 1 cast(title as varchar) from " + LoadConstant.infomaster + ".[dbo].[resource] where uid = m.uid) "+
										" ELSE (select TOP 1 cast(title as varchar) from " + LoadConstant.infomaster + ".[dbo].[resource] where uid = sd.sharepointAccountId)"+
										" END as resourceName,   (select countryName from " + LoadConstant.infomaster + ".[dbo].[country] where countryId = sd.countryId) as countryName,"+
										" sd.billableRate,  (select code from " + LoadConstant.infomaster + ".[dbo].[currency] where currencyId = s.currencyId) as currency, "+
										" CASE WHEN m.uid is not null THEN (SELECT COALESCE(sum(tsh.billableHrs), 0) "+
										" from " + LoadConstant.otc + ".[dbo].[tsitemhours] tsh "+
										" left join " + LoadConstant.otc + ".[dbo].[tsitem] tsi on tsi.tsitemId = tsh.tsItemId "+
										" left join " + LoadConstant.otc + ".[dbo].[taskCenter] task on task.taskId = tsi.taskId "+
										" left join " + LoadConstant.otc + ".[dbo].[tstimesheet] t on t.timesheetId = tsi.timesheetId "+
										" where  (t.uid = m.uid) and cast(tsh.itemDate as DATE) >= :monthstartDate AND cast(tsh.itemDate as DATE) <= :monthEndDate and task.projectId = m.projectId)"+
										" ELSE (SELECT COALESCE(sum(tsh.billableHrs), 0) from [InfoBiz].[dbo].[tsitemhours] tsh "+
										" left join " + LoadConstant.otc + ".[dbo].[tsitem] tsi on tsi.tsitemId = tsh.tsItemId "+
										" left join " + LoadConstant.otc + ".[dbo].[taskCenter] task on task.taskId = tsi.taskId "+
										" left join " + LoadConstant.otc + ".[dbo].[tstimesheet] t on t.timesheetId = tsi.timesheetId "+
										" where  (t.uid = sd.sharepointAccountId) and cast(tsh.itemDate as DATE) >= :monthstartDate AND cast(tsh.itemDate as DATE) <= :monthEndDate "+
										" and task.projectId = s.projectId) END as tsHrs, "+
										" (select name from " + LoadConstant.infomaster + ".[dbo].uom where uomId = s.uomId) as uom, s.sowNo FROM [InfoBiz].[dbo].sowdetail sd "+
										" LEFT JOIN " + LoadConstant.otc + ".[dbo].[monthly_allocation] m on sd.sowdetailId = m.sowdetailId and "+
										" m.prdMonth = MONTH(:monthstartDate) and m.prdYear = YEAR(:monthstartDate) left join " + LoadConstant.otc + ".[dbo].sow s on sd.sowId = s.sowId "+
										" left join " + LoadConstant.infomaster + ".[dbo].project p on p.itemId = s.projectId where  s.uomId in "+
										" (select uomId from " + LoadConstant.infomaster + ".[dbo].uom where name != 'Milestone' ) and  sd.isBillable = 1 and " + 
										" ((cast(sd.sowRoleStartDate  as DATE) between :monthstartDate and :monthEndDate) " + 
										" or (cast(sd.sowRoleEndDate as DATE) between :monthstartDate and :monthEndDate) or " + 
										" (cast(sd.sowRoleStartDate as DATE) < :monthstartDate and cast(sd.sowRoleEndDate as DATE) > :monthEndDate)  )" + 
										" order by projectName ";
	
	public static final String
	Query_Monthly_Invoices_Report	=	" select (Select title from " +LoadConstant.infomaster+ ".[dbo].accounts where itemId = p.accountId) as accountName," +
										" (select title from " + LoadConstant.infomaster + ".[dbo].[project] where itemId = i.projectId) as projectName , i.clientPO, " +
										" i.finalInvoiceNo, i.invoiceType,i.endClientInvoiceNo, (select title from " + LoadConstant.infomaster + ".dbo.project where " +
									 	" itemid = i.endclientprojectid)as endClientProjName,i.arInvoiceDate, (select code from " + LoadConstant.infomaster + ".[dbo].[currency] " +
									 	" where currencyId = i.currencyId) as currency, i.netSubTotal,i.cgstAmt, i.sgstAmt, i.igstAmt,i.utgstAmt, i.sgdGstAmt, i.total " +
									 	" from " + LoadConstant.otc + ".dbo.invoices i" + 
									 	" left join " + LoadConstant.infomaster + ".[dbo].project p on p.itemId = i.projectId" +
										" where cast(i.arinvoicedate as DATE) >= :monthstartDate and cast(i.arinvoicedate as DATE) <= :monthEndDate " +
										" order by finalinvoiceno desc ";
	
	public static final String 
	Query_Invoices_Project_Count 	=	" select count(DISTINCT p.itemId) as invoiceCount, i.invoiceStatus " + 
										" from " + LoadConstant.infomaster + ".dbo.project p " + 
										" left join " + LoadConstant.otc + ".dbo.invoices i on p.itemid = i.projectid " + 
										" 	and (cast(i.periodenddate as DATE) between :monthstartDate and :monthEndDate) " + 
										" left join " +LoadConstant.infomaster+ ".dbo.accounts a on p.accountId = a.itemId" + 
										" left join " +LoadConstant.infomaster+ ".dbo.billingtype b on b.billingTypeId = p.billingTypeId " +
										" where (cast(p.projectStart as DATE) <= :monthEndDate) " + 
										" 	and (cast(p.projectEnd as DATE) >= :monthstartDate) " +
										" 	and b.name <> 'None' " +
										" 	and (p.projectManagersId = :uid or a.dmId = :uid or a.rmId = :uid or a.ahId = :uid)" + 
										" group by i.invoiceStatus";
										
	public static final String		
	Query_Search_By_InvoiceNo 		=	"select i.* , "+
										" p.itemId as itemId," +
										" cast(p.title as varchar(MAX)) as projectName," +
										" p.accountId as accountId," +
										" (Select title from " +LoadConstant.infomaster+ ".[dbo].accounts where itemId = p.accountId) as accountName," +
										"(select sign from " +LoadConstant.infomaster+".[dbo].[currency] where currencyId = i.exchangecurrencyId) as currSign," +
										" u.name as billingUnit," +
								        " u.unitName as billingEntity," +
										" cast(b.name as varchar) as billingType," +
										" 0 as pmApprovalStatus," +
										" 0 as otherInvoicesCount," +
										" 0 as CrDrCount, " +
										" (Select finalInvoiceNo from  " +LoadConstant.otc+".[dbo].invoices  " + 
										" where endClientInvoiceNo = i.finalInvoiceNo and " +
										" invoicetype = 'Internal Invoice' and finalinvoiceNo is not null) as internalInvoiceNo, " +
										" (Select title from " +LoadConstant.infomaster+ ".[dbo].project where " +
										" itemid = i.endClientProjectId ) as endClientProjName, " +
										" '' as country," +
										" '' as currency, " +
										" 0 as onShoreDevTotal, " +
										" 0 as offShoreDevTotal, "  + 
										" (select name from  " +LoadConstant.otc+ ".[dbo].projectType where projectTypeId = p.projectTypeId ) as projectType"  +
										" FROM " +LoadConstant.infomaster+ ".[dbo].project p" +
										" LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[unit] u on u.unitId = p.billingUnitId "+
										" LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[entities] e on e.entityId = u.entityId "+
										" LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[billingtype] b on b.billingTypeId = p.billingTypeId " +
										" LEFT JOIN " + LoadConstant.otc + ".[dbo].[projectType] pt on pt.projectTypeId = p.projectTypeId " +
										" left join " +LoadConstant.otc+".[dbo].invoices i on p.itemid = i.projectId " +
										" where finalInvoiceNo = :searchInvoiceNo " ;
					
	
	/* ------------------------------------- Queries for Revenue Dashboard ------------------------------------------------------*/
	
	/* Query constant to calculate revenue for milestone based projects */
	public static final String
	Query_Revenue_Milestone_Value	= 	" select vfbm.sowValue from " + LoadConstant.otc + ".[dbo].[monthlySOWRevenueforMilestone_View] vfbm" +
									    " where vfbm.sowId = ss.sowId " +
										" and vfbm.year = yy.year and vfbm.monthNo = mm.monthNo "	;
		
	//" select " + LoadConstant.otc + ".[dbo].[fn_GetNWDAmount_for_FBM](s.totalContractValue,s.sowId,m.monthNo,y.year,'milestone')"+
										//"		from	" + LoadConstant.otc + ".[dbo].[sowMilestone] sm" +
									  //	"		LEFT JOIN " + LoadConstant.otc + ".[dbo].[sow] s on s.sowId = sm.sowId" +
									   // "		from " + LoadConstant.otc + ".[dbo].[sow] s" +
									  	//"		LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[year] y on y.year = yy.year" +
									  	//"		LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[month] m on m.yearId = y.yearId and m.monthNo = mm.monthNo	" +
									  	//"		WHERE ((MONTH(s.sowStartDate) <= m.monthNo and YEAR(s.sowStartDate) = y.year) or (YEAR(s.sowStartDate) < y.year)) " +
									  	//"		 and ((MONTH(s.sowEndDate) >= m.monthNo and YEAR(s.sowEndDate) = y.year) or (YEAR(s.sowEndDate) > y.year))";
	
	/* Query constant to calculate revenue non milestone based projects */
	public static final String
	Query_Revenue_Nonmilestone_Value = " select vtm.sowValue from " + LoadConstant.otc + ".dbo.monthlySOWRevenueforTM_View vtm " + 
									   " where vtm.sowId = ss.sowId " + 
									   " and vtm.year = yy.year and vtm.monthNo = mm.monthNo ";
			 	
	
	//" select ((100-COALESCE(s.flatDiscountPer,0))*SUM(" + 
									    /*"		CASE" + 
									    "			WHEN ((MONTH(sd.sowRoleStartDate) = m.monthNo) and (YEAR(sd.sowRoleStartDate) = y.year) and (MONTH(sd.sowRoleEndDate) = m.monthNo) and (YEAR(sowRoleEndDate) = y.year)) " + 
									    "				THEN" + 
									    "					CASE WHEN s.uomId = 1 THEN COALESCE(" + LoadConstant.otc + ".dbo.fn_GetHolidays(DAY(sd.sowRoleStartDate),DAY(sd.sowRoleEndDate), sd.sowDetailId, m.monthNo, y.year) * sd.expectedBillability * sd.billableRate * 8, 0)" + 
									    "						WHEN s.uomId = 2 THEN COALESCE(" + LoadConstant.otc + ".dbo.fn_GetHolidays(DAY(sd.sowRoleStartDate),DAY(sd.sowRoleEndDate), sd.sowDetailId, m.monthNo, y.year) * sd.expectedBillability * sd.billableRate, 0)" + 
									    "						WHEN s.uomId = 4 THEN COALESCE(ROUND(" + LoadConstant.otc + ".dbo.fn_GetHolidays(DAY(sd.sowRoleStartDate), DAY(sd.sowRoleEndDate), sd.sowDetailId, m.monthNo, y.year)*2.0/20.85, 0, 1)/2.0 * sd.billableRate, 0)" +
									    "						ELSE 0" + 
									    "					END" + 
									    "			WHEN ((MONTH(sowRoleStartDate) = m.monthNo) and (YEAR(sowRoleStartDate) = y.year)) " + 
									    "				THEN" + 
									    "					CASE WHEN s.uomId = 1 THEN COALESCE(" + LoadConstant.otc + ".dbo.fn_GetHolidays(DAY(sd.sowRoleStartDate),0, sd.sowDetailId, m.monthNo, y.year) * sd.expectedBillability * sd.billableRate * 8, 0)" + 
									    "						WHEN s.uomId = 2 THEN COALESCE(" + LoadConstant.otc + ".dbo.fn_GetHolidays(DAY(sd.sowRoleStartDate),0, sd.sowDetailId, m.monthNo, y.year) * sd.expectedBillability * sd.billableRate, 0)" + 
									    "						WHEN s.uomId = 4 THEN COALESCE(ROUND(" + LoadConstant.otc + ".dbo.fn_GetHolidays(DAY(sd.sowRoleStartDate),0, sd.sowDetailId, m.monthNo, y.year)*2.0/20.85, 0, 1)/2.0 * sd.billableRate, 0)" + 
									    "						ELSE 0 " + 
									    "					END" + 
									    "			WHEN ((MONTH(sowRoleEndDate) = m.monthNo) and (YEAR(sowRoleEndDate) = y.year)) " + 
									    "				THEN" + 
									    "					CASE WHEN s.uomId = 1 THEN COALESCE(" + LoadConstant.otc + ".dbo.fn_GetHolidays(0,DAY(sd.sowRoleEndDate), sd.sowDetailId, m.monthNo, y.year) * sd.expectedBillability * sd.billableRate * 8, 0)" + 
									    "						WHEN s.uomId = 2 THEN COALESCE(" + LoadConstant.otc + ".dbo.fn_GetHolidays(0,DAY(sd.sowRoleEndDate), sd.sowDetailId, m.monthNo, y.year) * sd.expectedBillability * sd.billableRate, 0)" + 
									    "						WHEN s.uomId = 4 THEN COALESCE(ROUND(" + LoadConstant.otc + ".dbo.fn_GetHolidays(0, DAY(sd.sowRoleEndDate), sd.sowDetailId, m.monthNo, y.year)*2.0/20.85, 0, 1)/2.0 * sd.billableRate, 0)" +  
									    "						ELSE 0 " + 
									    "					END" + 
									    "			ELSE" +
									    " 				CASE WHEN s.uomId = 1 THEN COALESCE((" + LoadConstant.otc + ".dbo.fn_GetHolidays(0,0, sd.sowDetailId, m.monthNo, y.year) * sd.expectedBillability * sd.billableRate * 8), 0) " + 
									    "					WHEN s.uomId = 2 THEN COALESCE((" + LoadConstant.otc + ".dbo.fn_GetHolidays(0,0, sd.sowDetailId, m.monthNo, y.year) * sd.expectedBillability * sd.billableRate), 0) " + 
									    "					WHEN s.uomId = 4 THEN COALESCE((sd.expectedBillability * sd.billableRate), 0) " + 
									    "			   	ELSE 0" + 
									    "			END"+
									    "		END*/
									   /* LoadConstant.otc+".[dbo].[fn_GetNWDAmount](sd.sowDetailId,m.monthNo,y.year,'sowDetail')"+
									    ")/100)" + 
									    "		from " + LoadConstant.otc + ".[dbo].[sowDetail] sd" + 
									    "		LEFT JOIN " + LoadConstant.otc + ".[dbo].[sow] s on s.sowId = sd.sowId" + 
									    "   	LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[year] y on y.year = yy.year "+
									    "   	LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[month] m on m.yearId = y.yearId and m.monthNo = mm.monthNo"+
									    "		WHERE ((MONTH(sd.sowRoleStartDate) <= m.monthNo and YEAR(sd.sowRoleStartDate) = y.year) or (YEAR(sd.sowRoleStartDate) < y.year)) and" + 
									    "			  ((MONTH(sd.sowRoleEndDate) >= m.monthNo and YEAR(sd.sowRoleEndDate) = y.year) or (YEAR(sd.sowRoleEndDate) > y.year))";
			*/
	
	/* Query constant to calculate revenue from staffing */
	public static final String
	Query_Revenue_By_Staffing = 		" (CASE WHEN p.billingTypeId = 3 "+ // Fixed bid Milestone projects
									    " THEN "+
									    "	( " + Query_Revenue_Milestone_Value   + ")" +
									    " ELSE "+
									    " 	(select (SUM( "+
									    /*" 		CASE "+
									    " 			WHEN ((MONTH(a.alcStartDate) = m.monthNo) and (YEAR(a.alcStartDate) = y.year) and (MONTH(a.alcEndDate) = m.monthNo) and (YEAR(a.alcEndDate) = y.year)) "+
									    " 				THEN "+
									    " 					CASE WHEN s.uomId = 1 THEN COALESCE(" + LoadConstant.otc + ".dbo.fn_GetHolidays(DAY(a.alcStartDate),DAY(a.alcEndDate), sd.sowDetailId, m.monthNo, y.year) * sd.expectedBillability * sd.billableRate * 8, 0) "+ 
									    " 						WHEN s.uomId = 2 THEN COALESCE(" + LoadConstant.otc + ".dbo.fn_GetHolidays(DAY(a.alcStartDate),DAY(a.alcEndDate), sd.sowDetailId, m.monthNo, y.year) * sd.expectedBillability * sd.billableRate, 0) "+
									    " 						WHEN s.uomId = 4 THEN COALESCE(ROUND(" + LoadConstant.otc + ".dbo.fn_GetHolidays(DAY(a.alcStartDate), DAY(a.alcEndDate), sd.sowDetailId, m.monthNo, y.year)*2.0/20.85, 0, 1)/2.0 * sd.billableRate, 0)" +
									    " 						ELSE 0 "+
									    " 						END "+
									    " 			WHEN ((MONTH(a.alcStartDate) = m.monthNo) and (YEAR(a.alcStartDate) = y.year)) "+  
									    " 				THEN "+
									    " 					CASE WHEN s.uomId = 1 THEN COALESCE(" + LoadConstant.otc + ".dbo.fn_GetHolidays(DAY(a.alcStartDate),0, sd.sowDetailId, m.monthNo, y.year) * sd.expectedBillability * sd.billableRate * 8, 0) "+
									    " 					WHEN s.uomId = 2 THEN COALESCE(" + LoadConstant.otc + ".dbo.fn_GetHolidays(DAY(a.alcStartDate),0, sd.sowDetailId, m.monthNo, y.year) * sd.expectedBillability * sd.billableRate, 0) "+
									    " 					WHEN s.uomId = 4 THEN COALESCE(ROUND(" + LoadConstant.otc + ".dbo.fn_GetHolidays(DAY(a.alcStartDate),0, sd.sowDetailId, m.monthNo, y.year)*2.0/20.85, 0, 1)/2.0 * sd.billableRate, 0)" + 
									    " 					ELSE 0 "+
									    " 				END "+
									    " 			WHEN ((MONTH(a.alcEndDate) = m.monthNo) and (YEAR(a.alcEndDate) = y.year)) "+ 
									    " 				THEN "+
									    " 					CASE WHEN s.uomId = 1 THEN COALESCE(" + LoadConstant.otc + ".dbo.fn_GetHolidays(0,DAY(a.alcEndDate), sd.sowDetailId, m.monthNo, y.year) * sd.expectedBillability * sd.billableRate * 8, 0) "+ 
									    " 						WHEN s.uomId = 2 THEN COALESCE(" + LoadConstant.otc + ".dbo.fn_GetHolidays(0,DAY(a.alcEndDate), sd.sowDetailId, m.monthNo, y.year) * sd.expectedBillability * sd.billableRate, 0) "+
									    " 						WHEN s.uomId = 4 THEN COALESCE(ROUND(" + LoadConstant.otc + ".dbo.fn_GetHolidays(0, DAY(a.alcEndDate), sd.sowDetailId, m.monthNo, y.year)*2.0/20.85, 0, 1)/2.0 * sd.billableRate, 0)" +  
									    " 						ELSE 0 "+
									    " 					END "+ 
									    " 			ELSE "+
									    " 				CASE WHEN s.uomId = 1 THEN COALESCE((" + LoadConstant.otc + ".dbo.fn_GetHolidays(0,0, sd.sowDetailId, m.monthNo, y.year) * sd.expectedBillability * sd.billableRate * 8), 0) "+
									    " 				WHEN s.uomId = 2 THEN COALESCE((" + LoadConstant.otc + ".dbo.fn_GetHolidays(0,0, sd.sowDetailId, m.monthNo, y.year) * sd.expectedBillability * sd.billableRate), 0) "+
									    " 				WHEN s.uomId = 4 THEN COALESCE((sd.expectedBillability * sd.billableRate), 0)   "+
									    " 		   	ELSE 0  "+ 
									    " 		END"+
									    " 	END*/
									    LoadConstant.otc+".[dbo].[fn_GetNWDAmount](sd.sowDetailId,m.monthNo,y.year,'allocation')"+
									    "))"+
									    " 	from " + LoadConstant.otc + ".[dbo].[allocation] a  "+
									    " 	LEFT JOIN " + LoadConstant.otc + ".[dbo].[sowDetail] sd on sd.sowDetailId = a.sowDetailId "+
									    " 	LEFT JOIN " + LoadConstant.otc + ".[dbo].[sow] s on s.sowId = sd.sowId "+
									    "  	LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[year] y on y.year = yy.year "+
									    "   LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[month] m on m.yearId = y.yearId and m.monthNo = mm.monthNo "+
									    " 	where s.sowId = ss.sowId and a.alcType = 1 and "+
									    " 		((MONTH(a.alcStartDate) <= m.monthNo and YEAR(a.alcStartDate) = y.year) or (YEAR(a.alcStartDate) < y.year)) and "+
									    " 		((MONTH(a.alcEndDate) >= m.monthNo and YEAR(a.alcEndDate) = y.year) or (YEAR(a.alcEndDate) > y.year)) ) " +
									    " END) ";
	
	/* Query constants for revenue by SOW */
	public static final String
	Query_Revenue_By_SOW			=	" CASE WHEN p.billingTypeId = 3 "+ // Fixed bid Milestone projects
									    " THEN "+
									    "	( " + Query_Revenue_Milestone_Value + 
									    "	  group by vfbm.sowId,vfbm.sowValue)" + 
									  	" ELSE" +
									  	"	( " + Query_Revenue_Nonmilestone_Value  + ")" +
									    " END " ;
	
	/* Query constants for revenue by Project */
	public static final String
	Query_Revenue_By_Project			=	" CASE WHEN p.billingTypeId = 3 "+ // Fixed bid Milestone projects
									    " THEN "+
									    "	( " + Query_Revenue_Milestone_Value + " and vfbm.projectId = p.itemId)" + 
									  	" ELSE" +
									  	"	( " + Query_Revenue_Nonmilestone_Value + " and s.projectId = p.itemId" + 
									  //  "	  group by s.flatDiscountPer)" + 
									    " END " ;
	
	/* Query constants for revenue by invoice */
	public static final String
	Query_Revenue_By_Invoice 	=  	" select COALESCE(sum((100-COALESCE(i.flatDiscountPer,0))*id.amount), 0)/100 "+
							    	" FROM " + LoadConstant.otc + ".[dbo].[invoiceDetail] id "+
							    	" LEFT JOIN " + LoadConstant.otc + ".[dbo].[invoices] i on i.invoiceId = id.invoiceId "+
							    	" where i.projectId = p.itemId and "+
							    	" i.invoiceType in ('Services Invoice', 'License Invoice') and " +
							    	" (i.invoiceStatus = 'Completed' or i.invoiceStatus = 'Approved') and MONTH(i.periodEndDate) = mm.monthNo and YEAR(i.periodEndDate) = yy.year";
							
	/* Query constant for fetching Revenue Variance YTD details*/
	public static final String 
	Query_Revenue_Invoice_YTD		=	" SELECT i.*," +
										" p.itemId as itemId," +
										" cast(p.title as varchar(MAX)) as projectName," +
										" p.accountId as accountId, pa.title as accountName," +
										" u.name as billingUnit, u.unitName as billingEntity, cast(b.name as varchar) as billingType," +
										" 0 as pmApprovalStatus," +
										" 0 as otherInvoicesCount," +
										" 0 as CrDrCount, " +
										" '0' as internalInvoiceNo, " +
										" '' as endClientProjName, " +
										" pa.country," +
										" (select sign from " +LoadConstant.infomaster+".[dbo].[currency] where currencyId = i.exchangecurrencyId) as currSign," +
										" (select code from " +LoadConstant.infomaster+ ".dbo.currency where currencyid = i.exchangecurrencyId) as currency, " +
										" (select COALESCE(sum((100-COALESCE(ii.flatDiscountPer,0))*id.amount), 0)/100 " + 
										" 	FROM " + LoadConstant.otc + ".[dbo].[invoiceDetail] id " +
										" 	LEFT JOIN " + LoadConstant.otc + ".[dbo].[invoices] ii on ii.invoiceId = id.invoiceId "+
										" 	where id.invoiceid = i.invoiceid and " +
										"	countryId in (select countryid from " +LoadConstant.infomaster+ ".dbo.country where countryName != 'India')) as onShoreDevTotal," + 
										" (select COALESCE(sum((100-COALESCE(ii.flatDiscountPer,0))*id.amount), 0)/100 " + 
										" 	FROM " + LoadConstant.otc + ".[dbo].[invoiceDetail] id " + 
										" 	LEFT JOIN " + LoadConstant.otc + ".[dbo].[invoices] ii on ii.invoiceId = id.invoiceId "+
										" 	where id.invoiceid = i.invoiceid and " +
										" 	( (countryId in (select countryid from " +LoadConstant.infomaster+ ".dbo.country where countryName = 'India')) or " +
										"	  (countryId is NULL) )) as offShoreDevTotal, " +
										" '' as projectType, " +
										" u.unitId, " +
										" 0 as interUnitCount " +
										" FROM " + LoadConstant.otc + ".dbo.invoices i " + 
										" left join " +LoadConstant.infomaster+ ".[dbo].project p on p.itemid = i.projectId " + 
										" LEFT JOIN " +LoadConstant.infomaster+ ".[dbo].[accounts] pa on pa.itemId = p.accountId " + 
										" LEFT JOIN " +LoadConstant.infomaster+ ".[dbo].[unit] u on u.unitId = p.billingUnitId " + 
										" LEFT JOIN " +LoadConstant.infomaster+ ".[dbo].[entities] e on e.entityId = u.entityId " + 
										" LEFT JOIN " +LoadConstant.infomaster+ ".[dbo].[billingtype] b on b.billingTypeId = p.billingTypeId " + 
										" LEFT JOIN " + LoadConstant.otc + ".[dbo].[projectType] pt on pt.projectTypeId = p.projectTypeId " +
										" where i.invoiceType in ('Services Invoice', 'License Invoice') and" + 
										" p.billingTypeId != 4 and p.projectTypeId != 12 and p.state != 'Draft' and "+
										" ((:phId != 0 and pa.dmId = :phId) or (:cepId != 0 and pa.rmId = :cepId) or (:phId = 0 and :cepId = 0)) and " +
										" (i.invoiceStatus = 'Completed' or i.invoiceStatus = 'Approved') and YEAR(i.periodEndDate) = :year";
	
	
	/* Query constants for contract gap percentage */
	public static final String
	Query_Contract_Gap_Percentage 	=  	"(CASE WHEN ss.revenue != 0 and ss.totalContractValue is not NULL " +
									    "	THEN (ss.revenue - ss.totalContractValue)*100/ss.revenue " +
									    "	ELSE 0 " +
									    " END) ";
	
	/* Query constants for retrieving invoice currency code */
	public static final String
	Query_Invoice_Currency 			=  	" (select TOP 1 iCur.code from " + LoadConstant.otc + ".[dbo].[invoices] i "+
										" left join " + LoadConstant.infomaster + ".[dbo].[currency] iCur on i.exchangecurrencyId = iCur.currencyId "+
										" where i.projectId = p.itemId and (i.invoiceStatus = 'Completed' or i.invoiceStatus = 'Approved') and MONTH(i.periodEndDate) = mm.monthNo and YEAR(i.periodEndDate) = yy.year)";
	
	public static final String
	Query_Revenue_Dashboard			= 	"SELECT p.itemId, p.title, p.accountId, p.projectManagersId, p.billingTypeId," +
										"ss.sowNo, ss.sowId, ss.sowStartDate, ss.sowEndDate,"+
										"pa.accountShortName as accountName, " +
									    "cast(rPm.title as VARCHAR (max)) as pmName, " +
									    "pt.name as projectTypeText, " +
									    "cast(rPo.title as VARCHAR (max)) as ownerName, " +
									    "cast(rDm.title as VARCHAR (max)) as dmName, " +
									    "cast(rRm.title as VARCHAR (max)) as rmName, " +
									    "u.name as executionUnit, b.name as billingTypeName, "+
									    "(SELECT reg.regionName from " + LoadConstant.infomaster + ".[dbo].region reg "+
									    	" where reg.regionId = pa.regionId) as regionName, "+
									    "mm.month, mm.monthNo, pa.accountNo," +
									    "(select name from " + LoadConstant.infomaster + ".[dbo].documentType where documentTypeId = ss.documentTypeId) as documentType, "+
									    Query_Contract_Gap_Percentage + " as contractGapPercent, " +
									    Query_Revenue_By_SOW + " as sowValue, "+
									    Query_Revenue_By_Staffing + " as alcValue, "+									    
									    "	(select " + 
									    "		CASE" + 
									    "			WHEN s.totalContractValue is not NULL" + 
									    "			THEN s.totalContractValue" + 
									    "			ELSE s.revenue" + 
									    "		END" + 
									    "	FROM " + LoadConstant.otc + ".dbo.sow s" + 
									    " 	where s.sowId = ss.sowId) as totalContractValue, "+
									    "(" + Query_Revenue_By_Invoice +" and ss.sowId = id.sowId) as invoiceValue, " +
									    Query_Invoice_Currency + " as invoiceCurrencySign, " +										
									    "(select cur.code FROM " + LoadConstant.infomaster + ".[dbo].[currency] cur " +
												" where cur.currencyId = ss.currencyId) as currencySign "+
								    	" FROM " + LoadConstant.otc + ".[dbo].sow as ss " +
				                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].project as p on ss.projectId = p.itemId " +
				                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[accounts] pa on pa.itemId = p.accountId " +
				                        " LEFT JOIN " + LoadConstant.otc + ".[dbo].[projectType] pt on pt.projectTypeId = p.projectTypeId " +
				                        " Left JOIN " + LoadConstant.infomaster + ".[dbo].[resource] rPm on rPm.uid = p.projectManagersId " +
				                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[resource] rDm on rDm.uid = pa.dmId "+
				                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[resource] rRm on rRm.uid = pa.rmId "+
				                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[resource] rPo on rPo.uid = pa.ahId "+
				                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[unit] u on u.unitId = p.executionUnitId "+
				                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[year] yy on yy.year = :year "+
					                    " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[billingtype] b on b.billingTypeId = p.billingTypeId " +				                        
				                        // p.projectTypeId != 12 == removing internal billing projects
				                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[month] mm on mm.yearId = yy.yearId " +
				                        " where p.billingTypeId != 4 and p.projectTypeId != 12 and p.state != 'Draft' and "+
				                        " ( (:pid != 0 and p.itemId = :pid) or (:accountId != 0 and pa.itemId = :accountId) or " +
				                        "   (:phId != 0 and pa.dmId = :phId) or (:cepId != 0 and pa.rmId = :cepId) or " +
				                        "   (:pid = 0 and :accountId = 0 and :phId = 0 and :cepId = 0 and pa.itemId is not null) ) and" +
				                        " ((YEAR(ss.sowStartDate) = yy.year or YEAR(ss.sowStartDate) < yy.year) and" + 
				                        "  (YEAR(ss.sowEndDate) = yy.year or YEAR(ss.sowEndDate) > yy.year))";
	
	
	/* Query constants for revenue by SOW */
	public static final String
	Query_Revenue_Milestone_By_Cms =	" select SUM(c.revenue) from " + LoadConstant.otc + ".[dbo].[cms] c	" +
								  		"		WHERE c.cmsId = cms.cmsId";
	
	/* Query constants for revenue by SOW */
	public static final String
	Query_Revenue_Nonmilestone_By_Cms = " select (SUM(" + 
									    /*"		CASE" + 
									    "			WHEN ((MONTH(sd.sowRoleStartDate) = m.monthNo) and (YEAR(sd.sowRoleStartDate) = y.year) and (MONTH(sd.sowRoleEndDate) = m.monthNo) and (YEAR(sowRoleEndDate) = y.year)) " + 
									    "				THEN" + 
									    "					CASE WHEN s.uomId = 1 THEN COALESCE(" + LoadConstant.otc + ".dbo.fn_GetHolidays(DAY(sd.sowRoleStartDate),DAY(sd.sowRoleEndDate), sd.cmsDetailId, m.monthNo, y.year) * sd.expectedBillability * sd.billableRate * 8, 0)" + 
									    "						WHEN s.uomId = 2 THEN COALESCE(" + LoadConstant.otc + ".dbo.fn_GetHolidays(DAY(sd.sowRoleStartDate),DAY(sd.sowRoleEndDate), sd.cmsDetailId, m.monthNo, y.year) * sd.expectedBillability * sd.billableRate, 0)" + 
									    "						WHEN s.uomId = 4 THEN COALESCE(ROUND(" + LoadConstant.otc + ".dbo.fn_GetHolidays(DAY(sd.sowRoleStartDate), DAY(sd.sowRoleEndDate), sd.cmsDetailId, m.monthNo, y.year)*2.0/20.85, 0, 1)/2.0 * sd.billableRate, 0)" +
									    "						WHEN s.uomId = 5 THEN COALESCE(" + LoadConstant.otc + ".dbo.fn_GetHolidays(DAY(sd.sowRoleStartDate),DAY(sd.sowRoleEndDate), sd.cmsDetailId, m.monthNo, y.year) * sd.expectedBillability * sd.billableRate * 8, 0)" + 
									    "						ELSE 0" + 
									    "					END" + 
									    "			WHEN ((MONTH(sowRoleStartDate) = m.monthNo) and (YEAR(sowRoleStartDate) = y.year)) " + 
									    "				THEN" + 
									    "					CASE WHEN s.uomId = 1 THEN COALESCE(" + LoadConstant.otc + ".dbo.fn_GetHolidays(DAY(sd.sowRoleStartDate),0, sd.cmsDetailId, m.monthNo, y.year) * sd.expectedBillability * sd.billableRate * 8, 0)" + 
									    "						WHEN s.uomId = 2 THEN COALESCE(" + LoadConstant.otc + ".dbo.fn_GetHolidays(DAY(sd.sowRoleStartDate),0, sd.cmsDetailId, m.monthNo, y.year) * sd.expectedBillability * sd.billableRate, 0)" + 
									    "						WHEN s.uomId = 4 THEN COALESCE(ROUND(" + LoadConstant.otc + ".dbo.fn_GetHolidays(DAY(sd.sowRoleStartDate),0, sd.cmsDetailId, m.monthNo, y.year)*2.0/20.85, 0, 1)/2.0 * sd.billableRate, 0)" + 
									    "						WHEN s.uomId = 5 THEN COALESCE(" + LoadConstant.otc + ".dbo.fn_GetHolidays(DAY(sd.sowRoleStartDate),0, sd.cmsDetailId, m.monthNo, y.year) * sd.expectedBillability * sd.billableRate * 8, 0)" + 
									    "						ELSE 0 " + 
									    "					END" + 
									    "			WHEN ((MONTH(sowRoleEndDate) = m.monthNo) and (YEAR(sowRoleEndDate) = y.year)) " + 
									    "				THEN" + 
									    "					CASE WHEN s.uomId = 1 THEN COALESCE(" + LoadConstant.otc + ".dbo.fn_GetHolidays(0,DAY(sd.sowRoleEndDate), sd.cmsDetailId, m.monthNo, y.year) * sd.expectedBillability * sd.billableRate * 8, 0)" + 
									    "						WHEN s.uomId = 2 THEN COALESCE(" + LoadConstant.otc + ".dbo.fn_GetHolidays(0,DAY(sd.sowRoleEndDate), sd.cmsDetailId, m.monthNo, y.year) * sd.expectedBillability * sd.billableRate, 0)" + 
									    "						WHEN s.uomId = 4 THEN COALESCE(ROUND(" + LoadConstant.otc + ".dbo.fn_GetHolidays(0, DAY(sd.sowRoleEndDate), sd.cmsDetailId, m.monthNo, y.year)*2.0/20.85, 0, 1)/2.0 * sd.billableRate, 0)" +  
									    "						WHEN s.uomId = 5 THEN COALESCE(" + LoadConstant.otc + ".dbo.fn_GetHolidays(0,DAY(sd.sowRoleEndDate), sd.cmsDetailId, m.monthNo, y.year) * sd.expectedBillability * sd.billableRate * 8, 0)" + 
									    "						ELSE 0 " + 
									    "					END" + 
									    "			ELSE" +
									    " 				CASE WHEN s.uomId = 1 THEN COALESCE((" + LoadConstant.otc + ".dbo.fn_GetHolidays(0,0, sd.cmsDetailId, m.monthNo, y.year) * sd.expectedBillability * sd.billableRate * 8), 0) " + 
									    "					WHEN s.uomId = 2 THEN COALESCE((" + LoadConstant.otc + ".dbo.fn_GetHolidays(0,0, sd.cmsDetailId, m.monthNo, y.year) * sd.expectedBillability * sd.billableRate), 0) " + 
									    "					WHEN s.uomId = 4 THEN COALESCE((sd.expectedBillability * sd.billableRate), 0) " + 
									    "					WHEN s.uomId = 5 THEN COALESCE(" + LoadConstant.otc + ".dbo.fn_GetHolidays(0,0, sd.cmsDetailId, m.monthNo, y.year) * sd.expectedBillability * sd.billableRate * 8, 0)" + 
									    "			   	ELSE 0" + 
									    "			END"+
									    "		END*/
									    LoadConstant.otc+".[dbo].[fn_GetNWDAmount](sd.cmsDetailId,m.monthNo,y.year,'cmsDetail')"+
									    "))" + 
									    "		from " + LoadConstant.otc + ".[dbo].[cmsDetail] sd" + 
									    "		LEFT JOIN " + LoadConstant.otc + ".[dbo].[cms] s on s.cmsId = sd.cmsId" + 
									    "   	LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[year] y on y.year = yy.year "+
									    "   	LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[month] m on m.yearId = y.yearId and m.monthNo = mm.monthNo"+
									    "		WHERE s.cmsId = cms.cmsId and sd.status != 'Cancelled' and sd.status != 'Active' and " +
									    "			 ((MONTH(sd.sowRoleStartDate) <= m.monthNo and YEAR(sd.sowRoleStartDate) = y.year) or (YEAR(sd.sowRoleStartDate) < y.year)) and" + 
									    "			  ((MONTH(sd.sowRoleEndDate) >= m.monthNo and YEAR(sd.sowRoleEndDate) = y.year) or (YEAR(sd.sowRoleEndDate) > y.year))";
		
	/* Query constants for revenue by CM-S (Total) */
	public static final String
	Query_Revenue_By_Cms =				" CASE "+
											" WHEN cms.uomId != 5 THEN ( " + Query_Revenue_Nonmilestone_By_Cms + ")" + // Non Milestone projects
											" WHEN cms.uomId = 5 AND " + // And role end date of one role should match the current month and year
											"		mm.monthNo = (SELECT TOP 1 MONTH(sowRoleEndDate)  FROM " + LoadConstant.otc + ".[dbo].[cmsDetail]) AND " +
											"		yy.year = (SELECT TOP 1 YEAR(sowRoleEndDate)  FROM " + LoadConstant.otc + ".[dbo].[cmsDetail]) " +
											" 	THEN ( " + Query_Revenue_Milestone_By_Cms + ")" + // Non Milestone projects
											" ELSE (0) " +
									    " END ";
	
	/* Query constants for revenue by CM-S (Certain) */
	public static final String
	Query_Revenue_Certain_By_Cms =		" CASE "+
											" WHEN cms.uomId != 5 THEN ( " + Query_Revenue_Nonmilestone_By_Cms + " and sd.probability = 'Certain')" + // Non Milestone projects
											" WHEN cms.uomId = 5 AND " + // And role end date of one role should match the current month and year
											"		mm.monthNo = (SELECT TOP 1 MONTH(sowRoleEndDate)  FROM " + LoadConstant.otc + ".[dbo].[cmsDetail] where cmsId = cms.cmsId) AND " +
											"		yy.year = (SELECT TOP 1 YEAR(sowRoleEndDate)  FROM " + LoadConstant.otc + ".[dbo].[cmsDetail] where cmsId = cms.cmsId) AND " +
											" 		'Certain' = (SELECT TOP 1 probability FROM " + LoadConstant.otc + ".[dbo].[cmsDetail] where cmsId = cms.cmsId) "+
											" 	THEN ( " + Query_Revenue_Milestone_By_Cms + ")" + // Non Milestone projects
											" ELSE (0) " +
									    " END ";
	
	/* Query constants for revenue by CM-S (Certain) */
	public static final String
	Query_Revenue_High_By_Cms =		" CASE "+
											" WHEN cms.uomId != 5 THEN ( " + Query_Revenue_Nonmilestone_By_Cms + " and sd.probability = 'High')" + // Non Milestone projects
											" WHEN cms.uomId = 5 AND " + // And role end date of one role should match the current month and year
											"		mm.monthNo = (SELECT TOP 1 MONTH(sowRoleEndDate)  FROM " + LoadConstant.otc + ".[dbo].[cmsDetail] where cmsId = cms.cmsId) AND " +
											"		yy.year = (SELECT TOP 1 YEAR(sowRoleEndDate)  FROM " + LoadConstant.otc + ".[dbo].[cmsDetail] where cmsId = cms.cmsId) AND" +
											" 		'High' = (SELECT TOP 1 probability FROM " + LoadConstant.otc + ".dbo.[cmsDetail] where cmsId = cms.cmsId) "+
											" 	THEN ( " + Query_Revenue_Milestone_By_Cms + ")" + // Non Milestone projects
											" ELSE (0) " +
									    " END ";
	
	/* Query constants for revenue by CM-S (Medium) */
	public static final String
	Query_Revenue_Medium_By_Cms =		" CASE "+
											" WHEN cms.uomId != 5 THEN ( " + Query_Revenue_Nonmilestone_By_Cms + " and sd.probability = 'Medium')" + // Non Milestone projects
											" WHEN cms.uomId = 5 AND " + // And role end date of one role should match the current month and year
											"		mm.monthNo = (SELECT TOP 1 MONTH(sowRoleEndDate)  FROM " + LoadConstant.otc + ".[dbo].[cmsDetail] where cmsId = cms.cmsId) AND " +
											"		yy.year = (SELECT TOP 1 YEAR(sowRoleEndDate)  FROM " + LoadConstant.otc + ".[dbo].[cmsDetail] where cmsId = cms.cmsId) AND " +
											" 		'Medium' = (SELECT TOP 1 probability FROM " + LoadConstant.otc + ".[dbo].[cmsDetail] where cmsId = cms.cmsId) "+
											" 	THEN ( " + Query_Revenue_Milestone_By_Cms + ")" + // Non Milestone projects
											" ELSE (0) " +
									    " END ";
	
	/* Query constants for revenue by CM-S (Certain) */
	public static final String
	Query_Revenue_Low_By_Cms =		" CASE "+
											" WHEN cms.uomId != 5 THEN ( " + Query_Revenue_Nonmilestone_By_Cms + " and sd.probability = 'Low')" + // Non Milestone projects
											" WHEN cms.uomId = 5 AND " + // And role end date of one role should match the current month and year
											"		mm.monthNo = (SELECT TOP 1 MONTH(sowRoleEndDate)  FROM " + LoadConstant.otc + ".[dbo].[cmsDetail] where cmsId = cms.cmsId) AND " +
											"		yy.year = (SELECT TOP 1 YEAR(sowRoleEndDate)  FROM " + LoadConstant.otc + ".[dbo].[cmsDetail] where cmsId = cms.cmsId) AND " +
											" 		'Low' = (SELECT TOP 1 probability FROM " + LoadConstant.otc + ".[dbo].[cmsDetail] where cmsId = cms.cmsId) "+
											" 	THEN ( " + Query_Revenue_Milestone_By_Cms + ")" + // Non Milestone projects
											" ELSE (0) " +
									    " END ";
	
	
	
	public static final String
	Query_Revenue_Forecast_Existing_Business = " SELECT rp.*, p.itemId, cast(p.title as VARCHAR (max)) as title," + 
								 " p.accountId as accountId, pa.accountShortName as accountName,"+
								 Query_Contract_Gap_Percentage + " as contractGapPercent, " +
								 Query_Revenue_By_SOW + " as sowValue, "+
								 "(" + Query_Revenue_By_Invoice +  " and ss.sowId = id.sowId) as invoiceValue,  "+
								 Query_Invoice_Currency + " as invoiceCurrencySign, " +	
								 "(select cur.code FROM " + LoadConstant.infomaster + ".[dbo].[currency] cur " +
									" where cur.currencyId = (select TOP 1 ss.currencyId from " + LoadConstant.otc + ".[dbo].sow ss where ss.projectId = p.itemId order by ss.sowId DESC)) as currencySign, "+
								 " mm.monthNo as monthNo , 0 as cmsIdfrmCMS, cast(b.name as varchar(max)) as billingType,'' as opportunityName, 0 as opportunityValue" +
								 " FROM " + LoadConstant.otc + ".[dbo].sow as ss " +
			                     " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].project as p on ss.projectId = p.itemId " +
			                     " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].billingType as b on p.billingTypeId = b.billingTypeId " +
								 " LEFT JOIN " + LoadConstant.otc + ".[dbo].revenueProjection as rp on rp.projectId = p.itemId and rp.year = :year " +
								 " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[accounts] pa on pa.itemId = p.accountId " +
					             " LEFT JOIN " + LoadConstant.otc + ".[dbo].[projectType] pt on pt.projectTypeId = p.projectTypeId " +
					             " Left JOIN " + LoadConstant.infomaster + ".[dbo].[resource] rPm on rPm.uid = p.projectManagersId " +
					             " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[resource] rDm on rDm.uid = pa.dmId "+
					             " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[resource] rRm on rRm.uid = pa.rmId "+
					             " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[year] yy on yy.year = :year "+
					             " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[month] mm on mm.yearId = yy.yearId" +
					             " where p.billingTypeId != 4 and p.projectTypeId != 12 and p.state != 'Draft' and "+
					             " ((:pid != 0 and p.itemId = :pid) or (:accountId != 0 and pa.itemId = :accountId) or (:pid = 0 and :accountId = 0 and pa.itemId is not null)) and" +
					             " 	 ((YEAR(ss.sowStartDate) = yy.year or YEAR(ss.sowStartDate) < yy.year) and" + 
			                     "    (YEAR(ss.sowEndDate) = yy.year or YEAR(ss.sowEndDate) > yy.year)) and "+
					             " (((:uid != 0) and ((p.projectManagersId = :uid) or (pa.ahId = :uid) or (pa.dmId = :uid))) or (:uid = 0))" ;

	public static final String
	Query_Revenue_Forecast_Pipeline_Business = " SELECT rp.*, 0 as itemId, cms.dummyProjectName as title," + 
								 " cms.accountId as accountId, pa.accountShortName as accountName, "+
								 " 0 as contractGapPercent, " +
								 " ( " + Query_Revenue_By_Cms + ") as sowValue,"  +
								 " 0 as invoiceValue,  "+
								 " '$' as invoiceCurrencySign, " +
								 "(select cur.code FROM " + LoadConstant.infomaster + ".[dbo].[currency] cur " +
									" where cur.currencyId = cms.currencyId) as currencySign, "+
								 " mm.monthNo as monthNo, cms.cmsId as cmsIdfrmCMS, '' as billingType, o.opportunityName, o.opportunityValue " +
								 " FROM " + LoadConstant.otc + ".[dbo].cms as cms " +
								 " LEFT JOIN " + LoadConstant.otc + ".[dbo].revenueProjection as rp on rp.cmsId = cms.cmsId and rp.year = :year " +
								 " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].opportunity o on cms.opportunityid = o.opportunityid " +
								 " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[accounts] pa on pa.itemId = cms.accountId " +
					             " Left JOIN " + LoadConstant.infomaster + ".[dbo].[resource] rPm on rPm.uid = cms.createdBy " +
					             " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[resource] rDm on rDm.uid = pa.dmId "+
					             " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[resource] rRm on rRm.uid = pa.rmId "+
					             " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[year] yy on yy.year = :year "+
					             " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[month] mm on mm.yearId = yy.yearId" +
					             " where (:uid = 0 or cms.createdBy = :uid or pa.dmId = :uid)";
	
	public static final String
	Query_Revenue_Forecast = 	 " SELECT rp.*, 0 as itemId, '' as title," + 
								 " pa.itemId as accountId, pa.accountShortName as accountName, "+
								 " 0 as contractGapPercent, " +
								 " 0 as sowValue,"  +
								 " 0 as invoiceValue,  "+
								 " '$' as invoiceCurrencySign, " +
								 " '$' as currencySign, "+
								 " 0 as monthNo, 0 as cmsIdfrmCMS " +
								 " FROM " + LoadConstant.otc + ".[dbo].revenueProjection as rp " +
								 " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[project] p on p.itemId = rp.projectId " +
								 " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[accounts] pa on pa.itemId = p.accountId " +
					             " where rp.year = :year";
	
	
	public static final String
	Query_Resources_By_Bfirm_Bucket =   " FROM " + LoadConstant.infomaster + ".[dbo].resource r " +
							            " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[grade] g on g.gradeId = r.gradeId" +
							            " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[band] ba on ba.bandId = r.bandId" +
							            " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[skill] ps on ps.skillId = r.pSkillId" +
							            " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[skill] ss on ss.skillId = r.sSkillId" +
							            " LEFT JOIN " + LoadConstant.otc + ".[dbo].[allocation] a on r.uid = a.uid " + 
							            " LEFT JOIN " + LoadConstant.otc + ".[dbo].[sowDetail] sd on sd.sowDetailId = a.sowDetailId " + 
							            " LEFT JOIN " + LoadConstant.otc + ".[dbo].[sow] s on s.sowId = sd.sowId " + 
							            " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[project] p on p.itemId = s.projectId" + 
							            " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[city] city on city.cityId = r.currentLocationId" +
							            " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[empType] empType on empType.empTypeId = r.empTypeId" +
							            " WHERE p.billingTypeId != 4 and a.alcType = 1 " + 
							            " and a.alcStartDate <= getDate() and a.alcEndDate >= getDate() and r.disabled = 0";
	
	public static final String
	Query_Resources_By_Brisk_Bucket = 	" FROM " + LoadConstant.infomaster + ".[dbo].[resource] r " +
										" LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[grade] g on g.gradeId = r.gradeId" +
							            " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[band] ba on ba.bandId = r.bandId" +
							            " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[skill] ps on ps.skillId = r.pSkillId" +
							            " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[skill] ss on ss.skillId = r.sSkillId" +
										" LEFT JOIN " + LoadConstant.otc + ".[dbo].[allocation] a on r.uid = a.uid" + 
										" LEFT JOIN " + LoadConstant.otc + ".[dbo].[sowDetail] sd on sd.sowDetailId = a.sowDetailId" + 
										" LEFT JOIN " + LoadConstant.otc + ".[dbo].[sow] s on s.sowId = sd.sowId" + 
										" LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[project] p on p.itemId = s.projectId" + 
										" LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[city] city on city.cityId = r.currentLocationId" +
							            " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[empType] empType on empType.empTypeId = r.empTypeId" +
										" WHERE (s.documentTypeId != 1 OR s.documentTypeId is NULL) and a.alcType = 1" + 
										" and alcStartDate <= getDate() and a.alcEndDate >= getDate() and r.disabled = 0"+
										" and p.billingTypeId != 4";
								
	public static final String
	Query_Resources_By_NBbuffer_Bucket = " FROM " + LoadConstant.infomaster + ".[dbo].[resource] r " +
										" LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[grade] g on g.gradeId = r.gradeId" +
							            " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[band] ba on ba.bandId = r.bandId" +
							            " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[skill] ps on ps.skillId = r.pSkillId" +
							            " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[skill] ss on ss.skillId = r.sSkillId" +
							            " LEFT JOIN " + LoadConstant.otc + ".[dbo].[allocation] a on r.uid = a.uid" + 
					            		" LEFT JOIN " + LoadConstant.otc + ".[dbo].[sowDetail] sd on sd.sowDetailId = a.sowDetailId" + 
					            		" LEFT JOIN " + LoadConstant.otc + ".[dbo].[sow] s on s.sowId = sd.sowId" + 
					            		" LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[project] p on p.itemId = s.projectId" + 
					            		" LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[city] city on city.cityId = r.currentLocationId" +
							            " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[empType] empType on empType.empTypeId = r.empTypeId" +
					            		" WHERE a.alcType != 1 and p.billingTypeId != 4" + 
					            		" and alcStartDate <= getDate() and a.alcEndDate >= getDate() and r.disabled = 0";
	
	public static final String
	Query_Resources_By_NBpool_Bucket = 	" FROM " + LoadConstant.infomaster + ".[dbo].[resource] r " +
										" LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[grade] g on g.gradeId = r.gradeId" +
							            " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[band] ba on ba.bandId = r.bandId" +
							            " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[skill] ps on ps.skillId = r.pSkillId" +
							            " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[skill] ss on ss.skillId = r.sSkillId" +
							            " left join " + LoadConstant.otc + ".[dbo].[associatebucket] ab on ab.associateUid = r.uid" + 
					            		" left join " + LoadConstant.otc + ".[dbo].[bucket] b on b.bucketId = ab.bucketId" + 
					            		" LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[city] city on city.cityId = r.currentLocationId" +
							            " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[empType] empType on empType.empTypeId = r.empTypeId" +
					            		" WHERE r.disabled = 0 and b.bucketName NOT IN ('OH_Mgmt', 'OH_LongLeave', 'OH_Trainee', 'NB_Leave', 'NB_Resigned', 'NB_Internal', 'NB_COE', 'NB_CAT', 'NB_OTHER') and" + 
					            		" r.uid NOT IN (select a.uid from " + LoadConstant.otc + ".[dbo].[allocation] a where a.alcStartDate <= getDate() and a.alcEndDate >= getDate())";
	
	public static final String
	Query_Resources_By_Bucket_Name = 	" FROM " + LoadConstant.infomaster + ".[dbo].[resource] r " +
										" LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[grade] g on g.gradeId = r.gradeId" +
							            " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[band] ba on ba.bandId = r.bandId" +
							            " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[skill] ps on ps.skillId = r.pSkillId" +
							            " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[skill] ss on ss.skillId = r.sSkillId" +
							            " left join " + LoadConstant.otc + ".[dbo].[associatebucket] ab on ab.associateUid = r.uid" + 
					            		" left join " + LoadConstant.otc + ".[dbo].[bucket] b on b.bucketId = ab.bucketId" + 
					            		" LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[city] city on city.cityId = r.currentLocationId" +
							            " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[empType] empType on empType.empTypeId = r.empTypeId" +
					            		" WHERE r.disabled = 0 and ab.status = 1 and b.bucketName = :bucket ";
	
	}
