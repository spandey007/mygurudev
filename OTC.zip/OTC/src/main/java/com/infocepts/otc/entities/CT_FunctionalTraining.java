package com.infocepts.otc.entities;

import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.SqlResultSetMappings;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.infocepts.otc.utilities.LoadConstant;

@Entity
@Table(catalog=LoadConstant.otc, schema="[dbo]",name="ct_functionalTraining")

@SqlResultSetMappings({
    @SqlResultSetMapping(
            name = "functionalTraining_mapping",
            classes = {
                    @ConstructorResult(
                            targetClass = CT_FunctionalTraining.class,
                            columns = {
                            		@ColumnResult(name = "functionalTrainingId"),
                            		@ColumnResult(name = "proficiencyLevelId"),
                            		@ColumnResult(name = "functionalTraining", type = String.class),
                            		@ColumnResult(name = "competencyId"),
                            		@ColumnResult(name = "competencyName", type = String.class)
                            }
                    )
            }
    )
})
@NamedNativeQueries({
    @NamedNativeQuery(
            name    =   "getAllFunctionalTraining",   
            query 	=   "select bt.functionalTrainingId as functionalTrainingId,bt.proficiencyLevelId as proficiencyLevelId, " + 
            			" bt.functionalTraining as functionalTraining, bt.competencyId as competencyId, cl.competencyName as competencyName from " + LoadConstant.otc + ".[dbo].[ct_functionalTraining] bt " + 
            			" left join " + LoadConstant.otc + ".[dbo].[ct_competency] cl on cl.competencyId = bt.competencyId",
						 
						resultClass=CT_FunctionalTraining.class, resultSetMapping = "functionalTraining_mapping"
    )
})
public class CT_FunctionalTraining {

	// Entity Columns
    // --------------------------------------------------------------------------------
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Integer functionalTrainingId;
    private Integer proficiencyLevelId;
    
    @Lob
    private String functionalTraining;
    
    private Integer competencyId;
    
    @Transient
    private String competencyName;

	public Integer getFunctionalTrainingId() {
		return functionalTrainingId;
	}

	public void setFunctionalTrainingId(Integer functionalTrainingId) {
		this.functionalTrainingId = functionalTrainingId;
	}

	public Integer getProficiencyLevelId() {
		return proficiencyLevelId;
	}

	public void setProficiencyLevelId(Integer proficiencyLevelId) {
		this.proficiencyLevelId = proficiencyLevelId;
	}

	public String getFunctionalTraining() {
		return functionalTraining;
	}

	public void setFunctionalTraining(String functionalTraining) {
		this.functionalTraining = functionalTraining;
	}
	public Integer getCompetencyId() {
		return competencyId;
	}

	public void setCompetencyId(Integer competencyId) {
		this.competencyId = competencyId;
	}

	public String getCompetencyName() {
		return competencyName;
	}

	public void setCompetencyName(String competencyName) {
		this.competencyName = competencyName;
	}

	public CT_FunctionalTraining(Integer functionalTrainingId, Integer proficiencyLevelId, String functionalTraining,
			Integer competencyId, String competencyName) {
		//super();
		this.functionalTrainingId = functionalTrainingId;
		this.proficiencyLevelId = proficiencyLevelId;
		this.functionalTraining = functionalTraining;
		this.competencyId = competencyId;
		this.competencyName = competencyName;
	}

	public CT_FunctionalTraining() {
		//super();
		// TODO Auto-generated constructor stub
	}
    
	
	
	
    
}
