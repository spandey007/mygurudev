package com.infocepts.otc.entities;

import java.util.Date;

import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.SqlResultSetMappings;
import javax.persistence.Table;
import com.infocepts.otc.utilities.LoadConstant;

@Entity
@Table(catalog=LoadConstant.infomaster, schema="[dbo]",name="department")
@SqlResultSetMappings({
    @SqlResultSetMapping(
            name = "department_list",
            classes = {
                    @ConstructorResult(
                            targetClass = Department.class,
                            columns = {
                            		@ColumnResult(name = "departmentId"),
									@ColumnResult(name = "departmentName"), 
									@ColumnResult(name = "pid")
                            }
                    )
            }
    )
})
@NamedNativeQueries({   
    @NamedNativeQuery(
            name    =   "getParentDepartment",   
            query 	=    "Select d.departmentId, d.departmentName, d.pid"+					
						" from " + LoadConstant.infomaster + ".[dbo].department as d"+						
						" where d.hrmsId = d.pid and d.status = 1", 
						resultClass=Department.class, resultSetMapping = "department_list"
    ),
    @NamedNativeQuery(
            name    =   "getSubepartment",   
            query 	=    "Select d.departmentId, d.departmentName, d.pid"+					
						" from " + LoadConstant.infomaster + ".[dbo].department as d"+						
						" where d.pid=:pid " , 
						resultClass=Department.class, resultSetMapping = "department_list"
    )
})
public class Department {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer departmentId;
	private String departmentName;
	private Integer hrmsId;
	private boolean status;
	private Integer pid;
	
	private Integer createdBy;
	private Date createdDate;
	private Integer modifiedBy;
	private Date modifiedDate;
	
	//Getters and Setters
	public Integer getDepartmentId() {
		return departmentId;
	}
	public void setDepartmentId(Integer departmentId) {
		this.departmentId = departmentId;
	}
	public String getDepartmentName() {
		return departmentName;
	}
	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}
	public Integer getHrmsId() {
		return hrmsId;
	}
	public void setHrmsId(Integer hrmsId) {
		this.hrmsId = hrmsId;
	}
	public boolean isStatus() {
		return status;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}
	public Integer getPid() {
		return pid;
	}
	public void setPid(Integer pid) {
		this.pid = pid;
	}
	public Integer getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public Integer getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public Date getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public Department() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Department(Integer departmentId, String departmentName, Integer pid) {
		
		this.departmentId = departmentId;
		this.departmentName = departmentName;
		this.pid = pid;
		
	}
	
	//End of: Getters and Setters
}
	