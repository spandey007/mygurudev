package com.infocepts.otc.controllers;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.infocepts.otc.entities.CT_GradeWiseMapping;
import com.infocepts.otc.entities.CT_TechnologyMapping;
import com.infocepts.otc.repositories.CT_GradeWiseMappingRepository;
import com.infocepts.otc.services.TimesheetService;

@RestController
@RequestMapping(value="/cT_GradeWiseMapping",headers="referer")
public class CT_GradeWiseMappingController {
	@Autowired
	CT_GradeWiseMappingRepository ct_GradeWiseMappingRepository;
	
	@Autowired
	TimesheetService service;
	
	@Autowired
	HttpSession session;

	@PersistenceContext(unitName = "otc")
	private EntityManager manager;
	
	final Logger logger = Logger.getLogger(CT_GradeWiseMappingController.class.getName());
	
	@RequestMapping(method=RequestMethod.POST)
	public CT_GradeWiseMapping addCT_GradeWiseMapping(@RequestBody CT_GradeWiseMapping cT_GradeWiseMapping){
		cT_GradeWiseMapping.setGradeWiseMappingId(null);
		Boolean isAValidCall = false;
		if(service.isHR() || service.isAdmin())
		{
			isAValidCall = true;
		}
		if(isAValidCall) {
			
			ct_GradeWiseMappingRepository.save(cT_GradeWiseMapping);
		}
		return cT_GradeWiseMapping;
	}
	
	@RequestMapping(method=RequestMethod.GET)
	public List<CT_GradeWiseMapping> getCT_GradeWiseMapping(@RequestParam(value = "gradeId", defaultValue = "0") Integer gradeId
			,@RequestParam(value = "isBehCom", defaultValue = "false") Boolean isBehCom
			,@RequestParam(value = "isFunCom", defaultValue = "false") Boolean isFunCom
			,@RequestParam(value = "roleId", defaultValue = "0") Integer roleId
			,@RequestParam(value = "departmentId", defaultValue = "0") Integer departmentId){
		List<CT_GradeWiseMapping> list = null;
		logger.info("isFunCom"+isFunCom);
		logger.info("isBehCom"+isBehCom);
		logger.info("gradeId"+gradeId);
		logger.info("departmentId"+departmentId);
		if(gradeId != 0 && roleId != 0){ // list for normal user
			System.out.println("inside grade role list");
			list = manager.createNamedQuery("getAllMappingsByGradeAndRole",CT_GradeWiseMapping.class)					
					.setParameter("gradeId", gradeId)
					.setParameter("roleId", roleId)
					.getResultList();
		}
		else if(isBehCom == true && gradeId != 0 && roleId == 0){ // list for normal user
			System.out.println("inside getBehavioralCompetency list");
			list = manager.createNamedQuery("getBehavioralCompetency",CT_GradeWiseMapping.class)
					.setParameter("gradeId", gradeId)
					.getResultList();
		}
		else if(isFunCom == true && gradeId != 0 && roleId == 0){ // list for normal user
			System.out.println("inside getFunctionalCompetency list");
			list = manager.createNamedQuery("getFunctionalCompetency",CT_GradeWiseMapping.class)
					.setParameter("gradeId", gradeId)
					.setParameter("departmentId", departmentId)
					.getResultList();
		}
		else 
		{
			System.out.println("inside tech mapping list");
			list = manager.createNamedQuery("getAllMappings",CT_GradeWiseMapping.class)
					.getResultList();
		}
		return list;
	}
	
	@RequestMapping(value="/{gradeWiseMappingId}",method=RequestMethod.GET)
	public CT_GradeWiseMapping getCT_GradeWiseMapping(@PathVariable Integer gradeWiseMappingId){
		CT_GradeWiseMapping cT_GradeWiseMapping = null;
		Boolean isAValidCall = false;
		if(service.isHR() || service.isAdmin())
		{
			isAValidCall = true;
		}
		if(isAValidCall) {
			
			cT_GradeWiseMapping = ct_GradeWiseMappingRepository.findOne(gradeWiseMappingId);
		}
		return cT_GradeWiseMapping;
	}
	
	@RequestMapping(value="/{gradeWiseMappingId}", method=RequestMethod.PUT)
	public CT_GradeWiseMapping updateCT_GradeWiseMapping(@PathVariable Integer gradeWiseMappingId,  @RequestBody CT_GradeWiseMapping updatedCT_GradeWiseMapping){
		updatedCT_GradeWiseMapping.setGradeWiseMappingId(gradeWiseMappingId);
		Boolean isAValidCall = false;
		if(service.isHR() || service.isAdmin())
		{
			isAValidCall = true;
		}
		if(isAValidCall) {
		ct_GradeWiseMappingRepository.save(updatedCT_GradeWiseMapping);
		}
		return updatedCT_GradeWiseMapping;
	}
	
	@RequestMapping(value="/{gradeWiseMappingId}",method=RequestMethod.DELETE)
	public void deleteCT_GradeWiseMapping(@PathVariable Integer gradeWiseMappingId){
		Boolean isAValidCall = false;
		if(service.isHR() || service.isAdmin())
		{
			isAValidCall = true;
		}
		if(isAValidCall) {
		ct_GradeWiseMappingRepository.delete(gradeWiseMappingId);
		}
	}
}

