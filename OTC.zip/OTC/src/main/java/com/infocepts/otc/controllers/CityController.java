package com.infocepts.otc.controllers;

import java.util.List;

import javax.mail.MessagingException;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.infocepts.otc.entities.City;
import com.infocepts.otc.notification.SmtpMailSender;
import com.infocepts.otc.repositories.CityRepository;
import com.infocepts.otc.services.TimesheetService;

@RestController
@RequestMapping(value="/city",headers="referer")
public class CityController {

	@Autowired
	CityRepository repository;
	
	@Autowired
	TimesheetService service;
	
	@Autowired
	SmtpMailSender smtpMailSender;
	
	
	final Logger logger = Logger.getLogger(CityController.class);
	
	
	@RequestMapping(method=RequestMethod.POST)
	public City addCity(@RequestBody City city, HttpServletRequest request) throws MessagingException{
		try{
			city.setCityId(null);
			repository.save(city);	
			service.sendCityNotification(city, "add", request); 

		}catch(Exception e){
			logger.error(e);
		}
		return city;
	}	
 
	 @RequestMapping(method=RequestMethod.GET)
	 public List<City> getAllCity(@RequestParam(value = "allItem", defaultValue = "0") Integer allItem){
		 List<City> citylist=null;
		 try{
			 
			 if(allItem == 1)
			 {
				 citylist = repository.findAll();
			 }
			 else{
				 citylist = repository.findAllActive();
			 }
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return citylist;
	 }
	 
	 @RequestMapping(value="/{cityId}",method=RequestMethod.GET)
	 public City getCityById(@PathVariable Integer cityId){
		 City city=null;
		 try{
			 city = repository.findOne(cityId);
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return city;
	 }
	
	 
	 
	 @RequestMapping(value="/{cityId}",method=RequestMethod.PUT)
	 public City updateCity(@RequestBody City updatedCity,@PathVariable Integer cityId){
		 try{
			 updatedCity.setCityId(cityId);
			 repository.save(updatedCity);
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return updatedCity;
	 }
	 
	 @RequestMapping(value="/{cityId}",method=RequestMethod.DELETE)
	 public void deleteCity(@PathVariable Integer cityId){
		 try{
			 repository.delete(cityId);
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
	 }	 
	
}
