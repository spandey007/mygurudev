package com.infocepts.otc.controllers;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.infocepts.otc.entities.PermissionsUrls;
import com.infocepts.otc.repositories.PermissionsUrlsRepository;
import com.infocepts.otc.services.TimesheetService;

@RestController
@RequestMapping(value="/permissionsurls",headers="referer")//JV: Added 'headers' param to validate the url.
public class PermissionsUrlsController {
	
	final Logger logger = Logger.getLogger(PermissionsUrlsController.class);

	@Autowired
	PermissionsUrlsRepository repository;
	
	@Autowired
	HttpSession session;
	
	@Autowired
	TimesheetService service;
	
	@RequestMapping(method=RequestMethod.GET)
	public List<PermissionsUrls> findPermissionsUrls(@RequestParam(value = "status", defaultValue = "all") String status,
													HttpServletRequest request){
		List<PermissionsUrls> permissionsurlslist=null;
		try{
			/* ------------------------- Authorization start ------------------------------------ */
			// Authorization for admin role
			if(!service.isAdmin())
			{
				service.sendTamperedMail("Permissions Urls View All", 0, 0, request);	
				return permissionsurlslist;
			}
			/* ------------------------- Authorization ends ------------------------------------ */
			if(status.equals("active"))
			{
				permissionsurlslist = repository.findActivePermissionsUrls();
			}
			else
			{
				permissionsurlslist = repository.findAll();
			}
		}
		catch(Exception e){
			logger.error(e);
		}
		return permissionsurlslist;
	}
	
	@RequestMapping(method=RequestMethod.POST)
	public PermissionsUrls addPermissionsUrls(@RequestBody PermissionsUrls permissions,
												HttpServletRequest request){
		 try{
			 /* ------------------------- Authorization start ------------------------------------ */
			// Authorization for admin role
			if(service.isAdmin())
			{
				 repository.save(permissions);
			}
			else
			{
				service.sendTamperedMail("Permissions Urls View All", 0, 0, request);
			}
			/* ------------------------- Authorization ends ------------------------------------ */			
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		return permissions;
	}
	 
	@RequestMapping(value="/{permissionsUrlsId}",method=RequestMethod.PUT)
	public PermissionsUrls updatePermissionsUrlsById(@PathVariable Integer permissionsUrlsId,@RequestBody PermissionsUrls updatedPermissions,
													HttpServletRequest request){
		try{
			/* ------------------------- Authorization start ------------------------------------ */
			// Authorization for admin role
			if(service.isAdmin())
			{
				updatedPermissions.setPermissionsUrlsId(permissionsUrlsId);
				repository.save(updatedPermissions);
			}
			else
			{
				service.sendTamperedMail("Permissions Urls View All", 0, 0, request);
			}
			/* ------------------------- Authorization ends ------------------------------------ */			
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		return updatedPermissions;
		
	}

}
