package com.infocepts.otc.entities;

import java.util.Date;

import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.infocepts.otc.utilities.LoadConstant;

@SqlResultSetMapping(
		name = "info_cab_details",
	      classes = {
	          @ConstructorResult(
	              targetClass = InfoCab.class,
	              columns = {
	            	//normal cols
	                  @ColumnResult(name = "infoCabId"),
	                  @ColumnResult(name = "uid"),
	                  @ColumnResult(name = "pickupPoint", type=String.class),
	                  @ColumnResult(name = "dropPoint", type=String.class),
	                  @ColumnResult(name = "projectId"),
	                  @ColumnResult(name = "dateCab", type=Date.class),
	                  @ColumnResult(name = "timeCab", type=String.class),
	                  @ColumnResult(name = "remarks", type=String.class),
	                  @ColumnResult(name = "pmApprovalStatus", type=String.class), 
	                  @ColumnResult(name = "pmApprovalDate", type=Date.class),
	                  @ColumnResult(name = "pmApprovalComment", type=String.class),
	                  @ColumnResult(name = "bookingStatus", type=String.class), 
	                  @ColumnResult(name = "vehicleNumber", type=String.class),
	                  @ColumnResult(name = "driverName", type=String.class),
	                  @ColumnResult(name = "driverContactNumber", type=String.class),
	                  @ColumnResult(name = "bookingComments", type=String.class),
	                  @ColumnResult(name = "cancelRequest", type=Boolean.class),
	                  @ColumnResult(name = "cancelComments", type=String.class),
	                  @ColumnResult(name = "chargeableComments", type=String.class),
	                  @ColumnResult(name = "userMobile", type=String.class),
	                  
	                  
	                  @ColumnResult(name = "submissionStatus"),
	                  @ColumnResult(name = "approverId"),
	                  @ColumnResult(name = "infoCabDriverId"),
	                  @ColumnResult(name = "infoCabVehicleId"),
	          		
	                  @ColumnResult(name = "travelWay", type=String.class),
	                  @ColumnResult(name = "billingType", type=String.class),
	                  
	                  @ColumnResult(name = "startKm"),
	                  @ColumnResult(name = "endKm"),
	                  @ColumnResult(name = "dieselLtr"),
	                  @ColumnResult(name = "dieselRate"),
	                  @ColumnResult(name = "orderNo"),
	                  @ColumnResult(name = "parking"),
	                  @ColumnResult(name = "referenceNo", type=String.class),
	                  
	                  
	                  @ColumnResult(name = "createdBy"),
	                  @ColumnResult(name = "createdDate", type=Date.class),
	                  @ColumnResult(name = "modifiedBy"),
	                  @ColumnResult(name = "modifiedDate", type=Date.class),
//	                		//transient-----------
	    	          @ColumnResult(name = "empId"),
	    	          @ColumnResult(name = "title", type=String.class),
	    	          @ColumnResult(name = "permTelephoneNo", type=String.class),
	    	          @ColumnResult(name = "tempMobNo", type=String.class),
	    	          @ColumnResult(name = "email", type=String.class),
	    	          @ColumnResult(name = "permStreet1", type=String.class),
	    	          @ColumnResult(name = "permStreet2", type=String.class),
	    	          @ColumnResult(name = "departmentId"),
	    	          @ColumnResult(name = "projectManagerName", type=String.class),
	    	          @ColumnResult(name = "cityName", type=String.class),	             	
	    	          @ColumnResult(name = "departmentName", type=String.class),
	                  @ColumnResult(name = "projectName", type=String.class),
	                  @ColumnResult(name = "resourceName", type=String.class),
	                  @ColumnResult(name = "approverName", type=String.class),
	                  @ColumnResult(name = "createdName", type=String.class)
	                 
	                  }
	          )
	      }
	)
@NamedNativeQueries({
	   @NamedNativeQuery(
	            name    =   "getInfoCab_by_Uid",
	            query   =   " SELECT ic.infoCabId as infoCabId, ic.uid as uid, ic.pickupPoint as pickupPoint, " + 
	            		"  ic.dropPoint as dropPoint, ic.dateCab as dateCab, ic.projectId as projectId, " + 
	            		"  ic.timeCab as timeCab, ic.remarks as remarks, ic.pmApprovalStatus as pmApprovalStatus, " + 
	            		"  ic.pmApprovalDate as pmApprovalDate, ic.pmApprovalComment as pmApprovalComment, ic.bookingStatus as bookingStatus, " + 
	            		"  ic.vehicleNumber as vehicleNumber, ic.driverName as driverName, ic.driverContactNumber as driverContactNumber, " + 
	            		"  ic.bookingComments as bookingComments, ic.cancelRequest as cancelRequest, ic.cancelComments as cancelComments, ic.chargeableComments as chargeableComments, ic.userMobile as userMobile, ic.submissionStatus as submissionStatus, ic.approverId as approverId, ic.infoCabDriverId as infoCabDriverId, ic.infoCabVehicleId as infoCabVehicleId, ic.travelWay as travelWay, ic.billingType as billingType, ic.startKm as startKm, ic.endKm as endKm, ic.dieselLtr as dieselLtr, ic.dieselRate as dieselRate, ic.orderNo as orderNo, ic.parking as parking, ic.referenceNo as referenceNo, ic.createdBy as createdBy, ic.createdDate as createdDate, ic.modifiedBy as modifiedBy, " + 
	            		"  ic.modifiedDate as modifiedDate,  r.empId as empId, r.title as title, r.permTelephoneNo as permTelephoneNo, " + 
	            		"  r.tempMobNo as tempMobNo, r.email as email, r.permStreet1 as permStreet1,r.permStreet2 as permStreet2, " + 
	            		"  r.departmentId as departmentId ,rr.title as projectManagerName,c.cityName as cityName, d.departmentName as departmentName, p.title as projectName, r.title as resourceName, ra.title as approverName, rc.title as createdName FROM " + LoadConstant.otc + ".[dbo].[infoCab] ic " + 
	            		"  left join " + LoadConstant.infomaster + ".[dbo].[resource] r on r.uid=ic.uid " +
	            		"  left join " + LoadConstant.infomaster + ".[dbo].[resource] ra on ra.uid=ic.approverId " +
	            		"  left join " + LoadConstant.infomaster + ".[dbo].[resource] rc on rc.uid=ic.createdBy " +
	            		"  left join " + LoadConstant.infomaster + " .[dbo].[project] p on p.itemId = ic.projectId "+
	            		"  left join " + LoadConstant.infomaster + ".[dbo].[resource] rr on rr.uid=p.projectManagersId " + 
	            		"  left join " + LoadConstant.infomaster + ".[dbo].[department] d on d.departmentId = r.departmentId "+
	            		"  left join " + LoadConstant.infomaster + ".[dbo].[city] c on c.cityId=r.cityId "+
	            		" where ic.uid = :uid order by ic.infoCabId",
	                       resultClass=InfoCab.class, resultSetMapping = "info_cab_details"                       		
	    ),
	   @NamedNativeQuery (
			   name    =   "getInfoCab_by_All",
	            query   =   " SELECT ic.infoCabId as infoCabId, ic.uid as uid, ic.pickupPoint as pickupPoint, " + 
	            		"  ic.dropPoint as dropPoint, ic.dateCab as dateCab, ic.projectId as projectId, " + 
	            		"  ic.timeCab as timeCab, ic.remarks as remarks, ic.pmApprovalStatus as pmApprovalStatus, " + 
	            		"  ic.pmApprovalDate as pmApprovalDate, ic.pmApprovalComment as pmApprovalComment, ic.bookingStatus as bookingStatus, " + 
	            		"  ic.vehicleNumber as vehicleNumber, ic.driverName as driverName, ic.driverContactNumber as driverContactNumber, " + 
	            		"  ic.bookingComments as bookingComments, ic.cancelRequest as cancelRequest, ic.cancelComments as cancelComments, ic.chargeableComments as chargeableComments, ic.userMobile as userMobile, ic.submissionStatus as submissionStatus, ic.approverId as approverId, ic.infoCabDriverId as infoCabDriverId, ic.infoCabVehicleId as infoCabVehicleId, ic.travelWay as travelWay, ic.billingType as billingType, ic.startKm as startKm, ic.endKm as endKm, ic.dieselLtr as dieselLtr, ic.dieselRate as dieselRate, ic.orderNo as orderNo, ic.parking as parking, ic.referenceNo as referenceNo, ic.createdBy as createdBy, ic.createdDate as createdDate, ic.modifiedBy as modifiedBy, " + 
	            		"  ic.modifiedDate as modifiedDate,  r.empId as empId, r.title as title, r.permTelephoneNo as permTelephoneNo, " + 
	            		"  r.tempMobNo as tempMobNo, r.email as email, r.permStreet1 as permStreet1,r.permStreet2 as permStreet2, " + 
	            		"  r.departmentId as departmentId ,rr.title as projectManagerName,c.cityName as cityName, d.departmentName as departmentName, p.title as projectName, r.title as resourceName, ra.title as approverName, rc.title as createdName FROM " + LoadConstant.otc + ".[dbo].[infoCab] ic " + 
	            		"  left join " + LoadConstant.infomaster + ".[dbo].[resource] r on r.uid=ic.uid " + 
	            		"  left join " + LoadConstant.infomaster + ".[dbo].[resource] ra on ra.uid=ic.approverId " +
	            		"  left join " + LoadConstant.infomaster + ".[dbo].[resource] rc on rc.uid=ic.createdBy " +
	            		"  left join " + LoadConstant.infomaster + " .[dbo].[project] p on p.itemId = ic.projectId "+
	            		"  left join " + LoadConstant.infomaster + ".[dbo].[resource] rr on rr.uid=p.projectManagersId " + 
	            		"  left join " + LoadConstant.infomaster + ".[dbo].[department] d on d.departmentId = r.departmentId "+
	            		"  left join " + LoadConstant.infomaster + ".[dbo].[city] c on c.cityId=r.cityId ",
	                       resultClass=InfoCab.class, resultSetMapping = "info_cab_details"
	   ),
	   @NamedNativeQuery (
			   name    =   "getInfoCab_by_submissionStatus",
	            query   =   " SELECT ic.infoCabId as infoCabId, ic.uid as uid, ic.pickupPoint as pickupPoint, " + 
	            		"  ic.dropPoint as dropPoint, ic.dateCab as dateCab, ic.projectId as projectId, " + 
	            		"  ic.timeCab as timeCab, ic.remarks as remarks, ic.pmApprovalStatus as pmApprovalStatus, " + 
	            		"  ic.pmApprovalDate as pmApprovalDate, ic.pmApprovalComment as pmApprovalComment, ic.bookingStatus as bookingStatus, " + 
	            		"  ic.vehicleNumber as vehicleNumber, ic.driverName as driverName, ic.driverContactNumber as driverContactNumber, " + 
	            		"  ic.bookingComments as bookingComments, ic.cancelRequest as cancelRequest, ic.cancelComments as cancelComments , ic.chargeableComments as chargeableComments, ic.userMobile as userMobile, ic.submissionStatus as submissionStatus, ic.approverId as approverId, ic.infoCabDriverId as infoCabDriverId, ic.infoCabVehicleId as infoCabVehicleId, ic.travelWay as travelWay, ic.billingType as billingType, ic.startKm as startKm, ic.endKm as endKm, ic.dieselLtr as dieselLtr, ic.dieselRate as dieselRate, ic.orderNo as orderNo, ic.parking as parking, ic.referenceNo as referenceNo, ic.createdBy as createdBy, ic.createdDate as createdDate, ic.modifiedBy as modifiedBy, " + 
	            		"  ic.modifiedDate as modifiedDate,  r.empId as empId, r.title as title, r.permTelephoneNo as permTelephoneNo, " + 
	            		"  r.tempMobNo as tempMobNo, r.email as email, r.permStreet1 as permStreet1,r.permStreet2 as permStreet2, " + 
	            		"  r.departmentId as departmentId ,rr.title as projectManagerName,c.cityName as cityName, d.departmentName as departmentName, p.title as projectName, r.title as resourceName, ra.title as approverName, rc.title as createdName FROM " + LoadConstant.otc + ".[dbo].[infoCab] ic " + 
	            		"  left join " + LoadConstant.infomaster + ".[dbo].[resource] r on r.uid=ic.uid " + 
	            		"  left join " + LoadConstant.infomaster + ".[dbo].[resource] ra on ra.uid=ic.approverId " +
	            		"  left join " + LoadConstant.infomaster + ".[dbo].[resource] rc on rc.uid=ic.createdBy " +
	            		"  left join " + LoadConstant.infomaster + " .[dbo].[project] p on p.itemId = ic.projectId "+
	            		"  left join " + LoadConstant.infomaster + ".[dbo].[resource] rr on rr.uid=p.projectManagersId " + 
	            		"  left join " + LoadConstant.infomaster + ".[dbo].[department] d on d.departmentId = r.departmentId "+
	            		"  left join " + LoadConstant.infomaster + ".[dbo].[city] c on c.cityId=r.cityId "+
	            		" where ic.submissionStatus = 1",
	                       resultClass=InfoCab.class, resultSetMapping = "info_cab_details"
	   ),
	   @NamedNativeQuery (
			   name    =   "getInfoCab_by_By_Id",
	            query   =   " SELECT ic.infoCabId as infoCabId, ic.uid as uid, ic.pickupPoint as pickupPoint, " + 
	            		"  ic.dropPoint as dropPoint, ic.dateCab as dateCab, ic.projectId as projectId, " + 
	            		"  ic.timeCab as timeCab, ic.remarks as remarks, ic.pmApprovalStatus as pmApprovalStatus, " + 
	            		"  ic.pmApprovalDate as pmApprovalDate, ic.pmApprovalComment as pmApprovalComment, ic.bookingStatus as bookingStatus, " + 
	            		"  ic.vehicleNumber as vehicleNumber, ic.driverName as driverName, ic.driverContactNumber as driverContactNumber, " + 
	            		"  ic.bookingComments as bookingComments, ic.cancelRequest as cancelRequest, ic.cancelComments as cancelComments ,ic.chargeableComments as chargeableComments, ic.userMobile as userMobile, ic.submissionStatus as submissionStatus, ic.approverId as approverId, ic.infoCabDriverId as infoCabDriverId, ic.infoCabVehicleId as infoCabVehicleId, ic.travelWay as travelWay, ic.billingType as billingType, ic.startKm as startKm, ic.endKm as endKm, ic.dieselLtr as dieselLtr, ic.dieselRate as dieselRate, ic.orderNo as orderNo, ic.parking as parking, ic.referenceNo as referenceNo, ic.createdBy as createdBy, ic.createdDate as createdDate, ic.modifiedBy as modifiedBy, " + 
	            		"  ic.modifiedDate as modifiedDate,  r.empId as empId, r.title as title, r.permTelephoneNo as permTelephoneNo, " + 
	            		"  r.tempMobNo as tempMobNo, r.email as email, r.permStreet1 as permStreet1,r.permStreet2 as permStreet2, " + 
	            		"  r.departmentId as departmentId ,rr.title as projectManagerName,c.cityName as cityName, d.departmentName as departmentName, p.title as projectName, r.title as resourceName, ra.title as approverName, rc.title as createdName FROM " + LoadConstant.otc + ".[dbo].[infoCab] ic " + 
	            		"  left join " + LoadConstant.infomaster + ".[dbo].[resource] r on r.uid=ic.uid " + 
	            		"  left join " + LoadConstant.infomaster + ".[dbo].[resource] ra on ra.uid=ic.approverId " +
	            		"  left join " + LoadConstant.infomaster + ".[dbo].[resource] rc on rc.uid=ic.createdBy " +
	            		"  left join " + LoadConstant.infomaster + " .[dbo].[project] p on p.itemId = ic.projectId "+
	            		"  left join " + LoadConstant.infomaster + ".[dbo].[resource] rr on rr.uid=p.projectManagersId " + 
	            		"  left join " + LoadConstant.infomaster + ".[dbo].[department] d on d.departmentId = r.departmentId "+
	            		"  left join " + LoadConstant.infomaster + ".[dbo].[city] c on c.cityId=r.cityId "+
	            		" where ic.infoCabId = :infoCabId",
	                       resultClass=InfoCab.class, resultSetMapping = "info_cab_details"
	   ),
	   @NamedNativeQuery (
			   name    =   "getApprovalList_by_UId",
	            query   =   " SELECT ic.infoCabId as infoCabId, ic.uid as uid, ic.pickupPoint as pickupPoint, " + 
	            		"  ic.dropPoint as dropPoint, ic.dateCab as dateCab, ic.projectId as projectId, " + 
	            		"  ic.timeCab as timeCab, ic.remarks as remarks, ic.pmApprovalStatus as pmApprovalStatus, " + 
	            		"  ic.pmApprovalDate as pmApprovalDate, ic.pmApprovalComment as pmApprovalComment, ic.bookingStatus as bookingStatus, " + 
	            		"  ic.vehicleNumber as vehicleNumber, ic.driverName as driverName, ic.driverContactNumber as driverContactNumber, " + 
	            		"  ic.bookingComments as bookingComments, ic.cancelRequest as cancelRequest, ic.cancelComments as cancelComments ,ic.chargeableComments as chargeableComments, ic.userMobile as userMobile, ic.submissionStatus as submissionStatus, ic.approverId as approverId, ic.infoCabDriverId as infoCabDriverId, ic.infoCabVehicleId as infoCabVehicleId, ic.travelWay as travelWay, ic.billingType as billingType, ic.startKm as startKm, ic.endKm as endKm, ic.dieselLtr as dieselLtr, ic.dieselRate as dieselRate, ic.orderNo as orderNo, ic.parking as parking, ic.referenceNo as referenceNo, ic.createdBy as createdBy, ic.createdDate as createdDate, ic.modifiedBy as modifiedBy, " + 
	            		"  ic.modifiedDate as modifiedDate,  r.empId as empId, r.title as title, r.permTelephoneNo as permTelephoneNo, " + 
	            		"  r.tempMobNo as tempMobNo, r.email as email, r.permStreet1 as permStreet1,r.permStreet2 as permStreet2, " + 
	            		"  r.departmentId as departmentId ,rr.title as projectManagerName,c.cityName as cityName, d.departmentName as departmentName, p.title as projectName, r.title as resourceName, ra.title as approverName, rc.title as createdName FROM " + LoadConstant.otc + ".[dbo].[infoCab] ic " + 
	            		"  left join " + LoadConstant.infomaster + ".[dbo].[resource] r on r.uid=ic.uid " + 
	            		"  left join " + LoadConstant.infomaster + ".[dbo].[resource] ra on ra.uid=ic.approverId " +
	            		"  left join " + LoadConstant.infomaster + ".[dbo].[resource] rc on rc.uid=ic.createdBy " +
	            		"  left join " + LoadConstant.infomaster + " .[dbo].[project] p on p.itemId = ic.projectId "+
	            		"  left join " + LoadConstant.infomaster + ".[dbo].[resource] rr on rr.uid=p.projectManagersId " + 
	            		"  left join " + LoadConstant.infomaster + ".[dbo].[department] d on d.departmentId = r.departmentId "+
	            		"  left join " + LoadConstant.infomaster + ".[dbo].[city] c on c.cityId=r.cityId "+
	            		" where ic.approverId = :uid and ic.submissionStatus >= 3 and ic.cancelRequest is null",
	                       resultClass=InfoCab.class, resultSetMapping = "info_cab_details"
	   ),
	   @NamedNativeQuery (
			   name    =   "getApprovedList",
	            query   =   " SELECT ic.infoCabId as infoCabId, ic.uid as uid, ic.pickupPoint as pickupPoint, " + 
	            		"  ic.dropPoint as dropPoint, ic.dateCab as dateCab, ic.projectId as projectId, " + 
	            		"  ic.timeCab as timeCab, ic.remarks as remarks, ic.pmApprovalStatus as pmApprovalStatus, " + 
	            		"  ic.pmApprovalDate as pmApprovalDate, ic.pmApprovalComment as pmApprovalComment, ic.bookingStatus as bookingStatus, " + 
	            		"  ic.vehicleNumber as vehicleNumber, ic.driverName as driverName, ic.driverContactNumber as driverContactNumber, " + 
	            		"  ic.bookingComments as bookingComments, ic.cancelRequest as cancelRequest, ic.cancelComments as cancelComments , ic.chargeableComments as chargeableComments,ic.userMobile as userMobile, ic.submissionStatus as submissionStatus, ic.approverId as approverId, ic.infoCabDriverId as infoCabDriverId, ic.infoCabVehicleId as infoCabVehicleId, ic.travelWay as travelWay, ic.billingType as billingType, ic.startKm as startKm, ic.endKm as endKm, ic.dieselLtr as dieselLtr, ic.dieselRate as dieselRate, ic.orderNo as orderNo, ic.parking as parking, ic.referenceNo as referenceNo, ic.createdBy as createdBy, ic.createdDate as createdDate, ic.modifiedBy as modifiedBy, " + 
	            		"  ic.modifiedDate as modifiedDate,  r.empId as empId, r.title as title, r.permTelephoneNo as permTelephoneNo, " + 
	            		"  r.tempMobNo as tempMobNo, r.email as email, r.permStreet1 as permStreet1,r.permStreet2 as permStreet2, " + 
	            		"  r.departmentId as departmentId ,rr.title as projectManagerName,c.cityName as cityName, d.departmentName as departmentName, p.title as projectName, r.title as resourceName, ra.title as approverName, rc.title as createdName FROM " + LoadConstant.otc + ".[dbo].[infoCab] ic " + 
	            		"  left join " + LoadConstant.infomaster + ".[dbo].[resource] r on r.uid=ic.uid " + 
	            		"  left join " + LoadConstant.infomaster + ".[dbo].[resource] ra on ra.uid=ic.approverId " +
	            		"  left join " + LoadConstant.infomaster + ".[dbo].[resource] rc on rc.uid=ic.createdBy " +
	            		"  left join " + LoadConstant.infomaster + " .[dbo].[project] p on p.itemId = ic.projectId "+
	            		"  left join " + LoadConstant.infomaster + ".[dbo].[resource] rr on rr.uid=p.projectManagersId " + 
	            		"  left join " + LoadConstant.infomaster + ".[dbo].[department] d on d.departmentId = r.departmentId "+
	            		"  left join " + LoadConstant.infomaster + ".[dbo].[city] c on c.cityId=r.cityId "+
	            		" where ic.pmApprovalStatus='Approved' and ic.submissionStatus =4",
	                       resultClass=InfoCab.class, resultSetMapping = "info_cab_details"
	   )
	   
})


@Entity
@Table(catalog=LoadConstant.otc, schema="[dbo]", name="infoCab")

public class InfoCab {

	// Entity Columns
    // --------------------------------------------------------------------------------
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Integer infoCabId;
    private Integer uid;
    private String pickupPoint;
    private String dropPoint;
    private Integer projectId;
    private Date dateCab;
    private String timeCab;
    private String remarks;
    private String pmApprovalStatus; 
    private Date pmApprovalDate;
    private String pmApprovalComment;
    private String bookingStatus; 
    private String vehicleNumber;
    private String driverName;
    private String driverContactNumber;
    private String bookingComments;
    private Boolean cancelRequest;
    private String cancelComments;
    private String chargeableComments;
    private String userMobile;
    
    //new work flow
    private Integer submissionStatus;
    private Integer approverId;
    private Integer infoCabDriverId;
    private Integer infoCabVehicleId;
    private String travelWay;
    private String billingType;
    
    
    //for traveldesk workflow
    private Integer startKm;
    private Integer endKm;
    private Integer dieselLtr;
    private Integer dieselRate;
    private Integer orderNo;
    private Integer parking;
    private String referenceNo;

    
    private Integer createdBy;
	private Date createdDate;
	private Integer modifiedBy;
	private Date modifiedDate;
    
//	 // Transient Variables
//    // --------------------------------------------------------------------------------
    @Transient
	private Integer empId;
	
	@Transient
	private String title;
	
	@Transient
	private String permTelephoneNo;
	
	@Transient
	private String tempMobNo;
	
	@Transient
	private String email;
	
	@Transient
	private String permStreet1;
	
	@Transient
	private String permStreet2;
	
	@Transient
	private Integer departmentId;
	
	@Transient
	private String projectManagerName;
	
	@Transient
	private String cityName;
	
	@Transient
	private String departmentName;
	
	@Transient
	private String projectName;
	
	@Transient
	private String resourceName;
	
	@Transient
	private String approverName;
	
	@Transient
	private String createdName;
	
	
	
	// Getter setter
	// --------------------------------------------------------------------------------
	//Press Alt+Shift+S => Generate Getter and Setters..

	public Integer getInfoCabId() {
		return infoCabId;
	}

	public void setInfoCabId(Integer infoCabId) {
		this.infoCabId = infoCabId;
	}

	public Integer getUid() {
		return uid;
	}

	public void setUid(Integer uid) {
		this.uid = uid;
	}

	public String getPickupPoint() {
		return pickupPoint;
	}

	public void setPickupPoint(String pickupPoint) {
		this.pickupPoint = pickupPoint;
	}

	public String getDropPoint() {
		return dropPoint;
	}

	public void setDropPoint(String dropPoint) {
		this.dropPoint = dropPoint;
	}
	

	public Integer getProjectId() {
		return projectId;
	}

	public void setProjectId(Integer projectId) {
		this.projectId = projectId;
	}

	public Date getDateCab() {
		return dateCab;
	}

	public void setDateCab(Date dateCab) {
		this.dateCab = dateCab;
	}

	public String getTimeCab() {
		return timeCab;
	}

	public void setTimeCab(String timeCab) {
		this.timeCab = timeCab;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	
	public String getPmApprovalStatus() {
		return pmApprovalStatus;
	}

	public void setPmApprovalStatus(String pmApprovalStatus) {
		this.pmApprovalStatus = pmApprovalStatus;
	}

	public Date getPmApprovalDate() {
		return pmApprovalDate;
	}

	public void setPmApprovalDate(Date pmApprovalDate) {
		this.pmApprovalDate = pmApprovalDate;
	}

	public String getPmApprovalComment() {
		return pmApprovalComment;
	}

	public void setPmApprovalComment(String pmApprovalComment) {
		this.pmApprovalComment = pmApprovalComment;
	}

	
	public String getBookingStatus() {
		return bookingStatus;
	}

	public void setBookingStatus(String bookingStatus) {
		this.bookingStatus = bookingStatus;
	}

	public String getVehicleNumber() {
		return vehicleNumber;
	}

	public void setVehicleNumber(String vehicleNumber) {
		this.vehicleNumber = vehicleNumber;
	}

	

	public String getDriverName() {
		return driverName;
	}

	public void setDriverName(String driverName) {
		this.driverName = driverName;
	}

	public String getDriverContactNumber() {
		return driverContactNumber;
	}

	public void setDriverContactNumber(String driverContactNumber) {
		this.driverContactNumber = driverContactNumber;
	}

	public String getBookingComments() {
		return bookingComments;
	}

	public void setBookingComments(String bookingComments) {
		this.bookingComments = bookingComments;
	}
	
	public Boolean getCancelRequest() {
		return cancelRequest;
	}

	public void setCancelRequest(Boolean cancelRequest) {
		this.cancelRequest = cancelRequest;
	}
	

	public String getCancelComments() {
		return cancelComments;
	}

	public void setCancelComments(String cancelComments) {
		this.cancelComments = cancelComments;
	}

	
	
	public String getChargeableComments() {
		return chargeableComments;
	}

	public void setChargeableComments(String chargeableComments) {
		this.chargeableComments = chargeableComments;
	}
	
	

	public String getUserMobile() {
		return userMobile;
	}

	public void setUserMobile(String userMobile) {
		this.userMobile = userMobile;
	}

	public Integer getSubmissionStatus() {
		return submissionStatus;
	}

	public void setSubmissionStatus(Integer submissionStatus) {
		this.submissionStatus = submissionStatus;
	}
	

	public Integer getApproverId() {
		return approverId;
	}

	public void setApproverId(Integer approverId) {
		this.approverId = approverId;
	}
	
	

	public Integer getInfoCabDriverId() {
		return infoCabDriverId;
	}

	public void setInfoCabDriverId(Integer infoCabDriverId) {
		this.infoCabDriverId = infoCabDriverId;
	}

	public Integer getInfoCabVehicleId() {
		return infoCabVehicleId;
	}

	public void setInfoCabVehicleId(Integer infoCabVehicleId) {
		this.infoCabVehicleId = infoCabVehicleId;
	}

	public String getTravelWay() {
		return travelWay;
	}

	public void setTravelWay(String travelWay) {
		this.travelWay = travelWay;
	}

	public String getBillingType() {
		return billingType;
	}

	public void setBillingType(String billingType) {
		this.billingType = billingType;
	}
	
	

	public Integer getStartKm() {
		return startKm;
	}

	public void setStartKm(Integer startKm) {
		this.startKm = startKm;
	}

	

	public Integer getEndKm() {
		return endKm;
	}

	public void setEndKm(Integer endKm) {
		this.endKm = endKm;
	}

	public Integer getDieselLtr() {
		return dieselLtr;
	}

	public void setDieselLtr(Integer dieselLtr) {
		this.dieselLtr = dieselLtr;
	}

	public Integer getDieselRate() {
		return dieselRate;
	}

	public void setDieselRate(Integer dieselRate) {
		this.dieselRate = dieselRate;
	}

	public Integer getOrderNo() {
		return orderNo;
	}

	public void setOrderNo(Integer orderNo) {
		this.orderNo = orderNo;
	}

	public Integer getParking() {
		return parking;
	}

	public void setParking(Integer parking) {
		this.parking = parking;
	}

	public String getReferenceNo() {
		return referenceNo;
	}

	public void setReferenceNo(String referenceNo) {
		this.referenceNo = referenceNo;
	}

	public Integer getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Integer getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public Integer getEmpId() {
		return empId;
	}

	public void setEmpId(Integer empId) {
		this.empId = empId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getPermTelephoneNo() {
		return permTelephoneNo;
	}

	public void setPermTelephoneNo(String permTelephoneNo) {
		this.permTelephoneNo = permTelephoneNo;
	}

	public String getTempMobNo() {
		return tempMobNo;
	}

	public void setTempMobNo(String tempMobNo) {
		this.tempMobNo = tempMobNo;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPermStreet1() {
		return permStreet1;
	}

	public void setPermStreet1(String permStreet1) {
		this.permStreet1 = permStreet1;
	}

	public String getPermStreet2() {
		return permStreet2;
	}

	public void setPermStreet2(String permStreet2) {
		this.permStreet2 = permStreet2;
	}

	public Integer getDepartmentId() {
		return departmentId;
	}

	public void setDepartmentId(Integer departmentId) {
		this.departmentId = departmentId;
	}

	public String getProjectManagerName() {
		return projectManagerName;
	}

	public void setProjectManagerName(String projectManagerName) {
		this.projectManagerName = projectManagerName;
	}

	public String getCityName() {
		return cityName;
	}

	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	public String getDepartmentName() {
		return departmentName;
	}

	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}
	
	
	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	
	public String getResourceName() {
		return resourceName;
	}

	public void setResourceName(String resourceName) {
		this.resourceName = resourceName;
	}

	public String getApproverName() {
		return approverName;
	}

	public void setApproverName(String approverName) {
		this.approverName = approverName;
	}
	
	

	public String getCreatedName() {
		return createdName;
	}

	public void setCreatedName(String createdName) {
		this.createdName = createdName;
	}

	// Getter setter
	// --------------------------------------------------------------------------------
	public InfoCab() {
	}
	//Press Alt+Shift+S => Generate Getter and Setters..

	public InfoCab(Integer infoCabId, Integer uid, String pickupPoint, String dropPoint, Integer projectId,
			Date dateCab, String timeCab, String remarks, String pmApprovalStatus, Date pmApprovalDate,
			String pmApprovalComment, String bookingStatus, String vehicleNumber, String driverName,
			String driverContactNumber, String bookingComments, Boolean cancelRequest, String cancelComments, String chargeableComments, String userMobile, 
			Integer submissionStatus, Integer approverId, Integer infoCabDriverId, Integer infoCabVehicleId,
			String travelWay, String billingType, Integer startKm, Integer endKm, Integer dieselLtr, Integer dieselRate,
			Integer orderNo, Integer parking, String referenceNo, Integer createdBy, Date createdDate,
			Integer modifiedBy, Date modifiedDate, Integer empId, String title, String permTelephoneNo,
			String tempMobNo, String email, String permStreet1, String permStreet2, Integer departmentId,
			String projectManagerName, String cityName, String departmentName, String projectName, String resourceName,
			String approverName, String createdName) {
		super();
		this.infoCabId = infoCabId;
		this.uid = uid;
		this.pickupPoint = pickupPoint;
		this.dropPoint = dropPoint;
		this.projectId = projectId;
		this.dateCab = dateCab;
		this.timeCab = timeCab;
		this.remarks = remarks;
		this.pmApprovalStatus = pmApprovalStatus;
		this.pmApprovalDate = pmApprovalDate;
		this.pmApprovalComment = pmApprovalComment;
		this.bookingStatus = bookingStatus;
		this.vehicleNumber = vehicleNumber;
		this.driverName = driverName;
		this.driverContactNumber = driverContactNumber;
		this.bookingComments = bookingComments;
		this.cancelRequest = cancelRequest;
		this.cancelComments = cancelComments;
		this.chargeableComments = chargeableComments;
		this.userMobile = userMobile;
		this.submissionStatus = submissionStatus;
		this.approverId = approverId;
		this.infoCabDriverId = infoCabDriverId;
		this.infoCabVehicleId = infoCabVehicleId;
		this.travelWay = travelWay;
		this.billingType = billingType;
		this.startKm = startKm;
		this.endKm = endKm;
		this.dieselLtr = dieselLtr;
		this.dieselRate = dieselRate;
		this.orderNo = orderNo;
		this.parking = parking;
		this.referenceNo = referenceNo;
		this.createdBy = createdBy;
		this.createdDate = createdDate;
		this.modifiedBy = modifiedBy;
		this.modifiedDate = modifiedDate;
		this.empId = empId;
		this.title = title;
		this.permTelephoneNo = permTelephoneNo;
		this.tempMobNo = tempMobNo;
		this.email = email;
		this.permStreet1 = permStreet1;
		this.permStreet2 = permStreet2;
		this.departmentId = departmentId;
		this.projectManagerName = projectManagerName;
		this.cityName = cityName;
		this.departmentName = departmentName;
		this.projectName = projectName;
		this.resourceName = resourceName;
		this.approverName = approverName;
		this.createdName = createdName;
	}

	
	

	
	
	
}
