package com.infocepts.otc.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.infocepts.otc.entities.InfoTravelDetail;

public interface InfoTravelDetailRepository extends CrudRepository<InfoTravelDetail,Integer>{

	@Override
	public List<InfoTravelDetail> findAll();	
	
	@Query("from InfoTravelDetail where infoTravelId = :infoTravelId")
	public List<InfoTravelDetail> findById(@Param(value="infoTravelId") Integer infoTravelId);
	
	
	 @Query("select origin, destination, departureDate from InfoTravelDetail where infoTravelId = :infoTravelId") 
	 public List<InfoTravelDetail> findOriginById(@Param(value="infoTravelId") Integer infoTravelId);
	
	
	
	
}


