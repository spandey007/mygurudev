/**
 * 
 */
package com.infocepts.otc.controllers;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;

import com.infocepts.otc.utilities.ExpenseMailNotification;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infocepts.otc.entities.Expense;
import com.infocepts.otc.entities.ExpenseSettlement;
import com.infocepts.otc.repositories.ExpenseRepository;
import com.infocepts.otc.repositories.ExpenseSettlementRepository;
import com.infocepts.otc.utilities.LoadConstant;

/**
 * @author Rewatiraman Singh
 *
 */
@RestController
@RequestMapping("/expenseSettlement")
public class ExpenseSettlementController extends Object {
	
	private final Logger logger = Logger.getLogger(ExpenseSettlementController.class.getName());
	@Autowired
	private ExpenseSettlementRepository expenseSettlementRepository;
	
	@Autowired
	private ExpenseRepository expenseRepository;

	@Autowired
	private ExpenseMailNotification mailNotification;
	
	@PersistenceContext(unitName = "otc")
	private EntityManager manager;
	
	@GetMapping("/getSettlementByExpenseId")
	public Object getSettlementByExpenseId(HttpServletRequest request) {
		return expenseSettlementRepository.findByExpenseId(manager, NumberUtils.toInt(request.getParameter("expenseId")));
	}
	
	@PostMapping
	public Object settle(@RequestBody List<ExpenseSettlement> expenseSettlementList, HttpServletRequest request) {
		Integer loggedInUser = (Integer) request.getSession().getAttribute("loggedInUid");
		Date currentDate = new Date();
		Integer expenseId = 0;
		List<ExpenseSettlement> savedSettlement = new ArrayList<>();
		try {
			if (CollectionUtils.isNotEmpty(expenseSettlementList)) {
				Date settlementDate = expenseSettlementList.get(0).getSettlementDate();
				Expense expense = expenseRepository.findOne(expenseSettlementList.get(0).getExpense().getExpenseId());
				expense.setSettlementDate(settlementDate);
				expense.setStatus(LoadConstant.EXPENSE_STATUS_SETTLED);
				Expense savedExpense = expenseRepository.save(expense);
				expenseSettlementList.forEach(eSettle -> {
					eSettle.setExpense(savedExpense);
					eSettle.setCreatedDate(currentDate);
					eSettle.setModifiedDate(currentDate);
					eSettle.setCreatedBy(loggedInUser);
					eSettle.setModifiedBy(loggedInUser);
					savedSettlement.add(expenseSettlementRepository.save(eSettle));
					new Thread(()-> mailNotification.notifySettlement(expense)).start();
				});
			}
		} catch (Exception e) {
			logger.log(Level.SEVERE, "SOMETHING WENT WRONG WHILE SETTLING THE EXPENSE WITH EXPENSE ID: " + expenseId, e);
		} finally {
			if (expenseSettlementList.size() == savedSettlement.size()) {
				logger.log(Level.INFO, "EXPENSE IS SETTLED WITH EXPENSE ID: " + expenseId);
			}
		}
		Map<String, List<ExpenseSettlement>> responseMap = new HashMap<>();
		responseMap.putIfAbsent("settlements", savedSettlement);
		return responseMap;
	}
}
