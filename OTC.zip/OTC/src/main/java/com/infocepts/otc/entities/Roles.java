package com.infocepts.otc.entities;

import java.util.Date;

import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.infocepts.otc.utilities.LoadConstant;

@Entity
@Table(catalog=LoadConstant.otc,schema="[dbo]",name="roles")
@SqlResultSetMapping(
	      name = "get_all_roles",
	      classes = {
	          @ConstructorResult(
	              targetClass = Roles.class,
	              columns = {
	                  @ColumnResult(name = "roleId"),
	                  @ColumnResult(name = "role"),
	                  @ColumnResult(name = "isEnabled"),
	                  @ColumnResult(name = "assignmentCount"),
               
	              }
	          )
	      }
	)
	@NamedNativeQueries({
	    @NamedNativeQuery(
	            name    =   "getAllRolesWithAssignmentCount",
	            query   =   "SELECT r.*,"
	            			+" (select count(*) from " + LoadConstant.otc + ".[dbo].[resource_roles] as rr where rr.roleId = r.roleId and rr.status = 1) as assignmentCount"
	            			+" FROM " + LoadConstant.otc + ".[dbo].[roles] as r order by role",
	                        resultClass=Roles.class, resultSetMapping = "get_all_roles"                       		
	    )
	})
public class Roles {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer roleId;
	private String role;
	private Boolean isEnabled;
	
	@Transient
	private Integer assignmentCount;
	
	public Integer getRoleId() {
		return roleId;
	}
	public void setRoleId(Integer roleId) {
		this.roleId = roleId;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public Boolean getIsEnabled() {
		return isEnabled;
	}
	public void setIsEnabled(Boolean isEnabled) {
		this.isEnabled = isEnabled;
	}
	public Integer getAssignmentCount() {
		return assignmentCount;
	}
	public void setAssignmentCount(Integer assignmentCount) {
		this.assignmentCount = assignmentCount;
	}
	
	public Roles() {
		
	};
	public Roles(Integer roleId, String role, Boolean isEnabled, Integer assignmentCount) {
		
		this.roleId = roleId;
		this.role = role;
		this.isEnabled = isEnabled;
		this.assignmentCount = assignmentCount;
	}
	
	

}
