package com.infocepts.otc.controllers;

import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.infocepts.otc.entities.ProjectTerms;
import com.infocepts.otc.repositories.ProjectTermsRepository;

@RestController
@RequestMapping(value="/projectterms",headers="referer")
public class ProjectTermsController {

	final Logger logger = Logger.getLogger(ProjectTermsController.class);
	
	@Autowired
	ProjectTermsRepository repository;
	
	@RequestMapping(method=RequestMethod.POST)
	public ProjectTerms addProjectTerms(@RequestBody ProjectTerms projectterms)
	{
		try{
			projectterms.setProjectTermsId(null);
			repository.save(projectterms);	
		}catch(Exception e){
			logger.error(e);
		}
		return projectterms;
	}	
 
	 @RequestMapping(method=RequestMethod.GET)
	 public List<ProjectTerms> getAllProjectTerms(@RequestParam(value="projectId",defaultValue="0") Integer projectId){
		 List<ProjectTerms> projecttermslist=null;
		 try{
			 if(projectId != 0){
				 projecttermslist = repository.findByProjectId(projectId);
			 }
			 else{
				 projecttermslist = repository.findAll();
			 }
			 
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return projecttermslist;
	 }

	 @RequestMapping(value="/{projectTermsId}",method=RequestMethod.PUT)
	 public ProjectTerms updateProjectTerms(@RequestBody ProjectTerms updatedProjectTerms,@PathVariable Integer projectTermsId){
		 try{
			 updatedProjectTerms.setProjectTermsId(projectTermsId);
			 repository.save(updatedProjectTerms);
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return updatedProjectTerms;
	 }
	 
	 @RequestMapping(value="/{projectTermsId}",method=RequestMethod.DELETE)
	 public void deleteProjectTerms(@PathVariable Integer projectTermsId){
		 try{
			 repository.delete(projectTermsId);
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
	 }
	 
	 @GetMapping("/getProjectTerms")
	 public List<ProjectTerms> getProjectTerms(@RequestParam(value="projectId",defaultValue="0") Integer projectId){
		 List<ProjectTerms> projecttermslist=null;
		 try{
			 if(projectId != 0){
				 projecttermslist = repository.findByProjectId(projectId);
			 }
			 else{
				 projecttermslist = repository.findAll();
			 }
			 
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return projecttermslist;
	 }
}
