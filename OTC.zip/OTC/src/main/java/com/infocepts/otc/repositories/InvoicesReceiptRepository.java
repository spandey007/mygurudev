package com.infocepts.otc.repositories;

import java.util.List;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import com.infocepts.otc.entities.InvoicesReceipt;

public interface InvoicesReceiptRepository extends CrudRepository<InvoicesReceipt,Integer>{

	@Override
	public List<InvoicesReceipt> findAll() ;

	@Query("from InvoicesReceipt where invoiceId=:invoiceId")
	public List<InvoicesReceipt> findByInvoiceId(@Param("invoiceId") Integer invoiceId);
	
}
