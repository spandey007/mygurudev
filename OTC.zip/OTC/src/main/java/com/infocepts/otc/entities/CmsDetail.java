package com.infocepts.otc.entities;

import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.SqlResultSetMappings;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.infocepts.otc.utilities.LoadConstant;

@Entity
@Table(catalog=LoadConstant.otc, schema="[dbo]",name="cmsDetail")
@SqlResultSetMappings({
	@SqlResultSetMapping(
		      name = "get_CmsDetails",
		      classes = {
		          @ConstructorResult(
		              targetClass = CmsDetail.class,
		              columns = {
		                  @ColumnResult(name = "cmsDetailId"),
		                  @ColumnResult(name = "infoceptsRole", type=String.class), //Not to be Push on Stage
		                  @ColumnResult(name = "sowRoleStartDate", type=Date.class),
		                  @ColumnResult(name = "sowRoleEndDate", type=Date.class),
		                  @ColumnResult(name = "reqStartDate", type=Date.class),
		                  @ColumnResult(name = "reqEndDate", type=Date.class),
		                  @ColumnResult(name = "treqId"),
		                  @ColumnResult(name = "treqStatus", type=String.class),
		                  @ColumnResult(name = "skillName", type=String.class),
		                  @ColumnResult(name = "priority", type=String.class),
		                  @ColumnResult(name = "billableRate", type=BigDecimal.class),	                  
		                  @ColumnResult(name = "expectedBillability", type=BigDecimal.class),            
		                  @ColumnResult(name = "expectedDays", type=BigDecimal.class),	
		                  @ColumnResult(name = "status", type=String.class),
		                  @ColumnResult(name = "comments", type=String.class),	                                    
		                  @ColumnResult(name = "cmsId"),
		                  @ColumnResult(name = "sowId"),
		                  @ColumnResult(name = "createdDate", type=Date.class),
		                  @ColumnResult(name = "modifiedDate", type=Date.class),
		                  @ColumnResult(name = "createdBy"),
		                  @ColumnResult(name = "modifiedBy"),
		                  @ColumnResult(name = "cost", type=BigDecimal.class),
		                  @ColumnResult(name = "amount", type=BigDecimal.class),
		                  @ColumnResult(name = "isBillable", type=Boolean.class),
		                  @ColumnResult(name = "unitId", type=Integer.class),
		                  @ColumnResult(name = "accountId", type=Integer.class),		                  
		                  @ColumnResult(name = "countryId", type=Integer.class),
		                  @ColumnResult(name = "countryName", type=String.class),
		                  @ColumnResult(name = "unitName", type=String.class),
		                  @ColumnResult(name = "uomName", type=String.class),
		                  @ColumnResult(name = "currencySign", type=String.class),
		                  @ColumnResult(name = "accountName", type=String.class),
		                  @ColumnResult(name = "dummyProjectName", type=String.class),
		                  @ColumnResult(name = "associateLevelId"),
		                  @ColumnResult(name = "cityId"),
		                  @ColumnResult(name = "associateLevelName", type=String.class),
		                  @ColumnResult(name = "cityName", type=String.class),
		                  @ColumnResult(name = "roleId"),
		                  @ColumnResult(name = "reasonForCancellation"),
		                  @ColumnResult(name = "probability", type=String.class),
		                  @ColumnResult(name = "roleCopiedFromSowDetailId"),
		                  
		                  @ColumnResult(name = "opportunityType", type=String.class),
		                  @ColumnResult(name = "createdByName", type=String.class),
		                  @ColumnResult(name = "ph", type=String.class),
		                  @ColumnResult(name = "cep", type=String.class),
		                  @ColumnResult(name = "opportunityName", type=String.class),
		                  @ColumnResult(name = "opportunityNumber", type=String.class),
		                  @ColumnResult(name = "opportunityValue", type=String.class),
		                  @ColumnResult(name = "jobDescription", type=String.class)	                  
		                  
		                }
		          )
		      }
	)
})
	@NamedNativeQueries({
	   @NamedNativeQuery(
	            name    =   "getCmsDetailsForAccount",
	            query   =   "select cd.*, c.countryName, u.name as unitName, uom.name as uomName, cur.sign as currencySign,"+
	            			" t.reqStartDate as reqStartDate, t.reqEndDate as reqEndDate, t.priority, t.treqId as treqId, t.status as treqStatus, t.jobDescription, acc.title as accountName,"+
	            			" CASE WHEN (cd.sowDetailId != NULL)"+
			    				" THEN (Select title FROM " + LoadConstant.infomaster + ".[dbo].project"+
			    				" left join " + LoadConstant.otc + ".[dbo].sowDetail sd on sd.sowDetailId = cd.sowDetailId"+
			    				" WHERE sd.sowDetailId = cd.sowDetailId)"+
			    				" ELSE cms.dummyProjectName"+
							" END as dummyProjectName,"+
	            			" sk.skillName as skillName, obj_city.cityName as cityName, g.grade as associateLevelName,"+
							" ar.amgRoleName as infoceptsRole,"+
	            			" '' as createdByName, '' as opportunityType, '' as ph, '' as cep, "+
							" '' as opportunityName, '' as opportunityNumber, '' as opportunityValue "+
	            		 	" FROM " + LoadConstant.otc + ".[dbo].cmsDetail cd "+
	            		 	" left join " + LoadConstant.otc + ".[dbo].cms cms on cms.cmsId = cd.cmsId"+
	            		 	" left join " + LoadConstant.otc + ".[dbo].treq t on t.cmsDetailId = cd.cmsDetailId"+
	            		 	" left join " + LoadConstant.infomaster + ".[dbo].uom uom on uom.uomId = cms.uomId"+
	            		 	" left join " + LoadConstant.infomaster + ".[dbo].currency cur on cur.currencyId = cms.currencyId"+
	            		 	" left join " + LoadConstant.infomaster + ".[dbo].country c on c.countryId = cd.countryId"+
	            		 	" left join " + LoadConstant.infomaster + ".[dbo].unit u on u.unitId = cd.unitId"+
	            		 	" left join " + LoadConstant.infomaster + ".[dbo].accounts acc on acc.itemId = cd.accountId"+
	            		 	" left join " + LoadConstant.infomaster + ".[dbo].skill sk on sk.skillId = t.skillId"+
	            		 	" left join " + LoadConstant.infomaster + ".[dbo].city obj_city on obj_city.cityId = cd.cityId"+
	            		 	" left join " + LoadConstant.infomaster + ".[dbo].grade g on g.gradeId = cd.associateLevelId"+
	            		 	" left join " + LoadConstant.infomaster + ".[dbo].amgRoles ar on ar.amgRoleId = cd.roleId"+
	            		 	//" left join " + LoadConstant.infomaster + ".[dbo].associateLevel obj_associateLevel on obj_associateLevel.obj_associateLevelId = cd.obj_associateLevel"+ 
	                        " WHERE ((:accountId != 0 and cd.accountId = :accountId and cd.sowId is null) or (:accountId = 0) or (cd.sowId= :sowId))"+
	            		 	" AND cd.status = :status"+
	                        " order by cd.cmsDetailId desc",
	                        resultClass=Sow.class, resultSetMapping = "get_CmsDetails"                       		
	    ),
	   @NamedNativeQuery(
	            name    =   "getCmsDetailByCmsId",
	            query   =   "select cd.*, c.countryName, u.name as unitName, uom.name as uomName, cur.sign as currencySign,"+
	            			" getDate() as reqStartDate, getDate() as reqEndDate, '' as priority, null as treqId, '' as treqStatus, '' as jobDescription, '' as accountName, cms.dummyProjectName,"+
	            			" '' as skillName, obj_city.cityName as cityName, g.grade as associateLevelName,"+
	            			" ar.amgRoleName as infoceptsRole,"+
	            			" '' as createdByName, '' as opportunityType, '' as ph, '' as cep, "+
	            			" '' as opportunityName, '' as opportunityNumber, '' as opportunityValue "+
	            		 	" FROM " + LoadConstant.otc + ".[dbo].cmsDetail cd "+
	            		 	" left join " + LoadConstant.otc + ".[dbo].cms cms on cms.cmsId = cd.cmsId"+
	            		 	//" left join " + LoadConstant.otc + ".[dbo].treq t on t.cmsDetailId = cd.cmsDetailId"+
	            		 	" left join " + LoadConstant.infomaster + ".[dbo].uom uom on uom.uomId = cms.uomId"+
	            		 	" left join " + LoadConstant.infomaster + ".[dbo].currency cur on cur.currencyId = cms.currencyId"+
	            		 	" left join " + LoadConstant.infomaster + ".[dbo].country c on c.countryId = cd.countryId"+
	            		 	" left join " + LoadConstant.infomaster + ".[dbo].unit u on u.unitId = cd.unitId"+
	            		 	//" left join " + LoadConstant.infomaster + ".[dbo].skill sk on sk.skillId = t.skillId"+
	            		 	" left join " + LoadConstant.infomaster + ".[dbo].city obj_city on obj_city.cityId = cd.cityId"+
	            		 	" left join " + LoadConstant.infomaster + ".[dbo].grade g on g.gradeId = cd.associateLevelId"+
	            		 	" left join " + LoadConstant.infomaster + ".[dbo].amgRoles ar on ar.amgRoleId = cd.roleId"+
	            		 	//" left join " + LoadConstant.infomaster + ".[dbo].associateLevel obj_associateLevel on obj_associateLevel.obj_associateLevelId = cd.obj_associateLevel"+
	                        " WHERE cms.cmsId= :cmsId",
	                        resultClass=Sow.class, resultSetMapping = "get_CmsDetails"                       		
	    ),
	   @NamedNativeQuery(
	            name    =   "getCmsDetailById",
	            query   =   "select cd.*, c.countryName, u.name as unitName, uom.name as uomName, cur.sign as currencySign,"+
	            			" t.reqStartDate as reqStartDate, t.reqEndDate as reqEndDate, t.priority, t.treqId as treqId, t.status as treqStatus, t.jobDescription, '' as accountName, cms.dummyProjectName,"+
	            			" sk.skillName as skillName, obj_city.cityName as cityName, g.grade as associateLevelName,"+
	            			" ar.amgRoleName as infoceptsRole,"+
	            			" '' as createdByName, '' as opportunityType, '' as ph, '' as cep, "+
	            			" '' as opportunityName, '' as opportunityNumber, '' as opportunityValue "+
	            		 	" FROM " + LoadConstant.otc + ".[dbo].cmsDetail cd "+
	            		 	" left join " + LoadConstant.otc + ".[dbo].cms cms on cms.cmsId = cd.cmsId"+
	            		 	" left join " + LoadConstant.otc + ".[dbo].treq t on t.cmsDetailId = cd.cmsDetailId"+
	            		 	" left join " + LoadConstant.infomaster + ".[dbo].uom uom on uom.uomId = cms.uomId"+
	            		 	" left join " + LoadConstant.infomaster + ".[dbo].currency cur on cur.currencyId = cms.currencyId"+
	            		 	" left join " + LoadConstant.infomaster + ".[dbo].country c on c.countryId = cd.countryId"+
	            		 	" left join " + LoadConstant.infomaster + ".[dbo].unit u on u.unitId = cd.unitId"+
	            		 	" left join " + LoadConstant.infomaster + ".[dbo].skill sk on sk.skillId = t.skillId"+
	            		 	" left join " + LoadConstant.infomaster + ".[dbo].city obj_city on obj_city.cityId = cd.cityId"+
	            		 	" left join " + LoadConstant.infomaster + ".[dbo].grade g on g.gradeId = cd.associateLevelId"+
	            		 	" left join " + LoadConstant.infomaster + ".[dbo].amgRoles ar on ar.amgRoleId = cd.roleId"+
	            		 	//" left join " + LoadConstant.infomaster + ".[dbo].associateLevel obj_associateLevel on obj_associateLevel.obj_associateLevelId = cd.obj_associateLevel"+
	                        " WHERE cd.cmsDetailId= :cmsDetailId",
	                        resultClass=Sow.class, resultSetMapping = "get_CmsDetails"                       		
	    ),
	   @NamedNativeQuery(
	            name    =   "getCmsDetailByOpportunityId",
	            query   =   "select cd.*, c.countryName, u.name as unitName, uom.name as uomName, cur.sign as currencySign,"+
	            			" t.reqStartDate as reqStartDate, t.reqEndDate as reqEndDate, t.priority, t.treqId as treqId, t.status as treqStatus, t.jobDescription, acc.title as accountName,"+
	            			" CASE WHEN (cd.sowDetailId != NULL)"+
			    				" THEN (Select title FROM " + LoadConstant.infomaster + ".[dbo].project"+
			    				" left join " + LoadConstant.otc + ".[dbo].sowDetail sd on sd.sowDetailId = cd.sowDetailId"+
			    				" WHERE sd.sowDetailId = cd.sowDetailId)"+
			    				" ELSE cms.dummyProjectName"+
							" END as dummyProjectName,"+
	            			" sk.skillName as skillName, obj_city.cityName as cityName, g.grade as associateLevelName,"+
							" ar.amgRoleName as infoceptsRole,"+
							" '' as createdByName, '' as opportunityType, '' as ph, '' as cep, "+
							" '' as opportunityName, '' as opportunityNumber, '' as opportunityValue "+
	            		 	" FROM " + LoadConstant.otc + ".[dbo].cmsDetail cd "+
	            		 	" left join " + LoadConstant.otc + ".[dbo].cms cms on cms.cmsId = cd.cmsId"+
	            		 	" left join " + LoadConstant.otc + ".[dbo].treq t on t.cmsDetailId = cd.cmsDetailId"+
	            		 	" left join " + LoadConstant.infomaster + ".[dbo].uom uom on uom.uomId = cms.uomId"+
	            		 	" left join " + LoadConstant.infomaster + ".[dbo].currency cur on cur.currencyId = cms.currencyId"+
	            		 	" left join " + LoadConstant.infomaster + ".[dbo].country c on c.countryId = cd.countryId"+
	            		 	" left join " + LoadConstant.infomaster + ".[dbo].unit u on u.unitId = cd.unitId"+
	            		 	" left join " + LoadConstant.infomaster + ".[dbo].accounts acc on acc.itemId = cd.accountId"+
	            		 	" left join " + LoadConstant.infomaster + ".[dbo].skill sk on sk.skillId = t.skillId"+
	            		 	" left join " + LoadConstant.infomaster + ".[dbo].city obj_city on obj_city.cityId = cd.cityId"+
	            		 	" left join " + LoadConstant.infomaster + ".[dbo].grade g on g.gradeId = cd.associateLevelId"+
	            		 	" left join " + LoadConstant.infomaster + ".[dbo].amgRoles ar on ar.amgRoleId = cd.roleId"+
	            		 	//" left join " + LoadConstant.infomaster + ".[dbo].associateLevel obj_associateLevel on obj_associateLevel.obj_associateLevelId = cd.obj_associateLevel"+
	                        " WHERE cms.opportunityId= :opportunityId and cd.status = :status",
	                        resultClass=Sow.class, resultSetMapping = "get_CmsDetails"                       		
	    ),
	   
	   @NamedNativeQuery(
	            name    =   "getResourcePlanning",
	            query   =   "select cd.*, c.countryName, u.name as unitName, uom.name as uomName, cur.sign as currencySign,"+
	            			" t.reqStartDate as reqStartDate, t.reqEndDate as reqEndDate, t.priority, t.treqId as treqId, t.status as treqStatus, t.jobDescription, a.accountShortName as accountName, cms.dummyProjectName,"+
	            			" sk.skillName as skillName, obj_city.cityName as cityName, g.grade as associateLevelName,"+
	            			" ar.amgRoleName as infoceptsRole,"+
	            			" (select title from " + LoadConstant.infomaster + ".dbo.resource where uid =  cms.createdBy) as createdByName,"+
	            			" cms.opportunityType as opportunityType,"+
	            			" (select title from " + LoadConstant.infomaster + ".dbo.resource where uid =  a.dmId) as ph,"+
	            			" (select title from " + LoadConstant.infomaster + ".dbo.resource where uid =  a.rmId) as cep, "+
	            			" o.opportunityName as opportunityName, o.info_OpportunityNumber as opportunityNumber, opportunityValue as opportunityValue "+
	            			" FROM " + LoadConstant.otc + ".[dbo].cmsDetail cd "+
	            		 	" left join " + LoadConstant.otc + ".[dbo].cms cms on cms.cmsId = cd.cmsId"+
	            		 	" left join " + LoadConstant.otc + ".[dbo].treq t on t.cmsDetailId = cd.cmsDetailId"+
	            		 	" left join " + LoadConstant.infomaster + ".[dbo].uom uom on uom.uomId = cms.uomId"+
	            		 	" left join " + LoadConstant.infomaster + ".[dbo].currency cur on cur.currencyId = cms.currencyId"+
	            		 	" left join " + LoadConstant.infomaster + ".[dbo].country c on c.countryId = cd.countryId"+
	            		 	" left join " + LoadConstant.infomaster + ".[dbo].unit u on u.unitId = cd.unitId"+
	            		 	" left join " + LoadConstant.infomaster + ".[dbo].skill sk on sk.skillId = t.skillId"+
	            		 	" left join " + LoadConstant.infomaster + ".[dbo].city obj_city on obj_city.cityId = cd.cityId"+
	            		 	" left join " + LoadConstant.infomaster + ".[dbo].grade g on g.gradeId = cd.associateLevelId"+
	            		 	" left join " + LoadConstant.infomaster + ".[dbo].amgRoles ar on ar.amgRoleId = cd.roleId"+
	            		 	" left join " + LoadConstant.infomaster + ".dbo.accounts a on cms.accountId = a.itemId "+	
	            		 	" left join " + LoadConstant.infomaster + ".dbo.opportunity o on o.opportunityId = cms.opportunityId "+	
	            		 	//" left join " + LoadConstant.infomaster + ".[dbo].associateLevel obj_associateLevel on obj_associateLevel.obj_associateLevelId = cd.obj_associateLevel"+
	                        " WHERE ( year(cd.sowRoleStartDate) = :year or year(cd.sowRoleEndDate) = :year ) and cd.status != 'Cancelled' and" +
	            		 	" ((a.dmId = :uid and :isPH=1) or :isBP=1 or (cms.createdBy = :uid) or (:uid IN (select ahId FROM " + LoadConstant.infomaster + ".[dbo].[accounts] ac where ac.itemId = cms.accountId)) or (cms.ownerId = :uid) ) "+
	            		 	" order by a.title,  cms.dummyProjectName ",
	                        resultClass=Sow.class, resultSetMapping = "get_CmsDetails"
        )
})

public class CmsDetail {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer cmsDetailId;
	
	@ManyToOne
	@JoinColumn(name="cmsId")
	private Cms cms;
	
	private Integer roleId;
	
	private Date sowRoleStartDate;
	private Date sowRoleEndDate;
	
	@Column(precision=12,scale=2)
	private BigDecimal billableRate; //for T&M 
	
	@Column(precision=12,scale=2)
	private BigDecimal expectedBillability; //for T&M 
	
	@Column(precision=6,scale=2)
	private BigDecimal expectedDays;

	private Integer countryId;
	private Integer unitId;
	private Integer accountId; // This variable is used to easily track all the cmsDetails entries for an account
	
	private Integer associateLevelId;
	private Integer cityId;
	
	@ManyToOne
	@JoinColumn(name="sowId")
	private Sow sow; // This variable is used to tag cmsDetail created directly in the proposed roles section on SOW page

	private Integer sowDetailId; // This variable is used to link a converted cmsDetail to sowDetail
	
	@Lob
	private String comments;
	
	private Integer createdBy;
	private Integer modifiedBy;
	private Date createdDate;
	private Date modifiedDate;
	
	@Column(precision=12,scale=2)
	private BigDecimal cost;
	
	@Column(precision=12,scale=2)
	private BigDecimal amount; 	
	
	private Boolean isBillable;
	
	private String status; // Proposed or Active
	
	@Transient
	private String countryName;
	@Transient
	private String unitName;
	@Transient
	private String uomName;
	
	@Transient
	private String infoceptsRole; 
	
	@Transient
	private String currencySign;
	
	@Transient
	private Date reqStartDate;
	@Transient
	private Date reqEndDate;	
	
	@Transient
	private String accountName;	
	
	@Transient
	private Integer treqId;
	@Transient
	private String treqStatus;
	
	@Transient
	private String skillName;
	@Transient
	private String priority;
	
	@Transient
	private String associateLevelName;
	@Transient
	private String cityName;
	
	private String reasonForCancellation;
	
	private String probability;
	
	private Integer roleCopiedFromSowDetailId;
	
	/*Resource Planning Report columns*/
	@Transient
	private String opportunityType;
	
	@Transient
	private String createdByName;
	
	@Transient
	private String ph;
	
	@Transient
	private String cep;
	
	@Transient
	private String opportunityName;
	
	@Transient
	private String opportunityNumber;
	
	@Transient
	private String opportunityValue;
	
	@Transient
	private String jobDescription;
	
	//Getters and Setters
	//--------------------------------------------------------------------------------------------------------	
	public Integer getCmsDetailId() {
		return cmsDetailId;
	}

	public void setCmsDetailId(Integer cmsDetailId) {
		this.cmsDetailId = cmsDetailId;
	}

	public String getInfoceptsRole() {
		return infoceptsRole;
	}

	public void setInfoceptsRole(String infoceptsRole) {
		this.infoceptsRole = infoceptsRole;
	}

	public BigDecimal getBillableRate() {
		return billableRate;
	}

	public void setBillableRate(BigDecimal billableRate) {
		this.billableRate = billableRate;
	}

	public BigDecimal getExpectedBillability() {
		return expectedBillability;
	}

	public void setExpectedBillability(BigDecimal expectedBillability) {
		this.expectedBillability = expectedBillability;
	}

	public BigDecimal getExpectedDays() {
		return expectedDays;
	}

	public void setExpectedDays(BigDecimal expectedDays) {
		this.expectedDays = expectedDays;
	}

	public Integer getCountryId() {
		return countryId;
	}

	public void setCountryId(Integer countryId) {
		this.countryId = countryId;
	}

	public String getCountryName() {
		return countryName;
	}

	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}
	

	public String getUnitName() {
		return unitName;
	}

	public void setUnitName(String unitName) {
		this.unitName = unitName;
	}

	public Sow getSow() {
		return sow;
	}

	public void setSow(Sow sow) {
		this.sow = sow;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public Integer getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	public Integer getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public BigDecimal getCost() {
		return cost;
	}

	public void setCost(BigDecimal cost) {
		this.cost = cost;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public Boolean getIsBillable() {
		return isBillable;
	}

	public void setIsBillable(Boolean isBillable) {
		this.isBillable = isBillable;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getUomName() {
		return uomName;
	}

	public void setUomName(String uomName) {
		this.uomName = uomName;
	}

	public String getCurrencySign() {
		return currencySign;
	}

	public void setCurrencySign(String currencySign) {
		this.currencySign = currencySign;
	}
	@Transient
	public Date getReqStartDate() {
		return reqStartDate;
	}

	public void setReqStartDate(Date reqStartDate) {
		this.reqStartDate = reqStartDate;
	}

	public Date getReqEndDate() {
		return reqEndDate;
	}

	public void setReqEndDate(Date reqEndDate) {
		this.reqEndDate = reqEndDate;
	}
	
	public Integer getAccountId() {
		return accountId;
	}

	public void setAccountId(Integer accountId) {
		this.accountId = accountId;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public Integer getUnitId() {
		return unitId;
	}

	public void setUnitId(Integer unitId) {
		this.unitId = unitId;
	}

	public Cms getCms() {
		return cms;
	}

	public void setCms(Cms cms) {
		this.cms = cms;
	}
	
	public Integer getSowDetailId() {
		return sowDetailId;
	}

	public void setSowDetailId(Integer sowDetailId) {
		this.sowDetailId = sowDetailId;
	}

	public Date getSowRoleStartDate() {
		return sowRoleStartDate;
	}

	public void setSowRoleStartDate(Date sowRoleStartDate) {
		this.sowRoleStartDate = sowRoleStartDate;
	}

	public Date getSowRoleEndDate() {
		return sowRoleEndDate;
	}

	public void setSowRoleEndDate(Date sowRoleEndDate) {
		this.sowRoleEndDate = sowRoleEndDate;
	}
	
	@Transient
	public String getSkillName() {
		return skillName;
	}

	public void setSkillName(String skillName) {
		this.skillName = skillName;
	}
	@Transient
	public String getPriority() {
		return priority;
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}
	
	@Transient
	public Integer getTreqId() {
		return treqId;
	}

	public void setTreqId(Integer treqId) {
		this.treqId = treqId;
	}
	@Transient
	public String getTreqStatus() {
		return treqStatus;
	}

	public void setTreqStatus(String treqStatus) {
		this.treqStatus = treqStatus;
	}
	
	public Integer getAssociateLevelId() {
		return associateLevelId;
	}

	public void setAssociateLevelId(Integer associateLevelId) {
		this.associateLevelId = associateLevelId;
	}

	public Integer getCityId() {
		return cityId;
	}

	public void setCityId(Integer cityId) {
		this.cityId = cityId;
	}

	public String getAssociateLevelName() {
		return associateLevelName;
	}

	public void setAssociateLevelName(String associateLevelName) {
		this.associateLevelName = associateLevelName;
	}

	public String getCityName() {
		return cityName;
	}

	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
	
	public Integer getRoleId() {
		return roleId;
	}

	public void setRoleId(Integer roleId) {
		this.roleId = roleId;
	}
	
	public String getReasonForCancellation() {
		return reasonForCancellation;
	}

	public void setReasonForCancellation(String reasonForCancellation) {
		this.reasonForCancellation = reasonForCancellation;
	}

	public String getProbability() {
		return probability;
	}

	public void setProbability(String probability) {
		this.probability = probability;
	}
	
	public Integer getRoleCopiedFromSowDetailId() {
		return roleCopiedFromSowDetailId;
	}

	public void setRoleCopiedFromSowDetailId(Integer roleCopiedFromSowDetailId) {
		this.roleCopiedFromSowDetailId = roleCopiedFromSowDetailId;
	}
	
	public String getOpportunityType() {
		return opportunityType;
	}

	public void setOpportunityType(String opportunityType) {
		this.opportunityType = opportunityType;
	}

	public String getCreatedByName() {
		return createdByName;
	}

	public void setCreatedByName(String createdByName) {
		this.createdByName = createdByName;
	}

	public String getPh() {
		return ph;
	}

	public void setPh(String ph) {
		this.ph = ph;
	}

	public String getCep() {
		return cep;
	}

	public void setCep(String cep) {
		this.cep = cep;
	}

	public String getOpportunityName() {
		return opportunityName;
	}

	public void setOpportunityName(String opportunityName) {
		this.opportunityName = opportunityName;
	}

	public String getOpportunityNumber() {
		return opportunityNumber;
	}

	public void setOpportunityNumber(String opportunityNumber) {
		this.opportunityNumber = opportunityNumber;
	}

	public String getOpportunityValue() {
		return opportunityValue;
	}

	public void setOpportunityValue(String opportunityValue) {
		this.opportunityValue = opportunityValue;
	}
	
	@Transient
	public String getJobDescription() {
		return jobDescription;
	}

	public void setJobDescription(String jobDescription) {
		this.jobDescription = jobDescription;
	}
	//End of: Getter and Setter
	

	//Constructor(s)
	public CmsDetail() {
	}

	public CmsDetail(Integer cmsDetailId, String infoceptsRole, Date sowRoleStartDate, Date sowRoleEndDate,
						Date reqStartDate, Date reqEndDate, Integer treqId, String treqStatus, String skillName, String priority,
						BigDecimal billableRate, BigDecimal expectedBillability, BigDecimal expectedDays,
						String status, String comments, Integer cmsId, Integer sowId, 
						Date createdDate, Date modifiedDate, Integer createdBy, Integer modifiedBy,
						BigDecimal cost, BigDecimal amount, Boolean isBillable, Integer unitId, Integer accountId, Integer countryId,
						String countryName, String unitName, String uomName, String currencySign, String accountName,
						String dummyProjectName,
						Integer associateLevelId, Integer cityId, String associateLevelName, String cityName, Integer roleId,
						String reasonForCancellation,
						String probability, Integer roleCopiedFromSowDetailId,
						String opportunityType, String createdByName, String ph, String cep,
						String opportunityName, String opportunityNumber, String opportunityValue, String jobDescription
					 )
	{
		this.cmsDetailId = cmsDetailId;
		this.infoceptsRole = infoceptsRole;	
		this.sowRoleStartDate = sowRoleStartDate;
		this.sowRoleEndDate = sowRoleEndDate;
		this.reqStartDate = reqStartDate;
		this.reqEndDate = reqEndDate;
		this.billableRate = billableRate;
		this.expectedBillability = expectedBillability;
		this.expectedDays = expectedDays;
		this.status = status;
		
		this.comments = comments;
		
		if(cmsId != null)
		{
			this.cms = new Cms();
			this.cms.setCmsId(cmsId);
			this.cms.setDummyProjectName(dummyProjectName);
		}
		
		if(sowId != null)
		{
			this.sow = new Sow();
			this.sow.setSowId(sowId);
			this.sow.setProjectName(dummyProjectName);
		}
		
		this.createdDate = createdDate;
		this.modifiedDate = modifiedDate;
		this.createdBy = createdBy;		
		this.modifiedBy = modifiedBy;
		this.cost = cost;
		this.amount = amount;
		this.isBillable = isBillable;
		
		this.unitId = unitId;
		this.accountId = accountId;
				
		this.countryId = countryId;
		this.countryName = countryName;
		this.unitName = unitName;
		this.uomName = uomName;
		this.currencySign = currencySign;
		this.accountName = accountName;
		this.treqId = treqId;
		this.treqStatus = treqStatus;
		this.skillName = skillName;
		this.priority = priority;
		
		this.associateLevelId = associateLevelId;
		this.cityId = cityId;
		this.associateLevelName = associateLevelName;
		this.cityName = cityName;
		this.roleId = roleId;
		this.reasonForCancellation = reasonForCancellation;
		this.probability = probability;
		this.roleCopiedFromSowDetailId = roleCopiedFromSowDetailId;
		this.opportunityType = opportunityType;
		this.createdByName = createdByName;
		this.ph = ph;
		this.cep = cep;
		this.opportunityName = opportunityName;
		this.opportunityNumber = opportunityNumber;
		this.opportunityValue = opportunityValue;
		this.jobDescription = jobDescription;
		
		
	}
	
	//End of: Constructor(s)
}