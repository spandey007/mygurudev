package com.infocepts.otc.controllers;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.infocepts.otc.entities.Permissions;
import com.infocepts.otc.repositories.PermissionsRepository;
import com.infocepts.otc.services.TimesheetService;

@RestController
@RequestMapping(value="/permissions",headers="referer")//JV: Added 'headers' param to validate the url.
public class PermissionsController {
	
	final Logger logger = Logger.getLogger(PermissionsController.class);

	@Autowired
	PermissionsRepository repository;
	
	@Autowired
	HttpSession session;
	
	@Autowired
	TimesheetService service;
	
	@RequestMapping(method=RequestMethod.GET)
	public List<Permissions> findPermissions(HttpServletRequest request){
		List<Permissions> permissionslist=null;
		try{
			/* ------------------------- Authorization start ------------------------------------ */
			// Authorization for admin role
			if(!service.isAdmin())
			{
				service.sendTamperedMail("Permissions View All", 0, 0, request);	
				return permissionslist;
			}
			/* ------------------------- Authorization ends ------------------------------------ */
			permissionslist = repository.findAll();
		}
		catch(Exception e){
			logger.error(e);
		}
		return permissionslist;
		
	}
	
	@RequestMapping(value="/{permissionsId}",method=RequestMethod.GET)
	public List<Permissions> findPermissionsByModuleId(@PathVariable(value="permissionsId") Integer permissionsId,
														HttpServletRequest request){
		List<Permissions> permissionslist=null;
		try{
			/* ------------------------- Authorization start ------------------------------------ */
			// Authorization for admin role
			if(service.isAdmin())
			{
				permissionslist = repository.findPermissionsByPermissionsId(permissionsId);
			}
			else
			{
				service.sendTamperedMail("Permissions By Module Id", 0, 0, request);
			}
			/* ------------------------- Authorization ends ------------------------------------ */
			
		}
		catch(Exception e){
			logger.error(e);
		}
		return permissionslist;
	}
	
	@RequestMapping(method=RequestMethod.POST)
	public Permissions addPermissions(@RequestBody Permissions permissions,
												HttpServletRequest request){
		try{
			/* ------------------------- Authorization start ------------------------------------ */
			// Authorization for admin role
			if(service.isAdmin())
			{
				repository.save(permissions);
			}
			else
			{
				service.sendTamperedMail("Permissions By Module Id", 0, 0, request);
			}
			/* ------------------------- Authorization ends ------------------------------------ */			
		}
		catch(Exception e){
			logger.error(e);
		}
		return permissions;
	}
	 
	@RequestMapping(value="/{permissionsId}",method=RequestMethod.PUT)
	public Permissions updatePermissionsById(@PathVariable Integer permissionsId,@RequestBody Permissions updatedPermissions,
												HttpServletRequest request){
		try{
			/* ------------------------- Authorization start ------------------------------------ */
			// Authorization for admin role
			if(service.isAdmin())
			{
				updatedPermissions.setPermissionsId(permissionsId);
				repository.save(updatedPermissions);
			}
			else
			{
				service.sendTamperedMail("Permissions By Module Id", 0, 0, request);
			}
			/* ------------------------- Authorization ends ------------------------------------ */
		}
		catch(Exception e){
			logger.error(e);
		}
		return updatedPermissions;
	}

}
