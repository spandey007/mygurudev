/*package com.infocepts.otc.db;

import java.util.HashMap;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceBuilder;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.env.Environment;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@EnableTransactionManagement
@EnableAutoConfiguration
@EnableJpaRepositories(
		basePackages = "com.infocepts.otc.repositoriesepm", 
		entityManagerFactoryRef = "epmEntityManagerFactory", 
		transactionManagerRef = "epmTransactionManager")
public class EpmDbConfig {
	
		@Autowired
		private Environment env;	
		
		@Bean  
		@ConfigurationProperties(prefix = "epm.datasource")
		public DataSource epmDataSource() {
			return DataSourceBuilder.create().build();
		}

	    @Bean(name = "epmEntityManager")
	    public EntityManager entityManager() {
	        return entityManagerFactory().createEntityManager();
	    }
	  
	    @Bean(name = "epmEntityManagerFactory")
	    public EntityManagerFactory entityManagerFactory() {
	        LocalContainerEntityManagerFactoryBean emf = new LocalContainerEntityManagerFactoryBean();
	        emf.setDataSource(epmDataSource());
	        
	        HibernateJpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();	        
	        emf.setJpaVendorAdapter(vendorAdapter);
	        emf.setPackagesToScan(new String[] {"com.infocepts.otc.entitiesepm"});
	        emf.setPersistenceUnitName("epm"); 
	        
	        HashMap<String, Object> properties = new HashMap<String, Object>();
			//properties.put("hibernate.show_sql", env.getProperty("hibernate.show_sql"));
	        //properties.put("hibernate.hbm2ddl.auto", env.getProperty("hibernate.hbm2ddl.auto"));
	        properties.put("hibernate.dialect", env.getProperty("hibernate.dialect"));
	        emf.setJpaPropertyMap(properties);
	        emf.afterPropertiesSet();
	        return emf.getObject();
	    }
	    
	    @Bean(name = "epmTransactionManager")
	    public PlatformTransactionManager transactionManager() {
	        JpaTransactionManager tm = new JpaTransactionManager();
	        tm.setEntityManagerFactory(entityManagerFactory());
	        return tm;
	    }
}


*/