package com.infocepts.otc.entities;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.SqlResultSetMappings;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.infocepts.otc.utilities.LoadConstant;

@Entity
@Table(catalog=LoadConstant.otc, schema="[dbo]",name="actionItem")
@SqlResultSetMappings({
	@SqlResultSetMapping(
		      name = "actionitem_portfolio",
		      classes = {
		    	@ConstructorResult(
		              targetClass = ActionItem.class,
		              columns = {
		                  
		                  @ColumnResult(name = "projectManagersId"),
		                  @ColumnResult(name = "projectManagersName", type=String.class),
		                  @ColumnResult(name = "ownersId"),
		                  @ColumnResult(name = "accountHead", type=String.class),
		                  @ColumnResult(name = "projectId", type=String.class)
		              }
		          ),
		    	
		      }
		),
	@SqlResultSetMapping(
		      name = "actionitems",
		      classes = {
		    	@ConstructorResult(
		              targetClass = ActionItem.class,
		              columns = {
		                  
		            		  @ColumnResult(name = "actionItemId"),
		            		  @ColumnResult(name = "name", type=String.class),
		            		  @ColumnResult(name = "proposedDate", type=Date.class),
		            		  @ColumnResult(name = "status", type=String.class),
		            		  @ColumnResult(name = "assignedTo", type=String.class),
		            		  @ColumnResult(name = "comments", type=String.class),
		            		  @ColumnResult(name = "createdBy"),
		            		  @ColumnResult(name = "createdDate", type=Date.class),
		            		  @ColumnResult(name = "modifiedBy"),
		            		  @ColumnResult(name = "modifiedDate", type=Date.class),
		            		  @ColumnResult(name = "projectManagersId"),
		            		  @ColumnResult(name = "projectManagersName", type=String.class),
		            		  @ColumnResult(name = "modifiedByUsername", type=String.class),
		            		  @ColumnResult(name = "portfolioId"),
		            		  @ColumnResult(name = "projectId"),
		            		  @ColumnResult(name = "assignedToName", type=String.class),
		            		  @ColumnResult(name = "projectName", type=String.class)
		              }
		          )
		    	
		      }
		)
})

@NamedNativeQueries({
	@NamedNativeQuery(
          name    	=   "getPMs_ForPortfolio",
          query   	=  " select distinct projectManagersId,r.title as projectManagersName,0 as ownersId,NULL as accountHead,projectId" +
      				   " FROM " + LoadConstant.infomaster + ".[dbo].[project] p" +
      				   " left join " + LoadConstant.infomaster + ".[dbo].[portfolio] p1 on p.portfolioId=p1.itemId" +
      				   " left join " + LoadConstant.infomaster + ".[dbo].[resource] r on r.uid=p.projectManagersId" +
      				   " where portfolioId=:portfolioId",
          resultClass	=	ActionItem.class , resultSetMapping = "actionitem_portfolio"
	),
	@NamedNativeQuery(
	          name    	=   "getAHs_ForPortfolio",
	          query   	=  " select distinct ownersId as projectManagersId,r1.title as projectManagersName,0 as ownersId,NULL as accountHead,projectId" +
	      				   " FROM " + LoadConstant.infomaster + ".[dbo].[project] p" +
	      				   " left join " + LoadConstant.infomaster + ".[dbo].[portfolio] p1 on p.portfolioId=p1.itemId" +
	      				   " left join " + LoadConstant.infomaster + ".[dbo].[resource] r1 on r1.uid=p.ownersId" +
	      				   " where portfolioId=:portfolioId",
	          resultClass	=	ActionItem.class , resultSetMapping = "actionitem_portfolio"
	),
	@NamedNativeQuery(
	          name    	= "get_action_items",
	          query   	= "select a.*, "+
		        		  " p.title as projectName, "+
		        		  " p.projectManagersId, "+
		        		  " (select title from " + LoadConstant.infomaster + ".dbo.resource where uid = p.projectManagersId) as projectManagersName, "+
		        		  " (select title from " + LoadConstant.infomaster + ".dbo.resource where uid = a.modifiedBy) as modifiedByUsername "+
		        		  " from actionItem a "+
		        		  " left join " + LoadConstant.infomaster + ".dbo.project p "+
		        		  " on a.projectId = p.itemId "+
		        		  " Where (1 = :all) or (a.portfolioId = :portfolioId) or (charIndex(:assignedToName,assignedToName) <> 0)",
	          resultClass	=	ActionItem.class , resultSetMapping = "actionitems"
		)
 
})
public class ActionItem {

	//Columns
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer actionItemId;
	
	@Lob
	private String name;
	
	private Date proposedDate;
	
	private String status;
	
	private String assignedTo;
	
	@Lob
	private String comments;
	
	private Integer createdBy;	
	
	private Date createdDate;	
	
	private Integer modifiedBy;
	
	private Date modifiedDate;
	
	@Transient
	private Integer projectManagersId;
	
	@Transient
	private String projectManagersName;
	
	@Transient
	private Integer ownersId;
	
	@Transient
	private String accountHead;
	
	@Transient
	private Object[] assignedToArr;
	
	@Transient
	private String modifiedByUsername;
	
	private Integer portfolioId;
	
	private Integer projectId;
	
	private String assignedToName;
	
	@Transient
	private String projectName;
	//End of: Columns
	
	//Getter and Setter
	public Integer getActionItemId() {
		return actionItemId;
	}
	
	public void setActionItemId(Integer actionItemId) {
		this.actionItemId = actionItemId;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public Date getProposedDate() {
		return proposedDate;
	}
	
	public void setProposedDate(Date proposedDate) {
		this.proposedDate = proposedDate;
	}
	
	public String getStatus() {
		return status;
	}
	
	public void setStatus(String status) {
		this.status = status;
	}
	
	public String getAssignedTo() {
		return assignedTo;
	}
	
	public void setAssignedTo(String assignedTo) {
		this.assignedTo = assignedTo;
	}
	
	public String getComments() {
		return comments;
	}
	
	public void setComments(String comments) {
		this.comments = comments;
	}
	
	public Integer getCreatedBy() {
		return createdBy;
	}
	
	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}
	
	public Date getCreatedDate() {
		return createdDate;
	}
	
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	
	public Integer getModifiedBy() {
		return modifiedBy;
	}
	
	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	
	public Date getModifiedDate() {
		return modifiedDate;
	}
	
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	
	public Integer getProjectManagersId() {
		return projectManagersId;
	}
	
	public void setProjectManagersId(Integer projectManagersId) {
		this.projectManagersId = projectManagersId;
	}
	
	public String getProjectManagersName() {
		return projectManagersName;
	}
	
	public void setProjectManagersName(String projectManagersName) {
		this.projectManagersName = projectManagersName;
	}
	
	public Integer getOwnersId() {
		return ownersId;
	}
	
	public void setOwnersId(Integer ownersId) {
		this.ownersId = ownersId;
	}
	
	public String getAccountHead() {
		return accountHead;
	}
	
	public void setAccountHead(String accountHead) {
		this.accountHead = accountHead;
	}
	
	public Object[] getAssignedToArr() {
		return assignedToArr;
	}
	
	public void setAssignedToArr(Object[] assignedToArr) {
		this.assignedToArr = assignedToArr;
	}
	
	public String getModifiedByUsername() {
		return modifiedByUsername;
	}
	
	public void setModifiedByUsername(String modifiedByUsername) {
		this.modifiedByUsername = modifiedByUsername;
	}
	
	public Integer getPortfolioId() {
		return portfolioId;
	}
	
	public void setPortfolioId(Integer portfolioId) {
		this.portfolioId = portfolioId;
	}
	
	public Integer getProjectId() {
		return projectId;
	}
	
	public void setProjectId(Integer projectId) {
		this.projectId = projectId;
	}

	public String getAssignedToName() {
		return assignedToName;
	}

	public void setAssignedToName(String assignedToName) {
		this.assignedToName = assignedToName;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	//End of: Getter and Setter

	//Constructor
	public ActionItem() {
		
	}
	
	public ActionItem(Integer projectManagersId, String projectManagersName, Integer ownersId, String accountHead,
			Integer projectId) {
		super();
		this.projectManagersId = projectManagersId;
		this.projectManagersName = projectManagersName;
		this.ownersId = ownersId;
		this.accountHead = accountHead;
		this.projectId = projectId;
	}

	public ActionItem(Integer actionItemId, String name, Date proposedDate, String status, String assignedTo,
			String comments, Integer createdBy, Date createdDate, Integer modifiedBy, Date modifiedDate,
			Integer projectManagersId, String projectManagersName, String modifiedByUsername, Integer portfolioId,
			Integer projectId, String assignedToName, String projectName) {
		super();
		this.actionItemId = actionItemId;
		this.name = name;
		this.proposedDate = proposedDate;
		this.status = status;
		this.assignedTo = assignedTo;
		this.comments = comments;
		this.createdBy = createdBy;
		this.createdDate = createdDate;
		this.modifiedBy = modifiedBy;
		this.modifiedDate = modifiedDate;
		this.projectManagersId = projectManagersId;
		this.projectManagersName = projectManagersName;
		this.modifiedByUsername = modifiedByUsername;
		this.portfolioId = portfolioId;
		this.projectId = projectId;
		this.assignedToName = assignedToName;
		this.projectName = projectName;
	}
	
	
	//End of: Constructor
	
	
}
