package com.infocepts.otc.controllers;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.infocepts.otc.entities.Month;
import com.infocepts.otc.repositories.MonthRepository;
import com.infocepts.otc.services.TimesheetService;

@RestController
@RequestMapping(value="/month",headers="referer")
public class MonthController {
	
	final Logger logger = Logger.getLogger(MonthController.class.getName());
	
	@Autowired
	MonthRepository repository;
	
	@Autowired
	TimesheetService service;
	
	@RequestMapping(method=RequestMethod.POST)
	public Month addMonth(@RequestBody Month month)
	{
		try{
			if(service.isPmo()){
				month.setMonthId(null);
				repository.save(month);	
			}
		}catch(Exception e){
			logger.info(String.format("exception - ", e));
		}
		return month;
	}	
 
	 @RequestMapping(method=RequestMethod.GET)
	 public List<Month> getAllMonth(@RequestParam(value="yearId", defaultValue="0") Integer yearId,
			 						@RequestParam(value="startMonth", defaultValue="") String startMonth,
			 						@RequestParam(value="endMonth", defaultValue="") String endMonth,
	 								@RequestParam(value="startDate", defaultValue="") String startDate,
	 								@RequestParam(value="endDate", defaultValue="") String endDate){
		 List<Month> monthlist=null;
		 try{
			 	//visible to all permissions
			 	if(yearId!=0)
				 {
					 if( (!("").equals(startMonth)) && (!("").equals(endMonth)))
					 {
						 Integer strtmonth=service.getMonth(startMonth);
						 Integer endmnth=service.getMonth(endMonth);
						 monthlist = repository.findMonthsBetweenStartAndEndMonth(yearId, strtmonth, endmnth);
					 }
					 else if( !("").equals(startDate) &&  !("").equals(endDate))//To get all the months between Start and End date
					 {
						 monthlist = repository.findMonthsBetweenStartAndEndDate(startDate, endDate);
					 }
					 else
					 {
						 monthlist = repository.findByYearId(yearId);
					 }	
				 }
			 	 else{
					 monthlist = repository.findAll();
				 }
		 }
		 catch(Exception e){
			 logger.info(String.format("exception - ", e));
		 }
		 return monthlist;
	 }
	 
	 @RequestMapping(value="/{monthId}",method=RequestMethod.GET)
	 public Month getMonth(@PathVariable Integer monthId){
		 Month month=null;
		 try{
			 //if(service.isPmo()){ // rkj month to be accessible to all
				 month = repository.findOne(monthId);
			 //}
		 }
		 catch(Exception e){
			 logger.info(String.format("exception - ", e));
		 }
		 return month;
	 }
	 
	 @RequestMapping(value="/{monthId}",method=RequestMethod.PUT)
	 public Month updateMonth(@RequestBody Month updatedMonth,@PathVariable Integer monthId){
		 try{
			 if(service.isPmo()){
				 updatedMonth.setMonthId(monthId);
				 repository.save(updatedMonth);
			 }
		 }
		 catch(Exception e){
			 logger.info(String.format("exception - ", e));
		 }
		 return updatedMonth;
	 }
	 
	 @RequestMapping(value="/{monthId}",method=RequestMethod.DELETE)
	 public void deleteMonth(@PathVariable Integer monthId){
		 try{
			 if(service.isPmo()){
				 repository.delete(monthId);
			 }
		 }
		 catch(Exception e){
			 logger.info(String.format("exception - ", e));
		 }
	 }	
	 
	 @GetMapping("/getMonthsforYearId")
		public List<Month> getMonthsforYearId(@RequestParam(value="yearId", defaultValue="0") Integer yearId,
											HttpServletRequest request) {
		 	List<Month> monthlist=null;
		 	 try{
		 		 monthlist = repository.findByYearId(yearId);
		 	 } catch(Exception e){
				 logger.info(String.format("exception - ", e));
			 }
			return monthlist;

		}
	 
	 
	 @GetMapping("/getMonthById")
		public Object getMonthById(@RequestParam(value = "monthId", defaultValue = "0") Integer monthId,
										  HttpServletRequest request){
		 	Month month=null;
			try{
				month = repository.findOne(monthId);
			}catch(Exception e){
				logger.log(Level.SEVERE, "exceptn msg", e);
			}
			return month;
		}
}
