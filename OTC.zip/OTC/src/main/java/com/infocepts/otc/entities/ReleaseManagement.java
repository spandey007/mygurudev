/**
* Filename: /src/main/java/com/infocepts/otc/entities/ReleaseManagement.java
* @author  Anjali S. Kalbande
* @version 1.0
* @since   2018-01-08 
*/

package com.infocepts.otc.entities;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.persistence.*;
import javax.validation.constraints.NotNull;

import com.infocepts.otc.utilities.LoadConstant;	
	@Entity
	@Table(catalog=LoadConstant.otc, schema="[dbo]", name="release")
	@SqlResultSetMappings({
	        @SqlResultSetMapping(
	                name = "release_info",
	                classes = {
	                        @ConstructorResult(
	                                targetClass = ReleaseManagement.class,
	                                columns = {
	                                		@ColumnResult(name = "releaseId"),
											@ColumnResult(name = "releaseName", type = String.class),
	                                        @ColumnResult(name = "releaseDate", type = Date.class),   
	                                        @ColumnResult(name = "status", type = String.class),  
	                                        @ColumnResult(name = "hideOnFrontEnd", type = Boolean.class),
											@ColumnResult(name = "comments",type = String.class),
											@ColumnResult(name = "createdBy"),										
	                                        @ColumnResult(name = "createdDate", type = Date.class),
											@ColumnResult(name = "modifiedBy"),
	                                        @ColumnResult(name = "modifiedDate", type = Date.class),                                      
	                                		@ColumnResult(name = "releaseType", type = String.class),
	                                		@ColumnResult(name = "epic", type = String.class),
	                                		@ColumnResult(name = "isRoadMap", type = String.class),
	                                		@ColumnResult(name = "createdByName", type = String.class)
	                                }
	                        )
	                }
	        )
	})	
	@NamedNativeQueries({
	        @NamedNativeQuery(
	                name    =   "getRelease_ReleaseManagement_All",   
//	                query 	=   "Select * from " + LoadConstant.otc + ".[dbo].Release ",	 
//								resultClass=ReleaseManagement.class, resultSetMapping = "release_info"
								
					query	=	"select rm.* ,"+ "r.title as createdByName"+
								" from "+ LoadConstant.otc +".[dbo].[release] rm "+ 
								"inner join " + LoadConstant.infomaster +".[dbo].[resource] r on rm.createdBy = r.uid",
								resultClass=ReleaseManagement.class, resultSetMapping = "release_info"
	        )        
	})
	public class ReleaseManagement {

		// Entity Columns
	    // --------------------------------------------------------------------------------
	    @Id
	    @GeneratedValue(strategy=GenerationType.IDENTITY)
	    private Integer releaseId; 	
	    
	    private String releaseName;
	    private Date releaseDate;    
	    private String status; 
	    private Boolean hideOnFrontEnd;
	    
	    @Lob
	    private String comments;// to store big text or notes	

		 // Audit Trail columns 
	    // --------------------------------------------------------------------------------
		private Integer createdBy;    
	    private Date createdDate;
	    private Integer modifiedBy;
	    private Date modifiedDate;
	    private String releaseType;
	    private String epic;
	    private String isRoadMap;
	
	    @Transient
	    private String createdByName;
	    
	    // Getter setter
		// --------------------------------------------------------------------------------		
		public Integer getReleaseId() {
			return releaseId;
		}

		public void setReleaseId(Integer releaseid) {
			this.releaseId = releaseid;
		}

		public String getReleaseName() {
			return releaseName;
		}

		public void setReleaseName(String releaseName) {
			this.releaseName = releaseName;
		}

		public Date getReleaseDate() {
			return releaseDate;
		}

		public void setReleaseDate(Date releaseDate) {
			this.releaseDate = releaseDate;
		}

		public String getStatus() {
			return status;
		}

		public void setStatus(String status) {
			this.status = status;
		}

		public Boolean getHideOnFrontEnd() {
			return hideOnFrontEnd;
		}

		public void setHideOnFrontEnd(Boolean hideOnFrontEnd) {
			this.hideOnFrontEnd = hideOnFrontEnd;
		}

		public String getComments() {
			return comments;
		}

		public void setComments(String comments) {
			this.comments = comments;
		}

		public Integer getCreatedBy() {
			return createdBy;
		}

		public void setCreatedBy(Integer createdBy) {
			this.createdBy = createdBy;
		}

		public Date getCreatedDate() {
			return createdDate;
		}

		public void setCreatedDate(Date createdDate) {
			this.createdDate = createdDate;
		}

		public Integer getModifiedBy() {
			return modifiedBy;
		}

		public void setModifiedBy(Integer modifiedBy) {
			this.modifiedBy = modifiedBy;
		}

		public Date getModifiedDate() {
			return modifiedDate;
		}

		public void setModifiedDate(Date modifiedDate) {
			this.modifiedDate = modifiedDate;
		}

		public String getCreatedByName() {
			return createdByName;
		}

		public void setCreatedByName(String createdByName) {
			this.createdByName = createdByName;
		}	

		public String getReleaseType() {
			return releaseType;
		}

		public void setReleaseType(String releaseType) {
			this.releaseType = releaseType;
		}

		public String getEpic() {
			return epic;
		}

		public void setEpic(String epic) {
			this.epic = epic;
		}

		public String getIsRoadMap() {
			return isRoadMap;
		}

		public void setIsRoadMap(String isRoadMap) {
			this.isRoadMap = isRoadMap;
		}

		// Constructor
		// ---------------------------------------------------------------------------------
		public ReleaseManagement() {
			//super();
			// TODO Auto-generated constructor stub
		}

		// Constructor using fields
		// ---------------------------------------------------------------------------------
		public ReleaseManagement(Integer releaseId, String releaseName, Date releaseDate, String status,
				Boolean hideOnFrontEnd, String comments, Integer createdBy, Date createdDate, Integer modifiedBy,
				Date modifiedDate, String releaseType, String epic, String isRoadMap, String createdByName) {
			
			this.releaseId = releaseId;
			this.releaseName = releaseName;
			this.releaseDate = releaseDate;
			this.status = status;
			this.hideOnFrontEnd = hideOnFrontEnd;
			this.comments = comments;
			this.createdBy = createdBy;
			this.createdDate = createdDate;
			this.modifiedBy = modifiedBy;
			this.modifiedDate = modifiedDate;
			this.releaseType = releaseType;
			this.epic = epic;
			this.isRoadMap = isRoadMap;
			this.createdByName = createdByName;
		}	
		
		
}
