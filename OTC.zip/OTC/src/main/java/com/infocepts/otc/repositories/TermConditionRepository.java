package com.infocepts.otc.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;


import com.infocepts.otc.entities.TermCondition;


public interface TermConditionRepository extends CrudRepository<TermCondition,Integer>{

	@Override
	public List<TermCondition> findAll();
	
	@Query("select p from TermCondition p where p.termId=:termId")
	public List<TermCondition> findByTermId(@Param("termId") Integer termId);
	
}
