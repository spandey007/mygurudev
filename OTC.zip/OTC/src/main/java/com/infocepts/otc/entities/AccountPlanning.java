package com.infocepts.otc.entities;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.SqlResultSetMappings;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.infocepts.otc.utilities.LoadConstant;

@Entity
@Table(catalog=LoadConstant.otc, schema="[dbo]",name="accountPlanning")
@SqlResultSetMapping(
            name = "account_planning_list",
            classes = {
                    @ConstructorResult(
                            targetClass = AccountPlanning.class,
                            columns = {
                             		
                            		@ColumnResult(name = "accountPlanningId"),
                            		@ColumnResult(name = "accountId"),
                            		@ColumnResult(name = "month"),
                            		@ColumnResult(name = "year"),      
                            		@ColumnResult(name = "revenue"),
                            		@ColumnResult(name = "currencyId"),                            		
                            		@ColumnResult(name = "createdBy"),
                            		@ColumnResult(name = "createdDate", type = Date.class),
                            		@ColumnResult(name = "modifiedBy"),
                            		@ColumnResult(name = "modifiedDate", type = Date.class),
                            		@ColumnResult(name = "accountNo", type = String.class),
                            		@ColumnResult(name = "accountShortName", type = String.class),
                            		@ColumnResult(name = "dmName", type = String.class),
                            		@ColumnResult(name = "rmName", type = String.class),
                            		@ColumnResult(name = "currencySign", type = String.class)
                            }
                    )
            }
    )
@NamedNativeQueries({
    @NamedNativeQuery(
            name  = "getAccountPlanning",                
            query = "SELECT ap.*,"+
            		" a.accountNo,"+
            		" a.accountShortName,"+
            		" cast(rDm.title as VARCHAR (max)) as dmName,"+
            		" cast(rRm.title as VARCHAR (max)) as rmName,"+
            		" cast(cur.sign as VARCHAR (max)) as currencySign"+
            		" FROM " + LoadConstant.otc + ".[dbo].[accountPlanning] ap "+ 
            		" LEFT JOIN  " + LoadConstant.infomaster + ".[dbo].[accounts] a on ap.accountId=a.itemId"+
            		" LEFT JOIN  " + LoadConstant.infomaster + ".[dbo].[resource] rDm on rDm.uid =a.dmId"+
            		" LEFT JOIN  " + LoadConstant.infomaster + ".[dbo].[resource] rRm on rRm.uid =a.rmId"+
            		" LEFT JOIN  " + LoadConstant.infomaster + ".[dbo].[currency] cur on cur.currencyId = ap.currencyId"+
            		" where ap.year=:year and "+
            		" ((:accountId != 0 and a.itemId = :accountId) or (:cepId != 0 and a.rmId = :cepId) or (:phId != 0 and a.dmId = :phId) or (:accountId = 0 and :cepId = 0 and :phId = 0))",
            resultClass=AccountPlanning.class, resultSetMapping = "account_planning_list"
    )
    
})
public class AccountPlanning {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	public Integer accountPlanningId;
	public Integer accountId;
	public Integer month;
	public Integer year;
	public BigDecimal revenue;
	public Integer currencyId;
	public Integer createdBy;
	public Date createdDate;
	private Integer modifiedBy;
	private Date modifiedDate;
	
    // Transient Variables
    // --------------------------------------------------------------------------------
	
	@Transient
    private String accountNo;
	
	@Transient
    private String accountShortName;
	
    @Transient
    private String dmName;
    
    @Transient
    private String rmName;

    @Transient
    private String currencySign;
    
    
	public Integer getAccountPlanningId() {
		return accountPlanningId;
	}
	public void setAccountPlanningId(Integer accountPlanningId) {
		this.accountPlanningId = accountPlanningId;
	}
	public Integer getAccountId() {
		return accountId;
	}
	public void setAccountId(Integer accountId) {
		this.accountId = accountId;
	}
	public Integer getMonth() {
		return month;
	}
	public void setMonth(Integer month) {
		this.month = month;
	}
	public Integer getYear() {
		return year;
	}
	public void setYear(Integer year) {
		this.year = year;
	}
	public BigDecimal getRevenue() {
		return revenue;
	}
	public void setRevenue(BigDecimal revenue) {
		this.revenue = revenue;
	}
	public Integer getCurrencyId() {
		return currencyId;
	}
	public void setCurrencyId(Integer currencyId) {
		this.currencyId = currencyId;
	}
	public Integer getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public Integer getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public Date getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	
	
	public String getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	public String getAccountShortName() {
		return accountShortName;
	}
	public void setAccountShortName(String accountShortName) {
		this.accountShortName = accountShortName;
	}
	public String getDmName() {
		return dmName;
	}
	public void setDmName(String dmName) {
		this.dmName = dmName;
	}
	public String getRmName() {
		return rmName;
	}
	public void setRmName(String rmName) {
		this.rmName = rmName;
	}
	public String getCurrencySign() {
		return currencySign;
	}
	public void setCurrencySign(String currencySign) {
		this.currencySign = currencySign;
	}
	public AccountPlanning() {
		super();
	}
	public AccountPlanning(Integer accountPlanningId, Integer accountId, Integer month, Integer year,
			BigDecimal revenue, Integer currencyId, Integer createdBy, Date createdDate, Integer modifiedBy,
			Date modifiedDate, String accountNo, String accountShortName,String dmName, String rmName, String currencySign) {
		super();
		this.accountPlanningId = accountPlanningId;
		this.accountId = accountId;
		this.month = month;
		this.year = year;
		this.revenue = revenue;
		this.currencyId = currencyId;
		this.createdBy = createdBy;
		this.createdDate = createdDate;
		this.modifiedBy = modifiedBy;
		this.modifiedDate = modifiedDate;
		this.accountNo = accountNo;
		this.accountShortName = accountShortName;		
		this.dmName = dmName;
		this.rmName = rmName;
		this.currencySign = currencySign;
	}
	
	
}
