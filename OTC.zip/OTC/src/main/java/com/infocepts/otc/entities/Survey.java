/**
* Filename: /src/main/java/com/infocepts/otc/entities/Survey.java
* @author  Anjali S. Kalbande
* @version 1.0
* @since   2019-06-03 
*/
package com.infocepts.otc.entities;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.persistence.*;
import javax.validation.constraints.NotNull;

import com.infocepts.otc.utilities.LoadConstant;
@Entity
@Table(catalog=LoadConstant.otc, schema="[dbo]", name="survey")

@SqlResultSetMappings({
        @SqlResultSetMapping(
                name = "surveyList",
                classes = {
                        @ConstructorResult(
                                targetClass = Survey.class,
                                columns = {
                                		@ColumnResult(name = "surveyId"),
										@ColumnResult(name = "title", type = String.class),
                                        @ColumnResult(name = "surveyStartDate", type = Date.class),   
                                        @ColumnResult(name = "surveyEndDate", type = Date.class),  
                                        @ColumnResult(name = "status", type = String.class),
										@ColumnResult(name = "reminderEvent"),
										@ColumnResult(name = "url", type = String.class),										
										@ColumnResult(name = "emailNotification", type = String.class),
                                        @ColumnResult(name = "description", type = String.class),
										@ColumnResult(name = "emailSubject", type = String.class),
                                        @ColumnResult(name = "fromEmail", type = String.class),
										@ColumnResult(name = "emailSignature", type = String.class),
										@ColumnResult(name = "emailNote", type = String.class),
										@ColumnResult(name = "emailHeader", type = String.class),
										@ColumnResult(name = "eligibleForSurvey"),	
										@ColumnResult(name = "createdBy"),
										@ColumnResult(name = "createdDate", type = Date.class),
										@ColumnResult(name = "modifiedBy"),
										@ColumnResult(name = "modifiedDate", type = Date.class),
										@ColumnResult(name = "createdByName", type = String.class)
                                }
                        )
                }
        )
})
@NamedNativeQueries({
        @NamedNativeQuery(
                name    =   "getAllSurvey",   
                query 	=   "Select sr.* ,"+ "r.title as createdByName "+
							"from " + LoadConstant.otc + ".[dbo].Survey as sr " +
							"inner join " + LoadConstant.infomaster +".[dbo].[resource] r on sr.createdBy = r.uid "+
							"where sr.status In (:status)",
							resultClass=Survey.class, resultSetMapping = "surveyList"
        )        
})
public class Survey {
	
	// Entity Columns
	@Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Integer surveyId; 	
	
	private String title;
	private Date surveyStartDate;
	private Date surveyEndDate;
	private String status;
	private Integer reminderEvent;
	private String url;
	private String emailNotification;
	
	@Lob
	private String description;
	
	private String emailSubject;
	private String fromEmail;
	private String emailSignature;
	private String emailNote;
	private String emailHeader;
	private Integer eligibleForSurvey;
	private Integer createdBy;
	private Date createdDate;
	private Integer modifiedBy;
	private Date modifiedDate;
	
	@Transient
	private String createdByName;
	
	// Getter setter
	public Integer getSurveyId() {
		return surveyId;
	}
	public void setSurveyId(Integer surveyId) {
		this.surveyId = surveyId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public Date getSurveyStartDate() {
		return surveyStartDate;
	}
	public void setSurveyStartDate(Date surveyStartDate) {
		this.surveyStartDate = surveyStartDate;
	}
	public Date getSurveyEndDate() {
		return surveyEndDate;
	}
	public void setSurveyEndDate(Date surveyEndDate) {
		this.surveyEndDate = surveyEndDate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Integer getReminderEvent() {
		return reminderEvent;
	}
	public void setReminderEvent(Integer reminderEvent) {
		this.reminderEvent = reminderEvent;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getEmailNotification() {
		return emailNotification;
	}
	public void setEmailNotification(String emailNotification) {
		this.emailNotification = emailNotification;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getEmailSubject() {
		return emailSubject;
	}
	public void setEmailSubject(String emailSubject) {
		this.emailSubject = emailSubject;
	}
	public String getFromEmail() {
		return fromEmail;
	}
	public void setFromEmail(String fromEmail) {
		this.fromEmail = fromEmail;
	}
	public String getEmailSignature() {
		return emailSignature;
	}
	public void setEmailSignature(String emailSignature) {
		this.emailSignature = emailSignature;
	}
	public String getEmailNote() {
		return emailNote;
	}
	public void setEmailNote(String emailNote) {
		this.emailNote = emailNote;
	}
	public String getEmailHeader() {
		return emailHeader;
	}
	public void setEmailHeader(String emailHeader) {
		this.emailHeader = emailHeader;
	}
	public Integer geteligibleForSurvey() {
		return eligibleForSurvey;
	}
	public void seteligibleForSurvey(Integer eligibleForSurvey) {
		this.eligibleForSurvey = eligibleForSurvey;
	}
	public Integer getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public Integer getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public Date getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}	
	public String getCreatedByName() {
		return createdByName;
	}
	public void setCreatedByName(String createdByName) {
		this.createdByName = createdByName;
	}
	
	// Constructor
	public Survey() {
		
	}
	
	// Constructor using fields
	public Survey(Integer surveyId, String title, Date surveyStartDate, Date surveyEndDate, String status,
			Integer reminderEvent, String url, String emailNotification, String description, String emailSubject,
			String fromEmail, String emailSignature, String emailNote, String emailHeader, Integer eligibleForSurvey,
			Integer createdBy, Date createdDate, Integer modifiedBy, Date modifiedDate, String createdByName) {
		
		this.surveyId = surveyId;
		this.title = title;
		this.surveyStartDate = surveyStartDate;
		this.surveyEndDate = surveyEndDate;
		this.status = status;
		this.reminderEvent = reminderEvent;
		this.url = url;
		this.emailNotification = emailNotification;
		this.description = description;
		this.emailSubject = emailSubject;
		this.fromEmail = fromEmail;
		this.emailSignature = emailSignature;
		this.emailNote = emailNote;
		this.emailHeader = emailHeader;
		this.eligibleForSurvey = eligibleForSurvey;
		this.createdBy = createdBy;
		this.createdDate = createdDate;
		this.modifiedBy = modifiedBy;
		this.modifiedDate = modifiedDate;
		this.createdByName = createdByName;
	}	

}
