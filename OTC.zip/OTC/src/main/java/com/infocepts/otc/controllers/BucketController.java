package com.infocepts.otc.controllers;

import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.infocepts.otc.entities.Bucket;
import com.infocepts.otc.repositories.BucketRepository;
import com.infocepts.otc.services.TimesheetService;


@RestController
@RequestMapping(value="/bucket",headers="referer")
public class BucketController {

	@Autowired
	BucketRepository repository;
	
	@Autowired
	TimesheetService service;
	
	final Logger logger = Logger.getLogger(BucketController.class);
	
	
	@RequestMapping(method=RequestMethod.POST)
	public Bucket saveBucket(@RequestBody Bucket bucket){
		try{
			if(service.isAMG()){
				bucket.setBucketId(null);
				repository.save(bucket);
			}
		}
		catch(Exception e){
			logger.error(e);
		}
		return bucket;
	}
	
	@RequestMapping(method=RequestMethod.GET)
	public List<Bucket> getBucket(){
		List<Bucket> bucketList=null;
		try
		{
			bucketList = repository.findAll();
		}
		catch(Exception e){
			logger.error(e);
		}
		return bucketList;
	}
	
	@RequestMapping(value="/{bucketId}",method=RequestMethod.PUT)
	public void updateBucket(@PathVariable Integer bucketId,@RequestBody Bucket updatedbucket){
		try{
			if(service.isAMG()){
				updatedbucket.setBucketId(bucketId);
				repository.save(updatedbucket);
			}
		}
		catch(Exception e){
			logger.error(e);
		}
	}
	
	@RequestMapping(value="/{bucketId}",method=RequestMethod.DELETE)
	public void deleteBucket(@PathVariable Integer bucketId){
			try{
				if(service.isAMG()){
					repository.delete(bucketId);
				}
			}
			catch(Exception e){
				logger.error(e);
			}
	}
	
}
