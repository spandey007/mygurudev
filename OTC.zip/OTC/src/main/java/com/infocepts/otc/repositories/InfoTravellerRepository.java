package com.infocepts.otc.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.infocepts.otc.entities.BusRouteTimings;
import com.infocepts.otc.entities.InfoTraveller;

public interface InfoTravellerRepository extends CrudRepository<InfoTraveller,Integer>{

	@Override
	public List<InfoTraveller> findAll();	
	
	@Query("from InfoTraveller where infoTravelId = :infoTravelId order by empId asc")
	public List<InfoTraveller> findById(@Param(value="infoTravelId") Integer infoTravelId);
	
}


