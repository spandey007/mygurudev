/**
* Filename: /src/main/java/com/infocepts/otc/repositories/CoeRepository.java
* @author  AA
* @version 1.0
* @since   2019-05-01 
*/
package com.infocepts.otc.repositories;
import java.util.List;
import org.springframework.data.repository.CrudRepository;
import com.infocepts.otc.entities.Coe;

public interface CoeRepository extends CrudRepository<Coe,Integer>{

	@Override
	public List<Coe> findAll();	
	
}