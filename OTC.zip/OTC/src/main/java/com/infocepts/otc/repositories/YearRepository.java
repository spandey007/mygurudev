/* 
 * Year Repository to manage years
 * -------------------------------------------------------------------------------------------------------------------------
 * 31 Aug 2017 - VK creation of the file
 * 7 Sept 2017 - RK review modification for a reference master
*/
package com.infocepts.otc.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.infocepts.otc.entities.Year;

public interface YearRepository extends CrudRepository<Year,Integer>{

	@Override
	public List<Year> findAll();
	
	@Query("select y from Year y where y.status = :status")
	public List<Year> findByYearStatus(@Param(value = "status") Boolean status);

	@Query("select y from Year y where y.yearId = :yearId order by y.year")
	public List<Year> findByYearId(@Param(value="yearId") Integer yearId);

	@Query("select y from Year y where y.year = :year")
	public List<Year> findByYear(@Param(value="year") Integer year);
}
