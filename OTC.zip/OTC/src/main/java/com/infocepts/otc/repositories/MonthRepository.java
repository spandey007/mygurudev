package com.infocepts.otc.repositories;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.infocepts.otc.entities.Month;
import com.infocepts.otc.utilities.LoadConstant;

public interface MonthRepository extends CrudRepository<Month,Integer>{
	
	public List<Month> findAll();
	
	@Query("select m from Month m where m.year.yearId = :yearId order by m.monthNo")
	public List<Month> findByYearId(@Param(value = "yearId") Integer yearId);

	@Query("select m from Month m where m.year.yearId = :yearId and monthNo >= :startMonth and monthNo <= :endMonth  order by monthNo")
	public List<Month> findMonthsBetweenStartAndEndMonth(@Param(value = "yearId") Integer yearId,@Param(value = "startMonth") Integer startMonth,@Param(value = "endMonth") Integer endMonth);
	
	@Query(value = "select * from "+LoadConstant.infomaster+".dbo.Month m where convert(date,m.monthStartDate) >= :startDate and  convert(date,m.monthEndDate) <= :endDate order by monthNo", nativeQuery = true)
	public List<Month> findMonthsBetweenStartAndEndDate(@Param(value = "startDate") String startDate,@Param(value = "endDate") String endDate);

}
