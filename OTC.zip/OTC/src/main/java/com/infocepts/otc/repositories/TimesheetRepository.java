package com.infocepts.otc.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.infocepts.otc.entities.Timesheet;



@Repository
public interface TimesheetRepository extends JpaRepository<Timesheet,Integer>{
	
	@Override
	public List<Timesheet> findAll();
	
	@Query("select ts FROM Timesheet ts where ts.periodId = :periodId AND ts.uid = :uid")
	public List<Timesheet> findTimesheetsByPeriodByUser(@Param("periodId") Integer periodId, @Param("uid") Integer uid);
}
