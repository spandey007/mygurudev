package com.infocepts.otc.controllers;

import java.util.List;

import javax.mail.MessagingException;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.infocepts.otc.entities.Reports;
import com.infocepts.otc.repositories.ReportsRepository;
import com.infocepts.otc.services.TimesheetService;


@RestController
@RequestMapping(value="/reports",headers="referer")
public class ReportsController {

	@Autowired
	ReportsRepository repository;
	
	@PersistenceContext(unitName="otc")
    private EntityManager manager;
	
	@Autowired
	TimesheetService service;
	
	final Logger logger = Logger.getLogger(ReportsController.class);
	
	@RequestMapping(method=RequestMethod.GET)
	public List<Reports> getReports(@RequestParam(name="reportId",defaultValue="0") Integer reportId
								,@RequestParam(name="roleAccess",defaultValue="") String roleAccess
								,HttpServletRequest request){
		
		List<Reports> ReportsList=null;
		
		try{	
			if(!roleAccess.equals("")){
				ReportsList = repository.findReportsByRoleAccess(roleAccess);
			}
			else 
			{
				ReportsList = repository.findAll();
			}
		
	
		}catch(Exception e){
			 logger.error(e);
		 }
			return ReportsList;
		}
	
	
	
	 @RequestMapping(value="/{reportId}",method=RequestMethod.GET)
	 public Reports getReportsById(@PathVariable Integer reportId, HttpServletRequest request){
		 
		 Reports report=null;
		 try{	
			 /* ------------------------- Authorization start ------------------------------------ */
				// Authorization for admin role
				if(service.isAdmin())
				{
					report = repository.findOne(reportId);
				}
				else
				{
					service.sendTamperedMail("Report By report Id", 0, 0, request);
				}
				/* ------------------------- Authorization ends ------------------------------------ */
			 
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return report;
	 }
	 
	
	 @RequestMapping(method=RequestMethod.POST)
	public Reports addReports(@RequestBody Reports reports, HttpServletRequest request) throws MessagingException
	{
		try{
			if(service.isAdmin())
			{
				reports.setReportId(null);
				repository.save(reports);	
			}
			else
			{
				service.sendTamperedMail("Add Report", 0, 0, request);
			}

		}catch(Exception e){
			logger.error(e);
		}
		return reports;
	}	


	@RequestMapping(value="/{reportId}",method=RequestMethod.DELETE)
	 public void deleteReport(@PathVariable Integer reportId, HttpServletRequest request){
		 try{
			 if(service.isAdmin())
			 {
				 repository.delete(reportId);
			 }
			 else
			 {
				service.sendTamperedMail("Delete Report", 0, 0, request);
			 } 
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
	 }	 
	
	 @RequestMapping(value="/{reportId}",method=RequestMethod.PUT)
	 public Reports updateReports(@RequestBody Reports updatedReports,@PathVariable Integer reportId, HttpServletRequest request){
		 try{
			 if(service.isAdmin())
			 {
				 updatedReports.setReportId(reportId);
				 repository.save(updatedReports);
			 }
			 else
			 {
				service.sendTamperedMail("Update Report", 0, 0, request);
			 } 
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return updatedReports;
	 }
	
}
