package com.infocepts.otc.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.SqlResultSetMappings;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.Constraint;
import javax.validation.constraints.NotNull;

import com.infocepts.otc.utilities.LoadConstant;

@Entity
@Table(catalog=LoadConstant.infomaster,schema="[dbo]",name="holiday")

@SqlResultSetMappings({
@SqlResultSetMapping(
	      name = "holidays_by_region",
	      classes = {
	    	@ConstructorResult(
	              targetClass = Holidays.class,
	              columns = {
	                  @ColumnResult(name = "holidayId"),
	                  @ColumnResult(name = "title", type=String.class),
	                  //@ColumnResult(name = "HolidayScheduleId", type=Integer.class),
	                  @ColumnResult(name = "HolidayScheduleText", type=String.class),
	                  @ColumnResult(name = "modifiedDate", type=Date.class),
	                  @ColumnResult(name = "createdDate", type=Date.class),
	                       
	              }
	          )
	      }
	),
	@SqlResultSetMapping(
		      name = "get_all_holidays",
		      classes = {
		    	@ConstructorResult(
		              targetClass = Holidays.class,
		              columns = {
		                  @ColumnResult(name = "date", type=Date.class),
		                  @ColumnResult(name = "countryId", type=Integer.class)
		                       
		              }
		          )
		      }
	),
	@SqlResultSetMapping(
		      name = "get_holidays_for_period",
		      classes = {
		    	@ConstructorResult(
		              targetClass = Holidays.class,
		              columns = {
		                  @ColumnResult(name = "date", type=Date.class)
		                  ,@ColumnResult(name = "title", type=String.class)
		                       
		              }
		          )
		      }
	)
})
@NamedNativeQueries({
	 @NamedNativeQuery(
	            name    	=   "getHolidaysByRegion",
	            query   	=   "select h.holidayId, cast(h.title as varchar) as title, hs.title as HolidayScheduleText, h.modifiedDate, h.createdDate" + 
								" FROM "+ LoadConstant.infomaster +".[dbo].holiday h"+
								" left join "+ LoadConstant.infomaster +".[dbo].holidaySchedules hs on hs.holidayScheduleId = h.holidayScheduleId"+
								" where h.holidayScheduleId = :country",
								resultClass = Holidays.class ,  resultSetMapping = "holidays_by_region"                          
	    ),
	 @NamedNativeQuery(
	            name    	=   "getAllHolidays",
	            query   	=   "select obj_holiday.date, obj_holidayschedule.countryId "+
	            				" from " + LoadConstant.infomaster + ".dbo.holiday obj_holiday "+
			            		"left join " + LoadConstant.infomaster + ".dbo.holidayschedules obj_holidayschedule "+
			            		"on "+
			            		"obj_holiday.holidayScheduleId = obj_holidayschedule.holidayScheduleId "+
			            		"where year(obj_holiday.date) > year(getDate())-2",
								resultClass = Holidays.class ,  resultSetMapping = "get_all_holidays"                          
	    ),
	 @NamedNativeQuery(
	            name    	=   "getHolidaysForUserInSelectedPeriod",
	            query   	=   " select h.date,h.title from " + LoadConstant.infomaster + ".dbo.holiday h"+
								" where holidayScheduleId = (select holidayScheduleId from " + LoadConstant.infomaster + ".dbo.resource where uid = :uid)"+ 
								" and cast(h.date as DATE) >= :periodStart and cast(h.date as DATE) <= :periodEnd ;",
								resultClass = Holidays.class ,  resultSetMapping = "get_holidays_for_period"                          
	    )
})
public class Holidays {

	//Columns
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer holidayId;
	private String title;
	private Date date;
	
	@ManyToOne
	@JoinColumn(name="holidayScheduleId")
	private HolidaySchedules holidaySchedules;
	
	private Date createdDate;
	private Date modifiedDate;
	private Integer createdBy;
	private Integer modifiedBy;
	
	@Transient
	private String HolidayScheduleText;
	
	@Transient
	private Integer countryId;
	
	//End of: Columns
	
	//Getter and Setter
	
	public Integer getHolidayId() {
		return holidayId;
	}
	public String getHolidayScheduleText() {
		return HolidayScheduleText;
	}
	public void setHolidayScheduleText(String holidayScheduleText) {
		HolidayScheduleText = holidayScheduleText;
	}
	public Integer getCountryId() {
		return countryId;
	}
	public void setCountryId(Integer countryId) {
		this.countryId = countryId;
	}
	public void setHolidayId(Integer holidayId) {
		this.holidayId = holidayId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public HolidaySchedules getHolidaySchedules() {
		return holidaySchedules;
	}
	public void setHolidaySchedules(HolidaySchedules holidaySchedules) {
		this.holidaySchedules = holidaySchedules;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public Date getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public Integer getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}
	public Integer getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	
	public Holidays(){
		
		
	}
		
	public Holidays(Integer holidayId, String title,String HolidayScheduleText,Date modifiedDate, Date createdDate) {
		
		//this.itemId = itemId;
		this.title = title;
		this.holidayId = holidayId;
		//this.HolidayScheduleId = HolidayScheduleId;
		//this.HolidayScheduleText = HolidayScheduleText;
		this.modifiedDate = modifiedDate;
		this.createdDate = createdDate;
		
	}
	public Holidays(Date date, Integer countryId) {
		
		this.date = date;
		this.countryId = countryId;
	}
	public Holidays(Date date, String title) {
		
		this.date = date;
		this.title = title;
	}
	
	


}
