package com.infocepts.otc.controllers;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
import javax.mail.MessagingException;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import com.infocepts.otc.entities.Sow;
import com.infocepts.otc.notification.SmtpMailSender;
import com.infocepts.otc.repositories.AccountRepository;
import com.infocepts.otc.repositories.SowRepository;
import com.infocepts.otc.services.TimesheetService;
import com.infocepts.otc.utilities.ExportUtil;

@RestController
@RequestMapping(value="/sow"/*,headers="referer"*/)
public class SowController {

	final Logger logger = Logger.getLogger(SowController.class);
	
	@Autowired
	SowRepository repository;
	
	@Value("${spring.host.localdrive}")
   	private String localdrive;
	
	@Autowired
	SmtpMailSender smtpMailSender;
		
	@Autowired
	TimesheetService service;
	
	@PersistenceContext
    private EntityManager manager;
	
	@Autowired
	ExportUtil exportUtil;
	
	@Autowired
	ProjectController projectController;
	
	@Autowired
	ResourceController resourceController;
	
	@Autowired
	AccountRepository accountRepository;

	String path=null;String filepath="";
	
	@RequestMapping(method=RequestMethod.POST)
	public Sow addSow(@RequestBody Sow sow, HttpServletRequest request) throws MessagingException{
	
		Boolean isAValidCall = false;
		Integer projectId = sow.getProjectId();
		if(projectId != 0)
		{
	 		isAValidCall = service.isAValidSOWCall(projectId, 0, "Add Sow", request);
			if(isAValidCall == true)
			{
				try{
					sow.setSowId(null);
					repository.save(sow);
					service.sendSowNotification(sow, "add", request); // Allocation add / update solution											

				}catch(Exception e){
					logger.error(e);
				}
			}
			else
			{
				throw new IllegalArgumentException("Access Denied");
			}
		}
		return sow;
	}
	
	@RequestMapping(value="/upload/{sowId}",method=RequestMethod.POST,consumes = {"multipart/form-data"})
    @ResponseBody
	public String uploadFile(@RequestPart("file") MultipartFile file,@PathVariable(value = "sowId") Integer sowId,HttpServletRequest request)
	{
		String str1="";String str="";
		Sow sow=repository.findOne(sowId);
		filepath=sow.getDocPath();
		path=exportUtil.getPath(file,request,sowId);
		if(path!=null){
			str="";
			str1=str+path;
			if(filepath != null && !filepath.isEmpty()){
				filepath=filepath+","+str1;
			}
			else{
				filepath=str1;
			}
		}
		sow.setDocPath(filepath);
		repository.save(sow);
		return path;
	}	
	
	@RequestMapping(value="/download/{sowId}",method=RequestMethod.GET)
	public void download(@PathVariable(value = "sowId") Integer sowId,HttpServletRequest request,HttpServletResponse response) throws ServletException, Exception {
		String path=null;
		File home=exportUtil.checkPath(request);
		String separator=File.separator;
		path=home.getPath();
		
		Sow sow=repository.findOne(sowId);
		String Filepath = sow.getDocPath();
		List<String> list = Arrays.asList(Filepath.split("\\s*,\\s*"));
		File zipFile = null;
		if(list.size() > 1){
			//download zip file in case of multiple files download
			if (home.exists() && home.isDirectory()) {
				 logger.info("home is a directory");
				    if(path.equals(separator)){
					 	path="usr"+File.separator+"home"+File.separator+"Download";
					}
					else{
						path=File.separator+"usr"+File.separator+"home"+File.separator+"Download";
					}
				
					if (Files.isDirectory(Paths.get(home + path))) {
						if(path.equals(separator)){
							path="usr"+File.separator+"home"+File.separator+"Download"+File.separator+"sow";
						}
						else{
							path=File.separator+"usr"+File.separator+"home"+File.separator+"Download"+File.separator+"sow";
						}
						
						if (Files.isDirectory(Paths.get(home + path))) {
							if(path.equals(separator)){
								path="usr"+File.separator+"home"+File.separator+"Download"+File.separator+"sow"+File.separator;
							}
							else{
								path=File.separator+"usr"+File.separator+"home"+File.separator+"Download"+File.separator+"sow"+File.separator;
							}
							zipFile = new File(home + path + "archive.zip");
							logger.info("zipFile created");
						} 
					}
				
			}
			
			try {
				 		// create byte buffer
				 		byte[] buffer = new byte[1024];
				 		FileOutputStream fos = new FileOutputStream(zipFile);
				 		ZipOutputStream zos = new ZipOutputStream(fos);
						Iterator<String> it=list.iterator();
						while(it.hasNext()){
							String s=it.next();
							File srcFile = new File(s);
					 		FileInputStream fis = new FileInputStream(srcFile);
					 		// begin writing a new ZIP entry, positions the stream to the start of the entry data
					 		zos.putNextEntry(new ZipEntry(srcFile.getName()));
					 		int length;
					 		while ((length = fis.read(buffer)) > 0) {
					 			zos.write(buffer, 0, length);
					 		}
					 		zos.closeEntry();
					 		// close the InputStream
					 		fis.close();
					 		// close the ZipOutputStream
					 		System.out.println("file written to zip file");
						}
						zos.close();
		                response.setHeader("Content-Length", String.valueOf(zipFile.length()));
		                response.setHeader("Content-Disposition", "attachment; filename=\"" + zipFile);
		                InputStream is = new FileInputStream(zipFile);
		                FileCopyUtils.copy(IOUtils.toByteArray(is), response.getOutputStream());
		                response.flushBuffer();
			 	}
			 	catch (IOException ioe) {
			 		System.out.println("Error creating zip file" + ioe);
			 	}
		}
		else{
			//in case of single file download
			try{
				File outputFile = new File(Filepath);
				Path file = Paths.get(outputFile+"");
			    response.addHeader("Content-Disposition", "attachment; filename="+file.getFileName());
			    Files.copy(file, response.getOutputStream());
			    response.getOutputStream().flush();
			}
			catch(FileNotFoundException fe){
				fe.printStackTrace();
			}
		}
	}
 
	  @RequestMapping(method=RequestMethod.GET)
	 public List<Sow> getAllSow(@RequestParam(value = "projectId", defaultValue = "0") Integer projectId,
			 					@RequestParam(value = "lastSow", defaultValue = "0") Integer lastSow,
			 					HttpServletRequest request) throws MessagingException {
		 Boolean isAValidCall = false;
		 List<Sow> sowlist=null;
		 try{
		 	if(projectId != 0){
		 		isAValidCall = service.isAValidSOWCall(projectId, 0, "All Sow By Project", request);
				if(isAValidCall == true)
				{
					sowlist = manager.createNamedQuery("getSowForProject",Sow.class)
						 .setParameter("projectId", projectId)
						 .getResultList();
				}
		 	}
		 	else if(lastSow != 0)
		 	{
		 		sowlist = manager.createNamedQuery("getLastSow",Sow.class)
						 .getResultList();
		 	}
		 	else{
		 		if(service.isPmo() || service.isFA())
		 		{
		 			sowlist = manager.createNamedQuery("getSowsForAllProjects",Sow.class)
		 				.getResultList();
		 		}
		 	}			 	
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return sowlist;
	 }
	 
	 @RequestMapping(value="/{sowId}",method=RequestMethod.GET)
	 public Sow getSow(@PathVariable Integer sowId,
			 			HttpServletRequest request) throws MessagingException {
		 Sow sow = null;
		 // Authorization for passed projectId (project id)
		 if(sowId != 0)
		 {
			 try{		 
				 sow =  manager.createNamedQuery("getSowById",Sow.class)
				 .setParameter("sowId", sowId)
				 .getSingleResult();
			 }
			 catch(Exception e){
				 logger.error(e);
			 }
			 
			 // Authorization for sow
			 Integer projectId = 0;
			 if(sow != null)
			 {
				 projectId = sow.getProjectId();			 	
				 if(projectId != 0)
				 {
					Boolean isAValidCall = service.isAValidSOWCall(projectId, 0, "Sow By Id", request);
					if(isAValidCall == false)
					{	
						sow = null;
					}
				 }
			 }
		 
			 
		 }
		 return sow;
	 }
	 
	 
	 @RequestMapping(value="/{sowId}",method=RequestMethod.PUT)
	 public Sow updateSow(@RequestBody Sow updatedSow,@PathVariable Integer sowId, HttpServletRequest request)throws MessagingException{
		 	Boolean isAValidCall = false;
			Integer projectId = updatedSow.getProjectId();
			if(projectId != 0)
			{
		 		isAValidCall = service.isAValidSOWCall(projectId, 0, "Update Sow", request);
				if(isAValidCall == true)
				{
					try{
						updatedSow.setSowId(sowId);
						repository.save(updatedSow);
						service.sendSowNotification(updatedSow, "update", request); // Allocation add / update solution	
					}catch(Exception e){
						 logger.error(e);
					}
				}
			}
			return updatedSow;
	 }
	 
	 @RequestMapping(value="/{sowId}",method=RequestMethod.DELETE)
	 public void deleteSow(@PathVariable Integer sowId){
		 try{
			 repository.delete(sowId);
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
	 }	 
}
