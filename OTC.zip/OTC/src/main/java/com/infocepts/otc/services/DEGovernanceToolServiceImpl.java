package com.infocepts.otc.services;


import javax.persistence.EntityManager;

import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import com.infocepts.otc.entities.DeGovernance;
import com.infocepts.otc.repositories.DeGovernanceRepository;


@Component
public class DEGovernanceToolServiceImpl implements DEGovernanceToolService {

	@Autowired
	public DeGovernanceRepository repository;
	
	
	@PersistenceContext(unitName = "otc")
	private EntityManager entityManager;

	@Override
	@Transactional
	public void InsertUpdateComments(DeGovernance de) {

		repository.InsertUpdateComments(de.getpProjectId(),de.getProjectMetricsForDate(),de.getAccountNotes(),de.getPortfolioNotes(),de.getDeliveryNotes());
		
	}

	
}
