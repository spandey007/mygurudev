package com.infocepts.otc.entities;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.infocepts.otc.utilities.LoadConstant;

@SqlResultSetMapping(
	      name = "city_work_location",
	      classes = {
	          @ConstructorResult(
	              targetClass = WorkLocation.class,
	              columns = {
	                  @ColumnResult(name = "workLocationId"),
	                  @ColumnResult(name = "locationName"),
	                  @ColumnResult(name = "createdBy"),
	                  @ColumnResult(name = "createdDate", type=Date.class),
	                  @ColumnResult(name = "modifiedBy"),
	                  @ColumnResult(name = "modifiedDate", type=Date.class),
	                  @ColumnResult(name = "cityId"),
	                  @ColumnResult(name = "cityName")
	                }
	          )
	      }
	)
	@NamedNativeQueries({
	   @NamedNativeQuery(
	            name    =   "getCity_WorkLocation",
	            query   =   "select wl.*,c.cityName as cityName FROM " + LoadConstant.otc + ".[dbo].[worklocation] wl" + 
	            		"  left join " + LoadConstant.infomaster + ".[dbo].[city] c on c.cityId=wl.cityId",
	                        resultClass=WorkLocation.class, resultSetMapping = "city_work_location"                       		
	    )
})
@Entity
@Table(catalog=LoadConstant.otc, schema="[dbo]",name="worklocation")
public class WorkLocation {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer workLocationId;
	private String locationName;
	private Integer createdBy;
	private Date createdDate;
	private Integer modifiedBy;
	private Date modifiedDate;
	private Integer cityId;
	@Transient
	private String cityName;
	
	
	//Getter and Setter
	
	
	
	public WorkLocation() {
	}
	public Integer getWorkLocationId() {
		return workLocationId;
	}
	public void setWorkLocationId(Integer workLocationId) {
		this.workLocationId = workLocationId;
	}
	public String getLocationName() {
		return locationName;
	}
	public void setLocationName(String locationName) {
		this.locationName = locationName;
	}
	public Integer getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public Integer getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public Date getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public Integer getCityId() {
		return cityId;
	}
	public void setCityId(Integer cityId) {
		this.cityId = cityId;
	}
	public String getCityName() {
		return cityName;
	}
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
	public WorkLocation(Integer workLocationId, String locationName, Integer createdBy, Date createdDate,
			Integer modifiedBy, Date modifiedDate, Integer cityId,String cityName) {
		this.workLocationId = workLocationId;
		this.locationName = locationName;
		this.createdBy = createdBy;
		this.createdDate = createdDate;
		this.modifiedBy = modifiedBy;
		this.modifiedDate = modifiedDate;
		this.cityId = cityId;
		this.cityName = cityName;
	}
	
	
}
