package com.infocepts.otc.entities;

import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.SqlResultSetMappings;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.infocepts.otc.utilities.LoadConstant;

@Entity
@Table(catalog=LoadConstant.otc, schema="[dbo]",name="ct_competency")
@SqlResultSetMappings({
    @SqlResultSetMapping(
            name = "competency_mapping",
            classes = {
                    @ConstructorResult(
                            targetClass = CT_Competency.class,
                            columns = {
                            		@ColumnResult(name = "competencyName", type = String.class),
                            		@ColumnResult(name = "competencyId"),                            		
                            		@ColumnResult(name = "clusterId"),
                            		@ColumnResult(name = "clusterName", type = String.class),
                            		@ColumnResult(name = "departmentId")
                            }
                    )
            }
    )
})
@NamedNativeQueries({
    @NamedNativeQuery(
            name    =   "getAllCompetency",   
            query 	=   "select c.competencyName as competencyName, c.competencyId as competencyId, " + 
            			" c.clusterId as clusterId, cl.clusterName as clusterName, null as departmentId from " + LoadConstant.otc + ".[dbo].[ct_competency] c " + 
            			" left join " + LoadConstant.otc + ".[dbo].[ct_cluster] cl on cl.clusterId = c.clusterId",						 
						resultClass=CT_Competency.class, resultSetMapping = "competency_mapping"
    ),
    @NamedNativeQuery(
            name    =   "getFunctionalCompetencyForNd",   
            query 	=   "select distinct c.competencyName as competencyName, c.competencyId as competencyId, " + 
            			" c.clusterId as clusterId, cl.clusterName as clusterName, c.departmentId as departmentId from " + LoadConstant.otc + ".[dbo].[ct_competency] c " + 
            			" left join " + LoadConstant.otc + ".[dbo].[ct_cluster] cl on cl.clusterId = c.clusterId"+
            			" where cl.type = 'F' and c.departmentId = (select pid from " + LoadConstant.infomaster + ".dbo.department dp where dp.departmentId = :departmentId)"+
            			" order by c.competencyName",
						resultClass=CT_Competency.class, resultSetMapping = "competency_mapping"
    )
})
public class CT_Competency {

	// Entity Columns
    // --------------------------------------------------------------------------------
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Integer competencyId;    
    private String competencyName;
    
    private Integer clusterId;  
    private Integer departmentId;  
    
    @Transient
    private String clusterName;

	public Integer getCompetencyId() {
		return competencyId;
	}

	public void setCompetencyId(Integer competencyId) {
		this.competencyId = competencyId;
	}

	public String getCompetencyName() {
		return competencyName;
	}

	public void setCompetencyName(String competencyName) {
		this.competencyName = competencyName;
	}


	public Integer getClusterId() {
		return clusterId;
	}

	public void setClusterId(Integer clusterId) {
		this.clusterId = clusterId;
	}

	public String getClusterName() {
		return clusterName;
	}

	public void setClusterName(String clusterName) {
		this.clusterName = clusterName;
	}

	public Integer getDepartmentId() {
		return departmentId;
	}

	public void setDepartmentId(Integer departmentId) {
		this.departmentId = departmentId;
	}

	public CT_Competency() {
		//super();
		// TODO Auto-generated constructor stub
	}

	public CT_Competency(String competencyName, Integer competencyId, Integer clusterId, String clusterName, Integer departmentId) {
		super();
		this.competencyName = competencyName;
		this.competencyId = competencyId;		
		this.clusterId = clusterId;
		this.clusterName = clusterName;
		this.departmentId = departmentId;
	}
	
	

	
	   
    
    
    
}
