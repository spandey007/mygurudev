package com.infocepts.otc.controllers;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.infocepts.otc.entities.CT_Competency;
import com.infocepts.otc.repositories.CT_CompetencyRepository;
import com.infocepts.otc.services.TimesheetService;

@RestController
@RequestMapping(value="/competency",headers="referer")
public class CT_CompetencyController {
	@Autowired
	CT_CompetencyRepository competencyRepository;
	
	@Autowired
	TimesheetService service;
	
	@PersistenceContext(unitName = "otc")
	private EntityManager manager;
	
	final Logger logger = Logger.getLogger(CT_CompetencyController.class.getName());
	
	@RequestMapping(method=RequestMethod.POST)
	public CT_Competency addCompetency(@RequestBody CT_Competency competency){
		competency.setCompetencyId(null);
		Boolean isAValidCall = false;
		if(service.isHR() || service.isAdmin())
		{
			isAValidCall = true;
		}
		if(isAValidCall) {
			
			competencyRepository.save(competency);
		}
		return competency;
	}
	
	@RequestMapping(method=RequestMethod.GET)
	public List<CT_Competency> getCompetency(
			@RequestParam(value = "isFunCom", defaultValue = "false") Boolean isFunCom
			,@RequestParam(value = "departmentId", defaultValue = "0") Integer departmentId){
		List<CT_Competency> list = null;
		logger.info("isFunCom"+isFunCom);		
		logger.info("departmentId"+departmentId);
		Boolean isAValidCall = false;
		if(service.isHR() || service.isAdmin())
		{
			isAValidCall = true;
		}
		if(isFunCom == true && departmentId != 0){ 
			System.out.println("get functional competency department based for no-delivery department");
			list =  manager.createNamedQuery("getFunctionalCompetencyForNd",CT_Competency.class)
					.setParameter("departmentId", departmentId)
					.getResultList();
		}
		else {
			System.out.println("inside all page");
			list =  manager.createNamedQuery("getAllCompetency",CT_Competency.class)
					.getResultList();
		}
		return list;
	}
	
	@RequestMapping(value="/{competencyId}",method=RequestMethod.GET)
	public CT_Competency getCompetency(@PathVariable Integer competencyId){
		CT_Competency competency = null;
		competency = competencyRepository.findOne(competencyId);
		return competency;
	}
	
	@RequestMapping(value="/{competencyId}", method=RequestMethod.PUT)
	public CT_Competency updateCompetency(@PathVariable Integer competencyId,  @RequestBody CT_Competency updatedCompetency){
		updatedCompetency.setCompetencyId(competencyId);
		Boolean isAValidCall = false;
		if(service.isHR() || service.isAdmin())
		{
			isAValidCall = true;
		}
		if(isAValidCall) {
		competencyRepository.save(updatedCompetency);
		}
		return updatedCompetency;
	}
	
	@RequestMapping(value="/{competencyId}",method=RequestMethod.DELETE)
	public void deleteCompetency(@PathVariable Integer competencyId){
		Boolean isAValidCall = false;
		if(service.isHR() || service.isAdmin())
		{
			isAValidCall = true;
		}
		if(isAValidCall) {
		competencyRepository.delete(competencyId);
		}
	}
}
