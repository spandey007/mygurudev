package com.infocepts.otc.controllers;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.infocepts.otc.entities.CT_FunctionalKeyAction;
import com.infocepts.otc.entities.CT_FunctionalKeyAction;
import com.infocepts.otc.repositories.CT_FunctionalKeyActionRepository;
import com.infocepts.otc.services.TimesheetService;

@RestController
@RequestMapping(value="/functionalKeyAction",headers="referer")
public class CT_FunctionalKeyActionController {
	@Autowired
	CT_FunctionalKeyActionRepository ct_FunctionalKeyActionRepository;
	
	@Autowired
	TimesheetService service;
	
	@PersistenceContext(unitName = "otc")
	private EntityManager manager;
	@RequestMapping(method=RequestMethod.POST)
	public CT_FunctionalKeyAction addCT_FunctionalKeyAction(@RequestBody CT_FunctionalKeyAction cT_FunctionalKeyAction){
		cT_FunctionalKeyAction.setFunctionalKeyActionId(null);
		Boolean isAValidCall = false;
		if(service.isHR() || service.isAdmin())
		{
			isAValidCall = true;
		}
		if(isAValidCall) {
			
			ct_FunctionalKeyActionRepository.save(cT_FunctionalKeyAction);
		}
		return cT_FunctionalKeyAction;
	}
	
	@RequestMapping(method=RequestMethod.GET)
	public List<CT_FunctionalKeyAction> getCT_FunctionalKeyAction(){
		List<CT_FunctionalKeyAction> list = null;
		Boolean isAValidCall = false;
		if(service.isHR() || service.isAdmin())
		{
			isAValidCall = true;
		}
		if(isAValidCall) {
		System.out.println("inside getAllFunctionalKeyAction page");
		list =  manager.createNamedQuery("getAllFunctionalKeyAction",CT_FunctionalKeyAction.class)
				.getResultList();
		}
		return list;
	}
	
	@RequestMapping(value="/{functionalKeyActionId}",method=RequestMethod.GET)
	public CT_FunctionalKeyAction getCT_FunctionalKeyAction(@PathVariable Integer functionalKeyActionId){
		CT_FunctionalKeyAction cT_FunctionalKeyAction = null;
		Boolean isAValidCall = false;
		if(service.isHR() || service.isAdmin())
		{
			isAValidCall = true;
		}
		if(isAValidCall) {
			
			cT_FunctionalKeyAction = ct_FunctionalKeyActionRepository.findOne(functionalKeyActionId);
		}
		return cT_FunctionalKeyAction;
	}
	
	@RequestMapping(value="/{functionalKeyActionId}", method=RequestMethod.PUT)
	public CT_FunctionalKeyAction updateCT_FunctionalKeyAction(@PathVariable Integer functionalKeyActionId,  @RequestBody CT_FunctionalKeyAction updatedCT_FunctionalKeyAction){
		updatedCT_FunctionalKeyAction.setFunctionalKeyActionId(functionalKeyActionId);
		Boolean isAValidCall = false;
		if(service.isHR() || service.isAdmin())
		{
			isAValidCall = true;
		}
		if(isAValidCall) {
		ct_FunctionalKeyActionRepository.save(updatedCT_FunctionalKeyAction);
		}
		return updatedCT_FunctionalKeyAction;
	}
	
	@RequestMapping(value="/{functionalKeyActionId}",method=RequestMethod.DELETE)
	public void deleteCT_FunctionalKeyAction(@PathVariable Integer functionalKeyActionId){
		Boolean isAValidCall = false;
		if(service.isHR() || service.isAdmin())
		{
			isAValidCall = true;
		}
		if(isAValidCall) {
		ct_FunctionalKeyActionRepository.delete(functionalKeyActionId);
		}
	}
}
