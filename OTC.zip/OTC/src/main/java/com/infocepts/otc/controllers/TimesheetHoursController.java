package com.infocepts.otc.controllers;

import java.lang.reflect.Array;
import java.util.List;

import javax.mail.MessagingException;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.thymeleaf.context.Context;

import com.infocepts.otc.entities.Project;
import com.infocepts.otc.entities.Resource;
import com.infocepts.otc.entities.Timesheet;
import com.infocepts.otc.entities.TimesheetApproval;
import com.infocepts.otc.entities.TimesheetHours;
import com.infocepts.otc.entities.TimesheetItem;
import com.infocepts.otc.notification.SmtpMailSender;
import com.infocepts.otc.repositories.ProjectRepository;
import com.infocepts.otc.repositories.ResourceRepository;
import com.infocepts.otc.repositories.TimesheetHoursRepository;
import com.infocepts.otc.services.TimesheetService;


@RestController
@RequestMapping(value="/tshours",headers="referer")//JV: Added 'headers' param to validate the url.
public class TimesheetHoursController {
	
	final Logger logger = Logger.getLogger(TimesheetHoursController.class);

	@Autowired
	TimesheetHoursRepository repository;
	
	@Autowired
	ResourceRepository resourceRepository;
	
	@Autowired
	ProjectRepository projectRepository;
	
	@Autowired
	HttpSession session;
	
	@Autowired
	ResourceController resourceController;
	
	@Autowired
	TimesheetService service;
	
	@Autowired
	private SmtpMailSender smtpMailSender;
	
	@PersistenceContext(unitName="otc")
    private EntityManager manager;
	
	@RequestMapping(method=RequestMethod.GET)
	public List<TimesheetHours> getTimesheetHours(@RequestParam(value = "tsitemId", defaultValue = "0") Integer tsitemId,
			@RequestParam(value = "periodId", defaultValue = "0") Integer periodId,
			@RequestParam(value = "uid", defaultValue = "0") Integer uid,
			@RequestParam(value = "tsmonth", defaultValue = "") String tsmonth,
			@RequestParam(value = "tsMonthStr", defaultValue = "0") String tsMonthStr,
			@RequestParam(value = "pid", defaultValue = "0") Integer pid,
			@RequestParam(value = "leaveFlag", defaultValue = "false") Boolean leaveFlag,
			@RequestParam(value = "alcEndDate", defaultValue = "") String alcEndDate,
			HttpServletRequest request) throws MessagingException {
		
		List<TimesheetHours> tshrs = null;
		
		/* ------------------------- Authorization start ------------------------------------ */
		Integer loggedInUid = (Integer) session.getAttribute("loggedInUid");
		// Authorization for passed uid (user id)
		if((uid != 0) && (pid == 0) )
		{
			Boolean isAValidCall = false;
			isAValidCall = service.isAValidTimesheetCall(uid);
			if((isAValidCall == false) && (!service.isAdmin()))
			{	
				service.sendTamperedMail("TsItemHrs View By uid", uid, pid, request);
				return tshrs;
			}
		}		
		// Authorization for passed pid (project id)
		else if(pid != 0)
		{
			Boolean isAValidCall = false;
			Project proj = projectRepository.getOne(pid);
			if(proj != null)
			{
				Integer pmUid = proj.getProjectManagersId();
				if(loggedInUid.equals(pmUid)) // If the current logged in user is not the project manager of the passed project (pid)
				{
					isAValidCall = true;
				}
				else if(service.isAValidAdminRole())
				{
					isAValidCall = true;
				}
			
				if(isAValidCall == false)
				{	
					// rkj commented as this was giving issues on project profile page - take a look later
					//service.sendTamperedMail("TsItemHrs View By Project", 0, pid, request);
					//return tshrs;
				}
			}
		}
		else if(tsitemId == 0) //Timesheet hours if both uid and pid are not passed (for retrieving all data)
		{
			if(!service.isAValidAdminRole()) // To access timesheet hours for all the associates and projects, one needs a valid admin role
			{
				service.sendTamperedMail("TsItemHrs View All", 0, 0, request);				
				return tshrs;
			}
		}
		/* ------------------------- Authorization ends ------------------------------------ */
		try{
			if(tsitemId != 0)
			{
				tshrs = manager.createNamedQuery("getTimesheetHrsByTsitemId", TimesheetHours.class)
						 .setParameter("tsitemId", tsitemId)
						 .getResultList();
			}
			// Query to find leaves taken by Associate in a period <SRA : 13-07-17>
			else if((periodId != 0) && (uid != 0) && (leaveFlag))
			{
				tshrs = manager.createNamedQuery("getLeaveHrsByPeriodIdAndEmpId", TimesheetHours.class)
						 .setParameter("periodId", periodId)
						 .setParameter("uid", uid)
						 .getResultList();
			}
			else if((periodId != 0) && (uid != 0))
			{
				tshrs = manager.createNamedQuery("getTimesheetHrsByPeriodIdAndUserId", TimesheetHours.class)
						 .setParameter("periodId", periodId)
						 .setParameter("uid", uid)
						 .getResultList();
			}
			else if((uid != 0) && (alcEndDate.equals("")))
			{			
				if(!tsmonth.equals("")) // for all open periods
				{						
					Integer month=service.getMonth(tsmonth);
					Integer year=service.getYear(tsmonth);
					if(year != null && month != null) // for month
					{
						tshrs = manager.createNamedQuery("getWkTsHrsSummaryByUserAndMonth", TimesheetHours.class)
								.setParameter("uid", uid)
								.setParameter("pid", pid)
								 .setParameter("year", year)
								 .setParameter("month", month)
								 .setParameter("monthStr", tsMonthStr)
								 .getResultList();
					}
				}				
				
			}
			else if(pid != 0 && !alcEndDate.equals(""))
			{
					tshrs = manager.createNamedQuery("getTsHrsByProjectAndAlcEndDate", TimesheetHours.class)
							.setParameter("pid", pid)
							.setParameter("uid", uid)
							.setParameter("alcEndDate", alcEndDate)
							.getResultList();

			}
			else if(pid != 0)
			{
				if(tsmonth != null)
				{	
					Integer month=service.getMonth(tsmonth);
					Integer year=service.getYear(tsmonth);
					tshrs = manager.createNamedQuery("getTsHrsByProjectAndMonth", TimesheetHours.class)
					 .setParameter("year", year)
					 .setParameter("month", month)
					 .setParameter("monthStr", tsMonthStr)
					 .setParameter("pid", pid)
		            .getResultList();
				}
			}
			else if(tsmonth != null)
			{	
				Integer month=service.getMonth(tsmonth);
				Integer year=service.getYear(tsmonth);
				tshrs = manager.createNamedQuery("getTsHrsByProjectAndMonth", TimesheetHours.class)
				 .setParameter("year", year)
				 .setParameter("month", month)
				 .setParameter("monthStr", tsMonthStr)
				 .setParameter("pid", 0)
	            .getResultList();
			}
			else
			{
					
				tshrs = manager.createNamedQuery("getTimesheetHrsByPeriodIdAndPmUid", TimesheetHours.class)
						 .setParameter("periodId", periodId)
						 .setParameter("uid", uid)
						 .getResultList();
			}
		}
		catch(Exception e){
			logger.error(e);
		}
		return tshrs;
		
	}
	
	@RequestMapping(method=RequestMethod.POST)
	public TimesheetHours addTimesheetHours(@RequestBody TimesheetHours tshours, HttpServletRequest request) {
		try
		{
			/* ------------------------- Authorization start ------------------------------------ */
			// Authorization for adding timesheet hours
			Boolean isAValidCall = false;
			TimesheetItem tsItem = tshours.getTimesheetItem();
			if(tsItem != null)
			{
				Timesheet ts = tsItem.getTimesheet();
				if(ts != null)
				{
					Integer uid = ts.getUid();
					if(uid != 0)
					{
						isAValidCall = service.isAValidTimesheetCall(uid);	
						if(isAValidCall == true)
						{
							tshours.setTshoursId(null);
						    repository.save(tshours);
						}
						else
						{
							service.sendTamperedMail("TsItemHrs Save", 0, 0, request);
						}
					}
				}
			}			
		}
		catch(Exception e){
			 logger.error(e);
		}
		return tshours;
	}
	
	@RequestMapping(value="/{tshoursId}",method=RequestMethod.PUT)
	public TimesheetHours updateTimesheetHours(@PathVariable Integer tshoursId,@RequestBody TimesheetHours utshours, HttpServletRequest request) {
		try
		{
			Boolean isAValidCall = false;
			TimesheetHours tshours = repository.findTsHoursByTsHoursId(tshoursId);
			if(tshours != null)
			{
				TimesheetItem tsitem=tshours.getTimesheetItem();
				if(tsitem!=null)
				{
					Timesheet ts=tsitem.getTimesheet();
					if(ts!=null)
					{
						Integer uid = ts.getUid();
						if(uid != 0)
						{
							isAValidCall = service.isAValidTimesheetCall(uid);	
							if(isAValidCall == true)
							{
								utshours.setTshoursId(tshoursId);
								repository.save(utshours);	
							}
							else
							{
								service.sendTamperedMail("TsItemHrs Delete", 0, 0, request);
							}
						}
					}
					
				}
			}
			
		}catch(Exception e){
			logger.error(e);
		}
		return utshours;
	}
	
	@RequestMapping(value="/{tshoursId}",method=RequestMethod.DELETE)
	public void deleteTimesheetHours(@PathVariable Integer tshoursId, HttpServletRequest request) {
		try
		{
			/* ------------------------- Authorization start ------------------------------------ */
			// Authorization for deleting Timesheet hours
			Boolean isAValidCall = false;
			TimesheetHours tshours = repository.findTsHoursByTsHoursId(tshoursId);				
			if(tshours != null)
			{
				TimesheetItem tsitem = tshours.getTimesheetItem();
				if(tsitem != null)
				{
					Timesheet ts = tsitem.getTimesheet();
					if(ts != null)
					{
						Integer uid = ts.getUid();						
						if(uid != 0)
						{
							isAValidCall = service.isAValidTimesheetCall(uid);	
							if(isAValidCall == true)
							{
								repository.delete(tshoursId);
							}
							else
							{
								service.sendTamperedMail("TsItemHrs Delete", 0, 0, request);
							}
						}
					}
				}
			}				
			/* ------------------------- Authorization End ------------------------------------ */			
		}catch(Exception e){
			logger.error(e);
		}
	}	
	
	@GetMapping("/getAllTimesheetResourcesByProject")
    public Object getAllTimesheetResourcesByProject(@RequestParam(value = "tsmonth", defaultValue = "0") String tsmonth,
													 @RequestParam(value = "tsMonthStr", defaultValue = "0") String tsMonthStr,
													 @RequestParam(value = "pid", defaultValue = "0") Integer pid,
													 HttpServletRequest request){    
		
		List<TimesheetHours> timesheetHoursList = null;
        try{
        	
        	if(pid != 0)
			{
				if(tsmonth != null)
				{	
					Integer month=service.getMonth(tsmonth);
					Integer year=service.getYear(tsmonth);
					timesheetHoursList = manager.createNamedQuery("getTsHrsByProjectAndMonth", TimesheetHours.class)
					 .setParameter("year", year)
					 .setParameter("month", month)
					 .setParameter("monthStr", tsMonthStr)
					 .setParameter("pid", pid)
		            .getResultList();
				}
			}
        	
        }catch(Exception e){
        	logger.info(String.format("error in fetching release list - ", e.getMessage()));
			e.printStackTrace();
        }
        return timesheetHoursList;
    }
}
