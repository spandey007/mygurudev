package com.infocepts.otc.controllers;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

import javax.mail.MessagingException;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.thymeleaf.context.Context;

import com.infocepts.otc.entities.TimesheetSubmit;
import com.infocepts.otc.notification.SmtpMailSender;
import com.infocepts.otc.repositories.TimesheetSubmitRepository;



@RestController
@RequestMapping(value="/tssubmit",headers="referer")//JV: Added 'headers' param to validate the url.
public class TimesheetSubmitController {
	
	final Logger logger = Logger.getLogger(TimesheetSubmitController.class);
	
	@Autowired
	TimesheetSubmitRepository repository;
	
	@Autowired
	HttpSession session;
	
	
	@PersistenceContext(unitName="otc")
    private EntityManager manager;
	
	@RequestMapping(method=RequestMethod.GET)
	public List<TimesheetSubmit> getTimesheetSubmit(@RequestParam(value = "projectId", defaultValue = "0") Integer projectId,
											@RequestParam(value = "timesheetId", defaultValue = "0") Integer timesheetId) {
		List<TimesheetSubmit> tsSubmitList = null;
		try{
			if(projectId != 0 && timesheetId != 0)
			{
				tsSubmitList = repository.findTimesheetSubmitByProjectAndTs(projectId, timesheetId);
			}
			else if (projectId == 0 && timesheetId != 0)
			{		
				tsSubmitList = repository.findTimesheetSubmitByTs(timesheetId);
			}
		}
		catch(Exception e){
			logger.error(e);
		}
		return tsSubmitList;
	}
	
	@RequestMapping(method=RequestMethod.POST)
	public TimesheetSubmit addTimesheetSubmit(@RequestBody TimesheetSubmit tssubmit) {
		try{
			tssubmit.setTssubmitId(null);
			repository.save(tssubmit);
		}
		catch(Exception e){
			logger.error(e);
		}
		return tssubmit;
	}
	
	@RequestMapping(value="/{tssubmitId}",method=RequestMethod.PUT)
	public TimesheetSubmit updateTimesheetSubmit(@PathVariable Integer tssubmitId, @RequestBody TimesheetSubmit utssubmit){
		try{
			utssubmit.setTssubmitId(tssubmitId);
			repository.save(utssubmit);
		}
		catch(Exception e){
			logger.error(e);
		}
		return utssubmit;
	}
	
	@RequestMapping(value="/{tssubmitId}",method=RequestMethod.DELETE)
	public void deleteTimesheetSubmit(@PathVariable Integer tssubmitId) {
		try{
			repository.delete(tssubmitId);
		}catch(Exception e){
			logger.error(e);
		}
	}
	
}
