package com.infocepts.otc.entities;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.persistence.*;
import javax.validation.constraints.NotNull;

import com.infocepts.otc.utilities.LoadConstant;
@Entity
@Table(catalog=LoadConstant.otc, schema="[dbo]", name="gtp")

@SqlResultSetMappings({
        @SqlResultSetMapping(
                name = "gtp_list",
                classes = {
                        @ConstructorResult(
                                targetClass = Gtp.class,
                                columns = {
                                		@ColumnResult(name = "gtpId"),
                                        @ColumnResult(name = "operationUnit", type = String.class),                                        
                                        @ColumnResult(name = "uid"),
                                        @ColumnResult(name = "associateCode", type = String.class),
                                        @ColumnResult(name = "associate", type = String.class),
                                        //@ColumnResult(name = "gradeId"),
                                        @ColumnResult(name = "designation", type = String.class),
                                        //@ColumnResult(name = "amgRoleId"),
                                        @ColumnResult(name = "role", type = String.class),
                                        //@ColumnResult(name = "departmentId"),
                                        @ColumnResult(name = "department", type = String.class),
                                        //@ColumnResult(name = "pSkillId"),
                                        @ColumnResult(name = "pSkillName", type = String.class),
                                        //@ColumnResult(name = "sSkillId"), 
                                        @ColumnResult(name = "sSkillName", type = String.class),                                        
                                       // @ColumnResult(name = "empTypeId"),
                                        @ColumnResult(name = "employmentType", type = String.class),
                                        //@ColumnResult(name = "currentLocationId"),
                                        @ColumnResult(name = "resourcePoolLocation", type = String.class),                                         
                                        //@ColumnResult(name = "countryId"),
                                        @ColumnResult(name = "resourcePoolCountry", type = String.class),                                          
                                       // @ColumnResult(name = "unitId"),
                                        @ColumnResult(name = "unit", type = String.class),  
                                        @ColumnResult(name = "joiningDate", type = Date.class),       
                                        
                                        ////////////////////gtp table 
                                        @ColumnResult(name = "lastAlcProjectId"),
                                        @ColumnResult(name = "lastAlcProject", type = String.class),                                         
                                        @ColumnResult(name = "lastAlcAccountId"),
                                        @ColumnResult(name = "lastAlcAccount", type = String.class), 
                                        @ColumnResult(name = "lastAlcDate", type = Date.class),                                         
                                        @ColumnResult(name = "gtpDays"),
                                        @ColumnResult(name = "gtpDaysCateg", type = String.class), 
                                        @ColumnResult(name = "availability",type = BigDecimal.class),
                                        
                                        @ColumnResult(name = "deployableStatus", type = String.class), 
                                        @ColumnResult(name = "resourceStatus", type = String.class), 
                                        @ColumnResult(name = "proposedDate", type = Date.class),
                                        @ColumnResult(name = "gtpDate", type = Date.class),
                                        @ColumnResult(name = "proposedDays"),
                                        @ColumnResult(name = "proposedDaysCateg", type = String.class), 
                                        @ColumnResult(name = "proposedAccountId"),
                                        @ColumnResult(name = "proposedAccount", type = String.class), 
                                        @ColumnResult(name = "confirmedDate", type = Date.class),
                                        @ColumnResult(name = "billingStartDate", type = Date.class),
                                        @ColumnResult(name = "gtpRemarks", type = String.class),
                                        @ColumnResult(name = "modifiedBy"),
                                        @ColumnResult(name = "modifiedDate", type = Date.class),
                                        @ColumnResult(name = "bucketId"),
                                        @ColumnResult(name = "bucket", type = String.class),
                                }
                        )
                }
        ),
        @SqlResultSetMapping(
                name = "gtp_id_list",
                classes = {
                        @ConstructorResult(
                                targetClass = Gtp.class,
                                columns = {
                                		@ColumnResult(name = "gtpId"),
                                }
                        )
                }
        )
        
})
@NamedNativeQueries({
        @NamedNativeQuery(
                name    =   "getGtpResources",   
                query 	=   "Select DISTINCT"+
                			" g.gtpId,"+
							" 'NA' as operationUnit,"+
							" gtpview.uid as uid,"+
							" gtpview.[Associate Code] as associateCode,"+
							" gtpview.[Associate] as associate,"+
							" gtpview.[Designation] as designation,"+
							" gtpview.[Role] as role,"+
							" gtpview.[Department] as department,"+
							" gtpview.[Primary Skill] as pSkillName,"+
							" gtpview.[Secondary Skill] as sSkillName,"+
							" gtpview.[Employment Type] as employmentType,"+
							" gtpview.[ResourcePool Location] as resourcePoolLocation,"+
							" gtpview.[ResourcePool Country] as resourcePoolCountry,"+
							" gtpview.[Unit] as unit,"+
							" gtpview.[DOJ] as joiningDate,"+
							" (select Top 1 itemId from " + LoadConstant.infomaster + ".[dbo].[project] p where p.title = gtpview.[Last Allocated Project]) as lastAlcProjectId,"+
							" gtpview.[Last Allocated Project] as lastAlcProject,"+
							" (select Top 1 itemId from " + LoadConstant.infomaster + ".[dbo].[accounts] a where a.accountShortName = gtpview.[Last Allocated Account]) as lastAlcAccountId,"+
							" gtpview.[Last Allocated Account] as lastAlcAccount,"+
							" "+ LoadConstant.otc + ".[dbo].fn_GetDateFromInt(gtpview.[Last Allocation Date]) as lastAlcDate,"+							
							" gtpview.[GTP Days] as gtpDays,"+
	                		" gtpview.[GTP Categories] as gtpDaysCateg,"+
	                		" gtpview.[Availaibility] as availability,"+
	                		" g.deployableStatus as deployableStatus,"+
	                		" g.resourceStatus as resourceStatus,"+
	                		" g.proposedDate as proposedDate,"+
	                		" g.gtpDate as gtpDate,"+
	                		" g.proposedDays as proposedDays,"+
	                		" g.proposedDaysCateg as proposedDaysCateg,"+
	                		" g.proposedAccountId as proposedAccountId,"+	                	
	                		" (select Top 1 accountShortName from " + LoadConstant.infomaster + ".[dbo].[accounts] a2 where a2.itemId = g.proposedAccountId) as proposedAccount,"+
	                		" g.confirmedDate as confirmedDate,"+
	                		" g.billingStartDate as billingStartDate,"+
	                		" g.gtpRemarks as gtpRemarks,"+ 
	                		" NULL as modifiedBy,"+  
	                		" getdate() as modifiedDate,"+
	                		" g.bucketId as bucketId,"+  
	                		" (select bucketName from " + LoadConstant.otc + ".[dbo].[bucket] where bucketId = g.bucketId) as bucket"+  
							" from " + LoadConstant.otc + ".[dbo].VW_GTP_LIVE_DATA as gtpview"+
							" LEFT JOIN " + LoadConstant.otc + ".[dbo].gtp  g on g.uid = gtpview.uid"+							
							" where cast(g.gtpDate as DATE) = :gtpDate order by gtpview.[Associate]",
							 
							resultClass=Gtp.class, resultSetMapping = "gtp_list"
        ),
        @NamedNativeQuery(
                name    =   "getGtpResourcesFromLastDate",   
                query 	=   "Select DISTINCT"+
                			" g.gtpId,"+
							" 'NA' as operationUnit,"+
							" gtpview.uid as uid,"+
							" gtpview.[Associate Code] as associateCode,"+
							" gtpview.[Associate] as associate,"+
							" gtpview.[Designation] as designation,"+
							" gtpview.[Role] as role,"+
							" gtpview.[Department] as department,"+
							" gtpview.[Primary Skill] as pSkillName,"+
							" gtpview.[Secondary Skill] as sSkillName,"+
							" gtpview.[Employment Type] as employmentType,"+
							" gtpview.[ResourcePool Location] as resourcePoolLocation,"+
							" gtpview.[ResourcePool Country] as resourcePoolCountry,"+
							" gtpview.[Unit] as unit,"+
							" gtpview.[DOJ] as joiningDate,"+
							" (select Top 1 itemId from " + LoadConstant.infomaster + ".[dbo].[project] p where p.title = gtpview.[Last Allocated Project]) as lastAlcProjectId,"+
							" gtpview.[Last Allocated Project] as lastAlcProject,"+
							" (select Top 1 itemId from " + LoadConstant.infomaster + ".[dbo].[accounts] a where a.accountShortName = gtpview.[Last Allocated Account]) as lastAlcAccountId,"+
							" gtpview.[Last Allocated Account] as lastAlcAccount,"+
							" "+ LoadConstant.otc + ".[dbo].fn_GetDateFromInt(gtpview.[Last Allocation Date]) as lastAlcDate,"+							
							" gtpview.[GTP Days] as gtpDays,"+
	                		" gtpview.[GTP Categories] as gtpDaysCateg,"+
	                		" gtpview.[Availaibility] as availability,"+
	                		" g.deployableStatus as deployableStatus,"+
	                		" g.resourceStatus as resourceStatus,"+
	                		" g.proposedDate as proposedDate,"+
	                		" g.gtpDate as gtpDate,"+
	                		" g.proposedDays as proposedDays,"+
	                		" g.proposedDaysCateg as proposedDaysCateg,"+
	                		" g.proposedAccountId as proposedAccountId,"+	                	
	                		" (select Top 1 accountShortName from " + LoadConstant.infomaster + ".[dbo].[accounts] a2 where a2.itemId = g.proposedAccountId) as proposedAccount,"+
	                		" g.confirmedDate as confirmedDate,"+
	                		" g.billingStartDate as billingStartDate,"+
	                		" g.gtpRemarks as gtpRemarks,"+ 
	                		" NULL as modifiedBy,"+  
	                		" getdate() as modifiedDate,"+
	                		" g.bucketId as bucketId,"+  
	                		" (select bucketName from " + LoadConstant.otc + ".[dbo].[bucket] where bucketId = g.bucketId) as bucket"+  
							" from " + LoadConstant.otc + ".[dbo].VW_GTP_LIVE_DATA as gtpview"+
							" LEFT JOIN " + LoadConstant.otc + ".[dbo].gtp  g on g.uid = gtpview.uid"+							
							" and cast(g.gtpDate as DATE) = (select TOP 1 gt.gtpDate from " + LoadConstant.otc + ".[dbo].gtp gt order by gt.gtpDate desc) order by gtpview.[Associate]",
							
							resultClass=Gtp.class, resultSetMapping = "gtp_list"
        ),
        @NamedNativeQuery(
                name    =   "getGtpResourceById",                
                query = "select"+
                		" g.gtpId,"+
                		" 'NA' as operationUnit,"+
                		" g.uid as uid,"+
                		" r.empId as associateCode,"+
                		" r.title as associate,"+
                		" gr.designation as designation,"+
                		" ar.amgRoleName as role,"+
                		" d.departmentName as department,"+ 
                		" ps.skillName as pSkillName,"+
                		" ss.skillName as sSkillName,"+ 
                		" et.empTypeName as  employmentType,"+
                		" ci.cityName as resourcePoolLocation,"+
                		" co.countryName as resourcePoolCountry,"+
                		" u.name as unit,"+
                		" r.joiningDate as joiningDate,"+
                		" g.lastAlcProjectId as lastAlcProjectId,"+
                		" p.title as lastAlcProject,"+
                		" g.lastAlcAccountId as lastAlcAccountId,"+
                		" a.accountShortName as lastAlcAccount,"+
                		" g.lastAlcDate as lastAlcDate,"+
                		" g.gtpDays as gtpDays,"+
                		" g.gtpDaysCateg as gtpDaysCateg,"+
                		" g.availability as availability,"+
                		" g.deployableStatus as deployableStatus,"+
                		" g.resourceStatus as resourceStatus,"+
                		" g.proposedDate as proposedDate,"+
                		" g.gtpDate as gtpDate,"+
                		" g.proposedDays as proposedDays,"+
                		" g.proposedDaysCateg as proposedDaysCateg,"+
                		" g.proposedAccountId as proposedAccountId,"+
                		" a2.accountShortName as proposedAccount,"+
                		" g.confirmedDate as confirmedDate,"+
                		" g.billingStartDate as billingStartDate,"+
                		" g.gtpRemarks as gtpRemarks,"+  
                		" NULL as modifiedBy,"+  
                		" getdate() as modifiedDate,"+ 
                		" g.bucketId as bucketId,"+  
                		" (select bucketName from " + LoadConstant.otc + ".[dbo].[bucket] where bucketId = g.bucketId) as bucket"+  
                		" FROM " + LoadConstant.otc + ".[dbo].gtp g"+
                		" LEFT JOIN  " + LoadConstant.infomaster + ".[dbo].[resource] r on r.uid = g.uid"+
                		" LEFT JOIN  " + LoadConstant.infomaster + ".[dbo].[grade] gr on gr.gradeId = r.gradeId"+                        
                		" LEFT JOIN  " + LoadConstant.infomaster + ".[dbo].[amgRoles] ar on ar.amgRoleId = r.amgRoleId"+
                		" LEFT JOIN  " + LoadConstant.infomaster + ".[dbo].[department] d on d.departmentId = r.departmentId"+
                		" LEFT JOIN  " + LoadConstant.infomaster + ".[dbo].[skill] ps on ps.skillId = r.pSkillId"+
                		" LEFT JOIN  " + LoadConstant.infomaster + ".[dbo].[skill] ss on ss.skillId = r.sSkillId"+
                		" LEFT JOIN  " + LoadConstant.infomaster + ".[dbo].[city] ci on ci.cityId = r.currentLocationId"+
                		" LEFT JOIN  " + LoadConstant.infomaster + ".[dbo].[country] co on co.countryId = ci.countryId"+
                		" LEFT JOIN  " + LoadConstant.infomaster + ".[dbo].[unit] u on u.unitId = r.unitId"+
                		" LEFT JOIN  " + LoadConstant.infomaster + ".[dbo].[empType] et on et.empTypeId = r.empTypeId"+
                		" LEFT JOIN  " + LoadConstant.infomaster + ".[dbo].[accounts] a on a.itemId = g.lastAlcAccountId"+
                		" LEFT JOIN  " + LoadConstant.infomaster + ".[dbo].[accounts] a2 on a2.itemId = g.proposedAccountId"+
                		" LEFT JOIN  " + LoadConstant.infomaster + ".[dbo].[project] p on p.itemId = g.lastAlcProjectId"+
                		" where g.gtpId = :gtpId",
					    resultClass=Gtp.class, resultSetMapping = "gtp_list"
        ),
        @NamedNativeQuery(
                name    =   "isUidPresentForGtpDate",                
                query = "select g.gtpId"+                		
                		" FROM " + LoadConstant.otc + ".[dbo].gtp g"+                		
                		" where g.uid = :uid and cast(g.gtpDate as DATE) = :gtpDate",
					    resultClass=Gtp.class, resultSetMapping = "gtp_id_list"
		),
        @NamedNativeQuery(
                name    =   "isDataPresentForGtpDate",                
                query = "select g.gtpId"+                		
                		" FROM " + LoadConstant.otc + ".[dbo].gtp g"+                		
                		" where cast(g.gtpDate as DATE) = :gtpDate",
					    resultClass=Gtp.class, resultSetMapping = "gtp_id_list"
		)
        
})
public class Gtp {

    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Integer gtpId; 
    @NotNull
    private Integer uid;
    private Integer lastAlcProjectId;    
    private Integer lastAlcAccountId; 
    private Date lastAlcDate;
    private Integer gtpDays;
    private String gtpDaysCateg;
    private BigDecimal availability;
    
    private String deployableStatus;
    private String resourceStatus;
    private Date proposedDate;
    private Date gtpDate;
    private Integer proposedDays;
    private String proposedDaysCateg;
    private Integer proposedAccountId;
    private Date confirmedDate;
    private Date billingStartDate;
    private String gtpRemarks;

    private Date modifiedDate;
    private Integer modifiedBy;
    
    private Integer bucketId;

    // Transient Variables
    // --------------------------------------------------------------------------------
    @Transient
    private String operationUnit;
    @Transient
    private String associateCode; 
    @Transient
    private String associate;
    @Transient
    private String designation;
    @Transient
    private String role;
    @Transient
    private String department;
    @Transient
    private String pSkillName;
    @Transient
    private String sSkillName;
    @Transient
    private String employmentType;
    @Transient
    private String resourcePoolLocation;
    @Transient
    private String resourcePoolCountry;
    @Transient
    private String unit;
    @Transient
    private Date joiningDate;    
    @Transient
    private String lastAlcAccount;
    @Transient
    private String lastAlcProject;
    @Transient
    private String proposedAccount;
    @Transient
    private String bucket;
    
	public Integer getGtpId() {
		return gtpId;
	}
	public void setGtpId(Integer gtpId) {
		this.gtpId = gtpId;
	}
	public Integer getUid() {
		return uid;
	}
	public void setUid(Integer uid) {
		this.uid = uid;
	}
	public Integer getLastAlcProjectId() {
		return lastAlcProjectId;
	}
	public void setLastAlcProjectId(Integer lastAlcProjectId) {
		this.lastAlcProjectId = lastAlcProjectId;
	}
	public Integer getLastAlcAccountId() {
		return lastAlcAccountId;
	}
	public void setLastAlcAccountId(Integer lastAlcAccountId) {
		this.lastAlcAccountId = lastAlcAccountId;
	}
	public Date getLastAlcDate() {
		return lastAlcDate;
	}
	public void setLastAlcDate(Date lastAlcDate) {
		this.lastAlcDate = lastAlcDate;
	}
	public Integer getGtpDays() {
		return gtpDays;
	}
	public void setGtpDays(Integer gtpDays) {
		this.gtpDays = gtpDays;
	}
	public String getGtpDaysCateg() {
		return gtpDaysCateg;
	}
	public void setGtpDaysCateg(String gtpDaysCateg) {
		this.gtpDaysCateg = gtpDaysCateg;
	}
	public BigDecimal getAvailability() {
		return availability;
	}
	public void setAvailability(BigDecimal availability) {
		this.availability = availability;
	}
	public String getDeployableStatus() {
		return deployableStatus;
	}
	public void setDeployableStatus(String deployableStatus) {
		this.deployableStatus = deployableStatus;
	}
	public String getResourceStatus() {
		return resourceStatus;
	}
	public void setResourceStatus(String resourceStatus) {
		this.resourceStatus = resourceStatus;
	}
	public Date getProposedDate() {
		return proposedDate;
	}
	public void setProposedDate(Date proposedDate) {
		this.proposedDate = proposedDate;
	}
	public Date getGtpDate() {
		return gtpDate;
	}
	public void setGtpDate(Date gtpDate) {
		this.gtpDate = gtpDate;
	}
	public Integer getProposedDays() {
		return proposedDays;
	}
	public void setProposedDays(Integer proposedDays) {
		this.proposedDays = proposedDays;
	}
	public String getProposedDaysCateg() {
		return proposedDaysCateg;
	}
	public void setProposedDaysCateg(String proposedDaysCateg) {
		this.proposedDaysCateg = proposedDaysCateg;
	}
	public Integer getProposedAccountId() {
		return proposedAccountId;
	}
	public void setProposedAccountId(Integer proposedAccountId) {
		this.proposedAccountId = proposedAccountId;
	}
	public Date getConfirmedDate() {
		return confirmedDate;
	}
	public void setConfirmedDate(Date confirmedDate) {
		this.confirmedDate = confirmedDate;
	}
	public Date getBillingStartDate() {
		return billingStartDate;
	}
	public void setBillingStartDate(Date billingStartDate) {
		this.billingStartDate = billingStartDate;
	}
	public String getGtpRemarks() {
		return gtpRemarks;
	}
	public void setGtpRemarks(String gtpRemarks) {
		this.gtpRemarks = gtpRemarks;
	}
	public Date getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public Integer getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public String getOperationUnit() {
		return operationUnit;
	}
	public void setOperationUnit(String operationUnit) {
		this.operationUnit = operationUnit;
	}
	public String getAssociateCode() {
		return associateCode;
	}
	public void setAssociateCode(String associateCode) {
		this.associateCode = associateCode;
	}
	public String getAssociate() {
		return associate;
	}
	public void setAssociate(String associate) {
		this.associate = associate;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public String getpSkillName() {
		return pSkillName;
	}
	public void setpSkillName(String pSkillName) {
		this.pSkillName = pSkillName;
	}
	public String getsSkillName() {
		return sSkillName;
	}
	public void setsSkillName(String sSkillName) {
		this.sSkillName = sSkillName;
	}
	public String getEmploymentType() {
		return employmentType;
	}
	public void setEmploymentType(String employmentType) {
		this.employmentType = employmentType;
	}
	public String getResourcePoolLocation() {
		return resourcePoolLocation;
	}
	public void setResourcePoolLocation(String resourcePoolLocation) {
		this.resourcePoolLocation = resourcePoolLocation;
	}
	public String getResourcePoolCountry() {
		return resourcePoolCountry;
	}
	public void setResourcePoolCountry(String resourcePoolCountry) {
		this.resourcePoolCountry = resourcePoolCountry;
	}
	public String getUnit() {
		return unit;
	}
	public void setUnit(String unit) {
		this.unit = unit;
	}
	public Date getJoiningDate() {
		return joiningDate;
	}
	public void setJoiningDate(Date joiningDate) {
		this.joiningDate = joiningDate;
	}
	public String getLastAlcAccount() {
		return lastAlcAccount;
	}
	public void setLastAlcAccount(String lastAlcAccount) {
		this.lastAlcAccount = lastAlcAccount;
	}
	public String getLastAlcProject() {
		return lastAlcProject;
	}
	public void setLastAlcProject(String lastAlcProject) {
		this.lastAlcProject = lastAlcProject;
	}
	public String getProposedAccount() {
		return proposedAccount;
	}
	public void setProposedAccount(String proposedAccount) {
		this.proposedAccount = proposedAccount;
	}
	public Integer getBucketId() {
		return bucketId;
	}

	public void setBucketId(Integer bucketId) {
		this.bucketId = bucketId;
	}
	public String getBucket() {
		return bucket;
	}
	public void setBucket(String bucket) {
		this.bucket = bucket;
	}
	public Gtp() {
		//super();
		// TODO Auto-generated constructor stub
	}
	public Gtp(Integer gtpId, String operationUnit, Integer uid,
			String associateCode, String associate, 
			String designation,	String role, String department,
			String pSkillName, String sSkillName, String employmentType,
			String resourcePoolLocation, String resourcePoolCountry, String unit, Date joiningDate,
			Integer lastAlcProjectId, String lastAlcProject, Integer lastAlcAccountId, String lastAlcAccount, 
			Date lastAlcDate,			
			Integer gtpDays, String gtpDaysCateg, BigDecimal availability, 
			String deployableStatus, String resourceStatus,
			Date proposedDate, Date gtpDate, 
			Integer proposedDays, String proposedDaysCateg, Integer proposedAccountId, String proposedAccount,
			Date confirmedDate, Date billingStartDate, String gtpRemarks,
			Integer modifiedBy, Date modifiedDate, Integer bucketId, String bucket
			) {
		//super();
		this.gtpId = gtpId;
		this.operationUnit = operationUnit;
		this.uid = uid;
		this.associateCode = associateCode;
		this.associate = associate;
		this.designation = designation;
		this.role = role;
		this.department = department;
		this.pSkillName = pSkillName;
		this.sSkillName = sSkillName;
		this.employmentType = employmentType;
		this.resourcePoolLocation = resourcePoolLocation;
		this.resourcePoolCountry = resourcePoolCountry;
		this.unit = unit;
		this.joiningDate = joiningDate;
		
		this.lastAlcProjectId = lastAlcProjectId;
		this.lastAlcProject = lastAlcProject;
		this.lastAlcAccountId = lastAlcAccountId;
		this.lastAlcAccount = lastAlcAccount;
		this.lastAlcDate = lastAlcDate;		
		this.gtpDays = gtpDays;
		this.gtpDaysCateg = gtpDaysCateg;
		this.availability = availability;
		this.deployableStatus = deployableStatus;
		this.resourceStatus = resourceStatus;
		this.proposedDate = proposedDate;
		this.gtpDate = gtpDate;
		this.proposedDays = proposedDays;
		this.proposedDaysCateg = proposedDaysCateg;
		this.proposedAccountId = proposedAccountId;
		this.proposedAccount = proposedAccount;		
		this.confirmedDate = confirmedDate;
		this.billingStartDate = billingStartDate;
		this.gtpRemarks = gtpRemarks;
		this.modifiedDate = modifiedDate;
		this.modifiedBy = modifiedBy;
		this.bucketId = bucketId; // bucket Id  for NB_POOL  = 11
		this.bucket = bucket;
	
	}
	
	public Gtp(Integer gtpId) {
			this.gtpId = gtpId;
	}
    
    
   
   



    
    

}
