package com.infocepts.otc.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.infocepts.otc.entities.BusNodalPoint;

public interface BusNodalPointRepository extends CrudRepository<BusNodalPoint,Integer>  {
	@Override
	public List<BusNodalPoint> findAll();
	
	
	@Query("from BusNodalPoint order by nodalPointName asc")
	public List<BusNodalPoint> findByBusNodalPointNames();
	
	@Query("from BusNodalPoint where busNodalPointId=:busNodalPointId")
	public BusNodalPoint findByBusNodalPoint(@Param("busNodalPointId") Integer busNodalPointId);
}
