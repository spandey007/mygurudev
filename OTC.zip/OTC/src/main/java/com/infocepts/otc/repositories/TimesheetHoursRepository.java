package com.infocepts.otc.repositories;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.infocepts.otc.entities.TimesheetHours;



@Repository
public interface TimesheetHoursRepository extends JpaRepository<TimesheetHours,Integer>{

	@Override
	public List<TimesheetHours> findAll();
	
	@Query("select tsh FROM TimesheetHours tsh where tsh.timesheetItem.tsitemId = :tsitemId")
	public List<TimesheetHours> findTimesheetsHoursByTimesheetItemId(@Param("tsitemId") Integer tsitemId);
	
	@Query("select tsh FROM TimesheetHours tsh where tsh.tshoursId = :tshoursId")
	public TimesheetHours findTsHoursByTsHoursId(@Param("tshoursId") Integer tshoursId);
	
	
	
}
