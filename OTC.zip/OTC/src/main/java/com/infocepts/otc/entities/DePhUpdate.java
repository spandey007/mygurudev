/**
* Filename: /src/main/java/com/infocepts/otc/entities/DePhUpdate.java
* @author  SHRI
* @version 1.0
* @since   2018-11-28 
*/
package com.infocepts.otc.entities;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.persistence.*;
import javax.validation.constraints.NotNull;

import com.infocepts.otc.utilities.LoadConstant;
@Entity
@Table(catalog=LoadConstant.otc, schema="[dbo]", name="dePhUpdate")

@SqlResultSetMappings({
        @SqlResultSetMapping(
                name = "list_all_dePhUpdate",
                classes = {
                        @ConstructorResult(
                                targetClass = DePhUpdate.class,
                                columns = {
                                		@ColumnResult(name = "dePhUpdateId"),
                                        @ColumnResult(name = "portfolioId"), 
										@ColumnResult(name = "filepath", type = String.class),
										@ColumnResult(name = "date", type = Date.class),	
                                        @ColumnResult(name = "status", type = String.class),
										@ColumnResult(name = "createdBy"),	
										@ColumnResult(name = "createdDate", type = Date.class),
										@ColumnResult(name = "modifiedBy"),
										@ColumnResult(name = "modifiedDate", type = Date.class),	
                                        @ColumnResult(name = "comments", type = String.class),
                                        @ColumnResult(name = "portfolioName", type = String.class)
                                }
                        )
                }
        )
})
@NamedNativeQueries({
        @NamedNativeQuery(
                name    =   "getAllDePhUpdateData",   
                query 	=   "Select dpr.*,  p.title as portfolioName "+
							" from " + LoadConstant.otc + ".[dbo].[dePhUpdate] as dpr"+
							" Left JOIN " + LoadConstant.infomaster + ".[dbo].[portfolio] p on p.itemId = dpr.portfolioId"+
							" WHERE  (('ph' = :view and dpr.createdBy = :uid ) "+
		            		"or "+
		            		"('pmo' = :view ) "+
		            		"or "+
		            		"('dh' = :view ) "+
		            		"or "+
		            		"('cep' = :view ) "+
		            		"or "+
		            		"('de' = :view )) order by dpr.dePhUpdateId desc",
							
							resultClass=DePhUpdate.class, resultSetMapping = "list_all_dePhUpdate"
        )        
})


public class DePhUpdate {

	// Entity Columns
    // --------------------------------------------------------------------------------
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Integer dePhUpdateId; 		
	private Integer portfolioId;    
	private String filepath;
    private Date date;
	private String status;
    private Integer createdBy;    
    private Date createdDate;
    private Integer modifiedBy;
    private Date modifiedDate;
	@Lob
	private String comments;
	
	@Transient
	private String portfolioName;

	


	public Integer getDePhUpdateId() {
		return dePhUpdateId;
	}



	public void setDePhUpdateId(Integer dePhUpdateId) {
		this.dePhUpdateId = dePhUpdateId;
	}


	public String getFilepath() {
		return filepath;
	}



	public void setFilepath(String filepath) {
		this.filepath = filepath;
	}



	public Date getDate() {
		return date;
	}



	public void setDate(Date date) {
		this.date = date;
	}



	public String getStatus() {
		return status;
	}



	public void setStatus(String status) {
		this.status = status;
	}



	public Integer getCreatedBy() {
		return createdBy;
	}



	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}



	public Date getCreatedDate() {
		return createdDate;
	}



	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}



	public Integer getModifiedBy() {
		return modifiedBy;
	}



	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}



	public Date getModifiedDate() {
		return modifiedDate;
	}



	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}



	public String getComments() {
		return comments;
	}



	public void setComments(String comments) {
		this.comments = comments;
	}


	public Integer getPortfolioId() {
		return portfolioId;
	}



	public void setPortfolioId(Integer portfolioId) {
		this.portfolioId = portfolioId;
	}


	public String getPortfolioName() {
		return portfolioName;
	}



	public void setPortfolioName(String portfolioName) {
		this.portfolioName = portfolioName;
	}



	/*default constructor*/
	public DePhUpdate() {
		
	}



	public DePhUpdate(Integer dePhUpdateId, Integer portfolioId, String filepath, Date date, String status,
			Integer createdBy, Date createdDate, Integer modifiedBy, Date modifiedDate, String comments,
			String portfolioName) {
		super();
		this.dePhUpdateId = dePhUpdateId;
		this.portfolioId = portfolioId;
		this.filepath = filepath;
		this.date = date;
		this.status = status;
		this.createdBy = createdBy;
		this.createdDate = createdDate;
		this.modifiedBy = modifiedBy;
		this.modifiedDate = modifiedDate;
		this.comments = comments;
		this.portfolioName = portfolioName;
	}


}
