package com.infocepts.otc.controllers;

import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.infocepts.otc.entities.InvoiceInfo;
import com.infocepts.otc.repositories.InvoiceInfoRepository;
import com.infocepts.otc.services.TimesheetService;

@RestController
@RequestMapping(value="/invoiceinfo",headers="referer")
public class InvoiceInfoController {
	
	final Logger logger = Logger.getLogger(InvoiceInfoController.class);

	@Autowired
	InvoiceInfoRepository repository;
	
	@Autowired
	TimesheetService service;
	
	@Autowired
	HttpSession session;
	
	@RequestMapping(method=RequestMethod.POST)
	public InvoiceInfo addInvoiceInfo(@RequestBody InvoiceInfo invoiceinfo)
	{
		try{
			if(service.isAR()){
				invoiceinfo.setInvoiceInfoId(null);
				repository.save(invoiceinfo);	
			}
		}catch(Exception e){
			logger.error(e);
		}
		return invoiceinfo;
	}	
 
	 @RequestMapping(method=RequestMethod.GET)
	 public InvoiceInfo getAllInvoiceInfos(@RequestParam(value = "projectId",defaultValue = "0") Integer projectId,
	 										@RequestParam(value = "pmId",defaultValue = "0") Integer pmId,
	 										@RequestParam(value = "dmId",defaultValue = "0") Integer dmId,
	 										@RequestParam(value = "ahId",defaultValue = "0") Integer ahId){
		 InvoiceInfo invoiceinfo=null;
		 Integer loggedInUid = (Integer) session.getAttribute("loggedInUid");
		 try{
			 if(service.isAR() || (loggedInUid.equals(pmId)) || loggedInUid.equals(dmId)  || loggedInUid.equals(ahId)){
				 if(projectId != 0){
					 invoiceinfo = repository.findByProjectId(projectId);
				 }
			 }
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return invoiceinfo;
	 }

	@RequestMapping(value="/{invoiceInfoId}",method=RequestMethod.GET)
	 public InvoiceInfo getInvoiceInfo(@PathVariable Integer invoiceInfoId){
		 InvoiceInfo invoiceinfo=null;
		 try{
			 if(service.isAR()){
				 invoiceinfo = repository.findOne(invoiceInfoId);
			 }
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return invoiceinfo;
	 }
	
	 @RequestMapping(value="/{invoiceInfoId}",method=RequestMethod.PUT)
	 public InvoiceInfo updateInvoiceInfo(@RequestBody InvoiceInfo updatedInvoiceInfo,@PathVariable Integer invoiceInfoId){
		 try{
			 if(service.isAR()){
				 updatedInvoiceInfo.setInvoiceInfoId(invoiceInfoId);
				 repository.save(updatedInvoiceInfo);
			 }
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return updatedInvoiceInfo;
	 }
	 
	 @RequestMapping(value="/{invoiceInfoId}",method=RequestMethod.DELETE)
	 public void deleteInvoiceInfo(@PathVariable Integer invoiceInfoId){
		 try{
			 if(service.isAR()){
				 repository.delete(invoiceInfoId);
			 }
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
	 }
	 
	 @GetMapping("/getInvoiceinfoByIds")
	 public InvoiceInfo getInvoiceinfoByIds(@RequestParam(value = "projectId",defaultValue = "0") Integer projectId,
	 										@RequestParam(value = "pmId",defaultValue = "0") Integer pmId,
	 										@RequestParam(value = "dmId",defaultValue = "0") Integer dmId,
	 										@RequestParam(value = "ahId",defaultValue = "0") Integer ahId){
		 InvoiceInfo invoiceinfo=null;
		 Integer loggedInUid = (Integer) session.getAttribute("loggedInUid");
		 try{
			 if(service.isAR() || (loggedInUid.equals(pmId)) || loggedInUid.equals(dmId)  || loggedInUid.equals(ahId)){
				 if(projectId != 0){
					 invoiceinfo = repository.findByProjectId(projectId);
				 }
			 }
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return invoiceinfo;
	 }
}
