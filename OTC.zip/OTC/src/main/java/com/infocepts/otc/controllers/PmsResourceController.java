package com.infocepts.otc.controllers;

import com.infocepts.pms.entities.PmsPerformance;
import com.infocepts.pms.entities.PmsResource;
import com.infocepts.pms.repositories.PmsCompetencyRepository;
import com.infocepts.pms.repositories.PmsGoalRepository;
import com.infocepts.pms.repositories.PmsPerformanceRepository;
import com.infocepts.pms.repositories.PmsResourceRepository;
import com.infocepts.otc.services.TimesheetService;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;



@RestController
@RequestMapping(value="/api/pms/resource",headers="referer")
public class PmsResourceController {

    final Logger logger = Logger.getLogger(PmsResourceController.class);

    @Autowired
    PmsResourceRepository repository;
    
    @Autowired
    PmsPerformanceRepository performanceRepository;
    
    @Autowired
    PmsGoalRepository goalRepository;
    
    @Autowired
    PmsCompetencyRepository compRepository;
    
    @Autowired
    HttpSession session;
    @Autowired
    TimesheetService service;
    
    @PersistenceContext(unitName = "pms")
    private EntityManager manager;

    @RequestMapping(method = RequestMethod.GET)
    public List<PmsResource> findResources(@RequestParam(value = "isPms", defaultValue = "0") Integer isPms,
    									@RequestParam(value = "cycleId", defaultValue = "0") Integer cycleId,
    									@RequestParam(value = "uid", defaultValue = "0") Integer uid,
										HttpServletRequest request){
        List<PmsResource> resourcelist = null;
        try {
        	Integer loggedInUid = (Integer) session.getAttribute("loggedInUid");
            if(isPms >= 1)
            {
            	// if the logged in user has HR-PMS role
            	if(service.isHRPmsAdmin() && isPms == 1){
            		resourcelist = manager.createNamedQuery("getPmsDataForAllResources", PmsResource.class)
            				.setParameter("filterHr", 0)
            				.setParameter("reportingManagersId",  0)
            				.setParameter("uid",  0)
            				.setParameter("cycleId",  cycleId)
            				.setParameter("portfolio",  "")
                            .getResultList();
            	}
            	else if(service.isHRPms() && isPms == 2){
            		resourcelist = manager.createNamedQuery("getPmsDataForAllResources", PmsResource.class)
            				.setParameter("filterHr", 1)
            				.setParameter("reportingManagersId",  0)
            				.setParameter("uid",  0)
            				.setParameter("cycleId",  cycleId)
            				.setParameter("portfolio",  "")
                            .getResultList();
            	}
        		else if(service.isPH() && isPms == 4){
        			
        			//Filter the list by portfolio name
            		List<String> res = service.getLoggedInUserPortfolio();
            		
        			for (String item : res){ //Loop through in case a person has multiple portfolios

            			List<PmsResource> resourcelistTemp = manager.createNamedQuery("getPmsDataForAllResources", PmsResource.class)
                				.setParameter("filterHr", 1)
                				.setParameter("reportingManagersId",  0)
                				.setParameter("uid",  0)
                				.setParameter("cycleId",  cycleId)
                				.setParameter("portfolio",  item)
                                .getResultList();
            			
            			if(resourcelist == null)
            				resourcelist = resourcelistTemp;
            			else
            				resourcelist.addAll(resourcelistTemp);
        			}
        			
            	}
                else
            	{
            		resourcelist = manager.createNamedQuery("getPmsDataForAllResources", PmsResource.class)
            				.setParameter("filterHr", 1)
            				.setParameter("reportingManagersId",  loggedInUid)
            				.setParameter("uid",  loggedInUid)
            				.setParameter("cycleId",  cycleId)
            				.setParameter("portfolio",  "")
                            .getResultList();
            	}
            }
            else if(uid != 0 && cycleId != 0) /* ------------- IMP - config data does not include the PMS performance object ----------------------------------------- */
            {
            	resourcelist = manager.createNamedQuery("getPmsConfigForResourceByUidandCycleId", PmsResource.class)
            			.setParameter("uid", uid)
            			.setParameter("cycleId", cycleId)
        				.getResultList();
            }
            else if(uid != 0) /* ------------- IMP - config data does not include the PMS performance object ----------------------------------------- */
            {
            	resourcelist = manager.createNamedQuery("getPmsConfigForResourceByUid", PmsResource.class)
            			.setParameter("uid", uid)
        				.getResultList();
            }
            else /* ------------- IMP - config data does not include the PMS performance object ----------------------------------------- */
            {
            	resourcelist = manager.createNamedQuery("getPmsConfigForAllResources", PmsResource.class)
            			.setParameter("cycleId",  cycleId)
        				.getResultList();
            }
        } 
		catch (Exception e){
            logger.error(e);
        }
        return resourcelist;

    }

    @RequestMapping(value="/{uid}",method=RequestMethod.GET)
    public PmsResource findResource(@PathVariable Integer uid) {
        PmsResource resource = null;
        try {
            resource = manager.createNamedQuery("getPmsConfigForResourceByUid", PmsResource.class)
                    .setParameter("uid", uid)
                    .getSingleResult();

        } catch (Exception e) {
            logger.error(e);
        }
        return resource;
    }
    
    /**
     * This method is add row in PMS Resource entity
     * 
     */
    @RequestMapping(method=RequestMethod.POST)
	public PmsResource addPmsResource(@RequestBody PmsResource pmsResource, HttpServletRequest request) {
		
    	//Restrict the save function to valid user only
    	if(!(service.isHRPms() || service.isHRPmsAdmin() || service.isAdmin()))
    	{
    		return null;
    	}
    	
		try{
			pmsResource.setId(null);
			repository.save(pmsResource);
		}
		catch(Exception e){
			logger.info(String.format("exception - ", e.getMessage()));
		}
	
		return pmsResource;
	}

    @RequestMapping(value = "/{id}", method = RequestMethod.PUT)
    public ResponseEntity<?> updateResource(@PathVariable("id") Integer id, @RequestBody PmsResource pmsResource) {
        
    	//Restrict the save function to valid user only
    	if(!(service.isHRPms() || service.isHRPmsAdmin() || service.isAdmin()))
    	{
    		return null;
    	}
    	
    	try {
        	pmsResource.setId(id);
            repository.save(pmsResource);
            
            // update performance object based on pmsresource columns -  *** IMP : udpate prod table for 0 as default value
            PmsPerformance performanceObject = null;            
            
            //forceful handshake
            if(pmsResource.getEnableHandshake()) {
            	            	
            	performanceObject = performanceRepository.findPmsPerformanceByUidandCycle(pmsResource.getUid(),pmsResource.getEnableHandshakeCycle());
            	 
            	 if(performanceObject != null) {
            		 
            		 //set to initiate state 0 
            		 if(pmsResource.getEnableHandshakeStatus() == 0) {     
            			 
            			 /*****delete goalObj*****/
            			 //goalRepository.deletePmsGoalByPerformanceId(performanceObject.getPerformanceId());
            			 
            			 /*****delete comp obj*****/
            			 //compRepository.deletePmsCompetencyByPerformanceId(performanceObject.getPerformanceId());
            			 
            			 /*****delete performanceObj*****/
            			 //performanceRepository.delete(performanceObject.getPerformanceId());
            		 }
            		 //set to draft state 5 / 10 / 15
            		 else if(pmsResource.getEnableHandshakeStatus() == 5 || pmsResource.getEnableHandshakeStatus() == 10 || pmsResource.getEnableHandshakeStatus() == 15) {
            			 /*****update goalobj for approval status*****/            			 
            			 goalRepository.updatePmsGoalByPerformanceId(performanceObject.getPerformanceId());
            			 
            			 performanceObject.setFormStatusGoalsetting(pmsResource.getEnableHandshakeStatus());  
                		 performanceObject.setFormStatusPitstop(null);
                		 performanceObject.setFormStatusEvaluation(null);
                		 performanceRepository.save(performanceObject);
            		 }          		
            		
            	 }            	
            }
            else if(pmsResource.getEnablePitstop()) {            	
            	performanceObject = performanceRepository.findPmsPerformanceByUidandCycle(pmsResource.getUid(),pmsResource.getEnablePitstopCycle());
            	
            	if(performanceObject != null) {
            		
            		 //set to initiate state 0            		 
            		performanceObject.setFormStatusPitstop(pmsResource.getEnablePitstopStatus());
                	performanceObject.setFormStatusEvaluation(null);
                	performanceRepository.save(performanceObject);
            	}            	
            }
            else if(pmsResource.getEnableEvaluation()) {
            	performanceObject = performanceRepository.findPmsPerformanceByUidandCycle(pmsResource.getUid(),pmsResource.getEnableEvaluationCycle());
            	
            	if(performanceObject != null) {
            		  performanceObject.setFormStatusEvaluation(pmsResource.getEnableEvaluationStatus());   
            		  performanceRepository.save(performanceObject);
					
					 // To discuss // self columns set to null
            		  if(pmsResource.getEnableEvaluationStatus() == 0) {//Evaluation | Not Initiated By Associate 
            			  
            			  performanceObject.setSelfRatingCompetency(null);
    					  performanceObject.setSelfRatingGoals(null);
    					  performanceObject.setSelfOverallRating(null);
    					 
    					  // Manager columns set to null
    					  performanceObject.setManagersRatingCompetency(null);
    					  performanceObject.setManagersRatingGoals(null);
    					  performanceObject.setManagersOverallRating(null);
    					 
    					  performanceObject.setManagersCommentsGoals(null);
    					  performanceObject.setManagersCommentsCompetency(null);
    					  performanceObject.setImprovementAreas(null);
    					  performanceObject.setReviewersImprovementAreas(null);
    					  
    					  // reviewer columns set to null
    					  performanceObject.setReviewersCommentsGoals(null);
    					  performanceObject.setReviewersCommentsCompetency(null);
            		  }
            		  else if(pmsResource.getEnableEvaluationStatus() == 5) {//Evaluation | Pending Associate Submit 
            			  
            			// Manager columns set to null
    					  performanceObject.setManagersRatingCompetency(null);
    					  performanceObject.setManagersRatingGoals(null);
    					  performanceObject.setManagersOverallRating(null);
    					 
    					  performanceObject.setManagersCommentsGoals(null);
    					  performanceObject.setManagersCommentsCompetency(null);
    					  performanceObject.setImprovementAreas(null);
    					  performanceObject.setReviewersImprovementAreas(null);
    					  
    					  // reviewer columns set to null
    					  performanceObject.setReviewersCommentsGoals(null);
    					  performanceObject.setReviewersCommentsCompetency(null);
            		  }
            		  else if(pmsResource.getEnableEvaluationStatus() == 10) {//Evaluation | Submitted By Associate 
            			  
              			// Manager columns set to null
      					  performanceObject.setManagersRatingCompetency(null);
      					  performanceObject.setManagersRatingGoals(null);
      					  performanceObject.setManagersOverallRating(null);
      					 
      					  performanceObject.setManagersCommentsGoals(null);
      					  performanceObject.setManagersCommentsCompetency(null);
      					  performanceObject.setImprovementAreas(null);
      					 performanceObject.setReviewersImprovementAreas(null);
      					  
      					  // reviewer columns set to null
      					  performanceObject.setReviewersCommentsGoals(null);
      					  performanceObject.setReviewersCommentsCompetency(null);
              		  }
            		  else if(pmsResource.getEnableEvaluationStatus() == 15) {//Evaluation | Pending Manager Submit 
            			  
            			  // reviewer columns set to null
    					  performanceObject.setReviewersCommentsGoals(null);
    					  performanceObject.setReviewersCommentsCompetency(null);
                	  }
            		  else if(pmsResource.getEnableEvaluationStatus() == 20) {//Evaluation | Submitted By Manager 
              			
      					  // reviewer columns set to null
      					  performanceObject.setReviewersCommentsGoals(null);
      					  performanceObject.setReviewersCommentsCompetency(null);
              		  }  
					 
            	}            	
           }
           
            
            
            
            return new ResponseEntity<>(HttpStatus.OK);
        } catch (Exception ex) {
            logger.error(ex);
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
