package com.infocepts.otc.utilities;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;

import java.util.logging.Logger;

public class InvoiceNoGenerator {
	
	final static Logger logger = Logger.getLogger(InvoiceNoGenerator.class.getName());
	
	final static String CreditNoteStr="Credit Note";
	
	public static String generateInvoiceno(String invoices, String numberType,String entity,Integer unit,String invoiceType, Date invoiceDate) throws Exception{
		String invoiceNo = "";
		try{
		String invoiceNoTemp = "";
		String nextYearStr = "";
		String prevYearStr = "";
		String yearStr = "";
		Integer tempInvoiceNo = 0;
		String tempNo = "";
		int nextYear = 0;
		int prevYear = 0;
		Date date = new Date();
		LocalDate localDate = date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
		int year  = localDate.getYear();
		//int monthNo = localDate.getMonthValue();
		LocalDate invoiceDt = invoiceDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
		int invoiceDtYear = invoiceDt.getYear();
		int monthNo 	  = invoiceDt.getMonthValue();
		
		//monthNo = monthNo - 1;
		logger.info("InvoiceNo Generator==============================invoices "+invoices);
		logger.info("InvoiceNo Generator=============invoice.getBillingEntity() "+entity);
		logger.info("InvoiceNo Generator===============invoice.getUnitId() "+unit);
		logger.info("InvoiceNo Generator=============================numberType "+numberType);
		if(invoices != null)
		{
			invoiceNoTemp = invoices;
			invoiceNoTemp = invoiceNoTemp.replaceAll("[^0-9]", "");
			if(LoadConstant.CO_LLC == unit){
				if(monthNo == 1) {
				if(invoiceDtYear < year) {
					year = invoiceDtYear;
				}
				}
				invoiceNoTemp = invoiceNoTemp.substring(4, invoiceNoTemp.length());
				tempInvoiceNo = Integer.parseInt(invoiceNoTemp) + 1;
				tempNo = String.format("%03d", tempInvoiceNo);
				if("draft".equals(numberType)){
					if(invoiceType.equals(CreditNoteStr)){
						invoiceNo = "DLLC" + year + "CR" +tempNo;
					}
					else{
						invoiceNo = "DLLC" + year+ tempNo;
					}
				}
				else{
					if(invoiceType.equals(CreditNoteStr)){
						invoiceNo = String.valueOf(year) + "CR"+ tempNo;
					}
					else{
						invoiceNo = String.valueOf(year) + tempNo;
					}
				}
			}else if(LoadConstant.CO_PTE == unit){
				invoiceNoTemp = invoiceNoTemp.toString().substring(6, invoiceNoTemp.length());
				tempInvoiceNo = Integer.parseInt(invoiceNoTemp) + 1;
				tempNo = String.format("%03d", tempInvoiceNo);
				if(monthNo > 3 ){
					nextYear = year + 1;
					nextYearStr = String.valueOf(nextYear).substring(2, 4);
					if("draft".equals(numberType)){
						if(invoiceType.equals(CreditNoteStr)){
							invoiceNo = "DIPL" + year + nextYearStr + "CR" + tempNo;
						}
						else{
							invoiceNo = "DIPL" + year + nextYearStr + tempNo;
						}
					}else{
						if(invoiceType.equals(CreditNoteStr)){
							invoiceNo = year + nextYearStr + "CR" + tempNo;
						}
						else{
							invoiceNo = year + nextYearStr + tempNo;
						}	
					}
					
				}else{
					prevYear = year - 1;
					yearStr = String.valueOf(year).substring(2, 4);
					if("draft".equals(numberType)){
						invoiceNo = "DIPL"+ prevYear + yearStr + tempNo;
					}else{
						invoiceNo = prevYear + yearStr + tempNo;
					}
					
				}
				
			}else if(LoadConstant.STPI_ITPL == unit){
				invoiceNoTemp = invoiceNoTemp.substring(4, invoiceNoTemp.length());
				tempInvoiceNo = Integer.parseInt(invoiceNoTemp) + 1;
				tempNo = String.format("%03d", tempInvoiceNo);
				if(monthNo > 3 ){
					nextYear = year + 1;
					nextYearStr = String.valueOf(nextYear).substring(2, 4);
					yearStr 	 = String.valueOf(year).substring(2, 4);
					if("draft".equals(numberType)){
						if(invoiceType.equals(CreditNoteStr))
						{
							invoiceNo = "DITPL" + yearStr + nextYearStr + "CR" + tempNo;
						}
						else{
							invoiceNo = "DITPL" + yearStr + nextYearStr + tempNo;
						}
					}else{
						if(invoiceType.equals(CreditNoteStr)){
							invoiceNo = yearStr + nextYearStr + "CR"+ tempNo;
						}
						else{
							invoiceNo = yearStr + nextYearStr + tempNo;
						}
					}
					
				}else{
					prevYear = year - 1;
					prevYearStr = String.valueOf(prevYear).substring(2, 4);
					yearStr = String.valueOf(year).substring(2, 4);
					if("draft".equals(numberType)){
						invoiceNo = "DITPL"+ prevYearStr + yearStr + tempNo;
					}else{
						invoiceNo = prevYearStr + yearStr + tempNo;
					}
					
				}
				
			}else if(LoadConstant.MIHAN_ITPL == unit){
				invoiceNoTemp = invoiceNoTemp.substring(4, invoiceNoTemp.length());
				tempInvoiceNo = Integer.parseInt(invoiceNoTemp) + 1;
				tempNo = String.format("%03d", tempInvoiceNo);
				if(monthNo > 3 ){
					nextYear = year + 1;
					nextYearStr = String.valueOf(nextYear).substring(2, 4);
					yearStr 	 = String.valueOf(year).substring(2, 4);
					if("draft".equals(numberType)){
						if(invoiceType.equals(CreditNoteStr))
						{
							invoiceNo = "DLUIII" + yearStr + nextYearStr + "CR" + tempNo;
						}
						else{
							invoiceNo = "DLUIII" + yearStr + nextYearStr + tempNo;
						}
					}else{
						if(invoiceType.equals(CreditNoteStr))
						{
							invoiceNo = "UIII" + yearStr + nextYearStr + "CR" + tempNo;
						}
						else{
							invoiceNo = "UIII" + yearStr + nextYearStr + tempNo;
						}
					}
					
				}else{
					prevYear = year - 1;
					prevYearStr = String.valueOf(prevYear).substring(2, 4);
					yearStr = String.valueOf(year).substring(2, 4);
					if("draft".equals(numberType)){
						invoiceNo = "DLUIII"+ prevYearStr + yearStr + tempNo;
					}else{
						invoiceNo = "UIII"+ prevYearStr + yearStr + tempNo;
					}
				}
			}else if(LoadConstant.BANGALORE_ITPL == unit){
				invoiceNoTemp = invoiceNoTemp.substring(4, invoiceNoTemp.length());
				tempInvoiceNo = Integer.parseInt(invoiceNoTemp) + 1;
				tempNo = String.format("%03d", tempInvoiceNo);
				if(monthNo > 3 ){
					nextYear = year + 1;
					nextYearStr = String.valueOf(nextYear).substring(2, 4);
					yearStr 	 = String.valueOf(year).substring(2, 4);
					if("draft".equals(numberType)){
//						if(invoiceType.equals(CreditNoteStr))
//						{
//							invoiceNo = "DLBLR" + yearStr + nextYearStr + "CR" + tempNo;
//						}
//						else{
							invoiceNo = "DLBLR" + yearStr + nextYearStr + tempNo;
//						}
					}else{
//						if(invoiceType.equals(CreditNoteStr))
//						{
//							invoiceNo = "UXI" + yearStr + nextYearStr + "CR" + tempNo;
//						}
//						else{
							invoiceNo = "BLR" + yearStr + nextYearStr + tempNo;
//						}
					}
					
				}else{
					prevYear = year - 1;
					prevYearStr = String.valueOf(prevYear).substring(2, 4);
					yearStr = String.valueOf(year).substring(2, 4);
					if("draft".equals(numberType)){
						invoiceNo = "DLBLR"+ prevYearStr + yearStr + tempNo;
					}else{
						invoiceNo = "BLR"+ prevYearStr + yearStr + tempNo;
					}
				}
			}else if(LoadConstant.CHENNAI_ITPL == unit){
				invoiceNoTemp = invoiceNoTemp.substring(4, invoiceNoTemp.length());
				tempInvoiceNo = Integer.parseInt(invoiceNoTemp) + 1;
				tempNo = String.format("%03d", tempInvoiceNo);
				if(monthNo > 3 ){
					nextYear = year + 1;
					nextYearStr = String.valueOf(nextYear).substring(2, 4);
					yearStr 	 = String.valueOf(year).substring(2, 4);
					if("draft".equals(numberType)){
//						if(invoiceType.equals(CreditNoteStr))
//						{
//							invoiceNo = "DLXI" + yearStr + nextYearStr + "CR" + tempNo;
//						}
//						else{
							invoiceNo = "DLCHN" + yearStr + nextYearStr + tempNo;
//						}
					}else{
//						if(invoiceType.equals(CreditNoteStr))
//						{
//							invoiceNo = "UXI" + yearStr + nextYearStr + "CR" + tempNo;
//						}
//						else{
							invoiceNo = "CHN" + yearStr + nextYearStr + tempNo;
//						}
					}
					
				}else{
					prevYear = year - 1;
					prevYearStr = String.valueOf(prevYear).substring(2, 4);
					yearStr = String.valueOf(year).substring(2, 4);
					if("draft".equals(numberType)){
						invoiceNo = "DLCHN"+ prevYearStr + yearStr + tempNo;
					}else{
						invoiceNo = "CHN"+ prevYearStr + yearStr + tempNo;
					}
				}
			}
		}
		}catch(Exception e){
			e.printStackTrace();
		}
		return invoiceNo;
	}
	
	public static String generateInvoiceno_CreditNote(String invoices, String numberType, Integer unit,String invoiceType){
		String invoiceNo="";
		String prevYearStr ="";
		String nextYearStr ="";
		String yearStr="";
		int nextYear = 0;
		int prevYear = 0;
		Date date = new Date();
		LocalDate localDate = date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
		int year  = localDate.getYear();
		nextYear = year + 1;
		nextYearStr = String.valueOf(nextYear).substring(2, 4);
		yearStr 	 = String.valueOf(year).substring(2, 4);
		if(invoices == ""){
			String tempNo="001";
			if(LoadConstant.STPI_ITPL == unit){
				if("draft".equals(numberType)){
					if(invoiceType.equals(CreditNoteStr)){
						invoiceNo = "DITPL"+ yearStr + nextYearStr + "CR" + tempNo;
					}
				}
				else{
					if(invoiceType.equals(CreditNoteStr)){
						invoiceNo = yearStr + nextYearStr + "CR" + tempNo;
					}
				}
			}
			else if(LoadConstant.MIHAN_ITPL == unit){
				if("draft".equals(numberType)){
					if(invoiceType.equals(CreditNoteStr)){
						invoiceNo = "DLUIII" + yearStr + nextYearStr + "CR" + tempNo;
					}
				}
				else{
					if(invoiceType.equals(CreditNoteStr)){
						invoiceNo = "UIII"+ yearStr + nextYearStr + "CR" + tempNo;
					}
				}
			}
			else if(LoadConstant.CO_PTE == unit){
				if("draft".equals(numberType)){
					if(invoiceType.equals(CreditNoteStr)){
						invoiceNo = "DIPL" + year + nextYearStr + "CR" + tempNo;
					}
				}
				else{
					if(invoiceType.equals(CreditNoteStr)){
						invoiceNo = year + nextYearStr + "CR" + tempNo;
					}
				}
			}
			else if(LoadConstant.CO_LLC == unit){
				if("draft".equals(numberType)){
					if(invoiceType.equals(CreditNoteStr)){
						invoiceNo = "DLLC" + year + "CR" +tempNo;
					}
				}
				else{
					if(invoiceType.equals(CreditNoteStr)){
						invoiceNo = String.valueOf(year) + "CR" +tempNo;
					}
				}
			}
			
		}
		return invoiceNo;
	}

	// TRavel Request tourCode NO generator
	public static String infoTravelTourCodeNo(String lastTourCode, Date creationDate) {
		//TPN1819xxx
		
		String tourCode="";
		String tempNo = "";
		String nextYearStr ="";
		String yearStr="";
		int nextYear = 0;

		Date date = new Date();
		LocalDate localDate = date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
		int year  = localDate.getYear(); //current year 2019
		nextYear = year + 1; //2020
		nextYearStr = String.valueOf(nextYear).substring(2, 4); //20
		yearStr 	 = String.valueOf(year).substring(2, 4); //19
		int prevYear = 0;
		
		LocalDate creationDt = creationDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
		int creationDtYear = creationDt.getYear(); //2019
		int monthNo 	  = creationDt.getMonthValue(); //4
		
		// logic for new financial year starting from April 1 - update the year series
		if(monthNo > 3 ){
			nextYear = year + 1; //2020
			nextYearStr = String.valueOf(nextYear).substring(2, 4); //"20"
			yearStr 	 = String.valueOf(year).substring(2, 4); //"19"
			
			//TPN1819002 => TPN1819001
			String lastNo =  String.valueOf(lastTourCode).substring(7, lastTourCode.length());	//001	
			int nextNo = Integer.parseInt(lastNo.trim()) + 1; //002
			tempNo = String.format("%03d", nextNo);//002
			tourCode = "TPN" + yearStr + nextYearStr +  tempNo; //TPN1920002

			logger.info("lastNo=");logger.info(lastNo);
			logger.info("nextNo=");logger.info(Integer.toString(nextNo));
			
		}
		// logic for current financial year from Jan - Mar - continue the year series
		else
		{
			year = creationDtYear; // 2019
			prevYear = year - 1; // 2018
			yearStr 	 = String.valueOf(year).substring(2, 4);
			String prevYearString = String.valueOf(prevYear).substring(2, 4);
			//TPN1819002 => TPN1819001
			String lastNo =  String.valueOf(lastTourCode).substring(7, lastTourCode.length());		
			int nextNo = Integer.parseInt(lastNo) + 1;
			tempNo = String.format("%03d", nextNo);
			tourCode = "TPN" + prevYearString + yearStr +  tempNo;
			

			logger.info("lastNo=");logger.info(lastNo);
			logger.info("nextNo=");logger.info(Integer.toString(nextNo));
		}
		
		
		logger.info("lastTourCode=");logger.info(lastTourCode);
		logger.info("newtourCode=");logger.info(tourCode);
		
		return tourCode;
	}

 public static String generateISowNo(String isow, Integer executionUnit) {
	 String isowNo = "";
		try{
		String isowNoTemp = "";
		String nextYearStr = "";
		String yearStr = "";
		Integer tempISowNo = 0;
		String tempNo = "";
		int nextYear = 0;
		int prevYear = 0;
		Date date = new Date();
		LocalDate localDate = date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
		int year  = localDate.getYear();
		int monthNo = localDate.getMonthValue();
		logger.info("ISOWNo Generator==============================isow "+isow);
		logger.info("ISOWNo Generator===============isow.getExecutionUnit() "+executionUnit);
			if("".equals(isow)){
				 tempNo="001";
				 nextYear = year + 1;
				 nextYearStr = String.valueOf(nextYear).substring(2, 4);
				 if(LoadConstant.STPI_ITPL == executionUnit){
					isowNo = "ISOWI"+ year +"-"+ nextYearStr +"-" + tempNo;
						
					}
					else if (LoadConstant.MIHAN_ITPL == executionUnit){
						isowNo = "ISOWIII"+year +"-"+ nextYearStr +"-" + tempNo;
						
					}
			}
			else if(isow != null)
			{
				isowNoTemp = isow;
				isowNoTemp = isowNoTemp.replaceAll("[^0-9]", "");
				System.out.println("isowNoTemp "+isowNoTemp);
				if(LoadConstant.STPI_ITPL == executionUnit){
					isowNoTemp = isowNoTemp.substring(6, isowNoTemp.length());
					tempISowNo = Integer.parseInt(isowNoTemp) + 1;
					tempNo = String.format("%03d", tempISowNo);
					if(monthNo > 3 ){
						nextYear = year + 1;
						nextYearStr = String.valueOf(nextYear).substring(2, 4);
						isowNo = "ISOWI" + year +"-"+ nextYearStr+"-" + tempNo;
					}else{
						prevYear = year - 1;
						yearStr = String.valueOf(year).substring(2, 4);
						isowNo = "ISOWI"+ prevYear +"-"+ yearStr+"-" + tempNo;
					}
					
				}else if(LoadConstant.MIHAN_ITPL == executionUnit){
					isowNoTemp = isowNoTemp.substring(6, isowNoTemp.length());
					tempISowNo = Integer.parseInt(isowNoTemp) + 1;
					tempNo = String.format("%03d", tempISowNo);
					if(monthNo > 3 ){
						nextYear = year + 1;
						nextYearStr = String.valueOf(nextYear).substring(2, 4);
						isowNo = "ISOWIII" + year +"-"+ nextYearStr+"-" + tempNo;
					}else{
						prevYear = year - 1;
						yearStr = String.valueOf(year).substring(2, 4);
						isowNo = "ISOWIII"+ prevYear +"-"+ yearStr+"-" + tempNo;
					}
				}
	}
	}catch(Exception e){
		e.printStackTrace();
	}
	 
	 return isowNo;
 }
}
