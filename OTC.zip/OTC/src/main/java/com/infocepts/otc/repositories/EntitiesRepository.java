package com.infocepts.otc.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.infocepts.otc.entities.Entities;

public interface EntitiesRepository extends CrudRepository<Entities,Integer>{

	@Override
	public List<Entities> findAll();
	
	@Query("from Entities e where e.country.countryId = :countryId")
	public List<Entities> findByCountryId(@Param("countryId") Integer countryId);
}
