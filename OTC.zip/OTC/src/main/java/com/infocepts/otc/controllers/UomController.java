package com.infocepts.otc.controllers;

import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.infocepts.otc.entities.Uom;
import com.infocepts.otc.repositories.UomRepository;
import com.infocepts.otc.services.TimesheetService;

@RestController
@RequestMapping(value="/uom",headers="referer")
public class UomController {

	final Logger logger = Logger.getLogger(UomController.class);
	
	@Autowired
	UomRepository repository;
	
	@Autowired
	TimesheetService service;
	
	@RequestMapping(method=RequestMethod.POST)
	public Uom addUom(@RequestBody Uom uom)
	{
		try{
			if(service.isAdmin()){
				uom.setUomId(null);
				repository.save(uom);
			}
				
		}catch(Exception e){
			logger.error(e);
		}
		return uom;
	}	
 
	 @RequestMapping(method=RequestMethod.GET)
	 public List<Uom> getAllUom(){
		 List<Uom> uomlist=null;
		 try{
			 uomlist = repository.findAll();
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return uomlist;
	 }
	 
	 @RequestMapping(value="/{uomId}",method=RequestMethod.GET)
	 public Uom getUomById(@PathVariable Integer uomId){
		 Uom uom=null;
		 try{
			 if(service.isAdmin()){
				 uom = repository.findOne(uomId);
			 }
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return uom;
	 }
	 
	 
	 @RequestMapping(value="/{uomId}",method=RequestMethod.PUT)
	 public Uom updateUom(@RequestBody Uom updatedUom,@PathVariable Integer uomId){
		 try{
			 if(service.isAdmin()){
				 updatedUom.setUomId(uomId);
				 repository.save(updatedUom);
			 }
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return updatedUom;
	 }
	 
	 @RequestMapping(value="/{uomId}",method=RequestMethod.DELETE)
	 public void deleteUom(@PathVariable Integer uomId){
		 try{
			 if(service.isAdmin()){
				 repository.delete(uomId);
			 }
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
	 }	 
}
