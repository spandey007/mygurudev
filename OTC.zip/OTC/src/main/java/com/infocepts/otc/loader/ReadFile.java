package com.infocepts.otc.loader;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

@Component
public class ReadFile {

	List lines;
	String fileName="src/main/resources/upload/Allocation_data.csv";
	public List readFile() throws IOException {
	    BufferedReader br = new BufferedReader(new FileReader(fileName));
	    lines = new ArrayList<String>();
	    String newLine;
	    while ((newLine = br.readLine()) != null) {	       
	        lines.add(newLine);
	       
	    }
	    br.close();
	    lines.remove(0);
	    return lines;
	}

}
