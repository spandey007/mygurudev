package com.infocepts.otc.controllers;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.infocepts.otc.entities.Portfolio;
import com.infocepts.otc.repositories.PortfolioRepository;
import com.infocepts.otc.services.TimesheetService;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(value="/portfolios",headers="referer")
public class PortfolioController {

	final Logger logger = Logger.getLogger(PortfolioController.class);
	
	@Autowired
	PortfolioRepository repository;
	
	@Autowired
	TimesheetService service;

    @RequestMapping(method=RequestMethod.GET)
    public List<Portfolio> getAllPortfolios(@RequestParam(value = "ownerId", defaultValue = "0") Integer ownerId,
											@RequestParam(value = "status", defaultValue = "") String status
    		
    		){
    	List<Portfolio> listPortfolio = null;
    	try{
    		if(ownerId!=0){
    			listPortfolio=repository.findByOwnerId(ownerId);
    		}
    		else if(!status.isEmpty()){
    			listPortfolio = this.repository.findByStatus(status);
    		}
    		else{
    			listPortfolio = this.repository.findAll();
    		}
        }
        catch(Exception e){
            logger.error(e);
        }
        return listPortfolio;
    }

	@RequestMapping(method=RequestMethod.POST)
	public Portfolio addPortfolio(@RequestBody Portfolio portfolio)
	{
		try{
			if(service.isAdmin()){
				portfolio.setItemId(null);
				repository.save(portfolio);
			}
		}catch(Exception e){
			logger.error(e);
		}
		return portfolio;
	}	

	@RequestMapping(value="/{itemId}",method=RequestMethod.GET)
	 public Portfolio getPortfolio(@PathVariable Integer itemId){
		 Portfolio portfolio=null;
		 try{
			 portfolio = repository.findOne(itemId);
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return portfolio;
	 }
	 
	@RequestMapping(value="/{itemId}",method=RequestMethod.PUT)
	 public Portfolio updatePortfolio(@RequestBody Portfolio updatedPortfolio,@PathVariable Integer itemId){
		 try{
			 if(service.isAdmin()){
				 updatedPortfolio.setItemId(itemId);
				 repository.save(updatedPortfolio);
			 }
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return updatedPortfolio;
	 }
	 
	 @RequestMapping(value="/{itemId}",method=RequestMethod.DELETE)
	 public void deletePortfolio(@PathVariable Integer itemId){
		 try{
			 if(service.isAdmin()){
				 repository.delete(itemId);
			 }
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
	 }	 
	 
	 @GetMapping("/getportfoliocount/{userId}")
		public Map<String, Object> getPortfolioCount(@PathVariable Integer userId) {
			Map<String, Object> countMap = new HashMap<>();
			countMap.putIfAbsent("portfolioHeadCount", repository.getPortfolioHeadCountForUser(userId));		
			return countMap;
		}
	 
	 @GetMapping("/getportfoliobyownerid/{portfolioOwnerId}")
	 public List<Portfolio> getPortfolioByOwnerId(@PathVariable Integer portfolioOwnerId) {
		 	List<Portfolio> listPortfolio = null;
		 	if(portfolioOwnerId!=0){
    			listPortfolio=repository.findByOwnerId(portfolioOwnerId);
    		}
    		else{
    			listPortfolio = this.repository.findAll();
    		}
			return listPortfolio;
		}
	
}

