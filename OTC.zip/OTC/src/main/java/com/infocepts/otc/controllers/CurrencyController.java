package com.infocepts.otc.controllers;

import java.util.List;

import javax.mail.MessagingException;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.infocepts.otc.entities.Currency;
import com.infocepts.otc.notification.SmtpMailSender;
import com.infocepts.otc.repositories.CurrencyRepository;
import com.infocepts.otc.services.TimesheetService;

@RestController
@RequestMapping(value="/currency",headers="referer")
public class CurrencyController {

	@Autowired
	CurrencyRepository repository;
	
	@Autowired
	TimesheetService service;
	
	@Autowired
	SmtpMailSender smtpMailSender;
	
	final Logger logger = Logger.getLogger(CurrencyController.class);
	
	
	@RequestMapping(method=RequestMethod.POST)
	public Currency addCurrency(@RequestBody Currency currency, HttpServletRequest request) throws MessagingException{
		try{
			if(service.isAdmin()){
				currency.setCurrencyId(null);
				repository.save(currency);	
				service.sendCurrencyNotification(currency, "add", request); 
			}
		}catch(Exception e){
			logger.error(e);
		}
		return currency;
	}	
 
	 @RequestMapping(method=RequestMethod.GET)
	 public List<Currency> getAllCurrency(@RequestParam(value = "allItem", defaultValue = "0") Integer allItem){
		 List<Currency> currencylist=null;
		 try{
			 
			 if(allItem == 1)
			 {
				 //visible to all permissions
				 currencylist = repository.findAll();
			 }
			 else{
				 currencylist = repository.findAllActive();
			 }
			 
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return currencylist;
	 }
	 
	 @RequestMapping(value="/{currencyId}",method=RequestMethod.GET)
	 public Currency getCurrencyById(@PathVariable Integer currencyId){
		 Currency currency=null;
		 try{
			 if(service.isAdmin()){
				 currency = repository.findOne(currencyId);
			 }
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return currency;
	 }
	 
	 @RequestMapping(value="/{currencyId}",method=RequestMethod.PUT)
	 public Currency updateCurrency(@RequestBody Currency updatedCurrency,@PathVariable Integer currencyId){
		 try{
			 if(service.isAdmin()){
				 updatedCurrency.setCurrencyId(currencyId);
				 repository.save(updatedCurrency);
			 }
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return updatedCurrency;
	 }
	 
	 @RequestMapping(value="/{currencyId}",method=RequestMethod.DELETE)
	 public void deleteCurrency(@PathVariable Integer currencyId){
		 try{
			 if(service.isAdmin()){
				 repository.delete(currencyId);
			 }
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
	 }	 
	 @GetMapping("/getCurrencies")
		public List<Currency> getCurrencies(@RequestParam(value = "allItem", defaultValue = "0") Integer allItem) {
		 List<Currency> currencylist=null;
		 try{
			 
			 if(allItem == 1)
			 {
				 //visible to all permissions
				 currencylist = repository.findAll();
			 }
			 else{
				 currencylist = repository.findAllActive();
			 }
			 
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return currencylist;

		}
}
