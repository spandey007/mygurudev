package com.infocepts.otc.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.infocepts.otc.utilities.LoadConstant;

@Entity
@Table(catalog=LoadConstant.otc, schema="[dbo]",name="shuttle")

public class Shuttle {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer shuttleId;

	public Integer getShuttleId() {
		return shuttleId;
	}

	public void setShuttleId(Integer shuttleId) {
		this.shuttleId = shuttleId;
	}
	
	
	//Getter and Setter
	
	
}
