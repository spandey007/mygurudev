package com.infocepts.otc.controllers;

import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.infocepts.otc.entities.Entities;
//import com.infocepts.otc.entities.Entities;
import com.infocepts.otc.repositories.EntitiesRepository;
import com.infocepts.otc.services.TimesheetService;

@RestController
@RequestMapping(value="/entities",headers="referer")
public class EntitiesController {
	
	final Logger logger = Logger.getLogger(EntitiesController.class);

	@Autowired
	EntitiesRepository repository;
	
	@Autowired
	TimesheetService service;
	

//	@RequestMapping(method=RequestMethod.POST)
//	public Entities addEntities(@RequestBody Entities entities)
//	{
//		try{
//			entities.setEntityId(null);
//			repository.save(entities);	
//		}catch(Exception e){
//			logger.error(e);
//		}
//		return entities;
//	}	
// 
	 @RequestMapping(method=RequestMethod.GET)
	 public List<Entities> getAllEntities(){
		 List<Entities> entitieslist=null;
		 try{
			 entitieslist = repository.findAll();
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return entitieslist;
	 }
	 
	 @RequestMapping(value="/{entityId}",method=RequestMethod.PUT)
	 public Entities updateEntities(@RequestBody Entities updatedEntities,@PathVariable Integer entityId){
		 try{
			 if(service.isAdmin()){
			 updatedEntities.setEntityId(entityId);
			 repository.save(updatedEntities);
			 }
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return updatedEntities;
	 }
	 
	 @RequestMapping(value="/{entityId}",method=RequestMethod.DELETE)
	 public void deleteEntities(@PathVariable Integer entityId){
		 try{
			 repository.delete(entityId);
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
	 }	 
}
