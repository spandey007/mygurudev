/**
 * 
 */
package com.infocepts.otc.controllers;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.infocepts.otc.entities.Expense;
import com.infocepts.otc.repositories.ExpenseRepository;
import com.infocepts.otc.utilities.ExpenseReportModel;

/**
 * @author Rewatiraman Singh
 *
 */
@RestController
@RequestMapping("/expenseReport")
public class ExpenseReportController extends Object {

	private static final Logger LOGGER = Logger.getLogger(ExpenseReportController.class.getName());
	
	@Autowired
	private ExpenseRepository expenseRepository;
	
	@PersistenceContext(unitName = "otc")
	private EntityManager manager;
	
	@GetMapping("/search")
	public Object search(@ModelAttribute ExpenseReportModel model, HttpServletRequest request) {
		Map<String, List<Expense>> expenseMap = new HashMap<>();
		try {
			expenseMap.putIfAbsent("expenses", expenseRepository.search(manager, model));
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, "SOMETHING WENT WRONG WHILE SEARCHING EXPENSES!", e);
		}
		return expenseMap;
	}
}
