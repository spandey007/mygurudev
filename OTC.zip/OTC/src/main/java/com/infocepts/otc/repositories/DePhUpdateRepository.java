/**
* Filename: /src/main/java/com/infocepts/otc/repositories/DePhUpdateRepository.java
* @author  SHRI
* @version 1.0
* @since   2019-11-28 
*/
package com.infocepts.otc.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.infocepts.otc.entities.DeMsr;
import com.infocepts.otc.entities.DePhUpdate;
import com.infocepts.otc.entities.DeWsr;

public interface DePhUpdateRepository extends CrudRepository<DePhUpdate,Integer>{

	@Override
	public List<DePhUpdate> findAll();	
		
	@Query("from DePhUpdate where projectId = :projectId")
	List<DePhUpdate> findByProjectID(@Param("projectId")Integer projectId);
	
}