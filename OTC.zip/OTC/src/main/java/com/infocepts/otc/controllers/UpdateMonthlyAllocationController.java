package com.infocepts.otc.controllers;

import java.util.List;

import javax.mail.MessagingException;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.thymeleaf.context.Context;

import com.infocepts.otc.entities.Account;
import com.infocepts.otc.entities.Allocation;
import com.infocepts.otc.entities.MonthlyAllocation;
import com.infocepts.otc.entities.Project;
import com.infocepts.otc.entities.Resource;
import com.infocepts.otc.entities.SowDetail;
import com.infocepts.otc.notification.SmtpMailSender;
import com.infocepts.otc.repositories.AllocationRepository;
import com.infocepts.otc.repositories.ProjectRepository;
import com.infocepts.otc.repositories.SowDetailRepository;
import com.infocepts.otc.services.MonthlyAllocationService;
import com.infocepts.otc.services.TimesheetService;



@RestController
@RequestMapping(value="/allocation")//JV: Added 'headers' param to validate the url.
public class UpdateMonthlyAllocationController {
	
	final Logger logger = Logger.getLogger(UpdateMonthlyAllocationController.class);

	@Autowired
	AllocationRepository repository;
	
	@Autowired
	ProjectRepository projectRepository;
	
	@Autowired
	MonthlyAllocationService monthlyAllocationService;
	
	@Autowired
	TimesheetService service;
	
	@Autowired
	HttpSession session;
	
	@Autowired
	SmtpMailSender smtpMailSender;
	
	 /*@RequestMapping(value="/updateMonthlyAllocation")
	 public void updateMonthlyAllocation(){	
		 List<Allocation> allocationList = null;
		 try{
			 allocationList = repository.findAllallocationToUpdate();
			 
			 for (Allocation allocation : allocationList) {
				 monthlyAllocationService.InsertUpdateMonthlyAllocation(allocation);
			}
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
	 } 	*/
}

