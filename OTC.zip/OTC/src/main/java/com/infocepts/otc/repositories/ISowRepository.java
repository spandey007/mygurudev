/**
* Filename: /src/main/java/com/infocepts/otc/controllers/ISowRepository.java
* @author  JV
* @version 1.0
* @since   2018-10-31 
*/
package com.infocepts.otc.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.infocepts.otc.entities.ISow;

public interface ISowRepository extends JpaRepository<ISow,Integer>{

	@Override
	public List<ISow> findAll();
}

