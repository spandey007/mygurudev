package com.infocepts.otc.controllers;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;

import javax.mail.MessagingException;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.infocepts.otc.entities.Cms;
import com.infocepts.otc.notification.SmtpMailSender;
import com.infocepts.otc.repositories.AccountRepository;
import com.infocepts.otc.repositories.CmsRepository;
import com.infocepts.otc.repositories.ProjectRepository;
import com.infocepts.otc.services.TimesheetService;
import com.infocepts.otc.utilities.LoadConstant;

@RestController
@RequestMapping(value="/cms",headers="referer")
public class CmsController {

	@Autowired
	CmsRepository repository;
	
	@Autowired
	HttpSession session;
	
	@Autowired
	ResourceController resourceController;
	
	@Autowired
	SmtpMailSender smtpMailSender;
	
	@Autowired
	TimesheetService service;
		
	@Autowired
	AccountRepository accountRepository;
	
	@Autowired
	private ProjectRepository projectRepository;
	
	@PersistenceContext(unitName="otc")
    private EntityManager manager;
	
	final Logger logger = Logger.getLogger(CmsController.class);
	
	private static final java.util.logging.Logger JAVA_LOGGER = java.util.logging.Logger.getLogger(CmsController.class.getName());
	//private Integer sessionUid = session.getAttribute("uid") == null ? 0 :Integer.valueOf(session.getAttribute("uid").toString());
	
	
	@RequestMapping(method=RequestMethod.POST)
	public Cms addCms(@RequestBody Cms cms, HttpServletRequest request) throws MessagingException{
		try{
			if(service.isG5AndAboveGrade()){
				cms.setCmsId(null);
				repository.save(cms);	
				
				if(!cms.getIsRevenuePlanning())
					service.sendCmsNotification(cms, "add", request); // Allocation add / update solution
			}
		}catch(Exception e){
			logger.error(e);
		}
		return cms;
	}	
 
	 @RequestMapping(method=RequestMethod.GET)
	 public List<Cms> getAllCms(@RequestParam(value = "uid", defaultValue = "0") Integer uid,
			 					@RequestParam(value = "cepUid", defaultValue = "0") Integer cepUid,
								@RequestParam(value = "dmUid", defaultValue = "0") Integer dmUid,
								@RequestParam(value = "accountId", defaultValue = "0") Integer accountId,
								@RequestParam(value = "year", defaultValue = "0") Integer year,
	 							@RequestParam(value = "gridView", defaultValue = "false") Boolean gridView){
		 
		 List<Cms> cmslist=null;
		 try{
			if(uid != 0)
			{		
				cmslist = manager.createNamedQuery("getCmsByCreatedBy_RM_DM", Cms.class)		
						.setParameter("uid", uid)	
						.getResultList();
			}
			else if(year != 0)
			{	
				if(service.isBP() || service.isPH() || service.isCEP() || service.isLeadership() || service.isFA())
				{
					cmslist = manager.createNamedQuery("getCmsRevenueByMonth", Cms.class)		
							.setParameter("year", year)
							.setParameter("accountId", accountId)
							.setParameter("cepId", cepUid)
							.setParameter("phId", dmUid)	
							.getResultList();
				}
			}
			else if(gridView == true)
			{
				cmslist = manager.createNamedQuery("getAllCmsForExport", Cms.class)		
						.getResultList();
			}
			else
			{
				cmslist = manager.createNamedQuery("getAllCms", Cms.class)		
						.getResultList();
			}
			
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return cmslist;
	 }
	 
	 @RequestMapping(value="/{cmsId}",method=RequestMethod.GET)
	 public Cms getByCmsId(@PathVariable Integer cmsId){
		 Cms cms =null;
		 try{
			 cms = manager.createNamedQuery("getCmsById", Cms.class)		
						.setParameter("cmsId", cmsId)	
						.getSingleResult();
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return cms;
	 }
	
	 
	 
	 @RequestMapping(value="/{cmsId}",method=RequestMethod.PUT)
	 public Cms updateCms(@RequestBody Cms updatedCms,@PathVariable Integer cmsId, HttpServletRequest request) throws MessagingException{
		 try{
			 if(service.isG5AndAboveGrade()){
				 updatedCms.setCmsId(cmsId);
				 repository.save(updatedCms);
				 try {
					 new Thread(()-> projectRepository.updateAccountIdForTreq(updatedCms.getAccountId(), getTreqsByCmsId(cmsId))).start();
				} catch (Exception e) {
					JAVA_LOGGER.log(Level.SEVERE, "(CMS Module) Something went wrong while updating the accountId in related treqs!", e);
				}
				 if(updatedCms.getIsRevenuePlanning() != null){
				 	if( !updatedCms.getIsRevenuePlanning())
					 	service.sendCmsNotification(updatedCms, "update", request); // Allocation add / update solution	
			 	 }
			 }
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return updatedCms;
	 }
	 
	 @RequestMapping(value="/{cmsId}",method=RequestMethod.DELETE)
	 public void deleteCms(@PathVariable Integer cmsId){
		 try{
			 if(service.isG5AndAboveGrade()){
				 repository.delete(cmsId);
			 }
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
	 }	 
	
	 @SuppressWarnings("rawtypes")
	private List getTreqsByCmsId(int cmsId) {
		final String sqlString = "select t.treqId from " + LoadConstant.otc + ".dbo.treq t inner join "
				+ LoadConstant.otc + ".dbo.cmsDetail c" + " on c.cmsDetailId = t.cmsDetailId where c.cmsId = :cmsId"
				+ " and c.status = 'Proposed' and t.sowDetailId is null";
		 try {
			 return manager.createNativeQuery(sqlString).setParameter("cmsId", cmsId).getResultList();
		} catch (Exception e) {
			JAVA_LOGGER.log(Level.SEVERE, String.format("Something went wrong while fetching treqs with cmsId : %s!", cmsId), e);
		}
		return new ArrayList<>();
	 }
}
