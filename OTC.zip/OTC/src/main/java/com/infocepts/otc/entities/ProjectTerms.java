package com.infocepts.otc.entities;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import com.infocepts.otc.utilities.LoadConstant;

@Entity
@Table(catalog=LoadConstant.otc, schema="[dbo]",name="projectTerms")
public class ProjectTerms {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer projectTermsId;
	
	private Integer projectId;
	
	@ManyToOne
	@JoinColumn(name="termId")
	private TermCondition termCondition;
	
	private Integer createdBy;
	private Date createdDate;

	public Integer getProjectTermsId() {
		return projectTermsId;
	}

	public void setProjectTermsId(Integer projectTermsId) {
		this.projectTermsId = projectTermsId;
	}
	
	public Integer getProjectId() {
		return projectId;
	}

	public void setProjectId(Integer projectId) {
		this.projectId = projectId;
	}

	public TermCondition getTermCondition() {
		return termCondition;
	}

	public void setTermCondition(TermCondition termCondition) {
		this.termCondition = termCondition;
	}

	public Integer getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

}
