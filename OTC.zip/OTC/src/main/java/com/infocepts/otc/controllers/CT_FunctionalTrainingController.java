package com.infocepts.otc.controllers;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.infocepts.otc.entities.CT_BehavioralTraining;
import com.infocepts.otc.entities.CT_FunctionalTraining;
import com.infocepts.otc.repositories.CT_FunctionalTrainingRepository;
import com.infocepts.otc.services.TimesheetService;

@RestController
@RequestMapping(value="/functionalTraining",headers="referer")
public class CT_FunctionalTrainingController {
	@Autowired
	CT_FunctionalTrainingRepository ct_FunctionalTrainingRepository;
	
	@Autowired
	TimesheetService service;
	
	@PersistenceContext(unitName = "otc")
	private EntityManager manager;
	
	@RequestMapping(method=RequestMethod.POST)
	public CT_FunctionalTraining addCT_FunctionalTraining(@RequestBody CT_FunctionalTraining cT_FunctionalTraining){
		cT_FunctionalTraining.setFunctionalTrainingId(null);
		Boolean isAValidCall = false;
		if(service.isHR() || service.isAdmin())
		{
			isAValidCall = true;
		}
		if(isAValidCall) {
			
			ct_FunctionalTrainingRepository.save(cT_FunctionalTraining);
		}
		return cT_FunctionalTraining;
	}
	
	@RequestMapping(method=RequestMethod.GET)
	public List<CT_FunctionalTraining> getCT_FunctionalTraining(){
		List<CT_FunctionalTraining> list = null;
		Boolean isAValidCall = false;
		if(service.isHR() || service.isAdmin())
		{
			isAValidCall = true;
		}
		if(isAValidCall) {
		System.out.println("inside getAllFunctionalTraining page");
		list =  manager.createNamedQuery("getAllFunctionalTraining",CT_FunctionalTraining.class)
				.getResultList();
		}
		return list;
	}
	
	@RequestMapping(value="/{functionalTrainingId}",method=RequestMethod.GET)
	public CT_FunctionalTraining getCT_FunctionalTraining(@PathVariable Integer functionalTrainingId){
		CT_FunctionalTraining cT_FunctionalTraining = null;
		Boolean isAValidCall = false;
		if(service.isHR() || service.isAdmin())
		{
			isAValidCall = true;
		}
		if(isAValidCall) {
			
			cT_FunctionalTraining = ct_FunctionalTrainingRepository.findOne(functionalTrainingId);
		}
		return cT_FunctionalTraining;
	}
	
	@RequestMapping(value="/{functionalTrainingId}", method=RequestMethod.PUT)
	public CT_FunctionalTraining updateCT_FunctionalTraining(@PathVariable Integer functionalTrainingId,  @RequestBody CT_FunctionalTraining updatedCT_FunctionalTraining){
		updatedCT_FunctionalTraining.setFunctionalTrainingId(functionalTrainingId);
		Boolean isAValidCall = false;
		if(service.isHR() || service.isAdmin())
		{
			isAValidCall = true;
		}
		if(isAValidCall) {
		ct_FunctionalTrainingRepository.save(updatedCT_FunctionalTraining);
		}
		return updatedCT_FunctionalTraining;
	}
	
	@RequestMapping(value="/{functionalTrainingId}",method=RequestMethod.DELETE)
	public void deleteCT_FunctionalTraining(@PathVariable Integer functionalTrainingId){
		Boolean isAValidCall = false;
		if(service.isHR() || service.isAdmin())
		{
			isAValidCall = true;
		}
		if(isAValidCall) {
		ct_FunctionalTrainingRepository.delete(functionalTrainingId);
		}
	}
}

