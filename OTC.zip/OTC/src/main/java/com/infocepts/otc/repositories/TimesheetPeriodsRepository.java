package com.infocepts.otc.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.infocepts.otc.entities.TimesheetPeriods;



@Repository
public interface TimesheetPeriodsRepository extends JpaRepository<TimesheetPeriods,Integer>{

	@Override
	public List<TimesheetPeriods> findAll();
	
	@Query("select tsp FROM TimesheetPeriods tsp where tsp.locked = :state order by tsp.periodStart")
    public List<TimesheetPeriods> findAllPeriodsByStatus(@Param("state") Boolean state);
}
