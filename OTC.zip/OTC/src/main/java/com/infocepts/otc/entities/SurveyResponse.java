/**
* Filename: /src/main/java/com/infocepts/otc/entities/SurveyResponse.java
* @author  SRA
* @version 1.0
* @since   2018-08-01 
*/
package com.infocepts.otc.entities;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.persistence.*;
import javax.validation.constraints.NotNull;

import com.infocepts.otc.utilities.LoadConstant;
@Entity
@Table(catalog=LoadConstant.otc, schema="[dbo]", name="surveyResponse")

@SqlResultSetMappings({
        @SqlResultSetMapping(
                name = "surveyResponseList",
                classes = {
                        @ConstructorResult(
                                targetClass = SurveyResponse.class,
                                columns = {
                                		@ColumnResult(name = "responceId"),
										@ColumnResult(name = "surveyId"),
                                        @ColumnResult(name = "email", type = String.class),
                                        @ColumnResult(name = "userName", type = String.class),
                                        @ColumnResult(name = "responce1", type = String.class),
                                        @ColumnResult(name = "responce2", type = String.class),
                                        @ColumnResult(name = "responce3", type = String.class),
                                        @ColumnResult(name = "responce4", type = String.class),
                                        @ColumnResult(name = "responce5", type = String.class),
                                        @ColumnResult(name = "responce6", type = String.class),
                                        @ColumnResult(name = "responce7", type = String.class),
                                        @ColumnResult(name = "responce8", type = String.class),
                                        @ColumnResult(name = "responce9", type = String.class),
                                        @ColumnResult(name = "responce10", type = String.class),
                                        @ColumnResult(name = "responce11", type = String.class),
                                        @ColumnResult(name = "responce12", type = String.class),
                                        @ColumnResult(name = "responce13", type = String.class),
                                        @ColumnResult(name = "responce14", type = String.class),
                                        @ColumnResult(name = "responce15", type = String.class),
                                        @ColumnResult(name = "responce16", type = String.class),
                                        @ColumnResult(name = "responce17", type = String.class),
                                        @ColumnResult(name = "responce18", type = String.class),
                                        @ColumnResult(name = "responce19", type = String.class),
                                        @ColumnResult(name = "responce20", type = String.class),
                                        @ColumnResult(name = "responce21", type = String.class),
                                        @ColumnResult(name = "responce22", type = String.class),
                                        @ColumnResult(name = "responce23", type = String.class),
                                        @ColumnResult(name = "responce24", type = String.class),
                                        @ColumnResult(name = "responce25", type = String.class),
                                        @ColumnResult(name = "responce26", type = String.class),
                                        @ColumnResult(name = "responce27", type = String.class),
                                        @ColumnResult(name = "responce28", type = String.class),
                                        @ColumnResult(name = "responce29", type = String.class),
                                        @ColumnResult(name = "responce30", type = String.class),
                                        @ColumnResult(name = "responce31", type = String.class),
                                        @ColumnResult(name = "responce32", type = String.class),
                                        @ColumnResult(name = "responce33", type = String.class),
                                        @ColumnResult(name = "responce34", type = String.class),
                                        @ColumnResult(name = "responce35", type = String.class),
                                        @ColumnResult(name = "responce36", type = String.class),
                                        @ColumnResult(name = "responce37", type = String.class),
                                        @ColumnResult(name = "responce38", type = String.class),
                                        @ColumnResult(name = "responce39", type = String.class),
                                        @ColumnResult(name = "responce40", type = String.class),
                                        @ColumnResult(name = "modifiedDate", type = Date.class),
                                        @ColumnResult(name = "createdDate", type = Date.class),
                                        @ColumnResult(name = "createdUid", type = Integer.class),
                                        @ColumnResult(name = "modifiedUid", type = Integer.class),
                                        
                                        @ColumnResult(name = "title", type = String.class),
                                        @ColumnResult(name = "empId", type = Integer.class),
                                        @ColumnResult(name = "band", type = String.class),
                                        @ColumnResult(name = "role", type = String.class),
                                        @ColumnResult(name = "grade", type = String.class),
                                        @ColumnResult(name = "department", type = String.class),
                                        @ColumnResult(name = "surveyName", type = String.class)
                                      
                                }
                        )
                }
        )
})
@NamedNativeQueries({
        @NamedNativeQuery(
        		 name    =   "SurveyResponseQuery",  

                 query     =  "Select sr.*," +
                             "r.title as title,"+
                             "r.empId as empId,"+
                             "b.band as band,"+
                             "ro.role as role,"+
                             "g.grade as grade,"+
                             "d.departmentName as department,"+
                             "s.title as surveyName"+
                             " from " + LoadConstant.otc + ".[dbo].surveyResponse as sr"+

                             " LEFT JOIN  " + LoadConstant.infomaster + ".[dbo].[resource] r on r.email = sr.email"+
                             " LEFT JOIN  " + LoadConstant.infomaster + ".[dbo].[band] b on b.bandId = r.bandId"+
                             " LEFT JOIN  " + LoadConstant.infomaster + ".[dbo].[grade] g on g.gradeId = r.gradeId"+
                             " LEFT JOIN  " + LoadConstant.infomaster + ".[dbo].[hrRoles] ro on ro.hrRoleId = r.hrRoleId"+
                             " LEFT JOIN  " + LoadConstant.infomaster + ".[dbo].[department] d on d.departmentId = r.departmentId"+
                             " LEFT JOIN  " + LoadConstant.otc + ".[dbo].[survey] s on s.surveyId = sr.surveyId"+
                             " where sr.surveyId = s.surveyId",
							 
							resultClass=SurveyResponse.class, resultSetMapping = "surveyResponseList" 
        )        
})
public class SurveyResponse {
	
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public Integer getEmpId() {
		return empId;
	}
	public void setEmpId(Integer empId) {
		this.empId = empId;
	}
	public String getBand() {
		return band;
	}
	public void setBand(String band) {
		this.band = band;
	}
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}

	// Entity Columns
    // --------------------------------------------------------------------------------
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Integer responceId; 
	
    @NotNull
    private Integer surveyId;
    private String email;
    private String userName;
    @Lob
    private String responce1;
    @Lob
    private String responce2;
    @Lob
    private String responce3;
    @Lob
    private String responce4;
    @Lob
    private String responce5;
    @Lob
    private String responce6;
    @Lob
    private String responce7;
    @Lob
    private String responce8;
    @Lob
    private String responce9;
    @Lob
    private String responce10;
    @Lob
    private String responce11;
    @Lob
    private String responce12;
    @Lob
    private String responce13;
    @Lob
    private String responce14;
    @Lob
    private String responce15;
    @Lob
    private String responce16;
    @Lob
    private String responce17;
    @Lob
    private String responce18;
    @Lob
    private String responce19;
    @Lob
    private String responce20;
    @Lob
    private String responce21;
    @Lob
    private String responce22;
    @Lob
    private String responce23;
    @Lob
    private String responce24;
    @Lob
    private String responce25;
    @Lob
    private String responce26;
    @Lob
    private String responce27;
    @Lob
    private String responce28;
    @Lob
    private String responce29;
    @Lob
    private String responce30;
    @Lob
    private String responce31;
    @Lob
    private String responce32;
    @Lob
    private String responce33;
    @Lob
    private String responce34;
    @Lob
    private String responce35;
    @Lob
    private String responce36;
    @Lob
    private String responce37;
    @Lob
    private String responce38;
    @Lob
    private String responce39;
    @Lob
    private String responce40;
    private Date modifiedDate;
    private Date createdDate;
    private Integer createdUid;
    private Integer modifiedUid;
    
    //Transient variable for extra fields
    @Transient
    private String title;
    @Transient
    private Integer empId;
    @Transient
    private String band;
    @Transient
    private String role;
    @Transient
    private String surveyName;
    
    public String getSurveyName() {
		return surveyName;
	}
	public void setSurveyName(String surveyName) {
		this.surveyName = surveyName;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}

	@Transient
    private String grade;
    @Transient
    private String department;

    
    
	public Integer getResponceId() {
		return responceId;
	}
	public void setResponceId(Integer responceId) {
		this.responceId = responceId;
	}
	public Integer getSurveyId() {
		return surveyId;
	}
	public void setSurveyId(Integer surveyId) {
		this.surveyId = surveyId;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getResponce1() {
		return responce1;
	}
	public void setResponce1(String responce1) {
		this.responce1 = responce1;
	}
	public String getResponce2() {
		return responce2;
	}
	public void setResponce2(String responce2) {
		this.responce2 = responce2;
	}
	public String getResponce3() {
		return responce3;
	}
	public void setResponce3(String responce3) {
		this.responce3 = responce3;
	}
	public String getResponce4() {
		return responce4;
	}
	public void setResponce4(String responce4) {
		this.responce4 = responce4;
	}
	public String getResponce5() {
		return responce5;
	}
	public void setResponce5(String responce5) {
		this.responce5 = responce5;
	}
	public String getResponce6() {
		return responce6;
	}
	public void setResponce6(String responce6) {
		this.responce6 = responce6;
	}
	public String getResponce7() {
		return responce7;
	}
	public void setResponce7(String responce7) {
		this.responce7 = responce7;
	}
	public String getResponce8() {
		return responce8;
	}
	public void setResponce8(String responce8) {
		this.responce8 = responce8;
	}
	public String getResponce9() {
		return responce9;
	}
	public void setResponce9(String responce9) {
		this.responce9 = responce9;
	}
	public String getResponce10() {
		return responce10;
	}
	public void setResponce10(String responce10) {
		this.responce10 = responce10;
	}
	public String getResponce11() {
		return responce11;
	}
	public void setResponce11(String responce11) {
		this.responce11 = responce11;
	}
	public String getResponce12() {
		return responce12;
	}
	public void setResponce12(String responce12) {
		this.responce12 = responce12;
	}
	public String getResponce13() {
		return responce13;
	}
	public void setResponce13(String responce13) {
		this.responce13 = responce13;
	}
	public String getResponce14() {
		return responce14;
	}
	public void setResponce14(String responce14) {
		this.responce14 = responce14;
	}
	public String getResponce15() {
		return responce15;
	}
	public void setResponce15(String responce15) {
		this.responce15 = responce15;
	}
	public String getResponce16() {
		return responce16;
	}
	public void setResponce16(String responce16) {
		this.responce16 = responce16;
	}
	public String getResponce17() {
		return responce17;
	}
	public void setResponce17(String responce17) {
		this.responce17 = responce17;
	}
	public String getResponce18() {
		return responce18;
	}
	public void setResponce18(String responce18) {
		this.responce18 = responce18;
	}
	public String getResponce19() {
		return responce19;
	}
	public void setResponce19(String responce19) {
		this.responce19 = responce19;
	}
	public String getResponce20() {
		return responce20;
	}
	public void setResponce20(String responce20) {
		this.responce20 = responce20;
	}
	public String getResponce21() {
		return responce21;
	}
	public void setResponce21(String responce21) {
		this.responce21 = responce21;
	}
	public String getResponce22() {
		return responce22;
	}
	public void setResponce22(String responce22) {
		this.responce22 = responce22;
	}
	public String getResponce23() {
		return responce23;
	}
	public void setResponce23(String responce23) {
		this.responce23 = responce23;
	}
	public String getResponce24() {
		return responce24;
	}
	public void setResponce24(String responce24) {
		this.responce24 = responce24;
	}
	public String getResponce25() {
		return responce25;
	}
	public void setResponce25(String responce25) {
		this.responce25 = responce25;
	}
	public String getResponce26() {
		return responce26;
	}
	public void setResponce26(String responce26) {
		this.responce26 = responce26;
	}
	public String getResponce27() {
		return responce27;
	}
	public void setResponce27(String responce27) {
		this.responce27 = responce27;
	}
	public String getResponce28() {
		return responce28;
	}
	public void setResponce28(String responce28) {
		this.responce28 = responce28;
	}
	public String getResponce29() {
		return responce29;
	}
	public void setResponce29(String responce29) {
		this.responce29 = responce29;
	}
	public String getResponce30() {
		return responce30;
	}
	public void setResponce30(String responce30) {
		this.responce30 = responce30;
	}
	public String getResponce31() {
		return responce31;
	}
	public void setResponce31(String responce31) {
		this.responce31 = responce31;
	}
	public String getResponce32() {
		return responce32;
	}
	public void setResponce32(String responce32) {
		this.responce32 = responce32;
	}
	public String getResponce33() {
		return responce33;
	}
	public void setResponce33(String responce33) {
		this.responce33 = responce33;
	}
	public String getResponce34() {
		return responce34;
	}
	public void setResponce34(String responce34) {
		this.responce34 = responce34;
	}
	public String getResponce35() {
		return responce35;
	}
	public void setResponce35(String responce35) {
		this.responce35 = responce35;
	}
	public String getResponce36() {
		return responce36;
	}
	public void setResponce36(String responce36) {
		this.responce36 = responce36;
	}
	public String getResponce37() {
		return responce37;
	}
	public void setResponce37(String responce37) {
		this.responce37 = responce37;
	}
	public String getResponce38() {
		return responce38;
	}
	public void setResponce38(String responce38) {
		this.responce38 = responce38;
	}
	public String getResponce39() {
		return responce39;
	}
	public void setResponce39(String responce39) {
		this.responce39 = responce39;
	}
	public String getResponce40() {
		return responce40;
	}
	public void setResponce40(String responce40) {
		this.responce40 = responce40;
	}
	public Date getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public Integer getCreatedUid() {
		return createdUid;
	}
	public void setCreatedUid(Integer createdUid) {
		this.createdUid = createdUid;
	}
	public Integer getModifiedUid() {
		return modifiedUid;
	}
	public void setModifiedUid(Integer modifiedUid) {
		this.modifiedUid = modifiedUid;
	}
	// Constructor
		// ---------------------------------------------------------------------------------
	public SurveyResponse(Integer responceId, Integer surveyId, String email, String userName, String responce1,
			String responce2, String responce3, String responce4, String responce5, String responce6, String responce7,
			String responce8, String responce9, String responce10, String responce11, String responce12,
			String responce13, String responce14, String responce15, String responce16, String responce17,
			String responce18, String responce19, String responce20, String responce21, String responce22,
			String responce23, String responce24, String responce25, String responce26, String responce27,
			String responce28, String responce29, String responce30, String responce31, String responce32,
			String responce33, String responce34, String responce35, String responce36, String responce37,
			String responce38, String responce39, String responce40, Date modifiedDate, Date createdDate,
			Integer createdUid, Integer modifiedUid, String title, Integer empId, String band, String role, String grade, String department,String surveyName ) {
		super();
		this.responceId = responceId;
		this.surveyId = surveyId;
		this.email = email;
		this.userName = userName;
		this.responce1 = responce1;
		this.responce2 = responce2;
		this.responce3 = responce3;
		this.responce4 = responce4;
		this.responce5 = responce5;
		this.responce6 = responce6;
		this.responce7 = responce7;
		this.responce8 = responce8;
		this.responce9 = responce9;
		this.responce10 = responce10;
		this.responce11 = responce11;
		this.responce12 = responce12;
		this.responce13 = responce13;
		this.responce14 = responce14;
		this.responce15 = responce15;
		this.responce16 = responce16;
		this.responce17 = responce17;
		this.responce18 = responce18;
		this.responce19 = responce19;
		this.responce20 = responce20;
		this.responce21 = responce21;
		this.responce22 = responce22;
		this.responce23 = responce23;
		this.responce24 = responce24;
		this.responce25 = responce25;
		this.responce26 = responce26;
		this.responce27 = responce27;
		this.responce28 = responce28;
		this.responce29 = responce29;
		this.responce30 = responce30;
		this.responce31 = responce31;
		this.responce32 = responce32;
		this.responce33 = responce33;
		this.responce34 = responce34;
		this.responce35 = responce35;
		this.responce36 = responce36;
		this.responce37 = responce37;
		this.responce38 = responce38;
		this.responce39 = responce39;
		this.responce40 = responce40;
		this.modifiedDate = modifiedDate;
		this.createdDate = createdDate;
		this.createdUid = createdUid;
		this.modifiedUid = modifiedUid;
		
		this.title = title ;
		this.empId = empId;
		this.band = band ;
		this.role = role;
		this.grade = grade;
		this.department= department;
		this.surveyName = surveyName;
	}
    

	
	
	
}
