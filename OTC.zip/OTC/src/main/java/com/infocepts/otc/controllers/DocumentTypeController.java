package com.infocepts.otc.controllers;


import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.infocepts.otc.entities.DocumentType;
import com.infocepts.otc.repositories.DocumentTypeRepository;
import com.infocepts.otc.services.TimesheetService;

@RestController
@RequestMapping(value="/documenttype",headers="referer")
public class DocumentTypeController {

		final Logger logger = Logger.getLogger(DocumentTypeController.class);
		
		@Autowired
		DocumentTypeRepository repository;
		
		@Autowired
		TimesheetService service;
		
		@RequestMapping(method=RequestMethod.POST)
		public DocumentType addDocumentType(@RequestBody DocumentType documenttype)
		{
			try{
				if(service.isAdmin()){
					documenttype.setDocumentTypeId(null);
					repository.save(documenttype);	
				}
			}catch(Exception e){
				logger.error(e);
			}
			return documenttype;
		}	
	 
		 @RequestMapping(method=RequestMethod.GET)
		 public List<DocumentType> getAllDocumentTypes(){
			 List<DocumentType> documenttypelist=null;
			 try{
				 documenttypelist = repository.findAllActive();				 
			 }
			 catch(Exception e){
				 logger.error(e);
			 }
			 return documenttypelist;
		 }

		@RequestMapping(value="/{documentTypeId}",method=RequestMethod.GET)
		 public DocumentType getDocumentType(@PathVariable Integer documentTypeId){
			 DocumentType documenttype=null;
			 try{
				 if(service.isAdmin()){
					 documenttype = repository.findOne(documentTypeId);
				 }
			 }
			 catch(Exception e){
				 logger.error(e);
			 }
			 return documenttype;
		 }
		 
		@RequestMapping(value="/{documentTypeId}",method=RequestMethod.PUT)
		 public DocumentType updateDocumentType(@RequestBody DocumentType updatedDocumentType,@PathVariable Integer documentTypeId){
			 try{
				 if(service.isAdmin()){
					 updatedDocumentType.setDocumentTypeId(documentTypeId);
					 repository.save(updatedDocumentType);
				 }
			 }
			 catch(Exception e){
				 logger.error(e);
			 }
			 return updatedDocumentType;
		 }
		 
		 @RequestMapping(value="/{documentTypeId}",method=RequestMethod.DELETE)
		 public void deleteDocumentType(@PathVariable Integer documentTypeId){
			 try{
				 if(service.isAdmin()){
					 repository.delete(documentTypeId);
				 }
			 }
			 catch(Exception e){
				 logger.error(e);
			 }
		 }	 
}


