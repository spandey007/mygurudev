package com.infocepts.otc.entities;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.infocepts.otc.utilities.LoadConstant;

@Entity
@Table(catalog=LoadConstant.otc, schema="[dbo]",name="sowMilestone")
public class SowMilestone {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer sowMilestoneId;
	
	private Integer milestoneId;

	private Date milestoneStartDate;
	private Date milestoneEndDate;
	
	@Column(precision=12,scale=2)
	private BigDecimal offshoreAmount;
	
	@Column(precision=12,scale=2)
	private BigDecimal onsiteAmount;
	
	
	@Column(precision=12,scale=2)
	private BigDecimal amount;
	
	@Lob
	private String milestonecomments;
	
	@Lob
	private String description;
	
    private Date createdDate;
	private Date modifiedDate;
	//only added for migration
//	private String sowNo;
//	private String clientPo;
//	private String comments;
//	private String quantity;
//	private String currency;
//	private String currencySign;
//	private String fbProjectId;
//	private String fixedbiddetailId;
	
	@ManyToOne
	//@OnDelete(action=OnDeleteAction.CASCADE)
	@JoinColumn(name="sowId")
	private Sow sow;
	
	private Integer createdBy;
	private Integer modifiedBy;
	
	
	public Integer getSowMilestoneId() {
		return sowMilestoneId;
	}
	public void setSowMilestoneId(Integer sowMilestoneId) {
		this.sowMilestoneId = sowMilestoneId;
	}
	public Integer getMilestoneId() {
		return milestoneId;
	}
	public void setMilestoneId(Integer milestoneId) {
		this.milestoneId = milestoneId;
	}
	public Date getMilestoneStartDate() {
		return milestoneStartDate;
	}
	public void setMilestoneStartDate(Date milestoneStartDate) {
		this.milestoneStartDate = milestoneStartDate;
	}
	public Date getMilestoneEndDate() {
		return milestoneEndDate;
	}
	public void setMilestoneEndDate(Date milestoneEndDate) {
		this.milestoneEndDate = milestoneEndDate;
	}
	public BigDecimal getAmount() {
		return amount;
	}
	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}
	public String getMilestonecomments() {
		return milestonecomments;
	}
	public void setMilestonecomments(String milestonecomments) {
		this.milestonecomments = milestonecomments;
	}
	public Sow getSow() {
		return sow;
	}
	public void setSow(Sow sow) {
		this.sow = sow;
	}
	public Integer getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}
	public Integer getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public Date getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	/**
	 * @return the offshoreAmount
	 */
	public BigDecimal getOffshoreAmount() {
		return offshoreAmount;
	}
	/**
	 * @param offshoreAmount the offshoreAmount to set
	 */
	public void setOffshoreAmount(BigDecimal offshoreAmount) {
		this.offshoreAmount = offshoreAmount;
	}
	/**
	 * @return the onsiteAmount
	 */
	public BigDecimal getOnsiteAmount() {
		return onsiteAmount;
	}
	/**
	 * @param onsiteAmount the onsiteAmount to set
	 */
	public void setOnsiteAmount(BigDecimal onsiteAmount) {
		this.onsiteAmount = onsiteAmount;
	}
	
	
//	public String getSowNo() {
//		return sowNo;
//	}
//	public void setSowNo(String sowNo) {
//		this.sowNo = sowNo;
//	}
//	public String getClientPo() {
//		return clientPo;
//	}
//	public void setClientPo(String clientPo) {
//		this.clientPo = clientPo;
//	}
//	public String getComments() {
//		return comments;
//	}
//	public void setComments(String comments) {
//		this.comments = comments;
//	}
//	public String getQuantity() {
//		return quantity;
//	}
//	public void setQuantity(String quantity) {
//		this.quantity = quantity;
//	}
//	public String getCurrency() {
//		return currency;
//	}
//	public void setCurrency(String currency) {
//		this.currency = currency;
//	}
//	public String getCurrencySign() {
//		return currencySign;
//	}
//	public void setCurrencySign(String currencySign) {
//		this.currencySign = currencySign;
//	}
//	public String getFbProjectId() {
//		return fbProjectId;
//	}
//	public void setFbProjectId(String fbProjectId) {
//		this.fbProjectId = fbProjectId;
//	}
//	public String getFixedbiddetailId() {
//		return fixedbiddetailId;
//	}
//	public void setFixedbiddetailId(String fixedbiddetailId) {
//		this.fixedbiddetailId = fixedbiddetailId;
//	}
	
}
