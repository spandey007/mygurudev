package com.infocepts.otc.services;

import java.lang.reflect.Array;
import java.net.InetAddress;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;

import javax.mail.MessagingException;
import javax.persistence.EntityManager;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.apache.http.HttpRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.thymeleaf.context.Context;

import com.infocepts.otc.controllers.InfoCabDriverController;
import com.infocepts.otc.controllers.InfoCabVehicleController;
import com.infocepts.otc.controllers.InfoTravelController;
import com.infocepts.otc.controllers.InfoTravelDetailController;
import com.infocepts.otc.controllers.InfoTravellerController;
import com.infocepts.otc.controllers.ProjectController;
import com.infocepts.otc.controllers.ResourceController;
import com.infocepts.otc.controllers.SurveyController;
import com.infocepts.otc.controllers.UnitController;
import com.infocepts.otc.entities.Account;
import com.infocepts.otc.entities.ActionItem;
import com.infocepts.otc.entities.Allocation;
import com.infocepts.otc.entities.AmgRoles;
import com.infocepts.otc.entities.BusNodalPoint;
import com.infocepts.otc.entities.BusPass;
import com.infocepts.otc.entities.BusRoute;
import com.infocepts.otc.entities.City;
import com.infocepts.otc.entities.Cms;
import com.infocepts.otc.entities.CmsDetail;
import com.infocepts.otc.entities.Coe;
import com.infocepts.otc.entities.Country;
import com.infocepts.otc.entities.Currency;
import com.infocepts.otc.entities.DEGovernanceNotes;
import com.infocepts.otc.entities.DeAppreciation;
import com.infocepts.otc.entities.DeComplaint;
import com.infocepts.otc.entities.DeGovernance;
import com.infocepts.otc.entities.DeMsr;
import com.infocepts.otc.entities.DeValueAdd;
import com.infocepts.otc.entities.DeWsr;
import com.infocepts.otc.entities.ExitAccess;
import com.infocepts.otc.entities.ExitForm;
import com.infocepts.otc.entities.Grade;
import com.infocepts.otc.entities.ISow;
import com.infocepts.otc.entities.InfoCab;
import com.infocepts.otc.entities.InfoCabDriver;
import com.infocepts.otc.entities.InfoCabVehicle;
import com.infocepts.otc.entities.InfoTravel;
import com.infocepts.otc.entities.InfoTravelDetail;
import com.infocepts.otc.entities.InfoTraveller;
import com.infocepts.otc.entities.Invoices;
import com.infocepts.otc.entities.Portfolio;
import com.infocepts.otc.entities.Project;
import com.infocepts.otc.entities.ProjectTask;
import com.infocepts.otc.entities.ProjectType;
import com.infocepts.otc.entities.Resource;
import com.infocepts.otc.entities.ResourceRoles;
import com.infocepts.otc.entities.Skill;
import com.infocepts.otc.entities.Sow;
import com.infocepts.otc.entities.SowDetail;
import com.infocepts.otc.entities.Survey;
import com.infocepts.otc.entities.TargetAudience;
import com.infocepts.otc.entities.Treq;
import com.infocepts.otc.entities.Unit;
import com.infocepts.otc.entities.WorkLocation;
import com.infocepts.otc.notification.SmtpMailSender;
import com.infocepts.otc.repositories.AccountRepository;
import com.infocepts.otc.repositories.ActionItemRepository;
import com.infocepts.otc.repositories.AmgRolesRepository;
import com.infocepts.otc.repositories.BusNodalPointRepository;
import com.infocepts.otc.repositories.CmsDetailRepository;
import com.infocepts.otc.repositories.CmsRepository;
import com.infocepts.otc.repositories.GradeRepository;
import com.infocepts.otc.repositories.InfoCabDriverRepository;
import com.infocepts.otc.repositories.InfoCabVehicleRepository;
import com.infocepts.otc.repositories.InfoTravelDetailRepository;
import com.infocepts.otc.repositories.InfoTravelRepository;
import com.infocepts.otc.repositories.InfoTravellerRepository;
import com.infocepts.otc.repositories.PortfolioRepository;
import com.infocepts.otc.repositories.ProjectRepository;
import com.infocepts.otc.repositories.ProjectTypeRepository;
import com.infocepts.otc.repositories.ResourceRepository;
import com.infocepts.otc.repositories.ResourceRolesRepository;
import com.infocepts.otc.repositories.SkillRepository;
import com.infocepts.otc.repositories.SowDetailRepository;
import com.infocepts.otc.repositories.SowRepository;
import com.infocepts.otc.repositories.SurveyRepository;
import com.infocepts.otc.repositories.TargetAudienceRepository;
import com.infocepts.otc.repositories.UnitRepository;
import com.infocepts.otc.repositories.CoeRepository;
import com.infocepts.otc.repositories.ExchangeRateRepository;
import com.infocepts.otc.utilities.DateConverter;
import com.infocepts.otc.utilities.InfoTravelUtil;
import com.infocepts.otc.utilities.LoadConstant;
import com.infocepts.pms.entities.PmsResource;
import com.infocepts.pms.repositories.PmsResourceRepository;
import java.util.logging.Level;
@Component
public class TimesheetServiceImpl implements TimesheetService{

	final Logger logger = Logger.getLogger(TimesheetServiceImpl.class.getName());
	@Autowired
	HttpSession session;

	@Autowired
	ResourceRepository resourceRepository;

	@Autowired
	ResourceRolesRepository resourceRolesRepository;

	@Autowired
	SowRepository sowRepository;

	@Autowired
	ProjectRepository projectRepository;

	@Autowired
	ProjectController projectController;

	@Autowired
	ResourceController resourceController;
	
	@Autowired
	UnitController unitController;
	
	@Autowired
	InfoTravellerController infoTravellerController;

	@Autowired
	SowDetailRepository sowDetailRepository;

	@Autowired
	private SmtpMailSender smtpMailSender;

	@Autowired
	AccountRepository accountRepository;
	
	
	@Autowired
	SkillRepository skillRepository;

	@Autowired
	CmsDetailRepository cmsDetailRepository;

	@Autowired
	CmsRepository cmsRepository;
	
	@Autowired
	AmgRolesRepository	amgRolesRepository;

	@Autowired
	GradeRepository gradeRepository;
	
	@Autowired
	ProjectTypeRepository projectTypeRepository;
	
	@Autowired
	BusNodalPointRepository busNodalPointRepository;
	
	@Autowired
	PortfolioRepository portfolioRepository;
	
	@Autowired
	UnitRepository unitRepository;
	
	@Autowired
	InfoTravellerRepository infoTravellerRepository;
	
	@Autowired
	PmsResourceRepository pmsResourceRepository;
	
	@Autowired
	InfoTravelDetailRepository infoTravelDetailRepository;
	
	@Autowired
	InfoTravelDetailController infoTravelDetailController;

	@Autowired
	ActionItemRepository actionItemRepository;
	
	@Autowired
	InfoTravelController infoTravelController;
	
	@Autowired
	InfoTravelRepository infoTravelRepository;
	
	@Autowired
	 private InfoTravelUtil infoTravelUtil;
	@Autowired
	SurveyController surveyController;

	@Autowired
	SurveyRepository surveyRepository;
	
	@Autowired
	TargetAudienceRepository targetAudienceRepository;
	@Autowired
	ExchangeRateRepository 	ExchangeRateRepository;
	
	@Autowired
	BusNodalPointRepository BusNodalPointRepository;
	
	@Autowired
	InfoCabDriverController infoCabDriverController;
	
	@Autowired
	InfoCabVehicleController infoCabVehicleController;

	@Autowired
	CoeRepository CoeRepository;
	/* Function to check if the call is from  valid user */
	@Override
	public boolean isAValidUserCall(Integer uid) {
		Boolean retVal = false;

		Integer loggedInUid = (Integer) session.getAttribute("loggedInUid");
		if(uid != 0) {
			if(loggedInUid.equals(uid))
			{
				retVal = true;
			}
			
		}
		return retVal;
	}
	
	/* Function to check if the call is from  valid user */
	@Override
	public boolean isAValidTimesheetCall(Integer uid) {
		Boolean retVal = false;

		Integer loggedInUid = (Integer) session.getAttribute("loggedInUid");
		if(uid != 0) {
			if(loggedInUid.equals(uid))
			{
				retVal = true;
			}
			else
			{
                retVal = isValidDelegation(uid);
            }
		}
		return retVal;
	}
	
	/* Function to check if the call is from  valid user */
	@Override
	public boolean isAValidPmsCall(Integer uid) {
		Boolean retVal = false;

		Integer loggedInUid = (Integer) session.getAttribute("loggedInUid");
		if(uid != 0) {
			if(loggedInUid.equals(uid))
			{
				retVal = true;
			}
			else
			{
				PmsResource loggedInResource = pmsResourceRepository.findResourceById(uid);
				if(loggedInResource != null)
				{
					Integer pmsManagersId = loggedInResource.getPmsManagerId();
					Integer pmsReviewersId = loggedInResource.getPmsReviewerId();
					if(loggedInUid.equals(pmsManagersId) || loggedInUid.equals(pmsReviewersId))
					{
						retVal = true; // delegation is valid
					}
		        }
            }
		}
		return retVal;
	}

	@Override
	public boolean isAValidSOWCall(Integer projectId, Integer sowId, String section, HttpServletRequest request)  throws MessagingException {
		Boolean isAValidCall = false;
		Integer loggedInUid = (Integer) session.getAttribute("loggedInUid");
		if(projectId == 0)
		{
			if(sowId != 0)
			{
				Sow sow = sowRepository.findOne(sowId);
				if(sow != null)
				{
					projectId = sow.getProjectId();
				}
			}
		}
		if(projectId != 0)
		{
			Account accnt= null;
			Integer ahUid=0;
			Project proj = projectRepository.getOne(projectId);
			
			if(proj.getAccountId() != null) {
				accnt = accountRepository.getOne(proj.getAccountId());
				if(accnt != null) {
					ahUid = accnt.getAhId();
				}					
			}			
			if(proj != null)
			{
				Integer projectTypeId=proj.getProjectTypeId();
				ProjectType projectType = projectTypeRepository.findOne(projectTypeId);
				String projectname="Internal Billing";
				if(projectType.getName().equals(projectname)){
					if(isAR() || isFA()){
						isAValidCall = true;
					}
				}
				Integer pmUid = proj.getProjectManagersId();				
				
				//To get the planners access for the project
				String planners=proj.getPlannersId();
				List<String> strList = new ArrayList<String>(Arrays.asList(planners.split(",")));
				List<Integer> intList = new ArrayList<Integer>();
				for(String s : strList) intList.add(Integer.valueOf(s));
				//if the loggedInUser is a Project Planner he will also have access to Project Task
			    if(intList.contains(loggedInUid)){
			    	isAValidCall = true;
				}
				if(loggedInUid.equals(pmUid)) // If the current logged in user is not the project manager of the passed project (pid)
				{
					isAValidCall = true;
				}
				if(loggedInUid.equals(ahUid)) // If the current logged in user is not the account head of the passed project (pid)
				{
					isAValidCall = true;
				}
				else if(isAValidAdminRole())
				{
					isAValidCall = true;
				}
				if(isAValidCall == false) {
					sendTamperedMail(section, 0, projectId, request);
				}
			}
		 }
		return isAValidCall;
	}

	@Override
	public boolean isAValidProjectCall(Integer projectId, String section, HttpServletRequest request)  throws MessagingException {
		Boolean isAValidCall = false;

		Integer loggedInUid = (Integer) session.getAttribute("loggedInUid");
		Integer loggedInUsersGrade = 0;
		try {
			loggedInUsersGrade = Integer.parseInt((String) session.getAttribute("grade"));
		} catch (Exception e) {
			logger.log(Level.SEVERE, "Could not parse the grade value, arg2", e);
		}
		if(projectId == 0) // Add user case
		{
			if(loggedInUsersGrade >= 5 || isPmo())
			{
				isAValidCall = true;
			}
		}
		else // Edit user case
        {
			Project proj = projectRepository.getOne(projectId);
			if(proj != null)
			{
				Integer pmUid = proj.getProjectManagersId();
				if(loggedInUid.equals(pmUid)) // If the current logged in user is not the project manager of the passed project (pid)
				{
					isAValidCall = true;
				}
				else if(isPmo())
				{
					isAValidCall = true;
                }
				else if(isDE())
				{
					isAValidCall = true;
				}
			}
		 }
		if(isAValidCall == false) {
			sendTamperedMail(section, 0, projectId, request);
		}
		return isAValidCall;
	}

	@Override
	public boolean isValidDelegation(Integer uid) {

		Boolean retVal = false;
		Integer loggedInUid = (Integer) session.getAttribute("loggedInUid");

		Resource delegatedResource = resourceRepository.findResourceById(uid);
		if(delegatedResource != null)
		{
			Integer timesheetDelegateId = delegatedResource.getTimesheetDelegatesId();
			if(loggedInUid.equals(timesheetDelegateId))
			{
				retVal = true; // delegation is valid
			}
        }
		return retVal;
    }

	@Override
	public boolean isAValidAdminRole() {
		Boolean retVal = false;
		Integer loggedInUid = (Integer) session.getAttribute("loggedInUid");
		List<ResourceRoles> resourcesRoles = resourceRolesRepository.findResourceRoles(loggedInUid);

		ArrayList<String> roles = new ArrayList<String>();

		roles.add("ADMIN");
		roles.add("AMG");
		roles.add("PMO");
		roles.add("AR");
		roles.add("BI");
		roles.add("FA");

        if (resourcesRoles.size() > 0)
		{
			for (ResourceRoles role : resourcesRoles) {
				if(roles.contains(role.getRoles().getRole())){
					retVal = true;
				}
			}
		}
		return retVal;
	 }

	@Override
	public boolean isAdmin() {
		Boolean retVal = false;
		Integer loggedInUid = (Integer) session.getAttribute("loggedInUid");
		List<ResourceRoles> resourcesRoles = resourceRolesRepository.findResourceRoles(loggedInUid);

		ArrayList<String> roles = new ArrayList<String>();

		roles.add("ADMIN");

        if (resourcesRoles.size() > 0)
		{
			for (ResourceRoles role : resourcesRoles) {
				if(roles.contains(role.getRoles().getRole())){
					retVal = true;
				}
			}
		}
		return retVal;
	 }

	@Override
	public boolean sendTamperedMail(String endPointName, Integer uid, Integer pid, HttpServletRequest request) throws MessagingException
	{
		Integer loggedInUid = (Integer) session.getAttribute("loggedInUid");
		Context context = new Context();

		String tamperedByName = "";
		String tamperedName = "";

		Resource tamperedByResource = resourceRepository.findResourceById(loggedInUid);
		if(tamperedByResource != null)
		{
			tamperedByName = tamperedByResource.getFirstName()+' '+tamperedByResource.getLastName();
		}
		if(uid != 0)
		{
			Resource tamperedResource = resourceRepository.findResourceById(uid);
			tamperedName = tamperedResource.getFirstName()+' '+tamperedResource.getLastName();

			context.setVariable("uid",uid);
			context.setVariable("UserDetail", tamperedName);

			System.out.println("Tampered Call in "+endPointName+" By - "+tamperedByName+'-'+loggedInUid+" for "+tamperedName+'-'+uid);
		}
		else if(pid != 0)
		{
			Project proj = projectRepository.getOne(pid);
			if(proj != null)
			{
                tamperedName = proj.getTitle();
				context.setVariable("UserDetail", tamperedName);
			}
        }
		else if(uid == 0 && pid == 0)
		{
			context.setVariable("UserDetail", "All Projects");
		}

		String ccEmails = LoadConstant.INFOBIZ;
		context.setVariable("TamperedDetail", tamperedByName);
		context.setVariable("loggedInUid",loggedInUid);

		String mailSubject = "Tampered Call in "+endPointName;

		smtpMailSender.send("",LoadConstant.INFOBIZ, mailSubject,"mail/tamperedCall", context,ccEmails,request);
		System.out.println("Tampered Call in "+endPointName+" By - "+tamperedByName+'-'+loggedInUid+" for "+tamperedName+'-'+uid);

		return true;
	}

	@Override
	public boolean isPmo() {
		Boolean retVal=false;
		Integer uid=(Integer)session.getAttribute("loggedInUid");
		List<ResourceRoles> resourceRoles=resourceRolesRepository.findResourceRoles(uid);

		ArrayList<String> roles = new ArrayList<String>();

		roles.add("ADMIN");
		roles.add("PMO");

        if (resourceRoles.size() > 0)
		{
			for (ResourceRoles role : resourceRoles)
			{
				if(roles.contains(role.getRoles().getRole())){
					retVal = true;
				}
			}
		}
		return retVal;
	}
	
	@Override
	public boolean isFA() {
		Boolean retVal=false;
		Integer uid=(Integer)session.getAttribute("loggedInUid");
		List<ResourceRoles> resourceRoles=resourceRolesRepository.findResourceRoles(uid);

		ArrayList<String> roles = new ArrayList<String>();

		roles.add("ADMIN");
		roles.add("FA");

        if (resourceRoles.size() > 0)
		{
			for (ResourceRoles role : resourceRoles)
			{
				if(roles.contains(role.getRoles().getRole())){
					retVal = true;
				}
			}
		}
		return retVal;
	}
	
	@Override
	public boolean isLegal() {
		Boolean retVal=false;
		Integer uid=(Integer)session.getAttribute("loggedInUid");
		List<ResourceRoles> resourceRoles=resourceRolesRepository.findResourceRoles(uid);

		ArrayList<String> roles = new ArrayList<String>();

		roles.add("ADMIN");
		roles.add("Legal");

        if (resourceRoles.size() > 0)
		{
			for (ResourceRoles role : resourceRoles)
			{
				if(roles.contains(role.getRoles().getRole())){
					retVal = true;
				}
			}
		}
		return retVal;
	}
	
	@Override
	public boolean isBF() {
		Boolean retVal=false;
		Integer uid=(Integer)session.getAttribute("loggedInUid");
		List<ResourceRoles> resourceRoles=resourceRolesRepository.findResourceRoles(uid);

		ArrayList<String> roles = new ArrayList<String>();

		roles.add("ADMIN");
		roles.add("BF");

        if (resourceRoles.size() > 0)
		{
			for (ResourceRoles role : resourceRoles)
			{
				if(roles.contains(role.getRoles().getRole())){
					retVal = true;
				}
			}
		}
		return retVal;
	}

	@Override
	public Integer getUserPM(Integer uid) {
		
		Integer pmId = null;
		Resource resource = resourceRepository.findResourceById(uid);
		if(resource != null)
		{
			pmId = resource.getReportingManagerId();
		}
		return pmId;
	}

	@Override
	public Integer getMonth(String tsmonth) {
		Integer month = null;

		String[] monthParts = tsmonth.split("-");
		if(Array.getLength(monthParts) >= 2)
		{
            if (!StringUtils.isBlank(monthParts[1])) month = Integer.parseInt(monthParts[1]);
		}
		return month;
	}

	@Override
	public Integer getYear(String tsmonth) {
		Integer year = null;
		String[] monthParts = tsmonth.split("-");
		if(Array.getLength(monthParts) >= 2)
		{
			if(!StringUtils.isBlank(monthParts[0])) year = Integer.parseInt(monthParts[0]);
		}
		return year;
	}
	


	@Override
	public List<String> getLoggedInUserPortfolio() {
		// TODO Auto-generated method stub
		
		Integer uid=(Integer)session.getAttribute("loggedInUid");
		
		List<String> portfolioNames = new ArrayList<>();
		List<Portfolio> portfolios = portfolioRepository.findByOwnerId(uid);
		
		for (Portfolio portfolio : portfolios) {
			portfolioNames.add(portfolio.getTitle());
		}
		
		
		return portfolioNames;
	}

	@Override
	public boolean isTravel() {
		Boolean retVal=false;
		Integer uid=(Integer)session.getAttribute("loggedInUid");
		List<ResourceRoles> resourceRoles=resourceRolesRepository.findResourceRoles(uid);

		ArrayList<String> roles = new ArrayList<String>();

		roles.add("ADMIN");
		roles.add("Travel");

        if (resourceRoles.size() > 0)
		{
			for (ResourceRoles role : resourceRoles)
			{
				if(roles.contains(role.getRoles().getRole())){
					retVal = true;
				}
			}
		}
		return retVal;
	}
	
	@Override
	public boolean isAMG() {
		Boolean retVal=false;
		Integer uid=(Integer)session.getAttribute("loggedInUid");
		List<ResourceRoles> resourceRoles=resourceRolesRepository.findResourceRoles(uid);

		ArrayList<String> roles = new ArrayList<String>();

		roles.add("ADMIN");
		roles.add("AMG");

        if (resourceRoles.size() > 0)
		{
			for (ResourceRoles role : resourceRoles)
			{
				if(roles.contains(role.getRoles().getRole())){
					retVal = true;
				}
			}
		}
		return retVal;
	}
//COE role
	@Override
	public boolean isCOE() {
		Boolean retVal=false;
		Integer uid=(Integer)session.getAttribute("loggedInUid");
		List<ResourceRoles> resourceRoles=resourceRolesRepository.findResourceRoles(uid);

		ArrayList<String> roles = new ArrayList<String>();

		roles.add("ADMIN");
		roles.add("COE");

        if (resourceRoles.size() > 0)
		{
			for (ResourceRoles role : resourceRoles)
			{
				if(roles.contains(role.getRoles().getRole())){
					retVal = true;
				}
			}
		}
		return retVal;
	}
	
	
	@Override
	public boolean isAR() {
		Boolean retVal=false;
		Integer uid=(Integer)session.getAttribute("loggedInUid");
		List<ResourceRoles> resourceRoles=resourceRolesRepository.findResourceRoles(uid);

		ArrayList<String> roles = new ArrayList<String>();

		roles.add("ADMIN");
		roles.add("AR");

        if (resourceRoles.size() > 0)
		{
			for (ResourceRoles role : resourceRoles)
			{
				if(roles.contains(role.getRoles().getRole())){
					retVal = true;
				}
			}
		}
		return retVal;
	}
	
	@Override
	public boolean isBP() {
		Boolean retVal=false;
		Integer uid=(Integer)session.getAttribute("loggedInUid");
		List<ResourceRoles> resourceRoles=resourceRolesRepository.findResourceRoles(uid);

		ArrayList<String> roles = new ArrayList<String>();

		roles.add("ADMIN");
		roles.add("BP");

        if (resourceRoles.size() > 0)
		{
			for (ResourceRoles role : resourceRoles)
			{
				if(roles.contains(role.getRoles().getRole())){
					retVal = true;
				}
			}
		}
		return retVal;
	}
	
	@Override
	public boolean isPH() {
		Boolean retVal=false;
		Integer uid=(Integer)session.getAttribute("loggedInUid");
		List<ResourceRoles> resourceRoles=resourceRolesRepository.findResourceRoles(uid);

		ArrayList<String> roles = new ArrayList<String>();

		roles.add("ADMIN");
		roles.add("PH");

        if (resourceRoles.size() > 0)
		{
			for (ResourceRoles role : resourceRoles)
			{
				if(roles.contains(role.getRoles().getRole())){
					retVal = true;
				}
			}
		}
		return retVal;
	}
	
	@Override
	public boolean isCEP() {
		Boolean retVal=false;
		Integer uid=(Integer)session.getAttribute("loggedInUid");
		List<ResourceRoles> resourceRoles=resourceRolesRepository.findResourceRoles(uid);

		ArrayList<String> roles = new ArrayList<String>();

		roles.add("ADMIN");
		roles.add("CEP");

        if (resourceRoles.size() > 0)
		{
			for (ResourceRoles role : resourceRoles)
			{
				if(roles.contains(role.getRoles().getRole())){
					retVal = true;
				}
			}
		}
		return retVal;
	}
	
	@Override
	public boolean isHR() {
		Boolean retVal=false;
		Integer uid=(Integer)session.getAttribute("loggedInUid");
		List<ResourceRoles> resourceRoles=resourceRolesRepository.findResourceRoles(uid);

		ArrayList<String> roles = new ArrayList<String>();

		roles.add("ADMIN");
		roles.add("HR");

        if (resourceRoles.size() > 0)
		{
			for (ResourceRoles role : resourceRoles)
			{
				if(roles.contains(role.getRoles().getRole())){
					retVal = true;
				}
			}
		}
		return retVal;
	}
	
	@Override
	public boolean isHRPms() {
		Boolean retVal=false;
		Integer uid=(Integer)session.getAttribute("loggedInUid");
		List<ResourceRoles> resourceRoles=resourceRolesRepository.findResourceRoles(uid);

		ArrayList<String> roles = new ArrayList<String>();

		roles.add("ADMIN");
		roles.add("HRPMS");

        if (resourceRoles.size() > 0)
		{
			for (ResourceRoles role : resourceRoles)
			{
				if(roles.contains(role.getRoles().getRole())){
					retVal = true;
				}
			}
		}
		return retVal;
	}
	
	@Override
	public boolean isHRPmsAdmin() {
		Boolean retVal=false;
		Integer uid=(Integer)session.getAttribute("loggedInUid");
		List<ResourceRoles> resourceRoles=resourceRolesRepository.findResourceRoles(uid);

		ArrayList<String> roles = new ArrayList<String>();

		roles.add("ADMIN");
		roles.add("HRPMSAdmin");

        if (resourceRoles.size() > 0)
		{
			for (ResourceRoles role : resourceRoles)
			{
				if(roles.contains(role.getRoles().getRole())){
					retVal = true;
				}
			}
		}
		return retVal;
	}
	
	@Override
	public boolean isDE() {
		Boolean retVal=false;
		Integer uid=(Integer)session.getAttribute("loggedInUid");
		List<ResourceRoles> resourceRoles=resourceRolesRepository.findResourceRoles(uid);

		ArrayList<String> roles = new ArrayList<String>();

		roles.add("ADMIN");
		roles.add("DE");

        if (resourceRoles.size() > 0)
		{
			for (ResourceRoles role : resourceRoles)
			{
				if(roles.contains(role.getRoles().getRole())){
					retVal = true;
				}
			}
		}
		return retVal;
	}
	
	@Override
	public boolean isLeadership() {
		Boolean retVal=false;
		Integer uid=(Integer)session.getAttribute("loggedInUid");
		List<ResourceRoles> resourceRoles=resourceRolesRepository.findResourceRoles(uid);

		ArrayList<String> roles = new ArrayList<String>();

		roles.add("ADMIN");
		roles.add("Leadership");

        if (resourceRoles.size() > 0)
		{
			for (ResourceRoles role : resourceRoles)
			{
				if(roles.contains(role.getRoles().getRole())){
					retVal = true;
				}
			}
		}
		return retVal;
	}
	
	@Override
	public boolean isTVF() {
		Boolean retVal=false;
		Integer uid=(Integer)session.getAttribute("loggedInUid");
		List<ResourceRoles> resourceRoles=resourceRolesRepository.findResourceRoles(uid);
		
		ArrayList<String> roles = new ArrayList<String>();
		
		roles.add("ADMIN");
		roles.add("TVF");
		
		if (resourceRoles.size() > 0)
		{
			for (ResourceRoles role : resourceRoles)
			{
				if(roles.contains(role.getRoles().getRole())){
					retVal = true;
				}
			}
		}
		return retVal;
	}

	@Override
	public boolean sendAllocationNotification(Allocation alc, String actionType, HttpServletRequest request)  throws MessagingException {

		Resource resourcePm = null;
		Resource createdBy = null;
        Resource updatedBy = null;
		Project project = null;
  	    SowDetail sowDetail = null;
		AmgRoles amgRole = null;
		CmsDetail cmsDetail = null;
		
		Cms cms = null;

	    Integer sowDetailId =0;
	    Integer cmsDetailId = 0;
		Integer cmsId= 0;
	    String pmEmail = "";
	    String projectName = "";

		String subject = "InfoBiz | New Allocation";
		String template = "mail/allocationAdd";

		if(actionType == "update")
		{
			subject = "InfoBiz | Update Allocation";
			template = "mail/allocationUpdate";
		}

		// create a new context
        Context context = new Context();
		if(alc !=null) {
			if(alc.getProjectId()!=null){
				project = projectController.getProject(alc.getProjectId());
				if(project != null)
				{
					resourcePm = resourceController.findResource(project.getProjectManagersId());
					if(resourcePm != null)
					{
	                    pmEmail = resourcePm.getEmail();
					}
					projectName = project.getTitle();
					context.setVariable("projectName", projectName);
					subject = subject.concat(" | "+projectName);
	            }
			}

			createdBy = resourceController.findResource(alc.getCreatedBy());
			if(createdBy != null)
			{
                context.setVariable("createdBy", createdBy.getTitle());
			}

			updatedBy = resourceController.findResource(alc.getModifiedBy());
			if(updatedBy != null){
                context.setVariable("updatedBy", updatedBy.getTitle());
			}

			if(alc.getSowDetail() != null) {
				sowDetailId = alc.getSowDetail().getSowDetailId();

				if(sowDetailId != 0){
			       sowDetail = sowDetailRepository.findOne(sowDetailId);
			       if(sowDetail.getSowDetailId()!=null){
                       context.setVariable("detailId", sowDetail.getSowDetailId());
                       if(sowDetail.getSow()!=null){
                           context.setVariable("number", sowDetail.getSow().getSowNo());		       
                       }
			       }
                }
			}else{
				if (alc.getCmsDetail() != null) {
					cmsDetailId = alc.getCmsDetail().getCmsDetailId();
					if (cmsDetailId != 0) 
					{
						cmsDetail = cmsDetailRepository.findOne(cmsDetailId);
						if(cmsDetail!=null)
						{
							context.setVariable("detailId", cmsDetail.getCmsDetailId());							
							if(cmsDetail.getCms()!=null)
							{
								context.setVariable("number", cmsDetail.getCms().getCmsId());
								cms = cmsRepository.findOne(cmsDetail.getCms().getCmsId());
								if(cms!=null){
									projectName = cms.getDummyProjectName();
									context.setVariable("projectName", cms.getDummyProjectName());
									subject = subject.concat(" | " + projectName);
								}
							}
						}
					}
				}
			}
			context.setVariable("resourceName",alc.getResourceName());
		}

		smtpMailSender.send("",pmEmail, subject, template, context,LoadConstant.AMG, request);
		return true;
	}

	@Override
	public boolean sendCmsNotification(Cms cms, String actionType, HttpServletRequest request)  throws MessagingException {

		Resource resourceDm = null;
        Resource resourceRm = null;
		Resource createdBy = null;
        Resource updatedBy = null;
        Account account = null;
		String createdByEmail = "";
		String dmEmail = "";
		String rmEmail = "";
		Integer cmsId;
		String ccEmails = null;

		String subject = "InfoBiz | New CM-S";
		String template = "mail/cmsAdd";

		if(actionType == "update")
		{
			subject = "InfoBiz | Update CM-S";
			template = "mail/cmsUpdate";
		}

		// create a new context
        Context context = new Context();
		if(cms !=null) {
			account = accountRepository.findOne(cms.getAccountId());

			if(account != null){

                String accountName = account.getTitle();
				context.setVariable("accountName", accountName);

				subject = subject.concat(" | "+accountName);

                resourceDm = resourceController.findResource(account.getDmId());
				resourceRm = resourceController.findResource(account.getRmId());

                if(resourceDm != null)
				{
                    dmEmail = resourceDm.getEmail();
				}
				if(resourceRm != null)
				{
                    rmEmail = resourceRm.getEmail();
				}
			}

			if(cms.getCreatedBy()!=null){
	            createdBy = resourceController.findResource(cms.getCreatedBy());
	            if(createdBy != null)
				{
	                context.setVariable("createdBy", createdBy.getTitle());
	                createdByEmail = createdBy.getEmail();
				}
			}
            
            if(cms.getModifiedBy()!=null){
				updatedBy = resourceController.findResource(cms.getModifiedBy());
	            if(updatedBy != null)
				{
	                context.setVariable("updatedBy", updatedBy.getTitle());
				}
            }
            
            if(cms.getCmsId() != null) {
                context.setVariable("cmsId", cms.getCmsId());
			}

            if(cms.getDummyProjectName()!=null){
                context.setVariable("projectName", cms.getDummyProjectName());

			}


        }																							
		
		if(rmEmail !=null) {						
			ccEmails = rmEmail;
		}					
		
		if(createdByEmail !=null) {						
			ccEmails = ccEmails.concat(","+createdByEmail);						
		}
		ccEmails = ccEmails.concat(","+LoadConstant.AMG+','+LoadConstant.PMO);

		smtpMailSender.send("",dmEmail, subject, template, context,ccEmails, request);
		return true;

    }


	@Override
	public boolean sendSowNotification(Sow sow, String actionType, HttpServletRequest request)  throws MessagingException {

        Resource resourcePm = null;
        Resource resourceDm = null;
		Resource createdBy = null;
		Resource updatedBy = null;
		Project project = null;
		Account account = null;
		String pmEmail = "";
        String dmEmail = "";
		String subject = "InfoBiz | New Sow";
		String template = "mail/sowAdd";
		String ccEmails = null;

        if(actionType == "update")
		{
			subject = "InfoBiz | Update Sow";
			template = "mail/sowUpdate";
		}

        // create a new context
        Context context = new Context();
		if(sow !=null) {
			project = projectController.getProject(sow.getProjectId());
			if(project != null)
			{
				resourcePm = resourceController.findResource(project.getProjectManagersId());
				if(resourcePm != null)
				{
                    pmEmail = resourcePm.getEmail();
				}

                account = accountRepository.findOne(project.getAccountId());
				if(account != null)
				{
					resourceDm = resourceController.findResource(account.getDmId());
					if(resourceDm != null)
					{
                        dmEmail = resourceDm.getEmail();
					}
				}

                String projectName = project.getTitle();
				context.setVariable("projectName", projectName);
				subject = subject.concat(" | "+projectName);
            }

			createdBy = resourceController.findResource(sow.getCreatedBy());
			if(createdBy != null)
			{
                context.setVariable("createdBy", createdBy.getTitle());
			}

            updatedBy = resourceController.findResource(sow.getModifiedBy());
			if(updatedBy != null)
			{
                context.setVariable("updatedBy", updatedBy.getTitle());
			}

            context.setVariable("sowId", sow.getSowNo());
		}				
		
		if(dmEmail !=null) {						
			ccEmails = dmEmail+","+LoadConstant.AMG+','+LoadConstant.PMO;			
		}else{
			ccEmails = LoadConstant.AMG+','+LoadConstant.PMO;
		}
		smtpMailSender.send("",pmEmail, subject, template, context,ccEmails, request);
		return true;
	}

	
	@Override
	public boolean sendBuspassNotification(BusPass busPass, String actionType, HttpServletRequest request) throws MessagingException {
		logger.info("inside sendBuspassNotification");
		String subject = "";
		String template = "";
		String travelEmail = LoadConstant.INFO_CABS;//
		String ccEmails = LoadConstant.INFO_CABS;
		String toEmail = "";
		String fromEmail = LoadConstant.INFO_CABS;
		Context context = new Context();      
        
		if(busPass !=null) {
			
			Resource resource = resourceController.findResource(busPass.getUid());
			toEmail = resource.getEmail();
			String empName = resource.getTitle();
			Integer empId = resource.getEmpId();
			logger.info(toEmail+" toEmail is here");
			logger.info(actionType+" actionType is here");
			Integer busPassId = busPass.getBusPassId();
			String busStatus = busPass.getStatus();
			logger.info(busStatus+" busStatus is here");
			
			WorkLocation locationNameObj = busPass.getWorklocation();
			String locationName = locationNameObj.getLocationName();
			BusNodalPoint nodalPointNameObj = busPass.getBusnodalpoint();
			String nodalPointName = nodalPointNameObj.getNodalPointName();
			String comments = busPass.getComments();			
		
			if(actionType == "add")
				{				
					//if user adds request for bus pass
					logger.info(" inside add ");
					Resource createdBy = resourceController.findResource(busPass.getCreatedBy());
					String title = createdBy.getTitle();				
					
				 	subject = "InfoCabs | New Bus Pass Applied | "+ createdBy.getTitle() +" | Request Id: "+ busPassId;						
					template = "mail/travelAddUpdate";					
					ccEmails = travelEmail;					
					
					
					context.setVariable("title", title);
					context.setVariable("addBusPass","addBusPass");
					
					
	
				}
			
				if(actionType == "update" && busPass.getReqClosure() == null){
					logger.info("update is here for travl");
					//if travel team edits/updates  travel section
			 		String statusVal = busPass.getStatus();
			 		BusRoute busRouteObj = busPass.getBusroute();
			 		String routeName = busRouteObj.getBusRouteName();
			 		
			 		Resource updatedBy = resourceController.findResource(busPass.getModifiedBy());
					String title = updatedBy.getTitle();
					Integer cardNo = busPass.getCardNo();
					String cardType = busPass.getCardType();
					String cmntsByIssuer = busPass.getCommentsByIssuer();				
					Integer nodalPointBusFare = busPass.getConfirmedNodalPt();
					BusNodalPoint nodal = BusNodalPointRepository.findByBusNodalPoint(nodalPointBusFare);
					String busFare = nodal.getBusFare();
					String pickUpTime = busPass.getPickUpTime();
									
					Integer confirmedNodal =  busPass.getConfirmedNodalPt();
					logger.info("confirmedNodal is:"+confirmedNodal);
					
					BusNodalPoint busNodalPoint=busNodalPointRepository.findOne(confirmedNodal);
					logger.info("busNodalPoint"+busNodalPoint.getNodalPointName());
					String confirmedNodalPt = busNodalPoint.getNodalPointName();
					
					logger.info("update is here");					
					
					logger.info("title="+title);
					logger.info("statusVal="+statusVal);
					logger.info("routeName="+routeName);
					logger.info("cardNo="+cardNo);
					logger.info("cardType="+cardType);
					logger.info("cmntsByIssuer="+cmntsByIssuer);
					logger.info("confirmedNodal="+confirmedNodal);
					logger.info("busFare="+busFare);
					logger.info("confirmedNodalPt="+confirmedNodalPt);
					logger.info("pickUpTime="+pickUpTime);
					
					
					subject = "InfoCabs | Bus Pass Updated | "+ empName +" | Request Id: "+ busPassId;						
					template = "mail/travelAddUpdate";					
					ccEmails = travelEmail;
					
					
					context.setVariable("title", title);
					context.setVariable("statusVal",statusVal);
					context.setVariable("routeName",routeName);
					context.setVariable("cardNo",cardNo);
					context.setVariable("cardType",cardType);
					context.setVariable("cmntsByIssuer",cmntsByIssuer);
					context.setVariable("updateBusPass","updateBusPass");
					context.setVariable("confirmedNodal",confirmedNodal);
					context.setVariable("busFare",busFare);
					context.setVariable("confirmedNodalPt",confirmedNodalPt);
					context.setVariable("pickUpTime",pickUpTime);
					
					
				}
				
				else if(actionType == "update" && busPass.getReqClosure() && busPass.getStatus().equals("Active"))
				{ 
			 		//if user requests for closure of bus pass
					logger.info(" closureValue is not here");
			 		Resource updatedBy = resourceController.findResource(busPass.getModifiedBy());
					String title = updatedBy.getTitle();
					String closureReason = busPass.getClosureReason();
					context.setVariable("title", title);
					context.setVariable("closureReason", closureReason);
					context.setVariable("closeBusPass","closeBusPass");
					
					subject = "InfoCabs | Bus Pass Closure Request | "+ empName +" | Request Id: "+ busPassId;							
					template = "mail/travelAddUpdate";					
					ccEmails = travelEmail;

				}
				
				else if(actionType == "update" && busPass.getReqClosure() && busPass.getStatus().equals("Closed"))
				{ 
			 		//if user requests for closure of bus pass
					logger.info(" closureValue is not here");
			 		Resource updatedBy = resourceController.findResource(busPass.getModifiedBy());
					String title = updatedBy.getTitle();
					context.setVariable("title", title);
					String byIssuer = busPass.getCommentsByIssuer();
					
					context.setVariable("byIssuer", byIssuer);
					logger.info("byIssuer="+byIssuer);
					context.setVariable("closedBusPass","closedBusPass");
					
					subject = "InfoCabs | Bus Pass Closure Request | "+ empName +" | Request Id: "+ busPassId;							
					template = "mail/travelAddUpdate";					
					ccEmails = travelEmail;

				}
			
			
				context.setVariable("busPassId", busPassId);
				context.setVariable("empName", empName);
				context.setVariable("empId", empId);
				context.setVariable("locationName", locationName);
				context.setVariable("nodalPointName", nodalPointName);
				context.setVariable("comments", comments); 
		}
		
		
		logger.info("toEmail="+toEmail);
		logger.info("subject="+subject);
		logger.info("template="+template);
		logger.info("context="+context);
		logger.info("ccEmails="+ccEmails);
		logger.info("request="+request);
		
		smtpMailSender.send(fromEmail,toEmail, subject,template, context,ccEmails, request);
		
		
		return true;
		//return false;
	}
	
	
	@Override
	public boolean sendInfoCabNotification(InfoCab infoCab, String actionType, HttpServletRequest request) throws MessagingException {
		logger.info("inside sendInfoCabNotification");
		String subject = "";
		String template = "";
		String travelEmail = LoadConstant.INFO_CABS;
		String ccEmails = LoadConstant.INFO_CABS;
		String toEmail = "";
		String fromEmail = LoadConstant.INFO_CABS;
		Context context = new Context();
		String empName = "";
		String empEmail = "";
		String approverEmail = "";
		String approverName = "";
		Integer empId = null;
		Integer loggedInUid=(Integer)session.getAttribute("loggedInUid");
        
		if(infoCab !=null) {
			if(infoCab.getUid() !=null){
				Resource resource = resourceController.findResource(infoCab.getUid());
				
				empName = resource.getTitle();
				empId = resource.getEmpId();
				empEmail = resource.getEmail();
				context.setVariable("empId", empId);
				context.setVariable("empName", empName);
			}
			
			

			Project projectNm = projectController.getProject(infoCab.getProjectId());
			if(projectNm != null)
			{
				Resource resourcePm = resourceController.findResource(projectNm.getProjectManagersId());
				
				if(infoCab.getApproverId() !=null) {
					Resource resource = resourceController.findResource(infoCab.getApproverId());
					approverEmail = resource.getEmail();
					approverName = resource.getTitle();
					
					context.setVariable("approverEmail", approverEmail);
					context.setVariable("approverName", approverName);
				}
				if(resourcePm != null)
				{
                    String pmEmail = resourcePm.getEmail();
                    String pmName = resourcePm.getTitle();

                    context.setVariable("pmEmail", pmEmail);
                    context.setVariable("pmName", pmName);


                    logger.info("pmEmail="+pmEmail);
				}
				String projectName = projectNm.getTitle();
				logger.info("projectName="+projectName);
				
			}

			

			
			Project projct = projectController.getProject(infoCab.getProjectId());
			String project = projct.getTitle();					
			Integer infoCabId = infoCab.getInfoCabId();
			String pickUpPt = infoCab.getPickupPoint();
			String dropPt = infoCab.getDropPoint();
			Date pickUpDt = infoCab.getDateCab();
			String pickUpTime = infoCab.getTimeCab();
			String remarks = infoCab.getRemarks();
			String billingType = "";
			String userMobile = "";

			if(infoCab.getBillingType() != null){
				billingType = infoCab.getBillingType();
				context.setVariable("billingType", billingType);
			}
			
			if(infoCab.getUserMobile()!=null) {
				userMobile = infoCab.getUserMobile();
				context.setVariable("userMobile", userMobile);
			}


			if(actionType == "add" && infoCab.getSubmissionStatus()==1)
			{
					//if user adds request for bus pass		
					Resource createdBy = resourceController.findResource(infoCab.getCreatedBy());					
					String title = createdBy.getTitle();
					
				 	subject = "InfoCabs | New InfoCab Request Applied | "+ empName +" | CRN"+ infoCabId;
				 	
				 	toEmail = LoadConstant.INFO_CABS;
					ccEmails = empEmail+','+approverEmail;
															
					context.setVariable("title", title);
					if(!infoCab.getCreatedBy().equals(infoCab.getUid())) {
						context.setVariable("addInfoCabByAdmin", "addInfoCabByAdmin");
					}
					else{						
						context.setVariable("addInfoCab", "addInfoCab");
					}
			}
			else if(actionType == "update" && infoCab.getSubmissionStatus()==2 && ("Non-Chargeable").equals(infoCab.getBillingType()))
			{

				//if travel team edits/updates  travel section
				Resource updatedBy = resourceController.findResource(infoCab.getModifiedBy());
				String title = updatedBy.getTitle();

				subject = "InfoCabs | InfoCab Request Booked | "+ billingType +" | "+ empName +" | CRN"+ infoCabId;
				
				toEmail = empEmail;
				ccEmails = LoadConstant.INFO_CABS+','+approverEmail;
				
				context.setVariable("statusAdminInfoCab", "statusAdminInfoCab");
				context.setVariable("title", title);

				String bookingStatus = infoCab.getBookingStatus();
				if(infoCab.getInfoCabVehicleId()!=null) {
					InfoCabVehicle infoCabVehicle = infoCabVehicleController.getInfoCabVehicle(infoCab.getInfoCabVehicleId());
					String vehicleNo = infoCabVehicle.getVehicleNumber();
					context.setVariable("vehicleNo", vehicleNo);
				}
				
				if(infoCab.getInfoCabDriverId() !=null) {
					InfoCabDriver infoCabDriver = infoCabDriverController.getInfoCabDriver(infoCab.getInfoCabDriverId());
					String driverNo = infoCabDriver.getDriverMobile();
					String driverName = infoCabDriver.getDriverName();
					context.setVariable("driverNo", driverNo);
					context.setVariable("driverName", driverName);
 				}
				
				//String driverName = infoCab.getDriverName();
				String comments = infoCab.getBookingComments();


				context.setVariable("statusAdminInfoCab", "statusAdminInfoCab");
				context.setVariable("bookingStatus", bookingStatus);
				//context.setVariable("driverName", driverName);
				context.setVariable("comments", comments);


			}
			else if(actionType == "update" && infoCab.getPmApprovalStatus().equals("Pending") && infoCab.getSubmissionStatus()==3 && ("Chargeable").equals(infoCab.getBillingType()))
			{
		  			
					//if travel team edits/updates  travel section			 		
			 		Resource updatedBy = resourceController.findResource(infoCab.getModifiedBy());
			 		String title = updatedBy.getTitle();
			 		
			 		if(("Chargeable").equals(infoCab.getBillingType())) {
			 			if(infoCab.getChargeableComments()!=null) {
			 				String chargeableComments = infoCab.getChargeableComments();
			 				context.setVariable("chargeableComments", chargeableComments);
			 			}
			 		}
					
					subject = "InfoCabs | InfoCab Approval Requested | "+ empName +" | CRN"+ infoCabId;
					
					toEmail = approverEmail;
					ccEmails = LoadConstant.INFO_CABS+','+empEmail;
										
					context.setVariable("updateInfoCab", "updateInfoCab");
					context.setVariable("title", title);
					
				
			}
			else if(actionType == "update" && infoCab.getPmApprovalStatus().equals("Approved") && infoCab.getBookingStatus().equals("Pending") && infoCab.getCancelRequest()==null && infoCab.getSubmissionStatus()==4)
			{
					Resource updatedBy = resourceController.findResource(infoCab.getModifiedBy());					
					String title = updatedBy.getTitle();					
					String PMStatus = infoCab.getPmApprovalStatus();
					String PMComments = infoCab.getPmApprovalComment();
										
					subject = "InfoCabs | InfoCab Request Approved by PM | "+ empName +" | CRN"+ infoCabId;	
					
					toEmail = LoadConstant.INFO_CABS;
					ccEmails = empEmail+','+approverEmail;
					
					context.setVariable("statusInfoCab", "statusInfoCab");					
					context.setVariable("title", title);
					context.setVariable("PMComments", PMComments);
					context.setVariable("PMStatus", PMStatus);
					
			}
			else if(actionType == "update" && infoCab.getPmApprovalStatus().equals("Rejected") && infoCab.getCancelRequest()==null && infoCab.getSubmissionStatus()==4)
			{
					Resource updatedBy = resourceController.findResource(infoCab.getModifiedBy());					
					String title = updatedBy.getTitle();					
					String PMStatus = infoCab.getPmApprovalStatus();
					String PMComments = infoCab.getPmApprovalComment();						
					
					subject = "InfoCabs | InfoCab Request Rejected by PM | "+ empName +" | CRN"+ infoCabId;
					
					toEmail = empEmail;
					ccEmails = LoadConstant.INFO_CABS+','+approverEmail;
										
					context.setVariable("title", title);					
					context.setVariable("statusInfoCab", "statusInfoCab");
					context.setVariable("PMStatus", PMStatus);					
					context.setVariable("PMComments", PMComments);
			}
			else if(actionType == "update" && infoCab.getPmApprovalStatus().equals("Approved") && infoCab.getBookingStatus().equals("Booked") && infoCab.getCancelRequest()==null && infoCab.getSubmissionStatus()==5)
			{
					
					Resource updatedBy = resourceController.findResource(infoCab.getModifiedBy());					
					String title = updatedBy.getTitle();					
					String PMStatus = infoCab.getPmApprovalStatus();					
					String bookingStatus = infoCab.getBookingStatus();
					if(infoCab.getInfoCabVehicleId()!=null) {
						InfoCabVehicle infoCabVehicle = infoCabVehicleController.getInfoCabVehicle(infoCab.getInfoCabVehicleId());
						String vehicleNo = infoCabVehicle.getVehicleNumber();
						context.setVariable("vehicleNo", vehicleNo);
					}
					
					if(infoCab.getInfoCabDriverId() !=null) {
						InfoCabDriver infoCabDriver = infoCabDriverController.getInfoCabDriver(infoCab.getInfoCabDriverId());
						String driverNo = infoCabDriver.getDriverMobile();
						String driverName = infoCabDriver.getDriverName();
						context.setVariable("driverNo", driverNo);
						context.setVariable("driverName", driverName);
	 				}
					String comments = infoCab.getBookingComments();
					
					subject = "InfoCabs | InfoCab Request Booked | "+ empName +" | CRN"+ infoCabId;
					
					toEmail = empEmail;
					ccEmails = LoadConstant.INFO_CABS+','+approverEmail;
					
					context.setVariable("title", title);					
					context.setVariable("statusAdminInfoCab", "statusAdminInfoCab");
					context.setVariable("PMStatus", PMStatus);
					context.setVariable("bookingStatus", bookingStatus);
					context.setVariable("comments", comments);
					
			}
			else if(actionType == "update" && infoCab.getBookingStatus().equals("Rejected") && infoCab.getCancelRequest()==null)
			{
					
					Resource updatedBy = resourceController.findResource(infoCab.getModifiedBy());					
					String title = updatedBy.getTitle();					
					String PMStatus = infoCab.getPmApprovalStatus();					
					String bookingStatus = infoCab.getBookingStatus();
					
					subject = "InfoCabs | InfoCab Request Rejected | "+ empName +" | CRN"+ infoCabId;
					
					toEmail = empEmail;
					ccEmails = LoadConstant.INFO_CABS+','+approverEmail;
					
					context.setVariable("title", title);					
					context.setVariable("statusRejectAdminInfoCab", "statusRejectAdminInfoCab");
					context.setVariable("PMStatus", PMStatus);
					context.setVariable("bookingStatus", bookingStatus);
					
			}
				
			else if(actionType == "update" && infoCab.getCancelRequest()!=null && infoCab.getSubmissionStatus()==6) {
						
						Resource updatedBy = resourceController.findResource(infoCab.getModifiedBy());					
						String title = updatedBy.getTitle();					
						String PMStatus = infoCab.getPmApprovalStatus();					
						String bookingStatus = infoCab.getBookingStatus();
						
						toEmail = LoadConstant.INFO_CABS;
						ccEmails = empEmail+','+approverEmail;
						
						subject = "InfoCabs | InfoCab Request Cancelled | "+ empName +" | CRN"+ infoCabId;		
						
						context.setVariable("title", title);					
						context.setVariable("cancelCabRequest", "cancelCabRequest");
			}
			else if(actionType == "update" && infoCab.getCancelRequest()==null && infoCab.getSubmissionStatus()==7) {
				
				Resource updatedBy = resourceController.findResource(infoCab.getModifiedBy());					
				String title = updatedBy.getTitle();			
				
				subject = "InfoCabs | InfoCab Request Updated | "+ empName +" | CRN"+ infoCabId;	
				
				toEmail = LoadConstant.INFO_CABS;
				ccEmails = LoadConstant.INFO_CABS;
				
				context.setVariable("title", title);					
				context.setVariable("updateBookedRequest", "updateBookedRequest");
				}
				
				
				context.setVariable("infoCabId", infoCabId);

				context.setVariable("project", project);
				context.setVariable("pickUpPt", pickUpPt);
				context.setVariable("dropPt", dropPt);
				context.setVariable("pickUpDt", DateConverter.changeDate2(pickUpDt));
				context.setVariable("pickUpTime", pickUpTime);
				context.setVariable("remarks", remarks);

				
				
				template = "mail/cabAddUpdate";			
				logger.info("ccEmails="+ccEmails);
           
		}	

		smtpMailSender.send(fromEmail,toEmail, subject, template, context,ccEmails, request);		
		
		return true;
	}
	
	
	@Override
	public boolean sendInfoTravelNotification(InfoTravel infoTravel, String actionType, HttpServletRequest request) throws MessagingException {
		logger.info("inside sendInfoTravelNotification");
		String subject = "";
		String template = "";
		String ccEmails = LoadConstant.TRAVEL_DESK;
		String fromEmail = LoadConstant.TRAVEL_DESK;
		String toEmail = "";
		Integer infoTravelId;
		Context context = new Context();      
		StringBuilder travellerDetail = new StringBuilder();
		String travellerDetailToString = "";
		StringBuilder travelDetail = new StringBuilder();
		String travelDetailToString = "";
		Resource approverId =null;
		String approverName = "";
		Grade approverGrade = null;
		String gradeName = "";
		String approverEmail = "";
		String originNew = "";
		String destinationNew = "";
		String departureDate = "";
		String returnDate = "";
		String managerName = "";
		String travelWay = "";
		Map<String,String> map = new HashMap<String,String>();
		
		
		if(infoTravel !=null) {
			
			Resource resource = resourceController.findResource(infoTravel.getUid());
			String resourceEmail = resource.getEmail();
			context.setVariable("resourceEmail", resourceEmail);
			String empName = resource.getTitle();
			context.setVariable("empName", empName);
			Integer empId = resource.getEmpId();
			context.setVariable("empId", empId);	
			
			if(infoTravel.getIsGuest()!=null && infoTravel.getIsGuest()==true) {
				Boolean isGuest = infoTravel.getIsGuest();
				context.setVariable("isGuest", isGuest);
			}
			
			infoTravelId = infoTravel.getInfoTravelId();
			String tourCode = infoTravel.getTourCode();
			
			if(infoTravel.getApproverId() !=null) {
				approverId = resourceController.findResource(infoTravel.getApproverId());			
				approverName = approverId.getTitle();	
				approverGrade = approverId.getGrade();
				gradeName = approverGrade.getGrade();
				approverEmail = approverId.getEmail();
				
				
				context.setVariable("approverName", approverName);				
				context.setVariable("approverEmail", approverEmail);
				context.setVariable("gradeName", gradeName);
			}
			
			
			Unit unit = unitController.getUnit(infoTravel.getUnit());
			String unitName = unit.getName();
			String travelType = infoTravel.getTravelType();
			if(infoTravel.getTravelWay() !=null) {
				travelWay = infoTravel.getTravelWay();
				context.setVariable("travelWay", travelWay);
			}
			String travelMode = infoTravel.getTravelMode();
			String typeOfTravel = infoTravel.getTypeOfTravel();
			
			Project projct = projectController.getProject(infoTravel.getProjectId());
			String projectName = projct.getTitle();
			String projectManager = projct.getPmName();
			
			Resource managerObj = resourceController.findResource(projct.getProjectManagersId());	
			String managerEmail = managerObj.getEmail();
		
			if(infoTravel.getApproverId() !=null) {
			Resource manager = resourceController.findResource(infoTravel.getApproverId());
			managerName = manager.getTitle();
			}
			Unit unit1 = unitController.getUnit(infoTravel.getAssociateUnit());
			String associateUnit = unit1.getName();
			if(infoTravel.getInvoiceUnit()!=null) {
				Unit unit2 = unitController.getUnit(infoTravel.getInvoiceUnit());
				if(("STPI - ITPL").equals(unit2.getName()))
				{
					String invoiceUnit = unit2.getName() + "/Unit-I";
					context.setVariable("invoiceUnit", invoiceUnit);					
				}
				if(("MIHAN - ITPL").equals(unit2.getName()))
				{
					String invoiceUnit = unit2.getName() + "/Unit-III";
					context.setVariable("invoiceUnit", invoiceUnit);
				}
				 
				
			}
			String travelPourpose = infoTravel.getTravelPurpose();
			String billableCost = infoTravel.getTravelCost();
			String approverRemark = infoTravel.getApprovalRemarks();
			String travelRemark = infoTravel.getTravelDeskClosureRemarks();
			String travellerRemark = infoTravel.getTravellerRemarks();
			
			String accomodation = infoTravel.getAccomodation();
			String nomineeName = infoTravel.getNomineeName();
			String nomineeRelation = infoTravel.getNomineeRelation();
			
			String createdDate = DateConverter.convertDateToString(infoTravel.getCreatedDate());
			
			
			
			
			Integer passengerCount = infoTravel.getAdultCount() + infoTravel.getChildCount() + infoTravel.getInfantCount();
			context.setVariable("passengerCount", passengerCount);
			
			if(infoTravelId !=null) {
			List<InfoTraveller> infoTraveller = infoTravellerRepository.findById(infoTravelId);
			
			//START- to get the passengers details//
			travellerDetail.append("<table style='width:100%'>");
			 for(InfoTraveller item : infoTraveller){
				 logger.info("item.getAlternateEmail()="+item.getAlternateEmail());
				 logger.info("item.getAirline()="+item.getAirline());
				 logger.info("item.getFrequentFlyerNo()="+item.getFrequentFlyerNo());
				 if(item.getAlternateEmail() ==null || "".equals(item.getAlternateEmail())) {
					 logger.info("if item.getAlternateEmail()="+item.getAlternateEmail());
					 item.setAlternateEmail("-");
				 }
				 else {
					 item.setAlternateEmail(item.getAlternateEmail());
				 }
				 if(item.getAirline() ==null || "".equals(item.getAirline())) {					 
					 logger.info("if item.getAirline()="+item.getAirline());
					 item.setAirline("-");
				 }
				 else {
					 item.setAirline(item.getAirline());
				 }
				 if(item.getFrequentFlyerNo() ==null || "".equals(item.getFrequentFlyerNo())) {					 
					 logger.info("if item.getFrequentFlyerNo()="+item.getFrequentFlyerNo());
					 item.setFrequentFlyerNo("-");
				 }	
				 else {
					 item.setFrequentFlyerNo(item.getFrequentFlyerNo());
				 }
				 
				 
				travellerDetail.append("<tr style='background-color:#333;color:#fff;style='width:100%''><td colspan='4'>Passenger</td></tr>");
				travellerDetail.append("<tr><td>Passenger First Name </td><td>"+item.getGivenName()+"</td><td>Passenger Last Name </td><td>"+item.getSurname()+ "</td></tr>");
				if(item.getDob()!=null) {
					
					travellerDetail.append("<tr><td>Date Of Birth</td><td >"+DateConverter.changeDate2(item.getDob())+"</td><td>Gender</td><td>"+item.getGender()+"</td></tr>");
				}
				travellerDetail.append("<tr><td>Employee Id</td><td>"+item.getEmpId()+"</td><td>Mobile No. at Origin</td><td>"+item.getMobileOrigin()+ "</td></tr>");
				travellerDetail.append("<tr><td>Passenger Grade</td><td>"+resource.getGrade().getGrade()+"</td><td>Mobile No. at Destination</td><td>"+item.getMobileDestination()+ "</td></tr>");
				travellerDetail.append("<tr><td>Email</td><td>"+item.getEmail()+"</td><td>Alternate Email</td><td >"+item.getAlternateEmail()+ "</td></tr>");
				if(("International").equals(travelType)) {
				travellerDetail.append("<tr><td>Passport No</td><td>"+item.getPassportNo()+"</td><td>Nationality</td><td>"+item.getNationality()+ "</td></tr>");
				}
				travellerDetail.append("<tr><td>Seat</td><td>"+item.getSeat()+"</td><td>Meal</td><td >"+item.getMeal()+ "</td></tr>");
				if(("International").equals(travelType)) {
				travellerDetail.append("<tr><td>Frequent Flyer Airline</td><td>"+item.getAirline()+"</td><td>Frequent Flyer No</td><td>"+item.getFrequentFlyerNo()+ "</td></tr>");
				travellerDetail.append("<tr><td>Nominee Name</td><td>"+nomineeName+"</td><td>Nominee Relation</td><td>"+nomineeRelation+"</td></tr>");
				}
				}
				
			 
			 
			travellerDetail.append("</table>");
			
			travellerDetailToString = travellerDetail.toString();
			logger.info("travellerDetailToString="+travellerDetailToString);
			logger.info("new infoTravel.getApproverId()="+infoTravel.getApproverId());
			 map.put("travellerDetailToString", travellerDetailToString);
			 
			 context.setVariable("travellerDetailToString", travellerDetailToString);
			}
			//END- to get the passengers details//
			 
			 
			//START - to get the passengers travel details//
			if(infoTravelId !=null) {
				List<InfoTravelDetail> infoTravelDetail = infoTravelDetailRepository.findById(infoTravelId);
				travelDetail.append("<table style='width:100%'>");
				if(("Hotel").equals(infoTravel.getTravelMode())) {
					if("Yes".equals(accomodation)) {
						String checkInDate = DateConverter.changeDate2(infoTravel.getCheckin());
						String checkOutDate = DateConverter.changeDate2(infoTravel.getCheckout());
						String businessAdress = infoTravel.getAddress();
						context.setVariable("checkInDate", checkInDate);
						context.setVariable("checkOutDate", checkOutDate);
						context.setVariable("businessAdress", businessAdress);
						travelDetail.append("<tr><td>Accomodation</td><td colspan='3'>"+accomodation+"</td></tr>");
						travelDetail.append("<tr><td>Check In Date</td><td>"+checkInDate+"</td><td>Check Out Date</td><td>"+checkOutDate+"</td></tr>"); 
						travelDetail.append("<tr><td>Business Address</td><td colspan='3'>"+businessAdress+"</td></tr>"); 
					}
				 else {
						travelDetail.append("<tr><td>Accomodation</td><td>"+accomodation+"</td></tr>");
				 }
				}
				else {
			 for(InfoTravelDetail item : infoTravelDetail){
				if(item.getOrigin()!=null && item.getDestination()!=null && item.getDepartureDate()!=null && ("One Way").equals(infoTravel.getTravelWay()) ) {
					
					//travelDetails = infoTravelDetailRepository.findOriginById(infoTravelId);
					if(!infoTravelDetail.isEmpty()) {
						 originNew = item.getOrigin();
						 destinationNew = item.getDestination();
						 departureDate = DateConverter.changeDate2(item.getDepartureDate());
						logger.info("originNew="+originNew);
						context.setVariable("originNew", originNew);
						context.setVariable("destinationNew", destinationNew);
						context.setVariable("departureDate", departureDate);
					}
				}
				if(item.getOrigin()!=null && item.getDestination()!=null && item.getDepartureDate()!=null && infoTravel.getReturnDate()!=null && ("Round Trip").equals(infoTravel.getTravelWay()) ) {
					
					//travelDetails = infoTravelDetailRepository.findOriginById(infoTravelId);
					if(!infoTravelDetail.isEmpty()) {
						 originNew = item.getOrigin();
						 destinationNew = item.getDestination();
						 departureDate = DateConverter.changeDate2(item.getDepartureDate());
						 if(infoTravel.getReturnDate() !=null)
						 {							 
							 returnDate = DateConverter.changeDate2(infoTravel.getReturnDate());
							 context.setVariable("returnDate", returnDate);
						 }
						logger.info("originNew="+originNew);
						context.setVariable("originNew", originNew);
						context.setVariable("destinationNew", destinationNew);
						context.setVariable("departureDate", departureDate);
					}
				}
			 }
				 for(InfoTravelDetail item : infoTravelDetail){
					 travelDetail.append("<tr><td>Origin </td><td>"+item.getOrigin()+ "</td><td>Destination</td><td>"+item.getDestination()+"</td></tr>");
					 if(infoTravel.getReturnDate() != null) {
						 travelDetail.append("<tr><td>Departure Date</td><td>"+DateConverter.changeDate2(item.getDepartureDate())+"</td><td>Return Date</td><td>"+DateConverter.changeDate2(infoTravel.getReturnDate())+"</td></tr>");
					 }
					 else {
						 travelDetail.append("<tr><td>Departure Date</td><td>"+DateConverter.changeDate2(item.getDepartureDate())+"</td></tr>"); 
					 }
					 
				 }
				 
				 
					 if("Yes".equals(accomodation)) {
							String checkInDate = DateConverter.changeDate2(infoTravel.getCheckin());
							String checkOutDate = DateConverter.changeDate2(infoTravel.getCheckout());
							String businessAdress = infoTravel.getAddress();
							context.setVariable("checkInDate", checkInDate);
							context.setVariable("checkOutDate", checkOutDate);
							context.setVariable("businessAdress", businessAdress);
							travelDetail.append("<tr><td>Accomodation</td><td colspan='3'>"+accomodation+"</td></tr>");
							travelDetail.append("<tr><td>Check In Date</td><td>"+checkInDate+"</td><td>Check Out Date</td><td>"+checkOutDate+"</td></tr>"); 
							travelDetail.append("<tr><td>Business Address</td><td colspan='3'>"+businessAdress+"</td></tr>"); 
						}
					 else {
							travelDetail.append("<tr><td>Accomodation</td><td>"+accomodation+"</td></tr>");
					 }
			
				}
					 
				 
				 travelDetail.append("</table>");
				
				 travelDetailToString = travelDetail.toString();
				map.put("travelDetailToString", travelDetailToString);
				
				context.setVariable("travelDetailToString", travelDetailToString);
			}
				//END - to get the passengers travel details//
				
				System.out.println(infoTravel.getSubmissionStatus());
			
			
			System.out.println(actionType);
			
			// 1.1 - if submitted directly without saving
			if(actionType == "add" && infoTravel.getSubmissionStatus().equals(1))
				{
					toEmail = approverEmail;
					if("Domestic".equals(infoTravel.getTravelType()) && "Deputation".equals(infoTravel.getTypeOfTravel())) {
						ccEmails = resourceEmail + "," + managerEmail + "," + LoadConstant.BPHR + "," + LoadConstant.AMG;
						context.setVariable("bphrAmg", "bphrAmg");	
					}
					else if("International".equals(infoTravel.getTravelType()) && "Business".equals(infoTravel.getTypeOfTravel())) {
						ccEmails = resourceEmail + "," + managerEmail + "," + LoadConstant.GLOBAL_MOBILITY;
						context.setVariable("visa", "visa");
					}
					else if("International".equals(infoTravel.getTravelType()) && "Deputation".equals(infoTravel.getTypeOfTravel())) {
						ccEmails = resourceEmail + "," + managerEmail + "," +LoadConstant.BPHR + "," + LoadConstant.AMG + "," + LoadConstant.GLOBAL_MOBILITY;
						context.setVariable("emailApproval", "emailApproval");
					}
					else {
						ccEmails = resourceEmail + "," + managerEmail;
					}
					
					//if user adds request for info travel	
					Resource createdBy = resourceController.findResource(infoTravel.getUid());					
					String title = createdBy.getTitle();
					
					if(("Hotel").equals(infoTravel.getTravelMode())) {
						subject = ""+ tourCode +" | "+ travelType +" | "+ empName+" X "+passengerCount+" | Approval Requested";
					}
					else if(("One Way").equals(infoTravel.getTravelWay())) {						
						subject = ""+ tourCode +" | "+ travelType +" | "+ empName+" X "+passengerCount+" | "+originNew+" - "+destinationNew+" | "+departureDate+" | Approval Requested";						
					}
					else if(("Round Trip").equals(infoTravel.getTravelWay())){						
						subject = ""+ tourCode +" | "+ travelType +" | "+ empName+" X "+passengerCount+" | "+originNew+" - "+destinationNew+" | "+departureDate+" - "+returnDate+" | Approval Requested";						
					}
					else {
						subject = ""+ tourCode +" | "+ travelType +" | "+ empName+" X "+passengerCount+" | Approval Requested";							
					}
					
															
					context.setVariable("title", title);
					context.setVariable("managerName", managerName);
					context.setVariable("addTravel", "addTravel");	
					template = "mail/infoTravel";		
				}
			//1.2 - if submitted after saving
			else if(actionType == "update" && infoTravel.getSubmissionStatus().equals(1) && infoTravel.getApprovalDate() ==null)
			{				
				//if user adds request for info travel
				System.out.println("Submitted");
				
				toEmail = approverEmail;
				if("Domestic".equals(infoTravel.getTravelType()) && "Deputation".equals(infoTravel.getTypeOfTravel())) {
					ccEmails = resourceEmail + "," + managerEmail + "," +LoadConstant.BPHR + "," + LoadConstant.AMG;
					context.setVariable("bphrAmg", "bphrAmg");
				}
				else if("International".equals(infoTravel.getTravelType()) && "Business".equals(infoTravel.getTypeOfTravel())) {
					ccEmails = resourceEmail + "," + managerEmail + "," + LoadConstant.GLOBAL_MOBILITY;
					context.setVariable("visa", "visa");
				}
				else if("International".equals(infoTravel.getTravelType()) && "Deputation".equals(infoTravel.getTypeOfTravel())) {
					ccEmails = resourceEmail + "," + managerEmail + "," + LoadConstant.BPHR + "," + LoadConstant.AMG + "," + LoadConstant.GLOBAL_MOBILITY;
					context.setVariable("emailApproval", "emailApproval");
				}
				else {
					ccEmails = resourceEmail + "," + managerEmail;
				}
				
				Resource createdBy = resourceController.findResource(infoTravel.getUid());					
				String title = createdBy.getTitle();
				
				if(("Hotel").equals(infoTravel.getTravelMode())) {
					subject = ""+ tourCode +" | "+ travelType +" | "+ empName+" X "+passengerCount+" | Approval Requested";
				}
				else if(("One Way").equals(infoTravel.getTravelWay())) {						
					subject = ""+ tourCode +" | "+ travelType +" | "+ empName+" X "+passengerCount+" | "+originNew+" - "+destinationNew+" | "+departureDate+" | Approval Requested";						
				}
				else if(("Round Trip").equals(infoTravel.getTravelWay())){						
					subject = ""+ tourCode +" | "+ travelType +" | "+ empName+" X "+passengerCount+" | "+originNew+" - "+destinationNew+" | "+departureDate+" - "+returnDate+" | Approval Requested";						
				}
				else {
					subject = ""+ tourCode +" | "+ travelType +" | "+ empName+" X "+passengerCount+" | Approval Requested";							
				}					
				
			 	logger.info("title="+title);
			 	
			 	
				context.setVariable("title", title);
				context.setVariable("managerName", managerName);
				context.setVariable("addTravel", "addTravel");		
				template = "mail/infoTravel";		
			}//after rejection
			else if(actionType == "update" && infoTravel.getSubmissionStatus().equals(1) && infoTravel.getApprovalDate() !=null)
			{				
				//if user adds request for info travel
				System.out.println("Submitted");
				
				toEmail = approverEmail;
				if("Domestic".equals(infoTravel.getTravelType()) && "Deputation".equals(infoTravel.getTypeOfTravel())) {
					ccEmails = resourceEmail + "," + managerEmail + "," + LoadConstant.BPHR + "," + LoadConstant.AMG;
					context.setVariable("bphrAmg", "bphrAmg");
				}
				else if("International".equals(infoTravel.getTravelType()) && "Business".equals(infoTravel.getTypeOfTravel())) {
					ccEmails = resourceEmail + "," + managerEmail + "," + LoadConstant.GLOBAL_MOBILITY;
					context.setVariable("visa", "visa");
				}
				else if("International".equals(infoTravel.getTravelType()) && "Deputation".equals(infoTravel.getTypeOfTravel())) {
					ccEmails = resourceEmail + "," + managerEmail + "," + LoadConstant.BPHR + "," + LoadConstant.AMG + "," + LoadConstant.GLOBAL_MOBILITY;
					context.setVariable("emailApproval", "emailApproval");
				}
				else {
					ccEmails = resourceEmail + "," + managerEmail;
				}
				
				Resource createdBy = resourceController.findResource(infoTravel.getUid());					
				String title = createdBy.getTitle();
				
				if(("Hotel").equals(infoTravel.getTravelMode())) {
					subject = ""+ tourCode +" | "+ travelType +" | "+ empName+" X "+passengerCount+" | Approval Requested";
				}
				else if(("One Way").equals(infoTravel.getTravelWay())) {						
					subject = ""+ tourCode +" | "+ travelType +" | "+ empName+" X "+passengerCount+" | "+originNew+" - "+destinationNew+" | "+departureDate+" | Approval Requested";						
				}
				else if(("Round Trip").equals(infoTravel.getTravelWay())){						
					subject = ""+ tourCode +" | "+ travelType +" | "+ empName+" X "+passengerCount+" | "+originNew+" - "+destinationNew+" | "+departureDate+" - "+returnDate+" | Approval Requested";						
				}
				else {
					subject = ""+ tourCode +" | "+ travelType +" | "+ empName+" X "+passengerCount+" | Approval Requested";							
				}					
				
			 	logger.info("title="+title);
			 	
			 	
				context.setVariable("title", title);
				context.setVariable("managerName", managerName);
				context.setVariable("rejectUpdate", "rejectUpdate");	
				template = "mail/infoTravel";		
			}
			//condition if request is cancelled
			else if(actionType == "update" && infoTravel.getSubmissionStatus().equals(2))
			{
				toEmail = resourceEmail;
				if("Domestic".equals(infoTravel.getTravelType()) && "Deputation".equals(infoTravel.getTypeOfTravel())) {
					ccEmails = approverEmail + "," + managerEmail + "," + LoadConstant.BPHR + "," + LoadConstant.AMG;
					context.setVariable("bphrAmg", "bphrAmg");
				}
				else if("International".equals(infoTravel.getTravelType()) && "Business".equals(infoTravel.getTypeOfTravel())) {
					ccEmails = approverEmail + "," + managerEmail + "," + LoadConstant.GLOBAL_MOBILITY;
					context.setVariable("visa", "visa");
				}
				else if("International".equals(infoTravel.getTravelType()) && "Deputation".equals(infoTravel.getTypeOfTravel())) {
					ccEmails = approverEmail + "," + managerEmail + "," + LoadConstant.BPHR + "," + LoadConstant.AMG + "," + LoadConstant.GLOBAL_MOBILITY;
					context.setVariable("emailApproval", "emailApproval");
				}
				else {
					ccEmails = managerEmail + "," + approverEmail;
				}
				
				System.out.println("Cancelled");
				//if user adds request for bus pass		
				Resource modifiedBy = resourceController.findResource(infoTravel.getUid());					
				String title = modifiedBy.getTitle();
				String cancelRemark = infoTravel.getReasonForCancellation();
				
				if(("Hotel").equals(infoTravel.getTravelMode())) {
					subject = ""+ tourCode +" | "+ travelType +" | "+ empName+" X "+passengerCount+" | Cancelled";
				}
				else if(("One Way").equals(infoTravel.getTravelWay())) {						
					subject = ""+ tourCode +" | "+ travelType +" | "+ empName+" X "+passengerCount+" | "+originNew+" - "+destinationNew+" | "+departureDate+" | Cancelled";						
				}
				else if(("Round Trip").equals(infoTravel.getTravelWay())){						
					subject = ""+ tourCode +" | "+ travelType +" | "+ empName+" X "+passengerCount+" | "+originNew+" - "+destinationNew+" | "+departureDate+" - "+returnDate+" | Cancelled";						
				}
				else {
					subject = ""+ tourCode +" | "+ travelType +" | "+ empName+" X "+passengerCount+" | Cancelled";							
				}								
				
			 	
				context.setVariable("title", title);
				context.setVariable("cancelRemark", cancelRemark);
				context.setVariable("managerName", managerName);
				context.setVariable("cancelInfoTravel", "cancelInfoTravel");	
				template = "mail/infoTravel";
				ccEmails = ccEmails + ',' + LoadConstant.TRAVEL_DESK;
			}
			
			//condition if request is auto-approved
			else if(actionType == "add" && infoTravel.getSubmissionStatus().equals(4) && infoTravel.getApproverId()==null)
			{	
				toEmail = LoadConstant.ACCOUNTS_PAYABLE;
				if("Domestic".equals(infoTravel.getTravelType()) && "Deputation".equals(infoTravel.getTypeOfTravel())) {
					ccEmails =  managerEmail + "," + resourceEmail + "," + LoadConstant.BPHR + "," + LoadConstant.AMG;
					context.setVariable("bphrAmg", "bphrAmg");
				}
				else if("International".equals(infoTravel.getTravelType()) && "Business".equals(infoTravel.getTypeOfTravel())) {
					ccEmails = managerEmail + "," + resourceEmail + "," + LoadConstant.GLOBAL_MOBILITY;
					context.setVariable("visa", "visa");
				}
				else if("International".equals(infoTravel.getTravelType()) && "Deputation".equals(infoTravel.getTypeOfTravel())) {
					ccEmails =  managerEmail + "," +resourceEmail + "," + LoadConstant.BPHR + "," + LoadConstant.AMG + "," + LoadConstant.GLOBAL_MOBILITY;
					context.setVariable("emailApproval", "emailApproval");
				}
				else {
					ccEmails = resourceEmail + "," + managerEmail;
				}
				ccEmails = ccEmails + "," + LoadConstant.S_GARG;
				
				String approvalDate = DateConverter.convertDateToString(infoTravel.getApprovalDate());
				
				System.out.println("Approved");
				
				Resource modifiedBy = resourceController.findResource(infoTravel.getUid());					
				String title = modifiedBy.getTitle();
				//String approveRemark = infoTravel.getApprovalRemarks();
				
			 	
				if(("Hotel").equals(infoTravel.getTravelMode())) {
					subject = ""+ tourCode +" | "+ travelType +" | "+ empName+" X "+passengerCount+" | Auto-Approved";
				}
				else if(("One Way").equals(infoTravel.getTravelWay())) {						
					subject = ""+ tourCode +" | "+ travelType +" | "+ empName+" X "+passengerCount+" | "+originNew+" - "+destinationNew+" | "+departureDate+" | Auto-Approved";						
				}
				else if(("Round Trip").equals(infoTravel.getTravelWay())){						
					subject = ""+ tourCode +" | "+ travelType +" | "+ empName+" X "+passengerCount+" | "+originNew+" - "+destinationNew+" | "+departureDate+" - "+returnDate+" | Auto-Approved";						
				}
				else {
					subject = ""+ tourCode +" | "+ travelType +" | "+ empName+" X "+passengerCount+" | Auto-Approved";							
				}
					 	
			 	
			 	//context.setVariable("approveRemark", approveRemark);
				context.setVariable("title", title);
				context.setVariable("managerName", managerName);
				context.setVariable("approvedAutoInfoTravel", "approvedAutoInfoTravel");	
				context.setVariable("approvalDate", approvalDate);
				logger.info("approvalDate="+approvalDate);
				template = "mail/infoTravel";
			}
			
			//condition if request is auto-approved
			else if(actionType == "update" && infoTravel.getSubmissionStatus().equals(4) && infoTravel.getApproverId()==null)
			{	
				toEmail = LoadConstant.ACCOUNTS_PAYABLE;
				if("Domestic".equals(infoTravel.getTravelType()) && "Deputation".equals(infoTravel.getTypeOfTravel())) {
					ccEmails =  managerEmail + "," + resourceEmail + "," + LoadConstant.BPHR + "," + LoadConstant.AMG;
					context.setVariable("bphrAmg", "bphrAmg");
				}
				else if("International".equals(infoTravel.getTravelType()) && "Business".equals(infoTravel.getTypeOfTravel())) {
					ccEmails = managerEmail + "," + resourceEmail + "," + LoadConstant.GLOBAL_MOBILITY;
					context.setVariable("visa", "visa");
				}
				else if("International".equals(infoTravel.getTravelType()) && "Deputation".equals(infoTravel.getTypeOfTravel())) {
					ccEmails =  managerEmail + "," +resourceEmail + "," + LoadConstant.BPHR + "," + LoadConstant.AMG + "," + LoadConstant.GLOBAL_MOBILITY;
					context.setVariable("emailApproval", "emailApproval");
				}
				else {
					ccEmails = managerEmail + "," +resourceEmail;
				}
				ccEmails = ccEmails + "," + LoadConstant.S_GARG;
				
				String approvalDate = DateConverter.convertDateToString(infoTravel.getApprovalDate());
				
				System.out.println("Approved");
				
				Resource modifiedBy = resourceController.findResource(infoTravel.getUid());					
				String title = modifiedBy.getTitle();
				//String approveRemark = infoTravel.getApprovalRemarks();
				
			 	
				if(("Hotel").equals(infoTravel.getTravelMode())) {
					subject = ""+ tourCode +" | "+ travelType +" | "+ empName+" X "+passengerCount+" | Auto-Approved";
				}
				else if(("One Way").equals(infoTravel.getTravelWay())) {						
					subject = ""+ tourCode +" | "+ travelType +" | "+ empName+" X "+passengerCount+" | "+originNew+" - "+destinationNew+" | "+departureDate+" | Auto-Approved";						
				}
				else if(("Round Trip").equals(infoTravel.getTravelWay())){						
					subject = ""+ tourCode +" | "+ travelType +" | "+ empName+" X "+passengerCount+" | "+originNew+" - "+destinationNew+" | "+departureDate+" - "+returnDate+" | Auto-Approved";						
				}
				else {
					subject = ""+ tourCode +" | "+ travelType +" | "+ empName+" X "+passengerCount+" | Auto-Approved";							
				}
					 	
			 	
			 	//context.setVariable("approveRemark", approveRemark);
				context.setVariable("title", title);
				context.setVariable("managerName", managerName);
				context.setVariable("approvedAutoInfoTravel", "approvedAutoInfoTravel");	
				context.setVariable("approvalDate", approvalDate);
				logger.info("approvalDate="+approvalDate);
				template = "mail/infoTravel";	
			}
			
			//condition if request is approved
			else if(actionType == "update" && infoTravel.getSubmissionStatus().equals(4))
			{	
				toEmail = LoadConstant.ACCOUNTS_PAYABLE;
				if("Domestic".equals(infoTravel.getTravelType()) && "Deputation".equals(infoTravel.getTypeOfTravel())) {
					ccEmails = approverEmail + "," + managerEmail + "," + resourceEmail + "," + LoadConstant.BPHR + "," + LoadConstant.AMG;
					context.setVariable("bphrAmg", "bphrAmg");
				}
				else if("International".equals(infoTravel.getTravelType()) && "Business".equals(infoTravel.getTypeOfTravel())) {
					ccEmails = approverEmail + "," + managerEmail + "," + resourceEmail + "," + LoadConstant.GLOBAL_MOBILITY;
					context.setVariable("visa", "visa");
				}
				else if("International".equals(infoTravel.getTravelType()) && "Deputation".equals(infoTravel.getTypeOfTravel())) {
					ccEmails = approverEmail + "," + managerEmail + "," +resourceEmail + "," + LoadConstant.BPHR + "," + LoadConstant.AMG + "," + LoadConstant.GLOBAL_MOBILITY;
					context.setVariable("emailApproval", "emailApproval");
				}
				else {
					ccEmails = managerEmail + "," + approverEmail + "," + resourceEmail;
				}
				
				String approvalDate = DateConverter.convertDateToString(infoTravel.getApprovalDate());
				
				System.out.println("Approved");
				
				Resource modifiedBy = resourceController.findResource(infoTravel.getUid());					
				String title = modifiedBy.getTitle();
				String approveRemark = infoTravel.getApprovalRemarks();
				
			 	
				if(("Hotel").equals(infoTravel.getTravelMode())) {
					subject = ""+ tourCode +" | "+ travelType +" | "+ empName+" X "+passengerCount+" | Approved";
				}
				else if(("One Way").equals(infoTravel.getTravelWay())) {						
					subject = ""+ tourCode +" | "+ travelType +" | "+ empName+" X "+passengerCount+" | "+originNew+" - "+destinationNew+" | "+departureDate+" | Approved";						
				}
				else if(("Round Trip").equals(infoTravel.getTravelWay())){						
					subject = ""+ tourCode +" | "+ travelType +" | "+ empName+" X "+passengerCount+" | "+originNew+" - "+destinationNew+" | "+departureDate+" - "+returnDate+" | Approved";						
				}
				else {
					subject = ""+ tourCode +" | "+ travelType +" | "+ empName+" X "+passengerCount+" | Approved";							
				}
					 	
			 	
			 	context.setVariable("approveRemark", approveRemark);
				context.setVariable("title", title);
				context.setVariable("managerName", managerName);
				context.setVariable("approvedInfoTravel", "approvedInfoTravel");	
				context.setVariable("approvalDate", approvalDate);
				logger.info("approvalDate="+approvalDate);
				template = "mail/infoTravel";		
			}
			
			//condition if request is rejected
			else if(actionType == "update" && infoTravel.getSubmissionStatus().equals(5))
			{
				toEmail =  resourceEmail;
				
				if("Domestic".equals(infoTravel.getTravelType()) && "Deputation".equals(infoTravel.getTypeOfTravel())) {
					ccEmails = managerEmail + "," + approverEmail + "," + LoadConstant.BPHR + "," + LoadConstant.AMG;
					context.setVariable("bphrAmg", "bphrAmg");
				}
				else if("International".equals(infoTravel.getTravelType()) && "Business".equals(infoTravel.getTypeOfTravel())) {
					ccEmails = managerEmail + "," + approverEmail + "," + LoadConstant.GLOBAL_MOBILITY;
					context.setVariable("visa", "visa");
				}
				else if("International".equals(infoTravel.getTravelType()) && "Deputation".equals(infoTravel.getTypeOfTravel())) {
					ccEmails = managerEmail + "," + approverEmail + "," + LoadConstant.BPHR + "," + LoadConstant.AMG + "," + LoadConstant.GLOBAL_MOBILITY;
					context.setVariable("emailApproval", "emailApproval");
				}
				else {
					ccEmails = managerEmail + "," + approverEmail;
				}
				
				System.out.println("Rejected");
				
				Resource modifiedBy = resourceController.findResource(infoTravel.getUid());					
				String title = modifiedBy.getTitle();
				String approveRemark = infoTravel.getApprovalRemarks();
				
				if(("Hotel").equals(infoTravel.getTravelMode())) {
					subject = ""+ tourCode +" | "+ travelType +" | "+ empName+" X "+passengerCount+" | Rejected";
				}
				else if(("One Way").equals(infoTravel.getTravelWay())) {						
					subject = ""+ tourCode +" | "+ travelType +" | "+ empName+" X "+passengerCount+" | "+originNew+" - "+destinationNew+" | "+departureDate+" | Rejected";						
				}
				else if(("Round Trip").equals(infoTravel.getTravelWay())){						
					subject = ""+ tourCode +" | "+ travelType +" | "+ empName+" X "+passengerCount+" | "+originNew+" - "+destinationNew+" | "+departureDate+" - "+returnDate+" | Rejected";						
				}
				else {
					subject = ""+ tourCode +" | "+ travelType +" | "+ empName+" X "+passengerCount+" | Rejected";							
				}
							 	
			 	
			 	context.setVariable("approveRemark", approveRemark);
				context.setVariable("title", title);
				context.setVariable("managerName", managerName);
				context.setVariable("rejectedInfoTravel", "rejectedInfoTravel");	
				template = "mail/infoTravel";		
			}
			//condition if request is validated
			else if(actionType == "update" && infoTravel.getSubmissionStatus().equals(6))
			{
				System.out.println("Validated");
				//if user adds request for bus pass		
				Resource modifiedBy = resourceController.findResource(infoTravel.getUid());					
				String title = modifiedBy.getTitle();
				Resource financeTeam = resourceController.findResource(infoTravel.getFinanceId());	
				String financeTitle = financeTeam.getTitle();
				String financeEmail = financeTeam.getEmail();
				
				 if(infoTravel.getValidatedDate()!=null) { 
					 String validatedDate = DateConverter.convertDateToString(infoTravel.getValidatedDate());
					 context.setVariable("validatedDate", validatedDate);
					 logger.info("validatedDate="+validatedDate);
				 }
				 if(infoTravel.getApprovalDate()!=null) { 
				 String approvalDate = DateConverter.convertDateToString(infoTravel.getApprovalDate());
				 context.setVariable("approvalDate", approvalDate);
				 }
				 
				toEmail = LoadConstant.TRAVEL_DESK;
				if(infoTravel.getApproverId()==null) {
					if("Domestic".equals(infoTravel.getTravelType()) && "Deputation".equals(infoTravel.getTypeOfTravel())) {
						ccEmails = LoadConstant.ACCOUNTS_PAYABLE + "," + resourceEmail + "," + managerEmail + "," + LoadConstant.BPHR + "," + LoadConstant.AMG;
						context.setVariable("bphrAmg", "bphrAmg");
					}
					else if("International".equals(infoTravel.getTravelType()) && "Business".equals(infoTravel.getTypeOfTravel())) {
						ccEmails = LoadConstant.ACCOUNTS_PAYABLE + "," + resourceEmail + "," + managerEmail + "," + LoadConstant.GLOBAL_MOBILITY;
						context.setVariable("visa", "visa");
					}
					else if("International".equals(infoTravel.getTravelType()) && "Deputation".equals(infoTravel.getTypeOfTravel())) {
						ccEmails = LoadConstant.ACCOUNTS_PAYABLE + "," + resourceEmail + "," + managerEmail + "," + LoadConstant.BPHR + "," + LoadConstant.AMG + "," + LoadConstant.GLOBAL_MOBILITY;
						context.setVariable("emailApproval", "emailApproval");
					}
					else {
						ccEmails = LoadConstant.ACCOUNTS_PAYABLE + "," + resourceEmail + "," + managerEmail;
					}
				}
				else {
					
					if("Domestic".equals(infoTravel.getTravelType()) && "Deputation".equals(infoTravel.getTypeOfTravel())) {
						ccEmails = LoadConstant.ACCOUNTS_PAYABLE + "," + resourceEmail + "," + managerEmail + "," + approverEmail + "," + LoadConstant.BPHR + "," + LoadConstant.AMG;
						context.setVariable("bphrAmg", "bphrAmg");
					}
					else if("International".equals(infoTravel.getTravelType()) && "Business".equals(infoTravel.getTypeOfTravel())) {
						ccEmails = LoadConstant.ACCOUNTS_PAYABLE + "," + resourceEmail + "," + managerEmail + "," + approverEmail + "," + LoadConstant.GLOBAL_MOBILITY;
						context.setVariable("visa", "visa");
					}
					else if("International".equals(infoTravel.getTravelType()) && "Deputation".equals(infoTravel.getTypeOfTravel())) {
						ccEmails = LoadConstant.ACCOUNTS_PAYABLE + "," + resourceEmail + "," + managerEmail + "," + approverEmail + "," + LoadConstant.BPHR + "," + LoadConstant.AMG + "," + LoadConstant.GLOBAL_MOBILITY;
						context.setVariable("emailApproval", "emailApproval");
					}
					else {
						ccEmails = LoadConstant.ACCOUNTS_PAYABLE + "," + resourceEmail + "," + managerEmail + "," + approverEmail;
					}
					context.setVariable("approverIdExist", "approverIdExist");
				}
				
				if(("Hotel").equals(infoTravel.getTravelMode())) {
					subject = ""+ tourCode +" | "+ travelType +" | "+ empName+" X "+passengerCount+" | Validated";
				}
				else if(("One Way").equals(infoTravel.getTravelWay())) {						
					subject = ""+ tourCode +" | "+ travelType +" | "+ empName+" X "+passengerCount+" | "+originNew+" - "+destinationNew+" | "+departureDate+" | Validated";						
				}
				else if(("Round Trip").equals(infoTravel.getTravelWay())){						
					subject = ""+ tourCode +" | "+ travelType +" | "+ empName+" X "+passengerCount+" | "+originNew+" - "+destinationNew+" | "+departureDate+" - "+returnDate+" | Validated";						
				}
				else {
					subject = ""+ tourCode +" | "+ travelType +" | "+ empName+" X "+passengerCount+" | Validated";							
				}
									
				
			 	
			 	logger.info("financeTitle="+financeTitle);
			 	
			 	context.setVariable("financeTitle", financeTitle);
			 	context.setVariable("financeEmail", financeEmail);
				context.setVariable("title", title);
				
				
				context.setVariable("updatedInfoTravel", "updatedInfoTravel");	
				template = "mail/infoTravel";		
			}//acknowledged by travel
			else if(actionType == "update" && infoTravel.getSubmissionStatus().equals(7))
			{
				toEmail = resourceEmail;
				if("Domestic".equals(infoTravel.getTravelType()) && "Deputation".equals(infoTravel.getTypeOfTravel())) {
					//ccEmails = managerEmail + "," + approverEmail + "," + LoadConstant.BPHR + "," + LoadConstant.AMG;
					//context.setVariable("bphrAmg", "bphrAmg");
				}
				else if("International".equals(infoTravel.getTravelType()) && "Business".equals(infoTravel.getTypeOfTravel())) {
					//ccEmails = managerEmail + "," + approverEmail + "," + LoadConstant.GLOBAL_MOBILITY;
					////context.setVariable("visa", "visa");
				}
				else if("International".equals(infoTravel.getTravelType()) && "Deputation".equals(infoTravel.getTypeOfTravel())) {
					//ccEmails = managerEmail + "," + approverEmail + "," + LoadConstant.BPHR + "," + LoadConstant.AMG + "," + LoadConstant.GLOBAL_MOBILITY;
					//context.setVariable("emailApproval", "emailApproval");
				}
				else {
					//ccEmails = managerEmail + "," + approverEmail;
				}
				System.out.println("Saved by admin");
				//if user adds request for bus pass		
				Resource modifiedBy = resourceController.findResource(infoTravel.getUid());					
				String title = modifiedBy.getTitle();
				String adminRemark = infoTravel.getTravelDeskClosureRemarks();
				
				if(("Hotel").equals(infoTravel.getTravelMode())) {
					subject = ""+ tourCode +" | "+ travelType +" | "+ empName+" X "+passengerCount+" | Approved & Validated | Documents uploaded";
				}
				else if(("One Way").equals(infoTravel.getTravelWay())) {						
					subject = ""+ tourCode +" | "+ travelType +" | "+ empName+" X "+passengerCount+" | "+originNew+" - "+destinationNew+" | "+departureDate+" | Approved & Validated | Documents uploaded";						
				}
				else if(("Round Trip").equals(infoTravel.getTravelWay())){						
					subject = ""+ tourCode +" | "+ travelType +" | "+ empName+" X "+passengerCount+" | "+originNew+" - "+destinationNew+" | "+departureDate+" - "+returnDate+" | Approved & Validated | Documents uploaded";						
				}
				else {
					subject = ""+ tourCode +" | "+ travelType +" | "+ empName+" X "+passengerCount+" | Approved & Validated | Documents uploaded";							
				}
				
				if(infoTravel.getFinanceId()!=null) {
					Resource financeTeam = resourceController.findResource(infoTravel.getFinanceId());	
					String financeTitle = financeTeam.getTitle();
					String financeEmail = financeTeam.getEmail();
					context.setVariable("financeTitle", financeTitle);
				 	context.setVariable("financeEmail", financeEmail);
				}
				
				 if(infoTravel.getValidatedDate()!=null) { 
					 String validatedDate = DateConverter.convertDateToString(infoTravel.getValidatedDate());
					 context.setVariable("validatedDate", validatedDate);
					 logger.info("validatedDate="+validatedDate);
				 }
				 if(infoTravel.getApprovalDate()!=null) { 
				 String approvalDate = DateConverter.convertDateToString(infoTravel.getApprovalDate());
				 context.setVariable("approvalDate", approvalDate);
				 }
			 	
				context.setVariable("title", title);
				context.setVariable("adminRemark", adminRemark);
				context.setVariable("managerName", managerName);
				context.setVariable("travelUpdate", "travelUpdate");
				template = "mail/infoTravel";
				
			}//travel request closed
			else if(actionType == "update" && infoTravel.getSubmissionStatus().equals(8))
			{	
				System.out.println("Saved by admin");
				toEmail = resourceEmail;
				if(infoTravel.getApproverId()==null) {
					
					if("Domestic".equals(infoTravel.getTravelType()) && "Deputation".equals(infoTravel.getTypeOfTravel())) {
						ccEmails = managerEmail  + "," + LoadConstant.BPHR + "," + LoadConstant.AMG;
						//context.setVariable("bphrAmg", "bphrAmg");
					}
					else if("International".equals(infoTravel.getTravelType()) && "Business".equals(infoTravel.getTypeOfTravel())) {
						ccEmails = managerEmail + "," + LoadConstant.GLOBAL_MOBILITY;
						//context.setVariable("visa", "visa");
					}
					else if("International".equals(infoTravel.getTravelType()) && "Deputation".equals(infoTravel.getTypeOfTravel())) {
						ccEmails = managerEmail + "," + LoadConstant.BPHR + "," + LoadConstant.AMG + "," + LoadConstant.GLOBAL_MOBILITY;
						//context.setVariable("emailApproval", "emailApproval");
					}
					else {
						ccEmails = managerEmail;
					}
				}
				else {
					if("Domestic".equals(infoTravel.getTravelType()) && "Deputation".equals(infoTravel.getTypeOfTravel())) {
						ccEmails = managerEmail + "," + approverEmail + "," + LoadConstant.BPHR + "," + LoadConstant.AMG;
						//context.setVariable("bphrAmg", "bphrAmg");
					}
					else if("International".equals(infoTravel.getTravelType()) && "Business".equals(infoTravel.getTypeOfTravel())) {
						ccEmails = managerEmail + "," + approverEmail + "," + LoadConstant.GLOBAL_MOBILITY;
						//context.setVariable("visa", "visa");
					}
					else if("International".equals(infoTravel.getTravelType()) && "Deputation".equals(infoTravel.getTypeOfTravel())) {
						ccEmails = managerEmail + "," + approverEmail + "," + LoadConstant.BPHR + "," + LoadConstant.AMG + "," + LoadConstant.GLOBAL_MOBILITY;
						//context.setVariable("emailApproval", "emailApproval");
					}
					else {
						ccEmails = managerEmail + "," + approverEmail;
					}

				}
				
				Resource modifiedBy = resourceController.findResource(infoTravel.getUid());					
				String title = modifiedBy.getTitle();
				
				if(("Hotel").equals(infoTravel.getTravelMode())) {
					subject = ""+ tourCode +" | "+ travelType +" | "+ empName+" X "+passengerCount+" | Approved & Validated | Closed";
				}
				else if(("One Way").equals(infoTravel.getTravelWay())) {						
					subject = ""+ tourCode +" | "+ travelType +" | "+ empName+" X "+passengerCount+" | "+originNew+" - "+destinationNew+" | "+departureDate+" | Approved & Validated | Closed";						
				}
				else if(("Round Trip").equals(infoTravel.getTravelWay())){						
					subject = ""+ tourCode +" | "+ travelType +" | "+ empName+" X "+passengerCount+" | "+originNew+" - "+destinationNew+" | "+departureDate+" - "+returnDate+" | Approved & Validated | Closed";						
				}
				else {
					subject = ""+ tourCode +" | "+ travelType +" | "+ empName+" X "+passengerCount+" | Approved & Validated | Closed";							
				}
								
				if(infoTravel.getFinanceId()!=null) {
					Resource financeTeam = resourceController.findResource(infoTravel.getFinanceId());	
					String financeTitle = financeTeam.getTitle();
					String financeEmail = financeTeam.getEmail();
					context.setVariable("financeTitle", financeTitle);
				 	context.setVariable("financeEmail", financeEmail);
				}
				
				 if(infoTravel.getValidatedDate()!=null) { 
					 String validatedDate = DateConverter.convertDateToString(infoTravel.getValidatedDate());
					 context.setVariable("validatedDate", validatedDate);
					 logger.info("validatedDate="+validatedDate);
				 }
				 if(infoTravel.getApprovalDate()!=null) { 
				 String approvalDate = DateConverter.convertDateToString(infoTravel.getApprovalDate());
				 context.setVariable("approvalDate", approvalDate);
				 }
			 	
				context.setVariable("title", title);
				context.setVariable("managerName", managerName);
				context.setVariable("travelClosed", "travelClosed");
				template = "mail/infoTravel";
				
			}
			//For feedback
			else if(actionType == "update" && infoTravel.getSubmissionStatus().equals(9))
			{	
				System.out.println("Feedback");
				toEmail = LoadConstant.TRAVEL_DESK;
				ccEmails = resourceEmail;
				
				Resource modifiedBy = resourceController.findResource(infoTravel.getUid());					
				String title = modifiedBy.getTitle();
				
				if(("Hotel").equals(infoTravel.getTravelMode())) {
					subject = ""+ tourCode +" | "+ travelType +" | "+ empName+" X "+passengerCount+" | Feedback";	
				}
				else if(("One Way").equals(infoTravel.getTravelWay())) {						
					subject = ""+ tourCode +" | "+ travelType +" | "+ empName+" X "+passengerCount+" | "+originNew+" - "+destinationNew+" | "+departureDate+" | Feedback";						
				}
				else if(("Round Trip").equals(infoTravel.getTravelWay())){						
					subject = ""+ tourCode +" | "+ travelType +" | "+ empName+" X "+passengerCount+" | "+originNew+" - "+destinationNew+" | "+departureDate+" - "+returnDate+" | Feedback";						
				}
				else {
					subject = ""+ tourCode +" | "+ travelType +" | "+ empName+" X "+passengerCount+" | Feedback";							
				}
								
				if(infoTravel.getFinanceId()!=null) {
					Resource financeTeam = resourceController.findResource(infoTravel.getFinanceId());	
					String financeTitle = financeTeam.getTitle();
					String financeEmail = financeTeam.getEmail();
					context.setVariable("financeTitle", financeTitle);
				 	context.setVariable("financeEmail", financeEmail);
				}
				
				 if(infoTravel.getValidatedDate()!=null) { 
					 String validatedDate = DateConverter.convertDateToString(infoTravel.getValidatedDate());
					 context.setVariable("validatedDate", validatedDate);
					 logger.info("validatedDate="+validatedDate);
				 }
				 if(infoTravel.getApprovalDate()!=null) { 
				 String approvalDate = DateConverter.convertDateToString(infoTravel.getApprovalDate());
				 context.setVariable("approvalDate", approvalDate);
				 }
				 if(infoTravel.getRating()!=null) {
					 Integer rating = infoTravel.getRating();
					 context.setVariable("rating", rating);
					 if(infoTravel.getRatingComments()!=null) {
						 String ratingComm = infoTravel.getRatingComments();
						 context.setVariable("ratingComm", ratingComm);
					 }
				 }
				 template = "mail/travelFeedback";		
				context.setVariable("title", title);
				context.setVariable("managerName", managerName);
				context.setVariable("feedback", "feedback");	
			}
				
				context.setVariable("infoTravelId", infoTravelId);
				context.setVariable("tourCode", tourCode);
				
				context.setVariable("unitName", unitName);
				context.setVariable("projectName", projectName);
				context.setVariable("travelType", travelType);
				
				context.setVariable("travelMode", travelMode);
				context.setVariable("typeOfTravel", typeOfTravel);
				context.setVariable("managerEmail", managerEmail);
			
				context.setVariable("approverRemark", approverRemark);
				context.setVariable("travellerRemark", travellerRemark);
				context.setVariable("accomodation", accomodation);
				context.setVariable("nomineeName", nomineeName);
				context.setVariable("nomineeRelation", nomineeRelation);
				context.setVariable("createdDate", createdDate);
				context.setVariable("travelRemark", travelRemark);
				context.setVariable("projectManager", projectManager);
				context.setVariable("associateUnit", associateUnit);
				
				context.setVariable("billableCost", billableCost);
				context.setVariable("travelPourpose", travelPourpose);
				
				context.setVariable("managerName", managerName);
				
				logger.info("ccEmails="+ccEmails);
				ccEmails = Arrays.asList(ccEmails.split(",")).stream().distinct().collect(Collectors.joining(","));
				logger.info("unitName="+unitName);
				logger.info("projectName="+projectName);
				logger.info("approverName="+approverName);
				logger.info("subject="+subject);
				
				
				
					
				logger.info("ccEmails="+ccEmails);
				logger.info("fromEmail="+fromEmail);
				logger.info("toEmail="+toEmail);
				
		}	

		smtpMailSender.send(fromEmail,toEmail, subject, template, context,ccEmails, request);		
		
		return true;
	}
	
	@Override
	public boolean sendInfoTravelApproverCronNotification()  throws MessagingException {
		logger.info("sendInfoTravelApproverCronNotification==================");
		List<InfoTravel> infoTravelList= infoTravelController.findInfoTravel(0, 0, false, false, false, false, 1, 0,null);
		
		//if user adds request for info travel
		String subject = "";
		String template = "";
		Context context = new Context();  
		String ccEmails= "";
		String fromEmail = LoadConstant.TRAVEL_DESK;
		String toEmail = "";
		//User
		for(InfoTravel infoTravel:infoTravelList) {
			if(infoTravel.getUid() !=null) {
				
				Resource resource = resourceController.findResource(infoTravel.getUid());
				String resourceEmail = resource.getEmail();
				String empName = resource.getTitle();
				Integer empId = resource.getEmpId();
				context.setVariable("resourceEmail", resourceEmail);
				context.setVariable("empName", empName);			
				context.setVariable("empId", empId);	
				
				if(infoTravel.getSubmittedDate() != null) {
					
					Date d1 = infoTravel.getSubmittedDate();
					Date d2 = new Date();
					
					//in milliseconds
					long diff = d2.getTime() - d1.getTime();
					long diffHours = diff / (60 * 60 * 1000) % 24;
					System.out.print(diffHours + " hours, ");
					
					String tourCode = infoTravel.getTourCode();			
					context.setVariable("tourCode", tourCode);
					
					if(tourCode!= null && infoTravel.getSubmissionStatus().equals(1) && diffHours > 4)
					{	
						if(infoTravel.getApproverId() != null) {
							Resource approverId = resourceController.findResource(infoTravel.getApproverId());			
							String approverName = approverId.getTitle();
							String approverEmail = approverId.getEmail();
							toEmail = approverEmail;
							
							subject = "Reminder Mail For Approval | "+ tourCode +" | "+ empName;
							
							template = "mail/infoTravelReminder";
							
							context.setVariable("approvalReminder", "approvalReminder");
							context.setVariable("approverName", approverName);
							context.setVariable("approverEmail", approverEmail);
							
							logger.info("approverName="+approverName);
							infoTravelUtil.send(fromEmail,toEmail, subject, template, context,ccEmails);
						}					
					}				
				}		
			}
		}
		return true;
	}
	
	
	@Override
	public boolean sendInfoTravelFinanceCronNotification()  throws MessagingException {
		logger.info("sendInfoTravelFinanceCronNotification==================");
		List<InfoTravel> infoTravelList= infoTravelController.findInfoTravel(0, 0, false, false, false, false, 4, 0,null);
		
		//if user adds request for info travel
		String subject = "";
		String template = "";
		Context context = new Context();  
		String ccEmails = "";
		String fromEmail = LoadConstant.TRAVEL_DESK;
		String toEmail = LoadConstant.ACCOUNTS_PAYABLE;
		Resource approverId = null;
		String tourCode = "";
		//User
		for(InfoTravel infoTravel:infoTravelList) {
			
			if(infoTravel.getUid()!=null) {
				
				Resource resource = resourceController.findResource(infoTravel.getUid());
				String resourceEmail = resource.getEmail();
				String empName = resource.getTitle();
				Integer empId = resource.getEmpId();
				
				context.setVariable("resourceEmail", resourceEmail);
				context.setVariable("empName", empName);			
				context.setVariable("empId", empId);
				
				tourCode = infoTravel.getTourCode();
				context.setVariable("tourCode", tourCode);
				
				subject = "Reminder Mail For Validation | "+ tourCode +" | "+ empName; 
				
				if(infoTravel.getApprovalDate() != null) {
					Date d1 = infoTravel.getApprovalDate();
					Date d2 = new Date();
					
					//in milliseconds
					long diff = d2.getTime() - d1.getTime();
					long diffHours = diff / (60 * 60 * 1000) % 24;
					System.out.print(diffHours + " hours, ");
					
					
					if(tourCode != null && infoTravel.getSubmissionStatus().equals(4) && diffHours > 2) { 
						
						if(infoTravel.getApproverId()!=null) {
							approverId = resourceController.findResource(infoTravel.getApproverId());			
							String approverName = approverId.getTitle();
							String approverEmail = approverId.getEmail();
							
							context.setVariable("validateReminder", "validateReminder");
							context.setVariable("approverName", approverName);
							context.setVariable("approverEmail", approverEmail);
							
							
							template = "mail/infoTravelReminder";
							logger.info("ccEmails="+ccEmails);
							logger.info("fromEmail="+fromEmail);
							logger.info("toEmail="+toEmail);
							infoTravelUtil.send(fromEmail,toEmail, subject, template, context,ccEmails);
						}
						
					}
					
				}
			}
			
		
		}
		return true;
	}
	
	
	@Override
	public boolean sendInfoTravelDeskDomesticEsc1CronNotification()  throws MessagingException {
		logger.info("sendInfoTravelDeskDomesticEsc1CronNotification==================");
		List<InfoTravel> infoTravelList= infoTravelController.findInfoTravel(0, 0, false, false, false, false, 6, 0, null);
		
		//if user adds request for info travel
		String subject = "";
		String template = "";
		Context context = new Context();  
		String ccEmails = "";
		String fromEmail = LoadConstant.TRAVEL_DESK;
		String toEmail = LoadConstant.SV_GOLHER;
		String tourCode = "";
		//User
		for(InfoTravel infoTravel:infoTravelList) {
			if(infoTravel.getUid()!=null) {
				
				Resource resource = resourceController.findResource(infoTravel.getUid());
				String resourceEmail = resource.getEmail();
				String empName = resource.getTitle();
				Integer empId = resource.getEmpId();
				
				
				context.setVariable("resourceEmail", resourceEmail);
				context.setVariable("empName", empName);			
				context.setVariable("empId", empId);	
				
				tourCode = infoTravel.getTourCode();
				subject = "Escalation Mail | Domestic | "+ tourCode +" | "+ empName; 
			
		
			if(infoTravel.getValidatedDate() != null) {
				
				Date d1 = infoTravel.getValidatedDate();
				Date d2 = new Date();
				
				//in milliseconds
				long diff = d2.getTime() - d1.getTime();
				long diffHours = diff / (60 * 60 * 1000) % 24;
				System.out.print(diffHours + " hours, ");
				

				if(tourCode != null && infoTravel.getSubmissionStatus().equals(6) && infoTravel.getTravelType() == "Domestic" && diffHours > 72) { 
					
					if(infoTravel.getApproverId()!=null) {
						Resource approverId = resourceController.findResource(infoTravel.getApproverId());			
						String approverName = approverId.getTitle();
						String approverEmail = approverId.getEmail();
						context.setVariable("approverName", approverName);
						context.setVariable("approverEmail", approverEmail);
					}
					if(infoTravel.getFinanceId()!=null) {
						Resource financeId = resourceController.findResource(infoTravel.getFinanceId());
						String financeName = financeId.getTitle();
						String financeEmail = financeId.getEmail();						
						context.setVariable("financeName", financeName);
						context.setVariable("financeEmail", financeEmail);
					}
					
					context.setVariable("travelReminder", "travelReminder");		
					
					
					template = "mail/infoTravelReminder";
					
					infoTravelUtil.send(fromEmail,toEmail, subject, template, context,ccEmails);	
				}
			}
			
		}
		}
		return true;
	}
	
	@Override
	public boolean sendInfoTravelDeskInternationalEsc1CronNotification()  throws MessagingException {
		logger.info("sendInfoTravelDeskInternationalEsc1CronNotification==================");
		List<InfoTravel> infoTravelList= infoTravelController.findInfoTravel(0, 0, false, false, false, false, 6, 0, null);
		
		//if user adds request for info travel
		String subject = "";
		String template = "";
		Context context = new Context();  
		String ccEmails = "";
		String fromEmail = LoadConstant.TRAVEL_DESK;
		String toEmail = LoadConstant.SV_GOLHER;
		String tourCode = "";
		//User
		for(InfoTravel infoTravel:infoTravelList) {
			
			
			if(infoTravel.getUid()!=null) {
				
				Resource resource = resourceController.findResource(infoTravel.getUid());
				String resourceEmail = resource.getEmail();
				String empName = resource.getTitle();
				Integer empId = resource.getEmpId();
				context.setVariable("resourceEmail", resourceEmail);
				context.setVariable("empName", empName);			
				context.setVariable("empId", empId);	
				
			    tourCode = infoTravel.getTourCode();
				subject = "Escalation Mail | International | "+ tourCode +" | "+ empName; 
			
			
			

			if(infoTravel.getValidatedDate() != null) {

				Date d1 = infoTravel.getValidatedDate();
				Date d2 = new Date();
				
				//in milliseconds
				long diff = d2.getTime() - d1.getTime();
				long diffHours = diff / (60 * 60 * 1000) % 24;
				System.out.print(diffHours + " hours, ");
				
				
				if(tourCode != null && infoTravel.getSubmissionStatus().equals(6) && infoTravel.getTravelType() == "International" && diffHours > 120) { 
					
					if(infoTravel.getApproverId()!=null) {
						Resource approverId = resourceController.findResource(infoTravel.getApproverId());			
						String approverName = approverId.getTitle();
						String approverEmail = approverId.getEmail();
						context.setVariable("approverName", approverName);
						context.setVariable("approverEmail", approverEmail);
					}
					
					
					if(infoTravel.getFinanceId()!=null) {
						Resource financeId = resourceController.findResource(infoTravel.getFinanceId());
						String financeName = financeId.getTitle();
						String financeEmail = financeId.getEmail();
						context.setVariable("financeName", financeName);
						context.setVariable("financeEmail", financeEmail);
					}
					
					context.setVariable("travelInternationReminder", "travelInternationReminder");
																	
					
					template = "mail/infoTravelReminder";
					
					infoTravelUtil.send(fromEmail,toEmail, subject, template, context,ccEmails);	
				}
				}
			
			}
		}
		return true;
	}
	
	@Override
	public boolean sendInfoTravelDeskDomesticEsc2CronNotification()  throws MessagingException {
		logger.info("sendInfoTravelDeskDomesticEsc2CronNotification==================");
		List<InfoTravel> infoTravelList= infoTravelController.findInfoTravel(0, 0, false, false, false, false, 6, 0, null);
		
		//if user adds request for info travel
		String subject = "";
		String template = "";
		Context context = new Context();  
		String ccEmails = "";
		String fromEmail = LoadConstant.TRAVEL_DESK;
		String toEmail = LoadConstant.L_NATHANI;
		String tourCode="";
		//User
		for(InfoTravel infoTravel:infoTravelList) {
			if(infoTravel.getUid()!=null) {
				
				Resource resource = resourceController.findResource(infoTravel.getUid());
				String resourceEmail = resource.getEmail();
				String empName = resource.getTitle();
				Integer empId = resource.getEmpId();
				
				
				context.setVariable("resourceEmail", resourceEmail);
				context.setVariable("empName", empName);			
				context.setVariable("empId", empId);
				
				tourCode = infoTravel.getTourCode();
				subject = "Escalation Mail | Domestic | "+ tourCode +" | "+ empName; 
			

			if(infoTravel.getValidatedDate() != null) {
				Date d1 = infoTravel.getValidatedDate();
				Date d2 = new Date();
				
				//in milliseconds
				long diff = d2.getTime() - d1.getTime();
				long diffHours = diff / (60 * 60 * 1000) % 24;
				System.out.print(diffHours + " hours, ");
			
				if(tourCode != null && infoTravel.getSubmissionStatus().equals(6) && infoTravel.getTravelType() == "Domestic" && diffHours > 96) { 
				
					if(infoTravel.getApproverId() != null) {
						Resource approverId = resourceController.findResource(infoTravel.getApproverId());			
						String approverName = approverId.getTitle();
						String approverEmail = approverId.getEmail();
						context.setVariable("approverName", approverName);
						context.setVariable("approverEmail", approverEmail);
					}
					if(infoTravel.getApproverId() != null) {
						
						Resource financeId = resourceController.findResource(infoTravel.getFinanceId());
						String financeName = financeId.getTitle();
						String financeEmail = financeId.getEmail();
						
						context.setVariable("financeName", financeName);
						context.setVariable("financeEmail", financeEmail);
					}
					
					context.setVariable("travelReminder", "travelReminder");
								
					
					template = "mail/infoTravelReminder";
					
					infoTravelUtil.send(fromEmail,toEmail, subject, template, context,ccEmails);	
				}
				}
			}
		
		}
		return true;
	}
	
	@Override
	public boolean sendInfoTravelDeskInternationalEsc2CronNotification()  throws MessagingException {
		logger.info("sendInfoTravelDeskInternationalEsc2CronNotification==================");
		List<InfoTravel> infoTravelList= infoTravelController.findInfoTravel(0, 0, false, false, false, false, 6, 0, null);
		
		//if user adds request for info travel
		String subject = "";
		String template = "";
		Context context = new Context();  
		String ccEmails = "";
		String tourCode="";
		String fromEmail = LoadConstant.TRAVEL_DESK;
		String toEmail = LoadConstant.L_NATHANI;
		//User
		for(InfoTravel infoTravel:infoTravelList) {
			if(infoTravel.getUid()!=null) {
				
				Resource resource = resourceController.findResource(infoTravel.getUid());
				String resourceEmail = resource.getEmail();
				String empName = resource.getTitle();
				Integer empId = resource.getEmpId();
				context.setVariable("resourceEmail", resourceEmail);
				context.setVariable("empName", empName);			
				context.setVariable("empId", empId);	
				
				tourCode = infoTravel.getTourCode();
				subject = "Escalation Mail | International | "+ tourCode +" | "+ empName; 
			
			
			

			if(infoTravel.getValidatedDate() !=null) {
				Date d1 = infoTravel.getValidatedDate();
				Date d2 = new Date();
				
				//in milliseconds
				long diff = d2.getTime() - d1.getTime();
				long diffHours = diff / (60 * 60 * 1000) % 24;
				System.out.print(diffHours + " hours, ");
			
				if(tourCode != null && infoTravel.getSubmissionStatus().equals(6) && infoTravel.getTravelType() == "International" && diffHours > 168) { 
				
					if(infoTravel.getApproverId() != null) {
						Resource approverId = resourceController.findResource(infoTravel.getApproverId());			
						String approverName = approverId.getTitle();
						String approverEmail = approverId.getEmail();
						context.setVariable("approverName", approverName);
						context.setVariable("approverEmail", approverEmail);
					}
					if(infoTravel.getApproverId() != null) {
						
						Resource financeId = resourceController.findResource(infoTravel.getFinanceId());
						String financeName = financeId.getTitle();
						String financeEmail = financeId.getEmail();
						
						context.setVariable("financeName", financeName);
						context.setVariable("financeEmail", financeEmail);
					}
					
					context.setVariable("travelInternationReminder", "travelInternationReminder");
											
					
					template = "mail/infoTravelReminder";
					
					infoTravelUtil.send(fromEmail,toEmail, subject, template, context,ccEmails);	
				}
			}
			}
			
		
		}
		return true;
	}
	
	@Override
	public boolean sendInfoTravelAutoRejectionNotification()  throws MessagingException {
		logger.info("sendInfoTravelAutoRejectionNotification==================");
		List<InfoTravel> infoTravelList= infoTravelController.findInfoTravel(0, 0, false, false, false, false, 1, 0, null);
		
		//if user adds request for info travel
		String subject = "";
		String template = "";
		Context context = new Context();  
		String ccEmails = LoadConstant.TRAVEL_DESK;
		String fromEmail = LoadConstant.TRAVEL_DESK;
		String toEmail = "";
		String tourCode = "";
		//User
		for(InfoTravel infoTravel:infoTravelList) {
			if(infoTravel.getTourCode()!=null) {
				
				 tourCode = infoTravel.getTourCode();
			}
			if(infoTravel.getUid()!=null) {
				
				Resource resource = resourceController.findResource(infoTravel.getUid());
				String resourceEmail = resource.getEmail();
				String empName = resource.getTitle();
				Integer empId = resource.getEmpId();
				
				toEmail = resourceEmail; 
				
				context.setVariable("resourceEmail", resourceEmail);
				context.setVariable("empName", empName);			
				context.setVariable("empId", empId);
				logger.info("resourceEmail="+resourceEmail);
				
				subject = "Auto Rejection Mail | "+ tourCode +" | "+ empName; 
			

			if(infoTravel.getSubmittedDate() != null) {
				Date d1 = infoTravel.getSubmittedDate();
				Date d2 = new Date();
				
				//in milliseconds
				long diff = d2.getTime() - d1.getTime();
				long diffHours = diff / (60 * 60 * 1000) % 24;
				System.out.print(diffHours + " hours, ");
			
				if(tourCode != null && infoTravel.getSubmissionStatus().equals(1) && diffHours > 48){ 
				
					//database update
					infoTravel.setSubmissionStatus(5);
					Date date = new Date();
					infoTravel.setApprovalDate(date);
					infoTravelRepository.save(infoTravel);
					
					if(infoTravel.getApproverId() != null) {
						Resource approverId = resourceController.findResource(infoTravel.getApproverId());			
						String approverName = approverId.getTitle();
						String approverEmail = approverId.getEmail();
						
						
						
						context.setVariable("rejectionMail", "rejectionMail");
						context.setVariable("approverName", approverName);
						context.setVariable("approverEmail", approverEmail);
						
						
						ccEmails = ccEmails + "," + approverEmail; 
						
						
						template = "mail/infoTravelReminder";
						
						logger.info("ccEmails="+ccEmails);
						logger.info("approverEmail="+approverEmail);
						infoTravelUtil.send(fromEmail,toEmail, subject, template, context,ccEmails);
					}
					
				}
			}
			
			}
		
		}
		return true;
	}
	
	
	
	
	@Override
	public boolean sendBuspassDeleteNotification(Integer busPassId, Integer Uid, HttpServletRequest request)  throws MessagingException {

		Resource createdBy = null;

		String subject = "InfoBiz | Sow role delete";
		String template = "mail/buspassDelete";
		String fromEmail = LoadConstant.INFO_CABS;

        Context context = new Context();
        createdBy = resourceController.findResource(Uid);
        context.setVariable("busPassId",busPassId);
		if(createdBy != null)
		{
            context.setVariable("createdBy", createdBy.getTitle());
		}
		String ccEmails = LoadConstant.INFO_CABS;
		smtpMailSender.send(fromEmail,LoadConstant.INFO_CABS, subject, template, context,ccEmails, request);
		return true;
	}

	@Override
	public boolean sendSowDetailDeleteNotification(Integer sowDetailId, Integer Uid, HttpServletRequest request)  throws MessagingException {

		Resource createdBy = null;

		String subject = "InfoBiz | Sow role delete";
		String template = "mail/sowDelete";

        Context context = new Context();
        createdBy = resourceController.findResource(Uid);
        context.setVariable("sowId",sowDetailId);
		if(createdBy != null)
		{
            context.setVariable("createdBy", createdBy.getTitle());
		}
		String ccEmails = LoadConstant.AMG;
		smtpMailSender.send("",LoadConstant.PMO, subject, template, context,ccEmails, request);
		return true;
	}

    @Override
	public boolean sendTreqNotification(Treq treq, String actionType, HttpServletRequest request)  throws MessagingException {

        Resource resourcePm = null;
        Resource resourceDm = null;
		Resource createdBy = null;
		Resource updatedBy = null;
		String createdByEmail = null;
		Project project = null;
		Account account = null;
		AmgRoles amgRole = null;
		Grade grade = null;
		CmsDetail cmsDetail = null;
  	    SowDetail sowDetail = null;
  	    Skill skill = null;
	    Integer sowDetailId =0;
        String pmEmail = "";
        String dmEmail = "";
        String subject = "";
        String ccEmails = "";
        if(treq.getRequisitionType().equals("Replacement - Billable") || treq.getRequisitionType().equals("Replacement - Non Billable")){
    		subject = "InfoBiz | Replacement Treq";

        }else{
    		subject = "InfoBiz | New Treq";

        }
		String template = "mail/treqAdd";

        if(actionType == "update")
		{
			subject = "InfoBiz | Update Treq";
			template = "mail/treqUpdate";
		}

        Context context = new Context();
		if(treq !=null) {
			if(treq.getSowDetail()!=null){
				 if(treq.getSowDetail().getSowDetailId()!=null){
                     sowDetailId = treq.getSowDetail().getSowDetailId();
					 sowDetail = sowDetailRepository.findOne(sowDetailId);
				 }
			 }


            if(sowDetail !=null){
				project = projectController.getProject(sowDetail.getSow().getProjectId());
				if(project != null)
				{
					resourcePm = resourceController.findResource(project.getProjectManagersId());
					if(resourcePm != null)
					{
                        pmEmail = resourcePm.getEmail();
					}
					String projectName = project.getTitle();
					context.setVariable("projectName","account "+ projectName);
					subject = subject.concat(" |"+" SOW "+"| "+projectName);
				}
				if(treq.getSowDetail()!=null){
					

	                sowDetail = sowDetailRepository.findOne(treq.getSowDetail().getSowDetailId());
		             context.setVariable("Comment",sowDetail.getComments());
		             if(sowDetail.getRoleId()!=null){
	                     amgRole = amgRolesRepository.findOne(sowDetail.getRoleId());
	                     context.setVariable("amgRole", amgRole.getAmgRoleName());
		             }
		             if(sowDetail.getAssociateLevelId()!=null){
		            	 grade = gradeRepository.findOne(sowDetail.getAssociateLevelId());
	                     context.setVariable("grade", grade.getGrade());
		             }
	             
				}

            }else{
	             account = accountRepository.findOne(treq.getAccountId());
	             if(account!=null){
	               resourceDm = resourceController.findResource(account.getDmId());
	               dmEmail = resourceDm.getEmail();
	               String accountName = account.getTitle();
		           context.setVariable("accountName","account "+account.getTitle());
				   subject = subject.concat(" |"+" CM-S "+"| "+accountName);
	             }

	             if(treq.getCmsDetail()!=null){
	                cmsDetail = cmsDetailRepository.findOne(treq.getCmsDetail().getCmsDetailId());
	
	                if (cmsDetail != null) {
			             context.setVariable("Comment",cmsDetail.getComments());
			             if(cmsDetail.getRoleId()!=null){
	                         amgRole = amgRolesRepository.findOne(cmsDetail.getRoleId());
	                         context.setVariable("amgRole", amgRole.getAmgRoleName());
			             }
	
	                    if(cmsDetail.getAssociateLevelId()!=null){
			            	 grade = gradeRepository.findOne(cmsDetail.getAssociateLevelId());
	                        context.setVariable("grade", grade.getGrade());
			             }
		             }
	             }

            }


            createdBy = resourceController.findResource(treq.getCreatedBy());
			if(createdBy != null)
			{
                context.setVariable("createdBy", createdBy.getTitle());
                createdByEmail = createdBy.getEmail();

			}

            updatedBy = resourceController.findResource(treq.getModifiedBy());
			if(updatedBy != null)
			{
                context.setVariable("updatedBy", updatedBy.getTitle());
			}
			
			skill = skillRepository.findOne(treq.getSkillId());
			if(skill!=null){
				context.setVariable("Skill",skill.getSkillName());
			}
			context.setVariable("JobCode",treq.getTreqId());
			context.setVariable("Status",treq.getStatus());
			context.setVariable("Location",treq.getLocation());
			context.setVariable("startDate",DateConverter.changeDate2(treq.getReqStartDate()));
			context.setVariable("endDate",DateConverter.changeDate2(treq.getReqEndDate()));
			context.setVariable("comments",treq.getComments());


            context.setVariable("treqId", treq.getTreqId());
            if(treq.getStatus().equals("Hiring")) {
					
				if(createdByEmail != null)
				{
					ccEmails = createdByEmail+','+LoadConstant.AMG+','+LoadConstant.TALENT_ACQUISITION;
				}else{				
					ccEmails = LoadConstant.AMG+','+LoadConstant.TALENT_ACQUISITION;		
				}
			}else{
				
				if(createdByEmail != null)
				{
					ccEmails = createdByEmail+','+LoadConstant.AMG;
				}else{												
					ccEmails = LoadConstant.AMG;
				}
			}
		}
	

		 if(sowDetailId !=null && sowDetailId !=0){
				smtpMailSender.send("",pmEmail, subject, template, context,LoadConstant.AMG, request);
		 }else{

				smtpMailSender.send("",dmEmail, subject, template, context,ccEmails, request);
		 }
		return true;
	}

    @Override
	public boolean sendInvoiceNotification(Invoices invoice, String actionType, HttpServletRequest request)  throws MessagingException {

        Resource resourcePm = null;
        Resource resourceDm = null;
        Resource resourceAh = null;
		Resource createdBy = null;
		Resource updatedBy = null;
		Project project = null;
		Account account = null;
		String pmEmail = "";
        String dmEmail = "";
		String subject = "InfoBiz | New Invoice";
		String template = "mail/invoiceAdd";
		Integer accountId = null;
		String ccEmails = "";
		String ahEmail = "";
		
        if(actionType == "update")
		{
			subject = "InfoBiz | Update Invoice";
			template = "mail/invoiceUpdate";
		}

        // create a new context
        Context context = new Context();
		if(invoice !=null) {
			project = projectController.getProject(invoice.getProjectId());
			if(project != null)
			{
				resourcePm = resourceController.findResource(project.getProjectManagersId());
				if(resourcePm != null)
				{
                    pmEmail = resourcePm.getEmail();
				}

                account = accountRepository.findOne(project.getAccountId());
				if(account != null)
				{
					resourceDm = resourceController.findResource(account.getDmId());
					if(resourceDm != null)
					{
                        dmEmail = resourceDm.getEmail();
					}
					accountId = account.getItemId();
					
					
					if(account.getAhId() != null) {
					resourceAh = resourceController.findResource(account.getAhId());
						if(resourceAh != null)
						{
		                    ahEmail = resourceAh.getEmail();
						}
					}
					
				}

                String projectName = project.getTitle();
				context.setVariable("projectName", projectName);
				subject = subject.concat(" | "+projectName);
			}
			
			if(invoice.getCreatedBy()!=null) {
	            createdBy = resourceController.findResource(invoice.getCreatedBy());
	            
	            if(createdBy != null)
				{
	                context.setVariable("createdBy", createdBy.getTitle());
				}
			}
			
			if(invoice.getModifiedBy()!=null) {
	            updatedBy = resourceController.findResource(invoice.getModifiedBy());
				if(updatedBy != null)
				{
	                context.setVariable("updatedBy", updatedBy.getTitle());
				}
			}
			
			if(invoice.getInvoiceStatus()!=null) {
				if(invoice.getInvoiceStatus().equals("Approved")){
	                context.setVariable("approveReject", "approved");
				}
				if(invoice.getInvoiceStatus().equals("Rejected")){
	                context.setVariable("approveReject", "rejected");
				}
			}

			if(invoice.getInvoiceNo()!=null) {
				context.setVariable("draftId",invoice.getInvoiceNo());	
			}
			if(invoice.getFinalInvoiceNo()!=null) {
				context.setVariable("finalInvoiceId",invoice.getFinalInvoiceNo());	
			}
			if(invoice.getPeriodStartDate()!=null) {
				context.setVariable("month",DateConverter.monthAndYearFromDate(invoice.getPeriodStartDate()));				
			}
			
			if(invoice.getInvoiceStatus()!=null) {
				context.setVariable("approvedRejected",invoice.getInvoiceStatus());				
			}


		}

		// shri - added check to don't send email to DM for Internal account
		
		if (accountId != null) {
			if ("Internal".equals(account.getStrategic())) {
				ccEmails = LoadConstant.INVOICES;
			} else {
				if (dmEmail != null && ahEmail != null) {
					ccEmails = dmEmail + ',' +ahEmail + ',' + LoadConstant.INVOICES;
				}else if(dmEmail != null) {
					ccEmails = dmEmail + ',' + LoadConstant.INVOICES;						
				} else {
					ccEmails = LoadConstant.INVOICES;
				}
			}		
		}
		

		smtpMailSender.send("",pmEmail, subject, template, context, ccEmails, request);
		return true;
	}

    @Override
public boolean sendProjectNotification(Project project, String actionType, HttpServletRequest request)  throws MessagingException {

        Resource resourcePm = null;
        Resource resourceDm = null;
		Resource createdBy = null;
		Resource updatedBy = null;
		Account account = null;
		String ccEmails = "";
		String pmEmail = "";
        String dmEmail = "";
		String subject = "InfoBiz | Initiate Project";
		String template = "mail/projectInitiate";

        if(actionType == "update")
		{
			subject = "InfoBiz | Project Update";
			template = "mail/projectCreate";
		}

        // create a new context
        Context context = new Context();
		if(project !=null) {
			project = projectController.getProject(project.getItemId());
			if(project != null)
			{
				resourcePm = resourceController.findResource(project.getProjectManagersId());
				if(resourcePm != null)
				{
                    pmEmail = resourcePm.getEmail();
				}

                account = accountRepository.findOne(project.getAccountId());

				if(account != null)
				{
					String accountName = account.getTitle();
					context.setVariable("accountName", accountName);
					resourceDm = resourceController.findResource(account.getDmId());
					if(resourceDm != null)
					{
                        dmEmail = resourceDm.getEmail();
					}

				}

                String projectName = project.getTitle();
				context.setVariable("projectName", projectName);
				subject = subject.concat(" | "+projectName);
			}

            createdBy = resourceController.findResource(project.getCreatedBy());
			if(createdBy != null)
			{
                context.setVariable("createdBy", createdBy.getTitle());
			}

            updatedBy = resourceController.findResource(project.getModifiedBy());
			if(updatedBy != null)
			{
                context.setVariable("updatedBy", updatedBy.getTitle());
			}
            context.setVariable("requestId", project.getItemId());
            context.setVariable("status", project.getState());

			//context.setVariable("sowId",sow.getSowNo());

		}
		if(actionType == "update")
		{
			if(dmEmail != null)
			{
				ccEmails = dmEmail+','+LoadConstant.PMO+','+LoadConstant.IBS_TEAM;
			}else{
				ccEmails = LoadConstant.PMO+','+LoadConstant.IBS_TEAM;
			}
		}else{
			if(dmEmail != null)
			{
				ccEmails = dmEmail+','+LoadConstant.PMO;
			}else{
				ccEmails = LoadConstant.PMO;
			}
		}

		smtpMailSender.send("",pmEmail, subject, template, context, ccEmails, request);
		return true;
	}


    public boolean sendTaskAssignmentNotification(ProjectTask taskinfo, List<String> resourceMailIds,
			HttpServletRequest request) throws MessagingException {

        String pmEmail = null;
		Resource updatedBy = null;
		Integer projectID = taskinfo.getProjectId();
		String[] plannersId= null;
		Project project = null;
		String ccEmails = "";
		String toEmails = "";
		String subject = "";
        String template = "mail/taskAssign";

		subject = "InfoBiz | New Task Assigned";


        for(String resourceId : resourceMailIds){
			if(!StringUtils.isEmpty(resourceId.trim())){
                toEmails = toEmails.concat(resourceController.getEmailByUid(Integer.parseInt(resourceId)) + ",");
			}
		}

		Context context = new Context();
		if (taskinfo != null) {
			project = projectController.getProject(projectID);
			if (project != null) {
                pmEmail = resourceController.getEmailByUid(project.getProjectManagersId());
                if (pmEmail != null) {
                    ccEmails = ccEmails.concat(pmEmail);
				}
				context.setVariable("projectName", project.getTitle());
				subject = subject.concat(" | " + project.getTitle());
			}
			context.setVariable("taskTitle", taskinfo.getTitle());
			context.setVariable("projectName", project.getTitle());
		}

		smtpMailSender.send("",toEmails, subject, template, context, ccEmails, request);
		return true;
	}
	
    
    @Override
	public boolean sendSkillNotification(Skill skill, String actionType, HttpServletRequest request)  throws MessagingException {

		Resource createdBy = null;
		String subject = "InfoBiz | New Skill Requested";
		String template = "mail/skillAdd";
		Coe coe = null;
		Resource coeResource = null;
		String ccEmails = LoadConstant.AMG+','+LoadConstant.TALENT_ACQUISITION;
		String coeEmail = "";
		String link="";
		
		// create a new context
        Context context = new Context();
		if(skill !=null) {
			context.setVariable("skillName", skill.getSkillName());
			createdBy = resourceController.findResource(skill.getCreatedBy());
		
			coe = CoeRepository.findOne(skill.getCoeId());
			if(coe!=null) {
				coeResource = resourceController.findResource(coe.getOwnerId());
				
				coeEmail = coeResource.getEmail();
			
			}
			
			if(createdBy != null)
			{
                context.setVariable("createdBy", createdBy.getTitle());
			}
			
			 String skillUrl = "https://"+request.getServerName()+"/masters/skill/#/?skillId="+skill.getSkillId();
			
            link = "<a href="+skillUrl+"><span>Approve/Reject</span></a>";
            context.setVariable("link", link);
			
		}
		
		if(coeEmail !=null) {
			smtpMailSender.send("",coeEmail, subject, template, context,ccEmails, request);
		}
		else{
			smtpMailSender.send("",LoadConstant.S_DIXIT, subject, template, context,ccEmails, request);
		}
		
		return true;
	}
    
    @Override
	public boolean sendCityNotification(City city, String actionType, HttpServletRequest request)  throws MessagingException {

		Resource createdBy = null;
		String subject = "InfoBiz | New City Added";
		String template = "mail/cityAdd";

        // create a new context
        Context context = new Context();
		if(city !=null) {
			context.setVariable("cityName", city.getCityName());
			createdBy = resourceController.findResource(city.getCreatedBy());
			if(createdBy != null)
			{
                context.setVariable("createdBy", createdBy.getTitle());
			}
		}
		
		String ccEmails = LoadConstant.TALENT_ACQUISITION;
		smtpMailSender.send("",LoadConstant.AMG, subject, template, context,ccEmails, request);
		return true;
	}
    
    
    
    @Override
	public boolean sendCountryNotification(Country country, String actionType, HttpServletRequest request) throws MessagingException{

		Resource createdBy = null;
		String subject = "InfoBiz | New Country Added";
		String template = "mail/countryAdd";

        // create a new context
        Context context = new Context();
		if(country !=null) {
			context.setVariable("countryName", country.getCountryName());
			createdBy = resourceController.findResource(country.getCreatedBy());
			if(createdBy != null)
			{
                context.setVariable("createdBy", createdBy.getTitle());
			}
		}
		String ccEmails = LoadConstant.TALENT_ACQUISITION;
		smtpMailSender.send("",LoadConstant.AMG, subject, template, context,ccEmails, request);
		return true;
	}
    
    
    @Override
	public boolean sendCurrencyNotification(Currency currency, String actionType, HttpServletRequest request) throws MessagingException{

		Resource createdBy = null;
		String subject = "InfoBiz | New Currency Added";
		String template = "mail/currencyAdd";

        // create a new context
        Context context = new Context();
		if(currency !=null) {
			context.setVariable("currencyName", currency.getName());
			createdBy = resourceController.findResource(currency.getCreatedBy());
			if(createdBy != null)
			{
                context.setVariable("createdBy", createdBy.getTitle());
			}
		}
		String ccEmails = LoadConstant.TALENT_ACQUISITION;
		smtpMailSender.send("",LoadConstant.AMG, subject, template, context,ccEmails, request);
		return true;
	}
    
    
	@Override
	public boolean sendDeNotification(DeGovernance deGovernance, String actionType,String isPhDe, HttpServletRequest request)  throws MessagingException {

        Resource resourcePm = null;
        Resource resourcePh = null;
        Resource resourceAh = null;        

		Project project =null;
		String ccEmails = "";
		String pmEmail = "";
        String phEmail = "";
        String ahEmail = "";        
        
		String subject = "InfoBiz | Delivery Excellance";
		String template = "mail/deNotesAddUpdate";

        Context context = new Context();
        
		resourcePm = resourceController.findResource(deGovernance.getPmId());
		if(resourcePm != null)
		{
            pmEmail = resourcePm.getEmail();
    		context.setVariable("matricName", resourcePm.getTitle());            
		}
		

		if(isPhDe.equals("DE")) {
            context.setVariable("createdBy", "DE Team");    
			context.setVariable("notes", deGovernance.getNotesByDE());	
		}
		
		//		commenting this code because of the PH ID issue		
			resourcePh = resourceController.findResource(deGovernance.getPortfolioHeadId());
			if(resourcePh != null)
			{
	            phEmail = resourcePh.getEmail();            
	    		if(isPhDe.equals("PH")) {
		            context.setVariable("createdBy", resourcePh.getTitle());    
					context.setVariable("notes", deGovernance.getNotesByPH());			
	    		}
			}			

		
		// 		commenting this code because of the ah ID issue		
		resourceAh = resourceController.findResource(deGovernance.getAccountHeadId());
		if(resourceAh != null)
		{
            ahEmail = resourceAh.getEmail();            
		}
		
		project = projectController.getProject(deGovernance.getProjectId());
		if (project != null) {
            pmEmail = resourceController.getEmailByUid(project.getProjectManagersId());
			context.setVariable("projectName", "for "+project.getTitle());
			subject = subject.concat(" | " + project.getTitle());
			
		}
		
		if(ahEmail !=null) {						
			ccEmails = ahEmail;						
		}												
		if(phEmail !=null) {						
			ccEmails = ccEmails.concat(","+phEmail);
		}
		ccEmails = ccEmails.concat(','+LoadConstant.DEG);

		smtpMailSender.send("",pmEmail, subject, template, context,ccEmails, request);
		return true;
	}

	
	@SuppressWarnings("null")
	@Override
	public boolean sendDeNoteNotification(DEGovernanceNotes deGovernanceNotes, HttpServletRequest request)  throws MessagingException {

        Resource resourcePh = null;
        ArrayList<Portfolio> portfolio = new ArrayList<Portfolio>();
		String ccEmails = "";
		String phEmail = "";
		
		String subject = "InfoBiz | Delivery Excellance";
		String template = "mail/deNotesAddUpdate";

        Context context = new Context();
        
        if(deGovernanceNotes.getPortfolioId() != null){
        	        	
        if(deGovernanceNotes.getPortfolioId() != 0) {
            portfolio.add(portfolioRepository.findOne(deGovernanceNotes.getPortfolioId()));
        }else{
            portfolio = (ArrayList<Portfolio>) portfolioRepository.findAll();        	
        }

        if (portfolio.size() > 0)
		{	

			for (Portfolio port : portfolio) {
				
	        	if(portfolio.size() == 1) {
		            context.setVariable("projectName",port.getTitle());
	        	}else {
		            context.setVariable("projectName","All Portfolios");        		
	        	}
	        	
	            resourcePh = resourceController.findResource(port.getOwnerId());
	            if(resourcePh != null)
	    		{	                
		        	 if(phEmail!="") {
		        		 phEmail = phEmail+","+resourcePh.getEmail();   			        		 
		        	 }else {
		        		 phEmail = resourcePh.getEmail(); 	        		 
		        	 }	                
	    		}
			}
		}

		context.setVariable("deNotes", deGovernanceNotes.getDeComments());
        
        }
		
        ccEmails = LoadConstant.A_JOSHI+','+LoadConstant.DEG;
        
		smtpMailSender.send("",phEmail, subject, template, context,ccEmails, request);
		return true;
	}
	
	@Override
	public boolean sendActionTrakerNotification(ActionItem actionItem, String actionType, HttpServletRequest request)  throws MessagingException {

        Portfolio portfolio = null;
        Project project = null;

		String ccEmails = "";
		String assineeEmail = "";
		String projectTitle = "";
		String subject = "InfoBiz | Delivery Excellance";
		String template = "mail/deActionTraker";
		Resource assineeId= null;
		Resource createdBy= null;
        Context context = new Context();        
        	
			createdBy = resourceController.findResource(actionItem.getCreatedBy());
			
			if(createdBy != null) {
				context.setVariable("Creator",createdBy.getTitle());									
			}
			
			if(actionItem.getName()!=null) {
				context.setVariable("actionIteam",actionItem.getName());						
			}
			
			if(actionItem.getComments()!=null) {
				context.setVariable("comments",actionItem.getComments());						
			}
			
			if(actionItem.getProposedDate()!=null) {
				context.setVariable("proposedDate",actionItem.getComments());										
			}
			
			if(actionItem.getProjectId()!=null) {
				
				project = projectController.getProject(actionItem.getProjectId());
				
				if(project!=null) {
					projectTitle = project.getTitle();
					context.setVariable("projectTitle",projectTitle);									
				}
				
			}
	        
	        
	        String line = actionItem.getAssignedTo();
	        String[] parts = line.split(",");
	        int[] ints = new int[parts.length];
	        for (int i = 0; i < parts.length; i++) {
	             ints[i] = Integer.parseInt(parts[i]);
	 	       	 assineeId = resourceController.findResource(ints[i]);
		    	 if(assineeId != null)
		    		{
		        	 if(assineeEmail!="") {
			        		assineeEmail = assineeEmail+","+assineeId.getEmail();   			        		 
		        	 }else {
			        		assineeEmail = assineeId.getEmail(); 	        		 
		        	 }
		    		}    
		    }
        

		smtpMailSender.send("",assineeEmail, subject, template, context,ccEmails, request);
		return true;
	}

	
	@Override
	public boolean isG5AndAboveGrade(){
		Boolean retVal=false;
		Integer uid=(Integer)session.getAttribute("loggedInUid");
		List<ResourceRoles> resourceRoles=resourceRolesRepository.findResourceRoles(uid);
		
		ArrayList<String> roles = new ArrayList<String>();
		  
		roles.add("ADMIN");
		roles.add("PMO");
		
		Integer o= Integer.valueOf(session.getAttribute("grade").toString());
		
		if(o >= 5){
			retVal = true;
		}
	
		for (ResourceRoles role : resourceRoles) // If ADMIN or PMO
		{
			if(roles.contains(role.getRoles().getRole())){
				retVal = true;
			}
		}
		return retVal;
	}
	
	@Override
	public boolean sendExitFormNotification(ExitForm exitForm, String actionType, HttpServletRequest request) throws MessagingException {

        Resource resource = null;
        Resource resourcePm = null;        
        Resource resourceDm = null;
		Resource createdBy = null;
		Resource updatedBy = null;
		Project project = null;
		Account account = null;
		String resourceEmail = "";
		String pmEmail = "";
        String dmEmail = "";
		String subject = "InfoBiz | Exit form submission";
		String template = "mail/exitForm";

        // create a new context
        Context context = new Context();
			//project = projectController.getProject(sow.getProjectId());
			if(exitForm != null)
			{
				resource = resourceController.findResource(exitForm.getuId());
				if(resource != null)
				{
					resourceEmail = resource.getEmail();
					context.setVariable("createdBy", resource.getTitle());

					resourcePm = resourceController.findResource(resource.getReportingManagerId());
					if(resourcePm != null)
					{
	                    pmEmail = resourcePm.getEmail();
					}
				}

            }
			
		
		String ccEmails = LoadConstant.BPHR;
		smtpMailSender.send("",resourceEmail, subject, template, context,ccEmails, request);
		return true;
	}
	
@Override
	public boolean sendISowNotification(ISow ISow, HttpServletRequest request)  throws MessagingException {

		Resource user = null;
		Project project = null;
		String subject = "InfoBiz | ISow";
		String template = "mail/isowAdd";
		String text = "";
		String projectName = "";
		String ursename = "";
		String isowNo = "";
		String toEmails = "";
		String ccEmails = "";
        // create a new context
        Context context = new Context();
		if(ISow !=null) {
			isowNo = ISow.getIsowNo().toString();
			project = projectController.getProject(ISow.getProjectId());
			if(project != null)
			{
                projectName = project.getTitle();
				subject = subject.concat(" | "+projectName);
            }

			if("Pending Approval".equals(ISow.getStatus()) || "Draft".equals(ISow.getStatus())) {
                
				if("Draft".equals(ISow.getStatus())) {
					user = resourceController.findResource(ISow.getCreatedBy());
					if(user != null) {
						ursename = user.getTitle();
						text = ursename+" has created a new ISOW (No - "+isowNo+" ) for project "+projectName;						
					}
					context.setVariable("textMessage", text);
				}else{
					user = resourceController.findResource(ISow.getModifiedBy());
					if(user !=null) {
						ursename = user.getTitle();
						text = ursename+" has submitted the ISOW (No - "+isowNo+" ) for project "+projectName;					
					}
					context.setVariable("textMessage", text);
				}
				toEmails =LoadConstant.V_GOUR+','+LoadConstant.G_TALATULE;
				ccEmails = LoadConstant.PMO;
			}else{
				user = resourceController.findResource(ISow.getModifiedBy());
				if(user !=null) {
					ursename = user.getTitle();
					if("Approved".equals(ISow.getStatus())) {
						text = ursename+" has approved the ISOW (No - "+isowNo+" ) for project "+projectName;					
						context.setVariable("textMessage", text);
					}else {
						text = ursename+" has rejected the ISOW (No - "+isowNo+" ) for project "+projectName;											
						context.setVariable("textMessage", text);
					}
				}
				toEmails = LoadConstant.PMO;
				ccEmails =LoadConstant.V_GOUR+','+LoadConstant.G_TALATULE;
			}
			smtpMailSender.send("",toEmails, subject, template, context,ccEmails, request);
		}
		

		return true;
	}
	
	@Override
	public boolean sendActionTrackerNotification(HttpServletRequest request) throws MessagingException {

        String assineeEmail = "";
		String subject = "InfoBiz | Action Tracker Notification";
		String template = "mail/actionTrackerReminderNotifications";
		
		Resource assineeId= null;
        Context context = new Context();
    	String status = "IN PROGRESS";
        List<ActionItem> actionItem = actionItemRepository.findByStatus(status);
        
        for(ActionItem item : actionItem){
	        String line = item.getAssignedTo();
	        String[] parts = line.split(",");
	        int[] ints = new int[parts.length];
	        
	        if(item.getProjectId() !=null && item.getProjectId() !=0) {
		        Project proj = projectRepository.getOne(item.getProjectId());
				if(proj != null)
				{
					subject = subject.concat(" | " + proj.getTitle());
					context.setVariable("projectTitle", proj.getTitle());
				}	        	
	        }
			
			context.setVariable("actionIteam", item.getName());
			context.setVariable("dueDate", DateConverter.changeDate2(item.getProposedDate()));
			context.setVariable("comments", item.getComments());
	        
	        for (int i = 0; i < parts.length; i++) {
	             ints[i] = Integer.parseInt(parts[i]);
	 	       	 assineeId = resourceController.findResource(ints[i]);
		    	 if(assineeId != null){
			        	 if(assineeEmail!=""){
				        		assineeEmail = assineeEmail+","+assineeId.getEmail();   			        		 
			        	 }else{
				        		assineeEmail = assineeId.getEmail(); 	        		 
			        	 }
		    		}    
	        }
	 		String ccEmails = "";
			smtpMailSender.send("",assineeEmail, subject, template, context,ccEmails, request);

        }


		
		return true;
	}
	

    @Override
public boolean sendAppreciationNotification(DeAppreciation deAppreciaton, String actionType, HttpServletRequest request)  throws MessagingException {

        Resource resourcePm = null;
        Resource resourceDm = null;
		Resource createdBy = null;
        Resource resourceAh = null;

		Project project = null;
		Account account = null;

		String ccEmails = "";
		String toEmail = "";
		String pmEmail = "";
        String dmEmail = "";
        String ahEmail = "";
        String subject = "InfoBiz | Appreciation";
		String template = "mail/appreciation";
		String createdByEmail = "";
		String url = "";

        if(actionType == "update")
		{
			subject = "InfoBiz | Appreciation Approved";
		}

        // create a new context
        Context context = new Context();
		if(deAppreciaton !=null) {
			
			if(deAppreciaton.getProjectId()!=null) {
				project = projectController.getProject(deAppreciaton.getProjectId());				
			}
			
			if(project != null)
			{
				resourcePm = resourceController.findResource(project.getProjectManagersId());
				if(resourcePm != null)
				{
                    pmEmail = resourcePm.getEmail();
				}
				
				
				
                account = accountRepository.findOne(project.getAccountId());
               
				if(account != null)
				{
					resourceDm = resourceController.findResource(account.getDmId());
					if(resourceDm != null)
					{
                        dmEmail = resourceDm.getEmail();
					}
					
					if(account.getAhId() != null) {
					resourceAh = resourceController.findResource(account.getAhId());
					if(resourceAh != null)
					{
	                    ahEmail = resourceAh.getEmail();
					}
					}
				}
                String projectName = project.getTitle();
				context.setVariable("projectName", projectName);
				subject = subject.concat(" | "+projectName);
			}
			
			if(deAppreciaton.getCreatedBy()!=null) {
		        
				if(actionType == "update")
				{
					createdBy = resourceController.findResource(deAppreciaton.getModifiedBy());		        	
				}else{
					createdBy = resourceController.findResource(deAppreciaton.getCreatedBy());					
				}
				
	            if(createdBy != null)
				{
		            context.setVariable("createdBy", createdBy.getTitle());
		            createdByEmail =  createdBy.getEmail();
				}				
			}
			
            context.setVariable("month", DateConverter.monthAndYearFromDate(deAppreciaton.getMonth()));
            context.setVariable("appreciationTo", deAppreciaton.getAppreciationTo());

// 			  download link on mail code
//            if(deAppreciaton.getFilepath()!=null) {
//            	url = "<a href='https://infobiz.infocepts.com/deappreciation/download/"+deAppreciaton.getAppreciationId()+">Download File</a>";
//                context.setVariable("download", url);
//            }
            
    		if(actionType == "update")
    		{
                context.setVariable("action","approved" );
        		toEmail = createdByEmail;
        		if(dmEmail !=null) {						
					ccEmails = dmEmail+','+LoadConstant.PMO+','+LoadConstant.DEG;		
				}else{
					ccEmails = LoadConstant.PMO+','+LoadConstant.DEG;
				}
    		}else if(actionType == "delete"){
    			
    			 context.setVariable("action", "deleted");
    			 if(dmEmail !=null) {						
 					ccEmails = dmEmail+','+LoadConstant.PMO+','+LoadConstant.DEG;		
 				}else{
 					ccEmails = LoadConstant.PMO+','+LoadConstant.DEG;
 				} 
    			 
    		}else{
                context.setVariable("action","added" );
    			toEmail = LoadConstant.PMO;
    			if(dmEmail !=null) {						
					ccEmails = dmEmail;						
				}
    			if(createdByEmail !=null) {						
					ccEmails = ccEmails.concat(","+createdByEmail);
				}
    			ccEmails = ccEmails.concat(',' + LoadConstant.PMO +','+LoadConstant.DEG);
    		}
    		
    		smtpMailSender.send("",toEmail, subject, template, context, ccEmails, request);
    		
		}
		

		return true;
	}
    
    
    
    @Override
    public boolean sendComplaintNotification(DeComplaint deComplaint, String actionType, HttpServletRequest request)  throws MessagingException {

        Resource resourcePm = null;
        Resource resourceDm = null;
		Resource createdBy = null;
        Resource resourceAh = null;

		Project project = null;
		Account account = null;

		String ccEmails = "";
		String toEmail = "";
		String pmEmail = "";
        String dmEmail = "";
		String ahEmail = "";
		String subject = "InfoBiz | Complaint";
		String template = "mail/complaint";
		String createdByEmail = "";
		String url = "";

        // create a new context
        Context context = new Context();
        
		if(deComplaint !=null) {

            if(actionType == "add") {
	            context.setVariable("action", "submitted ");
			}else if(actionType == "delete") {
	            context.setVariable("action", "deleted ");
			}
			if(deComplaint.getProjectId()!=null) {
				project = projectController.getProject(deComplaint.getProjectId());				
			}
			
			if(project != null)
			{
				resourcePm = resourceController.findResource(project.getProjectManagersId());
				if(resourcePm != null)
				{
                    pmEmail = resourcePm.getEmail();
				}
				

							
                account = accountRepository.findOne(project.getAccountId());
				if(account != null)
				{
					resourceDm = resourceController.findResource(account.getDmId());
					if(resourceDm != null)
					{
                        dmEmail = resourceDm.getEmail();
					}
					
					if(account.getAhId() != null) {
					resourceAh = resourceController.findResource(account.getAhId());
					if(resourceAh != null)
					{
	                    ahEmail = resourceAh.getEmail();
					}
					}
				}
				
                String projectName = project.getTitle();
				context.setVariable("projectName", projectName);
				subject = subject.concat(" | "+projectName);
			}
			
			if(deComplaint.getCreatedBy()!=null) {		     
					
				createdBy = resourceController.findResource(deComplaint.getCreatedBy());					
				
	            if(createdBy != null)
				{
		            context.setVariable("createdBy", createdBy.getTitle());
		            createdByEmail =  createdBy.getEmail();
				}				
			}
			
            context.setVariable("month", DateConverter.monthAndYearFromDate(deComplaint.getMonth()));
            context.setVariable("complaintTo", deComplaint.getComplaintTo());

// 			  download link on mail code
//            if(deAppreciaton.getFilepath()!=null) {
//            	url = "<a href='https://infobiz.infocepts.com/deappreciation/download/"+deAppreciaton.getAppreciationId()+">Download File</a>";
//                context.setVariable("download", url);
//            }

       		toEmail = LoadConstant.PMO;
       		if(pmEmail !=null) {						
				ccEmails = pmEmail;						
			}												
			if(ahEmail !=null) {						
				ccEmails = ccEmails.concat(","+ahEmail);
			}							
			if(dmEmail !=null) {						
				ccEmails = ccEmails.concat(","+dmEmail);						
			}
			if(createdByEmail !=null) {						
				ccEmails = ccEmails.concat(","+createdByEmail);						
			}
            ccEmails = ccEmails.concat(',' + LoadConstant.DEG);

    		smtpMailSender.send("",toEmail, subject, template, context, ccEmails, request);
		}

		return true;
	}
	
    
    @Override
    public boolean sendDeValueAddNotification(DeValueAdd deValueAdd, String actionType, HttpServletRequest request)  throws MessagingException {

        Resource resourcePm = null;
        Resource resourceDm = null;
		Resource createdBy = null;
        Resource resourceAh = null;

		Project project = null;
		Account account = null;

		String ccEmails = "";
		String toEmail = "";
		String pmEmail = "";
        String dmEmail = "";
        String ahEmail = "";

		String subject = "InfoBiz | Value Add";
		String template = "mail/valueAdd";
		String createdByEmail = "";

        // create a new context
        Context context = new Context();
        
		if(deValueAdd !=null) {
			
			if(actionType == "add") {
	            context.setVariable("action", "submitted ");
			}else if(actionType == "delete") {
	            context.setVariable("action", "deleted ");
			}
			
			if(deValueAdd.getProjectId()!=null) {
				project = projectController.getProject(deValueAdd.getProjectId());				
			}
			
			if(project != null)
			{
				resourcePm = resourceController.findResource(project.getProjectManagersId());
				if(resourcePm != null)
				{
                    pmEmail = resourcePm.getEmail();
				}
				
                account = accountRepository.findOne(project.getAccountId());
				if(account != null)
				{
					resourceDm = resourceController.findResource(account.getDmId());
					if(resourceDm != null)
					{
                        dmEmail = resourceDm.getEmail();
					}
					
					if(account.getAhId() != null) {
					resourceAh = resourceController.findResource(account.getAhId());
					if(resourceAh != null)
					{
	                    ahEmail = resourceAh.getEmail();
					}
					}
					
				}
				
                String projectName = project.getTitle();
				context.setVariable("projectName", projectName);
				subject = subject.concat(" | "+projectName);
			}
			
			if(deValueAdd.getCreatedBy()!=null) {
				createdBy = resourceController.findResource(deValueAdd.getCreatedBy());					
	            if(createdBy != null)
				{
		            context.setVariable("createdBy", createdBy.getTitle());
		            createdByEmail =  createdBy.getEmail();
				}				
			}
			
            context.setVariable("month", DateConverter.monthAndYearFromDate(deValueAdd.getMonth()));
            context.setVariable("valueAddCreatedBy", deValueAdd.getValueAddsPointOfContact());
    		
       		toEmail = LoadConstant.PMO;
       		if(pmEmail !=null) {						
				ccEmails = pmEmail;						
			}												
			if(ahEmail !=null) {						
				ccEmails = ccEmails.concat(","+ahEmail);
			}							
			if(dmEmail !=null) {						
				ccEmails = ccEmails.concat(","+dmEmail);						
			}
			if(createdByEmail !=null) {						
				ccEmails = ccEmails.concat(","+createdByEmail);						
			}
            ccEmails = ccEmails.concat(',' + LoadConstant.DEG);

    		smtpMailSender.send("",toEmail, subject, template, context, ccEmails, request);
		}


		return true;
	}
    
    
    @Override
    public boolean sendMsrNotification(DeMsr deMsr, String actionType, HttpServletRequest request)  throws MessagingException {

        Resource resourcePm = null;
        Resource resourceDm = null;
        Resource resourceAh = null;
		Resource createdBy = null;
		Project project = null;
		Account account = null;

		String ccEmails = "";
		String toEmail = "";
		String pmEmail = "";
        String dmEmail = "";
        String ahEmail = "";
		String subject = "InfoBiz | MSR";
		String template = "mail/msr";
		String createdByEmail = "";

        // create a new context
        Context context = new Context();
        
		if(deMsr !=null) {
			
			if(actionType == "add") {
	            context.setVariable("action", "submitted ");
			}else if(actionType == "delete") {
	            context.setVariable("action", "deleted ");
			}
			
			if(deMsr.getProjectId()!=null) {
				project = projectController.getProject(deMsr.getProjectId());				
			}
			
			if(project != null)
			{
				resourcePm = resourceController.findResource(project.getProjectManagersId());
				if(resourcePm != null)
				{
                    pmEmail = resourcePm.getEmail();
				}
								
				
				
                account = accountRepository.findOne(project.getAccountId());
				if(account != null)
				{
					resourceDm = resourceController.findResource(account.getDmId());
					if(resourceDm != null)
					{
                        dmEmail = resourceDm.getEmail();
					}
					
					if(account.getAhId() != null) {
					resourceAh = resourceController.findResource(account.getAhId());
					if(resourceAh != null)
					{
	                    ahEmail = resourceAh.getEmail();
					}
					}
				}
				
                String projectName = project.getTitle();
				context.setVariable("projectName", projectName);
				subject = subject.concat(" | "+projectName);
			}
			
			if(deMsr.getCreatedBy()!=null) {
				createdBy = resourceController.findResource(deMsr.getCreatedBy());					
	            if(createdBy != null)
				{
		            context.setVariable("createdBy", createdBy.getTitle());
		            createdByEmail =  createdBy.getEmail();
				}				
			}
			
            context.setVariable("month", DateConverter.monthAndYearFromDate(deMsr.getDeMsrMonth()));
    		
    		
    		toEmail = LoadConstant.PMO;
    		if(ahEmail !=null) {						
				ccEmails = ahEmail;						
			}													
			if(pmEmail !=null) {						
				ccEmails = ccEmails.concat(","+pmEmail);
			}								
			if(dmEmail !=null) {						
				ccEmails = ccEmails.concat(","+dmEmail);						
			}
			if(createdByEmail !=null) {						
				ccEmails = ccEmails.concat(","+createdByEmail);						
			}
            ccEmails = ccEmails.concat(',' + LoadConstant.DEG);

    		smtpMailSender.send("",toEmail, subject, template, context, ccEmails, request);
		}

		return true;
	}
    
    @Override
    public boolean sendWsrNotification(DeWsr deWsr, String actionType, HttpServletRequest request)  throws MessagingException {

        Resource resourcePm = null;
        Resource resourceDm = null;
		Resource createdBy = null;
		Resource modifiedBy = null;
        Resource resourceAh = null;

		Project project = null;
		Account account = null;

		String ccEmails = "";
		String toEmail = "";
		String pmEmail = "";
        String dmEmail = "";
        String ahEmail = "";
		String subject = "InfoBiz | WSR";
		String template = "mail/wsr";
		String cuByEmail = "";

        // create a new context
        Context context = new Context();
        
		if(deWsr !=null) {
			if(deWsr.getProjectId()!=null) {
				project = projectController.getProject(deWsr.getProjectId());				
			}
			
			if(project != null)
			{
				resourcePm = resourceController.findResource(project.getProjectManagersId());
				if(resourcePm != null)
				{
                    pmEmail = resourcePm.getEmail();
				}

				
				
                account = accountRepository.findOne(project.getAccountId());
				if(account != null)
				{
					resourceDm = resourceController.findResource(account.getDmId());
					if(resourceDm != null)
					{
                        dmEmail = resourceDm.getEmail();
					}
					
					if(account.getAhId() != null) {
					resourceAh = resourceController.findResource(account.getAhId());
					if(resourceAh != null)
					{
	                    ahEmail = resourceAh.getEmail();
					}
					}
				}
				
                String projectName = project.getTitle();
				context.setVariable("projectName", projectName);
				subject = subject.concat(" | "+projectName);
			}

		   	 if(actionType == "add")
				{
					if(deWsr.getCreatedBy()!=null) {
						createdBy = resourceController.findResource(deWsr.getCreatedBy());					
			            if(createdBy != null)
						{
				            context.setVariable("user", createdBy.getTitle());
				            cuByEmail =  createdBy.getEmail();
						}				
					}
		   		 
				}else{
					if(deWsr.getModifiedBy()!=null) {
						modifiedBy = resourceController.findResource(deWsr.getModifiedBy());					
			            if(modifiedBy != null)
						{
				            context.setVariable("user", modifiedBy.getTitle());
				            cuByEmail =  modifiedBy.getEmail();
						}				
					}					
				}
			
			
            context.setVariable("month", DateConverter.monthAndYearFromDate(deWsr.getDeWsrMonth()));
			
            toEmail = LoadConstant.PMO;
            if(ahEmail !=null) {						
				ccEmails = ahEmail;						
			}													
			if(pmEmail !=null) {						
				ccEmails = ccEmails.concat(","+pmEmail);
			}								
			if(dmEmail !=null) {						
				ccEmails = ccEmails.concat(","+dmEmail);						
			}
			if(cuByEmail !=null) {						
				ccEmails = ccEmails.concat(","+cuByEmail);						
			}
            ccEmails = ccEmails.concat(',' + LoadConstant.DEG);

		smtpMailSender.send("",toEmail, subject, template, context, ccEmails, request);         
		}
		

		return true;
	}
    
    @Override
   	public boolean sendSurveyNotification(Survey survey, String actionType, HttpServletRequest request)  throws MessagingException {

   		Resource createdBy = null;
   		Resource updatedBy = null;
   		String subject = "InfoBiz | New Survey";
   		String template = "mail/surveyAdd";
   		String ccEmails = null;
   		String eligibleFor = null;
   		
   	 if(actionType == "update")
		{
			subject = "InfoBiz | Update Survey";
			template = "mail/surveyUpdate";
		}
   		
           // create a new context
           Context context = new Context();
   		if(survey !=null) {
   			
   			context.setVariable("surveyName", survey.getTitle());
   			createdBy = resourceController.findResource(survey.getCreatedBy());
   			if(createdBy != null)
   			{
                   context.setVariable("createdBy", createdBy.getTitle());
   			}
   			
   			updatedBy = resourceController.findResource(survey.getModifiedBy());
   			if(updatedBy != null)
   			{
                   context.setVariable("updatedBy", updatedBy.getTitle());
   			}
   			
   			if(survey.geteligibleForSurvey() == 0)
   			{
   				eligibleFor ="None";
   				context.setVariable("eligiblrForSurvey",eligibleFor);
   			}else {
   				context.setVariable("eligiblrForSurvey",survey.geteligibleForSurvey());
   			}
   			
			context.setVariable("status",survey.getStatus());
			context.setVariable("url",survey.getUrl());
			context.setVariable("surveyStartDate",DateConverter.changeDate2(survey.getSurveyStartDate()));
			context.setVariable("surveyEndDate",DateConverter.changeDate2(survey.getSurveyEndDate()));
   			
   		}
   		
   		ccEmails = LoadConstant.INFOBIZ;
   		smtpMailSender.send("",LoadConstant.INFOBIZ, subject, template, context,ccEmails, request);
   		return true;
   	}
    	@Override
	public boolean sendSurveyReminderNotifications()  throws MessagingException {		

	    Date date = new Date();  
	    DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");  
	    String currentDate= formatter.format(date);
	    String startDate = "";
	    String endDate = "";
	    Boolean isSurveyEligiable = false;
	    String link = "";
        Context context = new Context();
	    String ccEmails = "";
		String toEmail = "";
		String subject = "";
		String from = "";
		String assineeEmail = "";
   		List<Resource> resourceList = null;
		String template = "mail/surveyReminderNotifications";
		List<TargetAudience> targetAudienceList = null;
		List<Survey> surveyList=null;
		surveyList = surveyController.findAllSurvey("Active");
		
		for(Survey survey:surveyList) 
		{
			startDate = formatter.format(survey.getSurveyStartDate());
			endDate = formatter.format(survey.getSurveyEndDate());
			assineeEmail = "";
			if(currentDate.compareTo(startDate) >= 0 && currentDate.compareTo(endDate) <= 0) 
			{	
				if(survey.getEmailNotification().equals("Yes")) {
					isSurveyEligiable = true;						
				}
			}
			
			

			if(isSurveyEligiable)
			{
				if(survey.getEmailSubject()!=null) {
					subject = survey.getEmailSubject();					
				}
				
				if(survey.getEmailHeader()!=null) {
		            context.setVariable("header", survey.getEmailHeader());
				}

				if(survey.getUrl()!=null) {
					link = "<a href="+survey.getUrl()+"><span>Link</span></a>";
		            context.setVariable("link", link);
				}

				if(survey.getFromEmail()!=null) {
		            from = survey.getFromEmail();
				}else {
					from = LoadConstant.INFOBIZ;
				}
				
				if(survey.getDescription()!=null) {
		            context.setVariable("description", survey.getDescription());
				}
				
				if(survey.getEmailNote()!=null) {
		            context.setVariable("note", survey.getEmailNote());
				}
				
				if(survey.getEmailSignature()!=null) {
		            context.setVariable("signature", survey.getEmailSignature());
				}

				if(survey.getTitle()!=null) {
		            context.setVariable("surveyName", survey.getTitle());
				}
				
				if(survey.getSurveyId()!=null) {
					
					// fetch the target audience for 30, 60 and 90 days 
					if(survey.geteligibleForSurvey() == 30 ||survey.geteligibleForSurvey() == 60 || survey.geteligibleForSurvey() == 90) {
												
						resourceList = resourceController.findResources(0, "all", 0, "", "", false, 0, 0, "0", 0, 0, 0, false, "", survey.geteligibleForSurvey());

						for(Resource item : resourceList){
							// 1-30 days survey, 2-60 days survey, 3-90 days survey							
								if(item.getEmail()!=null) {
						        	 if(assineeEmail!=""){
							        		assineeEmail = assineeEmail+","+item.getEmail();   			        		 
						        	 }else{
							        		assineeEmail = item.getEmail(); 	        		 
						        	 }
								}
						}
					}else{
						targetAudienceList= targetAudienceRepository.findTargetAudienceBySurveyId(survey.getSurveyId());
						for(TargetAudience item : targetAudienceList){
							if(item.getSurveyId()==null) {
								if(item.getEmployeeEmail()!=null) {
						        	 if(assineeEmail!=""){
							        		assineeEmail = assineeEmail+","+item.getEmployeeEmail();   			        		 
						        	 }else{
							        		assineeEmail = item.getEmployeeEmail(); 	        		 
						        	 }								
								}	
							}
						}				
					}
				}
				
			    System.out.println(assineeEmail+" Resource Email id");										
				toEmail = assineeEmail;
				ccEmails = LoadConstant.HR_OPERATIONS;
				infoTravelUtil.send(from,toEmail, subject, template, context,ccEmails);				
			}
				
		}

		return true;
				
    	}
    
    
    	@Override
    	public boolean sendExitAccessNotification(ExitAccess exitAccess, String actionType, HttpServletRequest request) throws MessagingException {

            Resource resource = null;
    		String resourceEmail = "";
    		String subject = "InfoBiz | Exit Access";
    		String template = "mail/exitAccess";

            // Create a new context
            Context context = new Context();
    			if(exitAccess != null)
    			{
    				resource = resourceController.findResource(exitAccess.getuId());
    				if(resource != null)
    				{
    					resourceEmail = resource.getEmail();
    					context.setVariable("createdBy", resource.getTitle());
    				}
                }
    		
    		String ccEmails = LoadConstant.BPHR;
    		smtpMailSender.send("",resourceEmail, subject, template, context,ccEmails, request);
    		return true;
    	}
    	
    
}
