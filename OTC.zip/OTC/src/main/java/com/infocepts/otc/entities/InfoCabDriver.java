package com.infocepts.otc.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.infocepts.otc.utilities.LoadConstant;

@Entity
@Table(catalog=LoadConstant.otc, schema="[dbo]",name="infocabdriver")
public class InfoCabDriver {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer infoCabDriverId;
	private String driverName;
	private String driverMobile;
	
	
	public Integer getInfoCabDriverId() {
		return infoCabDriverId;
	}
	public void setInfoCabDriverId(Integer infoCabDriverId) {
		this.infoCabDriverId = infoCabDriverId;
	}
	public String getDriverName() {
		return driverName;
	}
	public void setDriverName(String driverName) {
		this.driverName = driverName;
	}
	public String getDriverMobile() {
		return driverMobile;
	}
	public void setDriverMobile(String driverMobile) {
		this.driverMobile = driverMobile;
	}
	
	
}
