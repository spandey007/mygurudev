package com.infocepts.otc.controllers;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.infocepts.otc.entities.InfoCab;
import com.infocepts.otc.entities.InfoCabVehicle;
import com.infocepts.otc.repositories.InfoCabVehicleRepository;
import com.infocepts.otc.services.TimesheetService;

@RestController
@RequestMapping(value="/infocabvehicle",headers="referer")
public class InfoCabVehicleController {
	
	final Logger logger = Logger.getLogger(InfoCabVehicleController.class.getName());
	
	@Autowired
	InfoCabVehicleRepository infoCabVehicleRepository;
	
	@Autowired
	TimesheetService service;
	
	@RequestMapping(method=RequestMethod.POST)
	public InfoCabVehicle addInfoCabVehicle(@RequestBody InfoCabVehicle infoCabVehicle){
		infoCabVehicle.setInfoCabVehicleId(null);
		Boolean isAValidCall = false;
		if(service.isTravel())
		{
			isAValidCall = true;
		}
		if(isAValidCall) {
			
			infoCabVehicleRepository.save(infoCabVehicle);
		}
		return infoCabVehicle;
	}
	
	@RequestMapping(method=RequestMethod.GET)
	public List<InfoCabVehicle> getInfoCabVehicle(){
		List<InfoCabVehicle> list = null;
		Boolean isAValidCall = false;
		if(service.isTravel())
		{
			isAValidCall = true;
		}
		//if(isAValidCall) {
			list = infoCabVehicleRepository.findAll();
		//}
		return list;
	}
	
	@RequestMapping(value="/{infoCabVehicleId}",method=RequestMethod.GET)
	public InfoCabVehicle getInfoCabVehicle(@PathVariable Integer infoCabVehicleId){
		InfoCabVehicle infoCabVehicle = null;
		Boolean isAValidCall = false;
		if(service.isTravel())
		{
			isAValidCall = true;
		}
		if(isAValidCall) {
			
			infoCabVehicle = infoCabVehicleRepository.findOne(infoCabVehicleId);
		}
		return infoCabVehicle;
	}
	
	@RequestMapping(value="/{infoCabVehicleId}", method=RequestMethod.PUT)
	public InfoCabVehicle updateInfoCabVehicle(@PathVariable Integer infoCabVehicleId,  @RequestBody InfoCabVehicle updatedInfoCabVehicle){
		updatedInfoCabVehicle.setInfoCabVehicleId(infoCabVehicleId);
		Boolean isAValidCall = false;
		if(service.isTravel())
		{
			isAValidCall = true;
		}
		if(isAValidCall) {
		infoCabVehicleRepository.save(updatedInfoCabVehicle);
		}
		return updatedInfoCabVehicle;
	}
	
	@RequestMapping(value="/{infoCabVehicleId}",method=RequestMethod.DELETE)
	public void deleteInfoCabVehicle(@PathVariable Integer infoCabVehicleId){
		Boolean isAValidCall = false;
		if(service.isTravel())
		{
			isAValidCall = true;
		}
		if(isAValidCall) {
		infoCabVehicleRepository.delete(infoCabVehicleId);
		}
	}
	
	@GetMapping("/getCabVehicle")
    public Object getCabVehicle(HttpServletRequest request){        
		List<InfoCabVehicle> list = null;
        try{
        	list = infoCabVehicleRepository.findAll();
        }catch(Exception e){
        	logger.log(Level.SEVERE, "exceptn msg", e);
        }
        return list;
    }
	
	
	@GetMapping("/getVehicleById")
	public Object getVehicleById(@RequestParam(value = "infoCabVehicleId", defaultValue = "0") Integer infoCabVehicleId,
									  HttpServletRequest request){
		InfoCabVehicle infoCabVehicle = null;
		try{
			infoCabVehicle = infoCabVehicleRepository.findOne(infoCabVehicleId);
		}catch(Exception e){
			logger.log(Level.SEVERE, "exceptn msg", e);
		}
		return infoCabVehicle;
	}
	
}

