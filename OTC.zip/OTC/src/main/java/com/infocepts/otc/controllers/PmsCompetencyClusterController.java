/**
* Filename: /src/main/java/com/infocepts/otc/controllers/PmsCompetencyClusterController.java
* @author  SRA
* @version 1.0
* @since   2018-08-01 
*/

package com.infocepts.otc.controllers;

import java.util.logging.Logger;
import com.infocepts.pms.entities.PmsCompetencyCluster;
import com.infocepts.pms.entities.PmsDepartmentMapping;
import com.infocepts.pms.entities.PmsGradeMapping;
import com.infocepts.pms.repositories.PmsCompetencyClusterRepository;
import com.infocepts.pms.repositories.PmsDepartmentMappingRepository;
import com.infocepts.pms.repositories.PmsGradeMappingRepository;
import com.infocepts.otc.services.TimesheetService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.mail.MessagingException;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;


import java.util.List;

@RestController
@RequestMapping(value="/api/pms/competencyCluster", headers="referer")
public class PmsCompetencyClusterController {

    final Logger logger = Logger.getLogger(PmsCompetencyClusterController.class.getName());

    @Autowired
    PmsCompetencyClusterRepository repository;
    
    @Autowired
    PmsGradeMappingRepository gradeMappingRepository;
    
    @Autowired
    PmsDepartmentMappingRepository departmentMappingRepository;
    
    
    @Autowired
    HttpSession session;

    @PersistenceContext(unitName = "pms") 
    private EntityManager manager;
			
	@Autowired
	TimesheetService service;

	/**
   * This method is used to find results set from module entity
   * based on params passed from JS file
   */
    @RequestMapping(method = RequestMethod.GET)
    public List<PmsCompetencyCluster> findAllPmsCompetencyCluster(@RequestParam(value = "status", defaultValue = "2") String status //1:Active, 0: In Active, 2:All
            						,@RequestParam(value = "byUserGradeAndDepartment", defaultValue = "false") Boolean byUserGradeAndDepartment
            						,@RequestParam(value = "param3", defaultValue = "false") Boolean param3
									//,@RequestParam(value = "param4", defaultValue = "") Date param4
									//,@RequestParam(value = "param5", defaultValue = "") BigDecimal param5
            						,HttpServletRequest request){
        List<PmsCompetencyCluster> PmsCompetencyClusterList = null;

        
        logger.info("--------------------in <PmsCompetencyCluster> controller------------------");		
		logger.info("param2=");
		logger.info("param3="+param3);
		
        try {
        	/* ------------------------- Authorization start ------------------------------------ */
			// Authorization for XYZ role
			/*if(!service.isAdmin() && !service.isHRPms()) // isXYZ() needs implementation in declaration  in TimesheetService Class & implementation in TimesheetServiceImpl Class
			{
				service.sendTamperedMail("<PmsCompetencyCluster> view all", 0, 0, request);
				return PmsCompetencyClusterList;
			}*/
			/* ------------------------- Authorization ends ------------------------------------ */
			
			Integer uid=(Integer)session.getAttribute("loggedInUid");
			
			if(byUserGradeAndDepartment){
				PmsCompetencyClusterList = manager.createNamedQuery("getAllCompetencyClusterByUser", PmsCompetencyCluster.class)
        				.setParameter("uid", uid)
                        .getResultList();
			}
			else if (!status.equals("")) {
			
        		//option 1 to get PmsCompetencyClusterList using namedQuery		
        		PmsCompetencyClusterList = manager.createNamedQuery("getAllCompetencyCluster", PmsCompetencyCluster.class)
        				.setParameter("status", status)
                        .getResultList();
        					
        	} else {
			
        		//option 2 to get PmsCompetencyClusterList using repository functions		
				PmsCompetencyClusterList = repository.findAll();
			}
			
         } 
		catch (Exception e){
			 logger.info(String.format("exception - ", e));
        }
        return PmsCompetencyClusterList;

    }
    
    /**
     * This method is add row in PmsCompetencyCluster entity
     * 
     */
    @RequestMapping(method=RequestMethod.POST)
	public PmsCompetencyCluster addPmsCompetencyCluster(@RequestBody PmsCompetencyCluster PmsCompetencyCluster, HttpServletRequest request) throws MessagingException {
		// Authorization for XYZ role
    	if(service.isHRPms() || service.isHRPmsAdmin())
		{
			List<PmsGradeMapping> gradeMapping = PmsCompetencyCluster.getGradeMapping();
			List<PmsDepartmentMapping> departmentMapping = PmsCompetencyCluster.getDepartmentMapping();
			
			try{
				PmsCompetencyCluster.setCompetencyClusterId(null);
				repository.save(PmsCompetencyCluster);
				
				//Save the mapping tables
				
				//Set the id in mapping list
				for (PmsGradeMapping pmsGradeMapping : gradeMapping) {
					pmsGradeMapping.setTypeId(PmsCompetencyCluster.getCompetencyClusterId());
				}
				
				gradeMappingRepository.save(gradeMapping);
				
				//Set the id in mapping list
				for (PmsDepartmentMapping pmsDepartmentMapping : departmentMapping) {
					pmsDepartmentMapping.setTypeId(PmsCompetencyCluster.getCompetencyClusterId());
				}
				
				departmentMappingRepository.save(departmentMapping);
				
			}
			catch(Exception e){
				 logger.info(String.format("exception - ", e));
			}
		}
		else 
		{
			service.sendTamperedMail("PmsCompetencyCluster Save", 0, 0, request);
		}
		
		return PmsCompetencyCluster;
	}
    
    /**
     * This method is update row in PmsCompetencyCluster entity
     * based on primaryKey Of Module Table 
     */
     @RequestMapping(value="/{competencyClusterId}",method=RequestMethod.PUT)
	 public PmsCompetencyCluster updatePmsCompetencyCluster(@RequestBody PmsCompetencyCluster updatedPmsCompetencyCluster,@PathVariable Integer competencyClusterId,HttpServletRequest request) throws MessagingException{
        // Authorization for XYZ role
    	 if(service.isHRPms() || service.isHRPmsAdmin())
		{	
			List<PmsGradeMapping> gradeMapping = updatedPmsCompetencyCluster.getGradeMapping();
			List<PmsDepartmentMapping> departmentMapping = updatedPmsCompetencyCluster.getDepartmentMapping();
			
			try{
				 updatedPmsCompetencyCluster.setCompetencyClusterId(competencyClusterId);
				 repository.save(updatedPmsCompetencyCluster);
				 
				//Delete the existing mapping
				gradeMappingRepository.deleteGradeMapping(competencyClusterId , 1);
				
				gradeMappingRepository.save(gradeMapping);
				
				//Delete the existing mapping
				departmentMappingRepository.deleteDepartmentMapping(competencyClusterId, 1);
				
				departmentMappingRepository.save(departmentMapping);
			}
			catch(Exception e){
				 logger.info(String.format("exception - ", e));
			}
		}
		else
		{
			service.sendTamperedMail("<PmsCompetencyCluster> Save", 0, 0, request);
		}
		 return updatedPmsCompetencyCluster;
	 }
    
    /**
     * This method is get data for specific row in PmsCompetencyCluster entity
     * based on primaryKey Of Module Table 
     */
    @RequestMapping(value="/{competencyClusterId}",method=RequestMethod.GET)
	 public PmsCompetencyCluster getPmsCompetencyCluster(@PathVariable Integer competencyClusterId, HttpServletRequest request) throws MessagingException{
    	
    	PmsCompetencyCluster PmsCompetencyCluster = null;
		// Authorization for XYZ role
    	
    		
			try{
				 PmsCompetencyCluster = manager.createNamedQuery("getCompetencyClusterById", PmsCompetencyCluster.class)
						 .setParameter("competencyClusterId", competencyClusterId)
						 .getSingleResult();
				 
				//Get Grade mapping
				 List<PmsGradeMapping> gradeMapping = gradeMappingRepository.findByTypeId(competencyClusterId, 1);
				 
				 //Set Grade mapping
				 PmsCompetencyCluster.setGradeMapping(gradeMapping);
				 
				 //Get Department mapping
				 List<PmsDepartmentMapping> departmentMapping = departmentMappingRepository.findByTypeId(competencyClusterId, 1);
				 
				 //Set Department mapping
				 PmsCompetencyCluster.setDepartmentMapping(departmentMapping);
				 
			 }
			 catch(Exception e){
				 logger.info(String.format("exception - ", e));
			 }
		
		 
		 return PmsCompetencyCluster;
	 }
	 
    
    /**
     * This method is delete data for specific row in PmsCompetencyCluster entity
     * based on primaryKey Of Module Table 
     */	 
	@RequestMapping(value="/{competencyClusterId}",method=RequestMethod.DELETE)
	public void deletePmsCompetencyCluster(@PathVariable Integer competencyClusterId, HttpServletRequest request)  throws MessagingException {
		// Authorization for XYZ role
		if(service.isHRPms() || service.isHRPmsAdmin())
		{
			try{
			repository.delete(competencyClusterId);
			}
			catch(Exception e){
				 logger.info(String.format("exception - ", e));
			}
		}
		else
		{
			service.sendTamperedMail("<PmsCompetencyCluster> Delete", 0, 0, request);
		}		 
	}
	
  
   
}
