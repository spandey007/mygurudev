package com.infocepts.otc.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.infocepts.otc.entities.ExitForm;

public interface ExitFormRepository extends CrudRepository<ExitForm,Integer> {

	@Override
	public List<ExitForm> findAll();

//	@Query("select p from exitForm p where p.empId=:exitFormId")
//	public List<ExitForm> findByExitFormId(@Param("exitFormId") Integer exitFormId);
	
	@Query("from ExitForm p where p.uId=:uid")
	public List<ExitForm> findByUid(@Param("uid") Integer uid);
	
}
