package com.infocepts.otc.controllers;

import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.infocepts.otc.entities.TermCondition;
import com.infocepts.otc.repositories.TermConditionRepository;
import com.infocepts.otc.services.TimesheetService;


@RestController
@RequestMapping(value="/termcondition",headers="referer")
public class TermConditionController {
	
	final Logger logger = Logger.getLogger(TermConditionController.class);

	@Autowired
	TermConditionRepository repository;
	
	@Autowired
	TimesheetService service;
	
	@RequestMapping(method=RequestMethod.POST)
	public TermCondition addTermCondition(@RequestBody TermCondition termcondition)
	{
		try{
			if(service.isAR()){
				termcondition.setTermId(null);
				repository.save(termcondition);	
			}
		}catch(Exception e){
			logger.error(e);
		}
		return termcondition;
	}	
 
	 @RequestMapping(method=RequestMethod.GET)
	 public List<TermCondition> getAllTermCondition(){
		 List<TermCondition> termconditionlist=null;
		 try{
			 if(service.isAR()){
				 termconditionlist = repository.findAll();
			 }
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return termconditionlist;
	 }
	 
	 @RequestMapping(value="/{termId}",method=RequestMethod.GET)
	 public List<TermCondition> getTermById(@PathVariable Integer termId){
		 
		 List<TermCondition> term=null;
		 try{		
			 if(service.isAR()){
				 term = repository.findByTermId(termId);
			 }
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return term;
	 }
	
	 
	 @RequestMapping(value="/{termId}",method=RequestMethod.PUT)
	 public TermCondition updateTermCondition(@RequestBody TermCondition updatedTermCondition,@PathVariable Integer termId){
		 try{
			 if(service.isAR()){
				 updatedTermCondition.setTermId(termId);
				 repository.save(updatedTermCondition);
			 }
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return updatedTermCondition;
	 }
	 
	 @RequestMapping(value="/{termId}",method=RequestMethod.DELETE)
	 public void deleteTermCondition(@PathVariable Integer termId){
		 try{
			 if(service.isAR()){
				 repository.delete(termId);
			 }
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
	 }
	 
	 @GetMapping("/getTerms")
		public List<TermCondition> getTerms() {
		 List<TermCondition> termconditionlist=null;
		 try{
			 if(service.isAR()){
				 termconditionlist = repository.findAll();
			 }
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return termconditionlist;

		}
}
