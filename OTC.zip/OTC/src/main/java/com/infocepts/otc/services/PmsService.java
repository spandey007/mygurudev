package com.infocepts.otc.services;

import java.util.Dictionary;
import java.util.HashMap;

import javax.mail.MessagingException;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Service;

import com.infocepts.pms.entities.PmsCycle;
import com.infocepts.pms.entities.PmsIldp;
import com.infocepts.pms.entities.PmsPerformance;


@Service
public interface PmsService {

	//To delete all gradeMapping for a particular goalCluster 
	public void DeleteGradeMapping(Integer goalClusterId);
	
	//To delete all departmentMapping for a particular goalCluster 
	public void DeleteDepartmentMapping(Integer goalClusterId);
	
	//To get the user type [Associate/Manager/Reviewer] and Phase[Handshake/Pit-Stop/Evaluation]
	public HashMap<String, String> getUserTypeAndPhase(Integer performanceId,Integer uid);
	
	public boolean sendPMSNotification(PmsPerformance pmsPerformanceList, String phase, HttpServletRequest request)	throws MessagingException;
	public boolean sendCycleNotification(PmsCycle updatedPmsCycle, String action, HttpServletRequest request)	throws MessagingException;
	
	public boolean sendIldpNotification(PmsIldp updatedPmsIldp, String action, HttpServletRequest request)	throws MessagingException;

}
