package com.infocepts.otc.repositories;

import java.util.List;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import com.infocepts.otc.entities.ActionItem;



public interface ActionItemRepository extends CrudRepository<ActionItem, Integer>{
	
	@Override
	public List<ActionItem> findAll();
	
	@Query("from ActionItem where assignedTo like %:assignedTo% ")
	public List<ActionItem> findByAssignedTo(@Param("assignedTo") String assignedTo);

	@Query("from ActionItem where portfolioId=:portfolioId")
	public List<ActionItem> findByPortfolioId(@Param("portfolioId") Integer portfolioId);
	
	@Query("from ActionItem where projectId=:projectId")
	public List<ActionItem> findByProjectId(@Param("projectId") Integer projectId);
	
	@Query("from ActionItem where status like %:status% ")
	public List<ActionItem> findByStatus(@Param("status") String status);

	@Query("from ActionItem where portfolioId=:portfolioId and projectId=:projectId")
	public List<ActionItem> findByPortfolioIdAndProjectId(@Param("portfolioId") Integer portfolioId,@Param("projectId") Integer projectId);
	
	@Query("from ActionItem where portfolioId=:portfolioId and projectId=:projectId and status like %:status%")
	public List<ActionItem> findByPortfolioIdAndProjectIdAndStatus(@Param("portfolioId") Integer portfolioId,@Param("projectId") Integer projectId,@Param("status") String status);
	
	
	
	

}
