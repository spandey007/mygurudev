package com.infocepts.otc.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.infocepts.otc.entities.Reports;

public interface ReportsRepository extends CrudRepository<Reports,Integer> {

	@Override
	public List<Reports> findAll();
	
	@Query("from Reports r where r.section=:section")
	public List<Reports> findBySection(@Param("section") Integer section);
	
	//@Query("select Reports r from Reports r where ((r.roleAccess like :roleAccess) or (r.roleAccess like concat('%,',:roleAccess,',%')) or (r.roleAccess like concat(:roleAccess,',%'))or (r.roleAccess like concat('%,',:roleAccess)))")
	@Query("from Reports r where ((r.roleAccess like :roleAccess) or (r.roleAccess like concat('%,',:roleAccess,',%')) or (r.roleAccess like concat(:roleAccess,',%'))or (r.roleAccess like concat('%,',:roleAccess)))")
	public List<Reports> findReportsByRoleAccess(@Param("roleAccess") String roleAccess);
}
