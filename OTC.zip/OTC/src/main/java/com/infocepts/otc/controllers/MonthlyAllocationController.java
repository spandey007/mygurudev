package com.infocepts.otc.controllers;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.infocepts.otc.entities.MonthlyAllocation;
import com.infocepts.otc.repositories.MonthlyAllocationRepository;



@RestController
@RequestMapping(value="/monthlyallocation",headers="referer")//JV: Added 'headers' param to validate the url.
public class MonthlyAllocationController {
	
	final Logger logger = Logger.getLogger(MonthlyAllocationController.class);

	@Autowired
	MonthlyAllocationRepository repository;
	
	@PersistenceContext(unitName="otc")
    private EntityManager manager;
	
	@RequestMapping(method=RequestMethod.POST)
	public MonthlyAllocation addMonthlyAllocation(@RequestBody MonthlyAllocation newallocation) {
		try{
			newallocation.setMonthlyAlcId(null);
			repository.save(newallocation);
		}
		catch(Exception e){
			logger.error(e);
		}
		return newallocation;
	}

	@RequestMapping(method=RequestMethod.GET)
	 public List<MonthlyAllocation> getAllMonthlyAllocation(@RequestParam(value = "projectId", defaultValue = "0") Integer projectId,
			 							      @RequestParam(value = "allocationType", defaultValue = "") String allocationType){
		List<MonthlyAllocation> allocationlist=null;
		try{
		 	if(projectId == 0){
		 		allocationlist = manager.createNamedQuery("getAllMonthlyAllocation", MonthlyAllocation.class)
					     .getResultList();
		 	}
		 	else{
		 		Integer alcType = 1;
		 		if(allocationType.equals("billable")) alcType = 1; 
		 		if(allocationType.equals("billable-buffer")) alcType = 4;
		 		if(allocationType.equals("non-billable-buffer")) alcType = 2;
		 		if(allocationType.equals("non-billable-trainee")) alcType = 3;
		 		if(allocationType.equals("non-billable")) alcType = 20;// unreal alcType value to fetch all NB allocation types ie(2,3)

		 		
		 		allocationlist = manager.createNamedQuery("getMonthlyAllocationsForProject", MonthlyAllocation.class)
						 .setParameter("projectId", projectId)
						 .setParameter("alcType", alcType)
						 .getResultList();
		 	}
		 	
	 }
	 catch(Exception e){
		 logger.error(e);
	 }
		return allocationlist;
	 }
	 
	 @RequestMapping(value="/{monthlyAlcId}",method=RequestMethod.GET)
	 public MonthlyAllocation getMonthlyAllocation(@PathVariable Integer monthlyAlcId){	
		 MonthlyAllocation allocation = null;
		 try{
			 allocation = manager.createNamedQuery("getMonthlyAllocationById", MonthlyAllocation.class)
					 .setParameter("monthlyAlcId", monthlyAlcId)
	                 .getSingleResult();
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return allocation;
	 } 	
	 
	 @RequestMapping(value="/{monthlyAlcId}",method=RequestMethod.PUT)
	 public MonthlyAllocation updateMonthlyAllocation(@RequestBody MonthlyAllocation updatedAllocation,@PathVariable Integer monthlyAlcId){
		 try{
			 updatedAllocation.setMonthlyAlcId(monthlyAlcId);
			 repository.save(updatedAllocation);
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return updatedAllocation;
	 }
	 
	 @RequestMapping(value="/{monthlyAlcId}",method=RequestMethod.DELETE)
	 public void deleteMonthlyAllocation(@PathVariable Integer monthlyAlcId){
		 try{
			  repository.delete(monthlyAlcId);
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
	 }
}

