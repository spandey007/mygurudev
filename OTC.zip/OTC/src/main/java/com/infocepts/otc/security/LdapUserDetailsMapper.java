package com.infocepts.otc.security;

import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.ListIterator;
import java.util.Set;

import javax.naming.directory.Attributes;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.math.NumberUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.ldap.core.DirContextAdapter;
import org.springframework.ldap.core.DirContextOperations;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.ldap.userdetails.UserDetailsContextMapper;
import org.springframework.stereotype.Component;

import com.infocepts.otc.entities.Grade;
import com.infocepts.otc.entities.Resource;
import com.infocepts.otc.entities.ResourceRoles;
import com.infocepts.otc.repositories.ResourceRepository;
import com.infocepts.otc.repositories.ResourceRolesRepository;

import java.util.logging.Logger;



@Component
public class LdapUserDetailsMapper implements UserDetailsContextMapper{

	final Logger logger = Logger.getLogger(LdapUserDetailsMapper.class.getName());
	
	@Autowired
	HttpSession session;
	
	@Autowired
	ResourceRolesRepository resourceRolesrepository;
	
	@Autowired
	ResourceRepository repository;
	
	@Value("${spring.mstr.url}")
	private String mstrurl;
	
	@Value("${spring.host.url}")
	private String infobizhost;
	
	@Value("${spring.mstr.baseURL}")
	private String mstrBaseURL;
	
	@Value("${spring.http.multipart.max-file-size}")
	private String maxFileUploadSize;
	
	@Autowired
	HttpServletRequest request;
	
	
	public LdapUserDetailsMapper() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public UserDetails mapUserFromContext(DirContextOperations ctx, String username,
											Collection<? extends GrantedAuthority> authorities) {
		Set<GrantedAuthority> authority = new HashSet<GrantedAuthority>();
		Attributes attributes = ctx.getAttributes();
	    Object[] groups = new Object[100];
	    groups = ctx.getObjectAttributes("memberOf");
	  
	    String role_prefix = "ROLE_";
	    
	    //Retrieve the user object from the username
	    User userDetails = getUserRoles(username, authority, role_prefix);
	    
	    return userDetails;
	}

	private User getUserRoles(String username, Set<GrantedAuthority> authority, String role_prefix) {
		
		Resource resource = repository.findResourceByUsername(username);
	    Integer uid = resource.getUid();
	    String resourceName = resource.getTitle();
	    String grade = "";
	    Grade gradeObj = resource.getGrade();
	    if(gradeObj != null) grade = gradeObj.getGradeNo();
	    

	    logger.info("Username: "+username);
	    logger.info("Uid: "+uid);
	    logger.info("Resource Name: "+resourceName);
	    logger.info("Grade: "+grade);
	  
	    List<ResourceRoles> resourcesRoles = resourceRolesrepository.findResourceRoles(uid);
	    
	    // Setting the logged in user details in session
	    session.setAttribute("username", username);
	    session.setAttribute("loggedInUid", uid);
	    session.setAttribute("loggedInName", resourceName);
	    session.setAttribute("grade", grade);
	    session.setAttribute("mstrurl", mstrurl); //JV sets the mstr url in the session
	    session.setAttribute("infobizhost", infobizhost); // JV sets the host name of the current environment
	    // Base URL required to construct the MSTR web service URL in client side. [File : /reports/reports.js]
	    session.setAttribute("mstrBaseURL", mstrBaseURL);
	    /* This parameter is used to define the maximum size allowed for a file upload.
	     * As of now, It is specifically used to check the size of SOW document.
	    */
	    long sizeInBytes = NumberUtils.toInt(maxFileUploadSize.replace("MB", "")) * 1024 * 1024;
	    session.setAttribute("maxFileUploadSize", sizeInBytes);
	    
	    
	    if(resource.getDisabled()==false){
	    	authority.add(new SimpleGrantedAuthority("ROLE_MEMBER"));
	    }
	    
	    String userRoles = "";
	    if(resourcesRoles != null)
	    {  
	    	ListIterator<ResourceRoles> roleList = resourcesRoles.listIterator();
			while(roleList.hasNext()){
				ResourceRoles resRole = (ResourceRoles)roleList.next();	    	
	    		String role = role_prefix.concat(resRole.getRoles().getRole());	  
	    		if(userRoles.equals(""))
    			{
	    			userRoles = role;
    			}
	    		else
	    		{
	    			userRoles = userRoles + ',' + role;
	    		}
	    		authority.add(new SimpleGrantedAuthority(role));
	    	}
	    }
	    session.setAttribute("userRoles", userRoles);

	    User userDetails = new User(username, "", false, false, false, false, authority);
	    logger.info("UserDetails are:"+userDetails);
	    
	    //Code to impersonate other user | It checks if the user role is admin and username is provided for impersonation
	    if(userRoles.contains("ADMIN") && request != null)
	    {
	    	username = request.getParameter("errorText");
	    	if(!username.equals(""))
	    	{
	    		getUserRoles(username,authority,role_prefix);
	    		logger.info("Ejaz:"+username);
	    		return userDetails;
	    	}
	    }
	    //End of: Code to impersonate other user | It checks if the user role is admin and username is provided for impersonation
	    
		return userDetails;
	}
	
	@Override
	public void mapUserToContext(UserDetails arg0, DirContextAdapter arg1) {
		// TODO Auto-generated method stub
		
	}

}
