package com.infocepts.otc.controllers;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.math.NumberUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.infocepts.otc.entities.HolidaySchedules;
import com.infocepts.otc.entities.Resource;
import com.infocepts.otc.repositories.HolidaySchedulesRepository;
import com.infocepts.otc.repositories.ResourceRepository;
import com.infocepts.otc.services.TimesheetService;



@RestController
@RequestMapping(value="/resource",headers="referer")//JV: Added 'headers' param to validate the url.
public class ResourceController {

    final Logger logger = Logger.getLogger(ResourceController.class);

    @Autowired
    ResourceRepository repository;
    
    @Autowired
    HolidaySchedulesRepository holidaySchedulesRepository;
    
    @Autowired
    HttpSession session;
    @Autowired
    TimesheetService service;
    @PersistenceContext(unitName = "otc")
    private EntityManager manager;

    @RequestMapping(method = RequestMethod.GET)
    public List<Resource> findResources(@RequestParam(value = "limit", defaultValue = "0") Integer limit,
                                        @RequestParam(value = "status", defaultValue = "all") String status,
                                        @RequestParam(value = "tsDelegateId", defaultValue = "0") Integer tsDelegateId,
                                        @RequestParam(value = "name", defaultValue = "") String name,
										@RequestParam(value = "pskill", defaultValue = "") String pskill,
										@RequestParam(value = "resourceDDL", defaultValue = "false") boolean resourceDDL,
										@RequestParam(value = "aboveGrade", defaultValue = "0") Integer aboveGrade,
										@RequestParam(value = "grade", defaultValue = "0") Integer grade,
										@RequestParam(value = "bucket", defaultValue = "0") String bucket,
										@RequestParam(value = "unitId", defaultValue = "0") Integer unitId,
										@RequestParam(value = "billingUnitId", defaultValue = "0") Integer billingUnitId,
										@RequestParam(value = "roleId", defaultValue = "0") Integer roleId,
										@RequestParam(value = "forGradeApproval", defaultValue = "false") boolean forGradeApproval,
										@RequestParam(value = "searchStr", defaultValue = "") String searchStr,
										@RequestParam(value = "dateDiff", defaultValue = "0") Integer dateDiff){
        List<Resource> resourcelist = null;
        //Integer userId = (Integer) session.getAttribute("loggedInUid");
        try {
            /* ------------------------- Authorization start ------------------------------------ */
            if (tsDelegateId == 0) 
			{
                // Authorization for admin role
				// RKJ - Resource view all exposed to all associates
                //if (!service.isAValidAdminRole()) 
				//{
                //    service.sendTamperedMail("Resource View All", 0, 0, request);
                //    return resourcelist;
                //}
            }
            /* ------------------------- Authorization ends ------------------------------------ */
            Integer disabled = 0;
            Integer unitIdTemp = 0;
            if (tsDelegateId != 0) 
			{
                resourcelist = repository.findResourceByDelegateId(tsDelegateId);
            }
            else if(grade != 0){
            	 resourcelist = repository.findResourceByGradeId(grade);
            }
			else if (status.equals("active"))
			{
               
                if(resourceDDL)
                {
                	if(unitId != 0 && billingUnitId !=0) {
                		      
                    	resourcelist = manager.createNamedQuery("getAllResourcesDropDownByUnit", Resource.class)
                    			.setMaxResults(limit)
                    			.setParameter("disabled", disabled)
                    			.setParameter("aboveGrade", aboveGrade)
                    			.setParameter("unitId", unitId)
                    			.setParameter("billingUnitId", billingUnitId)
                    			.getResultList();
                	} 
                	else{                		
                   		              		
                        	resourcelist = manager.createNamedQuery("getAllResourcesDropDown", Resource.class)
                                    .setMaxResults(limit)
                                    .setParameter("disabled", disabled)
                                    .setParameter("aboveGrade", aboveGrade)
                                    .setParameter("unitId", unitId)
                                    .getResultList();
                    	 
                	}
                }               
                else if(!("".equals(searchStr)))
                {
                	resourcelist = manager.createNamedQuery("getAllResourcesBySearch", Resource.class)
                            .setMaxResults(limit)
                            .setParameter("disabled", disabled)
                            .setParameter("searchStr", searchStr)
                            .getResultList();
                }
                else
                {
                	resourcelist = manager.createNamedQuery("getAllResources", Resource.class)
                            .setMaxResults(limit)
                            .setParameter("disabled", disabled)
                            .getResultList();
                }
            } 
			else if (!name.equals("")) {
                resourcelist = manager.createNamedQuery("getAllResources", Resource.class)
						 .setMaxResults(limit)
						 .setParameter("name", name)
						 .setParameter("pskill", pskill)
		                .getResultList();
            }
			else if (bucket.equals("b_firm")) //Bucket - B_FIRM
			{
				resourcelist = manager.createNamedQuery("findResourcesByBfirmBucket", Resource.class)
						.getResultList();
			}
			/*else if (bucket.equals("b_risk")) //Bucket - B_RISK
			{
				resourcelist = manager.createNamedQuery("findResourcesByBriskBucket", Resource.class)
						.getResultList();
			}*/
			else if (bucket.equals("nb_buffer")) //Bucket - NB_BUFFER
			{
				resourcelist = manager.createNamedQuery("findResourcesByNBbufferBucket", Resource.class)
						.getResultList();
			}
			else if (bucket.equals("nb_pool")) //Bucket - NB_POOL
			{
				resourcelist = manager.createNamedQuery("findResourcesByNBpoolBucket", Resource.class)
						.getResultList();
			}
			else if (!bucket.equals("0")) //Get By Bucket name
			{
				resourcelist = manager.createNamedQuery("findResourcesByBucketName", Resource.class)
						.setParameter("bucket", bucket)
						.getResultList();
			}
			else if(roleId != 0){
				resourcelist = manager.createNamedQuery("findResourcesByRoleId", Resource.class)                        
                        .setParameter("roleId", roleId)
                        .getResultList();
			}
			else if(dateDiff != 0){
				resourcelist = manager.createNamedQuery("findResourcesJoiningDateDiffrance", Resource.class)
						.setParameter("dateDiff", dateDiff)
                        .getResultList();            	
            	
            }else{
                resourcelist = manager.createNamedQuery("getAllResources", Resource.class)
                        .setMaxResults(limit)
                        .setParameter("disabled", disabled)
                        .getResultList();
            }
            
            
            
            
        } 
		catch (Exception e){
            logger.error(e);
        }
        return resourcelist;

    }

    @RequestMapping(value = "/project/{projectId}", method = RequestMethod.GET)
    public List<Resource> getResourcesAllocatedToProject(@PathVariable("projectId") Integer projectId) {

        List<Resource> resourcelist = null;

        resourcelist = manager.createNamedQuery("findResourceInProject", Resource.class)
                .setParameter("projectId", projectId)
                .getResultList();

        return resourcelist;

    }


    @RequestMapping(value="/{uid}",method=RequestMethod.GET)
    public Resource findResource(@PathVariable Integer uid, @RequestParam(value = "amgResourceEdit", required=false) Integer...amgResourceEdit) {
        Resource resource = null;
        try {
        	if (amgResourceEdit != null && amgResourceEdit.length > 0  && amgResourceEdit[0] == 1) {
        		resource = repository.findResourcebyUid(uid);
        	} else {
        		resource = manager.createNamedQuery("findResourceByUid", Resource.class)
        		.setParameter("uid", uid)
        		.getSingleResult();
        	}
        } catch (Exception e) {
            logger.error(e);
        }
        return resource;
    }

    @RequestMapping(value = "/{uid}", method = RequestMethod.PUT)
    public ResponseEntity<?> updateResource(@PathVariable("uid") Integer uid, @RequestBody Resource resource) {
        try {
        	
        	//Get Holiday Schedule ID as per the current location
        	int holidayScheduleId = 0;
        	if(resource.getCurrentLocation() != null)
        	{
        	 	HolidaySchedules hc =  holidaySchedulesRepository.findByCityId(resource.getCurrentLocation().getCityId());
        	 	if(hc != null)holidayScheduleId = hc.getHolidayScheduleId();
        	}
        	if(holidayScheduleId!=0) resource.setHolidayScheduleId(holidayScheduleId);
        	
            resource.setUid(uid);
            repository.save(resource);
            return new ResponseEntity<>(HttpStatus.OK);
        } catch (Exception ex) {
            logger.error(ex);
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    public String getEmailByUid(Integer uid) {
        return this.repository.findEmailByUid(uid);
    }
    
    
    @GetMapping("/getResourceMap")
    public Object getResourceMap(HttpServletRequest request) {
    	Map<String, List<Map<Integer, String>>> resourceMap = new HashMap<>();
    	resourceMap.putIfAbsent("resourceMap", repository.getResourceMap(manager));
    	return resourceMap;
    }
    
    @GetMapping("/getGradeList")
    public Object getGradeList(@RequestParam(value = "forGradeApproval", defaultValue = "false") boolean forGradeApproval,
    		@RequestParam(value = "userId", defaultValue = "0") Integer userId,
    		@RequestParam(value = "status", defaultValue = "all") String status,
    		@RequestParam(value = "limit", defaultValue = "0") Integer limit,
    		HttpServletRequest request) {
    	
    	List<Resource> resourcelist = null;
    	List<Resource> filteredResourceList = new ArrayList<>();
    	Integer disabled = 0;
    	userId = (Integer) session.getAttribute("loggedInUid");
        	Resource resourceByUid = repository.findResourcebyUid(userId);
        	int userGradeNo = NumberUtils.toInt(resourceByUid.getGrade().getGradeNo());
        	
        	resourcelist = manager.createNamedQuery("getAllResources", Resource.class)
                    .setMaxResults(limit)
                    .setParameter("disabled", disabled)
                    .getResultList();
        	
        	for (Resource resource : resourcelist) {
        		int grdNo = NumberUtils.toInt(resource.getGrade().getGradeNo());
        		if (grdNo >= 6 && grdNo > userGradeNo) {
        			filteredResourceList.add(resource);
        		}
			}
        	 resourcelist.retainAll(filteredResourceList);
        	 return resourcelist;
    }


	@GetMapping("/findResourceByUId")
	public Object findResourceByUId(@RequestParam(value = "uid", defaultValue = "0") Integer uid,
									  HttpServletRequest request){
		Resource resource = null;

		resource = manager.createNamedQuery("findResourceByUid", Resource.class)
				.setParameter("uid", uid)
				.getSingleResult();

		return resource;
	}
	
	@RequestMapping("/getAllResources")
	public List<Resource> getAllResources(@RequestParam(value = "limit", defaultValue = "0") Integer limit,
			@RequestParam(value = "status", defaultValue = "all") String status,
			HttpServletRequest request) {
		Integer disabled = 0;
		List<Resource> list = null;
		list = manager.createNamedQuery("getAllResources", Resource.class)
                .setMaxResults(limit)
                .setParameter("disabled", disabled)
                .getResultList();
		return list;

	}
}
