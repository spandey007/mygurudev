package com.infocepts.otc.controllers;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.infocepts.otc.entities.CmsDetail;
import com.infocepts.otc.entities.Opportunity;
import com.infocepts.otc.repositories.OpportunityRepository;

@RestController
@RequestMapping(value="/opportunity",headers="referer")
public class OpportunityController {

	@Autowired
	OpportunityRepository repository;
	
	@PersistenceContext
    private EntityManager manager;
	
	final Logger logger = Logger.getLogger(OpportunityController.class);
	
	 @RequestMapping(method=RequestMethod.GET)
	 public List<Opportunity> getAllOpportunity(@RequestParam(value = "accountId", defaultValue = "0") Integer accountId,
			 									@RequestParam(value = "uid", defaultValue = "0") Integer uid,
			 									@RequestParam(value = "planningYear", defaultValue = "") String planningYear){
		 
		 List<Opportunity> opportunitylist=null;
		 try
		 {
			 if(!planningYear.equals(""))
			 {				 
				 opportunitylist = manager.createNamedQuery("getPlanningOpportunityForPh",Opportunity.class)
				 			.setParameter("uid", uid)
				 			//.setParameter("planningYear", planningYear)
							.getResultList();
			 }
			 else
			 {
				 opportunitylist = manager.createNamedQuery("getOpportunityForAccount",Opportunity.class)
				 			.setParameter("accountId", accountId)
							.getResultList();
			 }
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return opportunitylist;
	 }
	 
	 @RequestMapping(value="/{opportunityId}",method=RequestMethod.GET)
	 public Opportunity getOpportunityById(@PathVariable Integer opportunityId){
		 Opportunity opportunity=null;
		 try{
			 opportunity = repository.findOne(opportunityId);
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return opportunity;
	 }
	
	 /* Insert/Update/Delete not required since opportunities are flowing in InfoBiz from Hubspot
	 @RequestMapping(method=RequestMethod.POST)
		public Opportunity addOpportunity(@RequestBody Opportunity opportunity)
		{
			try{
				opportunity.setOpportunityId(null);
				repository.save(opportunity);	
			}catch(Exception e){
				logger.error(e);
			}
			return opportunity;
		}
	 
	 @RequestMapping(value="/{opportunityId}",method=RequestMethod.PUT)
	 public Opportunity updateOpportunity(@RequestBody Opportunity updatedOpportunity,@PathVariable Integer opportunityId){
		 try{
			 updatedOpportunity.setOpportunityId(opportunityId);
			 repository.save(updatedOpportunity);
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return updatedOpportunity;
	 }
	 
	 @RequestMapping(value="/{opportunityId}",method=RequestMethod.DELETE)
	 public void deleteOpportunity(@PathVariable Integer opportunityId){
		 try{
			 repository.delete(opportunityId);
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
	 }	
	 */ 
	
}
