package com.infocepts.otc.entities;

import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import com.infocepts.otc.utilities.LoadConstant;

@Entity
@Table(catalog=LoadConstant.infomaster, schema="[dbo]",name="month")
public class Month {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer monthId;
	private String month;
	
	@ManyToOne
	@JoinColumn(name="yearId")
	private Year year;
	private Integer totalDays;
	private Date createdDate;
	private Date modifiedDate;
	private Boolean status;
	private Boolean saved;
	private Integer createdBy;
	private Integer modifiedBy;
	private Integer monthNo;
	private Date monthStartDate;
	private Date monthEndDate;
	private Integer daysInMonth;
	public Integer getMonthId() {
		return monthId;
	}
	public void setMonthId(Integer monthId) {
		this.monthId = monthId;
	}
	public String getMonth() {
		return month;
	}
	public void setMonth(String month) {
		this.month = month;
	}
	
	public Year getYear() {
		return year;
	}
	public void setYear(Year year) {
		this.year = year;
	}
	public Integer getTotalDays() {
		return totalDays;
	}
	public void setTotalDays(Integer totalDays) {
		this.totalDays = totalDays;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public Date getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public Boolean getStatus() {
		return status;
	}
	public void setStatus(Boolean status) {
		this.status = status;
	}
	public Boolean getSaved() {
		return saved;
	}
	public void setSaved(Boolean saved) {
		this.saved = saved;
	}
	public Integer getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}
	public Integer getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public Integer getMonthNo() {
		return monthNo;
	}
	public void setMonthNo(Integer monthNo) {
		this.monthNo = monthNo;
	}
	public Date getMonthStartDate() {
		return monthStartDate;
	}
	public void setMonthStartDate(Date monthStartDate) {
		this.monthStartDate = monthStartDate;
	}
	public Date getMonthEndDate() {
		return monthEndDate;
	}
	public void setMonthEndDate(Date monthEndDate) {
		this.monthEndDate = monthEndDate;
	}
	public Integer getDaysInMonth() {
		return daysInMonth;
	}
	public void setDaysInMonth(Integer daysInMonth) {
		this.daysInMonth = daysInMonth;
	}
	
}
