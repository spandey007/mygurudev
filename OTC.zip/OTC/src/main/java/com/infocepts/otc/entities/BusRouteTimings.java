package com.infocepts.otc.entities;

import java.util.Date;

import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.SqlResultSetMappings;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.infocepts.otc.utilities.LoadConstant;
@SqlResultSetMappings({
	@SqlResultSetMapping(
			name = "timing_bus_pass",
		      classes = {
		          @ConstructorResult(
		              targetClass = BusRouteTimings.class,
		              columns = {
		            	//normal cols
		                  @ColumnResult(name = "busRouteTimingsId"),
		                  @ColumnResult(name = "busRouteId"),
		                  @ColumnResult(name = "busNodalPointId"),
		                  @ColumnResult(name = "pickUpTime", type=String.class),
		                  @ColumnResult(name = "busRouteName", type=String.class),
		                  @ColumnResult(name = "nodalPointName", type=String.class)
		                  }
		          )
		      }
		),
	@SqlResultSetMapping(
			name = "get_bus_route_timings",
		      classes = {
		          @ConstructorResult(
		              targetClass = BusRouteTimings.class,
		              columns = {		            	
		            		  @ColumnResult(name = "busRouteTimingsId"),
			                  @ColumnResult(name = "pickUpTime", type=String.class),			                
		                  }
		          )
		      }
		)
})
@NamedNativeQueries({
	   @NamedNativeQuery(
			   
			  
              
	            name    =   "getTimingBusPass",
	            query   =   " SELECT brt.busRouteTimingsId as busRouteTimingsId, brt.busRouteId as busRouteId," + 
	            			" brt.busNodalPointId as busNodalPointId, brt.pickUpTime as pickUpTime, br.busRouteName as busRouteName," + 
	            			" bnp.nodalPointName as nodalPointName" + 
	            			" FROM " + LoadConstant.otc + ".[dbo].[busroutetimings] brt" + 
	            			" left join " + LoadConstant.otc + ".[dbo].[busroute] br on br.busRouteId=brt.busRouteId" + 
	            			" left join " + LoadConstant.otc + ".[dbo].[busnodalpoint] bnp on bnp.busNodalPointId=brt.busNodalPointId",
	                       resultClass=BusRouteTimings.class, resultSetMapping = "timing_bus_pass"                       		
	    ),
	   @NamedNativeQuery(
	            name    =   "getBusRouteTimings",
	            query   =   " SELECT brt.busRouteTimingsId as busRouteTimingsId, brt.pickUpTime as pickUpTime" +             				
	            			" FROM " + LoadConstant.otc + ".[dbo].[busroutetimings] brt"+
	            			" where brt.busNodalPointId = :nodalpointid and brt.busRouteId = :routeid",
	                       resultClass=BusRouteTimings.class, resultSetMapping = "get_bus_route_timings"                       		
	    )
})

@Entity
@Table(catalog=LoadConstant.otc, schema="[dbo]",name="busroutetimings")

public class BusRouteTimings {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer busRouteTimingsId;
	
	@ManyToOne
	@JoinColumn(name="busRouteId")
	private BusRoute busroute;
	
	@ManyToOne
	@JoinColumn(name="busNodalPointId")
	private BusNodalPoint busnodalpoint;
	
	private String pickUpTime;
	@Transient
	private String busRouteName;
	
	@Transient
	private String nodalPointName;

	
	//Getter and Setter
	
	public Integer getBusRouteTimingsId() {
		return busRouteTimingsId;
	}

	public void setBusRouteTimingsId(Integer busRouteTimingsId) {
		this.busRouteTimingsId = busRouteTimingsId;
	}	

	public BusRoute getBusroute() {
		return busroute;
	}

	public void setBusroute(BusRoute busroute) {
		this.busroute = busroute;
	}

	public BusNodalPoint getBusnodalpoint() {
		return busnodalpoint;
	}

	public void setBusnodalpoint(BusNodalPoint busnodalpoint) {
		this.busnodalpoint = busnodalpoint;
	}

	public String getPickUpTime() {
		return pickUpTime;
	}

	public void setPickUpTime(String pickUpTime) {
		this.pickUpTime = pickUpTime;
	}

	public String getBusRouteName() {
		return busRouteName;
	}

	public void setBusRouteName(String busRouteName) {
		this.busRouteName = busRouteName;
	}

	public String getNodalPointName() {
		return nodalPointName;
	}

	public void setNodalPointName(String nodalPointName) {
		this.nodalPointName = nodalPointName;
	}

	

	public BusRouteTimings(Integer busRouteTimingsId, Integer busRouteId, Integer busNodalPointId,String pickUpTime,
			String busRouteName, String nodalPointName) {
		this.busRouteTimingsId = busRouteTimingsId;
		if(busRouteId != null)
		{
			this.busroute = new BusRoute();
			this.busroute.setBusRouteId(busRouteId);
		}
		if(busNodalPointId != null) 
		{
			this.busnodalpoint = new BusNodalPoint();
			this.busnodalpoint.setBusNodalPointId(busNodalPointId);
		}
		this.pickUpTime = pickUpTime;
		this.busRouteName = busRouteName;
		this.nodalPointName = nodalPointName;
	}
	
	public BusRouteTimings(Integer busRouteTimingsId,String pickUpTime) {
		this.busRouteTimingsId = busRouteTimingsId;
		this.pickUpTime = pickUpTime;
	}
	
	public BusRouteTimings() {
	}
	
	
	
	
	
	


}
