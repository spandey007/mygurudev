package com.infocepts.otc.security;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;


import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.infocepts.otc.entities.Permissions;
import com.infocepts.otc.entities.ResourceRoles;
import com.infocepts.otc.repositories.PermissionsRepository;
import com.infocepts.otc.repositories.ResourceRolesRepository;

@Component(value="securityService")
public class SecurityServiceImpl{
	 @Autowired
	 PermissionsRepository permissionsrepository;
	 
	 @Autowired
	 HttpSession session;
	 
	 @Autowired
	 ResourceRolesRepository resourceRolesrepository;
	 
	 public boolean userHasPermissionForURL(String currentUrl) {
		 
		List<String> userRolesList = new ArrayList<>();
		
		// retrieve the logged in users roles
		Integer uid = (Integer) session.getAttribute("loggedInUid");
		List<ResourceRoles> resourcesRoles = resourceRolesrepository.findResourceRoles(uid);
		if (resourcesRoles.size() > 0) 
		{
			ListIterator<ResourceRoles> roleIterator = resourcesRoles.listIterator();
			while (roleIterator.hasNext()) 
			{
				ResourceRoles resRole = (ResourceRoles) roleIterator.next();
				String role = resRole.getRoles().getRole();
				userRolesList.add(role);
			}
		}	
		
		// retrieve the permissions for the current url and check if the logged in user has the required role to access it
		List<Permissions> permissionsList = permissionsrepository.findActivePermissionsByUrl(currentUrl);
		ListIterator<Permissions> permissionIterator = permissionsList.listIterator();
		while(permissionIterator.hasNext())
		{
			Permissions permission = (Permissions)permissionIterator.next();
			String allowedrole = permission.getRoles().getRole();
			if(userRolesList.contains(allowedrole))
			{
				return true;
			}
			
		}
		return false;	  
	 }
}
