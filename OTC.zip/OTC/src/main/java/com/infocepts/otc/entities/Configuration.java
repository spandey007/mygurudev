package com.infocepts.otc.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.infocepts.otc.utilities.LoadConstant;

@Entity
@Table(catalog=LoadConstant.otc, schema="[dbo]",name="configuration")
public class Configuration {

	//Columns
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer configurationId;
	
	private String moduleName;
	
	private String configName;
	
	private String configValue01;
	
	private String configValue02;
	
	private String configValue03;
	
	private String configValue04;
	
	private String configValue05;
	
	//Getter and Setter
	public Integer getConfigurationId() {
		return configurationId;
	}
	public void setConfigurationId(Integer configurationId) {
		this.configurationId = configurationId;
	}
	public String getModuleName() {
		return moduleName;
	}
	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}
	public String getConfigName() {
		return configName;
	}
	public void setConfigName(String configName) {
		this.configName = configName;
	}
	public String getConfigValue01() {
		return configValue01;
	}
	public void setConfigValue01(String configValue01) {
		this.configValue01 = configValue01;
	}
	public String getConfigValue02() {
		return configValue02;
	}
	public void setConfigValue02(String configValue02) {
		this.configValue02 = configValue02;
	}
	public String getConfigValue03() {
		return configValue03;
	}
	public void setConfigValue03(String configValue03) {
		this.configValue03 = configValue03;
	}
	public String getConfigValue04() {
		return configValue04;
	}
	public void setConfigValue04(String configValue04) {
		this.configValue04 = configValue04;
	}
	public String getConfigValue05() {
		return configValue05;
	}
	public void setConfigValue05(String configValue05) {
		this.configValue05 = configValue05;
	}
	
	

	
	
	
}
