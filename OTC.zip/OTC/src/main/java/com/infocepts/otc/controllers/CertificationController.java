package com.infocepts.otc.controllers;

import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.infocepts.otc.entities.Certification;
import com.infocepts.otc.repositories.CertificationRepository;
import com.infocepts.otc.services.TimesheetService;


@RestController
@RequestMapping(value="/certification",headers="referer")
public class CertificationController {
	
	final Logger logger = Logger.getLogger(CertificationController.class);

	@Autowired
	CertificationRepository repository;
	
	@Autowired
	TimesheetService service;
	
	@RequestMapping(method=RequestMethod.POST)
	public Certification addCertification(@RequestBody Certification certification)
	{
		try{
				certification.setCertificationId(null);
				repository.save(certification);
		}catch(Exception e){
			logger.error(e);
		}
		return certification;
	}	
 
	 @RequestMapping(method=RequestMethod.GET)
	 public List<Certification> getAllCertifications(@RequestParam(name="certificationName",defaultValue="") String certificationName){
		 List<Certification> certificationlist=null;
		 try{
			 if(certificationName != null){
				 certificationlist = repository.findCertificationByName(certificationName);
			 }
			 else{
				 certificationlist = repository.findAllCertifications();
			 }
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return certificationlist;
	 }

	@RequestMapping(value="/{certificationId}",method=RequestMethod.GET)
	 public Certification getCertification(@PathVariable Integer certificationId){
		 Certification certification=null;
		 try{
			 certification = repository.findOne(certificationId);
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return certification;
	 }
	 
	@RequestMapping(value="/{certificationId}",method=RequestMethod.PUT)
	 public Certification updateCertification(@RequestBody Certification updatedCertification,@PathVariable Integer certificationId){
		 try{
			 	updatedCertification.setCertificationId(certificationId);
			 	repository.save(updatedCertification);
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return updatedCertification;
	 }
	 
	 @RequestMapping(value="/{certificationId}",method=RequestMethod.DELETE)
	 public void deleteCertification(@PathVariable Integer certificationId){
		 try{
			 if(service.isAMG()){
				 repository.delete(certificationId);
			 }	 
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
	 }	 
}
