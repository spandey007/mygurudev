package com.infocepts.otc.entities;

import com.infocepts.otc.utilities.LoadConstant;

import javax.persistence.*;
import java.util.Date;


@Entity
@Table(catalog=LoadConstant.otc,schema="[dbo]",name="deGovernance")

	@SqlResultSetMappings({
		@SqlResultSetMapping(
		      name = "project_list",
		      classes = {
		          @ConstructorResult(
		              targetClass = DeGovernance.class,
		              columns = {	
		            		  	            	  
		            	  //Actual Fields Mapping  
		            	  @ColumnResult(name = "itemId"),
		            	  @ColumnResult(name = "projectType",type=String.class),
		                  @ColumnResult(name = "projectMetricsForDate",type=Date.class),
		                  @ColumnResult(name = "projectId"),
		                  @ColumnResult(name = "accountId"),
		                  @ColumnResult(name = "totalAssociates",type=Integer.class),
		                  @ColumnResult(name = "projectedRevenueForMonth",type=Float.class),
		                  @ColumnResult(name = "actualRevenueForMonth",type=Float.class),	                  
		                  @ColumnResult(name = "percentageRevenueAchievedForMonth",type=Float.class),
		                  @ColumnResult(name = "effortVariance",type=Float.class),
		                  @ColumnResult(name = "totalInternalDefect"),
		                  @ColumnResult(name = "totalExternalDefect"),
		                  @ColumnResult(name = "defectLeakage",type=Float.class),
		                  @ColumnResult(name = "defectDensity",type=Float.class),
		                  @ColumnResult(name = "peopleRisk",type=String.class),
		                  @ColumnResult(name = "peopleRiskDescription",type=String.class),
		                  @ColumnResult(name = "customerFeedback",type=String.class),
		                  @ColumnResult(name = "customerFeedbackDescription",type=String.class),
		                  @ColumnResult(name = "executionRisk",type=String.class),
		                  @ColumnResult(name = "executionRiskDescription",type=String.class),
		                  @ColumnResult(name = "totalTasksReceived"),
		                  @ColumnResult(name = "tasksWithScheduleOverrun"),
		                  @ColumnResult(name = "percentageScheduleOverrun",type=Float.class),
		                  @ColumnResult(name = "tasksWithEffortOverrun",type=Integer.class),
		                  @ColumnResult(name = "percentageEffortOverrun",type=Float.class),
		                  @ColumnResult(name = "totalHoursSpent",type=Float.class),
		                  @ColumnResult(name = "totalHoursEstimated",type=Float.class),
		                  @ColumnResult(name = "actualHoursSpent",type=Float.class),
		                  @ColumnResult(name = "scheduleVariance",type=Float.class),
		                  
		                  @ColumnResult(name = "totalTicketsReceived"),
		                  @ColumnResult(name = "totalTicketsDelivered"),
		                  @ColumnResult(name = "totalTicketsCarriedForward"),
		                  @ColumnResult(name = "totalTicketsCarriedForwardPrev"),
		                  @ColumnResult(name = "responseSLA",type=Float.class),
		                  @ColumnResult(name = "resolutionSLA",type=Float.class),
		                  @ColumnResult(name = "capacityUtilization",type=Float.class),
		                  
		                  @ColumnResult(name = "avgTimeToResolve",type=Float.class),
		                  @ColumnResult(name = "firstTimeRight",type=Float.class),
		                  @ColumnResult(name = "backlogIndex",type=Float.class),
		                  @ColumnResult(name = "notesByPM",type=String.class),
		                  @ColumnResult(name = "notesByPH",type=String.class),
		                  @ColumnResult(name = "tbdInDeliveryReview",type=Boolean.class),
		                  
		                  @ColumnResult(name = "notesByAH",type=String.class),
		                  @ColumnResult(name = "notesByDH",type=String.class),
		                  @ColumnResult(name = "cutoffPerForScheduleOverrun",type=Float.class),
		                  @ColumnResult(name = "cutoffPerForEffortOverrun",type=Float.class),
		                  @ColumnResult(name = "cutoffPerDefectLeakage",type=Float.class),
		                  @ColumnResult(name = "cutoffPerBacklogIndex",type=Float.class),
		                  @ColumnResult(name = "pmId"),
		                  
		                  @ColumnResult(name = "pmModifiedOn",type=Date.class),
		                  @ColumnResult(name = "phId"),
		                  @ColumnResult(name = "phModifiedOn",type=Date.class),
		                  @ColumnResult(name = "ahId"),
		                  @ColumnResult(name = "ahModifiedOn",type=Date.class),
		                  @ColumnResult(name = "dhId"),
		                  @ColumnResult(name = "dhModifiedOn",type=Date.class),
		                  
		                  
		                  @ColumnResult(name = "associateCountOnsite"),
		                  @ColumnResult(name = "associateCountTotal"),
		                  @ColumnResult(name = "totalPositionsCarryForward"),
		                  @ColumnResult(name = "totalPositionsOpened"),
		                  @ColumnResult(name = "totalPositions"),
		                  @ColumnResult(name = "totalPositionsStaffed"),
		                  @ColumnResult(name = "totalInterViewsConducted"),
		                  @ColumnResult(name = "avgTimeToStaff"),
		                  @ColumnResult(name = "staffingIndex",type=Float.class),
//		                  @ColumnResult(name = "noOfComplaintsReceived"),
//		                  @ColumnResult(name = "noOfAppreciationsReceived"),
		                  @ColumnResult(name = "valueAdds"),
		                  @ColumnResult(name = "csatScore",type=String.class),
		                  @ColumnResult(name = "timeToStaff"),
		                  @ColumnResult(name = "noInterviewsbeforefinalisation",type=Float.class),
		                  @ColumnResult(name = "ratioOfPositionStaffedVsOpen",type=Float.class),
						  @ColumnResult(name = "knowledgeSkillsScore"),
						  @ColumnResult(name = "responsivenessScore"),
						  @ColumnResult(name = "qualityScore"),
						  @ColumnResult(name = "deliverResultScore"),	 
						  
		            	  //Transient Fields Mapping  
	            		  @ColumnResult(name = "projectName",type=String.class),
	            		  @ColumnResult(name = "pProjectId"),
	            		  @ColumnResult(name = "projectManagersId"),
	            		  @ColumnResult(name = "projectManager",type=String.class),
	            		  @ColumnResult(name = "portfolioId"),
	            		  @ColumnResult(name = "pAccountId"),
	            		  @ColumnResult(name = "portfolioName",type=String.class),
	            		  @ColumnResult(name = "portfolioHead",type=String.class),
	            		  
	            		  @ColumnResult(name = "deProjectType",type=String.class),
	            		  @ColumnResult(name = "accountName",type=String.class),
	            		  @ColumnResult(name = "associateCountOffshore",type=Integer.class),
	            		  
	            		  @ColumnResult(name = "noOfTicketsResponseTimeBreach"),
		                  @ColumnResult(name = "noOfTicketsResolutionTimeBreach"),
		                  @ColumnResult(name = "totaTeamCapacityInHours",type=Float.class),
		                  @ColumnResult(name = "totalHoursInvestedInTickets"),
		                  @ColumnResult(name = "totalTicketsReopened"),
		                  @ColumnResult(name = "valueAdd_OptimizationsDelivered"),
		                  
		                  @ColumnResult(name = "portfolioNotes",type=String.class),
		            	  @ColumnResult(name = "deliveryNotes",type=String.class),
		            	  @ColumnResult(name = "accountNotes",type=String.class),
		            	  @ColumnResult(name = "associatesCount"),
		            	  
		            	  @ColumnResult(name = "billableCount"),
		            	  @ColumnResult(name = "nonBillableCount"),
		            	  @ColumnResult(name = "offshoreCount"),
		            	  @ColumnResult(name = "onsiteCount"),
		            	  
		            	  @ColumnResult(name = "ahApproved",type=Boolean.class),
		            	  @ColumnResult(name = "phApproved",type=Boolean.class),
		            	  @ColumnResult(name = "dhApproved",type=Boolean.class),
		                  @ColumnResult(name = "totalFTE",type=Float.class),
		  				  @ColumnResult(name = "notesByDE", type = String.class),
						  @ColumnResult(name = "deModifiedOn", type = Date.class),
						  @ColumnResult(name = "deId"),
						  @ColumnResult(name = "portfolioHeadId"),
						  @ColumnResult(name = "accountHeadId"),
						  @ColumnResult(name = "closeActionItem"),
						  @ColumnResult(name = "openActionItem"),
						  @ColumnResult(name = "onHoldActionItem"),
						  @ColumnResult(name = "totalActionItem"),
		  				  @ColumnResult(name = "accountHead", type = String.class),
		  				  @ColumnResult(name = "client", type = String.class),
						  @ColumnResult(name = "projectStartDate", type = Date.class),
						  @ColumnResult(name = "projectEndDate", type = Date.class)
		              }
		          )
		      }
		),
		@SqlResultSetMapping(
			      name = "ytd_list",
			      classes = {
			          @ConstructorResult(
			              targetClass = DeGovernance.class,
			              columns = {	
			            		  @ColumnResult(name = "projectedRevenueForMonth",type=Float.class),
				                  @ColumnResult(name = "actualRevenueForMonth",type=Float.class),	                  
			            		  @ColumnResult(name = "percentageRevenueAchievedForMonth",type=Float.class),
			            		  @ColumnResult(name = "effortVariance",type=Float.class),
			            		  @ColumnResult(name = "defectLeakage",type=Float.class),
			            		  @ColumnResult(name = "defectDensity",type=Float.class),
			            		  @ColumnResult(name = "percentageScheduleOverrun",type=Float.class),
			            		  @ColumnResult(name = "percentageEffortOverrun",type=Float.class),
			            		  @ColumnResult(name = "responseSLA",type=Float.class),
			            		  @ColumnResult(name = "resolutionSLA",type=Float.class),
			            		  @ColumnResult(name = "capacityUtilization",type=Float.class),
			            		  @ColumnResult(name = "avgTimeToResolve",type=Float.class),
			            		  @ColumnResult(name = "firstTimeRight",type=Float.class),
			            		  @ColumnResult(name = "backlogIndex",type=Float.class),
			            		  @ColumnResult(name = "avgTimeToStaff"),
			            		  @ColumnResult(name = "noInterviewsbeforefinalisation",type=Float.class),
			            		  @ColumnResult(name = "ratioOfPositionStaffedVsOpen",type=Float.class),
			            		  @ColumnResult(name = "totalTasksReceived"),
			            		  @ColumnResult(name = "tasksWithScheduleOverrun"),
			            		  @ColumnResult(name = "tasksWithEffortOverrun"),
			            		  @ColumnResult(name = "totaTeamCapacityInHours",type=Float.class),
			            		  @ColumnResult(name = "totalHoursEstimated",type=Float.class),
			            		  @ColumnResult(name = "totalHoursSpent",type=Float.class),
			            		  @ColumnResult(name = "actualHoursSpent",type=Float.class),			            		  
			            		  @ColumnResult(name = "totalInternalDefect"),
			            		  @ColumnResult(name = "totalExternalDefect"),
			            		  @ColumnResult(name = "totalTicketsReceived"),
			            		  @ColumnResult(name = "totalTicketsDelivered"),
			            		  @ColumnResult(name = "totalTicketsCarriedForward"),
			            		  @ColumnResult(name = "totalTicketsCarriedForwardPrev"),
			            		  @ColumnResult(name = "noOfTicketsResponseTimeBreach"),
			            		  @ColumnResult(name = "noOfTicketsResolutionTimeBreach"),
			            		  @ColumnResult(name = "totalHoursInvestedInTickets"),
			            		  @ColumnResult(name = "totalTicketsReopened"),
			            		  @ColumnResult(name = "valueAdd_OptimizationsDelivered")
			              }
			          )
			      }
			),
	})

	@NamedNativeQueries({    
	   
	    @NamedNativeQuery(
	            name    =   "getProjects",
	            query   =  	"SELECT "+
		            		"de.*,"+
		            		"p.title as projectName,"+
		            		"p.itemId as pProjectId,"+
		            		"p.projectManagersId ,"+
		            		"(select r.title from "+LoadConstant.infomaster+".dbo.resource r where r.uid = p.projectManagersId) as projectManager,"+
		            		"p.portfolioId,"+
		            		"p.accountId as pAccountId, "+
		            		"pf.title as portfolioName, "+
		            		"(select r.title from "+LoadConstant.infomaster+".dbo.resource r where r.uid = pf.ownerId ) as portfolioHead, "+
		            		"p.deProjectType,"+
		            		"'' as portfolioNotes,"+
		            		"'' as deliveryNotes,"+
		            		"'' as accountNotes,"+
		            		"(select count(distinct ma.uid) from monthly_allocation ma where (ma.projectId = p.itemId or ma.projectId in (select itemId from "+LoadConstant.infomaster+".dbo.project where parentProjectId = p.itemId)) and ma.prdMonth=:month and ma.prdYear=:year and (ma.alcType = 1 or ma.alcType = 2 ) ) as associatesCount,"+
		            		"(select count(distinct ma.uid) from monthly_allocation ma where (ma.projectId = p.itemId or ma.projectId in (select itemId from "+LoadConstant.infomaster+".dbo.project where parentProjectId = p.itemId)) and prdMonth = :month and prdYear = :year and alcType = 1 ) as billableCount,"+
		            		"(select count(distinct ma.uid) from monthly_allocation ma where (ma.projectId = p.itemId or ma.projectId in (select itemId from "+LoadConstant.infomaster+".dbo.project where parentProjectId = p.itemId)) and prdMonth = :month and prdYear = :year and alcType = 2) as nonBillableCount,"+
		            		"(select count(distinct ma.uid) from monthly_allocation ma left join sowDetail sd on ma.sowdetailId = sd.sowdetailId where (ma.projectId=p.itemId or ma.projectId in (select itemId from "+LoadConstant.infomaster+".dbo.project where parentProjectId = p.itemId)) and ma.prdMonth = :month and ma.prdYear = :year and sd.countryId = 101 and (ma.alcType = 1 or ma.alcType = 2 )) as offshoreCount,"+
		            		"(select count(distinct ma.uid) from monthly_allocation ma left join sowDetail sd on ma.sowdetailId = sd.sowdetailId where (ma.projectId=p.itemId or ma.projectId in (select itemId from "+LoadConstant.infomaster+".dbo.project where parentProjectId = p.itemId)) and ma.prdMonth = :month and ma.prdYear = :year and sd.countryId <> 101 and (ma.alcType = 1 or ma.alcType = 2 )) as onsiteCount,"+
		            		"(select sum(alcFte) from monthly_allocation ma where (ma.projectId = p.itemId or ma.projectId in (select itemId from "+LoadConstant.infomaster+".dbo.project where parentProjectId = p.itemId)) and ma.prdMonth=:month and ma.prdYear=:year and (ma.alcType = 1 or ma.alcType = 2 )) as totalFTE,"+		            		
		            		"oAccounts.accountShortName as accountName, "+
		            		"(select r.uid from " + LoadConstant.infomaster+".dbo.resource r where r.uid = pf.ownerId ) as portfolioHeadId,"+ 
		    				"oAccounts.ahId as accountHeadId, "+
		    				"(select title from " + LoadConstant.infomaster+".dbo.resource where uid =oAccounts.ahId) as accountHead, "+ 
		    				"(select title from " + LoadConstant.infomaster+".dbo.accounts where itemId =  de.accountId) as client, "+
		    				"p.projectstart as projectStartDate, "+
		    				"p.projectend as projectEndDate "+
		    				"FROM "+LoadConstant.infomaster+".dbo.project p "+
		            		"left join "+
		            		"deGovernance de "+
		            		"on p.itemId = de.projectId and month(de.projectMetricsForDate) = :month and year(de.projectMetricsForDate) = :year "+
		            		"left join "+
		            		LoadConstant.infomaster+".dbo.portfolio pf "+
		            		"on p.portfolioId = pf.itemId "+
		            		"left join "+
		            		LoadConstant.infomaster+".dbo.accounts oAccounts "+
		            		"on p.accountId = oAccounts.itemId "+
		            		"WHERE (de.itemId is not null and p.state = 'Closed' or p.state = 'Active' and p.deProjectType is not NULL AND p.parentProjectId is NULL) AND "+
/*		            		"or "+ 
		            		"(de.projectId is not null and p.deProjectType is not NULL AND parentProjectId is NULL) and "+
		            		"((de.itemId is not null and month(de.projectMetricsForDate) = :month) or (de.itemId is NULL) ) "+
		            		"AND "+
		            		"((de.itemId is not null and year(de.projectMetricsForDate) = :year) or (de.itemId is NULL)) "+
		            		"AND "+*/
		            		"(('pm' = :view and p.projectManagersId = :uid ) "+
		            		"or "+
		            		"('ah' = :view and oAccounts.ahId = :uid ) "+
		            		"or "+
		            		"('ph' = :view and pf.ownerId = :uid ) "+
		            		"or "+
		            		"('cep' = :view and oAccounts.rmId = :uid ) "+
		            		"or "+
		            		"('de' = :view ) "+
		            		"or "+
		            		"('dh' = :view ))"
		            		
	                        ,resultClass=DeGovernance.class,  resultSetMapping = "project_list"  
	    				),
	    @NamedNativeQuery(
	            name    =   "getYTDDeGovernanceDetail",
	            query   =  	"SELECT sum(projectedRevenueForMonth) as projectedRevenueForMonth,sum(actualRevenueForMonth) as actualRevenueForMonth,sum(percentageRevenueAchievedForMonth) as percentageRevenueAchievedForMonth,sum(effortVariance) as effortVariance,sum(defectLeakage) as defectLeakage,sum(defectDensity) as defectDensity,sum(percentageScheduleOverrun) as percentageScheduleOverrun,sum(percentageEffortOverrun) as percentageEffortOverrun,sum(responseSLA) as responseSLA,sum(resolutionSLA) as resolutionSLA,sum(capacityUtilization) as capacityUtilization,sum(avgTimeToResolve) as avgTimeToResolve,sum(firstTimeRight) as firstTimeRight,sum(backlogIndex) as backlogIndex,sum(avgTimeToStaff) as avgTimeToStaff,sum(noInterviewsbeforefinalisation) as noInterviewsbeforefinalisation,sum(ratioOfPositionStaffedVsOpen) as ratioOfPositionStaffedVsOpen,sum(totalTasksReceived) as totalTasksReceived,sum(tasksWithScheduleOverrun) as tasksWithScheduleOverrun, sum(tasksWithEffortOverrun) as tasksWithEffortOverrun, sum(totaTeamCapacityInHours) as totaTeamCapacityInHours, sum(totalHoursEstimated) as totalHoursEstimated, sum(totalHoursSpent) as totalHoursSpent, sum(actualHoursSpent) as actualHoursSpent, sum(totalInternalDefect) as totalInternalDefect, sum(totalExternalDefect) as totalExternalDefect, sum(totalTicketsReceived) as totalTicketsReceived, sum(totalTicketsDelivered) as totalTicketsDelivered, sum(totalTicketsCarriedForward) as totalTicketsCarriedForward, sum(totalTicketsCarriedForwardPrev) as totalTicketsCarriedForwardPrev, sum(noOfTicketsResponseTimeBreach) as noOfTicketsResponseTimeBreach, sum(noOfTicketsResolutionTimeBreach) as noOfTicketsResolutionTimeBreach, sum(totalHoursInvestedInTickets) as totalHoursInvestedInTickets, sum(totalTicketsReopened) as totalTicketsReopened, sum(valueAdd_OptimizationsDelivered) as valueAdd_OptimizationsDelivered"+ 
						    " FROM "+ LoadConstant.otc +".[dbo].[deGovernance]"+
						    " WHERE projectId=:projectId and year(projectMetricsForDate)=:year and projectType=:deProjectType"
	                        ,resultClass=DeGovernance.class,  resultSetMapping = "ytd_list"  
	    				)
					})
public class DeGovernance {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer itemId;

    private String projectType;

    private Date projectMetricsForDate;//Will store month and year in this field.

    private Integer projectId;// no mapping as corresponding table is in infoMaters

    private Integer accountId;// no mapping as corresponding table is in infoMaters

    private Integer totalAssociates;

    private Float projectedRevenueForMonth;

    private Float actualRevenueForMonth;

    private Float percentageRevenueAchievedForMonth;

    private Float effortVariance;

    private Integer totalInternalDefect;

    private Integer totalExternalDefect;

    private Float defectLeakage;

    private Float defectDensity;

    private String peopleRisk; // can be (High, Low, Medium)

    @Lob
    private String peopleRiskDescription;

    private String customerFeedback; // can be (Major issues, Minor issues, No issues)

    @Lob
    private String customerFeedbackDescription;

    private String executionRisk; // can be (High, Low, Medium)

    @Lob
    private String executionRiskDescription;


    //Start -- Fields for Task Based Projects
    private Integer totalTasksReceived;
    private Integer tasksWithScheduleOverrun;
    private Float percentageScheduleOverrun;
    private Integer tasksWithEffortOverrun;
    private Float percentageEffortOverrun;
    private Float totalHoursSpent;
    //End -- Fields for Task Based Projects


    //Start -- Fields for MileStone Based Projects
    private Float totalHoursEstimated;
    private Float actualHoursSpent;
    private Float scheduleVariance;
    //End -- Fields for MileStone Based Projects


    //Start -- Fields for ManagedServices Based Projects
    private Integer totalTicketsReceived;
    private Integer totalTicketsDelivered;
    private Integer totalTicketsCarriedForward;
    private Integer totalTicketsCarriedForwardPrev;
    private Float responseSLA;
    private Float resolutionSLA;
    private Float capacityUtilization;
    private Float avgTimeToResolve;
    private Float firstTimeRight;
    private Float backlogIndex;
    
    //End -- Fields for ManagedServices Based Projects
    
    //Start -- Fields for ManagedServices Based Projects
    private Integer associateCountOffshore;
    private Integer associateCountOnsite;
    private Integer associateCountTotal;
    private Integer totalPositionsCarryForward;
    private Integer totalPositionsOpened;
    private Integer totalPositions;
    private Integer totalPositionsStaffed;
    private Integer totalInterViewsConducted;
    private Integer avgTimeToStaff;
    private Float staffingIndex;
//    private Integer noOfComplaintsReceived;
//    private Integer noOfAppreciationsReceived;
    private Integer valueAdds;
    private String csatScore;
    private Integer timeToStaff;
    private Float noInterviewsbeforefinalisation;
    private Float ratioOfPositionStaffedVsOpen;
    //End -- Fields for ManagedServices Based Projects


    //Start -- PM View fields
    @Lob
    private String notesByPM;
    //End -- Pm view fields

    //Start -- PH View field
    @Lob
    private String notesByPH;
    private Boolean tbdInDeliveryReview;
    //End -- PH View fields

    //Start -- AH View field
    @Lob
    private String notesByAH;
    //End -- AH View fields


    //Start -- DH View field
    @Lob
    private String notesByDH;
    //End -- DH View fields

    private Integer knowledgeSkillsScore;
    private Integer responsivenessScore;
    private Integer qualityScore;
    private Integer deliverResultScore;


    //These fields will come from separate table where cutoffs would be mentioned.
    //Start --Cutoff fields starts
    private Float cutoffPerForScheduleOverrun;
    private Float cutoffPerForEffortOverrun;
    private Float cutoffPerDefectLeakage;
    private Float cutoffPerBacklogIndex;
    //Finish --cutoff fields ends

    private Integer pmId;
    private Date pmModifiedOn;

    private Integer phId;
    private Date phModifiedOn;

    private Integer ahId;
    private Date ahModifiedOn;

    private Integer dhId;
    private Date dhModifiedOn;
    
    //Transient variables
    @Transient
    private String  projectName;
    
    @Transient
    private Integer pProjectId; //Project Id from project table
    
    @Transient
    private Integer projectManagersId;
    
    @Transient
    private String projectManager;
    
    @Transient
    private Integer portfolioId;
    
    @Transient
    private Integer pAccountId; //Account Id from Project table
    
    @Transient
    private String portfolioName;
    
    @Transient
    private String accountName; 
    
    @Transient
    private String deProjectType;

    private Integer noOfTicketsResponseTimeBreach;
    private Integer noOfTicketsResolutionTimeBreach;
    private Float totaTeamCapacityInHours;
    private Integer totalHoursInvestedInTickets;
    private Integer totalTicketsReopened;
    private Integer valueAdd_OptimizationsDelivered;
    
    @Transient
    private String portfolioNotes; 
    
    @Transient
    private String deliveryNotes; 
    
    @Transient
    private String accountNotes; 
    
    @Transient
    private String portfolioHead;
    
    @Transient
    private Integer associatesCount;
    
    @Transient
    private Integer billableCount;
    
    @Transient
    private Integer nonBillableCount;
    
    @Transient
    private Integer offshoreCount;
    
    @Transient
    private Integer onsiteCount;
    
    private Boolean ahApproved;
    private Boolean phApproved;
    private Boolean dhApproved;
    
    @Transient
    private Float totalFTE;
    
	// Start -- DH View field
	@Lob
	private String notesByDE;
	// End -- DH View fields
	
	private Date deModifiedOn;

	private Integer deId;	
	
	@Transient
	private Integer portfolioHeadId;
	
	@Transient
	private Integer accountHeadId;
	
	@Transient
	private String accountHead;
	
	@Transient
	private String client;
	
	@Transient
	private Date projectStartDate;
	
	@Transient
	private Date projectEndDate;
	
	private Integer closeActionItem;
	
	private Integer onHoldActionItem;
	
	private Integer openActionItem;
	
	private Integer totalActionItem;
	
    //default ctor
    public DeGovernance() {
    }

    //Getters and Setters

    public Integer getItemId() {
        return itemId;
    }

    public void setItemId(Integer itemId) {
        this.itemId = itemId;
    }

    public String getProjectType() {
        return projectType;
    }

    public void setProjectType(String projectType) {
        this.projectType = projectType;
    }

    public Date getProjectMetricsForDate() {
        return projectMetricsForDate;
    }

    public void setProjectMetricsForDate(Date projectMetricsForDate) {
        this.projectMetricsForDate = projectMetricsForDate;
    }

    public Integer getProjectId() {
        return projectId;
    }

    public void setProjectId(Integer projectId) {
        this.projectId = projectId;
    }

    public Integer getAccountId() {
        return accountId;
    }

    public void setAccountId(Integer accountId) {
        this.accountId = accountId;
    }

    public Integer getTotalAssociates() {
        return totalAssociates;
    }

    public void setTotalAssociates(Integer totalAssociates) {
        this.totalAssociates = totalAssociates;
    }

    public Float getProjectedRevenueForMonth() {
        return projectedRevenueForMonth;
    }

    public void setProjectedRevenueForMonth(Float projectedRevenueForMonth) {
        this.projectedRevenueForMonth = projectedRevenueForMonth;
    }

    public Float getActualRevenueForMonth() {
        return actualRevenueForMonth;
    }

    public void setActualRevenueForMonth(Float actualRevenueForMonth) {
        this.actualRevenueForMonth = actualRevenueForMonth;
    }

    public Float getPercentageRevenueAchievedForMonth() {
        return percentageRevenueAchievedForMonth;
    }

    public void setPercentageRevenueAchievedForMonth(Float percentageRevenueAchievedForMonth) {
        this.percentageRevenueAchievedForMonth = percentageRevenueAchievedForMonth;
    }

    public Float getEffortVariance() {
        return effortVariance;
    }

    public void setEffortVariance(Float effortVariance) {
        this.effortVariance = effortVariance;
    }

    public Integer getTotalInternalDefect() {
        return totalInternalDefect;
    }

    public void setTotalInternalDefect(Integer totalInternalDefect) {
        this.totalInternalDefect = totalInternalDefect;
    }

    public Integer getTotalExternalDefect() {
        return totalExternalDefect;
    }

    public void setTotalExternalDefect(Integer totalExternalDefect) {
        this.totalExternalDefect = totalExternalDefect;
    }

    public Float getDefectLeakage() {
        return defectLeakage;
    }

    public void setDefectLeakage(Float defectLeakage) {
        this.defectLeakage = defectLeakage;
    }

    public Float getDefectDensity() {
        return defectDensity;
    }

    public void setDefectDensity(Float defectDensity) {
        this.defectDensity = defectDensity;
    }

    public String getPeopleRisk() {
        return peopleRisk;
    }

    public void setPeopleRisk(String peopleRisk) {
        this.peopleRisk = peopleRisk;
    }

    public String getPeopleRiskDescription() {
        return peopleRiskDescription;
    }

    public void setPeopleRiskDescription(String peopleRiskDescription) {
        this.peopleRiskDescription = peopleRiskDescription;
    }

    public String getCustomerFeedback() {
        return customerFeedback;
    }

    public void setCustomerFeedback(String customerFeedback) {
        this.customerFeedback = customerFeedback;
    }

    public String getCustomerFeedbackDescription() {
        return customerFeedbackDescription;
    }

    public void setCustomerFeedbackDescription(String customerFeedbackDescription) {
        this.customerFeedbackDescription = customerFeedbackDescription;
    }

    public String getExecutionRisk() {
        return executionRisk;
    }

    public void setExecutionRisk(String executionRisk) {
        this.executionRisk = executionRisk;
    }

    public String getExecutionRiskDescription() {
        return executionRiskDescription;
    }

    public void setExecutionRiskDescription(String executionRiskDescription) {
        this.executionRiskDescription = executionRiskDescription;
    }

    public Integer getTotalTasksReceived() {
        return totalTasksReceived;
    }

    public void setTotalTasksReceived(Integer totalTasksReceived) {
        this.totalTasksReceived = totalTasksReceived;
    }

    public Integer getTasksWithScheduleOverrun() {
        return tasksWithScheduleOverrun;
    }

    public void setTasksWithScheduleOverrun(Integer tasksWithScheduleOverrun) {
        this.tasksWithScheduleOverrun = tasksWithScheduleOverrun;
    }

    public Float getPercentageScheduleOverrun() {
        return percentageScheduleOverrun;
    }

    public void setPercentageScheduleOverrun(Float percentageScheduleOverrun) {
        this.percentageScheduleOverrun = percentageScheduleOverrun;
    }

    public Integer getTasksWithEffortOverrun() {
        return tasksWithEffortOverrun;
    }

    public void setTasksWithEffortOverrun(Integer tasksWithEffortOverrun) {
        this.tasksWithEffortOverrun = tasksWithEffortOverrun;
    }

    public Float getPercentageEffortOverrun() {
        return percentageEffortOverrun;
    }

    public void setPercentageEffortOverrun(Float percentageEffortOverrun) {
        this.percentageEffortOverrun = percentageEffortOverrun;
    }

    public Float getTotalHoursSpent() {
        return totalHoursSpent;
    }

    public void setTotalHoursSpent(Float totalHoursSpent) {
        this.totalHoursSpent = totalHoursSpent;
    }

    public Float getTotalHoursEstimated() {
        return totalHoursEstimated;
    }

    public void setTotalHoursEstimated(Float totalHoursEstimated) {
        this.totalHoursEstimated = totalHoursEstimated;
    }

    public Float getActualHoursSpent() {
        return actualHoursSpent;
    }

    public void setActualHoursSpent(Float actualHoursSpent) {
        this.actualHoursSpent = actualHoursSpent;
    }

    public Float getScheduleVariance() {
        return scheduleVariance;
    }

    public void setScheduleVariance(Float scheduleVariance) {
        this.scheduleVariance = scheduleVariance;
    }

    public Integer getTotalTicketsReceived() {
        return totalTicketsReceived;
    }

    public void setTotalTicketsReceived(Integer totalTicketsReceived) {
        this.totalTicketsReceived = totalTicketsReceived;
    }

    public Integer getTotalTicketsDelivered() {
        return totalTicketsDelivered;
    }

    public void setTotalTicketsDelivered(Integer totalTicketsDelivered) {
        this.totalTicketsDelivered = totalTicketsDelivered;
    }

    public Integer getTotalTicketsCarriedForward() {
        return totalTicketsCarriedForward;
    }

    public void setTotalTicketsCarriedForwardPrev(Integer totalTicketsCarriedForwardPrev) {
        this.totalTicketsCarriedForwardPrev = totalTicketsCarriedForwardPrev;
    }
    public Integer getTotalTicketsCarriedForwardPrev() {
        return totalTicketsCarriedForwardPrev;
    }

    public void setTotalTicketsCarriedForward(Integer totalTicketsCarriedForward) {
        this.totalTicketsCarriedForward = totalTicketsCarriedForward;
    }

    public Float getResponseSLA() {
        return responseSLA;
    }

    public void setResponseSLA(Float responseSLA) {
        this.responseSLA = responseSLA;
    }

    public Float getResolutionSLA() {
        return resolutionSLA;
    }

    public void setResolutionSLA(Float resolutionSLA) {
        this.resolutionSLA = resolutionSLA;
    }

    public Float getCapacityUtilization() {
        return capacityUtilization;
    }

    public void setCapacityUtilization(Float capacityUtilization) {
        this.capacityUtilization = capacityUtilization;
    }

    public Float getAvgTimeToResolve() {
        return avgTimeToResolve;
    }

    public void setAvgTimeToResolve(Float avgTimeToResolve) {
        this.avgTimeToResolve = avgTimeToResolve;
    }

    public Float getFirstTimeRight() {
        return firstTimeRight;
    }

    public void setFirstTimeRight(Float firstTimeRight) {	
        this.firstTimeRight = firstTimeRight;
    }

    public Float getBacklogIndex() {
        return backlogIndex;
    }

    public void setBacklogIndex(Float backlogIndex) {
        this.backlogIndex = backlogIndex;
    }

    public String getNotesByPM() {
        return notesByPM;
    }

    public void setNotesByPM(String notesByPM) {
        this.notesByPM = notesByPM;
    }

    public Boolean getTbdInDeliveryReview() {
        return tbdInDeliveryReview;
    }

    public void setTbdInDeliveryReview(Boolean tbdInDeliveryReview) {
        this.tbdInDeliveryReview = tbdInDeliveryReview;
    }

    public Float getCutoffPerForScheduleOverrun() {
        return cutoffPerForScheduleOverrun;
    }

    public void setCutoffPerForScheduleOverrun(Float cutoffPerForScheduleOverrun) {
        this.cutoffPerForScheduleOverrun = cutoffPerForScheduleOverrun;
    }

    public Float getCutoffPerForEffortOverrun() {
        return cutoffPerForEffortOverrun;
    }

    public void setCutoffPerForEffortOverrun(Float cutoffPerForEffortOverrun) {
        this.cutoffPerForEffortOverrun = cutoffPerForEffortOverrun;
    }

    public Float getCutoffPerDefectLeakage() {
        return cutoffPerDefectLeakage;
    }

    public void setCutoffPerDefectLeakage(Float cutoffPerDefectLeakage) {
        this.cutoffPerDefectLeakage = cutoffPerDefectLeakage;
    }

    public Float getCutoffPerBacklogIndex() {
        return cutoffPerBacklogIndex;
    }

    public void setCutoffPerBacklogIndex(Float cutoffPerBacklogIndex) {
        this.cutoffPerBacklogIndex = cutoffPerBacklogIndex;
    }

    public Integer getPmId() {
        return pmId;
    }

    public void setPmId(Integer pmId) {
        this.pmId = pmId;
    }

    public Date getPmModifiedOn() {
        return pmModifiedOn;
    }

    public void setPmModifiedOn(Date pmModifiedOn) {
        this.pmModifiedOn = pmModifiedOn;
    }

    public Integer getPhId() {
        return phId;
    }

    public void setPhId(Integer phId) {
        this.phId = phId;
    }

    public String getNotesByAH() {
        return notesByAH;
    }

    public void setNotesByAH(String notesByAH) {
        this.notesByAH = notesByAH;
    }

    public Integer getAhId() {
        return ahId;
    }

    public void setAhId(Integer ahId) {
        this.ahId = ahId;
    }

    public Date getAhModifiedOn() {
        return ahModifiedOn;
    }

    public void setAhModifiedOn(Date ahModifiedOn) {
        this.ahModifiedOn = ahModifiedOn;
    }

    public Date getPhModifiedOn() {
        return phModifiedOn;
    }

    public void setPhModifiedOn(Date phModifiedOn) {
        this.phModifiedOn = phModifiedOn;
    }

    public Integer getDhId() {
        return dhId;
    }

    public void setDhId(Integer dhId) {
        this.dhId = dhId;
    }

    public Date getDhModifiedOn() {
        return dhModifiedOn;
    }

    public void setDhModifiedOn(Date dhModifiedOn) {
        this.dhModifiedOn = dhModifiedOn;
    }

    public String getNotesByPH() {
        return notesByPH;
    }

    public void setNotesByPH(String notesByPH) {
        this.notesByPH = notesByPH;
    }

    public String getNotesByDH() {
        return notesByDH;
    }

    public void setNotesByDH(String notesByDH) {
        this.notesByDH = notesByDH;
    }
    
    //Transient 
    public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public Integer getpProjectId() {
		return pProjectId;
	}

	public void setpProjectId(Integer pProjectId) {
		this.pProjectId = pProjectId;
	}

	public Integer getProjectManagersId() {
		return projectManagersId;
	}

	public void setProjectManagersId(Integer projectManagersId) {
		this.projectManagersId = projectManagersId;
	}

	public String getProjectManager() {
		return projectManager;
	}

	public void setProjectManager(String projectManager) {
		this.projectManager = projectManager;
	}

	public Integer getPortfolioId() {
		return portfolioId;
	}

	public void setPortfolioId(Integer portfolioId) {
		this.portfolioId = portfolioId;
	}

	public Integer getpAccountId() {
		return pAccountId;
	}

	public void setpAccountId(Integer pAccountId) {
		this.pAccountId = pAccountId;
	}

	public String getPortfolioName() {
		return portfolioName;
	}

	public void setPortfolioName(String portfolioName) {
		this.portfolioName = portfolioName;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public String getDeProjectType() {
		return deProjectType;
	}

	public void setDeProjectType(String deProjectType) {
		this.deProjectType = deProjectType;
	}
	
	//Staff Aug
	public Integer getAssociateCountOffshore() {
		return associateCountOffshore;
	}

	public void setAssociateCountOffshore(Integer associateCountOffshore) {
		this.associateCountOffshore = associateCountOffshore;
	}

	public Integer getAssociateCountOnsite() {
		return associateCountOnsite;
	}

	public void setAssociateCountOnsite(Integer associateCountOnsite) {
		this.associateCountOnsite = associateCountOnsite;
	}

	public Integer getAssociateCountTotal() {
		return associateCountTotal;
	}

	public void setAssociateCountTotal(Integer associateCountTotal) {
		this.associateCountTotal = associateCountTotal;
	}

	public Integer getTotalPositionsCarryForward() {
		return totalPositionsCarryForward;
	}

	public void setTotalPositionsCarryForward(Integer totalPositionsCarryForward) {
		this.totalPositionsCarryForward = totalPositionsCarryForward;
	}

	public Integer getTotalPositionsOpened() {
		return totalPositionsOpened;
	}

	public void setTotalPositionsOpened(Integer totalPositionsOpened) {
		this.totalPositionsOpened = totalPositionsOpened;
	}

	public Integer getTotalPositions() {
		return totalPositions;
	}

	public void setTotalPositions(Integer totalPositions) {
		this.totalPositions = totalPositions;
	}

	public Integer getTotalPositionsStaffed() {
		return totalPositionsStaffed;
	}

	public void setTotalPositionsStaffed(Integer totalPositionsStaffed) {
		this.totalPositionsStaffed = totalPositionsStaffed;
	}

	public Integer getTotalInterViewsConducted() {
		return totalInterViewsConducted;
	}

	public void setTotalInterViewsConducted(Integer totalInterViewsConducted) {
		this.totalInterViewsConducted = totalInterViewsConducted;
	}

	public Integer getAvgTimeToStaff() {
		return avgTimeToStaff;
	}

	public void setAvgTimeToStaff(Integer avgTimeToStaff) {
		this.avgTimeToStaff = avgTimeToStaff;
	}

	public Float getStaffingIndex() {
		return staffingIndex;
	}

	public void setStaffingIndex(Float staffingIndex) {
		this.staffingIndex = staffingIndex;
	}

//	public Integer getNoOfComplaintsReceived() {
//		return noOfComplaintsReceived;
//	}
//
//	public void setNoOfComplaintsReceived(Integer noOfComplaintsReceived) {
//		this.noOfComplaintsReceived = noOfComplaintsReceived;
//	}
//
//	public Integer getNoOfAppreciationsReceived() {
//		return noOfAppreciationsReceived;
//	}
//
//	public void setNoOfAppreciationsReceived(Integer noOfAppreciationsReceived) {
//		this.noOfAppreciationsReceived = noOfAppreciationsReceived;
//	}

	public Integer getValueAdds() {
		return valueAdds;
	}

	public void setValueAdds(Integer valueAdds) {
		this.valueAdds = valueAdds;
	}

	public String getCsatScore() {
		return csatScore;
	}

	public void setCsatScore(String csatScore) {
		this.csatScore = csatScore;
	}

	public Integer getTimeToStaff() {
		return timeToStaff;
	}

	public void setTimeToStaff(Integer timeToStaff) {
		this.timeToStaff = timeToStaff;
	}

	public Float getNoInterviewsbeforefinalisation() {
		return noInterviewsbeforefinalisation;
	}

	public void setNoInterviewsbeforefinalisation(Float noInterviewsbeforefinalisation) {
		this.noInterviewsbeforefinalisation = noInterviewsbeforefinalisation;
	}

	public Float getRatioOfPositionStaffedVsOpen() {
		return ratioOfPositionStaffedVsOpen;
	}

	public void setRatioOfPositionStaffedVsOpen(Float ratioOfPositionStaffedVsOpen) {
		this.ratioOfPositionStaffedVsOpen = ratioOfPositionStaffedVsOpen;
	}

	public Integer getNoOfTicketsResponseTimeBreach() {
		return noOfTicketsResponseTimeBreach;
	}

	public void setNoOfTicketsResponseTimeBreach(Integer noOfTicketsResponseTimeBreach) {
		this.noOfTicketsResponseTimeBreach = noOfTicketsResponseTimeBreach;
	}

	public Integer getNoOfTicketsResolutionTimeBreach() {
		return noOfTicketsResolutionTimeBreach;
	}

	public void setNoOfTicketsResolutionTimeBreach(Integer noOfTicketsResolutionTimeBreach) {
		this.noOfTicketsResolutionTimeBreach = noOfTicketsResolutionTimeBreach;
	}

	public Float getTotaTeamCapacityInHours() {
		return totaTeamCapacityInHours;
	}

	public void setTotaTeamCapacityInHours(Float totaTeamCapacityInHours) {
		this.totaTeamCapacityInHours = totaTeamCapacityInHours;
	}

	public Integer getTotalHoursInvestedInTickets() {
		return totalHoursInvestedInTickets;
	}

	public void setTotalHoursInvestedInTickets(Integer totalHoursInvestedInTickets) {
		this.totalHoursInvestedInTickets = totalHoursInvestedInTickets;
	}

	public Integer getValueAdd_OptimizationsDelivered() {
		return valueAdd_OptimizationsDelivered;
	}

	public void setValueAdd_OptimizationsDelivered(Integer valueAdd_OptimizationsDelivered) {
		this.valueAdd_OptimizationsDelivered = valueAdd_OptimizationsDelivered;
	}
	
	public Integer getTotalTicketsReopened() {
		return totalTicketsReopened;
	}

	public void setTotalTicketsReopened(Integer totalTicketsReopened) {
		this.totalTicketsReopened = totalTicketsReopened;
	}

	public String getPortfolioNotes() {
		return portfolioNotes;
	}

	public void setPortfolioNotes(String portfolioNotes) {
		this.portfolioNotes = portfolioNotes;
	}

	public String getDeliveryNotes() {
		return deliveryNotes;
	}

	public void setDeliveryNotes(String deliveryNotes) {
		this.deliveryNotes = deliveryNotes;
	}

	public String getAccountNotes() {
		return accountNotes;
	}

	public void setAccountNotes(String accountNotes) {
		this.accountNotes = accountNotes;
	}
	
	public String getPortfolioHead() {
		return portfolioHead;
	}

	public void setPortfolioHead(String portfolioHead) {
		this.portfolioHead = portfolioHead;
	}
	
	public Integer getAssociatesCount() {
		return associatesCount;
	}

	public void setAssociatesCount(Integer associatesCount) {
		this.associatesCount = associatesCount;
	}

	public Integer getBillableCount() {
		return billableCount;
	}

	public void setBillableCount(Integer billableCount) {
		this.billableCount = billableCount;
	}

	public Integer getNonBillableCount() {
		return nonBillableCount;
	}

	public void setNonBillableCount(Integer nonBillableCount) {
		this.nonBillableCount = nonBillableCount;
	}

	public Integer getOffshoreCount() {
		return offshoreCount;
	}

	public void setOffshoreCount(Integer offshoreCount) {
		this.offshoreCount = offshoreCount;
	}

	public Integer getOnsiteCount() {
		return onsiteCount;
	}

	public void setOnsiteCount(Integer onsiteCount) {
		this.onsiteCount = onsiteCount;
	}

	public Boolean getAhApproved() {
		return ahApproved;
	}

	public void setAhApproved(Boolean ahApproved) {
		this.ahApproved = ahApproved;
	}

	public Boolean getPhApproved() {
		return phApproved;
	}

	public void setPhApproved(Boolean phApproved) {
		this.phApproved = phApproved;
	}

	public Boolean getDhApproved() {
		return dhApproved;
	}

	public void setDhApproved(Boolean dhApproved) {
		this.dhApproved = dhApproved;
	}

	public Float getTotalFTE() {
		return totalFTE;
	}

	public void setTotalFTE(Float totalFTE) {
		this.totalFTE = totalFTE;
	}

	public String getNotesByDE() {
		return notesByDE;
	}

	public void setNotesByDE(String notesByDE) {
		this.notesByDE = notesByDE;
	}

	public Date getDeModifiedOn() {
		return deModifiedOn;
	}

	public void setDeModifiedOn(Date deModifiedOn) {
		this.deModifiedOn = deModifiedOn;
	}

	public Integer getDeId() {
		return deId;
	}

	public void setDeId(Integer deId) {
		this.deId = deId;
	}
	


	public Integer getPortfolioHeadId() {
		return portfolioHeadId;
	}

	public void setPortfolioHeadId(Integer portfolioHeadId) {
		this.portfolioHeadId = portfolioHeadId;
	}	
	
	public Integer getAccountHeadId() {
		return accountHeadId;
	}

	public void setAccountHeadId(Integer accountHeadId) {
		this.accountHeadId = accountHeadId;
	}
	
	public Integer getCloseActionItem() {
		return closeActionItem;
	}

	public void setCloseActionItem(Integer closeActionItem) {
		this.closeActionItem = closeActionItem;
	}

	public Integer getOnHoldActionItem() {
		return onHoldActionItem;
	}

	public void setOnHoldActionItem(Integer onHoldActionItem) {
		this.onHoldActionItem = onHoldActionItem;
	}

	public Integer getOpenActionItem() {
		return openActionItem;
	}

	public void setOpenActionItem(Integer openActionItem) {
		this.openActionItem = openActionItem;
	}

	public Integer getTotalActionItem() {
		return totalActionItem;
	}

	public void setTotalActionItem(Integer totalActionItem) {
		this.totalActionItem = totalActionItem;
	}

	public Integer getKnowledgeSkillsScore() {
		return knowledgeSkillsScore;
	}

	public void setKnowledgeSkillsScore(Integer knowledgeSkillsScore) {
		this.knowledgeSkillsScore = knowledgeSkillsScore;
	}

	public Integer getResponsivenessScore() {
		return responsivenessScore;
	}

	public void setResponsivenessScore(Integer responsivenessScore) {
		this.responsivenessScore = responsivenessScore;
	}

	public Integer getQualityScore() {
		return qualityScore;
	}

	public void setQualityScore(Integer qualityScore) {
		this.qualityScore = qualityScore;
	}

	public Integer getDeliverResultScore() {
		return deliverResultScore;
	}

	public void setDeliverResultScore(Integer deliverResultScore) {
		this.deliverResultScore = deliverResultScore;
	}

	public String getAccountHead() {
		return accountHead;
	}

	public void setAccountHead(String accountHead) {
		this.accountHead = accountHead;
	}

	public String getClient() {
		return client;
	}

	public void setClient(String client) {
		this.client = client;
	}


	public Date getProjectStartDate() {
		return projectStartDate;
	}

	public void setProjectStartDate(Date projectStartDate) {
		this.projectStartDate = projectStartDate;
	}

	public Date getProjectEndDate() {
		return projectEndDate;
	}

	public void setProjectEndDate(Date projectEndDate) {
		this.projectEndDate = projectEndDate;
	}

	//Constructor
	public DeGovernance(Integer itemId, String projectType, Date projectMetricsForDate, Integer projectId,
			Integer accountId, Integer totalAssociates, Float projectedRevenueForMonth, Float actualRevenueForMonth,
			Float percentageRevenueAchievedForMonth, Float effortVariance, Integer totalInternalDefect,
			Integer totalExternalDefect, Float defectLeakage, Float defectDensity, String peopleRisk,
			String peopleRiskDescription, String customerFeedback, String customerFeedbackDescription,
			String executionRisk, String executionRiskDescription, Integer totalTasksReceived,
			Integer tasksWithScheduleOverrun, Float percentageScheduleOverrun, Integer tasksWithEffortOverrun,
			Float percentageEffortOverrun, Float totalHoursSpent, Float totalHoursEstimated,
			Float actualHoursSpent, Float scheduleVariance, Integer totalTicketsReceived,
			Integer totalTicketsDelivered, Integer totalTicketsCarriedForward,Integer totalTicketsCarriedForwardPrev, Float responseSLA, Float resolutionSLA,
			Float capacityUtilization, Float avgTimeToResolve, Float firstTimeRight, Float backlogIndex,
			String notesByPM, String notesByPH, Boolean tbdInDeliveryReview, String notesByAH, String notesByDH,
			Float cutoffPerForScheduleOverrun, Float cutoffPerForEffortOverrun, Float cutoffPerDefectLeakage,
			Float cutoffPerBacklogIndex, Integer pmId, Date pmModifiedOn, Integer phId, Date phModifiedOn, Integer ahId,
			Date ahModifiedOn, Integer dhId, Date dhModifiedOn,
			 Integer associateCountOnsite, Integer associateCountTotal,
			Integer totalPositionsCarryForward, Integer totalPositionsOpened, Integer totalPositions,Integer totalPositionsStaffed,
			Integer totalInterViewsConducted,Integer avgTimeToStaff,Float staffingIndex,Integer valueAdds,String csatScore,Integer timeToStaff,Float noInterviewsbeforefinalisation,
			Float ratioOfPositionStaffedVsOpen, Integer knowledgeSkillsScore, Integer responsivenessScore, Integer qualityScore, Integer deliverResultScore, 
			String projectName, Integer pProjectId, Integer projectManagersId,String projectManager,
			Integer portfolioId, Integer pAccountId, String portfolioName, String portfolioHead, String deProjectType, String accountName,Integer associateCountOffshore,
			Integer noOfTicketsResponseTimeBreach, Integer noOfTicketsResolutionTimeBreach, Float totaTeamCapacityInHours,Integer totalHoursInvestedInTickets,
			Integer totalTicketsReopened, Integer valueAdd_OptimizationsDelivered,
			String portfolioNotes, String deliveryNotes, String accountNotes,Integer associatesCount,Integer billableCount, Integer nonBillableCount, Integer offshoreCount,
			Integer onsiteCount, Boolean ahApproved, Boolean phApproved, Boolean dhApproved, Float totalFTE, String notesByDE, Date deModifiedOn, Integer deId, Integer portfolioHeadId, Integer accountHeadId,
			Integer closeActionItem, Integer openActionItem, Integer onHoldActionItem, Integer totalActionItem, String accountHead, String client, Date  projectStartDate, Date projectEndDate) {
		super();
		this.itemId = itemId;
		this.projectType = projectType;
		this.projectMetricsForDate = projectMetricsForDate;
		this.projectId = projectId;
		this.accountId = accountId;
		this.totalAssociates = totalAssociates;
		this.projectedRevenueForMonth = projectedRevenueForMonth;
		this.actualRevenueForMonth = actualRevenueForMonth;
		this.percentageRevenueAchievedForMonth = percentageRevenueAchievedForMonth;
		this.effortVariance = effortVariance;
		this.totalInternalDefect = totalInternalDefect;
		this.totalExternalDefect = totalExternalDefect;
		this.defectLeakage = defectLeakage;
		this.defectDensity = defectDensity;
		this.peopleRisk = peopleRisk;
		this.peopleRiskDescription = peopleRiskDescription;
		this.customerFeedback = customerFeedback;
		this.customerFeedbackDescription = customerFeedbackDescription;
		this.executionRisk = executionRisk;
		this.executionRiskDescription = executionRiskDescription;
		this.totalTasksReceived = totalTasksReceived;
		this.tasksWithScheduleOverrun = tasksWithScheduleOverrun;
		this.percentageScheduleOverrun = percentageScheduleOverrun;
		this.tasksWithEffortOverrun = tasksWithEffortOverrun;
		this.percentageEffortOverrun = percentageEffortOverrun;
		this.totalHoursSpent = totalHoursSpent;
		this.totalHoursEstimated = totalHoursEstimated;
		this.actualHoursSpent = actualHoursSpent;
		this.scheduleVariance = scheduleVariance;
		this.totalTicketsReceived = totalTicketsReceived;
		this.totalTicketsDelivered = totalTicketsDelivered;
		this.totalTicketsCarriedForward = totalTicketsCarriedForward;
		this.totalTicketsCarriedForwardPrev = totalTicketsCarriedForwardPrev;
		this.responseSLA = responseSLA;
		this.resolutionSLA = resolutionSLA;
		this.capacityUtilization = capacityUtilization;
		this.avgTimeToResolve = avgTimeToResolve;
		this.firstTimeRight = firstTimeRight;
		this.backlogIndex = backlogIndex;
		this.notesByPM = notesByPM;
		this.notesByPH = notesByPH;
		this.tbdInDeliveryReview = tbdInDeliveryReview;
		this.notesByAH = notesByAH;
		this.notesByDH = notesByDH;
		this.cutoffPerForScheduleOverrun = cutoffPerForScheduleOverrun;
		this.cutoffPerForEffortOverrun = cutoffPerForEffortOverrun;
		this.cutoffPerDefectLeakage = cutoffPerDefectLeakage;
		this.cutoffPerBacklogIndex = cutoffPerBacklogIndex;
		this.pmId = pmId;
		this.pmModifiedOn = pmModifiedOn;
		this.phId = phId;
		this.phModifiedOn = phModifiedOn;
		this.ahId = ahId;
		this.ahModifiedOn = ahModifiedOn;
		this.dhId = dhId;
		this.dhModifiedOn = dhModifiedOn;
		
		this.associateCountOffshore = associateCountOffshore;
		this.associateCountOnsite = associateCountOnsite;
		this.associateCountTotal = associateCountTotal;
		this.totalPositionsCarryForward = totalPositionsCarryForward;
		this.totalPositionsOpened = totalPositionsOpened;
		this.totalPositions = totalPositions;
		this.totalPositionsStaffed = totalPositionsStaffed;
		this.totalInterViewsConducted = totalInterViewsConducted;
		this.avgTimeToStaff= avgTimeToStaff;
		this.staffingIndex = staffingIndex;
//		this.noOfComplaintsReceived = noOfComplaintsReceived;
//		this.noOfAppreciationsReceived = noOfAppreciationsReceived;
		this.valueAdds = valueAdds;
		this.csatScore = csatScore;
		this.timeToStaff = timeToStaff;
		this.noInterviewsbeforefinalisation = noInterviewsbeforefinalisation;
		this.ratioOfPositionStaffedVsOpen = ratioOfPositionStaffedVsOpen;
		this.knowledgeSkillsScore = knowledgeSkillsScore;
		this.responsivenessScore = responsivenessScore;
		this.qualityScore = qualityScore;
		this.deliverResultScore = deliverResultScore;
		
		this.projectName = projectName;
		this.pProjectId = pProjectId;
		this.projectManagersId = projectManagersId;
		this.projectManager = projectManager;
		this.portfolioId = portfolioId;
		this.pAccountId = pAccountId;
		this.portfolioName = portfolioName;
		this.portfolioHead = portfolioHead;
		this.accountName = accountName;
		this.deProjectType = deProjectType;
		
		this.noOfTicketsResponseTimeBreach = noOfTicketsResponseTimeBreach;
		this.noOfTicketsResolutionTimeBreach = noOfTicketsResolutionTimeBreach;	
		this.totaTeamCapacityInHours = totaTeamCapacityInHours;
		this.totalHoursInvestedInTickets = totalHoursInvestedInTickets;
		this.totalTicketsReopened = totalTicketsReopened;
		this.valueAdd_OptimizationsDelivered = valueAdd_OptimizationsDelivered;
		this.associatesCount = associatesCount;
		
		this.billableCount = billableCount;
		this.nonBillableCount = nonBillableCount;
		this.offshoreCount = offshoreCount;
		this.onsiteCount = onsiteCount;
		
		this.ahApproved = ahApproved;
		this.ahApproved = phApproved;
		this.ahApproved = dhApproved;
		this.totalFTE = totalFTE;		
		this.notesByDE = notesByDE;
		this.deModifiedOn = deModifiedOn;
		this.deId = deId;		
		this.portfolioHeadId = portfolioHeadId;		
		this.accountHeadId = accountHeadId;
		this.closeActionItem = closeActionItem;
		this.openActionItem = openActionItem;
		this.onHoldActionItem = onHoldActionItem;
		this.totalActionItem = totalActionItem;
		this.accountHead = accountHead;
		this.client = client;
		this.projectStartDate = projectStartDate;
		this.projectEndDate = projectEndDate;

		
	}

	public DeGovernance(Float projectedRevenueForMonth,Float actualRevenueForMonth, Float percentageRevenueAchievedForMonth, Float effortVariance,
			Float defectLeakage, Float defectDensity, Float percentageScheduleOverrun, Float percentageEffortOverrun,
			Float responseSLA, Float resolutionSLA, Float capacityUtilization, Float avgTimeToResolve,
			Float firstTimeRight, Float backlogIndex, Integer avgTimeToStaff, Float noInterviewsbeforefinalisation,
			Float ratioOfPositionStaffedVsOpen, Integer totalTasksReceived,Integer tasksWithScheduleOverrun,
			Integer tasksWithEffortOverrun, Float totaTeamCapacityInHours, Float totalHoursEstimated, Float totalHoursSpent,Float actualHoursSpent, 
			Integer totalInternalDefect, Integer totalExternalDefect,Integer totalTicketsReceived, Integer totalTicketsDelivered, Integer totalTicketsCarriedForward, 
			Integer totalTicketsCarriedForwardPrev,	Integer noOfTicketsResponseTimeBreach, Integer noOfTicketsResolutionTimeBreach,
			Integer totalHoursInvestedInTickets, Integer totalTicketsReopened, Integer valueAdd_OptimizationsDelivered ) {
		super();
		this.projectedRevenueForMonth = projectedRevenueForMonth;
		this.actualRevenueForMonth = actualRevenueForMonth;
		this.percentageRevenueAchievedForMonth = percentageRevenueAchievedForMonth;
		this.effortVariance = effortVariance;
		this.defectLeakage = defectLeakage;
		this.defectDensity = defectDensity;
		this.percentageScheduleOverrun = percentageScheduleOverrun;
		this.percentageEffortOverrun = percentageEffortOverrun;
		this.responseSLA = responseSLA;
		this.resolutionSLA = resolutionSLA;
		this.capacityUtilization = capacityUtilization;
		this.avgTimeToResolve = avgTimeToResolve;
		this.firstTimeRight = firstTimeRight;
		this.backlogIndex = backlogIndex;
		this.avgTimeToStaff = avgTimeToStaff;
		this.noInterviewsbeforefinalisation = noInterviewsbeforefinalisation;
		this.ratioOfPositionStaffedVsOpen = ratioOfPositionStaffedVsOpen;
		this.totalTasksReceived=totalTasksReceived;
		this.tasksWithScheduleOverrun=tasksWithScheduleOverrun;
		this.tasksWithEffortOverrun=tasksWithEffortOverrun;
		this.totaTeamCapacityInHours=totaTeamCapacityInHours;
		this.totalHoursEstimated=totalHoursEstimated;
		this.totalHoursSpent=totalHoursSpent;
		this.actualHoursSpent=actualHoursSpent;		
		this.totalInternalDefect=totalInternalDefect;
		this.totalExternalDefect=totalExternalDefect;
		
		this.totalTicketsReceived = totalTicketsReceived;
		this.totalTicketsDelivered = totalTicketsDelivered;
		this.totalTicketsCarriedForward = totalTicketsCarriedForward;
		this.totalTicketsCarriedForwardPrev = totalTicketsCarriedForwardPrev;
		this.noOfTicketsResponseTimeBreach = noOfTicketsResponseTimeBreach;
		this.noOfTicketsResolutionTimeBreach = noOfTicketsResolutionTimeBreach;	
		this.totalHoursInvestedInTickets = totalHoursInvestedInTickets;
		this.totalTicketsReopened = totalTicketsReopened;
		this.valueAdd_OptimizationsDelivered = valueAdd_OptimizationsDelivered;
	}

	@Override
    public String toString() {
        return "DeGovernance{" +
                "itemId=" + itemId +
                ", projectType='" + projectType + '\'' +
                ", projectMetricsForDate=" + projectMetricsForDate +
                ", projectId=" + projectId +
                ", accountId=" + accountId +
                ", totalAssociates=" + totalAssociates +
                ", projectedRevenueForMonth=" + projectedRevenueForMonth +
                ", actualRevenueForMonth=" + actualRevenueForMonth +
                ", percentageRevenueAchievedForMonth=" + percentageRevenueAchievedForMonth +
                ", effortVariance=" + effortVariance +
                ", totalInternalDefect=" + totalInternalDefect +
                ", totalExternalDefect=" + totalExternalDefect +
                ", defectLeakage=" + defectLeakage +
                ", defectDensity=" + defectDensity +
                ", peopleRisk='" + peopleRisk + '\'' +
                ", peopleRiskDescription='" + peopleRiskDescription + '\'' +
                ", customerFeedback='" + customerFeedback + '\'' +
                ", customerFeedbackDescription='" + customerFeedbackDescription + '\'' +
                ", executionRisk='" + executionRisk + '\'' +
                ", executionRiskDescription='" + executionRiskDescription + '\'' +
                ", totalTasksReceived=" + totalTasksReceived +
                ", tasksWithScheduleOverrun=" + tasksWithScheduleOverrun +
                ", percentageScheduleOverrun=" + percentageScheduleOverrun +
                ", tasksWithEffortOverrun=" + tasksWithEffortOverrun +
                ", percentageEffortOverrun=" + percentageEffortOverrun +
                ", totalHoursSpent=" + totalHoursSpent +
                ", totalHoursEstimated=" + totalHoursEstimated +
                ", actualHoursSpent=" + actualHoursSpent +
                ", scheduleVariance=" + scheduleVariance +
                ", totalTicketsReceived=" + totalTicketsReceived +
                ", totalTicketsDelivered=" + totalTicketsDelivered +
                ", totalTicketsCarriedForward=" + totalTicketsCarriedForward +
                ", responseSLA=" + responseSLA +
                ", resolutionSLA=" + resolutionSLA +
                ", capacityUtilization=" + capacityUtilization +
                ", avgTimeToResolve=" + avgTimeToResolve +
                ", firstTimeRight=" + firstTimeRight +
                ", backlogIndex=" + backlogIndex +
                ", notesByPM='" + notesByPM + '\'' +
                ", notesByPH='" + notesByPH + '\'' +
                ", tbdInDeliveryReview=" + tbdInDeliveryReview +
                ", notesByAH='" + notesByAH + '\'' +
                ", notesByDH='" + notesByDH + '\'' +
                ", cutoffPerForScheduleOverrun=" + cutoffPerForScheduleOverrun +
                ", cutoffPerForEffortOverrun=" + cutoffPerForEffortOverrun +
                ", cutoffPerDefectLeakage=" + cutoffPerDefectLeakage +
                ", cutoffPerBacklogIndex=" + cutoffPerBacklogIndex +
                ", pmId=" + pmId +
                ", pmModifiedOn=" + pmModifiedOn +
                ", phId=" + phId +
                ", phModifiedOn=" + phModifiedOn +
                ", ahId=" + ahId +
                ", ahModifiedOn=" + ahModifiedOn +
                ", dhId=" + dhId +
                ", dhModifiedOn=" + dhModifiedOn +
                '}';
    }
}
