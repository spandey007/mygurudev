package com.infocepts.otc.entities;

import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.Table;
import com.infocepts.otc.utilities.LoadConstant;
//import com.infocepts.otc.utilities.QueryConstant;


@Entity
@Table(catalog=LoadConstant.otc, schema="[dbo]",name="invoicesReceipt")
@SqlResultSetMapping(
	      name = "reciept_for_invoices",
	      classes = {
	          @ConstructorResult(
	              targetClass = InvoicesReceipt.class,
	              columns = {
	            	  @ColumnResult(name = "invoiceReceiptID"),
	            	  @ColumnResult(name = "arReceiptID"),
	                  @ColumnResult(name = "invoiceId"),
	                  @ColumnResult(name = "projectId"),
	                  @ColumnResult(name = "paymentTermDays"),
	                  @ColumnResult(name = "estimatedDueDate", type=Date.class),
	                  @ColumnResult(name = "receiptType"),
	                  @ColumnResult(name = "receiptDate", type=Date.class),
	                  @ColumnResult(name = "depositDate", type=Date.class),
	                  @ColumnResult(name = "amountReceived", type=BigDecimal.class),
	                  @ColumnResult(name = "chequeNo"),
	                  @ColumnResult(name = "paymentMode"),
	                  @ColumnResult(name = "createdDate", type=Date.class),
	                  @ColumnResult(name = "modifiedDate", type=Date.class),
	                  @ColumnResult(name = "comments"),
	            	  @ColumnResult(name = "createdBy"),
	                  @ColumnResult(name = "modifiedBy"),
	                  @ColumnResult(name = "arSubmitDate")
	                }
	          )
	      }
	)
public class InvoicesReceipt {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer invoiceReceiptID;
	
	private String arReceiptID;//for migration
	
	private Integer invoiceId;
	private Integer projectId;
	private Integer paymentTermDays;
	private Date estimatedDueDate;
	private String receiptType;
	private Date receiptDate;
	private Date depositDate;
	
	@Column(precision=12,scale=2)
	private BigDecimal amountReceived;
	
	private String chequeNo;
	private String paymentMode;
	private Date createdDate;
	private Date modifiedDate;
	private String comments;
	private Integer createdBy;
	private Integer modifiedBy;
	//only required for migration
	private String arInvoiceId;
	private String clientName;
	private String invoiceNo;
	private Date arSubmitDate;
	public Integer getInvoiceReceiptID() {
		return invoiceReceiptID;
	}
	public void setInvoiceReceiptID(Integer invoiceReceiptID) {
		this.invoiceReceiptID = invoiceReceiptID;
	}
	public String getArReceiptID() {
		return arReceiptID;
	}
	public void setArReceiptID(String arReceiptID) {
		this.arReceiptID = arReceiptID;
	}
	public Integer getInvoiceId() {
		return invoiceId;
	}
	public void setInvoiceId(Integer invoiceId) {
		this.invoiceId = invoiceId;
	}
	public Integer getProjectId() {
		return projectId;
	}
	public void setProjectId(Integer projectId) {
		this.projectId = projectId;
	}
	public Integer getPaymentTermDays() {
		return paymentTermDays;
	}
	public void setPaymentTermDays(Integer paymentTermDays) {
		this.paymentTermDays = paymentTermDays;
	}
	public Date getEstimatedDueDate() {
		return estimatedDueDate;
	}
	public void setEstimatedDueDate(Date estimatedDueDate) {
		this.estimatedDueDate = estimatedDueDate;
	}
	public String getReceiptType() {
		return receiptType;
	}
	public void setReceiptType(String receiptType) {
		this.receiptType = receiptType;
	}
	public Date getReceiptDate() {
		return receiptDate;
	}
	public void setReceiptDate(Date receiptDate) {
		this.receiptDate = receiptDate;
	}
	public Date getDepositDate() {
		return depositDate;
	}
	public void setDepositDate(Date depositDate) {
		this.depositDate = depositDate;
	}
	public BigDecimal getAmountReceived() {
		return amountReceived;
	}
	public void setAmountReceived(BigDecimal amountReceived) {
		this.amountReceived = amountReceived;
	}
	public String getChequeNo() {
		return chequeNo;
	}
	public void setChequeNo(String chequeNo) {
		this.chequeNo = chequeNo;
	}
	public String getPaymentMode() {
		return paymentMode;
	}
	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public Date getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public Integer getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}
	public Integer getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public String getArInvoiceId() {
		return arInvoiceId;
	}
	public void setArInvoiceId(String arInvoiceId) {
		this.arInvoiceId = arInvoiceId;
	}
	public String getClientName() {
		return clientName;
	}
	public void setClientName(String clientName) {
		this.clientName = clientName;
	}
	public String getInvoiceNo() {
		return invoiceNo;
	}
	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}
	/**
	 * @return the arSubmitDate
	 */
	public Date getArSubmitDate() {
		return arSubmitDate;
	}
	/**
	 * @param arSubmitDate the arSubmitDate to set
	 */
	public void setArSubmitDate(Date arSubmitDate) {
		this.arSubmitDate = arSubmitDate;
	}
}

