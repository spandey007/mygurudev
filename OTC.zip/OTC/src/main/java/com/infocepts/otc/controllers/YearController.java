/* 
 * Year Controller to manage years
 * -------------------------------------------------------------------------------------------------------------------------
 * 31 Aug 2017 - VK creation of the file
 * 7 Sept 2017 - RK review modification for a reference master
*/
package com.infocepts.otc.controllers;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.infocepts.otc.entities.Year;
import com.infocepts.otc.repositories.YearRepository;
import com.infocepts.otc.services.TimesheetService;

@RestController
@RequestMapping(value="/years",headers="referer")
public class YearController {

	final Logger logger = Logger.getLogger(YearController.class);
	
	@Autowired
	YearRepository repository;
	
	@Autowired
	TimesheetService service;
	
	@RequestMapping(method=RequestMethod.POST)
	public Year addYear(@RequestBody Year year)
	{
		try{
			if(service.isPmo()){
				year.setYearId(null);
				repository.save(year);	
			}
		}catch(Exception e){
			logger.error(e);
		}
		return year;
	}	
 
	 @RequestMapping(method=RequestMethod.GET)
	 public List<Year> getAllYear(@RequestParam(value="status",defaultValue="false") Boolean status,
			 @RequestParam(value="yearId",defaultValue="0") Integer yearId,
			 @RequestParam(value="year",defaultValue="0") Integer year){
		 List<Year> yearlist=null;
		 try{
			 	 //visible to all permissions
				 if(status == true){
					 yearlist = repository.findByYearStatus(true);
				 }
				 else if(yearId != 0){
					 yearlist = repository.findByYearId(yearId);
				 }
				 else if(year!=0){
					 yearlist = repository.findByYear(year);
				 }
				 else{
					 yearlist = repository.findAll();
				 }
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return yearlist;
	 }
	 
	 @RequestMapping(value="/{yearId}",method=RequestMethod.PUT)
	 public Year updateYear(@RequestBody Year updatedYear,@PathVariable Integer yearId){
		 try{
			 if(service.isPmo()){
				 updatedYear.setYearId(yearId);
				 repository.save(updatedYear);
			 }				 
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return updatedYear;
	 }
	 
	 @RequestMapping(value="/{yearId}",method=RequestMethod.DELETE)
	 public void deleteYear(@PathVariable Integer yearId){
		 try{
			 if(service.isPmo()){
				 repository.delete(yearId);
			 }
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
	 }
	 
	 @GetMapping("/getActiveYears")
		public List<Year> getActiveYears(@RequestParam(value="status",defaultValue="false") Boolean status,
											HttpServletRequest request) {
		    List<Year> yearlist=null;
		    yearlist = repository.findByYearStatus(true);
			return yearlist;

		}
}
