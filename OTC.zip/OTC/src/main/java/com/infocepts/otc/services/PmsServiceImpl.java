package com.infocepts.otc.services;

import java.util.HashMap;
import java.util.function.Predicate;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.mail.MessagingException;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;
import org.thymeleaf.context.Context;

import com.infocepts.otc.controllers.CT_CompetencyController;
import com.infocepts.otc.controllers.CT_GradeWiseMappingController;
import com.infocepts.otc.controllers.ResourceController;
import com.infocepts.otc.controllers.SkillController;
import com.infocepts.otc.entities.CT_Competency;
import com.infocepts.otc.entities.Resource;
import com.infocepts.otc.entities.Skill;
import com.infocepts.otc.entities.Year;
import com.infocepts.otc.notification.SmtpMailSender;
import com.infocepts.otc.repositories.YearRepository;
import com.infocepts.otc.utilities.LoadConstant;
import com.infocepts.pms.entities.PmsCycle;
import com.infocepts.pms.entities.PmsIldp;
import com.infocepts.pms.entities.PmsPerformance;
import com.infocepts.pms.entities.PmsResource;
import com.infocepts.pms.repositories.PmsCycleRepository;
import com.infocepts.pms.repositories.PmsDepartmentMappingRepository;
import com.infocepts.pms.repositories.PmsGradeMappingRepository;
import com.infocepts.pms.repositories.PmsPerformanceRepository;
import com.infocepts.pms.repositories.PmsResourceRepository;

@Component
public class PmsServiceImpl implements PmsService {

	final Logger logger = Logger.getLogger(PmsServiceImpl.class.getName());
	
	@Autowired
	public PmsGradeMappingRepository gradeMappingRepository;
	
	@Autowired
	public PmsDepartmentMappingRepository departmentMappingRepository;
	
	@Autowired
	public PmsCycleRepository pmsCycleRepository;
	
	@Autowired
	public PmsPerformanceRepository pmsPerformanceRepository;
	
	@Autowired
	PmsResourceRepository pmsResourceRepository;
	
	@PersistenceContext(unitName = "otc")
	private EntityManager entityManager;
	
	@Autowired
	ResourceController resourceController;
	
	@Autowired
	SkillController skillController;

	@Autowired
	CT_CompetencyController competencyController;
	
	@Autowired
	CT_GradeWiseMappingController gradeWiseMappingController;
	
	@Autowired
	public YearRepository yearRepository;
	
	@Autowired
	private SmtpMailSender smtpMailSender;
	
	@Override
	@Transactional
	public void DeleteGradeMapping(Integer goalClusterId) {		
		
		gradeMappingRepository.deleteGradeMapping(goalClusterId,1);
	}
	
	@Override
	@Transactional
	public void DeleteDepartmentMapping(Integer goalClusterId) {		
		
		departmentMappingRepository.deleteDepartmentMapping(goalClusterId,1);
	}
	
	@Override
	public  HashMap<String, String> getUserTypeAndPhase(Integer performanceId, Integer uid) {
		
		HashMap<String, String> result = new HashMap<>();
		
		PmsPerformance performance = pmsPerformanceRepository.findOne(performanceId);
		
		PmsResource pmsResource = pmsResourceRepository.findResourceById(performance.getUid());

		PmsCycle cycle = pmsCycleRepository.findOne(performance.getCycle().getCycleId());
		
		//Set the User Type
		if(performance.getUid().equals(uid))
			result.put("userType", "Associate");
		else if(pmsResource.getPmsManagerId().equals(uid))		
			result.put("userType", "Manager");
		else if(pmsResource.getPmsReviewerId().equals(uid))		
			result.put("userType", "Reviewer");
		else	
			result.put("userType", "HR");
		
		//Set the PMS Phase
		if(cycle.getStatus().equals("Not Initiated"))
			result.put("phase", "Not Initiated");
		if(cycle.getStatus().equals("Handshake In-Progress"))
			result.put("phase", "Handshake");
		if(cycle.getStatus().equals("Handshake Completed"))
			result.put("phase", "Handshake Completed");
		if(cycle.getStatus().equals("Pit-Stop In-Progress"))
			result.put("phase", "Pitstop");
		if(cycle.getStatus().equals("Pit-Stop Completed"))
			result.put("phase", "Pitstop Completed");
		if(cycle.getStatus().equals("Evaluation In-Progress"))
			result.put("phase", "Evaluation");
		if(cycle.getStatus().equals("Evaluation Completed"))
			result.put("phase", "Evaluation Completed");
		
		return result;
	}

	public boolean sendPMSNotification(PmsPerformance pmsPerformanceList, String phase, HttpServletRequest request)  throws MessagingException {

			String subject = "InfoBiz | PMS";
			String template = "mail/pms";
			String fromEmail = LoadConstant.PMS_INFO;
			String associateName = "";
			String managerName = "";
			String reviewerName = "";
			String associateEmail = "";
			String managerEmail = "";
			String reviewerEmail = "";
			String toEmail = "";
			String message = "";
			String ccEmails = "";
			Integer cycleYear = 0;
	 		String appropriateLetter  = "Dear";
			Resource manager = null;
	 		Resource associate= null;
	 		Resource reviewer= null;
	 		Year year= null;
	 		PmsResource pmsResourceObject = null;
	 		
	        Context context = new Context();  
	        
	     // individual form Unlock workflow - check PmsResource object to check cycle and enable Phase
    		Boolean flagHandshake = false;
    		Boolean flagPitstop = false;
    		Boolean flagEvaluation = false;
	    	
	    if(pmsPerformanceList !=null) {
	    	

		    //get manager and reviewer from pmsResource
		    pmsResourceObject = pmsResourceRepository.findResourceById(pmsPerformanceList.getUid());
		    
		    if(pmsResourceObject != null) {
		    	if(pmsResourceObject.getEnableHandshake() && (pmsResourceObject.getEnableHandshakeCycle() == pmsPerformanceList.getCycle().getCycleId())) {
		    		flagHandshake = true;
		    	}
		    	else if(pmsResourceObject.getEnablePitstop() && (pmsResourceObject.getEnablePitstopCycle() == pmsPerformanceList.getCycle().getCycleId())) {
		    		flagPitstop = true;
		    	}
		    	else if(pmsResourceObject.getEnableEvaluation() && (pmsResourceObject.getEnableEvaluationCycle() == pmsPerformanceList.getCycle().getCycleId())) {
		    		flagEvaluation = true;
		    	}
		    }	
	    	
			if(pmsPerformanceList.getUid() !=null && pmsPerformanceList.getUid() !=0) {
				associate = resourceController.findResource(pmsPerformanceList.getUid());
				if(associate != null) {
					associateEmail = associate.getEmail();
					associateName = associate.getTitle();
				}
			}
			
			if(pmsResourceObject.getPmsManagerId() !=null && pmsResourceObject.getPmsManagerId() !=0) {
				manager = resourceController.findResource(pmsResourceObject.getPmsManagerId());
				if(manager !=null) {
					managerEmail = manager.getEmail();
					managerName = manager.getTitle();
				}
			}
			
			if(pmsResourceObject.getPmsReviewerId() !=null && pmsResourceObject.getPmsReviewerId() !=0) {
				reviewer = resourceController.findResource(pmsResourceObject.getPmsReviewerId());
				if(reviewer != null) {
					reviewerEmail = reviewer.getEmail();
					reviewerName = reviewer.getTitle();
				}
			}
			
			if(pmsPerformanceList.getCycle() !=null) {
				year = yearRepository.findOne(pmsPerformanceList.getCycle().getYearId());
				subject = subject.concat(" | "+year.getYear());
				
			}
			
			if(phase != null && !phase.equals("")){
				
				
				if(phase.equals("Handshake") || flagHandshake) {
					subject = subject.concat(" | Handshake");
					phase = "Handshake";
					
					if(pmsPerformanceList.getFormStatusGoalsetting() == 10) {
						subject = subject.concat(" | "+"Goals submitted By "+associateName);
						message = associateName+" has submitted the performance "+phase.toLowerCase()+" form for your review.";
						appropriateLetter = appropriateLetter.concat(" "+managerName);
						toEmail = managerEmail;
						ccEmails = associateEmail+','+reviewerEmail+','+LoadConstant.BPHR;
					}else if(pmsPerformanceList.getFormStatusGoalsetting() == 20) {
						subject = subject.concat(" | "+"Goals Rejected By "+managerName);
						message = managerName+" has rejected the goals initiated by you.";
						appropriateLetter = appropriateLetter.concat(" "+associateName);
						toEmail = associateEmail;
						ccEmails = managerEmail+','+reviewerEmail+','+LoadConstant.BPHR;
					}else if(pmsPerformanceList.getFormStatusGoalsetting() == 25) {
						subject = subject.concat(" | "+"Goals Approved By "+managerName);
						message = managerName+" has approved the goals initiated by you.";
						toEmail = associateEmail;
						appropriateLetter = appropriateLetter.concat(" "+associateName);
						ccEmails = managerEmail+','+reviewerEmail+','+LoadConstant.BPHR;
					}
				}else if(phase.equals("Pitstop") || flagPitstop) {
					subject = subject.concat(" | Pit-Stop");
					phase = "Pit-Stop";
					
					if(pmsPerformanceList.getFormStatusPitstop() == 10) {
						subject = subject.concat(" | "+"Performance Pit-stop Phase | Submitted By "+associateName);
						message = associateName+" has submitted the pit-stop comments for your review.";
						appropriateLetter = appropriateLetter.concat(" "+managerName);
						toEmail = managerEmail;
						ccEmails = associateEmail+','+reviewerEmail+','+LoadConstant.BPHR;
					}else if(pmsPerformanceList.getFormStatusPitstop() == 20) {
						subject = subject.concat(" | "+"Performance Pit-stop Phase | Submitted By "+managerName);
						message = managerName+"  has submitted the pit-stop comments for you. ";
						appropriateLetter = appropriateLetter.concat(" "+associateName);
						toEmail = associateEmail;
						ccEmails = managerEmail+','+reviewerEmail+','+LoadConstant.BPHR;
					}

				}else if(phase.equals("Evaluation") || flagEvaluation) {
					subject = subject.concat(" | Evaluation");
					phase = "Evaluation";
					
					if(pmsPerformanceList.getFormStatusEvaluation() == 10) {
						subject = subject.concat(" | "+"Year End Performance Appraisal | Submitted By "+associateName);
						message = associateName+" has submitted the final evaluation comments with ratings for your review.";
						appropriateLetter = appropriateLetter.concat(" "+managerName);
						toEmail = managerEmail;
						ccEmails = associateEmail+','+reviewerEmail+','+LoadConstant.BPHR;
					}else if(pmsPerformanceList.getFormStatusEvaluation() == 20) {
						subject = subject.concat(" | "+"Year End Performance Appraisal | Submitted By "+managerName);
						message = managerName+" has submitted the final evaluation comments for "+associateName+" with ratings for you.";
						appropriateLetter = appropriateLetter.concat(" "+reviewerName);
						toEmail = reviewerEmail;
						ccEmails = managerEmail+','+associateEmail+','+LoadConstant.BPHR;
					}else if(pmsPerformanceList.getFormStatusEvaluation() == 25) { // reviewer check
						subject = subject.concat(" | "+"Year End Performance Appraisal | Submitted By "+reviewerName);
						message = reviewerName+" has submitted the final evaluation comments with ratings for you.";
						toEmail = associateEmail;
						appropriateLetter = appropriateLetter.concat(" "+associateName);
						ccEmails = managerEmail+','+reviewerEmail+','+LoadConstant.BPHR;
					}
				}
				

				
				context.setVariable("Phase",phase);
				context.setVariable("appropriateLetter",appropriateLetter);
				context.setVariable("message",message);
				context.setVariable("subject",subject);
	
			}			
	
			// workflow to reset pmsresource settings done for form unlock after email is sent
			//writing this code in competency and not performance, bcoz doing in performance, flags will get reset before goals/competency save
			if(pmsResourceObject != null) {
		    	if(pmsResourceObject.getEnableHandshake() && (pmsResourceObject.getEnableHandshakeCycle() == pmsPerformanceList.getCycle().getCycleId())) {
		   
		    		//set EnableHandshakeStatus same as current status of form
		    		pmsResourceObject.setEnableHandshakeStatus(pmsPerformanceList.getFormStatusGoalsetting());
					
					//reset all force handshake columns if form status has reached 25 - Handshke Approved by manager
					if(pmsPerformanceList.getFormStatusGoalsetting() == 25) {							
						pmsResourceObject.setEnableHandshake(false);
						pmsResourceObject.setEnableHandshakeCycle(0);
						pmsResourceObject.setEnableHandshakeStatus(0);
						flagHandshake = false;
					}
		    	}
		    	else if(pmsResourceObject.getEnablePitstop() && (pmsResourceObject.getEnablePitstopCycle() == pmsPerformanceList.getCycle().getCycleId())) {
		    		flagPitstop = true;			    		
	
		    		//set EnablePitstopStatus same as current status of form
		    		pmsResourceObject.setEnablePitstopStatus(pmsPerformanceList.getFormStatusPitstop());
					
					//reset all force handshake columns if form status has reached 20 - Pitstop Submitted By Manager
					if(pmsPerformanceList.getFormStatusPitstop() == 20) {
						
						pmsResourceObject.setEnablePitstop(false);
						pmsResourceObject.setEnablePitstopCycle(0);
						pmsResourceObject.setEnablePitstopStatus(0);
						flagPitstop = false;
					}
		    	}
		    	else if(pmsResourceObject.getEnableEvaluation() && (pmsResourceObject.getEnableEvaluationCycle() == pmsPerformanceList.getCycle().getCycleId())) {
		    		flagEvaluation = true;
		    		
		    		//set EnableEvaluationStatus same as current status of form
		    		pmsResourceObject.setEnableEvaluationStatus(pmsPerformanceList.getFormStatusEvaluation());
					
					//reset all force handshake columns if form status has reached 30 - Evaluation Submitted By Reviewer
					if(pmsPerformanceList.getFormStatusEvaluation() == 30) {
						
						pmsResourceObject.setEnableEvaluation(false);
						pmsResourceObject.setEnableEvaluationCycle(0);
						pmsResourceObject.setEnableEvaluationStatus(0);
						flagEvaluation = false;
					}
		    	}
		    	pmsResourceRepository.save(pmsResourceObject);
		    }

			smtpMailSender.send(fromEmail,toEmail, subject, template, context,ccEmails, request);
		
		
	    }

		return true;
	}
	
	
	public boolean sendCycleNotification(PmsCycle pmsCycle, String action, HttpServletRequest request)  throws MessagingException {
	
			String subject = "InfoBiz | PMS";
			String template = "mail/pms";
			String fromEmail = LoadConstant.PMS_INFO;
//			String createdUpdatedName = "";
			String toEmail = "";
			String message = "";
			String ccEmails = "";
			Resource createdUpdatedBy = null;
	 		Year year= null;
	 		String appropriateLetter  = "Dear Associate,";
	
	        Context context = new Context();        
	        toEmail = LoadConstant.BPHR;
	        ccEmails = LoadConstant.INFOBIZ;
			if(pmsCycle.getYearId() !=null) {
				year = yearRepository.findOne(pmsCycle.getYearId());
				subject = subject.concat(" | "+year.getYear());
			}
			
//			if(action.equals("update")) {
//				
//				createdUpdatedBy = resourceController.findResource(pmsCycle.getModifiedBy());
//				if(createdUpdatedBy != null) {
//					createdUpdatedName = createdUpdatedBy.getTitle();
//				}
//			}else {
//				createdUpdatedBy = resourceController.findResource(pmsCycle.getCreatedBy());
//				if(createdUpdatedBy != null) {
//					createdUpdatedName = createdUpdatedBy.getTitle();
//				}
//			}
			
	    if(pmsCycle !=null) {

	    	if(pmsCycle.getStatus() != null) {
	    		
	     		if(pmsCycle.getStatus().equals("Handshake In-Progress")) {
					subject = subject.concat(" | Launch"+" | "+"Handshake");
					message = "The performance handshake phase is now active. You are requested to schedule a disucssion with your manager and set your goals in the system.";	    			
	    		}else if(pmsCycle.getStatus().equals("Pit-Stop In-Progress")) {
					subject = subject.concat(" | Launch"+" | "+"Pit-Stop");
					message = "Performance pit-stop phase is now active, you are requested to schedule a meeting with your manager and discsuss on the progress of your gaols set during the performance handshake phase.";			
	    		}else if(pmsCycle.getStatus().equals("Evaluation In-Progress")) {
		    		subject = subject.concat(" | Launch"+" | "+"Evaluation");
					message = "Year end Performance appraisal phase is now active. You are requested to reflect on your performance for the year, rate yourself on the set goals and highlight comments against each goals set.";	    			
	    		}else if(pmsCycle.getStatus().equals("Handshake Completed")) {
					subject = subject.concat(" | "+"Handshake Completed");
					message = "The performance handshake phase is completed.";	    			
	    		}else if(pmsCycle.getStatus().equals("Pit-Stop Completed")) {
					subject = subject.concat(" | "+"Pit-Stop Completed");
					message = "The performance Pit-Stop phase is completed.";	    			
	    		}else if(pmsCycle.getStatus().equals("Evaluation Completed")) {
					subject = subject.concat(" | "+"Evaluation Completed");
					message = "The performance Evaluation phase is completed.";	    			
	    		}
				context.setVariable("appropriateLetter",appropriateLetter);
				context.setVariable("message",message);
				context.setVariable("subject",subject);
	    	}
	    	
		smtpMailSender.send(fromEmail,toEmail, subject, template, context,ccEmails, request);
	    }
	
		return true;
	}
	
	
	public boolean sendIldpNotification(PmsIldp pmsIldp, String actionType, HttpServletRequest request)  throws MessagingException {
		
		String subject = "InfoBiz | PMS - ILDP";
		String template = "mail/pms";
		String fromEmail = LoadConstant.PMS_INFO;
		String toEmail = "";
		String message = "";
		String ccEmails = "";
		Resource createdUpdatedBy = null;
 		Year year= null;
 		String appropriateLetter  = "Dear Associate,";
 		Skill skillId = null;

        Context context = new Context();        
        toEmail = LoadConstant.BPHR;
        
    if(pmsIldp !=null) {
    	
    	Integer implId = pmsIldp.getIldpId();
    	String behavioralComp = pmsIldp.getBehavioralComp().trim();
    	
    	
    	String functionalComp = pmsIldp.getFunctionalComp();
    	String technicalSkill = pmsIldp.getTechnicalSkill().trim();
    	String technicalComments = pmsIldp.getComments().trim();
    	
    	Integer empId = pmsIldp.getUid();
    	Resource emp = resourceController.findResource(empId);
    	toEmail = emp.getEmail();
    	String empName = emp.getTitle();
    	
    	competencyController.getCompetency(16).getCompetencyName();
    	
    	Predicate<String> predicate = (value) -> !StringUtils.isEmpty(value);  
    	
        technicalSkill = Stream.of(technicalSkill.split(",")).filter(predicate).map(Integer::parseInt).map(skillController::getSkill).map(Skill::getSkillName).collect(Collectors.joining(","));
        behavioralComp = Stream.of(behavioralComp.split(",")).filter(predicate).map(Integer::parseInt).map(competencyController::getCompetency).map(CT_Competency::getCompetencyName).collect(Collectors.joining(","));

		
    	if(actionType == "add" ){
    		
			Resource createdBy = resourceController.findResource(pmsIldp.getCreatedBy());
			String title = createdBy.getTitle();				
			ccEmails = createdBy.getEmail();
		 	subject = "InfoBiz | PMS | 2019 | ILDP | "+ empName +" "	;					
			template = "mail/pmsildp";				
			
			context.setVariable("title", title);
			context.setVariable("createdBy",createdBy);
			context.setVariable("addILDP","addILDP");
		}    	
    	else if(actionType == "update" ){
    		
    		Resource updatedBy = resourceController.findResource(pmsIldp.getModifiedBy());
			String title = updatedBy.getTitle();
			ccEmails = updatedBy.getEmail();
			subject = "InfoBiz | PMS | 2019 | ILDP | "+ empName +" "	;					
			template = "mail/pmsildp";				
			
			context.setVariable("title", title);
			context.setVariable("updatedBy",updatedBy);
			context.setVariable("updateILDP","updateILDP");
		}
    	
    	context.setVariable("empName", empName);
    	context.setVariable("behavioralComp", behavioralComp);
		context.setVariable("functionalComp",functionalComp);
		context.setVariable("technicalSkill",technicalSkill);
		context.setVariable("technicalComments",technicalComments);
		

    	context.setVariable("appropriateLetter",appropriateLetter);
		context.setVariable("subject",subject);
		
		smtpMailSender.send(fromEmail,toEmail, subject, template, context,ccEmails, request);
    }
		return true;
	}
    

}
