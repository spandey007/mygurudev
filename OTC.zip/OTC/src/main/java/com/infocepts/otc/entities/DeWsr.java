/**
* Filename: /src/main/java/com/infocepts/otc/entities/DeWsr.java
* @author  SHRI
* @version 1.0
* @since   2018-11-28 
*/
package com.infocepts.otc.entities;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.persistence.*;
import javax.validation.constraints.NotNull;

import com.infocepts.otc.utilities.LoadConstant;
@Entity
@Table(catalog=LoadConstant.otc, schema="[dbo]", name="deWsr")

@SqlResultSetMappings({
        @SqlResultSetMapping(
                name = "list_all_deWsr",
                classes = {
                        @ConstructorResult(
                                targetClass = DeWsr.class,
                                columns = {
                                		@ColumnResult(name = "deWsrId"),
                                        @ColumnResult(name = "projectId"), 
										@ColumnResult(name = "period", type = String.class),
										@ColumnResult(name = "filepath", type = String.class),
										@ColumnResult(name = "period1", type = String.class),
										@ColumnResult(name = "filepath1", type = String.class),
										@ColumnResult(name = "period2", type = String.class),
										@ColumnResult(name = "filepath2", type = String.class),
										@ColumnResult(name = "period3", type = String.class),
										@ColumnResult(name = "filepath3", type = String.class),
										@ColumnResult(name = "period4", type = String.class),
										@ColumnResult(name = "filepath4", type = String.class),
										@ColumnResult(name = "createdBy"),	
										@ColumnResult(name = "createdDate", type = Date.class),
										@ColumnResult(name = "modifiedBy"),
										@ColumnResult(name = "modifiedDate", type = Date.class),	
										@ColumnResult(name = "deWsrMonth", type = Date.class),	
										@ColumnResult(name = "uploadDate1", type = Date.class),
										@ColumnResult(name = "uploadDate2", type = Date.class),
										@ColumnResult(name = "uploadDate3", type = Date.class),
										@ColumnResult(name = "uploadDate4", type = Date.class),
										@ColumnResult(name = "uploadDate5", type = Date.class),
                                        @ColumnResult(name = "period1Comments", type = String.class),
                                        @ColumnResult(name = "period2Comments", type = String.class),
                                        @ColumnResult(name = "period3Comments", type = String.class),
                                        @ColumnResult(name = "period4Comments", type = String.class),
                                        @ColumnResult(name = "period5Comments", type = String.class),
                                        @ColumnResult(name = "projectName", type = String.class),
										@ColumnResult(name = "itemId"),
										@ColumnResult(name = "ahId"),
										@ColumnResult(name = "projectManagersId"),
										@ColumnResult(name = "portfolioId "),
                                        @ColumnResult(name = "accountName", type = String.class),
                                        @ColumnResult(name = "portfolioName", type = String.class)
                                }
                        )
                }
        )
})
@NamedNativeQueries({
        @NamedNativeQuery(
                name    =   "getAllDeWsrData",   
                query 	=   "Select dpr.*, p.title as projectName,p.itemId, a.ahId, p.projectManagersId, p.portfolioId, a.accountShortName as accountName, po.title as portfolioName"+
							" from " + LoadConstant.infomaster + ".[dbo].[project] p"+
							" Left JOIN " + LoadConstant.otc + ".[dbo].[deWsr] as dpr on p.itemId = dpr.projectId and month(dpr.deWsrMonth) = :month and year(dpr.deWsrMonth) = :year"+
							" Left JOIN " + LoadConstant.infomaster + ".[dbo].[accounts] as a on p.accountId = a.itemId"+
							" Left JOIN " + LoadConstant.infomaster + ".[dbo].[portfolio] as po on a.portfolioId = po.itemId"+
							" WHERE p.state = 'Active' AND p.parentProjectId is NULL AND "+
		            		"(('pm' = :view and p.projectManagersId = :uid ) "+
		            		"or ('pm' = :view and p.plannersId like concat('%,',:uid,',%') or p.plannersId like concat('%,',:uid) or p.plannersId like concat(:uid,',%')) "+
		            		"or "+
		            		"('ph' = :view and po.ownerId = :uid ) "+
		            		"or "+
		            		"('pmo' = :view ) "+
		            		"or "+
		            		"('cep' = :view and a.rmId = :uid ) "+
		            		"or "+
		            		"('dh' = :view ) "+
		            		"or "+
		            		"('de' = :view )) order by dpr.deWsrId desc",
							
							resultClass=DeWsr.class, resultSetMapping = "list_all_deWsr"
        )        
})


public class DeWsr {

	// Entity Columns
    // --------------------------------------------------------------------------------
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Integer deWsrId; 		
	private Integer projectId;    
	private String period;
	private String filepath;
	private String period1;
	private String filepath1;
	private String period2;
	private String filepath2;
	private String period3;
	private String filepath3;
	private String period4;
	private String filepath4;
	private Integer createdBy;    
    private Date createdDate;
    private Integer modifiedBy;
    private Date modifiedDate;
    private Date deWsrMonth;
    private Date uploadDate1;
    private Date uploadDate2;
    private Date uploadDate3;
    private Date uploadDate4;
    private Date uploadDate5;
    
	@Lob
	private String period1Comments;
	@Lob
	private String period2Comments;
	@Lob
	private String period3Comments;
	@Lob
	private String period4Comments;
	@Lob
	private String period5Comments;
	
	@Transient
	private String projectName;
	
	@Transient
	private Integer itemId;

	@Transient
	private Integer ahId;
	
	@Transient
	private Integer projectManagersId;

	@Transient
	private Integer portfolioId;
	
	@Transient
	private String accountName;
	
	@Transient
	private String portfolioName;
	
	public Integer getDeWsrId() {
		return deWsrId;
	}

	public void setDeWsrId(Integer deWsrId) {
		this.deWsrId = deWsrId;
	}

	public Integer getProjectId() {
		return projectId;
	}

	public void setProjectId(Integer projectId) {
		this.projectId = projectId;
	}

	public String getPeriod() {
		return period;
	}

	public void setPeriod(String period) {
		this.period = period;
	}

	public String getFilepath() {
		return filepath;
	}

	public void setFilepath(String filepath) {
		this.filepath = filepath;
	}

	public String getPeriod1() {
		return period1;
	}

	public void setPeriod1(String period1) {
		this.period1 = period1;
	}

	public String getFilepath1() {
		return filepath1;
	}

	public void setFilepath1(String filepath1) {
		this.filepath1 = filepath1;
	}

	public String getPeriod2() {
		return period2;
	}

	public void setPeriod2(String period2) {
		this.period2 = period2;
	}

	public String getFilepath2() {
		return filepath2;
	}

	public void setFilepath2(String filepath2) {
		this.filepath2 = filepath2;
	}

	public String getPeriod3() {
		return period3;
	}

	public void setPeriod3(String period3) {
		this.period3 = period3;
	}

	public String getFilepath3() {
		return filepath3;
	}

	public void setFilepath3(String filepath3) {
		this.filepath3 = filepath3;
	}

	public String getPeriod4() {
		return period4;
	}

	public void setPeriod4(String period4) {
		this.period4 = period4;
	}

	public String getFilepath4() {
		return filepath4;
	}

	public void setFilepath4(String filepath4) {
		this.filepath4 = filepath4;
	}


	public Integer getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Integer getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public Date getDeWsrMonth() {
		return deWsrMonth;
	}

	public void setDeWsrMonth(Date deWsrMonth) {
		this.deWsrMonth = deWsrMonth;
	}

	public String getPeriod1Comments() {
		return period1Comments;
	}

	public void setPeriod1Comments(String period1Comments) {
		this.period1Comments = period1Comments;
	}

	public String getPeriod2Comments() {
		return period2Comments;
	}

	public void setPeriod2Comments(String period2Comments) {
		this.period2Comments = period2Comments;
	}

	public String getPeriod3Comments() {
		return period3Comments;
	}

	public void setPeriod3Comments(String period3Comments) {
		this.period3Comments = period3Comments;
	}

	public String getPeriod4Comments() {
		return period4Comments;
	}

	public void setPeriod4Comments(String period4Comments) {
		this.period4Comments = period4Comments;
	}

	public String getPeriod5Comments() {
		return period5Comments;
	}

	public void setPeriod5Comments(String period5Comments) {
		this.period5Comments = period5Comments;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public Integer getItemId() {
		return itemId;
	}

	public void setItemId(Integer itemId) {
		this.itemId = itemId;
	}


	public Integer getAhId() {
		return ahId;
	}

	public void setAhId(Integer ahId) {
		this.ahId = ahId;
	}

	public Integer getProjectManagersId() {
		return projectManagersId;
	}

	public void setProjectManagersId(Integer projectManagersId) {
		this.projectManagersId = projectManagersId;
	}

	public Integer getPortfolioId() {
		return portfolioId;
	}

	public void setPortfolioId(Integer portfolioId) {
		this.portfolioId = portfolioId;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public String getPortfolioName() {
		return portfolioName;
	}

	public void setPortfolioName(String portfolioName) {
		this.portfolioName = portfolioName;
	}

	public Date getUploadDate1() {
		return uploadDate1;
	}

	public void setUploadDate1(Date uploadDate1) {
		this.uploadDate1 = uploadDate1;
	}

	public Date getUploadDate2() {
		return uploadDate2;
	}

	public void setUploadDate2(Date uploadDate2) {
		this.uploadDate2 = uploadDate2;
	}

	public Date getUploadDate3() {
		return uploadDate3;
	}

	public void setUploadDate3(Date uploadDate3) {
		this.uploadDate3 = uploadDate3;
	}

	public Date getUploadDate4() {
		return uploadDate4;
	}

	public void setUploadDate4(Date uploadDate4) {
		this.uploadDate4 = uploadDate4;
	}

	public Date getUploadDate5() {
		return uploadDate5;
	}

	public void setUploadDate5(Date uploadDate5) {
		this.uploadDate5 = uploadDate5;
	}

	/*default constructor*/
	public DeWsr() {
		
	}

	public DeWsr(Integer deWsrId, Integer projectId, String period, String filepath, String period1, String filepath1,
			String period2, String filepath2, String period3, String filepath3, String period4, String filepath4,
			Integer createdBy, Date createdDate, Integer modifiedBy, Date modifiedDate, Date deWsrMonth,
			Date uploadDate1, Date uploadDate2, Date uploadDate3, Date uploadDate4, Date uploadDate5,
			String period1Comments, String period2Comments, String period3Comments, String period4Comments,
			String period5Comments, String projectName, Integer itemId, Integer ahId, Integer projectManagersId,
			Integer portfolioId, String accountName, String portfolioName) {
		super();
		this.deWsrId = deWsrId;
		this.projectId = projectId;
		this.period = period;
		this.filepath = filepath;
		this.period1 = period1;
		this.filepath1 = filepath1;
		this.period2 = period2;
		this.filepath2 = filepath2;
		this.period3 = period3;
		this.filepath3 = filepath3;
		this.period4 = period4;
		this.filepath4 = filepath4;
		this.createdBy = createdBy;
		this.createdDate = createdDate;
		this.modifiedBy = modifiedBy;
		this.modifiedDate = modifiedDate;
		this.deWsrMonth = deWsrMonth;
		this.uploadDate1 = uploadDate1;
		this.uploadDate2 = uploadDate2;
		this.uploadDate3 = uploadDate3;
		this.uploadDate4 = uploadDate4;
		this.uploadDate5 = uploadDate5;
		this.period1Comments = period1Comments;
		this.period2Comments = period2Comments;
		this.period3Comments = period3Comments;
		this.period4Comments = period4Comments;
		this.period5Comments = period5Comments;
		this.projectName = projectName;
		this.itemId = itemId;
		this.ahId = ahId;
		this.projectManagersId = projectManagersId;
		this.portfolioId = portfolioId;
		this.accountName = accountName;
		this.portfolioName = portfolioName;
	}


	
	
}
