package com.infocepts.otc.services;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.infocepts.otc.db.OtcDbConfig;
import com.infocepts.otc.entities.Allocation;
import com.infocepts.otc.entities.Month;
import com.infocepts.otc.entities.MonthlyAllocation;
import com.infocepts.otc.entities.Holidays;
import com.infocepts.otc.repositories.HolidaysRepository;
import com.infocepts.otc.repositories.MonthRepository;
import com.infocepts.otc.repositories.MonthlyAllocationRepository;

@Component
public class MonthlyAllocationServiceImpl implements MonthlyAllocationService {

	@Autowired
	public MonthlyAllocationRepository monthlyAllocationRepository;
	
	@Autowired
	public MonthRepository monthRepository;
	
	@Autowired
	public HolidaysRepository holidaysRepository;
	
	@PersistenceContext(unitName = "otc")
	private EntityManager entityManager;
	
	@Override
	@Transactional
	public void InsertUpdateMonthlyAllocation(Allocation allocation) {

		//Get allocation id
		Integer alcId = allocation.getAlcId();
		
		//Delete all monthly allocation rows
		monthlyAllocationRepository.deleteMonthlyAllocationByAllocationId(alcId);
		
		//Create row for each month from the allocation using start and end date;
		List<MonthlyAllocation> monthlyAllocationRows = SplitRows(allocation);
		
		//Insert all the rows
		monthlyAllocationRepository.save(monthlyAllocationRows);

	}

	private List<MonthlyAllocation> SplitRows(Allocation allocation) {
		
		List<MonthlyAllocation> result =new  ArrayList<MonthlyAllocation>();
		
		//Get Start date and End date
		Date allocationStartDate = allocation.getAlcStartDate();
		Date allocationEndDate = allocation.getAlcEndDate();
		
		//Convert date to calendar type
		Calendar startDate = Calendar.getInstance();
		startDate.setTime(allocationStartDate);
		
		Calendar endDate = Calendar.getInstance();
		endDate.setTime(allocationEndDate);
		
		//Convert the allocationStartDate and allocationEndDate date such that they start at first date and end at last date
		Calendar startDateModified = Calendar.getInstance();
		startDateModified.setTime(allocationStartDate);
		startDateModified.set(Calendar.DATE,1);
		
		Calendar endDateModified = Calendar.getInstance();
		endDateModified.setTime(allocationEndDate);
		endDateModified.set(Calendar.DATE,endDateModified.getActualMaximum(Calendar.DATE));
				
		//Get all the months from month table between start and end date
		SimpleDateFormat formatDate = new SimpleDateFormat("yyyy-MM-dd");
		List<Month> months = monthRepository.findMonthsBetweenStartAndEndDate(formatDate.format(startDateModified.getTime()), formatDate.format(endDateModified.getTime()));
		
		
		//Get all the holidays between start and end date for resource as per his/her holiday schedule
		List<String> holidaysTemp = holidaysRepository.getHolidayCountByMonthWithinStartAndEndDate(allocationStartDate, allocationEndDate, allocation.getUid());
		
		//Create a dictionary for month with respective holiday count
		HashMap<String , Integer> holidays = new HashMap<String , Integer>();
		
		for (int i = 0; i < holidaysTemp.size(); i++) {
			
			String value = holidaysTemp.get(i);
			
			holidays.put(value.split("[|]")[0], Integer.valueOf(value.split("[|]")[1]));
		};
		
		//Loop through all the months within start and end date to split rows
		for(Month month : months) {
			
			//Get year
			Calendar monthStartDate = Calendar.getInstance();
			monthStartDate.setTime(month.getMonthStartDate());
			
			int monthYear = monthStartDate.get(Calendar.YEAR);
			
			//Get number of holidays for this month
			int holidayCount = 0;
			
			String key = month.getMonthNo()+"-"+monthYear;
			if(holidays.containsKey(key))
			{
				holidayCount = holidays.get(key);
			}
			
			//Set values in Monthly Allocation
			MonthlyAllocation monthlyAllocation_obj =  new MonthlyAllocation();
			monthlyAllocation_obj.setAlcEndDate(allocation.getAlcEndDate());
			monthlyAllocation_obj.setAlcFte(allocation.getAlcFte());
			
			//Subtract the holiday count from total working days and multiply by 8 to get in Hours
			monthlyAllocation_obj.setAlcHrs(allocation.getAlcFte().multiply(BigDecimal.valueOf((month.getTotalDays()-holidayCount)*8)));
			monthlyAllocation_obj.setAlcStartDate(allocation.getAlcStartDate());
			monthlyAllocation_obj.setAlcType(allocation.getAlcType());
			
			monthlyAllocation_obj.setComments(allocation.getComments());
			monthlyAllocation_obj.setCreatedBy(allocation.getCreatedBy());
			monthlyAllocation_obj.setCreatedDate(allocation.getCreatedDate());
			
			monthlyAllocation_obj.setModifiedBy(allocation.getModifiedBy());
			monthlyAllocation_obj.setModifiedDate(Calendar.getInstance().getTime());
			monthlyAllocation_obj.setPrdMonth(month.getMonthNo());
			
			monthlyAllocation_obj.setPrdName(month.getMonth().replace('-', ' '));
			monthlyAllocation_obj.setPrdYear(monthYear);
			monthlyAllocation_obj.setProjectId(allocation.getProjectId());
			
			monthlyAllocation_obj.setRequisitionId(allocation.getRequisitionId());
			if(allocation.getSowDetail()!=null) monthlyAllocation_obj.setSowDetailId(allocation.getSowDetail().getSowDetailId());
			monthlyAllocation_obj.setUid(allocation.getUid());
			
			monthlyAllocation_obj.setAllocation(allocation);
			monthlyAllocation_obj.setPrdId(1); //Replace it with actual period ID ,for now inserting dummy value
			
			monthlyAllocation_obj.setProjectId(allocation.getProjectId());
			
			//Add monthly allocation object in list
			result.add(monthlyAllocation_obj);
		}
		
		int workingDays = 0;
		//Get last day of endDate
		int lastDate = endDate.getActualMaximum(Calendar.DATE);
		
		//If start date and End date lies within the same month
		if(startDate.get(Calendar.MONTH) == endDate.get(Calendar.MONTH) && startDate.get(Calendar.YEAR) == endDate.get(Calendar.YEAR))
		{
			int holidayCount = 0;
			String key = (startDate.get(Calendar.MONTH)+1)+"-"+startDate.get(Calendar.YEAR);
			if(holidays.containsKey(key)) holidayCount = holidays.get(key);
			
			workingDays = CalculateNumberOfWorkingdaysForSameMonth(startDate,endDate);
			result.get(0).setAlcHrs(result.get(0).getAlcFte().multiply(BigDecimal.valueOf( (workingDays-holidayCount)*8)));
		}
		else
		{

			//if allocation is not starting from 1st day of month, and ending at last day of month
			//then recalculate number of working days and insert at first and last position
			if(startDate.get(Calendar.DATE) != 1)
			{
				//Get number of holidays for this month
				int holidayCount = 0;
				String key = (startDate.get(Calendar.MONTH)+1)+"-"+startDate.get(Calendar.YEAR);
				if(holidays.containsKey(key)) holidayCount = holidays.get(key);
	
				workingDays = CalculateNumberOfWorkingdays(startDate,1);
				result.get(0).setAlcHrs(result.get(0).getAlcFte().multiply(BigDecimal.valueOf( (workingDays-holidayCount)*8)));
			}
			if(endDate.get(Calendar.DATE) != lastDate)
			{
				//Get number of holidays for this month
				int holidayCount = 0;
				String key = (endDate.get(Calendar.MONTH)+1)+"-"+endDate.get(Calendar.YEAR);
				if(holidays.containsKey(key)) holidayCount = holidays.get(key);
				
				workingDays = CalculateNumberOfWorkingdays(endDate,2);
				result.get(result.size() - 1).setAlcHrs( result.get(result.size() - 1).getAlcFte().multiply(BigDecimal.valueOf( (workingDays-holidayCount)*8)));
			}
		}

		return result;
	}

	//To calculate number of working days for start (start at random date till end date of month) and end (start at first date and end at random date) date of a month
	private int CalculateNumberOfWorkingdays(Calendar date,int type) { //type: 1-Start date, 2-End date

		int count = 0;
		int month = date.get(Calendar.MONTH);
		while(date.get(Calendar.MONTH) == month)
		{
			
			if(date.get(Calendar.DAY_OF_WEEK) != 1 && date.get(Calendar.DAY_OF_WEEK) != 7) //1-Sunday, 7-Saturday
			{
				count++;
			}
			
			if(type==1)
				date.add(Calendar.DATE, 1);
			else
				date.add(Calendar.DATE, -1);
			
		}
		return count;
	}
	
	private int CalculateNumberOfWorkingdaysForSameMonth(Calendar startDate,Calendar endDate) { //type: 1-Start date, 2-End date

		int count = 0;
		int month = startDate.get(Calendar.MONTH);
		while(startDate.get(Calendar.DATE) <= endDate.get(Calendar.DATE) && startDate.get(Calendar.MONTH) == month)
		{
			
			if(startDate.get(Calendar.DAY_OF_WEEK) != 1 && startDate.get(Calendar.DAY_OF_WEEK) != 7) //1-Sunday, 7-Saturday
			{
				count++;
			}
			
			startDate.add(Calendar.DATE, 1);

		}
		return count;
	}
	
	@Override
	@Transactional
	public void DeleteMonthlyAllocation(Integer alcId) {
		
		//Delete all monthly allocation rows
		monthlyAllocationRepository.deleteMonthlyAllocationByAllocationId(alcId);
	}

}
