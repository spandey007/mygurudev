package com.infocepts.otc.controllers;

import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.infocepts.otc.entities.Entities;
import com.infocepts.otc.entities.Unit;
import com.infocepts.otc.repositories.EntitiesRepository;
import com.infocepts.otc.repositories.UnitRepository;

@RestController
@RequestMapping(value="/unit",headers="referer")
public class UnitController {
  
	final Logger logger = Logger.getLogger(UnitController.class);

	@Autowired
	UnitRepository repository;

	@Autowired
	EntitiesRepository entitiesRepository;
	
//	@RequestMapping(method=RequestMethod.POST)
//	public Entities addEntities(@RequestBody Entities entities)
//	{
//		try{
//			entities.setEntityId(null);
//			repository.save(entities);	
//		}catch(Exception e){
//			logger.error(e);
//		}
//		return entities;
//	}	

	 @RequestMapping(method=RequestMethod.GET)
	 public List<Unit> getAllUnit(@RequestParam(value = "countryId",defaultValue = "0") Integer countryId,
			                      @RequestParam(value = "entityId",defaultValue = "0") Integer entityId,
     							  @RequestParam(value = "status",defaultValue = "true",required=false) boolean status){
		 
		 List<Unit> unitlist=null;
		 try{
			 if(countryId != 0){
				 List<Entities> list=entitiesRepository.findByCountryId(countryId);//to get entity object first
				 Iterator<Entities> it=list.iterator();
				 while(it.hasNext()){
					Entities obj = it.next();
					unitlist = repository.findByEntityId(obj.getEntityId());//to get unit list from passed entity 
				 }
				 
			 }
			 else if(entityId != 0){
				 unitlist = repository.findByEntityId(entityId);
			 }
			 else if(status){
				 unitlist = repository.findActiveUnits(status);
			 }else{
				 unitlist = repository.findAll();
			 }
		 }catch(Exception e){
			 logger.error(e);
		 }
		 return unitlist;
	 }
	 
	 @RequestMapping(value="/{unitId}",method=RequestMethod.GET)
	 public Unit getUnit(@PathVariable Integer unitId){
		 Unit unit=null;
		 try{
			 unit = repository.findOne(unitId);
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return unit;
	 }
	 
	 @RequestMapping(value="/{unitId}",method=RequestMethod.PUT)
	 public Unit updateUnit(@RequestBody Unit updatedUnit,@PathVariable Integer unitId){
		 try{
			 updatedUnit.setUnitId(unitId);
			 repository.save(updatedUnit);
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return updatedUnit;
	 }
	 
	 @RequestMapping(value="/{unitId}",method=RequestMethod.DELETE)
	 public void deleteUnit(@PathVariable Integer unitId){
		 try{
			 repository.delete(unitId);
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
	 }
	 @GetMapping("/getAllUnits")
	 public List<Unit> getAllUnist(){
		 
		 List<Unit> unitlist=null;
		 try{
			unitlist = repository.findAll();
		 }catch(Exception e){
			 logger.error(e);
		 }
		 return unitlist;
	 }

}
