package com.infocepts.otc.repositories;

import java.util.List;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import com.infocepts.otc.entities.CmsDetail;
import com.infocepts.otc.utilities.LoadConstant;


public interface CmsDetailRepository extends CrudRepository<CmsDetail,Integer>{

	@Override
	public List<CmsDetail> findAll();
}
