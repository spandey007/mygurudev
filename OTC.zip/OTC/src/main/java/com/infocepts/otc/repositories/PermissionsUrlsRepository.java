package com.infocepts.otc.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.infocepts.otc.entities.PermissionsUrls;


public interface PermissionsUrlsRepository extends JpaRepository<PermissionsUrls,Integer>{

	@Override
	public List<PermissionsUrls> findAll();

	@Query("select pu from PermissionsUrls pu where pu.status = true")
	public List<PermissionsUrls> findActivePermissionsUrls();
}
