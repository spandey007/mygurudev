package com.infocepts.otc.utilities;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * @author Rewatiraman Singh
 *
 */
public class UniqueArrayList<T> extends ArrayList<T> {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 2544842829432559133L;

	public UniqueArrayList() {
		super();
	}
	
	public UniqueArrayList(int initialCapacity) {
		super(initialCapacity);
	}
	
	/*  Check if the given element is already present, If not then add it to the list.
	 */
	@Override
	public boolean add(T t) {
		return !contains(t) ? super.add(t) : false;
	}
	
	/* Check if the given element is already present at the specified index, If not then add it to the list.
	 */
	@Override
	public void add(int index, T element) {
		if (!contains(get(index))) {
			super.add(index, element);
		}
	}
	
	/* Check if the given elements are already present, If not then add those elements to the list.
	 */
	@Override
	public boolean addAll(Collection<? extends T> c) {
		return !containsAll(c) ? super.addAll(c) : false;
	}
	
	/* Check if the given elements are already present at the specified index, If not then add those elements to the list.
	 */
	@Override
	public boolean addAll(int index, Collection<? extends T> c) {
		if (!containsAll(c)) {
			super.addAll(index, c);
		}
		return false;
	}
	
	/**
	 * @param objects
	 * @return - UniqueArrayList instance containing the given elements.
	 */
	public static UniqueArrayList<Object> asUniqueList(Object... objects) {
		UniqueArrayList<Object> uniqueList = new UniqueArrayList<>();

		for (Object object : objects) {
			uniqueList.add(object);
		}
		return uniqueList;
	}
	
	/* @param objects
	* @return - UniqueArrayList instance containing the given elements.
			*/
	public static UniqueArrayList<String> asUniqueList(String...array) {
		UniqueArrayList<String> uniqueList = new UniqueArrayList<>();

		for (String string : array) {
			uniqueList.add(string);
		}
		return uniqueList;
	}

	 public static UniqueArrayList<Object> asUniqueList(List<?> list) {
		 UniqueArrayList<Object> uniqueList = new UniqueArrayList<>();
		 list.forEach(uniqueList::add);
		 return uniqueList;
	 }
}
