package com.infocepts.otc.controllers;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.infocepts.otc.entities.GstPercent;
import com.infocepts.otc.repositories.GstPercentRepository;

@RestController
@RequestMapping(value="/gstpercent",headers="referer")
public class GstPercentController {
	
	@Autowired
	GstPercentRepository repository;
	
    final Logger logger = Logger.getLogger(GstPercentController.class);

	@RequestMapping(method=RequestMethod.GET)
	 public GstPercent getGstPercent(@RequestParam(value = "title",defaultValue = "null") String title){
		 GstPercent gstPercent=null;
		 try{
			 gstPercent = repository.findByTitle(title);
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return gstPercent;
	 }
}
