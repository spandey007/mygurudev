package com.infocepts.otc.controllers;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.infocepts.otc.entities.CT_BehavioralKeyAction;
import com.infocepts.otc.entities.CT_BehavioralKeyAction;
import com.infocepts.otc.repositories.CT_BehavioralKeyActionRepository;
import com.infocepts.otc.services.TimesheetService;

@RestController
@RequestMapping(value="behavioralKeyAction",headers="referer")
public class CT_BehavioralKeyActionController {
	@Autowired
	CT_BehavioralKeyActionRepository ct_BehavioralKeyActionRepository;
	
	@Autowired
	TimesheetService service;
	
	@PersistenceContext(unitName = "otc")
	private EntityManager manager;
	
	@RequestMapping(method=RequestMethod.POST)
	public CT_BehavioralKeyAction addCT_BehavioralKeyAction(@RequestBody CT_BehavioralKeyAction cT_BehavioralKeyAction){
		cT_BehavioralKeyAction.setBehavioralKeyActionId(null);
		Boolean isAValidCall = false;
		if(service.isHR() || service.isAdmin())
		{
			isAValidCall = true;
		}
		if(isAValidCall) {
			
			ct_BehavioralKeyActionRepository.save(cT_BehavioralKeyAction);
		}
		return cT_BehavioralKeyAction;
	}
	
	@RequestMapping(method=RequestMethod.GET)
	public List<CT_BehavioralKeyAction> getCT_BehavioralKeyAction(){
		List<CT_BehavioralKeyAction> list = null;
		Boolean isAValidCall = false;
		if(service.isHR() || service.isAdmin())
		{
			isAValidCall = true;
		}
		if(isAValidCall) {
		System.out.println("inside AllBehavioralKeyAction page");
		list =  manager.createNamedQuery("getAllBehavioralKeyAction",CT_BehavioralKeyAction.class)
				.getResultList();
		}
		return list;
	}
	
	@RequestMapping(value="/{behavioralKeyActionId}",method=RequestMethod.GET)
	public CT_BehavioralKeyAction getCT_BehavioralKeyAction(@PathVariable Integer behavioralKeyActionId){
		CT_BehavioralKeyAction cT_BehavioralKeyAction = null;
		Boolean isAValidCall = false;
		if(service.isHR() || service.isAdmin())
		{
			isAValidCall = true;
		}
		if(isAValidCall) {
			
			cT_BehavioralKeyAction = ct_BehavioralKeyActionRepository.findOne(behavioralKeyActionId);
		}
		return cT_BehavioralKeyAction;
	}
	
	@RequestMapping(value="/{behavioralKeyActionId}", method=RequestMethod.PUT)
	public CT_BehavioralKeyAction updateCT_BehavioralKeyAction(@PathVariable Integer behavioralKeyActionId,  @RequestBody CT_BehavioralKeyAction updatedCT_BehavioralKeyAction){
		updatedCT_BehavioralKeyAction.setBehavioralKeyActionId(behavioralKeyActionId);
		Boolean isAValidCall = false;
		if(service.isHR() || service.isAdmin())
		{
			isAValidCall = true;
		}
		if(isAValidCall) {
		ct_BehavioralKeyActionRepository.save(updatedCT_BehavioralKeyAction);
		}
		return updatedCT_BehavioralKeyAction;
	}
	
	@RequestMapping(value="/{behavioralKeyActionId}",method=RequestMethod.DELETE)
	public void deleteCT_BehavioralKeyAction(@PathVariable Integer behavioralKeyActionId){
		Boolean isAValidCall = false;
		if(service.isHR() || service.isAdmin())
		{
			isAValidCall = true;
		}
		if(isAValidCall) {
		ct_BehavioralKeyActionRepository.delete(behavioralKeyActionId);
		}
	}
}
