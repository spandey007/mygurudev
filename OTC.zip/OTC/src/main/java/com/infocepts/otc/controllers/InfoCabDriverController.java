package com.infocepts.otc.controllers;

import java.util.List;
import java.util.logging.Level;

import java.util.logging.Logger;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.infocepts.otc.entities.InfoCabDriver;
import com.infocepts.otc.entities.InfoCabVehicle;
import com.infocepts.otc.repositories.InfoCabDriverRepository;
import com.infocepts.otc.services.TimesheetService;

@RestController
@RequestMapping(value="/infocabdriver",headers="referer")
public class InfoCabDriverController {
	
	final Logger logger = Logger.getLogger(InfoCabDriverController.class.getName());
	@Autowired
	InfoCabDriverRepository infoCabDriverRepository;
	
	@Autowired
	TimesheetService service;
	
	@RequestMapping(method=RequestMethod.POST)
	public InfoCabDriver addInfoCabDriver(@RequestBody InfoCabDriver infoCabDriver){
		infoCabDriver.setInfoCabDriverId(null);
		Boolean isAValidCall = false;
		if(service.isTravel())
		{
			isAValidCall = true;
		}
		if(isAValidCall) {
			
			infoCabDriverRepository.save(infoCabDriver);
		}
		return infoCabDriver;
	}
	
	@RequestMapping(method=RequestMethod.GET)
	public List<InfoCabDriver> getInfoCabDriver(){
		List<InfoCabDriver> list = null;
		Boolean isAValidCall = false;
		if(service.isTravel())
		{
			isAValidCall = true;
		}
		//if(isAValidCall) {
			list = infoCabDriverRepository.findAll();
		//}
		return list;
	}
	
	@RequestMapping(value="/{infoCabDriverId}",method=RequestMethod.GET)
	public InfoCabDriver getInfoCabDriver(@PathVariable Integer infoCabDriverId){
		InfoCabDriver infoCabDriver = null;
		Boolean isAValidCall = false;
		if(service.isTravel())
		{
			isAValidCall = true;
		}
		if(isAValidCall) {
			
			infoCabDriver = infoCabDriverRepository.findOne(infoCabDriverId);
		}
		return infoCabDriver;
	}
	
	@RequestMapping(value="/{infoCabDriverId}", method=RequestMethod.PUT)
	public InfoCabDriver updateInfoCabDriver(@PathVariable Integer infoCabDriverId,  @RequestBody InfoCabDriver updatedInfoCabDriver){
		updatedInfoCabDriver.setInfoCabDriverId(infoCabDriverId);
		Boolean isAValidCall = false;
		if(service.isTravel())
		{
			isAValidCall = true;
		}
		if(isAValidCall) {
		infoCabDriverRepository.save(updatedInfoCabDriver);
		}
		return updatedInfoCabDriver;
	}
	
	@RequestMapping(value="/{infoCabDriverId}",method=RequestMethod.DELETE)
	public void deleteInfoCabDriver(@PathVariable Integer infoCabDriverId){
		Boolean isAValidCall = false;
		if(service.isTravel())
		{
			isAValidCall = true;
		}
		if(isAValidCall) {
		infoCabDriverRepository.delete(infoCabDriverId);
		}
	}
	
	@GetMapping("/getCabDrivers")
    public Object getCabDrivers(HttpServletRequest request){        
		List<InfoCabDriver> list = null;
        try{
        	list = infoCabDriverRepository.findAll();
        }catch(Exception e){
        	logger.log(Level.SEVERE, "exceptn msg", e);
        }
        return list;
    }
	
	@GetMapping("/getDriverById")
	public Object getDriverById(@RequestParam(value = "infoCabDriverId", defaultValue = "0") Integer infoCabDriverId,
									  HttpServletRequest request){
		InfoCabDriver infoCabDriver = null;
		try{
			infoCabDriver = infoCabDriverRepository.findOne(infoCabDriverId);
		}catch(Exception e){
			logger.log(Level.SEVERE, "exceptn msg", e);
		}
		return infoCabDriver;
	}
}
