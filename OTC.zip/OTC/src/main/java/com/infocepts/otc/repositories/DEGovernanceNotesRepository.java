package com.infocepts.otc.repositories;

import com.infocepts.otc.entities.DEGovernanceNotes;
import com.infocepts.otc.entities.Portfolio;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface DEGovernanceNotesRepository extends JpaRepository <DEGovernanceNotes, Integer>{

	@Query("from DEGovernanceNotes where portfolioId = :portfolioId and month=:month and year=:year order by id asc")
	List<DEGovernanceNotes> findByPortfolioIdAndPeriod(@Param("portfolioId")Integer portfolioId, @Param("month")Integer month, @Param("year")Integer year);
	
	@Query("from DEGovernanceNotes where deliveryId = :deliveryId and month=:month and year=:year order by id asc")
	List<DEGovernanceNotes> findByDeliveryIdAndPeriod(@Param("deliveryId")Integer deliveryId, @Param("month")Integer month, @Param("year")Integer year);
	
	@Query("from DEGovernanceNotes where accountId = :accountId and month=:month and year=:year order by id asc")
	List<DEGovernanceNotes> findByAccountIdAndPeriod(@Param("accountId")Integer accountId, @Param("month")Integer month, @Param("year")Integer year);
	
	@Query("from DEGovernanceNotes where portfolioHeadId = :portfolioHeadId and month=:month and year=:year order by id asc")
	List<DEGovernanceNotes> findByPortfolioHeadIdAndPeriod(@Param("portfolioHeadId")Integer portfolioHeadId, @Param("month")Integer month, @Param("year")Integer year);

}
