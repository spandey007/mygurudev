package com.infocepts.otc.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.infocepts.otc.entities.InvoiceInfo;

public interface InvoiceInfoRepository extends CrudRepository<InvoiceInfo,Integer>{

	@Override
	public List<InvoiceInfo> findAll();
	
	
	@Query("select inf from InvoiceInfo inf where inf.projectId = :projectId")
	public InvoiceInfo findByProjectId(@Param(value="projectId") Integer projectId);
	
}
