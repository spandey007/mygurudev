package com.infocepts.otc.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.infocepts.otc.utilities.LoadConstant;



@Entity
@Table(catalog=LoadConstant.otc,schema="[dbo]",name="permissions")
public class Permissions {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer permissionsId;
	
	@ManyToOne
	@JoinColumn(name="permissionsUrlsId")
	private PermissionsUrls url;
	
	private Boolean status;
	
	@ManyToOne
	@JoinColumn(name="roleId")
	private Roles roles;	
	
	public Integer getPermissionsId() {
		return permissionsId;
	}
	public void setPermissionsId(Integer permissionsId) {
		this.permissionsId = permissionsId;
	}
	public PermissionsUrls getUrl() {
		return url;
	}
	public void setUrl(PermissionsUrls url) {
		this.url = url;
	}
	public Roles getRoles() {
		return roles;
	}
	public void setRoles(Roles roles) {
		this.roles = roles;
	}
	public Boolean getStatus() {
		return status;
	}
	public void setStatus(Boolean status) {
		this.status = status;
	}	
}
