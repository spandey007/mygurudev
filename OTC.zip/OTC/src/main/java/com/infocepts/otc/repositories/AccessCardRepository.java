/**
* Filename: /src/main/java/com/infocepts/otc/repositories/AccessCardRepository.java
* @author  SHRI
* @version 1.0
* @since   2019-09-25 
*/
package com.infocepts.otc.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import com.infocepts.otc.entities.AccessCard;

public interface AccessCardRepository extends CrudRepository<AccessCard,Integer>{

	@Override
	public List<AccessCard> findAll();	
		
//	@Query("from <ModuleName> where column1 = :column1")
//	public <ModuleName> find<ModuleName>ByColumn1(@Param(value = "column1") Integer column1);
	
}
