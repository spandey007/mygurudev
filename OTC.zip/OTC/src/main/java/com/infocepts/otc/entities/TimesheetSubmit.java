package com.infocepts.otc.entities;

import java.util.Date;
import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.infocepts.otc.utilities.LoadConstant;

@Entity
@Table(catalog=LoadConstant.otc,schema="[dbo]",name="tssubmit")
public class TimesheetSubmit {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer tssubmitId;
	
	@ManyToOne
	@JoinColumn(name="timesheetId")
	private Timesheet timesheet;
	
	private Integer projectId; // Project reference
	private Boolean submitted;	
	private Date submittedDate;
	private Integer submittedBy;
	
	private Integer createdBy;	
	private Date createdDate;	
	private Integer modifiedBy;
	private Date modifiedDate;
	
	public Integer getTssubmitId() {
		return tssubmitId;
	}
	public void setTssubmitId(Integer tssubmitId) {
		this.tssubmitId = tssubmitId;
	}
	public Timesheet getTimesheet() {
		return timesheet;
	}
	public void setTimesheet(Timesheet timesheet) {
		this.timesheet = timesheet;
	}
	public Integer getProjectId() {
		return projectId;
	}
	public void setProjectId(Integer projectId) {
		this.projectId = projectId;
	}
	public Boolean getSubmitted() {
		return submitted;
	}
	public void setSubmitted(Boolean submitted) {
		this.submitted = submitted;
	}
	public Date getSubmittedDate() {
		return submittedDate;
	}
	public void setSubmittedDate(Date submittedDate) {
		this.submittedDate = submittedDate;
	}
	public Integer getSubmittedBy() {
		return submittedBy;
	}
	public void setSubmittedBy(Integer submittedBy) {
		this.submittedBy = submittedBy;
	}
	public Integer getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public Integer getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public Date getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}	
}
