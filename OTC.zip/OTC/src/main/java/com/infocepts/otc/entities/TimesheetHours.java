package com.infocepts.otc.entities;

 
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.SqlResultSetMappings;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import com.infocepts.otc.utilities.LoadConstant;

 
@Entity
@Table(catalog=LoadConstant.otc,schema="[dbo]",name="tsitemhours")
@SqlResultSetMappings({
	@SqlResultSetMapping(
	      name = "detailed_tshrs",
	      classes = {
	          @ConstructorResult(
	              targetClass = TimesheetHours.class,
	              columns = {
	                  @ColumnResult(name = "tshoursId"),
	                  @ColumnResult(name = "tsitemId"),
	                  @ColumnResult(name = "itemDate", type=Date.class),
	                  @ColumnResult(name = "billableHrs", type=BigDecimal.class),
	                  @ColumnResult(name = "nonBillableHrs", type=BigDecimal.class),
	                  @ColumnResult(name = "totalWorkedHrs", type=BigDecimal.class),
	                  @ColumnResult(name = "notes"),
	                  @ColumnResult(name = "projectName"),
	                  @ColumnResult(name = "projectId"),
	        	  @ColumnResult(name = "taskName"),
	        	  @ColumnResult(name = "createdDate", type=Date.class),
	                  @ColumnResult(name = "createdBy")
	              }
	          )
	      }
	),
	@SqlResultSetMapping(
	  name = "ts_details",
	  	classes = {
	          @ConstructorResult(
	              targetClass = TimesheetHours.class,
	              columns = {	                  
	            		   @ColumnResult(name = "resourceName", type=String.class),
	            		   @ColumnResult(name = "resourceStatus", type=Boolean.class),	            		   
	            		   @ColumnResult(name = "periodStart", type=String.class),
	            		   @ColumnResult(name = "periodEnd", type=String.class),
	            		   @ColumnResult(name = "periodId"),
	            		   @ColumnResult(name = "periodMonth", type=String.class),
	            		   @ColumnResult(name = "submitted", type=Boolean.class),
	            		   @ColumnResult(name = "empId", type=Float.class),
	            		   @ColumnResult(name = "billableHrs", type=BigDecimal.class),
	 	                   @ColumnResult(name = "nonBillableHrs", type=BigDecimal.class),
	                           @ColumnResult(name = "nonWorkHours", type=Float.class),
	            		   @ColumnResult(name = "billableAllocHrs", type=Float.class),
	            		   @ColumnResult(name = "nonBillableAllocHrs", type=Float.class),
	            		   @ColumnResult(name = "rejectCount"),
	            		   @ColumnResult(name = "resourceId")
	              }
	          )
	      }
	  ),
	// Query to find leaves taken by Associate in a period <SRA : 13-07-17>
	@SqlResultSetMapping(
			  name = "leave_details",
			  	classes = {
			          @ConstructorResult(
			              targetClass = TimesheetHours.class,
			              columns = {	                  
			            		   @ColumnResult(name = "resourceName", type=String.class),			            		  
			            		   @ColumnResult(name = "itemDate", type=Date.class),
			            		   @ColumnResult(name = "taskName", type=String.class),
			 	                   @ColumnResult(name = "nonBillableHrs", type=BigDecimal.class)
			              }
			          )
			      }
			  ),
	// Query to find leaves taken by Associate in a period 
	@SqlResultSetMapping(
			name = "tshours_detail", 
			classes = {
					@ConstructorResult(
						targetClass = TimesheetHours.class, 
						columns = {
								@ColumnResult(name = "itemDate", type = Date.class) 
						}
					) 
				}
	)
})
@NamedNativeQueries({    
    @NamedNativeQuery(
            name    =   "getTimesheetHrsByTsitemId",
            query   =   "select tshrs.*, cast(p.title as varchar) as projectName, p.itemId as projectId, cast(task.title as varchar) as taskName" +
    				" FROM " + LoadConstant.otc + ".[dbo].tsitemhours tshrs" +
    				" left join " + LoadConstant.otc + ".[dbo].tsitem tsitem on tsitem.tsitemId=tshrs.tsitemId" +
    				" left join " + LoadConstant.otc + ".[dbo].tstimesheet ts on ts.timesheetId=tsitem.timesheetId" +
    				" left join " + LoadConstant.otc + ".[dbo].taskCenter task on task.taskId=tsitem.taskId" +
    				" left join " + LoadConstant.infomaster + ".[dbo].project p on p.itemId=task.projectId" +
    				" WHERE tshrs.tsitemId = :tsitemId",
                        resultClass=TimesheetHours.class,  resultSetMapping = "detailed_tshrs"                       		
    ),
    @NamedNativeQuery(
            name    =   "getTimesheetHrsByPeriodIdAndUserId",
            query   =   "select tshrs.*, cast(p.title as varchar) as projectName, p.itemId as projectId, cast(task.title as varchar) as taskName" +
	    				" FROM " + LoadConstant.otc + ".[dbo].tsitemhours tshrs" +
	    				" left join " + LoadConstant.otc + ".[dbo].tsitem tsitem on tsitem.tsitemId=tshrs.tsitemId" +
	    				" left join " + LoadConstant.otc + ".[dbo].tstimesheet ts on ts.timesheetId=tsitem.timesheetId" +
	    				" left join " + LoadConstant.otc + ".[dbo].taskCenter task on task.taskId=tsitem.taskId" +
	    				" left join " + LoadConstant.infomaster + ".[dbo].project p on p.itemId=task.projectId" +
	    				" WHERE ts.periodId = :periodId" +
	    				" AND ts.uid = :uid",
                        resultClass=TimesheetHours.class,  resultSetMapping = "detailed_tshrs"                       		
    ),
    @NamedNativeQuery(
            name    =   "getTimesheetHrsByPeriodIdAndPmUid",
            query   =   "select tshrs.*, cast(p.title as varchar) as projectName, p.itemId as projectId, cast(task.title as varchar) as taskName" +
	    				" FROM " + LoadConstant.otc + ".[dbo].tsitemhours tshrs" +
	    				" left join " + LoadConstant.otc + ".[dbo].tsitem tsitem on tsitem.tsitemId=tshrs.tsitemId" +
	    				" left join " + LoadConstant.otc + ".[dbo].tstimesheet ts on ts.timesheetId=tsitem.timesheetId" +
	    				" left join " + LoadConstant.otc + ".[dbo].taskCenter task on task.taskId=tsitem.taskId" +
	    				" left join " + LoadConstant.infomaster + ".[dbo].project p on p.itemId=task.projectId" +
	    				" WHERE ts.periodId = :periodId" +
	    				" AND tsitem.taskId in (select taskId from " + LoadConstant.otc + ".[dbo].taskCenter where projectId in " +
	    				" (SELECT itemId FROM " + LoadConstant.infomaster + ".[dbo].[project] where projectManagersId = :uid))" +
	    				" order by taskName;",    
                        resultClass=TimesheetHours.class,  resultSetMapping = "detailed_tshrs"                       		
    ),
    @NamedNativeQuery(
            name    =   "getTsHrsByProjectAndMonth",
			    query   =   "select r.Title as resourceName," +
			    		" r.Disabled as resourceStatus," +
	    				" getdate() as periodStart," +
	    				" getdate() as periodEnd," +
	    				" 0 as periodId," +
	    				" '' as periodMonth," +
			    		" 'true' as submitted," +
			    		" r.empId as empId," +
			    		" (SELECT COALESCE(sum(tsh.billableHrs), 0) "+
			    				"from " + LoadConstant.otc + ".[dbo].[tsitemhours] tsh" +
			    			   	" left join " + LoadConstant.otc + ".[dbo].[tsitem] tsi on tsi.tsitemId = tsh.tsItemId" +
			    				" left join " + LoadConstant.otc + ".[dbo].[taskCenter] task on task.taskId = tsi.taskId" +
			    				//" left join " + LoadConstant.infomaster + ".[dbo].[project] p on p.itemId = task.projectId" +
			    				" left join " + LoadConstant.otc + ".[dbo].[tstimesheet] t on t.timesheetId = tsi.timesheetId" +
			    				//" left join " + LoadConstant.infomaster + ".[dbo].[resource] rr1 on rr1.uid = t.uid" +
			    			   	//" where ( ((:pid != 0) and (p.itemId = :pid)) or ((:pid = 0) and (p.itemId is not null)) ) and rr1.uid = r.uid" +
			    			   	" where ( ((:pid != 0) and (task.projectId = :pid)) or ((:pid = 0) and (task.projectId is not null)) ) and t.uid = r.uid" +
			    				" and MONTH(tsh.itemDate) = :month AND YEAR(tsh.itemDate) = :year) as billableHrs," +
	    				" (SELECT COALESCE(sum(tsh.nonBillableHrs),0) "+
			    				"from " + LoadConstant.otc + ".[dbo].[tsitemhours] tsh" +
			    			   	" left join " + LoadConstant.otc + ".[dbo].[tsitem] tsi on tsi.tsitemId = tsh.tsItemId" +
			    				" left join " + LoadConstant.otc + ".[dbo].[taskCenter] task on task.taskId = tsi.taskId" +
			    				//" left join " + LoadConstant.infomaster + ".[dbo].[project] p on p.itemId = task.projectId" +
			    				" left join " + LoadConstant.otc + ".[dbo].[tstimesheet] t on t.timesheetId = tsi.timesheetId" +
			    				//" left join " + LoadConstant.infomaster + ".[dbo].[resource] rr1 on rr1.uid = t.uid" +
			    			   	//" where ( ((:pid != 0) and (p.itemId = :pid)) or ((:pid = 0) and (p.itemId is not null)) ) and rr1.uid = r.uid" +
			    			   	" where ( ((:pid != 0) and (task.projectId = :pid)) or ((:pid = 0) and (task.projectId is not null)) ) and t.uid = r.uid" +
			    			   	" and MONTH(tsh.itemDate) = :month AND YEAR(tsh.itemDate) = :year) as nonBillableHrs," +
	    				"(SELECT COALESCE(sum(tsh.nonBillableHrs),0) " +
	    						" from " + LoadConstant.otc + ".[dbo].[tsitemhours] tsh" +
			    			   	" left join " + LoadConstant.otc + ".[dbo].[tsitem] tsi on tsi.tsitemId = tsh.tsItemId" +
			    				" left join " + LoadConstant.otc + ".[dbo].[taskCenter] task on task.taskId = tsi.taskId" +
			    				//" left join " + LoadConstant.infomaster + ".[dbo].[project] p on p.itemId = task.projectId" +
			    				" left join " + LoadConstant.otc + ".[dbo].[tstimesheet] t on t.timesheetId = tsi.timesheetId" +
			    				//" left join " + LoadConstant.infomaster + ".[dbo].[resource] rr1 on rr1.uid = t.uid" +
			    			   	//" where (p.itemId is null) and rr1.uid = r.uid" +
			    			   	" where (task.projectId is null) and t.uid = r.uid" +
			    				" and MONTH(tsh.itemDate) = :month AND YEAR(tsh.itemDate) = :year) as nonWorkHours," +
				   	" (SELECT COALESCE(sum(a.alcHrs), 0) from " + LoadConstant.otc + ".[dbo].[monthly_allocation] a" +
							" where ( ((:pid != 0) and (a.projectId = :pid)) or (:pid = 0) ) and a.uid = r.uid and a.prdName = :monthStr" +
							" and (a.alcType = 1 or a.alcType = 4)) as billableAllocHrs," +
				   	" (SELECT COALESCE(sum(a.alcHrs), 0) from " + LoadConstant.otc + ".[dbo].[monthly_allocation] a" +
						   	" where ( ((:pid != 0) and (a.projectId = :pid)) or (:pid = 0) ) and a.uid = r.uid and a.prdName = :monthStr" +
						   	" and (a.alcType != 1 and a.alcType != 4)) as nonBillableAllocHrs," +
				   	" 0 as rejectCount," +
				   	" r.uid as resourceId" +
				   	" from " + LoadConstant.otc + ".[dbo].[monthly_allocation] alc" +
				   	" left join " + LoadConstant.infomaster + ".[dbo].[resource] r on r.uid = alc.uid" +
				   	" where ( ((:pid != 0) and (alc.projectId = :pid))"+ // To return ts hrs summary for all project users	
				   			 " or (:pid = 0) )" + // To return ts hrs summary for all users
					" and alc.prdName = :monthStr" +
					" and ( (r.Disabled = 1 and YEAR(r.lastDate) = :year and MONTH(r.lastDate) >= :month) or" + // to remove the associates with duplicate uid like Dilp Rewtani / Sarang Bhagat AND to show only associates who were disabled in the selected month
						  " (r.Disabled = 0) )" +
					" group by r.title, r.Disabled, r.uid, r.empId" +
					" order by r.title",                         
			                                      
                    resultClass=TimesheetHours.class,  resultSetMapping = "ts_details"  
                        
    ),
    @NamedNativeQuery(
            name    =   "getTsHrsByMonth",
			    query   =   "select r.Title as resourceName," +
			    		" r.Disabled as resourceStatus," +
	    				" getdate() as periodStart," +
	    				" getdate() as periodEnd," +
	    				" 0 as periodId," +
	    				" '' as periodMonth," +
			    		" 'true' as submitted," +
			    		" r.empId as empId," +
			    		" (SELECT COALESCE(sum(tsh.billableHrs), 0) "+
			    				"from " + LoadConstant.otc + ".[dbo].[tsitemhours] tsh" +
			    			   	" left join " + LoadConstant.otc + ".[dbo].[tsitem] tsi on tsi.tsitemId = tsh.tsItemId" +
			    				" left join " + LoadConstant.otc + ".[dbo].[taskCenter] task on task.taskId = tsi.taskId" +
			    				//" left join " + LoadConstant.infomaster + ".[dbo].[project] p on p.itemId = task.projectId" +
			    				" left join " + LoadConstant.otc + ".[dbo].[tstimesheet] t on t.timesheetId = tsi.timesheetId" +
			    				//" left join " + LoadConstant.infomaster + ".[dbo].[resource] rr1 on rr1.uid = t.uid" +
			    			   	//" where ( ((:pid != 0) and (p.itemId = :pid)) or ((:pid = 0) and (p.itemId is not null)) ) and rr1.uid = r.uid" +
			    			   	" where ( ((:pid != 0) and (task.projectId = :pid)) or ((:pid = 0) and (task.projectId is not null)) ) and t.uid = r.uid" +
			    				" and MONTH(tsh.itemDate) = :month AND YEAR(tsh.itemDate) = :year) as billableHrs," +
	    				" (SELECT COALESCE(sum(tsh.nonBillableHrs),0) "+
			    				"from " + LoadConstant.otc + ".[dbo].[tsitemhours] tsh" +
			    			   	" left join " + LoadConstant.otc + ".[dbo].[tsitem] tsi on tsi.tsitemId = tsh.tsItemId" +
			    				" left join " + LoadConstant.otc + ".[dbo].[taskCenter] task on task.taskId = tsi.taskId" +
			    				//" left join " + LoadConstant.infomaster + ".[dbo].[project] p on p.itemId = task.projectId" +
			    				" left join " + LoadConstant.otc + ".[dbo].[tstimesheet] t on t.timesheetId = tsi.timesheetId" +
			    				//" left join " + LoadConstant.infomaster + ".[dbo].[resource] rr1 on rr1.uid = t.uid" +
			    			   	//" where ( ((:pid != 0) and (p.itemId = :pid)) or ((:pid = 0) and (p.itemId is not null)) ) and rr1.uid = r.uid" +
			    			   	" where ( ((:pid != 0) and (task.projectId = :pid)) or ((:pid = 0) and (task.projectId is not null)) ) and t.uid = r.uid" +
			    			   	" and MONTH(tsh.itemDate) = :month AND YEAR(tsh.itemDate) = :year) as nonBillableHrs," +
	    				"(SELECT COALESCE(sum(tsh.nonBillableHrs),0) " +
	    						" from " + LoadConstant.otc + ".[dbo].[tsitemhours] tsh" +
			    			   	" left join " + LoadConstant.otc + ".[dbo].[tsitem] tsi on tsi.tsitemId = tsh.tsItemId" +
			    				" left join " + LoadConstant.otc + ".[dbo].[taskCenter] task on task.taskId = tsi.taskId" +
			    				//" left join " + LoadConstant.infomaster + ".[dbo].[project] p on p.itemId = task.projectId" +
			    				" left join " + LoadConstant.otc + ".[dbo].[tstimesheet] t on t.timesheetId = tsi.timesheetId" +
			    				//" left join " + LoadConstant.infomaster + ".[dbo].[resource] rr1 on rr1.uid = t.uid" +
			    			   	//" where (p.itemId is null) and rr1.uid = r.uid" +
			    			   	" where (task.projectId is null) and t.uid = r.uid" +
			    				" and MONTH(tsh.itemDate) = :month AND YEAR(tsh.itemDate) = :year) as nonWorkHours," +
	    				" (SELECT COALESCE(sum(a.alcHrs), 0) from " + LoadConstant.otc + ".[dbo].[monthly_allocation] a" +
								" where ( ((:pid != 0) and (a.projectId = :pid)) or (:pid = 0) ) and a.uid = r.uid and a.prdName = :monthStr" +
								" and (a.alcType = 1 or a.alcType = 4)) as billableAllocHrs," +
					   	" (SELECT COALESCE(sum(a.alcHrs), 0) from " + LoadConstant.otc + ".[dbo].[monthly_allocation] a" +
							   	" where ( ((:pid != 0) and (a.projectId = :pid)) or (:pid = 0) ) and a.uid = r.uid and a.prdName = :monthStr" +
							   	" and (a.alcType != 1 and a.alcType != 4)) as nonBillableAllocHrs," +
				   	" 0 as rejectCount," +
				   	" r.uid as resourceId" +
				   	" from " + LoadConstant.infomaster + ".[dbo].[resource] r" +
				   	" where ( (r.Disabled = 1 and YEAR(r.lastDate) = :year and MONTH(r.lastDate) >= :month) or" + // to remove the associates with duplicate uid like Dilp Rewtani / Sarang Bhagat AND to show only associates who were disabled in the selected month
						  " (r.Disabled = 0) )" +
					" group by r.title, r.Disabled, r.uid, r.empId" +
					" order by r.title",                         
			                                      
                    resultClass=TimesheetHours.class,  resultSetMapping = "ts_details"  
                        
    ),
    @NamedNativeQuery(
            name    =   "getWkTsHrsSummaryByUserAndMonth",
    		query   =   "select '' as resourceName," +
    				" 0 as resourceStatus," +
    				" FORMAT(per.period_start, 'dd MMM yy') as periodStart," +
    				" FORMAT(per.period_end, 'dd MMM yy') as periodEnd," +
    				" per.period_id as periodId," +
    				" FORMAT(per.period_end, 'MMM') as periodMonth," +
					" 0 as submitted," +
					" null as empId," +
					" (SELECT COALESCE(sum(tsh.billableHrs), 0) " +
		    				" from " + LoadConstant.otc + ".[dbo].[tsitemhours] tsh" +
		    			   	" left join " + LoadConstant.otc + ".[dbo].[tsitem] tsi on tsi.tsitemId = tsh.tsItemId" +
		    				" left join " + LoadConstant.otc + ".[dbo].[taskCenter] task on task.taskId = tsi.taskId" +
		    				" left join " + LoadConstant.otc + ".[dbo].[tstimesheet] t on t.timesheetId = tsi.timesheetId" +
		    				" where ( ((:pid != 0) and (task.projectId = :pid)) or ((:pid = 0) and (task.projectId IN (SELECT p.itemId FROM " + LoadConstant.infomaster + ".[dbo].[project] p))) ) and t.uid = :uid" +
		    			   	" and t.periodId =  per.PERIOD_ID) as billableHrs," +
	    				" (SELECT COALESCE(sum(tsh.nonBillableHrs),0) " +
		    				" from " + LoadConstant.otc + ".[dbo].[tsitemhours] tsh" +
		    			   	" left join " + LoadConstant.otc + ".[dbo].[tsitem] tsi on tsi.tsitemId = tsh.tsItemId" +
		    				" left join " + LoadConstant.otc + ".[dbo].[taskCenter] task on task.taskId = tsi.taskId" +
		    				" left join " + LoadConstant.otc + ".[dbo].[tstimesheet] t on t.timesheetId = tsi.timesheetId" +
		    				" where ( ((:pid != 0) and (task.projectId = :pid)) or ((:pid = 0) and (task.projectId IN (SELECT p.itemId FROM " + LoadConstant.infomaster + ".[dbo].[project] p))) ) and t.uid = :uid" +
		    			   	" and t.periodId =  per.PERIOD_ID) as nonBillableHrs," +
    				" (SELECT COALESCE(sum(tsh.nonBillableHrs),0)" +
		    				" from " + LoadConstant.otc + ".[dbo].[tsitemhours] tsh" +
		    			   	" left join " + LoadConstant.otc + ".[dbo].[tsitem] tsi on tsi.tsitemId = tsh.tsItemId" +
		    				" left join " + LoadConstant.otc + ".[dbo].[taskCenter] task on task.taskId = tsi.taskId" +
		    				" left join " + LoadConstant.otc + ".[dbo].[tstimesheet] t on t.timesheetId = tsi.timesheetId" +
		    				" where (tsi.taskId IN (SELECT nw.tsnonworkId FROM " + LoadConstant.otc + ".[dbo].[tsnonwork] nw)) and t.uid = :uid" +
		    				" and t.periodId =  per.PERIOD_ID) as nonWorkHours," +
					" (SELECT COALESCE(sum(a.alcHrs), 0) from " + LoadConstant.otc + ".[dbo].[monthly_allocation] a" +
					" left join " + LoadConstant.otc + ".[dbo].[allocation] al on a.alcId = al.alcId" +
						" where ( ((:pid != 0) and (a.projectId = :pid)) or (:pid = 0) ) and a.uid = :uid and a.prdName = :monthStr" +
					   	" and (a.alcType = 1 or a.alcType = 4) and al.alcStatus = 'Active') as billableAllocHrs," +
					" (SELECT COALESCE(sum(a.alcHrs), 0) from " + LoadConstant.otc + ".[dbo].[monthly_allocation] a" +
				 	" left join " + LoadConstant.otc + ".[dbo].[allocation] al on a.alcId = al.alcId" +
						" where ( ((:pid != 0) and (a.projectId = :pid)) or (:pid = 0) ) and a.uid = :uid and a.prdName = :monthStr" +
						" and (a.alcType != 1 and a.alcType != 4) and al.alcStatus = 'Active') as nonBillableAllocHrs," +
		    	   	" (SELECT count(tii.tsItemId) from " + LoadConstant.otc + ".[dbo].[tsitem] tii" +
		    	   		" left join " + LoadConstant.otc + ".[dbo].[tstimesheet] tt on tt.timesheetId = tii.timesheetId" +
			    		" where tt.uid = :uid and tii.approvalStatus = 2 and tt.periodId = per.period_id) as rejectCount," +
		    		" 0 as resourceId" +
		    	   	" from " + LoadConstant.otc + ".[dbo].[tsperiod] per" +
		    	   	" where ( ((:month = 0) and (:year = 0) and (per.locked = 0)) OR"+		    	   	
		    	   			" ((:month != 0) and (:year != 0)"+
		    	   				" and (MONTH(per.period_start) = :month AND YEAR(per.period_start) = :year)) )"+
	    	   					//" and (MONTH(per.period_end) = :month AND YEAR(per.period_end) = :year)) )"+   	
		    	   	//" group by per.period_id, per.period_start, per.period_end" +
		    	   	" order by period_start;",
		    	   	resultClass=TimesheetHours.class,  resultSetMapping = "ts_details"
   	),
    // Query to find leaves taken by Associate in a period <SRA : 13-07-17>
    @NamedNativeQuery(
            name    =   "getLeaveHrsByPeriodIdAndEmpId",
            query   =   "select r.Title as resourceName, tshrs.itemDate as itemDate,	nw.taskName as taskName, sum(tshrs.nonBillableHrs) as nonBillableHrs" +
						" FROM " + LoadConstant.otc + ".[dbo].tsitemhours tshrs" +
						" left join " + LoadConstant.otc + ".[dbo].tsitem tsitem on tsitem.tsitemId=tshrs.tsitemId" +
						" left join " + LoadConstant.otc + ".[dbo].tstimesheet ts on ts.timesheetId=tsitem.timesheetId" +
						" left join " + LoadConstant.otc + ".[dbo].taskCenter task on task.taskId=tsitem.taskId" +
						" left join " + LoadConstant.infomaster + ".[dbo].project p on p.itemId=task.projectId" +
						" left join " + LoadConstant.infomaster + ".[dbo].[resource] r on r.uid = ts.uid" +
						" left join " + LoadConstant.otc + ".[dbo].[tsnonwork] nw on nw.tsnonworkId = tsitem.taskId" +
						" WHERE p.title is NULL AND ts.uid = :uid AND ts.periodId = :periodId" +
						" group by tshrs.itemDate, r.Title,nw.taskName;",
                        resultClass=TimesheetHours.class,  resultSetMapping = "leave_details"                       		
    ),
    	// Query to find timesheet filled by Associate after allocation end date <Shri :
 		// 20-02-19>
 		@NamedNativeQuery(name = "getTsHrsByProjectAndAlcEndDate", query = "select tsh.itemDate" + " FROM "
 				+ LoadConstant.otc + ".[dbo].tstimesheet ts" + " left join " + LoadConstant.otc
 				+ ".[dbo].tsitem tsi on ts.timesheetId=tsi.timesheetId" + " left join " + LoadConstant.otc
 				+ ".[dbo].tsitemhours tsh on tsi.tsitemId=tsh.tsitemId" + " left join " + LoadConstant.otc
 				+ ".[dbo].tssubmit tss on tss.timesheetId=tsi.timesheetId"
 				+ " WHERE tss.projectId = :pid and ts.uid = :uid AND tsh.totalWorkedHrs > '0.00' AND cast(tsh.itemDate as DATE) >= :alcEndDate order by tsh.itemDate desc", resultClass = TimesheetHours.class, resultSetMapping = "tshours_detail")
})
public class TimesheetHours{
 
 	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
 	private Integer tshoursId;
 	
 	@ManyToOne
        @OnDelete(action=OnDeleteAction.CASCADE)
	@JoinColumn(name="tsitemId")
	private TimesheetItem timesheetItem;
 	
 	@Temporal(TemporalType.DATE)
 	private Date itemDate; 
 	
 	@Column(precision=4,scale=2)
 	private BigDecimal billableHrs; 
 	@Column(precision=4,scale=2)
 	private BigDecimal nonBillableHrs; 
 	@Column(precision=4,scale=2)
 	private BigDecimal totalWorkedHrs;
 	
 	@Column(name="notes") 
    @Lob 
 	private String notes; 
 	
 	@Transient
	private String taskName;	// Transient field for task reference
 	
 	@Transient
	private String projectName;	// Transient field for project reference
 	
 	@Transient
	private Integer projectId;	// Transient field for project reference
 	
 	@Transient
 	private Float nonWorkHours; 	
 	@Transient
	private Float billableAllocHrs; // Transient field for estimated billable allocation hours 
	@Transient
	private Float nonBillableAllocHrs; // Transient field for estimated non-billable allocation hours 
	
	@Transient
	private String resourceName;	// Transient field for resource Name 
	
	@Transient
	private Integer empId; // Transient field for resource employee id 
	
	@Transient
	private Boolean resourceStatus; // Transient field for resource status 
	
	@Transient
	private Integer resourceId;	// Transient field for resource Name 
	
	@Transient
	private Integer periodId;	// Transient field for period Id 
	
	@Transient
	private String month;	// Transient field for month
	
	@Transient
	private Integer submitted;	// Transient field for project submit status by associate
	
 	private Integer createdBy;	
	private Date createdDate;	
	private Integer modifiedBy;
	private Date modifiedDate;
 	
	public Integer getTshoursId() {
		return tshoursId;
	}
	public void setTshoursId(Integer tshoursId) {
		this.tshoursId = tshoursId;
	}
	public TimesheetItem getTimesheetItem() {
		return timesheetItem;
	}
	public void setTimesheetItem(TimesheetItem timesheetItem) {
		this.timesheetItem = timesheetItem;
	}
	public Date getItemDate() {
		return itemDate;
	}
	public void setItemDate(Date itemDate) {
		this.itemDate = itemDate;
	}	
	public BigDecimal getBillableHrs() {
		return billableHrs;
	}
	public void setBillableHrs(BigDecimal billableHrs) {
		this.billableHrs = billableHrs;
	}
	public BigDecimal getNonBillableHrs() {
		return nonBillableHrs;
	}
	public void setNonBillableHrs(BigDecimal nonBillableHrs) {
		this.nonBillableHrs = nonBillableHrs;
	}
	public BigDecimal getTotalWorkedHrs() {
		return totalWorkedHrs;
	}
	public void setTotalWorkedHrs(BigDecimal totalWorkedHrs) {
		this.totalWorkedHrs = totalWorkedHrs;
	}
	public String getNotes() {
		return notes;
	}
	public void setNotes(String notes) {
		this.notes = notes;
	}
	public String getTaskName() {
		return taskName;
	}
	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	public Integer getProjectId() {
		return projectId;
	}
	public void setProjectId(Integer projectId) {
		this.projectId = projectId;
	}
	@Transient
	public Float getNonWorkHours() {
		return nonWorkHours;
	}
	public void setNonWorkHours(Float nonWorkHours) {
		this.nonWorkHours = nonWorkHours;
	}
	public Float getBillableAllocHrs() {
		return billableAllocHrs;
	}
	public void setBillableAllocHrs(Float billableAllocHrs) {
		this.billableAllocHrs = billableAllocHrs;
	}
	public Float getNonBillableAllocHrs() {
		return nonBillableAllocHrs;
	}
	public void setNonBillableAllocHrs(Float nonBillableAllocHrs) {
		this.nonBillableAllocHrs = nonBillableAllocHrs;
	}
	
	@Transient
	public String getResourceName() {
		return resourceName;
	}
	public void setResourceName(String resourceName) {
		this.resourceName = resourceName;
	}
	
	@Transient	
	public Integer getEmpId() {
		return empId;
	}
	public void setEmpId(Integer empId) {
		this.empId = empId;
	}
	@Transient
	public Boolean getResourceStatus() {
		return resourceStatus;
	}
	public void setResourceStatus(Boolean resourceStatus) {
		this.resourceStatus = resourceStatus;
	}
	@Transient
	public Integer getResourceId() {
		return resourceId;
	}
	public void setResourceId(Integer resourceId) {
		this.resourceId = resourceId;
	}
	
	
	@Transient
	public Integer getPeriodId() {
		return periodId;
	}
	public void setPeriodId(Integer periodId) {
		this.periodId = periodId;
	}
	@Transient
	public String getMonth() {
		return month;
	}
	public void setMonth(String month) {
		this.month = month;
	}
	public Integer getSubmitted() {
		return submitted;
	}

	public void setSubmitted(Integer submitted) {
		this.submitted = submitted;
	}
	
	public Integer getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public Integer getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public Date getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}	
	
	public TimesheetHours() {
	};	

	public TimesheetHours(Integer tshoursId, Integer tsitemId, Date itemDate, 
			BigDecimal billableHrs, BigDecimal nonBillableHrs, BigDecimal totalWorkedHrs, String notes,
    		String projectName, Integer projectId, String taskName, Date createdDate, Integer createdBy ) {
		this.tshoursId = tshoursId;
		
        this.timesheetItem = new TimesheetItem();
        this.timesheetItem.setTsitemId(tsitemId);
        
        this.itemDate = itemDate;
        this.billableHrs = billableHrs;        
        this.nonBillableHrs = nonBillableHrs;
        this.totalWorkedHrs = totalWorkedHrs;
        this.notes = notes;
        this.projectName = projectName;
        this.projectId = projectId;
        this.taskName = taskName;
        this.createdDate = createdDate;
        this.createdBy = createdBy;
        
    };
    
    // Timesheet hours constructor for fetching timesheet details
    public TimesheetHours(String resourceName, Boolean resourceStatus, String periodStart, String periodEnd, Integer periodId, String periodMonth,
    		Boolean submitted, Float empId, BigDecimal billableHrs, BigDecimal nonBillableHrs, Float nonWorkHours, Float billableAllocHrs, Float nonBillableAllocHrs, 
    		Integer rejectCount, Integer resourceId) 
    {	
	
		this.resourceName = resourceName;
		this.resourceStatus = resourceStatus;
		if(periodId != 0 && periodId != null)
		{
			this.resourceName = periodStart + " - " + periodEnd;
			this.periodId = periodId;    
			this.month = periodMonth; 
		}
		
		this.nonWorkHours = nonWorkHours;
		this.billableAllocHrs = billableAllocHrs;
		this.nonBillableAllocHrs = nonBillableAllocHrs;
		
		if(submitted == null)
		{
			this.submitted = 0;
		}
		else if (submitted == true)
		{
			this.submitted = 1;
		}
		
		if(rejectCount > 0)
		{
			this.submitted = 2;
		}
		
		this.empId = 0;
		if(null != empId) this.empId = Math.round(empId);
		
		this.resourceId = resourceId;
		
		this.billableHrs = billableHrs;
		this.nonBillableHrs = nonBillableHrs;
    };
    
    // Query to find leaves taken by Associate in a period <SRA : 13-07-17>
    public TimesheetHours(String resourceName, Date itemDate, String taskName, BigDecimal nonBillableHrs) 
    {	
    	this.resourceName = resourceName;
    	this.itemDate = itemDate;
    	this.taskName = taskName;
    	this.nonBillableHrs = nonBillableHrs;
    }
    
	// Query to find timesheet filled by Associate after allocation end date
	public TimesheetHours(Date itemDate) {
		this.itemDate = itemDate;
	}
 	
}
