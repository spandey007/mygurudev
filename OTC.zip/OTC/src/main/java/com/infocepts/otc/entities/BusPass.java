package com.infocepts.otc.entities;

import java.util.Date;

import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.infocepts.otc.utilities.LoadConstant;

@SqlResultSetMapping(
		name = "routes_bus_pass",
	      classes = {
	          @ConstructorResult(
	              targetClass = BusPass.class,
	              columns = {
	            		  
	            	
	          			//normal cols
	                  @ColumnResult(name = "busPassId"),
	                  @ColumnResult(name = "uid"),
	                  @ColumnResult(name = "status", type=String.class),
	                  @ColumnResult(name = "comments", type=String.class),
	                  @ColumnResult(name = "cardNo"),
	                  @ColumnResult(name = "cardStartDate", type=Date.class),
	                  @ColumnResult(name = "cardEndDate", type=Date.class),
	                  @ColumnResult(name = "cardIssuedById"),
	                  @ColumnResult(name = "cardType", type=String.class),
	                  @ColumnResult(name = "commentsByIssuer", type=String.class),
	                  @ColumnResult(name = "createdBy"),
	                  @ColumnResult(name = "createdDate", type=Date.class),
	                  @ColumnResult(name = "modifiedBy"),
	                  @ColumnResult(name = "modifiedDate", type=Date.class),
	                  @ColumnResult(name = "cardIssueStart", type=Date.class),
	                  @ColumnResult(name = "cardIssueEnd", type=Date.class),
	                  @ColumnResult(name = "reqClosure", type=Boolean.class),
	                  @ColumnResult(name = "confirmedNodalPt"),
	                  @ColumnResult(name = "closureReason", type=String.class),	                  
	                 
	                  //join cols
	              	  @ColumnResult(name = "workLocationId" ),
	              	  @ColumnResult(name = "busRouteId"),
	              	  @ColumnResult(name = "busNodalPointId"),	                 
	                  @ColumnResult(name = "busRouteTimingsId"),
	                  @ColumnResult(name = "pickUpTime", type=String.class),
	                                
	    
	                  //transient-----------
	                  @ColumnResult(name = "empId"),
	             	  @ColumnResult(name = "title", type=String.class),
	                  @ColumnResult(name = "permTelephoneNo", type=String.class),
	                  @ColumnResult(name = "tempMobNo", type=String.class),
	                  @ColumnResult(name = "email", type=String.class),
	                  @ColumnResult(name = "permStreet1", type=String.class),
	                  @ColumnResult(name = "permStreet2", type=String.class),
	                  @ColumnResult(name = "cityName", type=String.class),	             	
	                  @ColumnResult(name = "cardIssuedByName", type=String.class),	          		  
	                  @ColumnResult(name = "locationName", type=String.class),
	                  @ColumnResult(name = "busRouteName", type=String.class),
	                  @ColumnResult(name = "nodalPointName", type=String.class),
	                  @ColumnResult(name = "confirmedNodalPtName", type=String.class),
	                  @ColumnResult(name = "busFare", type=String.class),
	          		  
	              
	                 
	                 
	                  
	                 
	                }
	          )
	      }
	)
@NamedNativeQueries({
	   @NamedNativeQuery(
			   
			  
              
	            name    =   "getRoutes_BusPass_By_Uid",
	            query   =   "select bp.busPassId as busPassId,"+
		            		"bp.uid as uid, bp.status as status,"+
		            		"bp.comments as comments, bp.cardNo as cardNo,"+
		            		"bp.cardStartDate as cardStartDate, bp.cardEndDate as cardEndDate,"+
		            		"bp.cardIssuedById as cardIssuedById, bp.cardType as cardType,"+
		            		"bp.commentsByIssuer as commentsByIssuer, bp.createdBy as createdBy,"+
		            		"bp.createdDate as createdDate, bp.modifiedBy as modifiedBy,"+
		            		"bp.modifiedDate as modifiedDate, bp.cardIssueStart as cardIssueStart, bp.cardIssueEnd as cardIssueEnd, bp.reqClosure,"+
	            		
							"bp.confirmedNodalPt as confirmedNodalPt,bp.closureReason as closureReason, bp.workLocationId as workLocationId, bp.busRouteId as busRouteId,"+
							"bp.busNodalPointId as busNodalPointId, bp.busRouteTimingsId as busRouteTimingsId, rt.pickUpTime as pickUpTime,"+
	            		
							"r.empId as empId, r.title as title, r.permTelephoneNo as permTelephoneNo,"+
	            			"r.tempMobNo as tempMobNo, r.email as email, r.permStreet1 as permStreet1,"+
	            			"r.permStreet2 as permStreet2, c.cityName as cityName, "+
	            			"rr.title as cardIssuedByName, w.locationName as locationName, br.busRouteName as busRouteName,"+
	            			"np.nodalPointName as nodalPointName, np1.nodalPointName as confirmedNodalPtName, np1.busFare as busFare"+
	            			
	            			" FROM " + LoadConstant.otc + ".[dbo].[buspass] bp"+
	            			" left join " + LoadConstant.infomaster + ".[dbo].[resource] r on r.uid=bp.uid"+
	            			" left join " + LoadConstant.infomaster + ".[dbo].[city] c on c.cityId=r.cityId"+
	            			" left join " + LoadConstant.otc + ".[dbo].[busroute] br on br.busRouteId=bp.busRouteId"+
	            			" left join " + LoadConstant.otc + ".[dbo].[worklocation] w on w.workLocationId=bp.workLocationId"+
	            			" left join " + LoadConstant.otc + ".[dbo].[busnodalpoint] np on np.busNodalPointId=bp.busNodalPointId"+
	            			" left join " + LoadConstant.otc + ".[dbo].[busnodalpoint] np1 on np1.busNodalPointId=bp.confirmedNodalPt"+
	            			" left join " + LoadConstant.otc + ".[dbo].[busroutetimings] rt on rt.busNodalPointId=bp.confirmedNodalPt and rt.busRouteId=bp.busRouteId"+
	            			" left join " + LoadConstant.infomaster + ".[dbo].[resource] rr on rr.uid=bp.cardIssuedById"+
	            			" where bp.uid = :uid order by bp.status desc",
	                       resultClass=BusPass.class, resultSetMapping = "routes_bus_pass"                       		
	    ),
	   @NamedNativeQuery(
	            name    =   "getRoutes_BusPass_All",
	            		query   =   "select bp.busPassId as busPassId,"+
			            		"bp.uid as uid, bp.status as status,"+
			            		"bp.comments as comments, bp.cardNo as cardNo,"+
			            		"bp.cardStartDate as cardStartDate, bp.cardEndDate as cardEndDate,"+
			            		"bp.cardIssuedById as cardIssuedById, bp.cardType as cardType,"+
			            		"bp.commentsByIssuer as commentsByIssuer, bp.createdBy as createdBy,"+
			            		"bp.createdDate as createdDate, bp.modifiedBy as modifiedBy,"+
			            		"bp.modifiedDate as modifiedDate, bp.cardIssueStart as cardIssueStart, bp.cardIssueEnd as cardIssueEnd, bp.reqClosure,"+
		            		
								"bp.confirmedNodalPt as confirmedNodalPt, bp.closureReason as closureReason, bp.workLocationId as workLocationId, bp.busRouteId as busRouteId,"+
								"bp.busNodalPointId as busNodalPointId, bp.busRouteTimingsId as busRouteTimingsId, rt.pickUpTime as pickUpTime,"+
		            		
			            		"r.empId as empId, r.title as title, r.permTelephoneNo as permTelephoneNo,"+
		            			"r.tempMobNo as tempMobNo, r.email as email, r.permStreet1 as permStreet1,"+
		            			"r.permStreet2 as permStreet2, c.cityName as cityName, "+
		            			"rr.title as cardIssuedByName, w.locationName as locationName, br.busRouteName as busRouteName,"+
		            			"np.nodalPointName as nodalPointName, np1.nodalPointName as confirmedNodalPtName, np1.busFare as busFare"+
		            			
		            			" FROM " + LoadConstant.otc + ".[dbo].[buspass] bp"+
		            			" left join " + LoadConstant.infomaster + ".[dbo].[resource] r on r.uid=bp.uid"+
		            			" left join " + LoadConstant.infomaster + ".[dbo].[city] c on c.cityId=r.cityId"+
		            			" left join " + LoadConstant.otc + ".[dbo].[busroute] br on br.busRouteId=bp.busRouteId"+
		            			" left join " + LoadConstant.otc + ".[dbo].[worklocation] w on w.workLocationId=bp.workLocationId"+
		            			" left join " + LoadConstant.otc + ".[dbo].[busnodalpoint] np on np.busNodalPointId=bp.busNodalPointId"+
		            			" left join " + LoadConstant.otc + ".[dbo].[busnodalpoint] np1 on np1.busNodalPointId=bp.confirmedNodalPt"+
		            			" left join " + LoadConstant.otc + ".[dbo].[busroutetimings] rt on rt.busNodalPointId=bp.confirmedNodalPt and rt.busRouteId=bp.busRouteId"+
		            			" left join " + LoadConstant.infomaster + ".[dbo].[resource] rr on rr.uid=bp.cardIssuedById order by bp.status desc",		               			
	                       resultClass=BusPass.class, resultSetMapping = "routes_bus_pass"                       		
	    ),
	   @NamedNativeQuery(
	            name    =   "getRoutes_BusPass_By_Id",
	            		query   =   "select bp.busPassId as busPassId,"+
			            		"bp.uid as uid, bp.status as status,"+
			            		"bp.comments as comments, bp.cardNo as cardNo,"+
			            		"bp.cardStartDate as cardStartDate, bp.cardEndDate as cardEndDate,"+
			            		"bp.cardIssuedById as cardIssuedById, bp.cardType as cardType,"+
			            		"bp.commentsByIssuer as commentsByIssuer, bp.createdBy as createdBy,"+
			            		"bp.createdDate as createdDate, bp.modifiedBy as modifiedBy,"+
			            		"bp.modifiedDate as modifiedDate, bp.cardIssueStart as cardIssueStart, bp.cardIssueEnd as cardIssueEnd, bp.reqClosure,"+
		            		
								"bp.confirmedNodalPt as confirmedNodalPt, bp.closureReason as closureReason, bp.workLocationId as workLocationId, bp.busRouteId as busRouteId,"+
								"bp.busNodalPointId as busNodalPointId, bp.busRouteTimingsId as busRouteTimingsId, rt.pickUpTime as pickUpTime,"+
		            		
								"r.empId as empId, r.title as title, r.permTelephoneNo as permTelephoneNo,"+
		            			"r.tempMobNo as tempMobNo, r.email as email, r.permStreet1 as permStreet1,"+
		            			"r.permStreet2 as permStreet2, c.cityName as cityName, "+
		            			"rr.title as cardIssuedByName, w.locationName as locationName, br.busRouteName as busRouteName,"+
		            			"np.nodalPointName as nodalPointName, np1.nodalPointName as confirmedNodalPtName, np1.busFare as busFare"+
		            			
		            			" FROM " + LoadConstant.otc + ".[dbo].[buspass] bp"+
		            			" left join " + LoadConstant.infomaster + ".[dbo].[resource] r on r.uid=bp.uid"+
		            			" left join " + LoadConstant.infomaster + ".[dbo].[city] c on c.cityId=r.cityId"+
		            			" left join " + LoadConstant.otc + ".[dbo].[busroute] br on br.busRouteId=bp.busRouteId"+
		            			" left join " + LoadConstant.otc + ".[dbo].[worklocation] w on w.workLocationId=bp.workLocationId"+
		            			" left join " + LoadConstant.otc + ".[dbo].[busnodalpoint] np on np.busNodalPointId=bp.busNodalPointId"+
		            			" left join " + LoadConstant.otc + ".[dbo].[busnodalpoint] np1 on np1.busNodalPointId=bp.confirmedNodalPt"+
		            			" left join " + LoadConstant.otc + ".[dbo].[busroutetimings] rt on rt.busNodalPointId=bp.confirmedNodalPt and rt.busRouteId=bp.busRouteId"+
		            			" left join " + LoadConstant.infomaster + ".[dbo].[resource] rr on rr.uid=bp.cardIssuedById"+
		            			" where bp.busPassId = :busPassId",
	                       resultClass=BusPass.class, resultSetMapping = "routes_bus_pass"                       		
	    )
})


@Entity
@Table(catalog=LoadConstant.otc, schema="[dbo]",name="buspass")
public class BusPass {	
	
	//Columns
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer busPassId;
	private Integer uid;
	private String status;
	private String comments;
	private Integer cardNo;
	private Date cardStartDate;
	private Date cardEndDate;
	private Integer cardIssuedById;
	private String cardType;
	
	@Lob
	private String commentsByIssuer;
	private Integer createdBy;
	private Date createdDate;
	private Integer modifiedBy;
	private Date modifiedDate;
	private Date cardIssueStart;
	private Date cardIssueEnd;
	private Boolean reqClosure;
	private Integer confirmedNodalPt;
	private String closureReason;
		
	@ManyToOne
	@JoinColumn(name="workLocationId")
	private WorkLocation worklocation;
	
	@ManyToOne
	@JoinColumn(name="busRouteId")
	private BusRoute busroute;
	
	@ManyToOne
	@JoinColumn(name="busNodalPointId")
	private BusNodalPoint busnodalpoint;
	

	private Integer busRouteTimingsId;
	private String pickUpTime;
	
	@Transient
	private String busFare;
		
	@Transient
	private Integer empId;
	
	@Transient
	private String title;
	
	@Transient
	private String permTelephoneNo;
	
	@Transient
	private String tempMobNo;
	
	@Transient
	private String email;
	
	@Transient
	private String permStreet1;
	
	@Transient
	private String permStreet2;
	
	@Transient
	private String cityName;
	
	@Transient
	private String cardIssuedByName;
		
	@Transient
	private String locationName;
	
	@Transient
	private String busRouteName;
	
	@Transient
	private String nodalPointName;
	
	@Transient
	private String confirmedNodalPtName;
	
	
	//Getter and Setter	
	public Integer getBusPassId() {
		return busPassId;
	}

	public void setBusPassId(Integer busPassId) {
		this.busPassId = busPassId;
	}

	public Integer getUid() {
		return uid;
	}

	public void setUid(Integer uid) {
		this.uid = uid;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public Integer getCardNo() {
		return cardNo;
	}

	public void setCardNo(Integer cardNo) {
		this.cardNo = cardNo;
	}

	public Date getCardStartDate() {
		return cardStartDate;
	}

	public void setCardStartDate(Date cardStartDate) {
		this.cardStartDate = cardStartDate;
	}

	public Date getCardEndDate() {
		return cardEndDate;
	}

	public void setCardEndDate(Date cardEndDate) {
		this.cardEndDate = cardEndDate;
	}

	public Integer getCardIssuedById() {
		return cardIssuedById;
	}

	public void setCardIssuedById(Integer cardIssuedById) {
		this.cardIssuedById = cardIssuedById;
	}

	public String getCardType() {
		return cardType;
	}

	public void setCardType(String cardType) {
		this.cardType = cardType;
	}

	public String getCommentsByIssuer() {
		return commentsByIssuer;
	}

	public void setCommentsByIssuer(String commentsByIssuer) {
		this.commentsByIssuer = commentsByIssuer;
	}

	public Integer getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Integer getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public Date getCardIssueStart() {
		return cardIssueStart;
	}

	public void setCardIssueStart(Date cardIssueStart) {
		this.cardIssueStart = cardIssueStart;
	}

	public Date getCardIssueEnd() {
		return cardIssueEnd;
	}

	public void setCardIssueEnd(Date cardIssueEnd) {
		this.cardIssueEnd = cardIssueEnd;
	}

	public WorkLocation getWorklocation() {
		return worklocation;
	}

	public void setWorklocation(WorkLocation worklocation) {
		this.worklocation = worklocation;
	}

	public BusRoute getBusroute() {
		return busroute;
	}

	public void setBusroute(BusRoute busroute) {
		this.busroute = busroute;
	}

	public BusNodalPoint getBusnodalpoint() {
		return busnodalpoint;
	}

	public void setBusnodalpoint(BusNodalPoint busnodalpoint) {
		this.busnodalpoint = busnodalpoint;
	}

	public Integer getBusRouteTimingsId() {
		return busRouteTimingsId;
	}

	public void setBusRouteTimingsId(Integer busRouteTimingsId) {
		this.busRouteTimingsId = busRouteTimingsId;
	}

	public Integer getEmpId() {
		return empId;
	}

	public void setEmpId(Integer empId) {
		this.empId = empId;
	}
	
	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getPermTelephoneNo() {
		return permTelephoneNo;
	}

	public void setPermTelephoneNo(String permTelephoneNo) {
		this.permTelephoneNo = permTelephoneNo;
	}

	public String getTempMobNo() {
		return tempMobNo;
	}

	public void setTempMobNo(String tempMobNo) {
		this.tempMobNo = tempMobNo;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPermStreet1() {
		return permStreet1;
	}

	public void setPermStreet1(String permStreet1) {
		this.permStreet1 = permStreet1;
	}

	public String getPermStreet2() {
		return permStreet2;
	}

	public void setPermStreet2(String permStreet2) {
		this.permStreet2 = permStreet2;
	}

	public String getCityName() {
		return cityName;
	}

	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	public String getCardIssuedByName() {
		return cardIssuedByName;
	}

	public void setCardIssuedByName(String cardIssuedByName) {
		this.cardIssuedByName = cardIssuedByName;
	}

	public String getLocationName() {
		return locationName;
	}

	public void setLocationName(String locationName) {
		this.locationName = locationName;
	}

	public String getBusRouteName() {
		return busRouteName;
	}

	public void setBusRouteName(String busRouteName) {
		this.busRouteName = busRouteName;
	}

	public String getNodalPointName() {
		return nodalPointName;
	}

	public void setNodalPointName(String nodalPointName) {
		this.nodalPointName = nodalPointName;
	}
	
	public Boolean getReqClosure() {
		return reqClosure;
	}

	public void setReqClosure(Boolean reqClosure) {
		this.reqClosure = reqClosure;
	}	

	

	public Integer getConfirmedNodalPt() {
		return confirmedNodalPt;
	}

	public void setConfirmedNodalPt(Integer confirmedNodalPt) {
		this.confirmedNodalPt = confirmedNodalPt;
	}
	
	
	
	public String getClosureReason() {
		return closureReason;
	}

	public void setClosureReason(String closureReason) {
		this.closureReason = closureReason;
	}

	public String getPickUpTime() {
		return pickUpTime;
	}

	public void setPickUpTime(String pickUpTime) {
		this.pickUpTime = pickUpTime;
	}

	public String getBusFare() {
		return busFare;
	}

	public void setBusFare(String busFare) {
		this.busFare = busFare;
	}

	public String getConfirmedNodalPtName() {
		return confirmedNodalPtName;
	}

	public void setConfirmedNodalPtName(String confirmedNodalPtName) {
		this.confirmedNodalPtName = confirmedNodalPtName;
	}

	public BusPass() {
		
	}
	
	public BusPass(Integer busPassId, Integer uid, String status, String comments, Integer cardNo, Date cardStartDate,
			Date cardEndDate, Integer cardIssuedById, String cardType, String commentsByIssuer, Integer createdBy,
			Date createdDate, Integer modifiedBy, Date modifiedDate, Date cardIssueStart, Date cardIssueEnd, Boolean reqClosure,
			Integer confirmedNodalPt, String closureReason,		
			Integer workLocationId, Integer busRouteId, Integer busNodalPointId, Integer busRouteTimingsId, String pickUpTime,
			
			Integer empId, String title, String permTelephoneNo, String tempMobNo, String email, String permStreet1,
			String permStreet2, String cityName, String cardIssuedByName, String locationName, String busRouteName,
			String nodalPointName, String confirmedNodalPtName, String busFare) {
		//super();
		this.busPassId = busPassId;
		this.uid = uid;
		this.status = status;
		this.comments = comments;
		this.cardNo = cardNo;
		this.cardStartDate = cardStartDate;
		this.cardEndDate = cardEndDate;
		this.cardIssuedById = cardIssuedById;
		this.cardType = cardType;
		this.commentsByIssuer = commentsByIssuer;
		this.createdBy = createdBy;
		this.createdDate = createdDate;
		this.modifiedBy = modifiedBy;
		this.modifiedDate = modifiedDate;
		this.cardIssueStart = cardIssueStart;
		this.cardIssueEnd = cardIssueEnd;	
		this.reqClosure = reqClosure;
		this.confirmedNodalPt = confirmedNodalPt;
		this.closureReason = closureReason;
		if(workLocationId != null)
		{
			this.worklocation = new WorkLocation();
			this.worklocation.setWorkLocationId(workLocationId);
		}		
		if(busRouteId != null)
		{
			this.busroute = new BusRoute();
			this.busroute.setBusRouteId(busRouteId);
		}
		if(busNodalPointId != null) 
		{
			this.busnodalpoint = new BusNodalPoint();
			this.busnodalpoint.setBusNodalPointId(busNodalPointId);
		}
		this.busRouteTimingsId = busRouteTimingsId;
		this.pickUpTime = pickUpTime;
		this.empId = empId;
		this.title = title;
		this.permTelephoneNo = permTelephoneNo;
		this.tempMobNo = tempMobNo;
		this.email = email;
		this.permStreet1 = permStreet1;
		this.permStreet2 = permStreet2;
		this.cityName = cityName;
		this.cardIssuedByName = cardIssuedByName;
		this.locationName = locationName;
		this.busRouteName = busRouteName;
		this.nodalPointName = nodalPointName;
		this.confirmedNodalPtName = confirmedNodalPtName;
		this.busFare = busFare;
	}

	

	

	
	
	
	
	
	
	
}

