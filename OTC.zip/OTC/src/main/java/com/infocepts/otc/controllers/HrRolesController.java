package com.infocepts.otc.controllers;

import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.infocepts.otc.entities.HrRoles;
import com.infocepts.otc.repositories.HrRolesRepository;

@RestController
@RequestMapping(value="/hrroles",headers="referer")
public class HrRolesController {
	
	final Logger logger = Logger.getLogger(HrRolesController.class);
	
	@Autowired
	HrRolesRepository repository;
	
	@RequestMapping(method=RequestMethod.GET)
	 public List<HrRoles> getAllHrRoles(){
		 List<HrRoles> hrRolesList=null;
		 try{
			 hrRolesList = repository.findAll();
		 }
		 catch(Exception e){
			logger.error(e);
		 }
		 return hrRolesList;
	 }
}
