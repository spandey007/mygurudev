package com.infocepts.otc.controllers;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.mail.MessagingException;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.infocepts.otc.entities.Project;
import com.infocepts.otc.entities.Resource;
import com.infocepts.otc.notification.SmtpMailSender;
import com.infocepts.otc.repositories.AccountRepository;
import com.infocepts.otc.repositories.InfoTravelRepository;
import com.infocepts.otc.repositories.ProjectRepository;
import com.infocepts.otc.repositories.ResourceRepository;
import com.infocepts.otc.services.TimesheetService;
import com.infocepts.otc.utilities.UniqueArrayList;


@RestController
@RequestMapping(value="/project",headers="referer")
public class ProjectController {

	final Logger logger = Logger.getLogger(ProjectController.class.getName());	
	
	
	@Autowired
	ProjectRepository projectRepository;
	
	@Autowired
	HttpSession session;
	
	@PersistenceContext(unitName="otc")
    private EntityManager manager;
	
	@Autowired
	TimesheetService timesheetService;
	
	@Autowired
	SmtpMailSender smtpMailSender;
	
	@Autowired
	ProjectController projectController;
	
	@Autowired
	ResourceController resourceController;
	
	@Autowired
	AccountRepository accountRepository;
	
	@Autowired
	ResourceRepository resourceRepository;
	
	@Autowired
	InfoTravelRepository infoTravelRepository;
	
	@Autowired
	TimesheetService service;
	
	
	@RequestMapping(method=RequestMethod.GET)
	public List<Project> getAllProjects(@RequestParam(value = "limit", defaultValue = "0") Integer limit,
			 							@RequestParam(value = "uid", defaultValue = "0") Integer uid,
			 							@RequestParam(value = "cepUid", defaultValue = "0") Integer cepUid,
			 							@RequestParam(value = "dmUid", defaultValue = "0") Integer dmUid,
			 							@RequestParam(value = "ahUid", defaultValue = "0") Integer ahUid,
			 							@RequestParam(value = "pmUid", defaultValue = "0") Integer pmUid,
			 							@RequestParam(value = "createdBy", defaultValue = "0") Integer createdBy,
			 							@RequestParam(value = "accountId", defaultValue = "0") Integer accountId,
			 							@RequestParam(value = "month", defaultValue = "0") Integer month,
			 							@RequestParam(value = "year", defaultValue = "0") Integer year,
			 							@RequestParam(value = "type", defaultValue = "") String type,
			 							@RequestParam(value = "pid", defaultValue = "0") Integer pid,
			 							@RequestParam(value = "state", defaultValue = "Active") String state,
			 							@RequestParam(value = "projectDDL", defaultValue = "false") boolean projectDDL,
			 							@RequestParam(value = "deProject", defaultValue = "false") boolean deProject,			 							
			 							@RequestParam(value = "portfolioHeadId", defaultValue = "0") Integer portfolioHeadId,
			 							@RequestParam(value = "plannerId", defaultValue = "0") Integer plannerId,
			 							HttpServletRequest request){
		List<Project> projectlist=null;
				
		try{
			if (createdBy != 0) {
                projectlist = manager.createNamedQuery("getProjectsByCreater", Project.class)
                		.setParameter("createdBy", createdBy)
                        .setParameter("state", state)
                        .getResultList();
            } else if (uid != 0) {					
				projectlist = manager.createNamedQuery("getMyAllocatedProjects", Project.class)
						.setParameter("uid", uid) 
						.setParameter("state", state)
						.getResultList();

			}
            else if (0 != month && 0 != year && !type.isEmpty())
			{
				if(type.equals("project"))
				{
					projectlist = manager.createNamedQuery("getProjectWithRevenueByMonth", Project.class)
						//.setParameter("month", month)
						.setParameter("year", year)
						.setParameter("pid", pid)
						.setParameter("accountId", accountId)
						.setParameter("cepId", cepUid)
						.setParameter("phId", dmUid)
						.getResultList();
				}
				else if(type.equals("sow"))
				{
					projectlist = manager.createNamedQuery("getSowWithRevenueByMonth", Project.class)
							//.setParameter("month", month)
							.setParameter("year", year)
							.setParameter("pid", pid)
							.setParameter("accountId", accountId)
							.setParameter("cepId", cepUid)
							.setParameter("phId", dmUid)
							.getResultList();
				}
            }
			else if(pmUid != 0)
			{
				projectlist = manager.createNamedQuery("getProjectsByPm", Project.class)
						.setParameter("pmUid", pmUid) 
						.setParameter("state", state)
						.getResultList();				
			}
			else if(ahUid != 0)
			{
				projectlist = manager.createNamedQuery("getProjectsAsAh", Project.class)
						.setParameter("ahUid", ahUid) 
						.setParameter("state", state)
						.getResultList();				
			}
			else if(cepUid != 0)
			{
				projectlist = manager.createNamedQuery("getProjectsAsCep", Project.class)
						.setParameter("cepUid", cepUid) 
						.setParameter("state", state)
						.getResultList();				
			}
			else if(dmUid != 0)
			{
				projectlist = manager.createNamedQuery("getMyPortfolioProjects", Project.class)
						.setParameter("dmUid", dmUid) 
						.setParameter("state", state)
						.getResultList();
			}
			else if(0 != limit)
			{
				projectlist = manager.createNamedQuery("getLatestProjects", Project.class)
						.setParameter("state", state)
						.getResultList();
			}			
			else if (0 != accountId)
			{
				projectlist = manager.createNamedQuery("getProjectsByAccount", Project.class)
						.setParameter("accountId", accountId)
						.setParameter("state", state)
						.getResultList();
            }
			else if (projectDDL)
			{
				if(portfolioHeadId == 0)
				{
					projectlist = manager.createNamedQuery("getAllProjectsDropDown", Project.class)
							.setParameter("state", state)
							.getResultList();
				}
				else{
					projectlist = manager.createNamedQuery("getAllProjectsDropDownForPH", Project.class)
							.setParameter("state", state)
							.setParameter("portfolioHeadId", portfolioHeadId)
							.getResultList();
				}
				
				
            }else if(deProject){
				projectlist = manager.createNamedQuery("getDeProjects", Project.class)
						.setParameter("state", state)
						.getResultList(); 
            }else if(plannerId!=0){
				projectlist = manager.createNamedQuery("getDePlannerProjects", Project.class)
						.setParameter("state", state)
						.setParameter("plannerId", plannerId)
						.getResultList();             	
            }
			
			else{
            	projectlist = manager.createNamedQuery("getAllProjects", Project.class)
                        .getResultList();
            }		
        }
		catch(Exception e){
			logger.log(Level.SEVERE, "exceptn msg", e);
		}
		return projectlist;
	}
	
	@RequestMapping(method=RequestMethod.POST)
	public void addProject(@RequestBody Project project, 
							HttpServletRequest request) throws MessagingException, UnauthorizedException {
		/* ------------------------- Authorization start ------------------------------------ */
		Boolean isAValidCall = timesheetService.isAValidProjectCall(0, "Project Add", request);
		if(isAValidCall == true)
		{	
			try{
				Integer lastInfoceptsProjectCode = Integer.parseInt(this.projectRepository.getLastInfoceptsProjectCode().replace("INF",""));
				project.setInfoCeptsProjectCode("INF"+String.format("%05d", ++lastInfoceptsProjectCode));
	            projectRepository.save(project);

				service.sendProjectNotification(project, "add", request); // Allocation add / update solution											
				
	        }catch(Exception e){
	        	logger.log(Level.SEVERE, "exceptn msg", e);
			}
		}
		else
		{
			throw new UnauthorizedException("Access Denied");
		}
	}
	@RequestMapping(value="/{itemId}",method=RequestMethod.GET)
	public Project getProject(@PathVariable Integer itemId){
		Project project = null;
		try{
			project = manager.createNamedQuery("getProjectById", Project.class)
					.setParameter("itemId", itemId)
					.getSingleResult();
			
		}catch(Exception e){
			logger.log(Level.SEVERE, "exceptn msg", e);
		}
		return project;
	}

	@GetMapping("/getProjectHeads")
	public Object getProjectHeads(@RequestParam(value = "itemId", defaultValue = "0") Integer itemId,
			@RequestParam(value = "requesterUid", defaultValue = "0") Integer requesterUid,
			@RequestParam(value = "approverId", defaultValue = "0") Integer approverId,
			HttpServletRequest request){
		System.out.println(requesterUid+"requesterUid");
		Integer loggedInUid = (Integer) session.getAttribute("loggedInUid");
		Project project=null;
		Resource resource = resourceRepository.findResourcebyUid(requesterUid);
		int gradeNo = NumberUtils.toInt(resource.getGrade().getGradeNo());
		List<Object> projectList = new UniqueArrayList<>();
		
		Map<String, List<Object>> resultMap = new HashMap<>(); 
		try{
			project = manager.createNamedQuery("getProjectAllHeads", Project.class)
					.setParameter("itemId", itemId)
					.getSingleResult();


			int pmGrade = NumberUtils.toInt(project.getProjectManagerGrade());
			int pmOGrade = NumberUtils.toInt(project.getProjectOwnerGrade());
			int ahGrade = NumberUtils.toInt(project.getAhGrade());
			int dmGrade = NumberUtils.toInt(project.getDmGrade());
			int rmGrade = NumberUtils.toInt(project.getRmGrade());
			int poGrade = NumberUtils.toInt(project.getPortOwnerGrade());
			
			Integer projectManagersId = project.getProjectManagersId();
			String projectManager = project.getProjectManager();
			Integer ownersId = project.getOwnersId();
			String projectOwner = project.getProjectOwner();
			Integer ahId = project.getAhId();
			String ahIDname = project.getAhIDname();
			Integer dmId = project.getDmId();
			String dmIDname = project.getDmIDname();
			Integer rmId = project.getRmId();
			String rmIDname = project.getRmIDname();
			Integer portOwnerId = project.getPortOwnerId();
			String portOwnerIdname = project.getPortOwnerIdname();

			Integer billingType = project.getBillingTypeId();
			
			
			if (gradeNo <= pmGrade && pmGrade>=6 && projectManagersId!=null) {
				if(!projectManagersId.equals(loggedInUid) || (approverId!=null && approverId.equals(loggedInUid))) {					
					projectList.add(projectManagersId+","+projectManager);
				}
			}
			if (gradeNo <= pmOGrade && pmOGrade>=6 && ownersId!=null) {
				if(!ownersId.equals(loggedInUid) || (approverId!=null && approverId.equals(loggedInUid))) {		
				projectList.add(ownersId+","+projectOwner);
				}
			}
			if (gradeNo <= ahGrade && ahGrade>=6 && ahId!=null) {
				if(!ahId.equals(loggedInUid) || (approverId!=null && approverId.equals(loggedInUid))) {
				projectList.add(ahId+","+ahIDname);
				}
			}
			if (gradeNo <= dmGrade && dmGrade>=6 &&dmId!=null) {
				if(!dmId.equals(loggedInUid) || (approverId!=null && approverId.equals(loggedInUid))) {
				projectList.add(dmId+","+dmIDname);
				}
			}
			if (gradeNo <= rmGrade && rmGrade>=6 && rmId!=null) {
				if(!rmId.equals(loggedInUid) || (approverId!=null && approverId.equals(loggedInUid))) {
				projectList.add(rmId+","+rmIDname);
				}
			}
			if (gradeNo <= poGrade  && poGrade>=6 && portOwnerId!=null) {
				if(!portOwnerId.equals(loggedInUid) || (approverId!=null && approverId.equals(loggedInUid))) {
				projectList.add(portOwnerId+","+ portOwnerIdname);
				}
			}			
			/*
			 * if(projectMap.isEmpty()) { projectMap.putIfAbsent(113,
			 * "Shashank Garg");//very imp to be removed }
			 */
			
			if(billingType !=4) {
				Resource resourceName = resourceRepository.findResourceByUsername("ajoshi");
				projectList.add(resourceName.getUid()+",Aditya Joshi");//very imp to be removed
			}
			if(project.getProjectManagersId()==113) {
				Resource resourceName = resourceRepository.findResourceByUsername("ajoshi");
				projectList.remove(resourceName.getUid());
			}
			
			resultMap.put("projectHead", projectList);
			
		}catch(Exception e){
			logger.log(Level.SEVERE, "exceptn msg", e);
		}
		return resultMap;
	}
	
	
	@RequestMapping(value="/{itemId}",method=RequestMethod.PUT)
	public Project updateProject(@PathVariable Integer itemId, @RequestBody Project project, 
									HttpServletRequest request) throws UnauthorizedException, MessagingException {
		boolean isAValidCall = timesheetService.isAValidProjectCall(itemId, "Project Edit", request);

		if (isAValidCall) {
			try {
				projectRepository.save(project);
				try {
					new Thread(() -> projectRepository.updateAccountInRelatedTreqs(manager, project.getAccountId(), itemId)).start();
				} catch (Exception e) {
					logger.log(Level.SEVERE, "(Project Module) Something went wrong while updating the accountId in related treqs!", e);
				}
				service.sendProjectNotification(project, "update", request); // Allocation add / update solution
			} catch (Exception e) {
				logger.log(Level.SEVERE, "exceptn msg", e);
			}
		} else {
			throw new UnauthorizedException("Access Denied");
		}
		return project;
	}
	
	@GetMapping("/getprojectcount/{userId}")
	public Map<String, Object> getProjectCount(@PathVariable Integer userId) {
		Map<String, Object> countMap = new HashMap<>();
		countMap.putIfAbsent("projectManager", projectRepository.getProjectCountForPM(userId));
		countMap.putIfAbsent("projectPlanner", projectRepository.getProjectCountForPlanner(String.valueOf(userId)));
		return countMap;
	}
	
	@GetMapping("/getProjectMap")
	public Object getProjectsMap(HttpServletRequest request) {
		Map<String, List<Map<String, String>>> projectMap = new HashMap<>();
		projectMap.putIfAbsent("projectMap", projectRepository.getProjectsMap());
		return projectMap;
	}

	@RequestMapping("/getAllProjects")
	public List<Project> getAllProjects(@RequestParam(value = "state", defaultValue = "Active") String state,
										HttpServletRequest request) {
		List<Project> projectlist = null;
		projectlist = manager.createNamedQuery("getAllProjectsDropDown", Project.class)
				.setParameter("state", state)
				.getResultList();
		return projectlist;

	}
	//getAllProjectsbyCoE
	@RequestMapping("/getAllProjectsbyCoE")
	public Object getAllProjectsbyCoE(@RequestParam(value = "coe", defaultValue = "false") boolean coe,
			HttpServletRequest request)
			 {
		List<Project> projectlist = null;

		try {
			if(coe)
			{
				projectlist = manager.createNamedQuery("getAllProjectsByCoE",Project.class) 						
						.getResultList();						  
			}
		} catch (Exception e) {
			logger.log(Level.SEVERE, "exceptn msg", e);
		}
		return projectlist;
	}
	
	@GetMapping("/getProjectById")
	public Object getProjectById(@PathVariable Integer itemId){
		Project project = null;
		try{
			project = manager.createNamedQuery("getProjectById", Project.class)
					.setParameter("itemId", itemId)
					.getSingleResult();
			
		}catch(Exception e){
			logger.log(Level.SEVERE, "exceptn msg", e);
		}
		return project;
	}
	
	@GetMapping("/getProjectHeadsForCab")
	public Object getProjectHeadsForCab(@RequestParam(value = "itemId", defaultValue = "0") Integer itemId,
			@RequestParam(value = "requesterUid", defaultValue = "0") Integer requesterUid,
			@RequestParam(value = "approverId", defaultValue = "0") Integer approverId,
			HttpServletRequest request){
		System.out.println(requesterUid+"requesterUid");
		Integer loggedInUid = (Integer) session.getAttribute("loggedInUid");
		Project project=null;
		Resource resource = resourceRepository.findResourcebyUid(requesterUid);
		int gradeNo = NumberUtils.toInt(resource.getGrade().getGradeNo());
		List<Object> projectList = new UniqueArrayList<>();
		
		Map<String, List<Object>> resultMap = new HashMap<>(); 
		try{
			project = manager.createNamedQuery("getProjectAllHeads", Project.class)
					.setParameter("itemId", itemId)
					.getSingleResult();


			int pmGrade = NumberUtils.toInt(project.getProjectManagerGrade());
			int pmOGrade = NumberUtils.toInt(project.getProjectOwnerGrade());
			int ahGrade = NumberUtils.toInt(project.getAhGrade());
			int dmGrade = NumberUtils.toInt(project.getDmGrade());
			int rmGrade = NumberUtils.toInt(project.getRmGrade());
			int poGrade = NumberUtils.toInt(project.getPortOwnerGrade());
			
			Integer projectManagersId = project.getProjectManagersId();
			String projectManager = project.getProjectManager();
			Integer ownersId = project.getOwnersId();
			String projectOwner = project.getProjectOwner();
			Integer ahId = project.getAhId();
			String ahIDname = project.getAhIDname();
			Integer dmId = project.getDmId();
			String dmIDname = project.getDmIDname();
			Integer rmId = project.getRmId();
			String rmIDname = project.getRmIDname();
			Integer portOwnerId = project.getPortOwnerId();
			String portOwnerIdname = project.getPortOwnerIdname();

			Integer billingType = project.getBillingTypeId();
			
			
			if (projectManagersId!=null) {
				if(!projectManagersId.equals(loggedInUid) || (approverId!=null && approverId.equals(loggedInUid))) {					
					projectList.add(projectManagersId+","+projectManager);
				}
			}
			if (ownersId!=null) {
				if(!ownersId.equals(loggedInUid) || (approverId!=null && approverId.equals(loggedInUid))) {		
				projectList.add(ownersId+","+projectOwner);
				}
			}
			if (ahId!=null) {
				if(!ahId.equals(loggedInUid) || (approverId!=null && approverId.equals(loggedInUid))) {
				projectList.add(ahId+","+ahIDname);
				}
			}
			if (dmId!=null) {
				if(!dmId.equals(loggedInUid) || (approverId!=null && approverId.equals(loggedInUid))) {
				projectList.add(dmId+","+dmIDname);
				}
			}
			if (rmId!=null) {
				if(!rmId.equals(loggedInUid) || (approverId!=null && approverId.equals(loggedInUid))) {
				projectList.add(rmId+","+rmIDname);
				}
			}
			if (portOwnerId!=null) {
				if(!portOwnerId.equals(loggedInUid) || (approverId!=null && approverId.equals(loggedInUid))) {
				projectList.add(portOwnerId+","+ portOwnerIdname);
				}
			}	
			
			if(billingType !=4) {
				Resource resourceName = resourceRepository.findResourceByUsername("ajoshi");
				projectList.add(resourceName.getUid()+",Aditya Joshi");//very imp to be removed
			}
			if(project.getProjectManagersId()==113) {
				Resource resourceName = resourceRepository.findResourceByUsername("ajoshi");
				projectList.remove(resourceName.getUid());
			}
			
			resultMap.put("projectHead", projectList);
			
		}catch(Exception e){
			logger.log(Level.SEVERE, "exceptn msg", e);
		}
		return resultMap;
	}
}
