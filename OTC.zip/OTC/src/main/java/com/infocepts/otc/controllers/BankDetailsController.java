package com.infocepts.otc.controllers;

import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.infocepts.otc.entities.BankDetails;
import com.infocepts.otc.repositories.BankDetailsRepository;

@RestController
@RequestMapping(value="/bankdetails",headers="referer")
public class BankDetailsController {
	
	final Logger logger = Logger.getLogger(BankDetailsController.class);
	
	@Autowired
	BankDetailsRepository repository;
	
	@RequestMapping(method=RequestMethod.GET)
	 public List<BankDetails> getAllBankDetails(@RequestParam(value = "entityId",defaultValue = "0") Integer entityId,
			 									@RequestParam(value = "unitId",defaultValue = "0") Integer unitId){
		 List<BankDetails> bankDetailsList=null;
		 try{
			 if(entityId != 0 && unitId != 0){
				 bankDetailsList = repository.findByEntityId(entityId,unitId);
			 }
			 else{
				 bankDetailsList = repository.findAll();
			 }
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return bankDetailsList;
	 }
	
	
	@RequestMapping(value="/{bankDetailsId}",method=RequestMethod.GET)
	 public BankDetails getBankDetail(@PathVariable Integer bankDetailsId){
		 BankDetails bankDetail=null;
		 try{
			 bankDetail = repository.findOne(bankDetailsId);
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return bankDetail;
	 }
	
	@GetMapping("/getBankDetailbyId")
	 public BankDetails getBankDetailbyId(@RequestParam(value = "bankDetailsId", defaultValue = "0") Integer bankDetailsId){
		 BankDetails bankDetail=null;
		 try{
			 bankDetail = repository.findOne(bankDetailsId);
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return bankDetail;
	 }

}
