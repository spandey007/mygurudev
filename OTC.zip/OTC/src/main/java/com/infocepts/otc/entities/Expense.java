/**
 * 
 */
package com.infocepts.otc.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.ColumnResult;
import javax.persistence.Entity;
import javax.persistence.EntityResult;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.SqlResultSetMappings;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.infocepts.otc.utilities.LoadConstant;

/**
 * @author Rewatiraman Singh
 *
 */
@Entity
@Table(catalog=LoadConstant.otc, schema="[dbo]",name="expense")
@DynamicUpdate
@DynamicInsert
@SqlResultSetMappings({
@SqlResultSetMapping(name = "myExpenseList", entities = {
		@EntityResult(entityClass = Expense.class)
		},
		columns = {
				@ColumnResult(name="projectTitle"),
				@ColumnResult(name="unitName"),
				@ColumnResult(name="currencyCode")
		}
),
@SqlResultSetMapping(name = "approvalList", entities = {
		@EntityResult(entityClass = Expense.class)
		},
		columns = {
				@ColumnResult(name="resourceName"),
				@ColumnResult(name="projectTitle"),
				@ColumnResult(name="unitName"),
				@ColumnResult(name="currencyCode")
		}
),
@SqlResultSetMapping(name = "fetchPurpose", entities =
			@EntityResult(entityClass = ExpensePurpose.class)
),
@SqlResultSetMapping(name = "reportSearch", entities = {
			@EntityResult(entityClass = Expense.class)
},
		columns = {
				@ColumnResult(name = "projectTitle"),
				@ColumnResult(name = "resourceName"),
				@ColumnResult(name = "unitName"),
				@ColumnResult(name = "currencyCode"),
		}
),
@SqlResultSetMapping(name = "userExpense", entities = {
		@EntityResult(entityClass = Expense.class)
},
columns = {
		@ColumnResult(name = "projectTitle"),
		@ColumnResult(name = "resourceName"),
		@ColumnResult(name = "designation"),
		@ColumnResult(name = "unitName"),
		@ColumnResult(name = "currencyCode"),
}
		),
@SqlResultSetMapping(name = "fetchProjects", 
columns = {
		@ColumnResult(name = "projectId"),
		@ColumnResult(name = "projectName"),
}
		),
@SqlResultSetMapping(name = "getApprovers", 
columns = {
		@ColumnResult(name = "uid"),
		@ColumnResult(name = "title"),
}
		)
})
public class Expense implements Serializable {

	/**
	 */
	private static final long serialVersionUID = 5767854005738191016L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer expenseId;
	private Integer uid;
	private Integer projectId;
	private Date dateOfSubmission;
	private Date settlementDate;
	private Integer status;
	private Date startDate;
	private Date endDate;
	private Date pmApprovalDate;
	private Date faApprovalDate;
	private Date tdApprovalDate;
	private String comments;
	private Integer createdBy;
	private Date createdDate;
	private Integer modifiedBy;
	private Date modifiedDate;
	private Integer reimburseType;
	private String tourCode;

	@Transient
	private int empId;
	
	@Transient
	private String expenseCode;
	
	@Transient 
	private Expense expense;
	
	@Transient
	private String resourceName;

	private Integer travelStatus;
	
	private Integer financeStatus;
	
	private Integer unitId;
	
	@Transient
	private String pmComments;
	
	@Transient
	private String tdComments;
	
	@Transient
	private String faComments;

	@Transient
	private String projectTitle;

	@Transient
	private String currencyCode;

	@Transient
	private Resource resource;
	
	private Double totalAmount;
	
	@Transient
	private String formattedAmount;
	
	@Transient
	private String formattedStartDate;
	
	@Transient
	private String formattedEndDate;
	
	@Transient
	private Boolean isMyExpense;

	@Transient
	private Boolean isReportView;
	
	@Transient
	private String unitName;
	
	@Transient
	private String designation;

	private Integer approverId;

	public Expense() {
	}
	
	/**
	 * @return the projectId
	 */
	public Integer getProjectId() {
		return projectId;
	}

	/**
	 * @param projectId the projectId to set
	 */
	public void setProjectId(Integer projectId) {
		this.projectId = projectId;
	}

	/**
	 * @return the expense
	 */
	public Expense getExpense() {
		return expense;
	}

	/**
	 * @return the resourceName
	 */
	public String getResourceName() {
		return resourceName;
	}

	/**
	 * @param expense the expense to set
	 */
	public void setExpense(Expense expense) {
		this.expense = expense;
	}

	/**
	 * @param resourceName the resourceName to set
	 */
	public void setResourceName(String resourceName) {
		this.resourceName = resourceName;
	}

	/**
	 * @return the expenseId
	 */
	public Integer getExpenseId() {
		return expenseId;
	}

	/**
	 * @return the uid
	 */
	public Integer getUid() {
		return uid;
	}

	/**
	 * @return the dateOfSubmission
	 */
	public Date getDateOfSubmission() {
		return dateOfSubmission;
	}

	/**
	 * @return the settlementDate
	 */
	public Date getSettlementDate() {
		return settlementDate;
	}


	/**
	 * @return the status
	 */
	public Integer getStatus() {
		return status;
	}

	/**
	 * @return the startDate
	 */
	public Date getStartDate() {
		return startDate;
	}

	/**
	 * @return the endDate
	 */
	public Date getEndDate() {
		return endDate;
	}

	/**
	 * @return the createdBy
	 */
	public Integer getCreatedBy() {
		return createdBy;
	}

	/**
	 * @return the createdDate
	 */
	public Date getCreatedDate() {
		return createdDate;
	}

	/**
	 * @return the modifiedBy
	 */
	public Integer getModifiedBy() {
		return modifiedBy;
	}

	/**
	 * @return the modifiedDate
	 */
	public Date getModifiedDate() {
		return modifiedDate;
	}

	/**
	 * @param expenseId the expenseId to set
	 */
	public void setExpenseId(Integer expenseId) {
		this.expenseId = expenseId;
	}

	/**
	 * @param uid the uid to set
	 */
	public void setUid(Integer uid) {
		this.uid = uid;
	}

	/**
	 * @param dateOfSubmission the dateOfSubmission to set
	 */
	public void setDateOfSubmission(Date dateOfSubmission) {
		this.dateOfSubmission = dateOfSubmission;
	}

	/**
	 * @param settlementDate the settlementDate to set
	 */
	public void setSettlementDate(Date settlementDate) {
		this.settlementDate = settlementDate;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(Integer status) {
		this.status = status;
	}

	/**
	 * @param startDate the startDate to set
	 */
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	/**
	 * @param endDate the endDate to set
	 */
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * @param modifiedBy the modifiedBy to set
	 */
	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	/**
	 * @param modifiedDate the modifiedDate to set
	 */
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	/**
	 * @return the expenseCode
	 */
	public String getExpenseCode() {
		return expenseCode;
	}

	/**
	 * @param expenseCode the expenseCode to set
	 */
	public void setExpenseCode(String expenseCode) {
		this.expenseCode = expenseCode;
	}

	/**
	 * @return the travelStatus
	 */
	public Integer getTravelStatus() {
		return travelStatus;
	}

	/**
	 * @return the financeStatus
	 */
	public Integer getFinanceStatus() {
		return financeStatus;
	}

	/**
	 * @return the pmApprovalDate
	 */
	public Date getPmApprovalDate() {
		return pmApprovalDate;
	}

	/**
	 * @return the tdApprovalDate
	 */
	public Date getTdApprovalDate() {
		return tdApprovalDate;
	}

	/**
	 * @return the faApprovalDate
	 */
	public Date getFaApprovalDate() {
		return faApprovalDate;
	}

	/**
	 * @param travelStatus the travelStatus to set
	 */
	public void setTravelStatus(Integer travelStatus) {
		this.travelStatus = travelStatus;
	}

	/**
	 * @param financeStatus the financeStatus to set
	 */
	public void setFinanceStatus(Integer financeStatus) {
		this.financeStatus = financeStatus;
	}

	/**
	 * @param pmApprovalDate the pmApprovalDate to set
	 */
	public void setPmApprovalDate(Date pmApprovalDate) {
		this.pmApprovalDate = pmApprovalDate;
	}

	/**
	 * @param tdApprovalDate the tdApprovalDate to set
	 */
	public void setTdApprovalDate(Date tdApprovalDate) {
		this.tdApprovalDate = tdApprovalDate;
	}

	/**
	 * @param faApprovalDate the faApprovalDate to set
	 */
	public void setFaApprovalDate(Date faApprovalDate) {
		this.faApprovalDate = faApprovalDate;
	}

	/**
	 * @return the pmComments
	 */
	public String getPmComments() {
		return pmComments;
	}

	/**
	 * @return the tdComments
	 */
	public String getTdComments() {
		return tdComments;
	}

	/**
	 * @return the faComments
	 */
	public String getFaComments() {
		return faComments;
	}

	/**
	 * @param pmComments the pmComments to set
	 */
	public void setPmComments(String pmComments) {
		this.pmComments = pmComments;
	}

	/**
	 * @param tdComments the tdComments to set
	 */
	public void setTdComments(String tdComments) {
		this.tdComments = tdComments;
	}

	/**
	 * @param faComments the faComments to set
	 */
	public void setFaComments(String faComments) {
		this.faComments = faComments;
	}

	/**
	 * @return the totalAmount
	 */
	public Double getTotalAmount() {
		return totalAmount;
	}

	/**
	 * @param totalAmount the totalAmount to set
	 */
	public void setTotalAmount(Double totalAmount) {
		this.totalAmount = totalAmount;
	}

	/**
	 * @return the comments
	 */
	public String getComments() {
		return comments;
	}

	/**
	 * @param comments the comments to set
	 */
	public void setComments(String comments) {
		this.comments = comments;
	}

	/**
	 * @return the project name
	 */
	public String getProjectTitle() {
		return projectTitle;
	}

	/**
	 * @param projectTitle the project name to set
	 */
	public void setProjectTitle(String projectTitle) {
		this.projectTitle = projectTitle;
	}

	/**
	 * @return currency code
	 */
	public String getCurrencyCode() {
		return currencyCode;
	}

	/**
	 * @param currencyCode currency code to set
	 */
	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	/**
	 * @return resource object associated with logged in user.
	 */
	public Resource getResource() {
		return resource;
	}

	/**
	 * @param resource resource object to set
	 */
	public void setResource(Resource resource) {
		this.resource = resource;
	}

	/**
	 * @return the formattedAmount
	 */
	public String getFormattedAmount() {
		return formattedAmount;
	}

	/**
	 * @param formattedAmount the formattedAmount to set
	 */
	public void setFormattedAmount(String formattedAmount) {
		this.formattedAmount = formattedAmount;
	}

	/**
	 * @return the formattedStartDate
	 */
	public String getFormattedStartDate() {
		return formattedStartDate;
	}

	/**
	 * @param formattedStartDate the formattedStartDate to set
	 */
	public void setFormattedStartDate(String formattedStartDate) {
		this.formattedStartDate = formattedStartDate;
	}

	/**
	 * @return the formattedEndDate
	 */
	public String getFormattedEndDate() {
		return formattedEndDate;
	}

	/**
	 * @param formattedEndDate the formattedEndDate to set
	 */
	public void setFormattedEndDate(String formattedEndDate) {
		this.formattedEndDate = formattedEndDate;
	}

	/**
	 * @return the isMyExpense
	 */
	public Boolean getIsMyExpense() {
		return isMyExpense;
	}

	/**
	 * @param isMyExpense the isMyExpense to set
	 */
	public void setIsMyExpense(Boolean isMyExpense) {
		this.isMyExpense = isMyExpense;
	}

	/**
	 * @return the reimburseType
	 */
	public Integer getReimburseType() {
		return reimburseType;
	}

	/**
	 * @param reimburseType the reimburseType to set
	 */
	public void setReimburseType(Integer reimburseType) {
		this.reimburseType = reimburseType;
	}

	/**
	 * @return the unitName
	 */
	public String getUnitName() {
		return unitName;
	}

	/**
	 * @param unitName the unitName to set
	 */
	public void setUnitName(String unitName) {
		this.unitName = unitName;
	}

	/**
	 * @return the unitId
	 */
	public Integer getUnitId() {
		return unitId;
	}

	/**
	 * @param unitId the unitId to set
	 */
	public void setUnitId(Integer unitId) {
		this.unitId = unitId;
	}

	public Boolean getReportView() {
		return isReportView;
	}

	public void setReportView(Boolean reportView) {
		isReportView = reportView;
	}

	/**
	 * @return the approverId
	 */
	public Integer getApproverId() {
		return approverId;
	}

	/**
	 * @param approverId the approverId to set
	 */
	public void setApproverId(Integer approverId) {
		this.approverId = approverId;
	}

	/**
	 * @return the tourCode
	 */
	public String getTourCode() {
		return tourCode;
	}

	/**
	 * @param tourCode the tourCode to set
	 */
	public void setTourCode(String tourCode) {
		this.tourCode = tourCode;
	}

	/**
	 * @return the designation
	 */
	public String getDesignation() {
		return designation;
	}

	/**
	 * @param designation the designation to set
	 */
	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}
}
