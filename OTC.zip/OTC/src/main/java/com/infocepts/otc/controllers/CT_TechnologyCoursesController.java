package com.infocepts.otc.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.infocepts.otc.entities.CT_TechnologyCourses;
import com.infocepts.otc.repositories.CT_TechnologyCoursesRepository;
import com.infocepts.otc.services.TimesheetService;

@RestController
@RequestMapping(value="/technologyCourses",headers="referer")
public class CT_TechnologyCoursesController {
	@Autowired
	CT_TechnologyCoursesRepository ct_TechnologyCoursesRepository;
	
	@Autowired
	TimesheetService service;
	
	@RequestMapping(method=RequestMethod.POST)
	public CT_TechnologyCourses addCT_TechnologyCourses(@RequestBody CT_TechnologyCourses cT_TechnologyCourses){
		cT_TechnologyCourses.setTechnologyCourseId(null);
		Boolean isAValidCall = false;
		if(service.isHR() || service.isAdmin())
		{
			isAValidCall = true;
		}
		if(isAValidCall) {
			
			ct_TechnologyCoursesRepository.save(cT_TechnologyCourses);
		}
		return cT_TechnologyCourses;
	}
	
	@RequestMapping(method=RequestMethod.GET)
	public List<CT_TechnologyCourses> getCT_TechnologyCourses(){
		List<CT_TechnologyCourses> list = null;
		Boolean isAValidCall = false;
		if(service.isHR() || service.isAdmin())
		{
			isAValidCall = true;
		}
		if(isAValidCall) {
			list = ct_TechnologyCoursesRepository.findAll();
		}
		return list;
	}
	
	@RequestMapping(value="/{technologyCourseId}",method=RequestMethod.GET)
	public CT_TechnologyCourses getCT_TechnologyCourses(@PathVariable Integer technologyCourseId){
		CT_TechnologyCourses cT_TechnologyCourses = null;
		Boolean isAValidCall = false;
		if(service.isHR() || service.isAdmin())
		{
			isAValidCall = true;
		}
		if(isAValidCall) {
			
			cT_TechnologyCourses = ct_TechnologyCoursesRepository.findOne(technologyCourseId);
		}
		return cT_TechnologyCourses;
	}
	
	@RequestMapping(value="/{technologyCourseId}", method=RequestMethod.PUT)
	public CT_TechnologyCourses updateCT_TechnologyCourses(@PathVariable Integer technologyCourseId,  @RequestBody CT_TechnologyCourses updatedCT_TechnologyCourses){
		updatedCT_TechnologyCourses.setTechnologyCourseId(technologyCourseId);
		Boolean isAValidCall = false;
		if(service.isHR() || service.isAdmin())
		{
			isAValidCall = true;
		}
		if(isAValidCall) {
			ct_TechnologyCoursesRepository.save(updatedCT_TechnologyCourses);
		}
		return updatedCT_TechnologyCourses;
	}
	
	@RequestMapping(value="/{technologyCourseId}",method=RequestMethod.DELETE)
	public void deleteCT_TechnologyCourses(@PathVariable Integer technologyCourseId){
		Boolean isAValidCall = false;
		if(service.isHR() || service.isAdmin())
		{
			isAValidCall = true;
		}
		if(isAValidCall) {
			ct_TechnologyCoursesRepository.delete(technologyCourseId);
		}
	}
}

