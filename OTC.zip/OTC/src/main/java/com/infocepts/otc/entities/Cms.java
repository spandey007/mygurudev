/* 
 * Country JPA Entity to manage Country
 * -------------------------------------------------------------------------------------------------------------------------
 * 20 Sep 2017 - EW creation of the file
 *
*/
package com.infocepts.otc.entities;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.SqlResultSetMappings;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.infocepts.otc.utilities.LoadConstant;
import com.infocepts.otc.utilities.QueryConstant;

@Entity
@Table(catalog=LoadConstant.otc, schema="[dbo]",name="cms")
@SqlResultSetMappings({
	@SqlResultSetMapping(
	      name = "cms_by_createdBy_RM_DM",
	      classes = {
	    	@ConstructorResult(
	              targetClass = Cms.class,
	              columns = {
	                  @ColumnResult(name = "cmsId"),
	                  @ColumnResult(name = "accountId"),
	                  @ColumnResult(name = "opportunityId"),
	                  @ColumnResult(name = "uomId"),
	                  @ColumnResult(name = "currencyId"),
	                  @ColumnResult(name = "dummyProjectName", type=String.class),
	                  @ColumnResult(name = "cost", type=BigDecimal.class),
	                  @ColumnResult(name = "revenue", type=BigDecimal.class),
	                  @ColumnResult(name = "margin", type=BigDecimal.class),	                  
	                  @ColumnResult(name = "status", type=String.class),
	                  @ColumnResult(name = "approvalStatus", type=String.class),
	                  @ColumnResult(name = "approvalDate", type=Date.class),
	                  @ColumnResult(name = "approvedBy"),
	                  @ColumnResult(name = "createdBy"),
	                  @ColumnResult(name = "createdDate", type=Date.class),
	                  @ColumnResult(name = "modifiedBy"),
	                  @ColumnResult(name = "modifiedDate", type=Date.class),
	                  @ColumnResult(name = "accountName", type=String.class),
	                  @ColumnResult(name = "accountNo", type=String.class),
	                  @ColumnResult(name = "rm", type=String.class),
	                  @ColumnResult(name = "dm", type=String.class),
	                  @ColumnResult(name = "createdByName", type=String.class),
	                  @ColumnResult(name = "modifiedByName", type=String.class),
	                  @ColumnResult(name = "currencySign", type=String.class),
	                  @ColumnResult(name = "opportunityName", type=String.class),
	                  @ColumnResult(name = "uomName", type=String.class),
	                  @ColumnResult(name = "daysInMonth",type=String.class),
	                  @ColumnResult(name = "accountStatus", type=String.class),
	                  @ColumnResult(name = "revenueCertain", type=BigDecimal.class),
	                  @ColumnResult(name = "revenueHigh", type=BigDecimal.class),
	                  @ColumnResult(name = "revenueMedium", type=BigDecimal.class),
	                  @ColumnResult(name = "revenueLow", type=BigDecimal.class),
	                  @ColumnResult(name = "revenueProbability", type=BigDecimal.class),	
	                  @ColumnResult(name = "opportunityType",type=String.class),
	                  @ColumnResult(name = "isRevenuePlanning",type=Boolean.class), 
	                  @ColumnResult(name = "ownerId"),
	                  @ColumnResult(name = "monthNo"),
	                  @ColumnResult(name = "monthlyCmsValueCertain", type=BigDecimal.class),
	                  @ColumnResult(name = "monthlyCmsValueHigh", type=BigDecimal.class),
	                  @ColumnResult(name = "monthlyCmsValueMedium", type=BigDecimal.class),
	                  @ColumnResult(name = "monthlyCmsValueLow", type=BigDecimal.class),
	                  @ColumnResult(name = "opportunityNo", type=String.class),
	                  @ColumnResult(name = "secondaryOwnerName", type=String.class),
	                  @ColumnResult(name = "opportunityValueUSD", type=String.class),
	                  @ColumnResult(name = "opportunityAccountId")
	                  
	              }
	          )
	      }),
	@SqlResultSetMapping(
		      name = "cms_by_createdBy_RM_DM_Download",
		      classes = {
		    	@ConstructorResult(
		              targetClass = Cms.class,
		              columns = {		             	                 
		                  @ColumnResult(name = "treqId"),
		                  @ColumnResult(name = "associateLevel", type=String.class),
		                  @ColumnResult(name = "billingPercentage"),
		                  @ColumnResult(name = "fulfilmentType", type=String.class),
		                  @ColumnResult(name = "fulfilledDate", type=Date.class),
		                  @ColumnResult(name = "location", type=String.class),
		                  @ColumnResult(name = "reqStartDate", type=Date.class),
		                  @ColumnResult(name = "reqEndDate", type=Date.class),
		                  @ColumnResult(name = "requisitionType", type=String.class),	                  
		                  @ColumnResult(name = "treqStatus", type=String.class),
		                  @ColumnResult(name = "amgFulfilledDate", type=Date.class),
		                  @ColumnResult(name = "cancelledDate", type=Date.class),
		                  @ColumnResult(name = "rejectedDate", type=Date.class),
		                  @ColumnResult(name = "extension", type=Boolean.class),
		                  @ColumnResult(name = "amount", type=BigDecimal.class),
		                  @ColumnResult(name = "billableRate", type=BigDecimal.class),
		                  @ColumnResult(name = "sowRoleStartDate", type=Date.class),
		                  @ColumnResult(name = "sowRoleEndDate", type=Date.class),
		                  @ColumnResult(name = "roleStatus", type=String.class),
		                  @ColumnResult(name = "cmsId"),
		                  @ColumnResult(name = "accountId"),
		                  @ColumnResult(name = "opportunityId"),		               
		                  @ColumnResult(name = "dummyProjectName", type=String.class),
		                  @ColumnResult(name = "cost", type=BigDecimal.class),
		                  @ColumnResult(name = "revenue", type=BigDecimal.class),
		                  @ColumnResult(name = "margin", type=BigDecimal.class),	                  
		                  @ColumnResult(name = "status", type=String.class),		                 		                 
		                  @ColumnResult(name = "createdDate", type=Date.class),		                  
		                  @ColumnResult(name = "modifiedDate", type=Date.class),
		                  @ColumnResult(name = "accountName", type=String.class),
		                  @ColumnResult(name = "accountNo", type=String.class),
		                  @ColumnResult(name = "rm", type=String.class),
		                  @ColumnResult(name = "dm", type=String.class),
		                  @ColumnResult(name = "createdByName", type=String.class),
		                  @ColumnResult(name = "modifiedByName", type=String.class),
		                  @ColumnResult(name = "currencySign", type=String.class),
		                  @ColumnResult(name = "opportunityName", type=String.class),
		                  @ColumnResult(name = "uomName", type=String.class),
		                  @ColumnResult(name = "accountStatus", type=String.class),		                  
		                  @ColumnResult(name = "revenueProbability", type=BigDecimal.class),	
		                  @ColumnResult(name = "opportunityType",type=String.class),
		                  @ColumnResult(name = "isRevenuePlanning",type=Boolean.class), 
		                  @ColumnResult(name = "opportunityNo", type=String.class),
		                  @ColumnResult(name = "secondaryOwnerName", type=String.class),
		                  @ColumnResult(name = "cmsDetailId"),
		                  @ColumnResult(name = "opportunityValueUSD", type=String.class),
		                  @ColumnResult(name = "opportunityAccountId")
		                  
		               	                  
		              }
		          )
		      })
})
@NamedNativeQueries({
	 @NamedNativeQuery(
	            name    	=   "getCmsByCreatedBy_RM_DM",
	            query   	=   "select c.*, rc.Title as createdByName, rm.Title as modifiedByName, cur.sign as currencySign, "+
			            		"a.title as accountName, a.accountNo, rrm.Title as rm, rdm.Title as dm, o.opportunityName, u.name as uomName, a.status as accountStatus, "+
			            		"0 as monthlyCmsValueCertain, 0 as monthlyCmsValueHigh, 0 as monthlyCmsValueMedium, 0 as monthlyCmsValueLow, 0 as monthNo," +
			            		"o.info_OpportunityNumber as opportunityNo, rs.Title as secondaryOwnerName,o.opportunityValue_USD as opportunityValueUSD , o.accountId as opportunityAccountId "+
			            		" FROM " + LoadConstant.otc + ".[dbo].cms c"+
			            		" Full Join " + LoadConstant.infomaster + ".[dbo].opportunity o on c.opportunityId = o.opportunityId"+
			            		" Left join " + LoadConstant.infomaster + ".dbo.accounts a on o.accountId = a.itemId"+
			            		" Left Join " + LoadConstant.infomaster + ".[dbo].resource rc on rc.uid = c.createdBy"+
			            		" Left Join " + LoadConstant.infomaster + ".[dbo].resource rm on rm.uid = c.modifiedBy"+
			            		" Left Join " + LoadConstant.infomaster + ".[dbo].resource rrm on rrm.uid = a.rmid"+
			            		" Left Join " + LoadConstant.infomaster + ".[dbo].resource rdm on rdm.uid = a.dmid"+
			            		" Left Join " + LoadConstant.infomaster + ".[dbo].currency cur on cur.currencyId = c.currencyId"+
			            		" Left Join " + LoadConstant.infomaster + ".[dbo].uom u on u.uomId = c.uomId"+
			            		" Left Join " + LoadConstant.infomaster + ".[dbo].resource rs on rs.uid = c.ownerId"+
			            		" where c.accountId in (select itemId from " + LoadConstant.infomaster + ".[dbo].accounts where dmId = :uid  or a.rmId = :uid) "+
			            		" or c.createdBy = :uid or c.ownerId = :uid  or a.rmId = :uid"+
			            		//To get all the opportunity of accounts in which user is PM
			            		" or (o.accountId in (select distinct accountId from " + LoadConstant.infomaster + ".[dbo].project where state = 'Active' and projectManagersId = :uid ) and (select count(*) from cms where opportunityId = o.opportunityId) = 0 )",
								resultClass = Cms.class ,  resultSetMapping = "cms_by_createdBy_RM_DM"                          
	 ),
	 @NamedNativeQuery(
	            name    	=   "getCmsById",
	            query   	=   "select c.*, rc.Title as createdByName, rm.Title as modifiedByName, cur.sign as currencySign, "+
	            				"a.title as accountName, a.accountNo, rrm.Title as rm, rdm.Title as dm, o.opportunityName, u.name as uomName, a.status as accountStatus, " + 
	            				"0 as monthlyCmsValueCertain, 0 as monthlyCmsValueHigh, 0 as monthlyCmsValueMedium, 0 as monthlyCmsValueLow, 0 as monthNo," +
	            				"o.info_OpportunityNumber as opportunityNo, rs.Title as secondaryOwnerName,o.opportunityValue_USD as opportunityValueUSD , o.accountId as opportunityAccountId "+
	            				" FROM " + LoadConstant.otc + ".[dbo].cms c"+
			            		" Left join " + LoadConstant.infomaster + ".dbo.accounts a on c.accountId = a.itemId"+
			            		" Left Join " + LoadConstant.infomaster + ".[dbo].opportunity o on c.opportunityId = o.opportunityId"+
			            		" Left Join " + LoadConstant.infomaster + ".[dbo].resource rc on rc.uid = c.createdBy"+
			            		" Left Join " + LoadConstant.infomaster + ".[dbo].resource rm on rm.uid = c.modifiedBy"+
			            		" Left Join " + LoadConstant.infomaster + ".[dbo].resource rrm on rrm.uid = a.rmid"+
			            		" Left Join " + LoadConstant.infomaster + ".[dbo].resource rdm on rdm.uid = a.dmid"+
			            		" Left Join " + LoadConstant.infomaster + ".[dbo].currency cur on cur.currencyId = c.currencyId"+
			            		" Left Join " + LoadConstant.infomaster + ".[dbo].uom u on u.uomId = c.uomId"+
			            		" Left Join " + LoadConstant.infomaster + ".[dbo].resource rs on rs.uid = c.ownerId"+
			            		" where c.cmsId = :cmsId ",								
								resultClass = Cms.class ,  resultSetMapping = "cms_by_createdBy_RM_DM"                          
	    ),
	 	@NamedNativeQuery(
	            name    	=   "getCmsRevenueByMonth",
	            query   	=   "select cms.*, rc.Title as createdByName, '' as modifiedByName, cur.sign as currencySign, "+
	            				"pa.accountShortName as accountName, pa.accountNo, rRm.Title as rm, rDm.Title as dm, op.opportunityName, u.name as uomName, pa.status as accountStatus, "+
	            				QueryConstant.Query_Revenue_Certain_By_Cms + " as monthlyCmsValueCertain, "+
	            				QueryConstant.Query_Revenue_High_By_Cms + " as monthlyCmsValueHigh, "+
	            				QueryConstant.Query_Revenue_Medium_By_Cms + " as monthlyCmsValueMedium, "+
	            				QueryConstant.Query_Revenue_Low_By_Cms + " as monthlyCmsValueLow, "+
	            				" mm.monthNo, "+
	            				"o.info_OpportunityNumber as opportunityNo, rs.Title as secondaryOwnerName,o.opportunityValue_USD as opportunityValueUSD , o.accountId as opportunityAccountId "+
	            				" FROM " + LoadConstant.otc + ".[dbo].cms cms"+	            				
								" LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[accounts] pa on pa.itemId = cms.accountId " +
								" LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[opportunity] op on op.opportunityId = cms.opportunityId " +
								" LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[resource] rDm on rDm.uid = pa.dmId "+
								" LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[resource] rRm on rRm.uid = pa.rmId "+
								" Left Join " + LoadConstant.infomaster + ".[dbo].[resource] rc on rc.uid = cms.createdBy"+
								" Left Join " + LoadConstant.infomaster + ".[dbo].currency cur on cur.currencyId = cms.currencyId"+
								" Left Join " + LoadConstant.infomaster + ".[dbo].uom u on u.uomId = cms.uomId"+
								" LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[year] yy on yy.year = :year "+
								" LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[month] mm on mm.yearId = yy.yearId " +
								" Left Join " + LoadConstant.infomaster + ".[dbo].resource rs on rs.uid = c.ownerId"+
								" where ( (:accountId != 0 and pa.itemId = :accountId) or " +
								"   (:phId != 0 and pa.dmId = :phId) or (:cepId != 0 and pa.rmId = :cepId) or " +
								"   (:accountId = 0 and :phId = 0 and :cepId = 0 and pa.itemId is not null) ) and " +
								"   cms.isRevenuePlanning = 1 and "+
								" 	op.opportunityStage != 'S7-Won - 100%' and op.opportunityStage != 'S7-Lost/Deferred - 0%'",
								resultClass = Cms.class ,  resultSetMapping = "cms_by_createdBy_RM_DM"                          
	    ),
	 	@NamedNativeQuery(
	            name    	=   "getAllCms",
	            query   	=   "select c.*, rc.Title as createdByName, rm.Title as modifiedByName, cur.sign as currencySign, "+
			            		"a.title as accountName, a.accountNo, rrm.Title as rm, rdm.Title as dm, o.opportunityName, u.name as uomName, a.status as accountStatus, "+
			            		"0 as monthlyCmsValueCertain, 0 as monthlyCmsValueHigh, 0 as monthlyCmsValueMedium, 0 as monthlyCmsValueLow, 0 as monthNo," +
			            		"o.info_OpportunityNumber as opportunityNo, rs.Title as secondaryOwnerName,o.opportunityValue_USD as opportunityValueUSD , o.accountId as opportunityAccountId "+
			            		" FROM " + LoadConstant.otc + ".[dbo].cms c"+
			            		" Left join " + LoadConstant.infomaster + ".dbo.accounts a on c.accountId = a.itemId"+
			            		" Left Join " + LoadConstant.infomaster + ".[dbo].opportunity o on c.opportunityId = o.opportunityId"+
			            		" Left Join " + LoadConstant.infomaster + ".[dbo].resource rc on rc.uid = c.createdBy"+
			            		" Left Join " + LoadConstant.infomaster + ".[dbo].resource rm on rm.uid = c.modifiedBy"+
			            		" Left Join " + LoadConstant.infomaster + ".[dbo].resource rrm on rrm.uid = a.rmid"+
			            		" Left Join " + LoadConstant.infomaster + ".[dbo].resource rdm on rdm.uid = a.dmid"+
			            		" Left Join " + LoadConstant.infomaster + ".[dbo].currency cur on cur.currencyId = c.currencyId"+
			            		" Left Join " + LoadConstant.infomaster + ".[dbo].uom u on u.uomId = c.uomId"+
			            		" Left Join " + LoadConstant.infomaster + ".[dbo].resource rs on rs.uid = c.ownerId"+
			            		" order by c.cmsId",								
								resultClass = Cms.class ,  resultSetMapping = "cms_by_createdBy_RM_DM"                          
	    ),
	 	@NamedNativeQuery(
	            name    	=   "getAllCmsForExport",
	            query   	=   "select t.treqId, t.associateLevel, t.billingPercentage, t.fulfilmentType, t.fulfilledDate, t.location, t.reqStartDate, t.reqEndDate, "+
	            				"t.requisitionType, t.status as treqStatus, t.amgFulfilledDate, t.cancelledDate, t.rejectedDate, t.extension, cd.amount, "+
	            				"cd.billableRate, cd.sowRoleStartDate, cd.sowRoleEndDate, cd.status as roleStatus, "+
	            				"c.cmsId, c.accountId, c.opportunityId, c.dummyProjectName, c.cost, c.revenue, c.margin, c.status, "+
	            				"c.createdDate, c.modifiedDate, a.title as accountName, "+
	            				"a.accountNo, rrm.Title as rm, rdm.Title as dm, rc.Title as createdByName, rm.Title as modifiedByName, cur.sign as currencySign, "+
	            				"o.opportunityName, u.name as uomName, a.status as accountStatus, "+
	            				"c.revenueProbability, c.opportunityType, c.isRevenuePlanning, o.info_OpportunityNumber as opportunityNo, rs.Title as secondaryOwnerName, cd.cmsDetailId ,o.opportunityValue_USD as opportunityValueUSD , o.accountId as opportunityAccountId "+
			            		" FROM " + LoadConstant.otc + ".[dbo].treq t"+
			            		" Left join " + LoadConstant.otc + ".dbo.cmsDetail cd on t.cmsDetailId = cd.cmsDetailId"+
			            		" Left join " + LoadConstant.otc + ".dbo.cms c on c.cmsId = cd.cmsId"+
			            		" Left join " + LoadConstant.infomaster + ".dbo.accounts a on c.accountId = a.itemId"+
			            		" Left Join " + LoadConstant.infomaster + ".[dbo].opportunity o on c.opportunityId = o.opportunityId"+
			            		" Left Join " + LoadConstant.infomaster + ".[dbo].resource rc on rc.uid = c.createdBy"+
			            		" Left Join " + LoadConstant.infomaster + ".[dbo].resource rm on rm.uid = c.modifiedBy"+
			            		" Left Join " + LoadConstant.infomaster + ".[dbo].resource rrm on rrm.uid = a.rmid"+
			            		" Left Join " + LoadConstant.infomaster + ".[dbo].resource rdm on rdm.uid = a.dmid"+
			            		" Left Join " + LoadConstant.infomaster + ".[dbo].currency cur on cur.currencyId = c.currencyId"+
			            		" Left Join " + LoadConstant.infomaster + ".[dbo].uom u on u.uomId = c.uomId"+
			            		" Left Join " + LoadConstant.infomaster + ".[dbo].resource rs on rs.uid = c.ownerId"+
			            		" order by t.treqId",								
								resultClass = Cms.class ,  resultSetMapping = "cms_by_createdBy_RM_DM_Download"                          
	    )
})
@DynamicUpdate
@DynamicInsert
public class Cms {

	//Columns
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer cmsId;
	
	private Integer opportunityId;
	
	private Integer accountId;
	private Integer uomId;
	
	private Integer currencyId;
	
	private String dummyProjectName;
	
	@Column(precision=12,scale=2)
	private BigDecimal cost;
	
	private BigDecimal margin;
	
	@Column(precision=12,scale=2)
	private BigDecimal revenue;
	
	private String status;
	
	private String approvalStatus;
	private Date approvalDate;
	private Integer approvedBy;
	
	private Date createdDate;
	private Date modifiedDate;
	private Integer createdBy;
	private Integer modifiedBy;
	
	private Integer ownerId;
	
	//Revenue Planning fields
	private Boolean isRevenuePlanning;
	
	@Column(precision=12,scale=2)
	private BigDecimal revenueCertain;
	
	@Column(precision=12,scale=2)
	private BigDecimal revenueHigh;
	
	@Column(precision=12,scale=2)
	private BigDecimal revenueMedium;
	
	@Column(precision=12,scale=2)
	private BigDecimal revenueLow;
	
	@Column(precision=12,scale=2)
	private BigDecimal revenueProbability;
	
	private String opportunityType;
	//End of: Revenue Planning fields
	//End of: Columns
	
	//Transient fields
	@Transient
	private String accountName;
	
	@Transient
	private String accountNo;
	
	@Transient
	private String rm;
	
	@Transient
	private String dm;
	
	@Transient
	private String createdByName;
	
	@Transient
	private String modifiedByName;
	
	@Transient
	private String opportunityName;
	
	@Transient
	private String currencySign;
	
	@Transient
	private String uomName;
	
	private String daysInMonth;
	
	@Transient
	private String accountStatus;
	
	@Transient
	private BigDecimal monthlyCmsValueCertain;
	
	@Transient
	private BigDecimal monthlyCmsValueHigh;
	
	@Transient
	private BigDecimal monthlyCmsValueMedium;
	
	@Transient
	private BigDecimal monthlyCmsValueLow;
	
	@Transient
	private Integer monthNo;
	
	@Transient
	private String opportunityNo;
	
	@Transient
	private String secondaryOwnerName;
	
	@Transient
	private Integer cmsDetailId;
	
	@Transient
	private Integer treqId;
	
	@Transient
	private String associateLevel;
	
	@Transient
	private Integer billingPercentage;
	
	@Transient
	private String fulfilmentType;
	
	@Transient
	private Date fulfilledDate;
	
	@Transient
	private String location;
	
	@Transient
	private Date reqStartDate;
	
	@Transient
	private Date reqEndDate;
	
	@Transient
	private String requisitionType;
	
	@Transient
	private String treqStatus;
	
	@Transient
	private Date amgFulfilledDate;
	
	@Transient
	private Date cancelledDate;
	
	@Transient
	private Date rejectedDate;
	
	@Transient
	private Boolean extension;
	
	@Transient
	private BigDecimal amount;
	
	@Transient
	private BigDecimal billableRate;
	
	@Transient
	private Date sowRoleStartDate;
	
	@Transient
	private Date sowRoleEndDate;
	
	@Transient
	private String roleStatus;
	
	
	@Transient
	private String opportunityValueUSD;
	
	@Transient
	private Integer opportunityAccountId;
	
	//Getter and Setter
		
	
	public Integer getCmsId() {
		return cmsId;
	}

	public Integer getTreqId() {
		return treqId;
	}

	public void setTreqId(Integer treqId) {
		this.treqId = treqId;
	}

	public String getAssociateLevel() {
		return associateLevel;
	}

	public void setAssociateLevel(String associateLevel) {
		this.associateLevel = associateLevel;
	}

	public Integer getBillingPercentage() {
		return billingPercentage;
	}

	public void setBillingPercentage(Integer billingPercentage) {
		this.billingPercentage = billingPercentage;
	}

	public String getFulfilmentType() {
		return fulfilmentType;
	}

	public void setFulfilmentType(String fulfilmentType) {
		this.fulfilmentType = fulfilmentType;
	}

	public Date getFulfilledDate() {
		return fulfilledDate;
	}

	public void setFulfilledDate(Date fulfilledDate) {
		this.fulfilledDate = fulfilledDate;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public Date getReqStartDate() {
		return reqStartDate;
	}

	public void setReqStartDate(Date reqStartDate) {
		this.reqStartDate = reqStartDate;
	}

	public Date getReqEndDate() {
		return reqEndDate;
	}

	public void setReqEndDate(Date reqEndDate) {
		this.reqEndDate = reqEndDate;
	}

	public String getRequisitionType() {
		return requisitionType;
	}

	public void setRequisitionType(String requisitionType) {
		this.requisitionType = requisitionType;
	}

	public String getTreqStatus() {
		return treqStatus;
	}

	public void setTreqStatus(String treqStatus) {
		this.treqStatus = treqStatus;
	}

	public Date getAmgFulfilledDate() {
		return amgFulfilledDate;
	}

	public void setAmgFulfilledDate(Date amgFulfilledDate) {
		this.amgFulfilledDate = amgFulfilledDate;
	}

	public Date getCancelledDate() {
		return cancelledDate;
	}

	public void setCancelledDate(Date cancelledDate) {
		this.cancelledDate = cancelledDate;
	}

	public Date getRejectedDate() {
		return rejectedDate;
	}

	public void setRejectedDate(Date rejectedDate) {
		this.rejectedDate = rejectedDate;
	}

	public Boolean getExtension() {
		return extension;
	}

	public void setExtension(Boolean extension) {
		this.extension = extension;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public BigDecimal getBillableRate() {
		return billableRate;
	}

	public void setBillableRate(BigDecimal billableRate) {
		this.billableRate = billableRate;
	}

	public Date getSowRoleStartDate() {
		return sowRoleStartDate;
	}

	public void setSowRoleStartDate(Date sowRoleStartDate) {
		this.sowRoleStartDate = sowRoleStartDate;
	}

	public Date getSowRoleEndDate() {
		return sowRoleEndDate;
	}

	public void setSowRoleEndDate(Date sowRoleEndDate) {
		this.sowRoleEndDate = sowRoleEndDate;
	}

	public String getRoleStatus() {
		return roleStatus;
	}

	public void setRoleStatus(String roleStatus) {
		this.roleStatus = roleStatus;
	}

	@Transient
	public String getOpportunityName() {
		return opportunityName;
	}
	public void setOpportunityName(String opportunityName) {
		this.opportunityName = opportunityName;
	}
	@Transient
	public String getAccountName() {
		return accountName;
	}
	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}
	@Transient
	public String getRm() {
		return rm;
	}
	public void setRm(String rm) {
		this.rm = rm;
	}
	@Transient
	public String getCreatedByName() {
		return createdByName;
	}

	public void setCreatedByName(String createdByName) {
		this.createdByName = createdByName;
	}
	@Transient
	public String getModifiedByName() {
		return modifiedByName;
	}

	public void setModifiedByName(String modifiedByName) {
		this.modifiedByName = modifiedByName;
	}
	@Transient
	public String getCurrencySign() {
		return currencySign;
	}

	public void setCurrencySign(String currencySign) {
		this.currencySign = currencySign;
	}
	@Transient
	public String getUomName() {
		return uomName;
	}

	public void setUomName(String uomName) {
		this.uomName = uomName;
	}

	@Transient
	public String getDm() {
		return dm;
	}
	public void setDm(String dm) {
		this.dm = dm;
	}
	public void setCmsId(Integer cmsId) {
		this.cmsId = cmsId;
	}
	public Integer getOpportunityId() {
		return opportunityId;
	}
	public void setOpportunityId(Integer opportunityId) {
		this.opportunityId = opportunityId;
	}
	public Integer getAccountId() {
		return accountId;
	}
	public void setAccountId(Integer accountId) {
		this.accountId = accountId;
	}
	public Integer getUomId() {
		return uomId;
	}
	public void setUomId(Integer uomId) {
		this.uomId = uomId;
	}
	public Integer getCurrencyId() {
		return currencyId;
	}
	public void setCurrencyId(Integer currencyId) {
		this.currencyId = currencyId;
	}
	public String getDummyProjectName() {
		return dummyProjectName;
	}
	public void setDummyProjectName(String dummyProjectName) {
		this.dummyProjectName = dummyProjectName;
	}
	public BigDecimal getCost() {
		return cost;
	}
	public void setCost(BigDecimal cost) {
		this.cost = cost;
	}

	public BigDecimal getMargin() {
		return margin;
	}

	public void setMargin(BigDecimal margin) {
		this.margin = margin;
	}

	public BigDecimal getRevenue() {
		return revenue;
	}

	public void setRevenue(BigDecimal revenue) {
		this.revenue = revenue;
	}

	
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getApprovalStatus() {
		return approvalStatus;
	}

	public void setApprovalStatus(String approvalStatus) {
		this.approvalStatus = approvalStatus;
	}

	public Date getApprovalDate() {
		return approvalDate;
	}

	public void setApprovalDate(Date approvalDate) {
		this.approvalDate = approvalDate;
	}

	public Integer getApprovedBy() {
		return approvedBy;
	}

	public void setApprovedBy(Integer approvedBy) {
		this.approvedBy = approvedBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public Date getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public Integer getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}
	public Integer getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public String getDaysInMonth() {
		return daysInMonth;
	}
	public void setDaysInMonth(String daysInMonth) {
		this.daysInMonth = daysInMonth;
	}
	

	
	public Boolean getIsRevenuePlanning() {
		return isRevenuePlanning;
	}

	public void setIsRevenuePlanning(Boolean isRevenuePlanning) {
		this.isRevenuePlanning = isRevenuePlanning;
	}

	public BigDecimal getRevenueCertain() {
		return revenueCertain;
	}

	public void setRevenueCertain(BigDecimal revenueCertain) {
		this.revenueCertain = revenueCertain;
	}

	public BigDecimal getRevenueHigh() {
		return revenueHigh;
	}

	public void setRevenueHigh(BigDecimal revenueHigh) {
		this.revenueHigh = revenueHigh;
	}

	public BigDecimal getRevenueMedium() {
		return revenueMedium;
	}

	public void setRevenueMedium(BigDecimal revenueMedium) {
		this.revenueMedium = revenueMedium;
	}

	public BigDecimal getRevenueLow() {
		return revenueLow;
	}

	public void setRevenueLow(BigDecimal revenueLow) {
		this.revenueLow = revenueLow;
	}

	public BigDecimal getRevenueProbability() {
		return revenueProbability;
	}

	public void setRevenueProbability(BigDecimal revenueProbability) {
		this.revenueProbability = revenueProbability;
	}
	
	public Integer getOwnerId() {
		return ownerId;
	}

	public void setOwnerId(Integer ownerId) {
		this.ownerId = ownerId;
	}
	
	public String getOpportunityType() {
		return opportunityType;
	}

	public void setOpportunityType(String opportunityType) {
		this.opportunityType = opportunityType;
	}
	
	@Transient	
	public BigDecimal getMonthlyCmsValueCertain() {
		return monthlyCmsValueCertain;
	}

	public void setMonthlyCmsValueCertain(BigDecimal monthlyCmsValueCertain) {
		this.monthlyCmsValueCertain = monthlyCmsValueCertain;
	}
	@Transient
	public BigDecimal getMonthlyCmsValueHigh() {
		return monthlyCmsValueHigh;
	}

	public void setMonthlyCmsValueHigh(BigDecimal monthlyCmsValueHigh) {
		this.monthlyCmsValueHigh = monthlyCmsValueHigh;
	}
	@Transient
	public BigDecimal getMonthlyCmsValueMedium() {
		return monthlyCmsValueMedium;
	}

	public void setMonthlyCmsValueMedium(BigDecimal monthlyCmsValueMedium) {
		this.monthlyCmsValueMedium = monthlyCmsValueMedium;
	}
	@Transient
	public BigDecimal getMonthlyCmsValueLow() {
		return monthlyCmsValueLow;
	}

	public void setMonthlyCmsValueLow(BigDecimal monthlyCmsValueLow) {
		this.monthlyCmsValueLow = monthlyCmsValueLow;
	}

	@Transient
	public Integer getMonthNo() {
		return monthNo;
	}

	public void setMonthNo(Integer monthNo) {
		this.monthNo = monthNo;
	}

	public String getAccountStatus() {
		return accountStatus;
	}
	
	
	@Transient	
	public String getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}

	public void setAccountStatus(String accountStatus) {
		this.accountStatus = accountStatus;
	}
	
	@Transient
	public String getOpportunityNo() {
		return opportunityNo;
	}

	public void setOpportunityNo(String opportunityNo) {
		this.opportunityNo = opportunityNo;
	}
	
	@Transient
	public String getSecondaryOwnerName() {
		return secondaryOwnerName;
	}

	public void setSecondaryOwnerName(String secondaryOwnerName) {
		this.secondaryOwnerName = secondaryOwnerName;
	}
		
	//End of: Getter and Setter

	public Integer getCmsDetailId() {
		return cmsDetailId;
	}

	public void setCmsDetailId(Integer cmsDetailId) {
		this.cmsDetailId = cmsDetailId;
	}
	
	

	public String getOpportunityValueUSD() {
		return opportunityValueUSD;
	}

	public void setOpportunityValueUSD(String opportunityValueUSD) {
		this.opportunityValueUSD = opportunityValueUSD;
	}

	public Integer getOpportunityAccountId() {
		return opportunityAccountId;
	}

	public void setOpportunityAccountId(Integer opportunityAccountId) {
		this.opportunityAccountId = opportunityAccountId;
	}

	//Constructor
	public Cms(Integer cmsId, Integer accountId, Integer opportunityId, Integer uomId, Integer currencyId, String dummyProjectName, 
			BigDecimal cost, BigDecimal revenue, BigDecimal margin, String status,  
			String approvalStatus, Date approvalDate, Integer approvedBy,
			Integer createdBy, Date createdDate, Integer modifiedBy, Date modifiedDate,
			String accountName, String accountNo, String rm, String dm, String createdByName, String modifiedByName, 
			String currencySign, String opportunityName, String uomName, String daysInMonth, String accountStatus,
			BigDecimal revenueCertain, BigDecimal revenueHigh, BigDecimal revenueMedium, BigDecimal revenueLow, 
			BigDecimal revenueProbability, String opportunityType, Boolean isRevenuePlanning, Integer ownerId,
			Integer monthNo, BigDecimal monthlyCmsValueCertain, BigDecimal monthlyCmsValueHigh, 
			BigDecimal monthlyCmsValueMedium, BigDecimal monthlyCmsValueLow, String opportunityNo, String secondaryOwnerName,
			String opportunityValueUSD, Integer opportunityAccountId) {
		
		this.cmsId 			= cmsId;
		this.accountId 		= accountId;
		this.opportunityId 	= opportunityId;		
		this.uomId 			= uomId;		
		this.currencyId 	= currencyId;
		
		this.dummyProjectName = dummyProjectName;
		this.cost 		= cost;
		this.revenue 	= revenue;
		this.margin 	= margin;
		this.status 	= status;
		
		this.approvalStatus = approvalStatus;
		this.approvalDate = approvalDate;
		this.approvedBy = approvedBy;		
		
		this.createdBy 		= createdBy;
		this.createdDate 	= createdDate;
		this.modifiedBy 	= modifiedBy;
		this.modifiedDate 	= modifiedDate;
		
		this.accountName 	= accountName;
		this.accountNo		= accountNo;
		this.rm 			= rm;
		this.dm 			= dm;
		this.createdByName 	= createdByName;
		this.modifiedByName = modifiedByName;
		this.currencySign 	= currencySign;
		this.opportunityName = opportunityName;
		this.uomName 		= uomName;
		this.daysInMonth = daysInMonth;
		this.accountStatus = accountStatus;
		this.revenueCertain = revenueCertain;
		this.revenueHigh = revenueHigh;
		this.revenueMedium = revenueMedium;
		this.revenueLow = revenueLow;
		this.revenueProbability = revenueProbability;
		this.opportunityType = opportunityType;
		this.isRevenuePlanning = isRevenuePlanning;
		this.ownerId = ownerId;
		
		this.monthNo = monthNo;
		this.monthlyCmsValueCertain = monthlyCmsValueCertain;
		this.monthlyCmsValueHigh = monthlyCmsValueHigh;
		this.monthlyCmsValueMedium = monthlyCmsValueMedium;			
		this.monthlyCmsValueLow = monthlyCmsValueLow;	
		
		this.opportunityNo = opportunityNo;
		this.secondaryOwnerName = secondaryOwnerName;
		
		this.opportunityValueUSD = opportunityValueUSD;
		this.opportunityAccountId = opportunityAccountId;
	}


	public Cms(Integer treqId, String associateLevel, Integer billingPercentage,
			String fulfilmentType, Date fulfilledDate, String location, Date reqStartDate, Date reqEndDate,
			String requisitionType, String treqStatus, Date amgFulfilledDate, Date cancelledDate, Date rejectedDate,
			Boolean extension, BigDecimal amount, BigDecimal billableRate, Date sowRoleStartDate, Date sowRoleEndDate,
			String roleStatus, Integer cmsId, Integer accountId, Integer opportunityId, String dummyProjectName, BigDecimal cost,
			BigDecimal revenue, BigDecimal margin,  String status, Date createdDate, Date modifiedDate, String accountName,
			String accountNo, String rm, String dm, String createdByName, String modifiedByName, String currencySign, String opportunityName,
			String uomName, String accountStatus, BigDecimal revenueProbability, String opportunityType, Boolean isRevenuePlanning,  
			String opportunityNo, String secondaryOwnerName, Integer cmsDetailId, String opportunityValueUSD, Integer opportunityAccountId) {
		
		
		this.treqId = treqId;
		this.associateLevel = associateLevel;
		this.billingPercentage = billingPercentage;
		this.fulfilmentType = fulfilmentType;
		this.fulfilledDate = fulfilledDate;
		this.location = location;
		this.reqStartDate = reqStartDate;
		this.reqEndDate = reqEndDate;
		this.requisitionType = requisitionType;
		this.treqStatus = treqStatus;
		this.amgFulfilledDate = amgFulfilledDate;
		this.cancelledDate = cancelledDate;
		this.rejectedDate = rejectedDate;
		this.extension = extension;
		this.amount = amount;
		this.billableRate = billableRate;
		this.sowRoleStartDate = sowRoleStartDate;
		this.sowRoleEndDate = sowRoleEndDate;
		this.roleStatus = roleStatus;		
		this.cmsId = cmsId;
		this.accountId = accountId;
		this.opportunityId = opportunityId;		
		this.dummyProjectName = dummyProjectName;
		this.cost = cost;
		this.revenue = revenue;
		this.margin = margin;	
		this.status = status;
		this.createdDate = createdDate;
		this.modifiedDate = modifiedDate;
		this.accountName = accountName;
		this.accountNo = accountNo;
		this.rm = rm;
		this.dm = dm;
		this.createdByName = createdByName;
		this.modifiedByName = modifiedByName;		
		this.currencySign = currencySign;
		this.opportunityName = opportunityName;		
		this.uomName = uomName;
		this.accountStatus = accountStatus;
		this.revenueProbability = revenueProbability;
		this.opportunityType = opportunityType;		
		this.isRevenuePlanning = isRevenuePlanning;
		this.opportunityNo = opportunityNo;
		this.secondaryOwnerName = secondaryOwnerName;
		this.cmsDetailId = cmsDetailId;
		this.opportunityValueUSD = opportunityValueUSD;
		this.opportunityAccountId = opportunityAccountId;
	}

	public Cms() {
		// TODO Auto-generated constructor stub
	}

}
