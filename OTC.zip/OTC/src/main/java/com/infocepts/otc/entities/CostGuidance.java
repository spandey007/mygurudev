package com.infocepts.otc.entities;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import com.infocepts.otc.utilities.LoadConstant;

@Entity
@Table(catalog=LoadConstant.infomaster, schema="[dbo]",name="costGuidance")
public class CostGuidance {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer	costGuidanceId;
	
	@ManyToOne
	@JoinColumn(name="countryId")
	private Country	country;
	
	@ManyToOne
	@JoinColumn(name="gradeId")
	private Grade grade;
	
	@ManyToOne
	@JoinColumn(name="yearId")
	private Year yearId;
	
	private Integer ctc;
	
	@ManyToOne
	@JoinColumn(name="currencyId")
	private Currency currency;
	
	private Integer createdBy;
	private Date createdDate;
	private Integer modifiedBy;
	private Date modifiedDate;


	public Integer getCostGuidanceId() {
		return costGuidanceId;
	}

	public void setCostGuidanceId(Integer costGuidanceId) {
		this.costGuidanceId = costGuidanceId;
	}

	public Country getCountry() {
		return country;
	}

	public void setCountry(Country country) {
		this.country = country;
	}

	public Grade getGrade() {
		return grade;
	}

	public void setGrade(Grade grade) {
		this.grade = grade;
	}

	public Integer getCtc() {
		return ctc;
	}

	public void setCtc(Integer ctc) {
		this.ctc = ctc;
	}

	public Currency getCurrency() {
		return currency;
	}

	public void setCurrency(Currency currency) {
		this.currency = currency;
	}

	public Integer getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Integer getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public Year getYearId() {
		return yearId;
	}

	public void setYearId(Year yearId) {
		this.yearId = yearId;
	}
}
