package com.infocepts.otc.services;

import com.infocepts.otc.entities.ProjectTask;
import com.infocepts.otc.repositories.ProjectTaskRepository;
import com.infocepts.otc.repositories.ResourceRepository;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.mail.MessagingException;
import javax.servlet.http.HttpServletRequest;
import java.util.*;

@Component
public class ProjectTaskServiceImpl implements ProjectTaskService {

    private static final Logger logger = LoggerFactory.getLogger(ProjectTaskServiceImpl.class);

    @Autowired
    HttpServletRequest request;

    @Autowired
    TimesheetService timesheetService;
    @Autowired
    private ProjectTaskRepository projectTaskRepository;
    @Autowired
    private ResourceRepository resourceRepository;

    @Override
    public List<ProjectTask> getAllTasksForProject(final Integer projectId) {
        return this.projectTaskRepository.getAllActiveTasksForProject(projectId);
    }

    @Override
    public List<ProjectTask> saveAllTasksForProject(final Integer projectId, final List<ProjectTask> taskCenterList) {

        List<ProjectTask> currentTaskList = this.projectTaskRepository.getAllActiveTasksForProjectOrderedByTaskId(projectId);

        List<ProjectTask> oldTaskCenterListOrderedByTaskId = new ArrayList<>();
        for (ProjectTask projectTask : currentTaskList) {
            try {
                oldTaskCenterListOrderedByTaskId.add(projectTask.clone());
            } catch (CloneNotSupportedException cloneNotSupportedException) {
                logger.error(cloneNotSupportedException.getMessage());
            }
        }

        this.disableTasksNotInTaskCenterList(projectId, taskCenterList);

        final List<ProjectTask> newTaskCenterList = this.projectTaskRepository.save(taskCenterList);

        final List<ProjectTask> newTaskListOrderedByTaskId = this.projectTaskRepository.getAllActiveTasksForProjectOrderedByTaskId(projectId);

        this.getNewlyAssignedTaskDetails(oldTaskCenterListOrderedByTaskId, newTaskListOrderedByTaskId, this.request);

        return newTaskCenterList;
    }

    @Override
    public void disableTasksNotInTaskCenterList(final Integer projectId, final List<ProjectTask> projectTaskList) {
        List<Integer> taskIds = new ArrayList<>();
        for (ProjectTask task : projectTaskList)
            if (null != task.getTaskId())
                taskIds.add(task.getTaskId());

        logger.debug("Old TaskIds length : " + taskIds.size());

        List<Integer> tasksToDisable;
        if (!taskIds.isEmpty()) {
            tasksToDisable = this.projectTaskRepository.getTasksToDisabled(projectId, taskIds);
            logger.debug("tasksToDisable length : " + tasksToDisable.size());
            if (!tasksToDisable.isEmpty())
                this.projectTaskRepository.setTaskToDisabled(tasksToDisable);
        }
    }

    @Override
    public void getNewlyAssignedTaskDetails(List<ProjectTask> oldProjectTaskList, List<ProjectTask> newProjectTaskList, HttpServletRequest request) {

        try {
            newProjectTaskList.forEach(projectTask -> {

                Integer index = Collections.binarySearch(oldProjectTaskList,
                        new ProjectTask(projectTask.getTaskId()), Comparator.comparing(ProjectTask::getTaskId));

                if (projectTask.getTimesheet()) {
                    if (index > 0) {
                        logger.debug("Inside old task...");
                        if (null == projectTask.getAssignedAssociate())
                            projectTask.setAssignedAssociate("");
                        if (StringUtils.isNotBlank(projectTask.getAssignedAssociate().trim())) {

                            List<String> newResourceIds = null;
                            if (StringUtils.isNotBlank(projectTask.getAssignedAssociate().trim())) {
                                newResourceIds = Arrays.asList(projectTask.getAssignedAssociate().split(","));
                            }

                            ProjectTask oldProjectTask = oldProjectTaskList.get(index);

                            List<String> oldResourceIds = null;
                            if(null == oldProjectTask.getAssignedAssociate())
                            	oldProjectTask.setAssignedAssociate("");
                            if (StringUtils.isNotBlank(oldProjectTask.getAssignedAssociate().trim())) {
                                oldResourceIds = Arrays.asList(oldProjectTask.getAssignedAssociate().split(","));
                            }

                            List<String> resourceIds = null;

                            if ((!oldProjectTaskList.get(index).getTimesheet()) && projectTask.getTimesheet()) {
                                if (null != newResourceIds) {
                                    resourceIds = newResourceIds;
                                    this.sendTaskAssignmentMail(projectTask, resourceIds, request);
                                }
                            } else {
                                if (null != newResourceIds) {
                                    if (oldResourceIds == null) {
                                        resourceIds = newResourceIds;
                                    } else {
                                        resourceIds = (List<String>) CollectionUtils.subtract(newResourceIds, oldResourceIds);
                                    }
                                    if (!resourceIds.isEmpty()) {
                                        this.sendTaskAssignmentMail(projectTask, resourceIds, request);
                                    }
                                }
                            }
                        }
                    } else {
                        if (null != projectTask.getAssignedAssociate()) {
                            if (StringUtils.isNotBlank(projectTask.getAssignedAssociate().trim())) {
                                List<String> resourceIds = Arrays.asList(projectTask.getAssignedAssociate().split(","));
                                if (!resourceIds.isEmpty()) {
                                    this.sendTaskAssignmentMail(projectTask, resourceIds, request);
                                }
                            }
                        }
                    }
                }
            });
        } catch (Exception e){
            logger.error(e.getMessage());
        }
    }

    @Override
    public void sendTaskAssignmentMail(ProjectTask taskinfo, List<String> resourceMailIds, HttpServletRequest request) {
        logger.debug(String.format("Sending mail for task : %s : to resource : %s", taskinfo.getTitle(), resourceMailIds));
        try {
            timesheetService.sendTaskAssignmentNotification(taskinfo, resourceMailIds, request);
        } catch (MessagingException e) {
            logger.error(e.getMessage());
        }
    }

}
