package com.infocepts.otc.repositories;

import java.util.List;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import com.infocepts.otc.entities.AssociateCertifications;

public interface AssociateCertificationsRepository extends CrudRepository<AssociateCertifications,Integer>{

	@Override
	public List<AssociateCertifications> findAll();
	
	@Query("from AssociateCertifications where uid=:uid")
	public List<AssociateCertifications> findByUid(@Param(value = "uid") Integer uid);
}
