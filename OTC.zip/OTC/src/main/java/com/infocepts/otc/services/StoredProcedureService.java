package com.infocepts.otc.services;

import org.springframework.stereotype.Service;


//Description: The service contain methods for calling different Stored Procedure 

@Service
public interface StoredProcedureService {
	
	//To insert or update resource bucket
	public void ResourceBucket(Integer alcId);
	
	//To update allocation on SOW role update
	public void UpdateAllocationOnSowUpdate(Integer sowDetailId);
	
	//To Generate monthly allocation from allocation
	public void GenerateMonthlyAllocation(Integer alcId);
	
	//To delete the sow role, allocation and treq details
	public void DeleteSOWDetailAllocatioTreq(Integer sowDetailId, Integer uid);

}
