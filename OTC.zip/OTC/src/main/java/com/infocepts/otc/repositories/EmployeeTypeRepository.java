package com.infocepts.otc.repositories;

import com.infocepts.otc.entities.EmployeeType;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface EmployeeTypeRepository extends CrudRepository<EmployeeType,Integer> {

    @Override
    List<EmployeeType> findAll();
}
