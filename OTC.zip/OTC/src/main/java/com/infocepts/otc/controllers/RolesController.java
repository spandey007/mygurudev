package com.infocepts.otc.controllers;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.infocepts.otc.entities.Roles;
import com.infocepts.otc.repositories.RolesRepository;
import com.infocepts.otc.services.TimesheetService;


@RestController
@RequestMapping(value="/roles",headers="referer")//JV: Added 'headers' param to validate the url.
public class RolesController {
	
	final Logger logger = Logger.getLogger(RolesController.class);

	@Autowired
	RolesRepository repository;
	
	@Autowired
	HttpSession session;
	
	@Autowired
	TimesheetService service;
	
	@PersistenceContext(unitName="otc")
    private EntityManager manager;
	
    @RequestMapping(method=RequestMethod.GET)
	public List<Roles> getAllRoles(@RequestParam(value = "status", defaultValue = "all") String status,
									@RequestParam(value = "role", defaultValue = "") String role,
									@RequestParam(value = "roleId", defaultValue = "") Integer roleId,
									HttpServletRequest request){
    	 List<Roles> roleslist=null;
    	 try{
    		/* ------------------------- Authorization start ------------------------------------ */
 			// Authorization for admin role
 			/*if(!service.isAdmin())
 			{
 				service.sendTamperedMail("Roles View All", 0, 0, request);
 				return roleslist;
 			}*/
 			/* ------------------------- Authorization ends ------------------------------------ */
    		 if(status.equals("active") && !role.equals(""))
			 {
	    		 roleslist = repository.findActiveRoleId(role);
			 }
    		 else if(status.equals("active"))
			 {
	    		 roleslist = repository.findActiveRoles();
			 }
	    	 else if(!role.equals("")){	    	    		 
	    		 roleslist = repository.findRoleId(role);	    		
	    	 }
	    	 else if(roleId != null)
	    	 {
	    		 roleslist = repository.findRoleById(roleId);
	    	 }
			 else
			 {
				 //roleslist = repository.findAll();
				 roleslist = manager.createNamedQuery("getAllRolesWithAssignmentCount", Roles.class).getResultList();
			 }
    	 }
    	 catch(Exception e){
    		 logger.error(e);
    	 }
    	 return roleslist;
	 }
	
    
    @RequestMapping(value="/{roleId}",method=RequestMethod.GET)
	public Roles findRoleById(@PathVariable(value="roleId") Integer roleId){
    	System.out.println("roleId"+roleId);
		Roles role=null;
		try{
			role = repository.findOne(roleId);
			System.out.println("role obj"+role);
		}catch(Exception e){
			logger.error(e);
		}
		return role;
	}
    
    @RequestMapping(method=RequestMethod.POST)
	public Roles addRoles(@RequestBody Roles roles,
							HttpServletRequest request){
    	try{
    		/* ------------------------- Authorization start ------------------------------------ */
 			// Authorization for admin role
 			if(service.isAdmin())
 			{
 				repository.save(roles);
 			}
 			else
 			{
 				service.sendTamperedMail("Roles Add", 0, 0, request);
 			}
 			/* ------------------------- Authorization ends ------------------------------------ */
    		
    	}catch(Exception e){
    		logger.error(e);
    	}
		return roles;
	}
    
    @RequestMapping(value="/{roleId}",method=RequestMethod.PUT)
   	public Roles updateRoles(@RequestBody Roles updatedRoles,@PathVariable Integer roleId,
   								HttpServletRequest request){
    	try{
    		/* ------------------------- Authorization start ------------------------------------ */
 			// Authorization for admin role
 			if(service.isAdmin())
 			{
 				updatedRoles.setRoleId(roleId);
 				repository.save(updatedRoles);
 			}
 			else
 			{
 				service.sendTamperedMail("Roles update", 0, 0, request);
 			}
 			/* ------------------------- Authorization ends ------------------------------------ */
    	}catch(Exception e){
    		logger.error(e);
    	}
    	return updatedRoles;
   	}
    
    @RequestMapping(value="/{roleId}",method=RequestMethod.DELETE)
	public void deleteRoles(@PathVariable Integer roleId,
							HttpServletRequest request){
    	try{
    		/* ------------------------- Authorization start ------------------------------------ */
 			// Authorization for admin role
 			if(service.isAdmin())
 			{
 				repository.delete(roleId);
 			}
 			else
 			{
 				service.sendTamperedMail("Roles delete", 0, 0, request);
 			}
 			/* ------------------------- Authorization ends ------------------------------------ */
    	}catch(Exception e){
    		logger.error(e);
    	}
    }
    
}
