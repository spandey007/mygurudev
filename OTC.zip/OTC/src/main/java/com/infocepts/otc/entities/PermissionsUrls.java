package com.infocepts.otc.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.infocepts.otc.utilities.LoadConstant;

@Entity
@Table(catalog=LoadConstant.otc,schema="[dbo]",name="permissions_urls")
public class PermissionsUrls {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer permissionsUrlsId;
	
	private String url;
	private Boolean status;
	
	public Integer getPermissionsUrlsId() {
		return permissionsUrlsId;
	}
	public void setPermissionsUrlsId(Integer permissionsUrlsId) {
		this.permissionsUrlsId = permissionsUrlsId;
	}	
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}	
	public Boolean getStatus() {
		return status;
	}
	public void setStatus(Boolean status) {
		this.status = status;
	}	
	
}
