package com.infocepts.otc.services;

import javax.mail.MessagingException;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Service;

import com.infocepts.otc.entities.ActionItem;
import com.infocepts.otc.entities.Allocation;
import com.infocepts.otc.entities.BusPass;
import com.infocepts.otc.entities.City;
import com.infocepts.otc.entities.Cms;
import com.infocepts.otc.entities.Country;
import com.infocepts.otc.entities.Currency;
import com.infocepts.otc.entities.DEGovernanceNotes;
import com.infocepts.otc.entities.DeAppreciation;
import com.infocepts.otc.entities.DeComplaint;
import com.infocepts.otc.entities.DeGovernance;
import com.infocepts.otc.entities.DeMsr;
import com.infocepts.otc.entities.DeValueAdd;
import com.infocepts.otc.entities.DeWsr;
import com.infocepts.otc.entities.ExitAccess;
import com.infocepts.otc.entities.ExitForm;
import com.infocepts.otc.entities.ISow;
import com.infocepts.otc.entities.InfoCab;
import com.infocepts.otc.entities.InfoTravel;
import com.infocepts.otc.entities.Invoices;
import com.infocepts.otc.entities.Project;
import com.infocepts.otc.entities.ProjectTask;
import com.infocepts.otc.entities.Skill;
import com.infocepts.otc.entities.Sow;
import com.infocepts.otc.entities.Survey;
import com.infocepts.otc.entities.Treq;
import com.infocepts.pms.entities.PmsPerformance;

import java.text.ParseException;
import java.util.List;

@Service
public interface TimesheetService {

	// To validate infocepts user call
	public boolean isAValidUserCall(Integer uid);
	
	// To validate timesheet call
	public boolean isAValidTimesheetCall(Integer uid);
	
	// To validate PMS performance page call
	public boolean isAValidPmsCall(Integer uid);
	
	// To validate sow call
    public boolean isAValidProjectCall(Integer projectId, String section, HttpServletRequest request)  throws MessagingException;
    
    // To validate sow call
    public boolean isAValidSOWCall(Integer projectId, Integer sowId, String section, HttpServletRequest request)  throws MessagingException;
	
	public boolean isValidDelegation(Integer uid);
	
	public boolean isAValidAdminRole();
	
	public boolean isAdmin();
	
	public boolean sendTamperedMail(String endPointName, Integer uid, Integer pid, HttpServletRequest request) throws MessagingException;

    public boolean isPmo();
    
    public boolean isFA();
    
    public boolean isLegal();
    
    public boolean isBF();
        
    public boolean isAMG();
    
    public boolean isAR();
    
    public boolean isBP();
    
    public boolean isPH();
    
    public boolean isCEP();
    
    public boolean isLeadership();
    
    public boolean isTravel();
    
    public boolean isCOE();
    
    public boolean isDE();
    
    public boolean isHR(); // Normal HR access
    public boolean isHRPms(); // HR Super admin for PMS
    public boolean isHRPmsAdmin(); // HR Super admin for PMS
    
    public boolean isTVF();
    
    public Integer getUserPM(Integer uid);
    
	public Integer getMonth(String tsmonth);

	public Integer getYear(String tsmonth);
	
	public List<String> getLoggedInUserPortfolio();
	
	// Allocation add / update notification
    public boolean sendAllocationNotification(Allocation alc, String actionType, HttpServletRequest request)  throws MessagingException;

    public boolean sendCmsNotification(Cms cms, String actionType, HttpServletRequest request)  throws MessagingException;
    
    public boolean sendSowNotification(Sow sow, String actionType, HttpServletRequest request)  throws MessagingException;

    public boolean sendTreqNotification(Treq treq, String actionType, HttpServletRequest request)  throws MessagingException;

    public boolean sendInvoiceNotification(Invoices invoices, String actionType, HttpServletRequest request)  throws MessagingException;

    public boolean sendProjectNotification(Project project, String actionType, HttpServletRequest request)  throws MessagingException;

    public boolean sendTaskAssignmentNotification(ProjectTask taskinfo, List<String> resourceMailId, HttpServletRequest request) throws MessagingException;

    public boolean sendSkillNotification(Skill skill, String actionType, HttpServletRequest request)  throws MessagingException;
    
    public boolean sendCityNotification(City city, String actionType, HttpServletRequest request)  throws MessagingException;
    
    public boolean sendCountryNotification(Country country, String actionType, HttpServletRequest request)  throws MessagingException;
    
    public boolean sendCurrencyNotification(Currency currency, String actionType, HttpServletRequest request)  throws MessagingException;
    
    public boolean sendExitFormNotification(ExitForm exitForm, String actionType, HttpServletRequest request)  throws MessagingException;
    
    public boolean sendSowDetailDeleteNotification(Integer sowDetailId,Integer Uid, HttpServletRequest request)	throws MessagingException;
    
    public boolean sendDeNotification(DeGovernance deGovernance, String actionType,String isPhDe, HttpServletRequest request)  throws MessagingException;
    
	public boolean isG5AndAboveGrade();

	public boolean sendBuspassNotification(BusPass busPass, String actionType, HttpServletRequest request) throws MessagingException;
	public boolean sendBuspassDeleteNotification(Integer busPassId,Integer Uid, HttpServletRequest request)	throws MessagingException;
	public boolean sendInfoCabNotification(InfoCab infoCab, String actionType, HttpServletRequest request) throws MessagingException;
	
	public boolean sendDeNoteNotification(DEGovernanceNotes deGovernanceNotes, HttpServletRequest request)	throws MessagingException;
	
	public boolean sendActionTrakerNotification(ActionItem actionItem, String actionType, HttpServletRequest request)	throws MessagingException;
	public boolean sendISowNotification(ISow ISow, HttpServletRequest request) throws MessagingException;

	public boolean sendInfoTravelNotification(InfoTravel infoTravel, String actionType, HttpServletRequest request) throws MessagingException;

	public boolean sendActionTrackerNotification(HttpServletRequest request) throws MessagingException;
	public boolean sendAppreciationNotification(DeAppreciation deAppreciaton, String actionType, HttpServletRequest request) throws MessagingException;
	public boolean sendComplaintNotification(DeComplaint deComplaint, String actionType, HttpServletRequest request) throws MessagingException;
	public boolean sendDeValueAddNotification(DeValueAdd deValueAdd, String actionType, HttpServletRequest request) throws MessagingException;
	public boolean sendMsrNotification(DeMsr deMsr, String actionType, HttpServletRequest request) throws MessagingException;
	public boolean sendWsrNotification(DeWsr deWsr, String actionType, HttpServletRequest request) throws MessagingException;
	
	public boolean sendInfoTravelApproverCronNotification() throws MessagingException;
	public boolean sendInfoTravelFinanceCronNotification() throws MessagingException;
	public boolean sendInfoTravelDeskDomesticEsc1CronNotification() throws MessagingException;
	public boolean sendInfoTravelDeskInternationalEsc1CronNotification() throws MessagingException;
	public boolean sendInfoTravelDeskDomesticEsc2CronNotification() throws MessagingException;
	public boolean sendInfoTravelDeskInternationalEsc2CronNotification() throws MessagingException;
	public boolean sendInfoTravelAutoRejectionNotification() throws MessagingException;
	public boolean sendSurveyReminderNotifications() throws MessagingException;
    public boolean sendSurveyNotification(Survey survey, String actionType, HttpServletRequest request)  throws MessagingException;
    public boolean sendExitAccessNotification(ExitAccess exitAccess, String actionType, HttpServletRequest request)  throws MessagingException;

    
}
