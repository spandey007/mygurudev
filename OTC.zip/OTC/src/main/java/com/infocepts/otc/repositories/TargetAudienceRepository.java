/**
* Filename: /src/main/java/com/infocepts/otc/repositories/TargetAudienceRepository.java
* @author  Anjali S. Kalbande
* @version 1.0
* @since   2019-06-10 
*/
package com.infocepts.otc.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.infocepts.otc.entities.Survey;
import com.infocepts.otc.entities.TargetAudience;

public interface TargetAudienceRepository extends JpaRepository<TargetAudience,Integer>{
	
	@Override
	public List<TargetAudience> findAll();	
	
	@Transactional
	@Modifying
	@Query("delete from TargetAudience where surveyId = :surveyId")
	public void deleteTargetAudienceBySurveyId(@Param(value = "surveyId") Integer surveyId);
	
	@Query("from TargetAudience where surveyId = :surveyId")
	public List<TargetAudience> findTargetAudienceBySurveyId(@Param(value = "surveyId") Integer surveyId);
	
}
