package com.infocepts.otc.entities;

import java.math.BigDecimal;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import com.infocepts.otc.utilities.LoadConstant;

@Entity
@Table(catalog=LoadConstant.otc, schema="[dbo]",name="contributionMargin")
public class ContributionMargin {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer contributionMarginId;
	
	@Column(precision=12,scale=2)
	private BigDecimal onshoreRevenue;
	
	@Column(precision=12,scale=2)
	private BigDecimal offshoreRevenue;
	
	@Column(precision=12,scale=2)
	private BigDecimal revenue;
	
	@Column(precision=12,scale=2)
	private BigDecimal peopleCost;
	
	@Column(precision=8,scale=2)
	private BigDecimal cm1;
	
	@Column(precision=8,scale=2)
	private BigDecimal cm1Onshore;
	
	@Column(precision=8,scale=2)
	private BigDecimal cm1Offshore;
	
	@Column(precision=8,scale=2)
	private BigDecimal cm2;
	
	@Column(precision=12,scale=2)
	private BigDecimal expenses;
	
	@Column(precision=8,scale=2)
	private BigDecimal travel;
	
	@Column(precision=8,scale=2)
	private BigDecimal others;

	public Integer getContributionMarginId() {
		return contributionMarginId;
	}

	public void setContributionMarginId(Integer contributionMarginId) {
		this.contributionMarginId = contributionMarginId;
	}

	public BigDecimal getOnshoreRevenue() {
		return onshoreRevenue;
	}

	public void setOnshoreRevenue(BigDecimal onshoreRevenue) {
		this.onshoreRevenue = onshoreRevenue;
	}

	public BigDecimal getOffshoreRevenue() {
		return offshoreRevenue;
	}

	public void setOffshoreRevenue(BigDecimal offshoreRevenue) {
		this.offshoreRevenue = offshoreRevenue;
	}

	public BigDecimal getRevenue() {
		return revenue;
	}

	public void setRevenue(BigDecimal revenue) {
		this.revenue = revenue;
	}

	public BigDecimal getPeopleCost() {
		return peopleCost;
	}

	public void setPeopleCost(BigDecimal peopleCost) {
		this.peopleCost = peopleCost;
	}

	public BigDecimal getCm1() {
		return cm1;
	}

	public void setCm1(BigDecimal cm1) {
		this.cm1 = cm1;
	}

	public BigDecimal getCm1Onshore() {
		return cm1Onshore;
	}

	public void setCm1Onshore(BigDecimal cm1Onshore) {
		this.cm1Onshore = cm1Onshore;
	}

	public BigDecimal getCm1Offshore() {
		return cm1Offshore;
	}

	public void setCm1Offshore(BigDecimal cm1Offshore) {
		this.cm1Offshore = cm1Offshore;
	}

	public BigDecimal getCm2() {
		return cm2;
	}

	public void setCm2(BigDecimal cm2) {
		this.cm2 = cm2;
	}

	public BigDecimal getExpenses() {
		return expenses;
	}

	public void setExpenses(BigDecimal expenses) {
		this.expenses = expenses;
	}

	public BigDecimal getTravel() {
		return travel;
	}

	public void setTravel(BigDecimal travel) {
		this.travel = travel;
	}

	public BigDecimal getOthers() {
		return others;
	}

	public void setOthers(BigDecimal others) {
		this.others = others;
	}
}
