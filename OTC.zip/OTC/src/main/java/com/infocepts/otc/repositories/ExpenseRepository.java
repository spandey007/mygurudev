/**
 * 
 */
package com.infocepts.otc.repositories;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.persistence.EntityManager;

import com.infocepts.otc.entities.ExpensePurpose;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.infocepts.otc.entities.Expense;
import com.infocepts.otc.utilities.ExpenseReportModel;
import com.infocepts.otc.utilities.LoadConstant;


/**
 * @author Rewatiraman Singh
 *
 */
@Repository
public interface ExpenseRepository extends JpaRepository<Expense, Integer> {
	
	public static final Logger LOGGER = Logger.getLogger(ExpenseRepository.class.getName());
	public enum ApprovalFor {
		PM_AH_PH,
		TRAVEL,
		FINANCE,
		SETTLEMENT
	}

	@SuppressWarnings("unchecked")
	static List<Expense> findExpenseByUserId(EntityManager manager, Integer uid) {
		String queryString = "select e.*, p.title as projectTitle, u.name as unitName,"
				+ " cr.code as currencyCode from " + LoadConstant.otc + ".[dbo].[expense] e" + 
				" inner join " + LoadConstant.infomaster + ".[dbo].[resource] r on r.uid = e.uid" + 
				" inner join " + LoadConstant.infomaster + ".[dbo].[project] p on p.itemId = e.projectId" + 
				" inner join " + LoadConstant.infomaster + ".[dbo].[unit] u on u.unitId = e.unitId" + 
				" inner join " +  LoadConstant.infomaster  + ".[dbo].[entities] en on en.entityId = u.entityId" + 
				" inner join " +  LoadConstant.infomaster  + ".[dbo].[country] c on c.countryId = en.countryId" + 
				" inner join " +  LoadConstant.infomaster  + ".[dbo].[currency] cr on cr.currencyId = c.currencyId" + 
				" where e.uid = :uid order by e.expenseId desc";
		
		List<Expense> expenses = new ArrayList<>();
		try {
			List<Object[]> resultList = manager.createNativeQuery(queryString, "myExpenseList").setParameter("uid", uid).getResultList();
			resultList.forEach(object -> {
				Expense expense = (Expense) object[0];
				expense.setExpenseCode("EXP00" + expense.getExpenseId());
				expense.setProjectTitle((String)object[1]);
				expense.setIsMyExpense(true);
				expense.setUnitName((String)object[2]);
				expense.setCurrencyCode((String)object[3]);
				expenses.add(expense);
			});
		} catch (Exception ex) {
			LOGGER.log(Level.SEVERE, "COULD NOT FETCH EXPENSES WITH USER ID: " + uid, ex);
		}
		return expenses;
	}
	
	
	/**
	 * @param entityManager
	 * @param
	 * @return - true if the current user is an account head false otherwise.
	 */
	static boolean isAH(EntityManager entityManager, Integer uid) {
		String queryString = "SELECT COUNT(*) FROM Account ac WHERE ac.ahId = :uid";
		try {
			javax.persistence.Query countQuery = entityManager.createQuery(queryString, Long.class);
			countQuery.setParameter("uid", uid);
			return (Long) countQuery.getSingleResult() > 0;
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, "COULDN'T FETCH COUNT FOR ACCOUNTS WITH GIVEN AH ID: " + uid, e);
		}
		return false;
	}
	
	/**
	 * @param manager
	 * @param expenseId
	 * @return - Formatted Expense, That is expense object containing project, resource title and currency as such.
	 */
	@SuppressWarnings("unchecked")
	static Expense findFormattedExpenseByExpenseId(EntityManager manager, Integer expenseId) {
		String queryString = "select e.*, p.title as projectTitle, r.title as resourceName, g.designation, u.name as unitName,"
				+ " cr.code as currencyCode from " + LoadConstant.otc + ".[dbo].[expense] e" + 
				" inner join " + LoadConstant.infomaster + ".[dbo].[resource] r on r.uid = e.uid" + 
				" inner join " + LoadConstant.infomaster + ".[dbo].[project] p on p.itemId = e.projectId" + 
				" inner join " + LoadConstant.infomaster + ".[dbo].[unit] u on u.unitId = e.unitId" + 
				" inner join " +  LoadConstant.infomaster  + ".[dbo].[entities] en on en.entityId = u.entityId" + 
				" inner join " +  LoadConstant.infomaster  + ".[dbo].[country] c on c.countryId = en.countryId" + 
				" inner join " +  LoadConstant.infomaster  + ".[dbo].[currency] cr on cr.currencyId = c.currencyId" + 
				" inner join " +  LoadConstant.infomaster  + ".[dbo].[grade] g on g.gradeId = r.gradeId" + 
				" where e.expenseId = :expenseId";
		
		List<Expense> expenses = new ArrayList<>();
		try {
			List<Object[]> resultList = manager.createNativeQuery(queryString, "userExpense").setParameter("expenseId", expenseId).getResultList();
			resultList.forEach(object -> {
				Expense expense = (Expense) object[0];
				expense.setExpenseCode("EXP00" + expense.getExpenseId());
				expense.setProjectTitle((String)object[1]);
				expense.setResourceName((String)object[2]);
				expense.setDesignation((String)object[3]);
				expense.setIsMyExpense(true);
				expense.setUnitName((String)object[4]);
				expense.setCurrencyCode((String)object[5]);
				expenses.add(expense);
			});
		} catch (Exception ex) {
			LOGGER.log(Level.SEVERE, "COULD NOT FETCH EXPENSES WITH USER ID: " + expenseId, ex);
		}
		return expenses.get(0);
	}
	
	@Query("FROM Expense WHERE uid = :uid AND expenseId = :expenseId")
	public Expense findExpenseByUserAndExpenseId(@Param("uid") Integer uid, @Param("expenseId") Integer expenseId);
	
	
	// This method is supposed to fetch approval list for the user having role either as PM, AH or PH.
	/**
	 * @param manager - EntityManager object to create the JPQL.
	 * @param uid - User for which the approval list is to be fetched.
	 * @return - List of expenses to be shown on approval tab.
	 */
	@SuppressWarnings("unchecked")
	@Query
	static List<Expense> getApprovalList(EntityManager manager, Integer uid, ApprovalFor approvalFor) {
		List<Expense> approvalList = new ArrayList<>();
		
		if (approvalFor == ApprovalFor.PM_AH_PH) {
			/* Here "exd.status > 1" predicate in query implies that fetch only those records whose status is anything but DRAFT. 
			Expenses with DRAFT status are non-submitted expenses which should not be visible for approvals.
			 * Please refer below constant values.
			 *  EXPENSE_STATUS_DRAFT = 1;
			EXPENSE_STATUS_PENDING_APPROVAL = 2;
			EXPENSE_STATUS_APPROVED = 3;
			EXPENSE_STATUS_REJECTED = 4;
			EXPENSE_STATUS_CANCELLED = 5;
			 */
			String query = "select e.*, r.title as resourceName, p.title as projectTitle, u.name as unitName"
					+ ", cr.code as currencyCode from " + LoadConstant.otc + ".[dbo].[expense] e" + 
					" inner join " + LoadConstant.infomaster + ".[dbo].[resource] r on r.uid = e.uid" + 
					" inner join "+ LoadConstant.infomaster + ".[dbo].[project] p on p.itemId = e.projectId" + 
					" inner join " +  LoadConstant.infomaster  + ".[dbo].[accounts] ac on p.accountId = ac.itemId" + 
					" inner join " +  LoadConstant.infomaster  + ".[dbo].[unit] u on u.unitId = e.unitId" + 
					" inner join " +  LoadConstant.infomaster  + ".[dbo].[entities] en on en.entityId = u.entityId" + 
					" inner join " +  LoadConstant.infomaster  + ".[dbo].[country] c on c.countryId = en.countryId" +
					" inner join " +  LoadConstant.infomaster  + ".[dbo].[currency] cr on cr.currencyId = c.currencyId" +
					" inner join " +  LoadConstant.infomaster  + ".[dbo].[grade] g on g.gradeId = r.gradeId" +
					" inner join " +  LoadConstant.infomaster  + ".[dbo].[portfolio] pf on pf.itemId = p.portfolioId" +
					" where e.status > 1 and (p.projectManagersId = :uid or ac.ahId = :uid or pf.ownerId = :uid) and" +
					" e.uid <> :uid order by e.expenseId desc";

			try {
				List<Object[]> resultList = manager.createNativeQuery(query, "approvalList").setParameter("uid", uid).getResultList();
				prepareExpenseList(resultList, approvalList);
			} catch (Exception e) {
				LOGGER.log(Level.SEVERE, "SOMETHING WENT WRONG WHILE FETCHING PM/AH/PH APPROVAL LIST!", e);
			}
			
		} 
		
		// Fetch approval list for user(s) having Travel role.
		else if (approvalFor == ApprovalFor.TRAVEL) {
			String query = "select r.title as resourceName, p.title as projectTitle, e.*, u.name as unitName"
					+ ", cr.code as currencyCode from " + LoadConstant.otc + ".[dbo].[expense] e" + 
					" inner join " + LoadConstant.otc + ".[dbo].[expenseDetail] ed on ed.expenseId = e.expenseId" + 
					" inner join " + LoadConstant.infomaster + ".[dbo].[resource] r on r.uid = e.uid" + 
					" inner join "+ LoadConstant.infomaster + ".[dbo].[project] p on p.itemId = e.projectId" + 
					" inner join " +  LoadConstant.infomaster  + ".[dbo].[unit] u on u.unitId = e.unitId" + 
					" inner join " +  LoadConstant.infomaster  + ".[dbo].[entities] en on en.entityId = u.entityId" + 
					" inner join " +  LoadConstant.infomaster  + ".[dbo].[country] c on c.countryId = en.countryId" + 
					" inner join " +  LoadConstant.infomaster  + ".[dbo].[currency] cr on cr.currencyId = c.currencyId" + 
					" inner join "+ LoadConstant.infomaster + ".[dbo].[expensePurpose] ept on ept.purposeId = ed.purposeId" +
					" where e.status = 3 and e.travelStatus > 1 and e.uid <> :uid and ept.purposeName like '%Travel%' order by e.travelStatus, e.expenseId desc";
			try {
				List<Object[]> resultList = manager.createNativeQuery(query, "approvalList").setParameter("uid", uid).getResultList();
				prepareExpenseList(resultList, approvalList);
			} catch (Exception e) {
				LOGGER.log(Level.SEVERE, "SOMETHING WENT WRONG WHILE FETCHING TRAVEL APPROVAL LIST!", e);
			}
		} 
		
		// Fetch approval list for user(s) having Finance role.
		else if (approvalFor == ApprovalFor.FINANCE) {
			/*Display only those expense to finance which are already approved by PM/AH/PH and then Travel team.
			 */
			String query = "select r.title as resourceName, p.title as projectTitle, e.*, u.name as unitName"
					+ ", cr.code as currencyCode from " + LoadConstant.otc + ".[dbo].[expense] e" + 
					" inner join " + LoadConstant.infomaster + ".[dbo].[resource] r on r.uid = e.uid" + 
					" inner join "+ LoadConstant.infomaster + ".[dbo].[project] p on p.itemId = e.projectId" + 
					" inner join " +  LoadConstant.infomaster  + ".[dbo].[unit] u on u.unitId = e.unitId" + 
					" inner join " +  LoadConstant.infomaster  + ".[dbo].[entities] en on en.entityId = u.entityId" + 
					" inner join " +  LoadConstant.infomaster  + ".[dbo].[country] c on c.countryId = en.countryId" + 
					" inner join " +  LoadConstant.infomaster  + ".[dbo].[currency] cr on cr.currencyId = c.currencyId" + 
					" where e.status = 2 or e.travelStatus = 2 or e.financeStatus = 2 order by e.expenseId desc";
			try {
				List<Object[]> resultList = manager.createNativeQuery(query, "approvalList").getResultList();
				prepareExpenseList(resultList, approvalList);
			} catch (Exception e) {
				LOGGER.log(Level.SEVERE, "SOMETHING WENT WRONG WHILE FETCHING FINANCE APPROVAL LIST!", e);
			}
		} else if (approvalFor == ApprovalFor.SETTLEMENT) {

			/*Display only those expense to finance which are already approved by PM/AH/PH and then Travel team.
			 */
			String query = "select r.title as resourceName, p.title as projectTitle, e.*, u.name as unitName" + 
					" , cr.code as currencyCode from " + LoadConstant.otc + ".[dbo].[expense] e" + 
					" inner join " + LoadConstant.infomaster + ".[dbo].[resource] r on r.uid = e.uid" + 
					" inner join "+ LoadConstant.infomaster + ".[dbo].[project] p on p.itemId = e.projectId" + 
					" inner join " +  LoadConstant.infomaster  + ".[dbo].[unit] u on u.unitId = e.unitId" + 
					" inner join " +  LoadConstant.infomaster  + ".[dbo].[entities] en on en.entityId = u.entityId" + 
					" inner join " +  LoadConstant.infomaster  + ".[dbo].[country] c on c.countryId = en.countryId" + 
					" inner join " +  LoadConstant.infomaster  + ".[dbo].[currency] cr on cr.currencyId = c.currencyId" + 
					" where e.financeStatus = 3 order by e.expenseId desc";
			try {
				List<Object[]> resultList = manager.createNativeQuery(query, "approvalList").getResultList();
				prepareExpenseList(resultList, approvalList);
			} catch (Exception e) {
				LOGGER.log(Level.SEVERE, "SOMETHING WENT WRONG WHILE FETCHING FINANCE APPROVAL LIST!", e);
			}
		}
		
		return approvalList;
	}
	
	default boolean deleteExpenseByUserId(Integer uid) {
		boolean isDeleted = false;
		try {
			this.delete(uid);
			isDeleted = true;
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, "SOMETHING WENT WRONG DELETING AN EXPENSE WITH ID: " + uid, e);
		}
		return isDeleted;
	}
	
	/**In this method we're simply extracting the expense object and resource name (Transient variable)
	 * and appending it to the approval list we're going to send back to client side.
	 * @param resultList
	 * @param approvalList
	 */
	static void prepareExpenseList(List<Object[]>  resultList, List<Expense> approvalList) {
		if (!CollectionUtils.isEmpty(resultList)) {
			for (Object[] object : resultList) {
				Expense expense = (Expense) object[0];
				expense.setResourceName((String)object[1]);
				expense.setProjectTitle((String)object[2]);
				expense.setUnitName((String)object[3]);
				expense.setExpenseCode("EXP00" + expense.getExpenseId());
				expense.setCurrencyCode((String)object[4]);
				approvalList.add(expense);
			}
		}
	}
	
	/**
	 * @param manager
	 * @param expenseId
	 * @return - true if the given expense is of type travel, False otherwise.
	 */
	@SuppressWarnings("unchecked")
	default boolean isPurposeTypeTravel(EntityManager manager, Integer expenseId) {
		String queryString = "select ept.* from " + LoadConstant.otc + ".[dbo].[expense] e"
				+ " inner join " + LoadConstant.otc + ".[dbo].[expenseDetail] ed on ed.expenseId = e.expenseId"
				+ " inner join " + LoadConstant.infomaster + ".[dbo].[expensePurpose] ept"
				+ " on ept.purposeId = ed.purposeId"
				+ " where e.expenseId = :expenseId";
		List<ExpensePurpose> expensePurposeList = manager.createNativeQuery(queryString, "fetchPurpose")
				.setParameter("expenseId", expenseId)
				.getResultList();
		return expensePurposeList.stream().anyMatch(purpose -> "Travel".equals(purpose.getPurposeName()));
	}
	
	/**
	 * @param manager
	 * @param expenseReportModel - Model object which contains the search parameter sent from client side.
	 * @return - List of Expense record after applying the search criteria in the query.
	 */
	@SuppressWarnings("unchecked")
	default List<Expense> search(EntityManager manager, ExpenseReportModel expenseReportModel) {
		String query = "select e.*, p.title as projectTitle, r.title as resourceName, u.name as unitName, cr.code as currencyCode" +
				" from " + LoadConstant.otc + ".[dbo].[expense] e" +
				" inner join " + LoadConstant.infomaster + ".[dbo].[resource] r on r.uid = e.uid" +
				" inner join " +  LoadConstant.infomaster  + ".[dbo].[unit] u on u.unitId = e.unitId" +
				" inner join " +  LoadConstant.infomaster  + ".[dbo].[entities] en on en.entityId = u.entityId" +
				" inner join " +  LoadConstant.infomaster  + ".[dbo].[country] c on c.countryId = en.countryId" +
				" inner join " +  LoadConstant.infomaster  + ".[dbo].[currency] cr on cr.currencyId = c.currencyId" +
				" inner join "+ LoadConstant.infomaster + ".[dbo].[project] p on p.itemId = e.projectId where e.status <> 1";
		
		StringBuilder queryString = new StringBuilder(query);
		Integer uid = expenseReportModel.getUid();
		Integer unitId = expenseReportModel.getUnitId();
		Integer status = expenseReportModel.getStatus();
		Integer financeStatus = expenseReportModel.getFinanceStatus();
		Integer travelStatus = expenseReportModel.getTravelStatus();
		Integer projectId = expenseReportModel.getProjectId();
		Date startDate = expenseReportModel.getStartDate();
		Date endDate = expenseReportModel.getEndDate();
		String expenseCode = expenseReportModel.getExpenseCode();
		Integer expenseId = null;

		if (StringUtils.isNotBlank(expenseCode)) {
		    expenseId = NumberUtils.toInt(expenseCode.replace("EXP00", ""));
        }

		List<Expense> searchResult = new ArrayList<>();

		if (uid != null) { 
			// Check if the query already has "where" clause.
            if (queryString.indexOf("where") == -1) {
                queryString.append(String.format(" where e.uid=%s", uid));
            } else {
                queryString.append(String.format(" and e.uid=%s", uid));
            }
		}

		if (expenseId != null) {
            // Check if the query already has "where" clause.
            if (queryString.indexOf("where") == -1) {
                queryString.append(String.format(" where e.expenseId=%s", expenseId));
            } else {
                queryString.append(String.format(" and e.expenseId=%s", expenseId));
            }
        }
		
		if (unitId != null) {
			// Check if the query already has "where" clause.
			if (queryString.indexOf("where") == -1) {
				queryString.append(String.format(" where r.unitId=%s", unitId));
			} else {
				queryString.append(String.format(" and r.unitId=%s", unitId));
			}
		}
		
		if (status != null) {
			// Check if the query already has "where" clause.
			if (queryString.indexOf("where") == -1) {
				queryString.append(" where ");
			} else {
				queryString.append(" and ");
			}
			appendStatusCondition(queryString, status);
		}
		if (travelStatus != null) {
			// Check if the query already has "where" clause.
			if (queryString.indexOf("where") == -1) {
				queryString.append(String.format(" where e.travelStatus = %s", travelStatus));
			} else {
				queryString.append(String.format(" and e.travelStatus = %s", travelStatus));
			}
		}
		
		if (financeStatus != null) {
			// Check if the query already has "where" clause.
			if (queryString.indexOf("where") == -1) {
				queryString.append(String.format(" where e.financeStatus = %s", financeStatus));
			} else {
				queryString.append(String.format(" and e.financeStatus = %s", financeStatus));
			}
		}
		
		if (projectId != null) {
			// Check if the query already has "where" clause.
			if (queryString.indexOf("where") == -1) {
				queryString.append(String.format(" where e.projectId = %s", projectId));
			} else {
				queryString.append(String.format(" and e.projectId = %s", projectId));
			}
		}
		
		if (startDate != null) {
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
			String formattedStartDate = simpleDateFormat.format(startDate);
			// Check if the query already has "where" clause.
			if (queryString.indexOf("where") == -1) {
				queryString.append(String.format(" where convert(date, e.startDate) = '%s'", formattedStartDate));
			} else {
				queryString.append(String.format(" and convert(date, e.startDate) = '%s'", formattedStartDate));
			}
		}
		
		if (endDate != null) {
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
			String formattedEndDate = simpleDateFormat.format(endDate);
			// Check if the query already has "where" clause.
			if (queryString.indexOf("where") == -1) {
				queryString.append(String.format(" where convert(date, e.endDate) = '%s'", formattedEndDate));
			} else {
				queryString.append(String.format(" and convert(date, e.endDate) = '%s'", formattedEndDate));
			}
		}

		try {
			List<Object[]> resultList = manager.createNativeQuery(queryString.toString(), "reportSearch").getResultList();
			resultList.forEach(object -> {
				Expense expense = (Expense) object[0];
				expense.setProjectTitle((String)object[1]);
				expense.setResourceName((String)object[2]);
				expense.setUnitName((String)object[3]);
				expense.setCurrencyCode((String)object[4]);
				expense.setReportView(true);
				expense.setExpenseCode("EXP00" + expense.getExpenseId());
                searchResult.add(expense);
			});
		} catch (Exception e) {
			LOGGER.log(Level.WARNING, "COULD NOT FETCH EXPENSE RECORDS WITH THE GIVEN SEARCH CRITERIA!", e);
		}
		return searchResult;
	}

	default void appendStatusCondition(StringBuilder queryString, Integer status) {
		if (status == LoadConstant.EXPENSE_PM_REJECTED) {
			queryString.append("e.status = 4");
		} else if (status == LoadConstant.EXPENSE_PM_APPROVED_TD_PENDING) {
			queryString.append("e.status = 3 and e.travelStatus = 2");
		} else if (status == LoadConstant.EXPENSE_PM_APPROVED_TD_REJECTED) {
			queryString.append("e.status = 3 and e.travelStatus = 4");
		} else if (status == LoadConstant.EXPENSE_PM_TD_APPROVED_FINANCE_PENDING) {
			queryString.append("e.status = 3 and e.travelStatus = 3 and e.financeStatus = 2");
		} else if (status == LoadConstant.EXPENSE_PM_APPROVED_FINANCE_PENDING) {
			queryString.append("e.status = 3 and  e.financeStatus = 2");
		} else if (status == LoadConstant.EXPENSE_PM_APPROVED_FINANCE_REJECTED) {
			queryString.append("e.status = 3 and  e.financeStatus = 4");
		} else if (status == LoadConstant.EXPENSE_PM_FINANCE_APPROVED_SETTLEMENT_PENDING) {
			queryString.append("e.status = 3 and  e.financeStatus = 3 and e.settlementDate is null");
		} else if (status == LoadConstant.EXPENSE_PM_TD_APPROVED_FINANCE_REJECTED) {
			queryString.append("e.status = 3 and e.travelStatus = 3 and e.financeStatus = 4");
		} else if (status == LoadConstant.EXPENSE_PM_TD_FINANCE_APPROVED_SETTLEMENT_PENDING) {
			queryString.append("e.status = 3 and e.travelStatus = 3 and e.financeStatus = 3 and e.settlementDate is null");
		} else if (status == LoadConstant.EXPENSE_SETTLED_BY_FINANCE) {
			queryString.append("e.status = 6");
		} else if (status == LoadConstant.EXPENSE_PM_APPROVAL_PENDING) {
			queryString.append("e.status = 2");
		}
	}
}
