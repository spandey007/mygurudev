/**
* Filename: /src/main/java/com/infocepts/otc/repositories/CT_FunctionalTrainingRepository.java
* @author  VVC
* @version 1.0
* @since   2018-12-03 
*/

package com.infocepts.otc.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import com.infocepts.otc.entities.CT_TechnologyMapping;

public interface CT_TechnologyMappingRepository extends CrudRepository<CT_TechnologyMapping,Integer>{

	@Override
	public List<CT_TechnologyMapping> findAll();
	
}


