package com.infocepts.otc.controllers;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.infocepts.otc.entities.Timesheet;
import com.infocepts.otc.repositories.TimesheetRepository;


@RestController
@RequestMapping(value="/timesheet",headers="referer")//JV: Added 'headers' param to validate the url.
public class TimesheetController {
	
	final Logger logger = Logger.getLogger(TimesheetController.class);
	
	@Autowired
	TimesheetRepository repository;
	
	@RequestMapping(method=RequestMethod.GET)
	public List<Timesheet> getTimesheet(@RequestParam(value = "periodId", defaultValue = "0") Integer periodId,
											@RequestParam(value = "uid", defaultValue = "0") Integer uid) {
		List<Timesheet> timesheetlist=null;
		try{
			if(periodId == 0 && uid == 0)
			{
				timesheetlist = repository.findAll();
			}
			else
			{			
				timesheetlist = repository.findTimesheetsByPeriodByUser(periodId, uid);
			}
		}catch(Exception e){
			logger.error(e);
		}
		return timesheetlist;
	}
	
	 @RequestMapping(value="/{timesheetId}",method=RequestMethod.GET)
	 public Timesheet getSow(@PathVariable Integer timesheetId){
		 Timesheet timesheet = null;
		 try{
		    timesheet = repository.findOne(timesheetId);
		 }
		 catch(Exception e){
			logger.error(e);
		 }
		 return timesheet;
	 }
	
	@RequestMapping(method=RequestMethod.POST)
	public Timesheet addTimesheet(@RequestBody Timesheet timesheet) {
		try{
			timesheet.setTimesheetId(null);
			repository.save(timesheet);
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return timesheet;
	}
	
	@RequestMapping(value="/{timesheetId}",method=RequestMethod.PUT)
	public Timesheet updateTimesheet(@PathVariable Integer timesheetId,@RequestBody Timesheet utimesheet) {
		try{
			utimesheet.setTimesheetId(timesheetId);
			repository.save(utimesheet);
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
		 return utimesheet;
	}
	
	@RequestMapping(value="/{timesheetId}",method=RequestMethod.DELETE)
	public void deleteTimesheet(@PathVariable Integer timesheetId) {
		try{
			repository.delete(timesheetId);
		 }
		 catch(Exception e){
			 logger.error(e);
		 }
	}
	
}
