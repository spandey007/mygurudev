package com.infocepts.otc.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.infocepts.otc.utilities.LoadConstant;

@Entity
@Table(catalog=LoadConstant.otc, schema="[dbo]",name="busroute")

public class BusRoute {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer busRouteId;
	private String busRouteName;
	
	
	//Getter and Setter
	
	public Integer getBusRouteId() {
		return busRouteId;
	}
	public void setBusRouteId(Integer busRouteId) {
		this.busRouteId = busRouteId;
	}
	public String getBusRouteName() {
		return busRouteName;
	}
	public void setBusRouteName(String busRouteName) {
		this.busRouteName = busRouteName;
	}
}
