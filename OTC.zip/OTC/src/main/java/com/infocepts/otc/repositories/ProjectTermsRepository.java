package com.infocepts.otc.repositories;

import java.util.List;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import com.infocepts.otc.entities.ProjectTerms;
import java.lang.Integer;

public interface ProjectTermsRepository extends CrudRepository<ProjectTerms,Integer>{

	@Override
	public List<ProjectTerms> findAll();
	
	@Query("from ProjectTerms where projectId = :projectId")
	public List<ProjectTerms> findByProjectId(@Param("projectId")Integer projectId);
}
