package com.infocepts.otc.entities;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.Table;
import javax.persistence.Transient;
import com.infocepts.otc.utilities.LoadConstant;


@Entity
@Table(catalog=LoadConstant.otc, schema="[dbo]",name="sow")
@SqlResultSetMapping(
	      name = "sow_for_project",
	      classes = {
	          @ConstructorResult(
	              targetClass = Sow.class,
	              columns = {
	                  @ColumnResult(name = "sowId"),
	                  @ColumnResult(name = "sowNo"),
	                  @ColumnResult(name = "sowStartDate", type=Date.class),
	                  @ColumnResult(name = "sowEndDate", type=Date.class),
	                  @ColumnResult(name = "projectId"),
	                  @ColumnResult(name = "projectName"),
	                  @ColumnResult(name = "projectType"),
	                  @ColumnResult(name = "status"),
	                  @ColumnResult(name = "createdDate", type=Date.class),
	                  @ColumnResult(name = "modifiedDate", type=Date.class),
	                  @ColumnResult(name = "comments"),
	                  @ColumnResult(name = "clientPo"),
	                  @ColumnResult(name = "uomId"),
	                  @ColumnResult(name = "currencyId"),
	                  @ColumnResult(name = "currencySign"),
	                  @ColumnResult(name = "uomName"),
	                  @ColumnResult(name = "documentTypeId"),
	                  @ColumnResult(name = "docPath"),
	                  @ColumnResult(name = "flatDiscountPer", type=BigDecimal.class),
	                  @ColumnResult(name = "externalSowNo"),
	                  @ColumnResult(name = "revenue",type=BigDecimal.class),
	                  @ColumnResult(name = "onshoreRevenue",type=BigDecimal.class),
	                  @ColumnResult(name = "offshoreRevenue",type=BigDecimal.class),
	                  @ColumnResult(name = "onshoreCost",type=BigDecimal.class),
	                  @ColumnResult(name = "offshoreCost",type=BigDecimal.class),
	                  @ColumnResult(name = "cost",type=BigDecimal.class),
	                  @ColumnResult(name = "margin",type=BigDecimal.class),
	                  @ColumnResult(name = "sowRolesCount"),
	                  @ColumnResult(name = "createdBy"),
	                  @ColumnResult(name = "modifiedBy"),
	                  @ColumnResult(name = "daysInMonth",type=String.class),
	                  @ColumnResult(name = "totalContractValue", type=BigDecimal.class),
	                  @ColumnResult(name = "opportunityId"),
	                  @ColumnResult(name = "isowId"),
	                  @ColumnResult(name = "isowNo",type=String.class)
	                }
	          )
	      }
	)
	@NamedNativeQueries({
	   @NamedNativeQuery(
	            name    =   "getSowForProject",
	            query   =   "select s.*, cast(p.title as varchar) as projectName,cast(b.name as varchar) as projectType, c.sign as currencySign, u.name as uomName,"+
	            			"(select count(*) from " + LoadConstant.otc + ".[dbo].sowDetail sd where sd.sowId=s.sowId and sd.isBillable = 1) as sowRolesCount,"+
	            			"(select Top 1 isowId from " + LoadConstant.otc + ".[dbo].isow  where sowId=s.sowId) as isowId,"+
	            			"(select Top 1 isowNo from " + LoadConstant.otc + ".[dbo].isow  where sowId=s.sowId) as isowNo"+
	            		 	" FROM " + LoadConstant.otc + ".[dbo].sow s"+
	            			" left join " + LoadConstant.infomaster + ".[dbo].project p on p.itemId=s.projectId"+
	            			" LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[billingtype] b on b.billingTypeId = p.billingTypeId " +
            				" left join " + LoadConstant.infomaster + ".[dbo].currency c on c.currencyId = s.currencyId" +
            				" Left Join " + LoadConstant.infomaster + ".[dbo].uom u on u.uomId = s.uomId"+
	                        " WHERE s.projectId= :projectId",
	                        resultClass=Sow.class, resultSetMapping = "sow_for_project"                       		
	    ),
	    @NamedNativeQuery(
	            name    =   "getSowsForAllProjects",
	            query   =   "select s.*, cast(p.title as varchar) as projectName,cast(b.name as varchar) as projectType, c.sign as currencySign, u.name as uomName," +
	            			"(select count(*) from " + LoadConstant.otc + ".[dbo].sowDetail sd where sd.sowId=s.sowId) as sowRolesCount, 0 as isowId, null as isowNo"+
	            			" FROM " + LoadConstant.otc + ".[dbo].sow s "+
	            			" left join " + LoadConstant.infomaster + ".[dbo].project p on p.itemId=s.projectId"+
	            			" LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[billingtype] b on b.billingTypeId = p.billingTypeId " +
	            			" left join " + LoadConstant.infomaster + ".[dbo].currency c on c.currencyId = s.currencyId"+
	            			" Left Join " + LoadConstant.infomaster + ".[dbo].uom u on u.uomId = s.uomId",
	                        resultClass=Sow.class, resultSetMapping = "sow_for_project"                       		
	    ),
	    @NamedNativeQuery(
	            name    =   "getLastSow",
	            query   =   "select TOP 1 s.*, '' as projectName, '' as projectType, '' as currencySign, u.name as uomName," +
	            			"null as sowRolesCount, 0 as isowId, null as isowNo"+
	            			" FROM " + LoadConstant.otc + ".[dbo].sow s "+
	            			" Left Join " + LoadConstant.infomaster + ".[dbo].uom u on u.uomId = s.uomId"+
	            			" order by s.sowId DESC",
	                        resultClass=Sow.class, resultSetMapping = "sow_for_project"                       		
	    ),
	    @NamedNativeQuery(
	            name    =   "getSowById",
	            query   =   "select s.*, cast(p.title as varchar) as projectName,cast(b.name as varchar) as projectType, c.sign as currencySign, u.name as uomName,"+
	            			"(select count(*) from " + LoadConstant.otc + ".[dbo].sowDetail sd where sd.sowId=s.sowId and sd.isBillable = 1) as sowRolesCount, 0 as isowId, null as isowNo"+
	            		 	" FROM " + LoadConstant.otc + ".[dbo].sow s"+
	            			" left join " + LoadConstant.infomaster + ".[dbo].project p on p.itemId=s.projectId"+
	            			" LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[billingtype] b on b.billingTypeId = p.billingTypeId " +
            				" left join " + LoadConstant.infomaster + ".[dbo].currency c on c.currencyId = s.currencyId" +
            				" Left Join " + LoadConstant.infomaster + ".[dbo].uom u on u.uomId = s.uomId"+
	                        " WHERE s.sowId= :sowId",
	                        resultClass=Sow.class, resultSetMapping = "sow_for_project"                       		
	    ),
})
public class Sow {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer sowId;
	
	private String sowNo;
	private Date sowStartDate;
	private Date sowEndDate;
	
	// Fields related to project
	private Integer projectId;
	
	private String status;
	private String clientPo;
	
	@Lob
	private String comments;
	
	private Integer uomId;	
	private Integer currencyId;
	private Integer documentTypeId;
	
	@Lob
	private String docPath; //  For VK - this should be docPath
	
	// Other general fields added
	@Column(precision=4,scale=2)
	private BigDecimal flatDiscountPer;
	private String externalSowNo;
		
	@Column(precision=12,scale=2)
	private BigDecimal revenue;
	
	@Column(precision=12,scale=2)
	private BigDecimal onshoreRevenue;
	
	@Column(precision=12,scale=2)
	private BigDecimal offshoreRevenue;
	
	@Column(precision=12,scale=2)
	private BigDecimal onshoreCost;
	
	@Column(precision=12,scale=2)
	private BigDecimal offshoreCost;
	
	@Column(precision=12,scale=2)
	private BigDecimal cost;
	private BigDecimal margin;
	
	@Column(precision=12,scale=2)
	private BigDecimal totalContractValue;
	
	private String daysInMonth;
	
	private Integer createdBy;
	private Integer modifiedBy;
	private Date createdDate;
	private Date modifiedDate;
	
	@Transient
	private String projectName;
	@Transient
	private String projectType;
	
	@Transient
	private String currencySign;
	
	@Transient
	private Integer sowRolesCount;
	
	@Transient
	private String uomName;
	
	private Integer opportunityId;
	
	@Transient
	private Integer isowId;
	
	@Transient
	private String isowNo;
	
	//only added for migration
//	private String projectManager;
//	private String projectMsa;
//	private String rmProjectId;
	//headerId - ???
	
	public Integer getSowId() {
		return sowId;
	}
	public void setSowId(Integer sowId) {
		this.sowId = sowId;
	}
	
	public Date getSowStartDate() {
		return sowStartDate;
	}
	public void setSowStartDate(Date sowStartDate) {
		this.sowStartDate = sowStartDate;
	}
	public Date getSowEndDate() {
		return sowEndDate;
	}
	public void setSowEndDate(Date sowEndDate) {
		this.sowEndDate = sowEndDate;
	}
	public Integer getProjectId() {
		return projectId;
	}
	public void setProjectId(Integer projectId) {
		this.projectId = projectId;
	}
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	public String getProjectType() {
		return projectType;
	}
	public void setProjectType(String projectType) {
		this.projectType = projectType;
	}
		
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public Date getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getClientPo() {
		return clientPo;
	}
	public void setClientPo(String clientPo) {
		this.clientPo = clientPo;
	}
	public Integer getUomId() {
		return uomId;
	}
	public void setUomId(Integer uomId) {
		this.uomId = uomId;
	}
	public Integer getCurrencyId() {
		return currencyId;
	}
	public void setCurrencyId(Integer currencyId) {
		this.currencyId = currencyId;
	}
	public Integer getDocumentTypeId() {
		return documentTypeId;
	}
	public void setDocumentTypeId(Integer documentTypeId) {
		this.documentTypeId = documentTypeId;
	}
	public String getDocPath() {
		return docPath;
	}
	public void setDocPath(String docPath) {
		this.docPath = docPath;
	}
	public String getSowNo() {
		return sowNo;
	}
	public void setSowNo(String sowNo) {
		this.sowNo = sowNo;
	}
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	public BigDecimal getFlatDiscountPer() {
		return flatDiscountPer;
	}
	public void setFlatDiscountPer(BigDecimal flatDiscountPer) {
		this.flatDiscountPer = flatDiscountPer;
	}
	public String getExternalSowNo() {
		return externalSowNo;
	}
	public void setExternalSowNo(String externalSowNo) {
		this.externalSowNo = externalSowNo;
	}
	
	public BigDecimal getRevenue() {
		return revenue;
	}
	public void setRevenue(BigDecimal revenue) {
		this.revenue = revenue;
	}
	public BigDecimal getOnshoreRevenue() {
		return onshoreRevenue;
	}

	public void setOnshoreRevenue(BigDecimal onshoreRevenue) {
		this.onshoreRevenue = onshoreRevenue;
	}

	public BigDecimal getOffshoreRevenue() {
		return offshoreRevenue;
	}

	public void setOffshoreRevenue(BigDecimal offshoreRevenue) {
		this.offshoreRevenue = offshoreRevenue;
	}
	
	public BigDecimal getOnshoreCost() {
		return onshoreCost;
	}
	public void setOnshoreCost(BigDecimal onshoreCost) {
		this.onshoreCost = onshoreCost;
	}
	public BigDecimal getOffshoreCost() {
		return offshoreCost;
	}
	public void setOffshoreCost(BigDecimal offshoreCost) {
		this.offshoreCost = offshoreCost;
	}
	public String getUomName() {
		return uomName;
	}
	public void setUomName(String uomName) {
		this.uomName = uomName;
	}
	public BigDecimal getCost() {
		return cost;
	}
	public void setCost(BigDecimal cost) {
		this.cost = cost;
	}
	public BigDecimal getMargin() {
		return margin;
	}
	public void setMargin(BigDecimal margin) {
		this.margin = margin;
	}	
	public BigDecimal getTotalContractValue() {
		return totalContractValue;
	}
	public void setTotalContractValue(BigDecimal totalContractValue) {
		this.totalContractValue = totalContractValue;
	}	
	public Integer getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}
	public Integer getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
//		public String getProjectManager() {
//		return projectManager;
//	}
//	public void setProjectManager(String projectManager) {
//		this.projectManager = projectManager;
//	}
//	public String getProjectMsa() {
//		return projectMsa;
//	}
//	public void setProjectMsa(String projectMsa) {
//		this.projectMsa = projectMsa;
//	}
//	public String getRmProjectId() {
//		return rmProjectId;
//	}
//	public void setRmProjectId(String rmProjectId) {
//		this.rmProjectId = rmProjectId;
//	}
	
	@Transient
	public String getCurrencySign() {
		return currencySign;
	}
	public void setCurrencySign(String currencySign) {
		this.currencySign = currencySign;
	}
	
	@Transient
	public Integer getSowRolesCount() {
		return sowRolesCount;
	}
	public void setSowRolesCount(Integer sowRolesCount) {
		this.sowRolesCount = sowRolesCount;
	}
	
	public String getDaysInMonth() {
		return daysInMonth;
	}
	public void setDaysInMonth(String daysInMonth) {
		this.daysInMonth = daysInMonth;
	}
	
	
	public Integer getOpportunityId() {
		return opportunityId;
	}
	public void setOpportunityId(Integer opportunityId) {
		this.opportunityId = opportunityId;
	}
	
	/**
	 * @return the isowId
	 */
	public Integer getIsowId() {
		return isowId;
	}
	/**
	 * @param isowId the isowId to set
	 */
	public void setIsowId(Integer isowId) {
		this.isowId = isowId;
	}
	/**
	 * @return the isowNo
	 */
	public String getIsowNo() {
		return isowNo;
	}
	/**
	 * @param isowNo the isowNo to set
	 */
	public void setIsowNo(String isowNo) {
		this.isowNo = isowNo;
	}
	public Sow() {
	}
	public Sow(Integer sowId, String sowNo, Date sowStartDate, Date sowEndDate, Integer projectId,
			String projectName, String projectType, String status, 
			Date createdDate, Date modifiedDate, String comments, String clientPo,
			Integer uomId, Integer currencyId, String currencySign, String uomName, Integer documentTypeId, String docPath,
			BigDecimal flatDiscountPer,String externalSowNo,BigDecimal revenue, 
			BigDecimal onshoreRevenue, BigDecimal offshoreRevenue, BigDecimal onshoreCost, BigDecimal offshoreCost, BigDecimal cost, BigDecimal margin,
			Integer sowRolesCount, Integer createdBy,Integer modifiedBy, String daysInMonth, BigDecimal totalContractValue,
			Integer opportunityId, Integer isowId, String isowNo) {
		this.sowId = sowId;
		this.sowNo = sowNo;
		this.sowStartDate = sowStartDate;
		this.sowEndDate = sowEndDate;
		this.projectId = projectId;
		this.projectName = projectName;
		this.projectType = projectType;
		this.status = status;
		this.createdDate = createdDate;
		this.modifiedDate = modifiedDate;
		this.comments = comments;
		this.clientPo = clientPo;
		this.uomId = uomId;
		this.currencyId = currencyId;
		this.currencySign = currencySign;
		this.uomName = uomName;
		
		this.sowRolesCount = sowRolesCount;
		
		this.documentTypeId = documentTypeId;
		this.docPath = docPath;
		this.flatDiscountPer = flatDiscountPer;
		this.externalSowNo = externalSowNo;
		this.revenue = revenue;
		this.onshoreRevenue = onshoreRevenue;
		this.offshoreRevenue = offshoreRevenue;
		this.onshoreCost = onshoreCost;
		this.offshoreCost = offshoreCost;
		this.cost = cost;
		this.margin = margin;
		this.createdBy=createdBy;
		this.modifiedBy=modifiedBy;
		this.daysInMonth = daysInMonth;
		this.totalContractValue = totalContractValue;
		this.opportunityId = opportunityId;
		this.isowId = isowId;
		this.isowNo = isowNo;
		
	}
	@Override
	public String toString() {
		return "Sow [sowId=" + sowId + ", sowNo=" + sowNo + ", sowStartDate=" + sowStartDate + ", sowEndDate="
				+ sowEndDate + ", projectId=" + projectId + ", projectName=" + projectName + ", projectType="
				+ projectType + ", status=" + status + ", clientPo=" + clientPo + ", comments=" + comments
				+ ", uomId=" + uomId + ", currencyId=" + currencyId
				+ ", currencySign=" + currencySign + ", uomName=" + uomName + ", documentTypeId=" + documentTypeId + ", docPath=" + docPath
				+ ", flatDiscountPer=" + flatDiscountPer + ", externalSowNo=" + externalSowNo + ", revenue="
				+ revenue + ", onshoreRevenue=" + onshoreRevenue + ", offshoreRevenue=" + offshoreRevenue + " , onshoreCost=" + onshoreCost + ", offshoreCost=" + offshoreCost + ", cost=" + cost + ", margin=" + margin + ", createdBy=" + createdBy + ", modifiedBy=" + modifiedBy + ", createdDate="
				+ createdDate + ", modifiedDate=" + modifiedDate + " , totalContractValue=" + totalContractValue +", opportunityId="+opportunityId+ "]";
	}
	
	
	
	
}
