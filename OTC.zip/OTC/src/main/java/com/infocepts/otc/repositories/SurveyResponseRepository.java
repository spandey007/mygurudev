package com.infocepts.otc.repositories;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import com.infocepts.otc.entities.SurveyResponse;

public interface SurveyResponseRepository extends CrudRepository<SurveyResponse,Integer>{

	@Override
	public List<SurveyResponse> findAll();	
		
	//@Query("from <ModuleName> where column1 = :column1")
	//public <ModuleName> find<ModuleName>ByColumn1(@Param(value = "column1") Integer column1);
	
}
