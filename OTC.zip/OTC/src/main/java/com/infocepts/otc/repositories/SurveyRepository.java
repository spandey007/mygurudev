/**
* Filename: /src/main/java/com/infocepts/otc/repositories/SurveyRepository.java
* @author  Anjali S. Kalbande
* @version 1.0
* @since   2019-06-03 
*/
package com.infocepts.otc.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.infocepts.otc.entities.Survey;

public interface SurveyRepository extends JpaRepository<Survey,Integer>{

	@Override
	public List<Survey> findAll();	
		
	@Query("from Survey where surveyId = :surveyId")
	public Survey findSurveyBySurveyId(@Param(value = "surveyId") Integer surveyId);
	
}
