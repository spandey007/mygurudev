package com.infocepts.otc.entities;

import java.util.Date;


import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.infocepts.otc.utilities.LoadConstant;

@SqlResultSetMapping(
		name = "get_info_traveller",
	      classes = {
	          @ConstructorResult(
	              targetClass = InfoTraveller.class,
	              columns = {
	            	//normal cols
	            		//normal cols
	            		  @ColumnResult(name = "uid"),
		                  @ColumnResult(name = "givenName", type=String.class),
		                  @ColumnResult(name = "surname", type=String.class),
		                  @ColumnResult(name = "dob", type=Date.class),
		                  @ColumnResult(name = "gender", type=String.class),
		                  @ColumnResult(name = "mobileOrigin", type=String.class),
		                  @ColumnResult(name = "mobileDestination", type=String.class),
		                  @ColumnResult(name = "passportNo", type=String.class),
		                  @ColumnResult(name = "nationality", type=String.class),		                  
		                  @ColumnResult(name = "empId"),
		                  @ColumnResult(name = "seat", type=String.class),
		                  @ColumnResult(name = "email", type=String.class),
		                  @ColumnResult(name = "alternateEmail", type=String.class),
		                  @ColumnResult(name = "meal", type=String.class),
		                  @ColumnResult(name = "frequentFlyerNo", type=String.class),
		                  @ColumnResult(name = "airline", type=String.class),
		                  @ColumnResult(name = "createdBy"),
		                  @ColumnResult(name = "createdDate", type=Date.class),
		                  @ColumnResult(name = "modifiedBy"),
		                  @ColumnResult(name = "modifiedDate", type=Date.class)
	                  }
	          )
	      }
	)
@NamedNativeQueries({
	   @NamedNativeQuery(
			   
			  
              
	            name    =   "getInfoTravel",
	            query   =   " SELECT * FROM " + LoadConstant.otc + ".[dbo].[infoTraveller]" + 
	            			"  where infoTravelId=:infoTravelId",
	                       resultClass=InfoTravel.class, resultSetMapping = "get_info_traveller"                       		
	    )
})

@Entity
@Table(catalog=LoadConstant.otc, schema="[dbo]",name="infoTraveller")
public class InfoTraveller {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer infoTravellerId;
	
	@ManyToOne
	@JoinColumn(name="infoTravelId")
	private InfoTravel infoTravel;

	private Integer uid;
	private String givenName;
	private String surname;
	private Date dob;
	private String gender;
	private String mobileOrigin;
	private String mobileDestination;
	private String passportNo;
	private String nationality;
	private Integer empId;
	private String seat;
	private String email;
	private String alternateEmail;
	private String meal;
	private String frequentFlyerNo;
	private String airline;
	private Date createdDate;
	private Integer modifiedBy;
	private Date modifiedDate;
	
	
	//getter setter
	
	
	public Integer getInfoTravellerId() {
		return infoTravellerId;
	}
	public void setInfoTravellerId(Integer infoTravellerId) {
		this.infoTravellerId = infoTravellerId;
	}
	public InfoTravel getInfoTravel() {
		return infoTravel;
	}
	public void setInfoTravel(InfoTravel infoTravel) {
		this.infoTravel = infoTravel;
	}
	public Integer getUid() {
		return uid;
	}
	public void setUid(Integer uid) {
		this.uid = uid;
	}
	public String getGivenName() {
		return givenName;
	}
	public void setGivenName(String givenName) {
		this.givenName = givenName;
	}
	public String getSurname() {
		return surname;
	}
	public void setSurname(String surname) {
		this.surname = surname;
	}
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getMobileOrigin() {
		return mobileOrigin;
	}
	public void setMobileOrigin(String mobileOrigin) {
		this.mobileOrigin = mobileOrigin;
	}
	public String getMobileDestination() {
		return mobileDestination;
	}
	public void setMobileDestination(String mobileDestination) {
		this.mobileDestination = mobileDestination;
	}
	public String getPassportNo() {
		return passportNo;
	}
	public void setPassportNo(String passportNo) {
		this.passportNo = passportNo;
	}
	public String getNationality() {
		return nationality;
	}
	public void setNationality(String nationality) {
		this.nationality = nationality;
	}
	public Integer getEmpId() {
		return empId;
	}
	public void setEmpId(Integer empId) {
		this.empId = empId;
	}
	public String getSeat() {
		return seat;
	}
	public void setSeat(String seat) {
		this.seat = seat;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	public String getAlternateEmail() {
		return alternateEmail;
	}
	public void setAlternateEmail(String alternateEmail) {
		this.alternateEmail = alternateEmail;
	}
	public String getMeal() {
		return meal;
	}
	public void setMeal(String meal) {
		this.meal = meal;
	}
	public String getFrequentFlyerNo() {
		return frequentFlyerNo;
	}
	public void setFrequentFlyerNo(String frequentFlyerNo) {
		this.frequentFlyerNo = frequentFlyerNo;
	}
	public String getAirline() {
		return airline;
	}
	public void setAirline(String airline) {
		this.airline = airline;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public Integer getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public Date getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	
	
	
	// CONSTRUCTOR
	
	public InfoTraveller(Integer infoTravellerId, InfoTravel infoTravel, Integer uid, String givenName, String surname,
			Date dob, String gender, String mobileOrigin, String mobileDestination, String passportNo,
			String nationality, Integer empId, String seat, String email,String alternateEmail, String meal, String frequentFlyerNo,
			String airline, Date createdDate, Integer modifiedBy, Date modifiedDate) {
		this.infoTravellerId = infoTravellerId;
		this.infoTravel = infoTravel;
		this.uid = uid;
		this.givenName = givenName;
		this.surname = surname;
		this.dob = dob;
		this.gender = gender;
		this.mobileOrigin = mobileOrigin;
		this.mobileDestination = mobileDestination;
		this.passportNo = passportNo;
		this.nationality = nationality;
		this.empId = empId;
		this.seat = seat;
		this.email = email;
		this.alternateEmail = alternateEmail;
		this.meal = meal;
		this.frequentFlyerNo = frequentFlyerNo;
		this.airline = airline;
		this.createdDate = createdDate;
		this.modifiedBy = modifiedBy;
		this.modifiedDate = modifiedDate;
	}
	public InfoTraveller() {
		// TODO Auto-generated constructor stub
	}
	
	
	
	
}
