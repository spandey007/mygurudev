/**
* Filename: /src/main/java/com/infocepts/otc/controllers/DeMsrController.java
* @author  SHRI
* @version 1.0
* @since   2018-11-28 
*/

package com.infocepts.otc.controllers;

import java.util.logging.Logger;
import com.infocepts.otc.entities.DeGovernance;
import com.infocepts.otc.entities.DeMsr;
import com.infocepts.otc.entities.ISow;
import com.infocepts.otc.repositories.DeMsrRepository;
import com.infocepts.otc.utilities.DateConverter;
import com.infocepts.otc.utilities.ExportUtil;
import com.infocepts.otc.services.TimesheetService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.mail.MessagingException;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.io.File;
import java.io.FileNotFoundException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

@RestController
@RequestMapping(value="/demsr",headers="referer")
public class DeMsrController {

    final Logger logger = Logger.getLogger(DeMsrController.class.getName());

    @Autowired
    DeMsrRepository deMsrRepository;
    
    @Autowired
    HttpSession session;

    @PersistenceContext(unitName = "otc") 
    private EntityManager manager;
			
	@Autowired
	ExportUtil exportUtil;
	
	@Autowired
	TimesheetService service;
	String path=null;
	String filepath="";
	String filepath1="";
	String filepath2="";
	String filepath3="";
	String filepath4="";
	
    @RequestMapping(method = RequestMethod.GET)
    public List<DeMsr> findAll(@RequestParam(value = "view", defaultValue = "0") String view
			,@RequestParam(value = "monthYear", defaultValue = "0") String monthYear,
    		@RequestParam(value = "projectId", defaultValue = "0") Integer projectId,HttpServletRequest request) throws MessagingException{
         List<DeMsr> DeMsrList = null;
         Integer loggedInUid = (Integer) session.getAttribute("loggedInUid");
		 int month = 0;
		 int year = 0;
		 boolean isDEMember = false;
		 boolean isPMOMember = false;
		 
		 //Get the user roles
		 String userRoles = session.getAttribute("userRoles") != null ? session.getAttribute("userRoles").toString() : "";
		 int uid = session.getAttribute("loggedInUid") != null ? Integer.valueOf(session.getAttribute("loggedInUid").toString()) : 0;
		 if(userRoles.toLowerCase().contains("de")) isDEMember = true;
		 if(userRoles.toLowerCase().contains("pmo")) isPMOMember = true;
		 
        try {
			/* ------------------------- Authorization ends ------------------------------------ */
   		 if(!monthYear.equals("") && monthYear.contains("-")) { month = Integer.valueOf(monthYear.split("-")[0]); year = Integer.valueOf(monthYear.split("-")[1]); }

	   		 if( (view.equals("de") && isDEMember) || (view.equals("pmo") && isPMOMember) || (view.equals("dh") && uid == 512)){
	    		
	   			 if(projectId != 0) {
	   				DeMsrList = deMsrRepository.findByProjectId(projectId);
	   			 }else{
	 	   			DeMsrList = manager.createNamedQuery("getAllDeMsrData", DeMsr.class)
			 				.setParameter("uid", uid)
		    				.setParameter("view", view)
			 				.setParameter("month", month)
			 				.setParameter("year", year)
			 				.getResultList();
	   				 
	   			 }
	        }else if(view.equals("pm") || view.equals("ph") || view.equals("cep")){
	   			 if(projectId != 0) {
	   				DeMsrList = deMsrRepository.findByProjectId(projectId);
	   			 }else{
		        		DeMsrList = manager.createNamedQuery("getAllDeMsrData", DeMsr.class)
				 				.setParameter("uid", uid)
		        				.setParameter("view", view)
				 				.setParameter("month", month)
				 				.setParameter("year", year)
				 				.getResultList();	   				 
	   			 }
		 	}

         } 
		catch (Exception e){
			e.printStackTrace();
			 logger.info(String.format("exception - ", e));
        }
        
        return DeMsrList;

    }
    
    /**
     * This method is add row in moduleName entity
     * 
     */
    @RequestMapping(method=RequestMethod.POST)
	public DeMsr addDeMsr(@RequestBody DeMsr deMsr, HttpServletRequest request) {
		// Authorization for XYZ role
			try{
				deMsr.setDeMsrId(null);
				deMsrRepository.save(deMsr);
				service.sendMsrNotification(deMsr, "add", request);

			}
			catch(Exception e){
				 logger.info(String.format("exception - ", e));
			}
		
		return deMsr;
	}
    
    
	@RequestMapping(value="/upload/{deMsrId}",method=RequestMethod.POST,consumes = {"multipart/form-data"})
    @ResponseBody
	public String uploadFile(@RequestPart("file") MultipartFile file,@PathVariable(value = "deMsrId") Integer deMsrId,HttpServletRequest request)
	{
		DeMsr deMsr = deMsrRepository.findOne(deMsrId);

		String type = "demsr";
		path=exportUtil.getDeFilePath(file,request,deMsrId,type);		

				deMsr.setFilepath(path);

		deMsrRepository.save(deMsr);
		return path;
	}
	
	@RequestMapping(value="/download/{deMsrId}",method=RequestMethod.GET)
	public void download(@PathVariable(value = "deMsrId") Integer deMsrId,HttpServletRequest request,HttpServletResponse response) throws ServletException, Exception {
		String path=null;
		File home=exportUtil.checkPath(request);
		String separator=File.separator;
		String Filepath = "";
		path=home.getPath();
		
		DeMsr deMsr =deMsrRepository.findOne(deMsrId);

	
			Filepath = deMsr.getFilepath();
	
		List<String> list = Arrays.asList(Filepath.split("\\s*,\\s*"));
	
		if(list.size() > 1){
		
			if (home.exists() && home.isDirectory()) {
				 logger.info("home is a directory");
				    if(path.equals(separator)){
					 	path="usr"+File.separator+"home"+File.separator+"Download";
					}
					else{
						path=File.separator+"usr"+File.separator+"home"+File.separator+"Download";
					}
				
					if (Files.isDirectory(Paths.get(home + path))) {
						if(path.equals(separator)){
							path="usr"+File.separator+"home"+File.separator+"Download"+File.separator+"infotravel";
						}
						else{
							path=File.separator+"usr"+File.separator+"home"+File.separator+"Download"+File.separator+"infotravel";
						}
						
						if (Files.isDirectory(Paths.get(home + path))) {
							if(path.equals(separator)){
								path="usr"+File.separator+"home"+File.separator+"Download"+File.separator+"infotravel"+File.separator;
							}
							else{
								path=File.separator+"usr"+File.separator+"home"+File.separator+"Download"+File.separator+"infotravel"+File.separator;
							}
							
						} 
					}
				
			}
			
			
		}
		else{
			try{
				File outputFile = new File(Filepath);
				Path file = Paths.get(outputFile+"");
			    response.addHeader("Content-Disposition", "attachment; filename="+file.getFileName());
			    Files.copy(file, response.getOutputStream());
			    response.getOutputStream().flush();
			}
			catch(FileNotFoundException fe){
				fe.printStackTrace();
			}
		}
	}
	
	
//    
    /**
     * This method is update row in moduleName entity
     * based on primaryKey Of Module Table 
     */
	
    @RequestMapping(value="/{deMsrId}",method=RequestMethod.PUT)
	 public DeMsr updateDeMsr(@RequestBody DeMsr deMsr,@PathVariable Integer deMsrId,HttpServletRequest request){
	
			try{
				 deMsr.setDeMsrId(deMsrId);
				 deMsrRepository.save(deMsr);
			}
			catch(Exception e){
				 logger.info(String.format("exception - ", e));
			}
		 return deMsr;
	 }
    
    /**
     * This method is get data for specific row in moduleName entity
     * based on primaryKey Of Module Table 
     */
 
    
		 @RequestMapping(value="/{deMsrId}",method=RequestMethod.GET)
		 public DeMsr getDeMsrId(@PathVariable Integer deMsrId){
			 DeMsr deMsr = null;

				 if(deMsrId != 0){
					 deMsr = deMsrRepository.findOne(deMsrId);
				 }

			 return deMsr;
		 }
	   
    
    /**
     * This method is delete data for specific row in moduleName entity
     * based on primaryKey Of Module Table 
     */	 
		@RequestMapping(value= "/{deMsrId}",method=RequestMethod.DELETE)
		public void deleteDeMsr(@PathVariable Integer deMsrId, HttpServletRequest request) {
				try{
					if(deMsrId!=null) {
						DeMsr deMsr = deMsrRepository.findOne(deMsrId);
						service.sendMsrNotification(deMsr, "delete", request);
						deMsrRepository.delete(deMsrId);						
					}
				}
				catch(Exception e){
					 logger.info(String.format("exception - ", e));
				}
		}
	
  
   
}
