package com.infocepts.pms.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.infocepts.otc.utilities.LoadConstant;
import com.infocepts.pms.entities.PmsDepartmentMapping;


public interface PmsDepartmentMappingRepository extends CrudRepository<PmsDepartmentMapping,Integer>{

	@Override
	public List<PmsDepartmentMapping> findAll();
	
	@Query("from PmsDepartmentMapping where typeId = :typeId and type = :type")
	public List<PmsDepartmentMapping> findByTypeId(@Param("typeId") Integer typeId,@Param("type") Integer type);
	
	@Transactional
	@Modifying
	@Query(value = "DELETE FROM "+LoadConstant.pms+".dbo.DepartmentMapping WHERE typeId=:typeId and type = :type", nativeQuery = true)
	public void deleteDepartmentMapping(@Param("typeId") Integer typeId, @Param("type") Integer type);
	

	
}
