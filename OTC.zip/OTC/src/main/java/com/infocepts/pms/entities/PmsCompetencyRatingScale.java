/**
* Filename: /src/main/java/com/infocepts/pms/entities/PmsGoalCluster.java
* @author  SRA
* @version 1.0
* @since   2018-11-13  
*/
package com.infocepts.pms.entities;

import java.util.Date;
import javax.persistence.*;
import javax.validation.constraints.NotNull;

import com.infocepts.otc.utilities.LoadConstant;
@Entity
@Table(catalog=LoadConstant.pms, schema="[dbo]", name="competencyRatingScale")

@SqlResultSetMappings({
        @SqlResultSetMapping(
                name = "competency_rating_scale_details",
                classes = {
                        @ConstructorResult(
                                targetClass = PmsCompetencyRatingScale.class,
                                columns = {
                                		@ColumnResult(name = "competencyRatingScaleId"),
                                		@ColumnResult(name = "ratingName", type = String.class),
										@ColumnResult(name = "ratingScale", type = String.class),
                                        @ColumnResult(name = "description", type = String.class),                                                                               							
										@ColumnResult(name = "createdBy"),
                                        @ColumnResult(name = "createdDate", type = Date.class),
										@ColumnResult(name = "modifiedBy"),
                                        @ColumnResult(name = "modifiedDate", type = Date.class),                                        
                                }
                        )
                }
        )
})
@NamedNativeQueries({
        @NamedNativeQuery(
                name    =   "getAllCompetencyRatingScales",   
                query 	=    "Select crs.* from " + LoadConstant.pms + ".[dbo].competencyRatingScale as crs", 
							resultClass=PmsCompetencyRatingScale.class, resultSetMapping = "competency_rating_scale_details"
        ),
        @NamedNativeQuery(
                name    =   "getCompetencyRatingScaleById",   
                query 	=    "Select crs.* from " + LoadConstant.pms + ".[dbo].competencyRatingScale as crs"+
                			" where competencyRatingScaleId = :competencyRatingScaleId",
							resultClass=PmsCompetencyRatingScale.class, resultSetMapping = "competency_rating_scale_details"
        )
})
public class PmsCompetencyRatingScale {

	// Entity Columns
    // --------------------------------------------------------------------------------
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Integer competencyRatingScaleId; 
	
    @NotNull
    private String ratingName;
    @NotNull
    private String ratingScale;
    private String description;    
   	
    // Audit Trail columns 
    // --------------------------------------------------------------------------------
	private Integer createdBy;    
    private Date createdDate;
    private Integer modifiedBy;
    private Date modifiedDate;
   
    // Getter setter
	// --------------------------------------------------------------------------------
  

	public Integer getcompetencyRatingScaleId() {
		return competencyRatingScaleId;
	}

	public void setcompetencyRatingScaleId(Integer competencyRatingScaleId) {
		this.competencyRatingScaleId = competencyRatingScaleId;
	}

	public String getRatingName() {
		return ratingName;
	}

	public void setRatingName(String ratingName) {
		this.ratingName = ratingName;
	}

	public String getRatingScale() {
		return ratingScale;
	}

	public void setRatingScale(String ratingScale) {
		this.ratingScale = ratingScale;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Integer getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Integer getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	// Constructor
	// ---------------------------------------------------------------------------------
	public PmsCompetencyRatingScale() {
		//super();
		// TODO Auto-generated constructor stub
	}
	
	public PmsCompetencyRatingScale(Integer competencyRatingScaleId, String ratingName, String ratingScale, String description, 
			Integer createdBy, Date createdDate, Integer modifiedBy, Date modifiedDate) {
		
		this.competencyRatingScaleId = competencyRatingScaleId;
		this.ratingName = ratingName;
		this.ratingScale = ratingScale;
		this.description = description;
		this.createdBy = createdBy;
		this.createdDate = createdDate;
		this.modifiedBy = modifiedBy;
		this.modifiedDate = modifiedDate;
	}

	
		
   
   



    
    

}
