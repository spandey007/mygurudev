/**
* Filename: /src/main/java/com/infocepts/pms/repositories/PmsPerformanceRepository.java
* @author  SRA
* @version 1.0
* @since   2018-12-07
*/
package com.infocepts.pms.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.infocepts.pms.entities.PmsPerformance;

public interface PmsPerformanceRepository extends CrudRepository<PmsPerformance,Integer>{

	@Override
	public List<PmsPerformance> findAll();	
		
	@Query("from PmsPerformance where uid = :uid and cycleId = :cycleId")
	public PmsPerformance findPmsPerformanceByUidandCycle(@Param(value = "uid") Integer uid,@Param(value = "cycleId") Integer cycleId);
	
}
