/**
* Filename: /src/main/java/com/infocepts/pms/repositories/PmsCategoryRepository.java
* @author  RKJ
* @version 1.0
* @since   2018-10-30 
*/
package com.infocepts.pms.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import com.infocepts.pms.entities.PmsCategory;

public interface PmsCategoryRepository extends CrudRepository<PmsCategory,Integer>{

	@Override
	public List<PmsCategory> findAll();
}
