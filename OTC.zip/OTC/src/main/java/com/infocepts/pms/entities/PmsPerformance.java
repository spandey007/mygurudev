/**
* Filename: /src/main/java/com/infocepts/pms/entities/PmsPerformance.java
* @author  SRA
* @version 1.0
* @since   2018-12-07
*/
package com.infocepts.pms.entities;

import java.util.Date;
import javax.persistence.*;
import javax.validation.constraints.NotNull;

import com.infocepts.otc.utilities.LoadConstant;
@Entity
@Table(catalog=LoadConstant.pms, schema="[dbo]", name="performance")

@SqlResultSetMappings({
        @SqlResultSetMapping(
                name = "performance_list",
                classes = {
                        @ConstructorResult(
                                targetClass = PmsPerformance.class,
                                columns = {
                                		@ColumnResult(name = "performanceId"),
										@ColumnResult(name = "uid"),
                                        @ColumnResult(name = "managersUid"),   
                                        @ColumnResult(name = "reviewersUid"),                                        
                                        @ColumnResult(name = "startDateWithManager", type = Date.class),   
                                        @ColumnResult(name = "endDateWithManager", type = Date.class),  
                                        /*********FK************************************************/                                        
                                        @ColumnResult(name = "cycleId"),   
                                        /*********Goal Columns**************************************/
                                        @ColumnResult(name = "selfRatingGoals", type = String.class),   
                                        @ColumnResult(name = "managersRatingGoals", type = String.class),   
                                        @ColumnResult(name = "managersCommentsGoals", type = String.class), 
                                        @ColumnResult(name = "reviewersCommentsGoals", type = String.class),
                                        /*********Competency Columns********************************/
                                        @ColumnResult(name = "selfRatingCompetency", type = String.class),   
                                        @ColumnResult(name = "managersRatingCompetency", type = String.class),   
                                        @ColumnResult(name = "managersCommentsCompetency", type = String.class),   
                                        @ColumnResult(name = "reviewersCommentsCompetency", type = String.class),   
                                        /*********Form Status Columns********************************/
                                        @ColumnResult(name = "formStatusGoalsetting"),   
                                        @ColumnResult(name = "formStatusPitstop"),   
                                        @ColumnResult(name = "formStatusEvaluation"), 
                                        /*********Other Columns********************************/
                                        @ColumnResult(name = "selfOverallRating", type = String.class),   
                                        @ColumnResult(name = "managersOverallRating", type = String.class),   
                                        @ColumnResult(name = "normalizedRating", type = String.class),                                         
                                        @ColumnResult(name = "improvementAreas", type = String.class),
                                        @ColumnResult(name = "reviewersImprovementAreas", type = String.class),
                                        /*********Audit Trail Columns********************************/
										@ColumnResult(name = "createdBy"),
                                        @ColumnResult(name = "createdDate", type = Date.class),
										@ColumnResult(name = "modifiedBy"),
                                        @ColumnResult(name = "modifiedDate", type = Date.class),
					            		
                                }
                        )
                }
        )
})
@NamedNativeQueries({
        @NamedNativeQuery(
                name    =   "getAllPerformance",   
                query 	=   "Select p.*"+
							" from " + LoadConstant.pms + ".[dbo].performance as p",							 
							resultClass=PmsPerformance.class, resultSetMapping = "performance_list"
        ),
		@NamedNativeQuery(
                name    =   "getPerformanceByCycle",   
                query 	=   "Select p.*"+
							" from " + LoadConstant.pms + ".[dbo].performance as p"+
							" where p.cycleId = :cycleId",							 
							resultClass=PmsPerformance.class, resultSetMapping = "performance_list"
        ) ,
		@NamedNativeQuery(
                name    =   "getPerformanceByCycleAndUid",   
                query 	=   "Select p.*"+
							" from " + LoadConstant.pms + ".[dbo].performance as p"+
							" where p.cycleId = :cycleId and p.uid = :uid",							 
							resultClass=PmsPerformance.class, resultSetMapping = "performance_list"
        )  ,
		@NamedNativeQuery(
                name    =   "getPerformanceById",   
                query 	=   "Select p.*"+
							" from " + LoadConstant.pms + ".[dbo].performance as p"+
							" where p.performanceId = :performanceId ",							 
							resultClass=PmsPerformance.class, resultSetMapping = "performance_list"
        )		
})
public class PmsPerformance {

	// Entity Columns
    // --------------------------------------------------------------------------------
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Integer performanceId; 
	
    @NotNull
    private Integer uid;
	@NotNull
    private Integer managersUid;    
	@NotNull
    private Integer reviewersUid; 
	
	private Date startDateWithManager;
	private Date endDateWithManager;
	
	/*********FK************************************************/
	@NotNull
	@ManyToOne
	@JoinColumn(name="cycleId")
	private PmsCycle cycle;
	
	/*********Goal Columns**************************************/
	private String selfRatingGoals; // 0-5 or A-E
	private String managersRatingGoals;	
	@Lob
	private String managersCommentsGoals;
	@Lob
	private String reviewersCommentsGoals;
	
	/*********Competency Columns********************************/
	private String selfRatingCompetency;
	private String managersRatingCompetency;
	@Lob
	private String managersCommentsCompetency;
	@Lob
	private String reviewersCommentsCompetency;	
	
	/*********Form Status Columns********************************/
	private Integer formStatusGoalsetting; 
	private Integer formStatusPitstop;
	private Integer formStatusEvaluation;
	
	/*********Other Columns********************************/
	private String selfOverallRating;
	private String managersOverallRating;
	private String normalizedRating;
	@Lob
	private String improvementAreas;
	@Lob
	private String reviewersImprovementAreas;

    // Audit Trail columns 
    // --------------------------------------------------------------------------------
	private Integer createdBy;    
    private Date createdDate;
    private Integer modifiedBy;
    private Date modifiedDate;
   
    // Getter setter
	// --------------------------------------------------------------------------------	
	public Integer getPerformanceId() {
		return performanceId;
	}
	public void setPerformanceId(Integer performanceId) {
		this.performanceId = performanceId;
	}
	public Integer getUid() {
		return uid;
	}
	public void setUid(Integer uid) {
		this.uid = uid;
	}
	public Integer getManagersUid() {
		return managersUid;
	}
	public void setManagersUid(Integer managersUid) {
		this.managersUid = managersUid;
	}
	public Integer getReviewersUid() {
		return reviewersUid;
	}
	public void setReviewersUid(Integer reviewersUid) {
		this.reviewersUid = reviewersUid;
	}
	public Date getStartDateWithManager() {
		return startDateWithManager;
	}
	public void setStartDateWithManager(Date startDateWithManager) {
		this.startDateWithManager = startDateWithManager;
	}
	public Date getEndDateWithManager() {
		return endDateWithManager;
	}
	public void setEndDateWithManager(Date endDateWithManager) {
		this.endDateWithManager = endDateWithManager;
	}
	public PmsCycle getCycle() {
		return cycle;
	}
	public void setCycle(PmsCycle cycle) {
		this.cycle = cycle;
	}
	public String getSelfRatingGoals() {
		return selfRatingGoals;
	}
	public void setSelfRatingGoals(String selfRatingGoals) {
		this.selfRatingGoals = selfRatingGoals;
	}
	public String getManagersRatingGoals() {
		return managersRatingGoals;
	}
	public void setManagersRatingGoals(String managersRatingGoals) {
		this.managersRatingGoals = managersRatingGoals;
	}
	public String getManagersCommentsGoals() {
		return managersCommentsGoals;
	}
	public void setManagersCommentsGoals(String managersCommentsGoals) {
		this.managersCommentsGoals = managersCommentsGoals;
	}
	public String getReviewersCommentsGoals() {
		return reviewersCommentsGoals;
	}
	public void setReviewersCommentsGoals(String reviewersCommentsGoals) {
		this.reviewersCommentsGoals = reviewersCommentsGoals;
	}
	public String getSelfRatingCompetency() {
		return selfRatingCompetency;
	}
	public void setSelfRatingCompetency(String selfRatingCompetency) {
		this.selfRatingCompetency = selfRatingCompetency;
	}
	public String getManagersRatingCompetency() {
		return managersRatingCompetency;
	}
	public void setManagersRatingCompetency(String managersRatingCompetency) {
		this.managersRatingCompetency = managersRatingCompetency;
	}
	public String getManagersCommentsCompetency() {
		return managersCommentsCompetency;
	}
	public void setManagersCommentsCompetency(String managersCommentsCompetency) {
		this.managersCommentsCompetency = managersCommentsCompetency;
	}
	public String getReviewersCommentsCompetency() {
		return reviewersCommentsCompetency;
	}
	public void setReviewersCommentsCompetency(String reviewersCommentsCompetency) {
		this.reviewersCommentsCompetency = reviewersCommentsCompetency;
	}
	public Integer getFormStatusGoalsetting() {
		return formStatusGoalsetting;
	}
	public void setFormStatusGoalsetting(Integer formStatusGoalsetting) {
		this.formStatusGoalsetting = formStatusGoalsetting;
	}
	public Integer getFormStatusPitstop() {
		return formStatusPitstop;
	}
	public void setFormStatusPitstop(Integer formStatusPitstop) {
		this.formStatusPitstop = formStatusPitstop;
	}
	public Integer getFormStatusEvaluation() {
		return formStatusEvaluation;
	}
	public void setFormStatusEvaluation(Integer formStatusEvaluation) {
		this.formStatusEvaluation = formStatusEvaluation;
	}
	public String getSelfOverallRating() {
		return selfOverallRating;
	}
	public void setSelfOverallRating(String selfOverallRating) {
		this.selfOverallRating = selfOverallRating;
	}
	public String getManagersOverallRating() {
		return managersOverallRating;
	}
	public void setManagersOverallRating(String managersOverallRating) {
		this.managersOverallRating = managersOverallRating;
	}
	public String getNormalizedRating() {
		return normalizedRating;
	}
	public void setNormalizedRating(String normalizedRating) {
		this.normalizedRating = normalizedRating;
	}
	public String getImprovementAreas() {
		return improvementAreas;
	}
	public void setImprovementAreas(String improvementAreas) {
		this.improvementAreas = improvementAreas;
	}	
	public String getReviewersImprovementAreas() {
		return reviewersImprovementAreas;
	}
	public void setReviewersImprovementAreas(String reviewersImprovementAreas) {
		this.reviewersImprovementAreas = reviewersImprovementAreas;
	}
	public Integer getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public Integer getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public Date getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	
		
	// Constructor
	// ---------------------------------------------------------------------------------
	public PmsPerformance() {
		//super();
		
	}
	public PmsPerformance(
			Integer performanceId, 
			Integer uid,
			Integer managersUid,
			Integer reviewersUid,			
			Date startDateWithManager,
			Date endDateWithManager, 
			Integer cycleId,
			String selfRatingGoals,
			String managersRatingGoals,
			String managersCommentsGoals,
			String reviewersCommentsGoals,			
			String selfRatingCompetency,
			String managersRatingCompetency,
			String managersCommentsCompetency,
			String reviewersCommentsCompetency,
			Integer formStatusGoalsetting,
			Integer formStatusPitstop,
			Integer formStatusEvaluation,
			String selfOverallRating,
			String managersOverallRating,
			String normalizedRating,
			String improvementAreas,
			String reviewersImprovementAreas,
			Integer createdBy,
			Date createdDate,
			Integer modifiedBy,
			Date modifiedDate) {
		super();
		this.performanceId = performanceId;
		this.uid = uid;
		this.managersUid = managersUid;
		this.reviewersUid = reviewersUid;
		this.startDateWithManager = startDateWithManager;
		this.endDateWithManager = endDateWithManager;
		if(cycleId != null)
		{
			this.cycle = new PmsCycle();
			this.cycle.setCycleId(cycleId);			
		}		
		this.selfRatingGoals = selfRatingGoals;
		this.managersRatingGoals = managersRatingGoals;
		this.managersCommentsGoals = managersCommentsGoals;
		this.reviewersCommentsGoals = reviewersCommentsGoals;
		this.selfRatingCompetency = selfRatingCompetency;
		this.managersRatingCompetency = managersRatingCompetency;
		this.managersCommentsCompetency = managersCommentsCompetency;
		this.reviewersCommentsCompetency = reviewersCommentsCompetency;
		
		this.formStatusGoalsetting = formStatusGoalsetting;
		if(this.formStatusGoalsetting == null) this.formStatusGoalsetting = 0;
		
		this.formStatusPitstop = formStatusPitstop;
		if(this.formStatusPitstop == null) this.formStatusPitstop = 0;
		
		this.formStatusEvaluation = formStatusEvaluation;
		if(this.formStatusEvaluation == null) this.formStatusEvaluation = 0;
	
		this.selfOverallRating = selfOverallRating;
		this.managersOverallRating = managersOverallRating;
		this.normalizedRating = normalizedRating;
		this.improvementAreas = improvementAreas;
		this.reviewersImprovementAreas = reviewersImprovementAreas;
		this.createdBy = createdBy;
		this.createdDate = createdDate;
		this.modifiedBy = modifiedBy;
		this.modifiedDate = modifiedDate;
		
	}
	
    
   
   



    
    

}
