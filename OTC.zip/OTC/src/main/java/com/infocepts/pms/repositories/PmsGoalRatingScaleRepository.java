/**
* Filename: /src/main/java/com/infocepts/pms/repositories/PmsGoalRatingScaleRepository.java
* @author  SRA
* @version 1.0
* @since   2018-11-13 
*/
package com.infocepts.pms.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import com.infocepts.pms.entities.PmsGoalRatingScale;

public interface PmsGoalRatingScaleRepository extends CrudRepository<PmsGoalRatingScale,Integer>{

	@Override
	public List<PmsGoalRatingScale> findAll();	
		
	
	
}
