/**
* Filename: /src/main/java/com/infocepts/pms/entities/PmsCompetencyMaster.java
* @author  MEW
* @version 1.0
* @since   2018-11-01 
*/
package com.infocepts.pms.entities;

import java.util.Date;
import java.util.List;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

import com.infocepts.otc.utilities.LoadConstant;
@Entity
@Table(catalog=LoadConstant.pms, schema="[dbo]", name="competencyMaster")

@SqlResultSetMappings({
        @SqlResultSetMapping(
                name = "competency_master_details",
                classes = {
                        @ConstructorResult(
                                targetClass = PmsCompetencyMaster.class,
                                columns = {
                                		@ColumnResult(name = "competencyMasterId"),
										@ColumnResult(name = "competencyName"),										
										@ColumnResult(name = "competencyClusterId"),   
                                        @ColumnResult(name = "weightage"),
                                        @ColumnResult(name = "description", type = String.class),
										@ColumnResult(name = "createdBy"),
                                        @ColumnResult(name = "createdDate", type = Date.class),
										@ColumnResult(name = "modifiedBy"),
                                        @ColumnResult(name = "modifiedDate", type = Date.class), 
                                        @ColumnResult(name = "clusterName", type = String.class),
                                        @ColumnResult(name = "sequence"),
                                        @ColumnResult(name = "gradeNames", type = String.class),
                                        @ColumnResult(name = "departmentNames", type = String.class)
                                }
                        )
                }
        )
})
@NamedNativeQueries({
        @NamedNativeQuery(
                name    =   "getAllCompetencyMasters",   
                query 	=   "Select cm.*,cc.name as clusterName, "+	
            				" STUFF((Select ','+g.grade from grademapping gm  "+
            				" left join " + LoadConstant.infomaster + ".dbo.grade g on g.gradeId = gm.gradeId "+
            				" where gm.typeId =cm.competencyMasterId and gm.type = 4"+
            				" FOR XML PATH('')),1,1,'') as gradeNames, "+
							" STUFF((Select ','+dep.departmentName from departmentMapping dm "+
							" left join " + LoadConstant.infomaster + ".dbo.department dep on dep.departmentId = dm.departmentId "+
							" where dm.typeId =cm.competencyMasterId and dm.type = 4"+
							" FOR XML PATH('')),1,1,'') as departmentNames "+
							" from " + LoadConstant.pms + ".[dbo].competencyMaster as cm"+
							" LEFT JOIN " + LoadConstant.pms + ".[dbo].competencyCluster as cc on cc.competencyClusterId = cm.competencyClusterId ",
							
							resultClass=PmsCompetencyMaster.class, resultSetMapping = "competency_master_details"
        ),
        @NamedNativeQuery(
                name    =   "getCompetencyMastersByCluster",   
                query 	=   "Select cm.*,cc.name as clusterName "+		
                			", '' as gradeNames, '' as departmentNames "+
	                		" from " + LoadConstant.pms + ".[dbo].competencyMaster as cm"+
							" LEFT JOIN " + LoadConstant.pms + ".[dbo].competencyCluster as cc on cc.competencyClusterId = cm.competencyClusterId"+
							" where cm.competencyClusterId = :competencyClusterId", 
							resultClass=PmsCompetencyMaster.class, resultSetMapping = "competency_master_details"
        ) ,
        @NamedNativeQuery(
                name    =   "getCompetencyMasterById",   
                query 	=   "Select cm.*,cc.name as clusterName "+		
                			", '' as gradeNames, '' as departmentNames "+
	                		" from " + LoadConstant.pms + ".[dbo].competencyMaster as cm"+
							" LEFT JOIN " + LoadConstant.pms + ".[dbo].competencyCluster as cc on cc.competencyClusterId = cm.competencyClusterId"+
							" where cm.competencyMasterId = :competencyMasterId", 
							resultClass=PmsCompetencyMaster.class, resultSetMapping = "competency_master_details"
        ) 
})
public class PmsCompetencyMaster {

	// Entity Columns
    // --------------------------------------------------------------------------------
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Integer competencyMasterId; 
	
    @NotNull
    private String competencyName;
    
    @ManyToOne
   	@JoinColumn(name="competencyClusterId")
    private PmsCompetencyCluster pmsCompetencyCluster;
   
    private Integer weightage;	
    
    private Integer sequence; 
    
    @Lob
    private String description;
   
    // Audit Trail columns 
    // --------------------------------------------------------------------------------
	private Integer createdBy;    
    private Date createdDate;
    private Integer modifiedBy;
    private Date modifiedDate;
    
    // Transient Variables
    // -------------------------------------------------------------------------------
    @Transient
    private String clusterName;
    
    @Transient
    private List<PmsGradeMapping> gradeMapping;
    
    @Transient
    private List<PmsDepartmentMapping> departmentMapping;
    
    @Transient
    private String gradeNames;
    
    @Transient
    private String 	departmentNames;


    // Getter setter
	// --------------------------------------------------------------------------------

	public Integer getCompetencyMasterId() {
		return competencyMasterId;
	}

	public void setCompetencyMasterId(Integer competencyMasterId) {
		this.competencyMasterId = competencyMasterId;
	}

	public String getCompetencyName() {
		return competencyName;
	}

	public void setCompetencyName(String competencyName) {
		this.competencyName = competencyName;
	}

	public PmsCompetencyCluster getPmsCompetencyCluster() {
		return pmsCompetencyCluster;
	}

	public void setPmsCompetencyCluster(PmsCompetencyCluster pmsCompetencyCluster) {
		this.pmsCompetencyCluster = pmsCompetencyCluster;
	}

	public Integer getWeightage() {
		return weightage;
	}

	public void setWeightage(Integer weightage) {
		this.weightage = weightage;
	}

	public Integer getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Integer getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getClusterName() {
		return clusterName;
	}

	public void setClusterName(String clusterName) {
		this.clusterName = clusterName;
	}
	
	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	
	public Integer getSequence() {
		return sequence;
	}

	public void setSequence(Integer sequence) {
		this.sequence = sequence;
	}	
	
	public List<PmsGradeMapping> getGradeMapping() {
		return gradeMapping;
	}
	
	public void setGradeMapping(List<PmsGradeMapping> gradeMapping) {
		this.gradeMapping = gradeMapping;
	}
	
	public List<PmsDepartmentMapping> getDepartmentMapping() {
		return departmentMapping;
	}
	
	public void setDepartmentMapping(List<PmsDepartmentMapping> departmentMapping) {
		this.departmentMapping = departmentMapping;
	}
	
	public String getGradeNames() {
		return gradeNames;
	}

	public void setGradeNames(String gradeNames) {
		this.gradeNames = gradeNames;
	}

	public String getDepartmentNames() {
		return departmentNames;
	}

	public void setDepartmentNames(String departmentNames) {
		this.departmentNames = departmentNames;
	}
	

	// Constructor
	// ---------------------------------------------------------------------------------

	public PmsCompetencyMaster() {
		//super();
		// TODO Auto-generated constructor stub
	}
	
	public PmsCompetencyMaster(Integer competencyMasterId, String competencyName,
			Integer competencyClusterId, Integer weightage, String description,
			Integer createdBy, Date createdDate, Integer modifiedBy, Date modifiedDate, String clusterName,
			Integer sequence, String gradeNames, String departmentNames
	) {
		super();
		this.competencyMasterId = competencyMasterId;
		this.competencyName = competencyName;
		if(competencyClusterId != null)
		{
			this.pmsCompetencyCluster = new PmsCompetencyCluster();
			this.pmsCompetencyCluster.setCompetencyClusterId(competencyClusterId);
			this.pmsCompetencyCluster.setName(clusterName);
		}
		
		this.weightage = weightage;
		this.description = description;
		this.createdBy = createdBy;
		this.createdDate = createdDate;
		this.modifiedBy = modifiedBy;
		this.modifiedDate = modifiedDate;
		this.clusterName = clusterName;
		this.sequence = sequence;
		
		this.gradeNames = gradeNames;
		this.departmentNames = departmentNames;
	}

}
