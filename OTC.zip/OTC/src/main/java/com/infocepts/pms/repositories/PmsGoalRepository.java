/**
* Filename: /src/main/java/com/infocepts/pms/repositories/PmsGoalRepository.java
* @author  SRA
* @version 1.0
* @since   2018-12-07 
*/
package com.infocepts.pms.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.infocepts.otc.utilities.LoadConstant;
import com.infocepts.pms.entities.PmsGoal;

public interface PmsGoalRepository extends CrudRepository<PmsGoal,Integer>{

	@Override
	public List<PmsGoal> findAll();	
	
	@Transactional
	@Modifying
	@Query(value = "DELETE FROM " + LoadConstant.pms + ".dbo.goal WHERE performanceId = :performanceId", nativeQuery = true)
	public void deletePmsGoalByPerformanceId(@Param("performanceId") Integer performanceId);
	
	@Transactional
	@Modifying
	@Query(value = "update " + LoadConstant.pms + ".dbo.goal set approvalStatus = null, commentsRejection = null where performanceId = :performanceId", nativeQuery = true)
	public void updatePmsGoalByPerformanceId(@Param(value = "performanceId") Integer performanceId);
		
}
