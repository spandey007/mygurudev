/**
* Filename: /src/main/java/com/infocepts/pms/repositories/PmsCompetencyClusterRepository.java
* @author  MEW
* @version 1.0
* @since   2018-11-01 
*/
package com.infocepts.pms.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import com.infocepts.pms.entities.PmsCompetencyMaster;

public interface PmsCompetencyMasterRepository extends CrudRepository<PmsCompetencyMaster,Integer>{

	@Override
	public List<PmsCompetencyMaster> findAll();	
		
	
	
}
