/**
* Filename: /src/main/java/com/infocepts/pms/entities/PmsCompetency.java
* @author  SRA
* @version 1.0
* @since   2018-08-01 
*/
package com.infocepts.pms.entities;


import java.util.Date;
import javax.persistence.*;
import javax.validation.constraints.NotNull;

import com.infocepts.otc.utilities.LoadConstant;
@Entity
@Table(catalog=LoadConstant.pms, schema="[dbo]", name="competency")

@SqlResultSetMappings({
        @SqlResultSetMapping(
                name = "competency_list",
                classes = {
                        @ConstructorResult(
                                targetClass = PmsCompetency.class,
                                columns = {                           		
                                		
											@ColumnResult(name = "competencyId"),
											@ColumnResult(name = "performanceId"),
											@ColumnResult(name = "competencyMasterId"),   											
											@ColumnResult(name = "commentsSelfPitstop",type = String.class),
											@ColumnResult(name = "commentsManagerPitstop",type = String.class),										
											@ColumnResult(name = "commentsSelfAnnual",type = String.class),
											@ColumnResult(name = "commentsManagerAnnual",type = String.class),
											@ColumnResult(name = "commentsReviewerAnnual",type = String.class),
											@ColumnResult(name = "selfRating",type = String.class),
											@ColumnResult(name = "managersRating",type = String.class),	
											@ColumnResult(name = "createdBy"),
											@ColumnResult(name = "createdDate", type = Date.class),
											@ColumnResult(name = "modifiedBy"),
											@ColumnResult(name = "modifiedDate", type = Date.class),		
											@ColumnResult(name = "cmCompetencyMasterId"),
											@ColumnResult(name = "competencyClusterId"),
											@ColumnResult(name = "competencyName",type = String.class),										
											@ColumnResult(name = "clusterName",type = String.class),
											@ColumnResult(name = "competencyDesc",type = String.class),
											@ColumnResult(name = "docLinkSelfAnnual",type = String.class),
											@ColumnResult(name = "docLinkManagerAnnual",type = String.class)
											
											
                                }
                        )
                }
        ),
        @SqlResultSetMapping(
                name = "competency_list_manager",
                classes = {
                        @ConstructorResult(
                                targetClass = PmsCompetency.class,
                                columns = {                           		
                                		
											@ColumnResult(name = "competencyId"),
											@ColumnResult(name = "performanceId"),
											@ColumnResult(name = "competencyMasterId"),   											
											@ColumnResult(name = "commentsSelfPitstop",type = String.class),
											@ColumnResult(name = "commentsManagerPitstop",type = String.class),										
											@ColumnResult(name = "commentsSelfAnnual",type = String.class),
											@ColumnResult(name = "commentsManagerAnnual",type = String.class),
											@ColumnResult(name = "commentsReviewerAnnual",type = String.class),
											@ColumnResult(name = "selfRating",type = String.class),
											@ColumnResult(name = "managersRating",type = String.class),	
											@ColumnResult(name = "createdBy"),
											@ColumnResult(name = "createdDate", type = Date.class),
											@ColumnResult(name = "modifiedBy"),
											@ColumnResult(name = "modifiedDate", type = Date.class),		
											@ColumnResult(name = "cmCompetencyMasterId"),
											@ColumnResult(name = "competencyClusterId"),
											@ColumnResult(name = "docLinkSelfAnnual",type = String.class),
											@ColumnResult(name = "docLinkManagerAnnual",type = String.class)
											
                                }
                        )
                }
        )
        
})
@NamedNativeQueries({
        @NamedNativeQuery(
                name    =   "getAllCompetency",   
                query 	=   "Select c.*"+
                			", '' as cmCompetencyMasterId, '' as  competencyClusterId "+
							" from " + LoadConstant.pms + ".[dbo].competency AS c",			 
							resultClass=PmsCompetency.class, resultSetMapping = "competency_list"
        ),
		@NamedNativeQuery(
                name    =   "getCompetencyByPerformanceId",   
                query 	=   " Select distinct comp.*,  compMaster.competencyMasterId as cmCompetencyMasterId, compMaster.competencyClusterId , compMaster.competencyName as competencyName, compCluster.name as clusterName, compMaster.description as competencyDesc"+
                			" from " + LoadConstant.pms + ".[dbo].competencyMaster compMaster "+
							" left join " + LoadConstant.pms + ".[dbo].competencyCluster as compCluster on compMaster.competencyClusterId = compCluster.competencyClusterId "+
							" left join " + LoadConstant.pms + ".[dbo].gradeMapping gm on compMaster.competencyMasterId = gm.typeId and gm.type = 4 "+
							" left join " + LoadConstant.pms + ".[dbo].departmentMapping dm on compMaster.competencyMasterId = dm.typeId and dm.type = 4 "+
							" left join " + LoadConstant.infomaster + ".[dbo].department dep on dm.departmentId = dep.pid "+
							" left join " + LoadConstant.infomaster + ".[dbo].resource r on r.departmentId = dep.departmentId and r.gradeId = gm.gradeId "+
							" left join " + LoadConstant.pms + ".[dbo].competency comp on comp.competencyMasterId = compMaster.competencyMasterId and comp.performanceId = :performanceId"+ 
							" left join " + LoadConstant.pms + ".[dbo].performance p on p.performanceId = comp.performanceId "+
							" where comp.performanceId = :performanceId",							 
							resultClass=PmsCompetency.class, resultSetMapping = "competency_list"
        ) ,
		@NamedNativeQuery(
                name    =   "getCompetencyByUserAndPerformanceId",   
                query 	=   " Select distinct comp.*,  compMaster.competencyMasterId as cmCompetencyMasterId, compMaster.competencyClusterId, compMaster.competencyName as competencyName, compCluster.name as clusterName, compMaster.description as competencyDesc"+
                			" from " + LoadConstant.pms + ".[dbo].competencyMaster compMaster "+
							" left join " + LoadConstant.pms + ".[dbo].competencyCluster as compCluster on compMaster.competencyClusterId = compCluster.competencyClusterId "+
							" left join " + LoadConstant.pms + ".[dbo].gradeMapping gm on compMaster.competencyMasterId = gm.typeId and gm.type = 4 "+
							" left join " + LoadConstant.pms + ".[dbo].departmentMapping dm on compMaster.competencyMasterId = dm.typeId and dm.type = 4 "+
							" left join " + LoadConstant.infomaster + ".[dbo].department dep on dm.departmentId = dep.pid "+
							" left join " + LoadConstant.infomaster + ".[dbo].resource r on r.departmentId = dep.departmentId and r.gradeId = gm.gradeId "+
							" left join " + LoadConstant.pms + ".[dbo].competency comp on comp.competencyMasterId = compMaster.competencyMasterId and comp.performanceId = :performanceId"+ 
							" left join " + LoadConstant.pms + ".[dbo].performance p on p.performanceId = comp.performanceId "+
							" Where (:performanceId = 0 and compCluster.isActive = 1 and r.uid = :uid) or (:performanceId <> 0 and comp.performanceId = :performanceId)",
							
							resultClass=PmsCompetency.class, resultSetMapping = "competency_list"
        ),
		@NamedNativeQuery(
                name    =   "getCompetencyByManagerAndPerformanceId",   
                query 	=   " Select comp.*,  compMaster.competencyMasterId as cmCompetencyMasterId, compMaster.competencyClusterId, compMaster.competencyName as competencyName, compCluster.name as clusterName, compMaster.description as competencyDesc  "+
                			" from " + LoadConstant.pms + ".[dbo].competency comp "+
	                		" right join " + LoadConstant.pms + ".[dbo].competencyMaster compMaster on comp.competencyMasterId = compMaster.competencyMasterId"+
	                		" left join " + LoadConstant.pms + ".[dbo].competencyCluster as compCluster on compMaster.competencyClusterId = compCluster.competencyClusterId "+
	                		" left join " + LoadConstant.pms + ".[dbo].performance p on p.performanceId = comp.performanceId and comp.performanceId = :performanceId "+
	                		" Where p.managersUid = :uid order by compCluster.sequence,compMaster.sequence ",
							
							resultClass=PmsCompetency.class, resultSetMapping = "competency_list"
        )
        
        
        
})
public class PmsCompetency {

	// Entity Columns
    // --------------------------------------------------------------------------------
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Integer competencyId; 
	
	/*********FK************************************************/
	@NotNull
	@ManyToOne 	
	@JoinColumn(name="performanceId")
	private PmsPerformance pmsPerformance;    

	@NotNull
	@ManyToOne 	
	@JoinColumn(name="competencyMasterId")
	private PmsCompetencyMaster pmsCompetencyMaster;  

	/*********Other Columns********************************/        
	@Lob
	private String commentsSelfPitstop;
	@Lob
	private String commentsManagerPitstop;
	@Lob
	private String commentsSelfAnnual;
	@Lob
	private String commentsManagerAnnual;
	@Lob
	private String commentsReviewerAnnual;
	private String selfRating;
	private String managersRating;
	
	// Audit Trail columns 
    // --------------------------------------------------------------------------------	
	private Integer createdBy;    
    private Date createdDate;
    private Integer modifiedBy;
    private Date modifiedDate;
	@Lob
	private String docLinkSelfAnnual;
	@Lob
	private String docLinkManagerAnnual;	
    // Transient Variables
    // --------------------------------------------------------------------------------
    @Transient
    private Integer cmCompetencyMasterId;
    
    @Transient
    private Integer competencyClusterId;
    
    @Transient
    private PmsCompetencyCluster pmsCompetencyCluster;
    
    @Transient
    private String competencyName;
    
    @Transient
    private String clusterName;
    
    @Transient
    private String competencyDesc;
   
    // Getter setter
	// --------------------------------------------------------------------------------

	public Integer getCompetencyId() {
		return competencyId;
	}
	public void setCompetencyId(Integer competencyId) {
		this.competencyId = competencyId;
	}
	public PmsPerformance getPmsPerformance() {
		return pmsPerformance;
	}
	public void setPmsPerformance(PmsPerformance pmsPerformance) {
		this.pmsPerformance = pmsPerformance;
	}
	public PmsCompetencyMaster getPmsCompetencyMaster() {
		return pmsCompetencyMaster;
	}
	public void setPmsCompetencyMaster(PmsCompetencyMaster pmsCompetencyMaster) {
		this.pmsCompetencyMaster = pmsCompetencyMaster;
	}
	
	public String getCommentsSelfPitstop() {
		return commentsSelfPitstop;
	}
	public void setCommentsSelfPitstop(String commentsSelfPitstop) {
		this.commentsSelfPitstop = commentsSelfPitstop;
	}
	public String getCommentsManagerPitstop() {
		return commentsManagerPitstop;
	}
	public void setCommentsManagerPitstop(String commentsManagerPitstop) {
		this.commentsManagerPitstop = commentsManagerPitstop;
	}
	
	public String getCommentsSelfAnnual() {
		return commentsSelfAnnual;
	}
	public void setCommentsSelfAnnual(String commentsSelfAnnual) {
		this.commentsSelfAnnual = commentsSelfAnnual;
	}
	public String getCommentsManagerAnnual() {
		return commentsManagerAnnual;
	}
	public void setCommentsManagerAnnual(String commentsManagerAnnual) {
		this.commentsManagerAnnual = commentsManagerAnnual;
	}
	public String getCommentsReviewerAnnual() {
		return commentsReviewerAnnual;
	}
	public void setCommentsReviewerAnnual(String commentsReviewerAnnual) {
		this.commentsReviewerAnnual = commentsReviewerAnnual;
	}
	public String getSelfRating() {
		return selfRating;
	}
	public void setSelfRating(String selfRating) {
		this.selfRating = selfRating;
	}
	public String getManagersRating() {
		return managersRating;
	}
	public void setManagersRating(String managersRating) {
		this.managersRating = managersRating;
	}
	public Integer getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public Integer getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public Date getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	
	public Integer getCmCompetencyMasterId() {
		return cmCompetencyMasterId;
	}
	
	public void setCmCompetencyMasterId(Integer cmCompetencyMasterId) {
		this.cmCompetencyMasterId = cmCompetencyMasterId;
	}
	
	public Integer getCompetencyClusterId() {
		return competencyClusterId;
	}
	
	public void setCompetencyClusterId(Integer competencyClusterId) {
		this.competencyClusterId = competencyClusterId;
	}
	
	public PmsCompetencyCluster getPmsCompetencyCluster() {
		return pmsCompetencyCluster;
	}
	
	public void setPmsCompetencyCluster(PmsCompetencyCluster pmsCompetencyCluster) {
		this.pmsCompetencyCluster = pmsCompetencyCluster;
	}
	
	
	public String getCompetencyName() {
		return competencyName;
	}
	public void setCompetencyName(String competencyName) {
		this.competencyName = competencyName;
	}
	public String getClusterName() {
		return clusterName;
	}
	public void setClusterName(String clusterName) {
		this.clusterName = clusterName;
	}
	public String getCompetencyDesc() {
		return competencyDesc;
	}
	public void setCompetencyDesc(String competencyDesc) {
		this.competencyDesc = competencyDesc;
	}

	public String getDocLinkSelfAnnual() {
		return docLinkSelfAnnual;
	}
	public void setDocLinkSelfAnnual(String docLinkSelfAnnual) {
		this.docLinkSelfAnnual = docLinkSelfAnnual;
	}
	public String getDocLinkManagerAnnual() {
		return docLinkManagerAnnual;
	}
	public void setDocLinkManagerAnnual(String docLinkManagerAnnual) {
		this.docLinkManagerAnnual = docLinkManagerAnnual;
	}
	// Constructor
	// ---------------------------------------------------------------------------------
	public PmsCompetency() {
		//super();		
	}
	public PmsCompetency(Integer competencyId, Integer performanceId, Integer competencyMasterId, 
		 String commentsSelfPitstop, String commentsManagerPitstop,
		 String commentsSelfAnnual, String commentsManagerAnnual,
			String commentsReviewerAnnual, String selfRating, String managersRating, Integer createdBy,
			Date createdDate, Integer modifiedBy, Date modifiedDate,
			Integer cmCompetencyMasterId, Integer competencyClusterId, String competencyName, String clusterName, String competencyDesc, String docLinkSelfAnnual, String docLinkManagerAnnual
		) {
		super();
		this.competencyId = competencyId;
		
		if(performanceId != null)
		{
			
			this.pmsPerformance = new PmsPerformance();
			this.pmsPerformance.setPerformanceId(performanceId);   
		}	
		
		if(cmCompetencyMasterId != null)
		{
			this.pmsCompetencyMaster = new PmsCompetencyMaster();
			this.pmsCompetencyMaster.setCompetencyMasterId(competencyMasterId);
		}	
		
		if(competencyClusterId != null)
		{
			this.pmsCompetencyCluster = new PmsCompetencyCluster();
			this.pmsCompetencyCluster.setCompetencyClusterId(competencyClusterId);
		}
		
		this.commentsSelfPitstop = commentsSelfPitstop;
		this.commentsManagerPitstop = commentsManagerPitstop;
		this.commentsSelfAnnual = commentsSelfAnnual;
		this.commentsManagerAnnual = commentsManagerAnnual;
		this.commentsReviewerAnnual = commentsReviewerAnnual;
		this.selfRating = selfRating;
		this.managersRating = managersRating;
		this.createdBy = createdBy;
		this.createdDate = createdDate;
		this.modifiedBy = modifiedBy;
		this.modifiedDate = modifiedDate;
		this.cmCompetencyMasterId = cmCompetencyMasterId;
		this.competencyClusterId = competencyClusterId;
		this.competencyName = competencyName;
		this.clusterName = clusterName;
		this.competencyDesc = competencyDesc;
		this.docLinkSelfAnnual = docLinkSelfAnnual;
		this.docLinkManagerAnnual = docLinkManagerAnnual;
	
	}
	
}
