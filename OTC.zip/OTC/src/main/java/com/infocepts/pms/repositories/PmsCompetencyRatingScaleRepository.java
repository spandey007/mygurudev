/**
* Filename: /src/main/java/com/infocepts/pms/repositories/PmsCompetencyRatingScaleRepository.java
* @author  MEW
* @version 1.0
* @since   2018-11-19 
*/
package com.infocepts.pms.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import com.infocepts.pms.entities.PmsCompetencyRatingScale;

public interface PmsCompetencyRatingScaleRepository extends CrudRepository<PmsCompetencyRatingScale,Integer>{

	@Override
	public List<PmsCompetencyRatingScale> findAll();	
		
	
	
}
