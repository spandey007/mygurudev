package com.infocepts.pms.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.infocepts.pms.entities.PmsResource;


public interface PmsResourceRepository extends JpaRepository<PmsResource,Integer>{

	@Override
	public List<PmsResource> findAll();
	
	@Query("select r from PmsResource r where r.uid = :uid")
	public PmsResource findResourceById(@Param(value = "uid") Integer uid);
}
