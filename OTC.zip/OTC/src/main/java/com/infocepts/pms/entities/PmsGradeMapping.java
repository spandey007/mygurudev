package com.infocepts.pms.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import com.infocepts.otc.utilities.LoadConstant;

@Entity
@Table(catalog=LoadConstant.pms, schema="[dbo]",name="gradeMapping")
public class PmsGradeMapping {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer gradeMappingId;
	private Integer type; // 
	private Integer gradeId;
	private Integer typeId;
	public Integer getGradeMappingId() {
		return gradeMappingId;
	}
	public void setGradeMappingId(Integer gradeMappingId) {
		this.gradeMappingId = gradeMappingId;
	}
	public Integer getType() {
		return type;
	}
	public void setType(Integer type) {
		this.type = type;
	}
	public Integer getGradeId() {
		return gradeId;
	}
	public void setGradeId(Integer gradeId) {
		this.gradeId = gradeId;
	}
	public Integer getTypeId() {
		return typeId;
	}
	public void setTypeId(Integer typeId) {
		this.typeId = typeId;
	}
	
	
}

/* Mapping details
 * 
 * 1: Competency Cluster
 * 2: Goal Cluster
 * 
 * 
 * 
 * 
 */


	