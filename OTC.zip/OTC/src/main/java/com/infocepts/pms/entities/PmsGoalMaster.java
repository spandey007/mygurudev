/**
* Filename: /src/main/java/com/infocepts/pms/entities/PmsGoalMaster.java
* @author  SRA
* @version 1.0
* @since   2018-11-01 
*/
package com.infocepts.pms.entities;

import java.util.Date;
import java.util.List;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

import com.infocepts.otc.utilities.LoadConstant;
@Entity
@Table(catalog=LoadConstant.pms, schema="[dbo]", name="goalMaster")

@SqlResultSetMappings({
        @SqlResultSetMapping(
                name = "goal_master_details",
                classes = {
                        @ConstructorResult(
                                targetClass = PmsGoalMaster.class,
                                columns = {
                                		@ColumnResult(name = "goalMasterId", type = Integer.class),
										@ColumnResult(name = "goalName"),										
										@ColumnResult(name = "goalClusterId", type = Integer.class), 
										@ColumnResult(name = "kpi"),
                                        @ColumnResult(name = "weightage", type = Integer.class),
                                        @ColumnResult(name = "uom"),
                                        @ColumnResult(name = "uomDate", type = Date.class),
                                        @ColumnResult(name = "uomNumber", type = Integer.class),                                        
                                        @ColumnResult(name = "uomPercentage", type = Integer.class),                                        
                                        @ColumnResult(name = "target"),
                                        @ColumnResult(name = "actionPlan"),  
                                        @ColumnResult(name = "sequence"),   
										@ColumnResult(name = "createdBy"),
                                        @ColumnResult(name = "createdDate", type = Date.class),
										@ColumnResult(name = "modifiedBy"),
                                        @ColumnResult(name = "modifiedDate", type = Date.class), 
                                        @ColumnResult(name = "clusterName"), 
                                        @ColumnResult(name = "gradeNames", type = String.class),
                                        @ColumnResult(name = "departmentNames", type = String.class)
                                     
                                  	
                                }
                        )
                }
        )
})
@NamedNativeQueries({
        @NamedNativeQuery(
                name    =   "getAllGoalMasters",   
                query 	=    "Select gm.*,gc.clusterName as clusterName,"+	
	            			" STUFF((Select ','+g.grade from " + LoadConstant.pms + ".[dbo].grademapping gmp  "+
	        				" left join " + LoadConstant.infomaster + ".dbo.grade g on g.gradeId = gmp.gradeId "+
	        				" where gmp.typeId =gm.goalMasterId and gmp.type=3 "+
	        				" FOR XML PATH('')),1,1,'') as gradeNames, "+
							" STUFF((Select ','+dep.departmentName from " + LoadConstant.pms + ".[dbo].departmentMapping dmp "+
							" left join " + LoadConstant.infomaster + ".dbo.department dep on dep.departmentId = dmp.departmentId "+
							" where dmp.typeId =gm.goalMasterId and dmp.type=3  "+
							" FOR XML PATH('')),1,1,'') as departmentNames "+
							" from " + LoadConstant.pms + ".[dbo].goalMaster as gm"+
							" LEFT JOIN " + LoadConstant.pms + ".[dbo].goalCluster as gc on gc.goalClusterId = gm.goalClusterId", 							
							resultClass=PmsGoalMaster.class, resultSetMapping = "goal_master_details"
        ),
        @NamedNativeQuery(
                name    =   "getGoalMastersByCluster",   
                query 	=    "Select gm.*,gc.clusterName as clusterName"+	
                			", '' as gradeNames, '' as departmentNames "+
	                		" from " + LoadConstant.pms + ".[dbo].goalMaster as gm"+
							" LEFT JOIN " + LoadConstant.pms + ".[dbo].goalCluster as gc on gc.goalClusterId = gm.goalClusterId"+							
							" where gm.goalClusterId = :goalClusterId", 
							resultClass=PmsGoalMaster.class, resultSetMapping = "goal_master_details"
        ),
        @NamedNativeQuery(
                name    =   "getGoalMastersById",   
                query 	=    "Select gm.*,gc.clusterName as clusterName"+	
                			", '' as gradeNames, '' as departmentNames "+
	                		" from " + LoadConstant.pms + ".[dbo].goalMaster as gm"+
							" LEFT JOIN " + LoadConstant.pms + ".[dbo].goalCluster as gc on gc.goalClusterId = gm.goalClusterId"+							
							" where gm.goalMasterId = :goalMasterId", 
							resultClass=PmsGoalMaster.class, resultSetMapping = "goal_master_details"
        ),
		@NamedNativeQuery(
		        name    =   "getGoalMastersByClusterGradeDepartment",   
		        query 	=    "Select gm.*,gc.clusterName as clusterName"+	
		        			", '' as gradeNames, '' as departmentNames "+
		            		" from " + LoadConstant.pms + ".[dbo].goalMaster as gm"+
							" LEFT JOIN " + LoadConstant.pms + ".[dbo].goalCluster as gc on gc.goalClusterId = gm.goalClusterId"+
							" left join " + LoadConstant.pms + ".[dbo].gradeMapping gmap on gm.goalMasterId = gmap.typeId and gmap.type = 3"+
							" left join " + LoadConstant.pms + ".[dbo].departmentMapping dm on gm.goalMasterId = dm.typeId and dm.type = 3"+
							" left join " + LoadConstant.infomaster + ".[dbo].department dep on dm.departmentId = dep.pid "+
							" left join " + LoadConstant.infomaster + ".[dbo].resource r on r.departmentId = dep.departmentId and r.gradeId = gmap.gradeId"+
							" where gm.goalClusterId = :goalClusterId and r.uid = :uid", 
							resultClass=PmsGoalMaster.class, resultSetMapping = "goal_master_details"
),
})
public class PmsGoalMaster {

	// Entity Columns
    // --------------------------------------------------------------------------------
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Integer goalMasterId; 
	
    @NotNull
    private String goalName;
    
    @ManyToOne
   	@JoinColumn(name="goalClusterId")
    private PmsGoalCluster pmsGoalCluster;
    
    @Lob
    private String kpi;
    
    private Integer weightage;
  
    @NotNull
    private String uom;
    private Date uomDate;
    private Integer uomNumber;
    private Integer uomPercentage;
    
    @Lob
    private String target;
    @Lob
    private String actionPlan;	
    private Integer sequence;
   
    // Audit Trail columns 
    // --------------------------------------------------------------------------------
	private Integer createdBy;    
    private Date createdDate;
    private Integer modifiedBy;
    private Date modifiedDate;
    
    // Transient Variables
    // -------------------------------------------------------------------------------
    @Transient
    private List<PmsGradeMapping> gradeMapping;
    
    @Transient
    private List<PmsDepartmentMapping> departmentMapping;
    
    @Transient
    private String gradeNames;
    
    @Transient
    private String 	departmentNames;
    

    // Getter setter
	// --------------------------------------------------------------------------------
	public Integer getGoalMasterId() {
		return goalMasterId;
	}

	public void setGoalMasterId(Integer goalMasterId) {
		this.goalMasterId = goalMasterId;
	}

	public String getGoalName() {
		return goalName;
	}

	public void setGoalName(String goalName) {
		this.goalName = goalName;
	}

	public PmsGoalCluster getPmsGoalCluster() {
		return pmsGoalCluster;
	}

	public void setPmsGoalCluster(PmsGoalCluster pmsGoalCluster) {
		this.pmsGoalCluster = pmsGoalCluster;
	}

	public String getKpi() {
		return kpi;
	}

	public void setKpi(String kpi) {
		this.kpi = kpi;
	}

	public Integer getWeightage() {
		return weightage;
	}

	public void setWeightage(Integer weightage) {
		this.weightage = weightage;
	}

	public String getUom() {
		return uom;
	}

	public void setUom(String uom) {
		this.uom = uom;
	}

	public Date getUomDate() {
		return uomDate;
	}

	public void setUomDate(Date uomDate) {
		this.uomDate = uomDate;
	}

	public Integer getUomNumber() {
		return uomNumber;
	}

	public void setUomNumber(Integer uomNumber) {
		this.uomNumber = uomNumber;
	}

	public Integer getUomPercentage() {
		return uomPercentage;
	}

	public void setUomPercentage(Integer uomPercentage) {
		this.uomPercentage = uomPercentage;
	}

	public String getTarget() {
		return target;
	}

	public void setTarget(String target) {
		this.target = target;
	}

	public String getActionPlan() {
		return actionPlan;
	}

	public void setActionPlan(String actionPlan) {
		this.actionPlan = actionPlan;
	}

	public Integer getSequence() {
		return sequence;
	}

	public void setSequence(Integer sequence) {
		this.sequence = sequence;
	}

	public Integer getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Integer getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	
	public List<PmsGradeMapping> getGradeMapping() {
		return gradeMapping;
	}
	
	public void setGradeMapping(List<PmsGradeMapping> gradeMapping) {
		this.gradeMapping = gradeMapping;
	}
	
	public List<PmsDepartmentMapping> getDepartmentMapping() {
		return departmentMapping;
	}
	
	public void setDepartmentMapping(List<PmsDepartmentMapping> departmentMapping) {
		this.departmentMapping = departmentMapping;
	}
	
	public String getGradeNames() {
		return gradeNames;
	}

	public void setGradeNames(String gradeNames) {
		this.gradeNames = gradeNames;
	}

	public String getDepartmentNames() {
		return departmentNames;
	}

	public void setDepartmentNames(String departmentNames) {
		this.departmentNames = departmentNames;
	}
	
	// Constructor
	// ---------------------------------------------------------------------------------

	public PmsGoalMaster() {
		//super();
		// TODO Auto-generated constructor stub
	}

	public PmsGoalMaster(	
			Integer goalMasterId,
			String goalName,
			Integer goalClusterId,
			String kpi,
			Integer weightage,
			String uom,
			Date uomDate,
			Integer uomNumber,
			Integer uomPercentage,
			String target,
			String actionPlan,
			Integer sequence,
			Integer createdBy, Date createdDate, Integer modifiedBy, Date modifiedDate,
			String clusterName
			, String gradeNames,
			String departmentNames
	) {
		
		this.goalMasterId = goalMasterId;
		this.goalName = goalName;
		
		if(goalClusterId != null)
		{
			this.pmsGoalCluster = new PmsGoalCluster();
			this.pmsGoalCluster.setGoalClusterId(goalClusterId);
			this.pmsGoalCluster.setClusterName(clusterName);
		}			
		
		this.kpi = kpi;
		this.weightage = weightage;
		this.uom = uom;
		this.uomDate = uomDate;
		this.uomNumber = uomNumber;
		this.uomPercentage = uomPercentage;
		this.target = target;
		this.actionPlan = actionPlan;	
		this.sequence = sequence;
		this.createdBy = createdBy;
		this.createdDate = createdDate;
		this.modifiedBy = modifiedBy;
		this.modifiedDate = modifiedDate;
		
		this.gradeNames = gradeNames;
		this.departmentNames = departmentNames;
		
		
	}
		
	

		
   
   



    
    

}
