/**
* Filename: /src/main/java/com/infocepts/pms/entities/PmsGoalCluster.java
* @author  SRA
* @version 1.0
* @since   2018-11-01 
*/
package com.infocepts.pms.entities;

import java.util.Date;
import java.util.List;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

import com.infocepts.otc.utilities.LoadConstant;
@Entity
@Table(catalog=LoadConstant.pms, schema="[dbo]", name="goalCluster")

@SqlResultSetMappings({
        @SqlResultSetMapping(
                name = "goal_cluster_details",
                classes = {
                        @ConstructorResult(
                                targetClass = PmsGoalCluster.class,
                                columns = {
                                		@ColumnResult(name = "goalClusterId"),
										@ColumnResult(name = "clusterName"),
                                        @ColumnResult(name = "rangeLow"),   
                                        @ColumnResult(name = "rangeHigh"),  
                                        @ColumnResult(name = "isActive",type = Boolean.class),  
                                        @ColumnResult(name = "sequence"),
										@ColumnResult(name = "createdBy"),
                                        @ColumnResult(name = "createdDate", type = Date.class),
										@ColumnResult(name = "modifiedBy"),
                                        @ColumnResult(name = "modifiedDate", type = Date.class),  
                                        @ColumnResult(name = "gradeNames", type = String.class),
                                        @ColumnResult(name = "departmentNames", type = String.class)
                               }
                        )
                }
        )
})
@NamedNativeQueries({
        @NamedNativeQuery(
                name    =   "getAllGoalClusters",   
                query 	=    "Select gc.*, "+
                			" STUFF((Select ','+g.grade from " + LoadConstant.pms + ".[dbo].grademapping gmp "+
	        				" left join " + LoadConstant.infomaster + ".dbo.grade g on g.gradeId = gmp.gradeId "+
	        				" where gmp.typeId =gc.goalClusterId and gmp.type = 2"+
	        				" FOR XML PATH('')),1,1,'') as gradeNames, "+
							" STUFF((Select ','+dep.departmentName from " + LoadConstant.pms + ".[dbo].departmentMapping dmp "+
							" left join " + LoadConstant.infomaster + ".dbo.department dep on dep.departmentId = dmp.departmentId "+
							" where dmp.typeId =gc.goalClusterId and dmp.type = 2"+
							" FOR XML PATH('')),1,1,'') as departmentNames "+
                			" from " + LoadConstant.pms + ".[dbo].goalCluster as gc"+
							" where (gc.isActive = :status or  2 = :status) order by gc.sequence",
							resultClass=PmsGoalCluster.class, resultSetMapping = "goal_cluster_details"
        ),
        @NamedNativeQuery(
                name    =   "getGoalClusterById",   
                query 	=   "Select gc.*, '' as gradeNames, '' as departmentNames  from " + LoadConstant.pms + ".[dbo].goalCluster as gc"+
							" where gc.goalClusterId = :goalClusterId order by gc.sequence", 
							resultClass=PmsGoalCluster.class, resultSetMapping = "goal_cluster_details"
        ),
        @NamedNativeQuery(
                name    =   "getAllGoalClusterByUser",   
                query 	=   " Select gc.*, '' as gradeNames, '' as departmentNames  from "+ LoadConstant.pms + ".[dbo].goalCluster as gc"+
							" left join " + LoadConstant.pms + ".[dbo].gradeMapping gm on gc.goalClusterId = gm.typeId and gm.type = 2"+
							" left join " + LoadConstant.pms + ".[dbo].departmentMapping dm on gc.goalClusterId = dm.typeId and dm.type = 2"+
							" left join " + LoadConstant.infomaster + ".[dbo].department dep on dm.departmentId = dep.pid "+
							" left join " + LoadConstant.infomaster + ".[dbo].resource r on r.departmentId = dep.departmentId and r.gradeId = gm.gradeId"+
							" where gc.isActive = 1"+//status = 1
							" and r.uid = :uid order by gc.sequence",
							 
							resultClass=PmsGoalCluster.class, resultSetMapping = "goal_cluster_details"
        ),       
        @NamedNativeQuery(
                name    =   "getGoalClustersByPerformanceId",   
                query 	=   " Select Distinct gc.*, '' as gradeNames, '' as departmentNames  from "+ LoadConstant.pms + ".[dbo].goalCluster as gc"+
							//" left join " + LoadConstant.pms + ".[dbo].gradeMapping gm on gc.goalClusterId = gm.typeId and gm.type = 2"+
							//" left join " + LoadConstant.pms + ".[dbo].departmentMapping dm on gc.goalClusterId = dm.typeId and dm.type = 2"+
							//" left join " + LoadConstant.infomaster + ".[dbo].department dep on dm.departmentId = dep.pid "+
							//" left join " + LoadConstant.infomaster + ".[dbo].resource r on r.departmentId = dep.departmentId and r.gradeId = gm.gradeId"+
							" left join " + LoadConstant.pms + ".[dbo].goal g on g.goalClusterId = gc.goalClusterId "+
							" left join " + LoadConstant.pms + ".[dbo].performance p on p.performanceId = g.performanceId "+
							" where (:performanceId <> 0 and p.performanceId = :performanceId)",
													 
							resultClass=PmsGoalCluster.class, resultSetMapping = "goal_cluster_details"
        )
})
public class PmsGoalCluster {

	// Entity Columns
    // --------------------------------------------------------------------------------
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Integer goalClusterId; 
	
    @NotNull
    private String clusterName;
    private Integer rangeLow;    
    private Integer rangeHigh; 
    private Boolean isActive;	
    private Integer sequence;	
	
    // Audit Trail columns 
    // --------------------------------------------------------------------------------
	private Integer createdBy;    
    private Date createdDate;
    private Integer modifiedBy;
    private Date modifiedDate;
    
    // Transient Variables
    // -------------------------------------------------------------------------------
    @Transient
    private List<PmsGradeMapping> gradeMapping;
    
    @Transient
    private List<PmsDepartmentMapping> departmentMapping;
	
    @Transient
    private String gradeNames;
    
    @Transient
    private String 	departmentNames;

    // Getter setter
	// --------------------------------------------------------------------------------
 
	public Integer getGoalClusterId() {
		return goalClusterId;
	}

	public void setGoalClusterId(Integer goalClusterId) {
		this.goalClusterId = goalClusterId;
	}

	public String getClusterName() {
		return clusterName;
	}

	public void setClusterName(String clusterName) {
		this.clusterName = clusterName;
	}

	public Integer getRangeLow() {
		return rangeLow;
	}

	public void setRangeLow(Integer rangeLow) {
		this.rangeLow = rangeLow;
	}

	public Integer getRangeHigh() {
		return rangeHigh;
	}

	public void setRangeHigh(Integer rangeHigh) {
		this.rangeHigh = rangeHigh;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}
	public Integer getSequence() {
		return sequence;
	}

	public void setSequence(Integer sequence) {
		this.sequence = sequence;
	}

	public Integer getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Integer getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public List<PmsGradeMapping> getGradeMapping() {
		return gradeMapping;
	}
	public void setGradeMapping(List<PmsGradeMapping> gradeMapping) {
		this.gradeMapping = gradeMapping;
	}
	public List<PmsDepartmentMapping> getDepartmentMapping() {
		return departmentMapping;
	}
	public void setDepartmentMapping(List<PmsDepartmentMapping> departmentMapping) {
		this.departmentMapping = departmentMapping;
	}

    
	public String getGradeNames() {
		return gradeNames;
	}

	public void setGradeNames(String gradeNames) {
		this.gradeNames = gradeNames;
	}

	public String getDepartmentNames() {
		return departmentNames;
	}

	public void setDepartmentNames(String departmentNames) {
		this.departmentNames = departmentNames;
	}

	// Constructor
	// ---------------------------------------------------------------------------------
	public PmsGoalCluster() {
		//super();
		// TODO Auto-generated constructor stub
	}
	
	public PmsGoalCluster(
				Integer goalClusterId,			
				String clusterName,
				Integer rangeLow,
				Integer rangeHigh,
				Boolean isActive,
				Integer sequence,
				Integer createdBy,
				Date createdDate,
				Integer modifiedBy,
				Date modifiedDate
				, String gradeNames,
				String departmentNames
	) {
		
		this.goalClusterId = goalClusterId;
		this.clusterName = clusterName;
		this.rangeLow = rangeLow;
		this.rangeHigh = rangeHigh;
		this.isActive = isActive;
		this.sequence = sequence;
		this.createdBy = createdBy;
		this.createdDate = createdDate;
		this.modifiedBy = modifiedBy;
		this.modifiedDate = modifiedDate;	
		
		this.gradeNames = gradeNames;
		this.departmentNames = departmentNames;
	}

		
   
   



    
    

}
