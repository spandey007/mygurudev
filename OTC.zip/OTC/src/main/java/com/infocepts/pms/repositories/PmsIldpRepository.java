/**
* Filename: /src/main/java/com/infocepts/pms/repositories/PmsILDPRepository.java
* @author  VVC
* @version 1.0
* @since   2019-01-29
*/
package com.infocepts.pms.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.infocepts.pms.entities.PmsIldp;

public interface PmsIldpRepository extends CrudRepository<PmsIldp,Integer>{

	@Override
	public List<PmsIldp> findAll();
}
