/**
* Filename: /src/main/java/com/infocepts/pms/repositories/PmsCompetencyRepository.java
* @author  SRA
* @version 1.0
* @since   2018-12-07
*/
package com.infocepts.pms.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.infocepts.otc.utilities.LoadConstant;
import com.infocepts.pms.entities.PmsCompetency;

public interface PmsCompetencyRepository extends CrudRepository<PmsCompetency,Integer>{

	@Override
	public List<PmsCompetency> findAll();	
		
	@Transactional
	@Modifying
	@Query(value = "DELETE FROM " + LoadConstant.pms + ".dbo.competency WHERE performanceId = :performanceId", nativeQuery = true)
	public void deletePmsCompetencyByPerformanceId(@Param("performanceId") Integer performanceId);

}
