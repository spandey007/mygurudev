/**
* Filename: /src/main/java/com/infocepts/pms/entities/PmsCycle.java
* @author  RKJ
* @version 1.0
* @since   2018-10-31 
*/
package com.infocepts.pms.entities;

import java.util.Date;
import javax.persistence.*;
import javax.validation.constraints.NotNull;

import com.infocepts.otc.utilities.LoadConstant;
import com.infocepts.pms.entities.PmsCategory;
@Entity
@Table(catalog=LoadConstant.pms, schema="[dbo]", name="cycle")

@SqlResultSetMappings({
        @SqlResultSetMapping(
                name = "cycle_details",
                classes = {
                        @ConstructorResult(
                                targetClass = PmsCycle.class,
                                columns = {
                                		@ColumnResult(name = "cycleId"),
										@ColumnResult(name = "yearId"),
										@ColumnResult(name = "categoryId"),
										@ColumnResult(name = "startDate",type = Date.class),
										@ColumnResult(name = "endDate",type = Date.class),
                                        @ColumnResult(name = "isActive", type = Boolean.class),
                                        @ColumnResult(name = "enableHandshake", type = Boolean.class),
                                        @ColumnResult(name = "enablePitstop", type = Boolean.class),
                                        @ColumnResult(name = "enableEvaluation", type = Boolean.class),	
                                        @ColumnResult(name = "pitstopCutoffDate", type = Date.class),
                                        @ColumnResult(name = "evaluationCutoffDate", type = Date.class),
										@ColumnResult(name = "createdBy"),
                                        @ColumnResult(name = "createdDate", type = Date.class),
										@ColumnResult(name = "modifiedBy"),
                                        @ColumnResult(name = "modifiedDate", type = Date.class),
                                        @ColumnResult(name = "status", type = String.class),
                                        @ColumnResult(name = "categoryName", type = String.class),
                                        @ColumnResult(name = "year"),
                                        @ColumnResult(name = "functionalPercentage"),
                                		@ColumnResult(name = "behaviouralPercentage")
                                }
                        )
                }
        )
})
@NamedNativeQueries({
        @NamedNativeQuery(
                name    =   "getAllCycles",   
                query 	=   "Select c.*, cc.name as categoryName, y.year"+
							" from " + LoadConstant.pms + ".[dbo].cycle as c"+
							" left join " + LoadConstant.pms + ".[dbo].category as cc on cc.categoryId = c.categoryId"+
							" left join " + LoadConstant.infomaster + ".[dbo].year as y on y.yearId = c.yearId",
							resultClass=PmsCycle.class, resultSetMapping = "cycle_details"
        ),
        @NamedNativeQuery(
                name    =   "getActiveCycle",   
                query 	=   "Select c.*, cc.name as categoryName, y.year"+
							" from " + LoadConstant.pms + ".[dbo].cycle as c"+
							" left join " + LoadConstant.pms + ".[dbo].category as cc on cc.categoryId = c.categoryId "+
							" left join " + LoadConstant.infomaster + ".[dbo].year as y on y.yearId = c.yearId "+
							" where c.isActive = 1 and c.status != 'Not Initiated'"+
							" order by y.year desc",							 
							resultClass=PmsCycle.class, resultSetMapping = "cycle_details"
        ),
        @NamedNativeQuery(
                name    =   "getCycleById",   
                query 	=   "Select c.*, cc.name as categoryName, y.year"+
							" from " + LoadConstant.pms + ".[dbo].cycle as c"+
							" left join " + LoadConstant.pms + ".[dbo].category as cc on cc.categoryId = c.categoryId "+
							" left join " + LoadConstant.infomaster + ".[dbo].year as y on y.yearId = c.yearId "+
							" where c.cycleId = :cycleId",							 
							resultClass=PmsCycle.class, resultSetMapping = "cycle_details"
        )
})
public class PmsCycle {

	// Entity Columns
    // --------------------------------------------------------------------------------
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Integer cycleId; 
	
    @NotNull
    private Integer yearId;
    
    @ManyToOne
	@JoinColumn(name="categoryId")
    private PmsCategory category;
    
    private Date startDate; 
    private Date endDate;
    
    private Boolean isActive;
    
    private String status;
    
    private Boolean enableHandshake;
    private Boolean enablePitstop;
    private Boolean enableEvaluation;
    
    private Date pitstopCutoffDate;
    private Date evaluationCutoffDate;
    
    private Integer functionalPercentage;  
    private Integer behaviouralPercentage;  
	
	// Audit Trail columns 
    // --------------------------------------------------------------------------------
	private Integer createdBy;    
    private Date createdDate;
    private Integer modifiedBy;
    private Date modifiedDate;
    
    // Transient Variables
    // -------------------------------------------------------------------------------
    @Transient
    private String categoryName;
    
    @Transient
    private Integer year;
    
    // Getter setter
	// --------------------------------------------------------------------------------
	public Integer getCycleId() {
		return cycleId;
	}
	public void setCycleId(Integer cycleId) {
		this.cycleId = cycleId;
	}
	public Integer getYearId() {
		return yearId;
	}
	public void setYearId(Integer yearId) {
		this.yearId = yearId;
	}
	public PmsCategory getCategory() {
		return category;
	}
	public void setCategory(PmsCategory category) {
		this.category = category;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public Boolean getIsActive() {
		return isActive;
	}
	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Boolean getEnableHandshake() {
		return enableHandshake;
	}
	public void setEnableHandshake(Boolean enableHandshake) {
		this.enableHandshake = enableHandshake;
	}
	public Boolean getEnablePitstop() {
		return enablePitstop;
	}
	public void setEnablePitstop(Boolean enablePitstop) {
		this.enablePitstop = enablePitstop;
	}
	public Boolean getEnableEvaluation() {
		return enableEvaluation;
	}
	public void setEnableEvaluation(Boolean enableEvaluation) {
		this.enableEvaluation = enableEvaluation;
	}
	
	public Date getPitstopCutoffDate() {
		return pitstopCutoffDate;
	}
	public void setPitstopCutoffDate(Date pitstopCutoffDate) {
		this.pitstopCutoffDate = pitstopCutoffDate;
	}
	public Date getEvaluationCutoffDate() {
		return evaluationCutoffDate;
	}
	public void setEvaluationCutoffDate(Date evaluationCutoffDate) {
		this.evaluationCutoffDate = evaluationCutoffDate;
	}
	public Integer getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public Integer getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public Date getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}	
	
	@Transient
	public String getCategoryName() {
		return categoryName;
	}
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	
	@Transient
	public Integer getYear() {
		return year;
	}
	public void setYear(Integer year) {
		this.year = year;
	}
	
	public Integer getFunctionalPercentage() {
		return functionalPercentage;
	}
	public void setFunctionalPercentage(Integer functionalPercentage) {
		this.functionalPercentage = functionalPercentage;
	}
	public Integer getBehaviouralPercentage() {
		return behaviouralPercentage;
	}
	public void setBehaviouralPercentage(Integer behaviouralPercentage) {
		this.behaviouralPercentage = behaviouralPercentage;
	}
	
	// Constructor
	// ---------------------------------------------------------------------------------
	
	public PmsCycle() {
		//super();
		// TODO Auto-generated constructor stub
	}
	
	public PmsCycle(Integer cycleId, Integer yearId, Integer categoryId, Date startDate, Date endDate, 
					Boolean isActive, Boolean enableHandshake, Boolean enablePitstop, Boolean enableEvaluation,
					Date pitstopCutoffDate, Date evaluationCutoffDate,
					Integer createdBy, Date createdDate, Integer modifiedBy, Date modifiedDate,String status,
					String categoryName, Integer year, Integer functionalPercentage, Integer behaviouralPercentage ) {
		
		this.cycleId = cycleId;
		this.yearId = yearId;
		this.year = year;
		
		if(categoryId != null)
		{
			this.category = new PmsCategory();
			this.category.setCategoryId(categoryId);
			this.category.setName(categoryName);
		}
		this.startDate = startDate;
		this.endDate = endDate;
		this.isActive = isActive;
		this.enableHandshake = enableHandshake;
		this.enablePitstop = enablePitstop;
		this.enableEvaluation = enableEvaluation;
		
		this.pitstopCutoffDate = pitstopCutoffDate;
		this.evaluationCutoffDate = evaluationCutoffDate;
		
		this.createdBy = createdBy;
		this.createdDate = createdDate;
		this.modifiedBy = modifiedBy;
		this.modifiedDate = modifiedDate;	
		this.status = status;
		this.functionalPercentage = functionalPercentage;
		this.behaviouralPercentage = behaviouralPercentage;
	}
    
    
   
   



    
    

}
