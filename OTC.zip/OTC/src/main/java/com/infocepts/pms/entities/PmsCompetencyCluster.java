/**
* Filename: /src/main/java/com/infocepts/pms/entities/PmsCompetencyCluster.java
* @author  MEW
* @version 1.0
* @since   2018-11-12 
*/
package com.infocepts.pms.entities;

import java.util.Date;
import java.util.List;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import com.infocepts.otc.utilities.LoadConstant;



@Entity
@Table(catalog=LoadConstant.pms, schema="[dbo]", name="competencyCluster")

@SqlResultSetMappings({
        @SqlResultSetMapping(
                name = "competency_cluster_details",
                classes = {
                        @ConstructorResult(
                                targetClass = PmsCompetencyCluster.class,
                                columns = {
                                		@ColumnResult(name = "competencyClusterId"),
										
                                        @ColumnResult(name = "name", type = String.class),   
                                        @ColumnResult(name = "weightage"),
                                        @ColumnResult(name = "isActive", type = Boolean.class),  							
										@ColumnResult(name = "createdBy"),
                                        @ColumnResult(name = "createdDate", type = Date.class),
										@ColumnResult(name = "modifiedBy"),
                                        @ColumnResult(name = "modifiedDate", type = Date.class),
                                        @ColumnResult(name = "sequence")
                                }
                        )
                }
        )
})
@NamedNativeQueries({
        @NamedNativeQuery(
                name    =   "getAllCompetencyCluster",   
                query 	=   "Select compCluster.* "+						
							" from " + LoadConstant.pms + ".[dbo].competencyCluster as compCluster "+
							" where (isActive = :status or  2 = :status)",
							 
							resultClass=PmsCompetencyCluster.class, resultSetMapping = "competency_cluster_details"
        ) ,
        @NamedNativeQuery(
                name    =   "getCompetencyClusterById",   
                query 	=   "Select compCluster.* "+
							" from " + LoadConstant.pms + ".[dbo].competencyCluster as compCluster "+
							" where competencyClusterId = :competencyClusterId",			
														 
							resultClass=PmsCompetencyCluster.class, resultSetMapping = "competency_cluster_details"
        ),
        @NamedNativeQuery(
                name    =   "getAllCompetencyClusterByUser",   
                query 	=   " Select compCluster.* from competencyCluster as compCluster "+
							" left join gradeMapping gm "+
							" on compCluster.competencyClusterId = gm.typeId and gm.type = 1 "+
							" left join departmentMapping dm "+
							" on compCluster.competencyClusterId = dm.typeId and dm.type = 1 "+
							" left join "+LoadConstant.infomaster + ".[dbo].department dep on dm.departmentId = dep.pid "+
							" left join "+
							  LoadConstant.infomaster + ".[dbo].resource r "+
							" on r.departmentId = dep.departmentId and r.gradeId = gm.gradeId "+
							" Where compCluster.isActive = 1 "+
							" And r.uid = :uid ",
							 
							resultClass=PmsCompetencyCluster.class, resultSetMapping = "competency_cluster_details"
        )
})
public class PmsCompetencyCluster {
	

	// Entity Columns
    // --------------------------------------------------------------------------------
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Integer competencyClusterId; 
	
    @NotNull
    private String name;
    private Integer weightage;    
    private Boolean isActive; 
    private Integer sequence; 
    @Transient
    private List<PmsGradeMapping> gradeMapping;
    
    @Transient
    private List<PmsDepartmentMapping> departmentMapping;
	
	 // Audit Trail columns 
    // --------------------------------------------------------------------------------
	private Integer createdBy;    
    private Date createdDate;
    private Integer modifiedBy;
    private Date modifiedDate;
    
    // Transient Variables
    // --------------------------------------------------------------------------------


    // Getter setter
	// --------------------------------------------------------------------------------
	public Integer getCompetencyClusterId() {
		return competencyClusterId;
	}
	
	public void setCompetencyClusterId(Integer competencyClusterId) {
		this.competencyClusterId = competencyClusterId;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public Integer getWeightage() {
		return weightage;
	}
	
	public void setWeightage(Integer weightage) {
		this.weightage = weightage;
	}
	
	public Boolean getIsActive() {
		return isActive;
	}
	
	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}
	
	public Integer getCreatedBy() {
		return createdBy;
	}
	
	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}
	
	public Date getCreatedDate() {
		return createdDate;
	}
	
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	
	public Integer getModifiedBy() {
		return modifiedBy;
	}
	
	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	
	public Date getModifiedDate() {
		return modifiedDate;
	}
	
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	
	public List<PmsGradeMapping> getGradeMapping() {
				
		return gradeMapping;
	}
	
	public void setGradeMapping(List<PmsGradeMapping> gradeMapping) {
		this.gradeMapping = gradeMapping;
	}
	
	public List<PmsDepartmentMapping> getDepartmentMapping() {
		return departmentMapping;
	}
	
	public void setDepartmentMapping(List<PmsDepartmentMapping> departmentMapping) {
		this.departmentMapping = departmentMapping;
	}
	
	public Integer getSequence() {
		return sequence;
	}
	
	public void setSequence(Integer sequence) {
		this.sequence = sequence;
	}
	
	// Constructor
	// ---------------------------------------------------------------------------------
	public PmsCompetencyCluster() {
		//super();
		// TODO Auto-generated constructor stub
	}
	
	public PmsCompetencyCluster(Integer competencyClusterId, 
						 
						 String name,   
						 Integer weightage,
						 Boolean isActive,
						 Integer createdBy,    						 
						 Date createdDate,
						 Integer modifiedBy,
						 Date modifiedDate,
						 Integer sequence
						
	) {
				
		this.competencyClusterId = competencyClusterId;
		this.name = name;
		this.weightage = weightage;
		this.isActive = isActive;
		this.createdBy = createdBy;
		this.createdDate = createdDate;
		this.modifiedBy = modifiedBy;
		this.modifiedDate = modifiedDate;
		this.sequence = sequence;
		
	}
    
    
   
   



    
    

}
