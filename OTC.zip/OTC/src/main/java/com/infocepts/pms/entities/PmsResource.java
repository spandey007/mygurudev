package com.infocepts.pms.entities;

import java.util.Date;
import javax.persistence.*;

import com.infocepts.otc.utilities.LoadConstant;
@Entity
@Table(catalog = LoadConstant.pms, schema = "[dbo]", name = "pmsResource")
@SqlResultSetMappings({
        @SqlResultSetMapping(
                name = "pms_resource_list",
                classes = {
                        @ConstructorResult(
                                targetClass = PmsResource.class,
                                columns = {
                                		@ColumnResult(name = "id"),
                                		@ColumnResult(name = "uid"),
                                		@ColumnResult(name = "pmsManagerId"),
                                		@ColumnResult(name = "pmsManagerEmpId"),
                                		@ColumnResult(name = "pmsManagerName", type = String.class),
                                		@ColumnResult(name = "pmsReviewerId"),
                                		@ColumnResult(name = "pmsReviewerEmpId"),
                                		@ColumnResult(name = "pmsReviewerName", type = String.class),
                                		@ColumnResult(name = "promomtionDue", type = String.class),
                                		@ColumnResult(name = "enableHandshake", type = Boolean.class),
                                        @ColumnResult(name = "enablePitstop", type = Boolean.class),
                                        @ColumnResult(name = "enableEvaluation", type = Boolean.class),
                                        @ColumnResult(name = "enableHandshakeCycle"),
                                        @ColumnResult(name = "enablePitstopCycle"),
                                        @ColumnResult(name = "enableEvaluationCycle"),
                                        @ColumnResult(name = "enableHandshakeStatus"),
                                        @ColumnResult(name = "enablePitstopStatus"),
                                        @ColumnResult(name = "enableEvaluationStatus"),                                		
                                		@ColumnResult(name = "createdBy", type = Integer.class),
                                        @ColumnResult(name = "createdDate", type = Date.class),
                                        @ColumnResult(name = "modifiedBy", type = Integer.class),
                                        @ColumnResult(name = "modifiedDate", type = Date.class),
                                        @ColumnResult(name = "email", type = String.class),
                                        @ColumnResult(name = "title", type = String.class),
                                        @ColumnResult(name = "empId"),
                                        @ColumnResult(name = "firstName"),
                                        @ColumnResult(name = "lastName"),
                                        @ColumnResult(name = "gender", type = String.class),
                                        @ColumnResult(name = "reportingManagerId"),
                                        @ColumnResult(name = "reportingManagerText", type = String.class),
                                        @ColumnResult(name = "reportingManagerActive", type = Boolean.class),
                                        @ColumnResult(name = "indirectReportingManagerId"),
                                        @ColumnResult(name = "indirectReportingManagerText", type = String.class),
                                        @ColumnResult(name = "indirectReportingManagerActive", type = Boolean.class),
                                        @ColumnResult(name = "unitId"),                                        
                                        @ColumnResult(name = "empTypeId"),
                                        @ColumnResult(name = "employmentType", type = String.class),
                                		@ColumnResult(name = "gradeId"),
                                		@ColumnResult(name = "gradeName", type = String.class),
                                		@ColumnResult(name = "gradeNo"),
                                        @ColumnResult(name = "bandId"),
                                        @ColumnResult(name = "bandName", type = String.class),
                                        @ColumnResult(name = "departmentId"),
                                        @ColumnResult(name = "departmentName", type = String.class),
                                        @ColumnResult(name = "designation", type = String.class),
                                        @ColumnResult(name = "joiningDate", type = Date.class),
                                        @ColumnResult(name = "disabled", type = Boolean.class),
                                        @ColumnResult(name = "resourceUid"),
                                        @ColumnResult(name = "performanceId"),
                                        @ColumnResult(name = "formStatusGoalsetting"),
                                        @ColumnResult(name = "formStatusPitstop"),
                                        @ColumnResult(name = "formStatusEvaluation"),
                                        @ColumnResult(name = "portfolio"),
                                        @ColumnResult(name = "parentDepartmentId"),
                                        @ColumnResult(name = "parentDepartmentName", type = String.class),
                                        @ColumnResult(name = "role", type = String.class),
                                        @ColumnResult(name = "ildpId"),
                                        @ColumnResult(name = "behavioralComp", type = String.class),
                                        @ColumnResult(name = "functionalComp", type = String.class),
                                        @ColumnResult(name = "technicalSkill", type = String.class),
                                        @ColumnResult(name = "ildpComments", type = String.class)
                                }
                        )
                }
        )
})
@NamedNativeQueries({        
        @NamedNativeQuery(
                name    =   "getPmsDataForAllResources",
                query = "select * from ("+
                		"select pr.*, r.email, r.title, r.empId, r.firstName, r.lastName, r.gender, r.reportingManagerId, dsr.title as reportingManagerText, dsr.disabled as reportingManagerActive, "+
                		" idsr.uid as indirectReportingManagerId, idsr.title as indirectReportingManagerText, idsr.disabled as indirectReportingManagerActive, "+
                		" pmsManager.empId as pmsManagerEmpId, pmsManager.title as pmsManagerName, pmsReviewer.empId as pmsReviewerEmpId, pmsReviewer.title as pmsReviewerName,"+
                		" r.uid as resourceUid, r.unitId, r.empTypeId, empType.empTypeName as employmentType, r.gradeId, g.grade as gradeName, g.gradeNo,"+
                		" r.bandId, b.band as bandName, r.departmentId, d.departmentName, g.designation, r.joiningDate, r.disabled,"+
                		" pd.departmentId as parentDepartmentId, pd.departmentName as parentDepartmentName, hr.role as role, i.ildpId as ildpId, i.behavioralComp as behavioralComp, i.functionalComp as functionalComp, i.technicalSkill as technicalSkill, i.comments as ildpComments ,"+
                		" (SELECT TOP 1 performanceId from " + LoadConstant.pms + ".[dbo].performance pp "+
                        "		WHERE pp.uid = r.uid and pp.cycleId = :cycleId) as performanceId,"+
                		" (SELECT TOP 1 formStatusGoalsetting from " + LoadConstant.pms + ".[dbo].performance pp1 "+
                        "		WHERE pp1.uid = r.uid and pp1.cycleId = :cycleId) as formStatusGoalsetting,"+
                        " (SELECT TOP 1 formStatusPitstop from " + LoadConstant.pms + ".[dbo].performance pp2 "+
                        "		WHERE pp2.uid = r.uid and pp2.cycleId = :cycleId) as formStatusPitstop,"+
                        " (SELECT TOP 1 formStatusEvaluation from " + LoadConstant.pms + ".[dbo].performance pp3 "+
                        "		WHERE pp3.uid = r.uid and pp3.cycleId = :cycleId) as formStatusEvaluation,"+
                        " ISNULL((SELECT (SELECT TOP 1 pp.title from " + LoadConstant.otc + ".[dbo].allocation alc" + 
                        "	left JOIN " + LoadConstant.infomaster + ".[dbo].project p on p.itemId = alc.projectId" + 
                        "	left JOIN " + LoadConstant.infomaster + ".[dbo].accounts a on a.itemId = p.accountId" + 
                        "	left JOIN " + LoadConstant.infomaster + ".[dbo].portfolio pp on p.portfolioId = pp.itemId" + 
                        "	where alc.uid = rr.uid and p.state = 'Active'" + 
                        "	order by billingTypeId)" +
                        "	from " + LoadConstant.infomaster + ".[dbo].resource rr" + 
                        "   where rr.uid = r.uid" + 
                        "   and r.disabled = 0),'Delivery - Delivery Enablement Portfolio') as portfolio" +
						
                		" FROM " + LoadConstant.infomaster + ".[dbo].resource r" +
                        " LEFT JOIN " + LoadConstant.pms + ".[dbo].pmsResource pr on pr.uid = r.uid" +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[grade] g on g.gradeId = r.gradeId" +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[band] b on b.bandId = r.bandId" +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[department] d on d.departmentId = r.departmentId" +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[hrRoles] hr on hr.hrRoleId = r.hrRoleId" +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[city] city on city.cityId = r.currentLocationId" +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[empType] empType on empType.empTypeId = r.empTypeId" +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].resource dsr on dsr.uid = r.reportingManagerId" + // direct supervisor
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].resource idsr on idsr.uid = dsr.reportingManagerId" + // indirect supervisor
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].resource pmsManager on pmsManager.uid = pr.pmsManagerId" + // pms manager
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].resource pmsReviewer on pmsReviewer.uid = pr.pmsReviewerId" + // pms manager
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[department] pd on pd.departmentId = d.pid " +
                        " LEFT JOIN " + LoadConstant.pms + ".[dbo].[ildp] i on i.uid = r.uid " +
                        " LEFT JOIN " + LoadConstant.pms + ".[dbo].[performance] p on p.uid = r.uid and p.cycleId = :cycleId " +
                        " where "+
                        " ((:filterHr = 0 and (r.disabled = 0 or (r.disabled = 1 and p.performanceId is not null)) ) or (:filterHr = 1 and (r.disabled = 0 or (r.disabled = 1 and p.performanceId is not null)) and (d.pid != 39 or r.uid = :uid or pr.pmsManagerId = :reportingManagersId)))"+ // filter all resources in HR parent department
                        " and ( ((:reportingManagersId = 0) or (:reportingManagersId = pr.pmsManagerId and r.disabled = 0)"+ // filter all resources in for a reporting manager
                        "		or (pr.pmsReviewerId  = :reportingManagersId and r.disabled = 0)"+ // Get 2ed level subordinates
                        "   	or (:uid = 0) or (:uid = r.uid and r.disabled = 0) ) )"+ // and include self
                        " and r.email is not null) res where (:portfolio != '' and res.portfolio = :portfolio) or (:portfolio = '')", 
                resultClass=PmsResource.class, resultSetMapping = "pms_resource_list"
        ),
        /* ------------- IMP - config data does not include the PMS performance object  ----------------------------------------- */
        @NamedNativeQuery(
                name    =   "getPmsConfigForAllResources",
                query = "select pr.*, r.email, r.title, r.empId, r.firstName, r.lastName, r.gender, r.reportingManagerId, dsr.title as reportingManagerText, dsr.disabled as reportingManagerActive, "+
                		" idsr.uid as indirectReportingManagerId, idsr.title as indirectReportingManagerText, idsr.disabled as indirectReportingManagerActive, "+
                		" pmsManager.empId as pmsManagerEmpId, pmsManager.title as pmsManagerName, pmsReviewer.empId as pmsReviewerEmpId, pmsReviewer.title as pmsReviewerName,"+
                		" r.uid as resourceUid, r.unitId, r.empTypeId, empType.empTypeName as employmentType, r.gradeId, g.grade as gradeName, g.gradeNo,"+
                		" r.bandId, b.band as bandName, r.departmentId, d.departmentName, g.designation, r.joiningDate, r.disabled,"+
                		" pd.departmentId as parentDepartmentId, pd.departmentName as parentDepartmentName, hr.role as role, i.ildpId as ildpId,  i.behavioralComp as behavioralComp, i.functionalComp as functionalComp, i.technicalSkill as technicalSkill, i.comments as ildpComments , "+
                
                		" (SELECT TOP 1 performanceId from " + LoadConstant.pms + ".[dbo].performance pp "+
                        "		WHERE pp.uid = r.uid and pp.cycleId = :cycleId) as performanceId,"+
                		" (SELECT TOP 1 formStatusGoalsetting from " + LoadConstant.pms + ".[dbo].performance pp1 "+
                        "		WHERE pp1.uid = r.uid and pp1.cycleId = :cycleId) as formStatusGoalsetting,"+
                        " (SELECT TOP 1 formStatusPitstop from " + LoadConstant.pms + ".[dbo].performance pp2 "+
                        "		WHERE pp2.uid = r.uid and pp2.cycleId = :cycleId) as formStatusPitstop,"+
                        " (SELECT TOP 1 formStatusEvaluation from " + LoadConstant.pms + ".[dbo].performance pp3 "+
                        "		WHERE pp3.uid = r.uid and pp3.cycleId = :cycleId) as formStatusEvaluation,"+
                        " ISNULL((SELECT (SELECT TOP 1 pp.title from " + LoadConstant.otc + ".[dbo].allocation alc" + 
                        "	left JOIN " + LoadConstant.infomaster + ".[dbo].project p on p.itemId = alc.projectId" + 
                        "	left JOIN " + LoadConstant.infomaster + ".[dbo].accounts a on a.itemId = p.accountId" + 
                        "	left JOIN " + LoadConstant.infomaster + ".[dbo].portfolio pp on p.portfolioId = pp.itemId" + 
                        "	where alc.uid = rr.uid and p.state = 'Active'" + 
                        "	order by billingTypeId)" +
                        "	from " + LoadConstant.infomaster + ".[dbo].resource rr" + 
                        "   where rr.uid = r.uid" + 
                        "   and r.disabled = 0),'Delivery - Delivery Enablement Portfolio') as portfolio" +
                        
                		" FROM " + LoadConstant.infomaster + ".[dbo].resource r" +
                        " LEFT JOIN " + LoadConstant.pms + ".[dbo].pmsResource pr on pr.uid = r.uid" +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[grade] g on g.gradeId = r.gradeId" +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[band] b on b.bandId = r.bandId" +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[department] d on d.departmentId = r.departmentId" +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[hrRoles] hr on hr.hrRoleId = r.hrRoleId" +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[city] city on city.cityId = r.currentLocationId" +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[empType] empType on empType.empTypeId = r.empTypeId" +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].resource dsr on dsr.uid = r.reportingManagerId" + // direct supervisor
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].resource idsr on idsr.uid = dsr.reportingManagerId" + // indirect supervisor
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].resource pmsManager on pmsManager.uid = pr.pmsManagerId" + // pms manager
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].resource pmsReviewer on pmsReviewer.uid = pr.pmsReviewerId" + // pms manager
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[department] pd on pd.departmentId = d.pid " +
                        " LEFT JOIN " + LoadConstant.pms + ".[dbo].[ildp] i on i.uid = r.uid " +                 
                        " where"+
                        " r.email is not null and r.disabled = 0"+
                        " order by r.title", 
                resultClass=PmsResource.class, resultSetMapping = "pms_resource_list"
        ),
        /* ------------- IMP - config data does not include the PMS performance object  ----------------------------------------- */
        @NamedNativeQuery(
                name    =   "getPmsConfigForResourceByUidandCycleId",
                query = "select pr.*, r.email, r.title, r.empId, r.firstName, r.lastName, r.gender, r.reportingManagerId, dsr.title as reportingManagerText, dsr.disabled as reportingManagerActive, "+
                		" idsr.uid as indirectReportingManagerId, idsr.title as indirectReportingManagerText, idsr.disabled as indirectReportingManagerActive, "+
                		" pmsManager.empId as pmsManagerEmpId, pmsManager.title as pmsManagerName, pmsReviewer.empId as pmsReviewerEmpId, pmsReviewer.title as pmsReviewerName,"+
                		" r.uid as resourceUid, r.unitId, r.empTypeId, empType.empTypeName as employmentType, r.gradeId, g.grade as gradeName, g.gradeNo,"+
                		" r.bandId, b.band as bandName, r.departmentId, d.departmentName, g.designation, r.joiningDate, r.disabled,"+
                		" pd.departmentId as parentDepartmentId, pd.departmentName as parentDepartmentName, hr.role as role, i.ildpId as ildpId,  i.behavioralComp as behavioralComp, i.functionalComp as functionalComp, i.technicalSkill as technicalSkill, i.comments as ildpComments ,"+
                		
						" (SELECT TOP 1 performanceId from " + LoadConstant.pms + ".[dbo].performance pp "+
						"		WHERE pp.uid = r.uid and pp.cycleId = :cycleId) as performanceId,"+
						" (SELECT TOP 1 formStatusGoalsetting from " + LoadConstant.pms + ".[dbo].performance pp1 "+
						"		WHERE pp1.uid = r.uid and pp1.cycleId = :cycleId) as formStatusGoalsetting,"+
						" (SELECT TOP 1 formStatusPitstop from " + LoadConstant.pms + ".[dbo].performance pp2 "+
						"		WHERE pp2.uid = r.uid and pp2.cycleId = :cycleId) as formStatusPitstop,"+
						" (SELECT TOP 1 formStatusEvaluation from " + LoadConstant.pms + ".[dbo].performance pp3 "+
						"		WHERE pp3.uid = r.uid and pp3.cycleId = :cycleId) as formStatusEvaluation,"+                        
						
                        " '' as portfolio"+
                		" FROM " + LoadConstant.infomaster + ".[dbo].resource r" +
                        " LEFT JOIN " + LoadConstant.pms + ".[dbo].pmsResource pr on pr.uid = r.uid" +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[grade] g on g.gradeId = r.gradeId" +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[band] b on b.bandId = r.bandId" +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[department] d on d.departmentId = r.departmentId" +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[hrRoles] hr on hr.hrRoleId = r.hrRoleId" +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[city] city on city.cityId = r.currentLocationId" +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[empType] empType on empType.empTypeId = r.empTypeId" +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].resource dsr on dsr.uid = r.reportingManagerId" + // direct supervisor
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].resource idsr on idsr.uid = dsr.reportingManagerId" + // indirect supervisor
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].resource pmsManager on pmsManager.uid = pr.pmsManagerId" + // pms manager
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].resource pmsReviewer on pmsReviewer.uid = pr.pmsReviewerId" + // pms manager
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[department] pd on pd.departmentId = d.pid " +
                        " LEFT JOIN " + LoadConstant.pms + ".[dbo].[ildp] i on i.uid = r.uid " +
                        " where r.disabled = 0 and r.uid= :uid"+
                        " and r.email is not null"+
                        " order by r.title", 
                resultClass=PmsResource.class, resultSetMapping = "pms_resource_list"
        ),
        /* ------------- IMP - config data does not include the PMS performance object  ----------------------------------------- */
        @NamedNativeQuery(
                name    =   "getPmsConfigForResourceByUid",
                query = "select pr.*, r.email, r.title, r.empId, r.firstName, r.lastName, r.gender, r.reportingManagerId, dsr.title as reportingManagerText, dsr.disabled as reportingManagerActive, "+
                		" idsr.uid as indirectReportingManagerId, idsr.title as indirectReportingManagerText, idsr.disabled as indirectReportingManagerActive, "+
                		" pmsManager.empId as pmsManagerEmpId, pmsManager.title as pmsManagerName, pmsReviewer.empId as pmsReviewerEmpId, pmsReviewer.title as pmsReviewerName,"+
                		" r.uid as resourceUid, r.unitId, r.empTypeId, empType.empTypeName as employmentType, r.gradeId, g.grade as gradeName, g.gradeNo,"+
                		" r.bandId, b.band as bandName, r.departmentId, d.departmentName, g.designation, r.joiningDate, r.disabled,"+
                		" pd.departmentId as parentDepartmentId, pd.departmentName as parentDepartmentName, hr.role as role, i.ildpId as ildpId,  i.behavioralComp as behavioralComp, i.functionalComp as functionalComp, i.technicalSkill as technicalSkill, i.comments as ildpComments ,"+
                		" 0 as performanceId,"+
                		" 0 as formStatusGoalsetting,"+
                        " 0 as formStatusPitstop,"+
                        " 0 as formStatusEvaluation,"+
                        " '' as portfolio"+
                		" FROM " + LoadConstant.infomaster + ".[dbo].resource r" +
                        " LEFT JOIN " + LoadConstant.pms + ".[dbo].pmsResource pr on pr.uid = r.uid" +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[grade] g on g.gradeId = r.gradeId" +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[band] b on b.bandId = r.bandId" +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[department] d on d.departmentId = r.departmentId" +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[hrRoles] hr on hr.hrRoleId = r.hrRoleId" +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[city] city on city.cityId = r.currentLocationId" +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[empType] empType on empType.empTypeId = r.empTypeId" +
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].resource dsr on dsr.uid = r.reportingManagerId" + // direct supervisor
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].resource idsr on idsr.uid = dsr.reportingManagerId" + // indirect supervisor
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].resource pmsManager on pmsManager.uid = pr.pmsManagerId" + // pms manager
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].resource pmsReviewer on pmsReviewer.uid = pr.pmsReviewerId" + // pms manager
                        " LEFT JOIN " + LoadConstant.infomaster + ".[dbo].[department] pd on pd.departmentId = d.pid " +
                        " LEFT JOIN " + LoadConstant.pms + ".[dbo].[ildp] i on i.uid = r.uid " +
                        " where r.disabled = 0 and r.uid= :uid"+
                        " and r.email is not null"+
                        " order by r.title", 
                resultClass=PmsResource.class, resultSetMapping = "pms_resource_list"
        )
})
public class PmsResource {

    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Integer id;
    
    private Integer uid; // Reference to infomaster resource
    
    private Integer pmsManagerId;    
    private Integer pmsReviewerId;   
    
    private String promomtionDue;
    
    // To force enable the state for associate
    private Boolean enableHandshake;
    private Boolean enablePitstop;
    private Boolean enableEvaluation;
    
    private Date createdDate;
    private Integer createdBy;
    private Date modifiedDate;
    private Integer modifiedBy;
  
    private Integer enableHandshakeCycle;   
    private Integer enablePitstopCycle;   
    private Integer enableEvaluationCycle;
    
    private Integer enableHandshakeStatus;
    private Integer enablePitstopStatus;
    private Integer enableEvaluationStatus;

    // Transient Variables
    // --------------------------------------------------------------------------------
    @Transient
    private Integer pmsManagerEmpId;
    @Transient
    private String pmsManagerName;
    @Transient
    private Integer pmsReviewerEmpId;
    @Transient
    private String pmsReviewerName;
    
    @Transient
    private Integer performanceId;
    @Transient
    private Integer formStatusGoalsetting;
    @Transient
    private Integer formStatusPitstop;
    @Transient
    private Integer formStatusEvaluation;
    
    @Transient
    private String email;    
    @Transient
    private String title;    
    @Transient
    private Integer empId;
    @Transient
    private String firstName;
    @Transient
    private String lastName;
    @Transient
    private String gender;
    
    @Transient
    private Integer reportingManagerId;
    @Transient
    private String reportingManagerText;
    @Transient
    private Boolean reportingManagerActive;    
    
    @Transient
    private Integer indirectReportingManagerId;
    @Transient
    private String indirectReportingManagerText;
    @Transient
    private Boolean indirectReportingManagerActive;

    @Transient
    private Integer unitId;
    @Transient
    private Integer empTypeId;
    @Transient
    private String employmentType;
    @Transient
    private Integer gradeId;
    @Transient
    private String gradeName;
    @Transient
    private String gradeNo;
    @Transient
    private Integer bandId;
    @Transient
    private String bandName;
    @Transient
    private Integer departmentId;
    @Transient
    private String departmentName;
    @Transient
    private Integer cityId;
    @Transient
    private String designation;

    @Transient
    private Date joiningDate;
    @Transient
    private Date terminatedDate;
    @Transient
    private Boolean disabled; 
    @Transient
    private String portfolio;
    @Transient
    private Integer parentDepartmentId;
    
    @Transient
    private String parentDepartmentName;
    
    @Transient
    private String role;
    
    @Transient
    private Integer ildpId;
  
	//For ILDP Grid
	
	@Transient
    private String behavioralComp;
	
	@Transient
    private String functionalComp;
	
	@Transient
    private String technicalSkill;
	
	@Transient
    private String ildpComments;
	
    
    // Getter and Setters
    // ------------------------------------------------------------
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getUid() {
		return uid;
	}

	public void setUid(Integer uid) {
		this.uid = uid;
	}
	
	public Integer getPmsManagerId() {
		return pmsManagerId;
	}

	public void setPmsManagerId(Integer pmsManagerId) {
		this.pmsManagerId = pmsManagerId;
	}

	public String getPmsManagerName() {
		return pmsManagerName;
	}

	public void setPmsManagerName(String pmsManagerName) {
		this.pmsManagerName = pmsManagerName;
	}

	public Integer getPmsReviewerId() {
		return pmsReviewerId;
	}

	public void setPmsReviewerId(Integer pmsReviewerId) {
		this.pmsReviewerId = pmsReviewerId;
	}

	public String getPmsReviewerName() {
		return pmsReviewerName;
	}

	public void setPmsReviewerName(String pmsReviewerName) {
		this.pmsReviewerName = pmsReviewerName;
	}

	public String getPromomtionDue() {
		return promomtionDue;
	}

	public void setPromomtionDue(String promomtionDue) {
		this.promomtionDue = promomtionDue;
	}
	
	public Boolean getEnableHandshake() {
		return enableHandshake;
	}
	public void setEnableHandshake(Boolean enableHandshake) {
		this.enableHandshake = enableHandshake;
	}
	public Boolean getEnablePitstop() {
		return enablePitstop;
	}
	public void setEnablePitstop(Boolean enablePitstop) {
		this.enablePitstop = enablePitstop;
	}
	public Boolean getEnableEvaluation() {
		return enableEvaluation;
	}
	public void setEnableEvaluation(Boolean enableEvaluation) {
		this.enableEvaluation = enableEvaluation;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Integer getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public Integer getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Integer getEmpId() {
		return empId;
	}

	public void setEmpId(Integer empId) {
		this.empId = empId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public Integer getReportingManagerId() {
		return reportingManagerId;
	}

	public void setReportingManagerId(Integer reportingManagerId) {
		this.reportingManagerId = reportingManagerId;
	}

	public String getReportingManagerText() {
		return reportingManagerText;
	}

	public void setReportingManagerText(String reportingManagerText) {
		this.reportingManagerText = reportingManagerText;
	}

	public Integer getIndirectReportingManagerId() {
		return indirectReportingManagerId;
	}

	public void setIndirectReportingManagerId(Integer indirectReportingManagerId) {
		this.indirectReportingManagerId = indirectReportingManagerId;
	}

	public String getIndirectReportingManagerText() {
		return indirectReportingManagerText;
	}

	public void setIndirectReportingManagerText(String indirectReportingManagerText) {
		this.indirectReportingManagerText = indirectReportingManagerText;
	}

	public Boolean getReportingManagerActive() {
		return reportingManagerActive;
	}

	public void setReportingManagerActive(Boolean reportingManagerActive) {
		this.reportingManagerActive = reportingManagerActive;
	}

	public Boolean getIndirectReportingManagerActive() {
		return indirectReportingManagerActive;
	}

	public void setIndirectReportingManagerActive(Boolean indirectReportingManagerActive) {
		this.indirectReportingManagerActive = indirectReportingManagerActive;
	}

	public Integer getUnitId() {
		return unitId;
	}

	public void setUnitId(Integer unitId) {
		this.unitId = unitId;
	}

	public Integer getEmpTypeId() {
		return empTypeId;
	}

	public void setEmpTypeId(Integer empTypeId) {
		this.empTypeId = empTypeId;
	}

	public String getEmploymentType() {
		return employmentType;
	}

	public void setEmploymentType(String employmentType) {
		this.employmentType = employmentType;
	}

	public Integer getGradeId() {
		return gradeId;
	}

	public void setGradeId(Integer gradeId) {
		this.gradeId = gradeId;
	}

	public String getGradeName() {
		return gradeName;
	}

	public void setGradeName(String gradeName) {
		this.gradeName = gradeName;
	}

	public String getGradeNo() {
		return gradeNo;
	}

	public void setGradeNo(String gradeNo) {
		this.gradeNo = gradeNo;
	}

	public Integer getBandId() {
		return bandId;
	}

	public void setBandId(Integer bandId) {
		this.bandId = bandId;
	}

	public String getBandName() {
		return bandName;
	}

	public void setBandName(String bandName) {
		this.bandName = bandName;
	}

	public Integer getDepartmentId() {
		return departmentId;
	}

	public void setDepartmentId(Integer departmentId) {
		this.departmentId = departmentId;
	}

	public String getDepartmentName() {
		return departmentName;
	}

	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}

	public Integer getCityId() {
		return cityId;
	}

	public void setCityId(Integer cityId) {
		this.cityId = cityId;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public Date getJoiningDate() {
		return joiningDate;
	}

	public void setJoiningDate(Date joiningDate) {
		this.joiningDate = joiningDate;
	}

	public Date getTerminatedDate() {
		return terminatedDate;
	}

	public void setTerminatedDate(Date terminatedDate) {
		this.terminatedDate = terminatedDate;
	}

	public Boolean getDisabled() {
		return disabled;
	}

	public void setDisabled(Boolean disabled) {
		this.disabled = disabled;
	}
	
	public Integer getFormStatusGoalsetting() {
		return formStatusGoalsetting;
	}

	public void setFormStatusGoalsetting(Integer formStatusGoalsetting) {
		this.formStatusGoalsetting = formStatusGoalsetting;
	}

	public Integer getFormStatusPitstop() {
		return formStatusPitstop;
	}

	public void setFormStatusPitstop(Integer formStatusPitstop) {
		this.formStatusPitstop = formStatusPitstop;
	}

	public Integer getFormStatusEvaluation() {
		return formStatusEvaluation;
	}

	public void setFormStatusEvaluation(Integer formStatusEvaluation) {
		this.formStatusEvaluation = formStatusEvaluation;
	}

	public Integer getPerformanceId() {
		return performanceId;
	}

	public void setPerformanceId(Integer performanceId) {
		this.performanceId = performanceId;
	}
	
	public String getPortfolio() {
		
		return portfolio;
	}

	public void setPortfolio(String portfolio) {
		
		
		this.portfolio = portfolio;
	}

	public Integer getParentDepartmentId() {
		return parentDepartmentId;
	}

	public void setParentDepartmentId(Integer parentDepartmentId) {
		this.parentDepartmentId = parentDepartmentId;
	}

	public String getParentDepartmentName() {
		return parentDepartmentName;
	}

	public void setParentDepartmentName(String parentDepartmentName) {
		this.parentDepartmentName = parentDepartmentName;
	}	
	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public Integer getIldpId() {
		return ildpId;
	}

	public void setIldpId(Integer ildpId) {
		this.ildpId = ildpId;
	}
	
	public String getBehavioralComp() {
		return behavioralComp;
	}

	public void setBehavioralComp(String behavioralComp) {
		this.behavioralComp = behavioralComp;
	}

	public String getFunctionalComp() {
		return functionalComp;
	}

	public void setFunctionalComp(String functionalComp) {
		this.functionalComp = functionalComp;
	}

	public String getTechnicalSkill() {
		return technicalSkill;
	}

	public void setTechnicalSkill(String technicalSkill) {
		this.technicalSkill = technicalSkill;
	}

	public String getIldpComments() {
		return ildpComments;
	}

	public void setIldpComments(String ildpComments) {
		this.ildpComments = ildpComments;
	}

	public Integer getEnableHandshakeCycle() {
		return enableHandshakeCycle;
	}

	public void setEnableHandshakeCycle(Integer enableHandshakeCycle) {
		this.enableHandshakeCycle = enableHandshakeCycle;
	}

	public Integer getEnablePitstopCycle() {
		return enablePitstopCycle;
	}

	public void setEnablePitstopCycle(Integer enablePitstopCycle) {
		this.enablePitstopCycle = enablePitstopCycle;
	}

	public Integer getEnableEvaluationCycle() {
		return enableEvaluationCycle;
	}

	public void setEnableEvaluationCycle(Integer enableEvaluationCycle) {
		this.enableEvaluationCycle = enableEvaluationCycle;
	}

	public Integer getEnableHandshakeStatus() {
		return enableHandshakeStatus;
	}

	public void setEnableHandshakeStatus(Integer enableHandshakeStatus) {
		this.enableHandshakeStatus = enableHandshakeStatus;
	}

	public Integer getEnablePitstopStatus() {
		return enablePitstopStatus;
	}

	public void setEnablePitstopStatus(Integer enablePitstopStatus) {
		this.enablePitstopStatus = enablePitstopStatus;
	}

	public Integer getEnableEvaluationStatus() {
		return enableEvaluationStatus;
	}

	public void setEnableEvaluationStatus(Integer enableEvaluationStatus) {
		this.enableEvaluationStatus = enableEvaluationStatus;
	}
	
	public Integer getPmsManagerEmpId() {
		return pmsManagerEmpId;
	}

	public void setPmsManagerEmpId(Integer pmsManagerEmpId) {
		this.pmsManagerEmpId = pmsManagerEmpId;
	}

	public Integer getPmsReviewerEmpId() {
		return pmsReviewerEmpId;
	}

	public void setPmsReviewerEmpId(Integer pmsReviewerEmpId) {
		this.pmsReviewerEmpId = pmsReviewerEmpId;
	}

	public PmsResource() {

    }
	
	public PmsResource(Integer id, Integer uid, Integer pmsManagerId,Integer pmsManagerEmpId, String pmsManagerName, Integer pmsReviewerId, Integer pmsReviewerEmpId,
			String pmsReviewerName, String promomtionDue,
			Boolean enableHandshake, Boolean enablePitstop, Boolean enableEvaluation,
			Integer enableHandshakeCycle, Integer enablePitstopCycle, Integer enableEvaluationCycle,
			Integer enableHandshakeStatus, Integer enablePitstopStatus, Integer enableEvaluationStatus,
			Integer createdBy, Date createdDate, Integer modifiedBy, Date modifiedDate, 
			String email, String title, Integer empId, String firstName, String lastName, String gender,
			Integer reportingManagerId, String reportingManagerText, Boolean reportingManagerActive,
			Integer indirectReportingManagerId, String indirectReportingManagerText, Boolean indirectReportingManagerActive,	
            Integer unitId, Integer empTypeId, String employmentType, Integer gradeId, String gradeName, String gradeNo,
            Integer bandId, String bandName, Integer departmentId, String departmentName, String designation,            
            Date joiningDate, Boolean disabled, Integer resourceUid, Integer performanceId,
            Integer formStatusGoalsetting, Integer formStatusPitstop, Integer formStatusEvaluation, 
			String portfolio,
            Integer parentDepartmentId, String parentDepartmentName,String role,Integer ildpId,String behavioralComp, 
        	String functionalComp, String technicalSkill, String ildpComments
           
			) 
	{		
		this.id = id;
		this.uid = uid;   
		if(id == null) this.uid = resourceUid;
		
		this.performanceId = performanceId;
		this.pmsManagerId = pmsManagerId;
		this.pmsManagerEmpId = pmsManagerEmpId;
		this.pmsManagerName = pmsManagerName;
		this.pmsReviewerId = pmsReviewerId;
		this.pmsReviewerEmpId = pmsReviewerEmpId;
		this.pmsReviewerName = pmsReviewerName;
		
		this.promomtionDue = promomtionDue;
		this.enableHandshake = enableHandshake;
		this.enablePitstop = enablePitstop;
		this.enableEvaluation = enableEvaluation;		

		this.enableHandshakeCycle = enableHandshakeCycle;
		this.enablePitstopCycle = enablePitstopCycle;
		this.enableEvaluationCycle = enableEvaluationCycle;
		
		this.enableHandshakeStatus = enableHandshakeStatus;
		this.enablePitstopStatus = enablePitstopStatus;
		this.enableEvaluationStatus = enableEvaluationStatus;
		
		this.createdBy = createdBy;
        this.createdDate = createdDate;
        this.modifiedBy = modifiedBy;
        this.modifiedDate = modifiedDate;
				
		this.title = title;
		this.email = email;
		this.empId = empId;
		
		this.firstName = firstName;
        this.lastName = lastName;
        this.gender = gender;
        this.reportingManagerId = reportingManagerId;
        this.reportingManagerText = reportingManagerText;
        this.reportingManagerActive = reportingManagerActive;
        this.indirectReportingManagerId = indirectReportingManagerId;
        this.indirectReportingManagerText = indirectReportingManagerText;
        this.indirectReportingManagerActive = indirectReportingManagerActive;
        
        this.formStatusGoalsetting = formStatusGoalsetting;
        this.formStatusPitstop = formStatusPitstop;
        this.formStatusEvaluation = formStatusEvaluation;
        
        if(this.formStatusGoalsetting == null) this.formStatusGoalsetting = 0;
        if(this.formStatusPitstop == null) this.formStatusPitstop = 0;
        if(this.formStatusEvaluation == null) this.formStatusEvaluation = 0;
        
		
		this.unitId = unitId;
		this.empTypeId = empTypeId;
		this.employmentType = employmentType;
		
		this.gradeId = gradeId;
		this.gradeName = gradeName;
		this.gradeNo = gradeNo;
		this.bandId = bandId;
		this.bandName = bandName;
		this. designation = designation;
		
		this.departmentId = departmentId;
		this.departmentName = departmentName;
		
		this.disabled = disabled;
		this.joiningDate = joiningDate;
		this.portfolio = portfolio;
		
		this.parentDepartmentId = parentDepartmentId;
		this.parentDepartmentName = parentDepartmentName;
		this.role = role;
		this.ildpId = ildpId;
		
		this.behavioralComp = behavioralComp;
		this.functionalComp = functionalComp;
		this.technicalSkill = technicalSkill;
		this.ildpComments = ildpComments;

	}
}
