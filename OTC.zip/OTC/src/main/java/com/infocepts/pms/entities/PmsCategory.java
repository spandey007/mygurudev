/**
* Filename: /src/main/java/com/infocepts/pms/entities/PmsCategory.java
* @author  RKJ
* @version 1.0
* @since   2018-08-01 
*/
package com.infocepts.pms.entities;

import java.util.Date;
import javax.persistence.*;
import javax.validation.constraints.NotNull;

import com.infocepts.otc.utilities.LoadConstant;
@Entity
@Table(catalog=LoadConstant.pms, schema="[dbo]", name="category")

@SqlResultSetMappings({
        @SqlResultSetMapping(
                name = "pms_categories",
                classes = {
                        @ConstructorResult(
                                targetClass = PmsCategory.class,
                                columns = {
                                		@ColumnResult(name = "categoryId"),
										@ColumnResult(name = "name", type = String.class)
                                }
                        )
                }
        )
})
@NamedNativeQueries({
        @NamedNativeQuery(
                name    =   "getAllCategories",   
                query 	=   "Select c.*"+
							" from " + LoadConstant.pms + ".[dbo].category as c"+
							" order by c.name",
							 
							resultClass=PmsCategory.class, resultSetMapping = "pms_categories"
        ),
        @NamedNativeQuery(
                name    =   "getCategoryById",   
                query 	=   "Select c.*"+
							" from " + LoadConstant.pms + ".[dbo].category as c"+
							" where c.categoryId = :categoryId"+
							" order by c.name",
							 
							resultClass=PmsCategory.class, resultSetMapping = "pms_categories"
        )
})
public class PmsCategory {

	// Entity Columns
    // --------------------------------------------------------------------------------
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Integer categoryId; 
	
    @NotNull
    private String name;
	
	// Audit Trail columns 
    // --------------------------------------------------------------------------------
	private Integer createdBy;    
    private Date createdDate;
    private Integer modifiedBy;
    private Date modifiedDate;
    
    // Getter setter
	// --------------------------------------------------------------------------------
	public Integer getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(Integer categoryId) {
		this.categoryId = categoryId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public Integer getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public Date getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	
	// Constructor
	// ---------------------------------------------------------------------------------
	public PmsCategory() {
		//super();
		// TODO Auto-generated constructor stub
	}
	
	public PmsCategory(Integer categoryId, String name) 
	{		
		this.categoryId = categoryId;
		this.name = name;	
	}

}
