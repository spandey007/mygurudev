package com.infocepts.pms.entities;

import java.util.Date;

import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.SqlResultSetMappings;
import javax.persistence.Table;
import com.infocepts.otc.utilities.LoadConstant;

@Entity
@Table(catalog=LoadConstant.pms, schema="[dbo]",name="ildp")


@SqlResultSetMappings({
    @SqlResultSetMapping(
            name = "ildp_details",
            classes = {
                    @ConstructorResult(
                            targetClass = PmsIldp.class,
                            columns = {
                            		@ColumnResult(name = "ildpId"),
                            		@ColumnResult(name = "cycleId"),
                            		@ColumnResult(name = "uid"),                            		
                            		@ColumnResult(name = "technicalSkill", type = String.class),
                            		@ColumnResult(name = "behavioralComp", type = String.class),
                            		@ColumnResult(name = "functionalComp", type = String.class),   
                            		@ColumnResult(name = "comments", type = String.class),   
									@ColumnResult(name = "createdBy"),
                                    @ColumnResult(name = "createdDate", type = Date.class),
									@ColumnResult(name = "modifiedBy"),
                                    @ColumnResult(name = "modifiedDate", type = Date.class)
                            }
                    )
            }
    )
})
@NamedNativeQueries({
    @NamedNativeQuery(
            name    =   "getAllIldp",   
            query 	=   "  select i.ildpId as ildpId, i.cycleId as cycleId, i.uid as uid , i.technicalSkill as technicalSkill, i.behavioralComp as behavioralComp, i.functionalComp as functionalComp, i.comments as comments, i.createdBy as createdBy, i.createdDate as createdDate, " + 
	            		"  i.modifiedBy as modifiedBy, i.modifiedDate as modifiedDate  " + 
	            		"  from " + LoadConstant.pms + ".[dbo].[ildp] i " ,	            		
						resultClass=PmsIldp.class, resultSetMapping = "ildp_details"
    ),
    @NamedNativeQuery(
            name    =   "getIldpByUid",   
            query 	=   "  select i.ildpId as ildpId, i.cycleId as cycleId, i.uid as uid , i.technicalSkill as technicalSkill, i.behavioralComp as behavioralComp, i.functionalComp as functionalComp, i.comments as comments, i.createdBy as createdBy, i.createdDate as createdDate, " + 
	            		"  i.modifiedBy as modifiedBy, i.modifiedDate as modifiedDate " + 
	            		"  from " + LoadConstant.pms + ".[dbo].[ildp] i "+
	            		"  where uid=:uid ",
						resultClass=PmsIldp.class, resultSetMapping = "ildp_details"
    )
})

public class PmsIldp {

	// Entity Columns
    // ---------------------------------------------------------------------------------------------------------------
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Integer ildpId; 
	
    /*********FK************************************************/
	
	@ManyToOne
	@JoinColumn(name="cycleId")
	private PmsCycle cycle;
	
    private Integer uid;
    private String technicalSkill;
    private String behavioralComp;
    private String functionalComp;
    @Lob
    private String comments;

	
	// Audit Trail columns 
    // ----------------------------------------------------------------------------------------------------------------
	private Integer createdBy;    
    private Date createdDate;
    private Integer modifiedBy;
    private Date modifiedDate;
    
    
 // Getter setter
 	// ----------------------------------------------------------------------------------------------------------------
         
	public Integer getIldpId() {
		return ildpId;
	}
	public void setIldpId(Integer ildpId) {
		this.ildpId = ildpId;
	}
	
	public PmsCycle getCycle() {
		return cycle;
	}
	public void setCycle(PmsCycle cycle) {
		this.cycle = cycle;
	}
	public Integer getUid() {
		return uid;
	}
	public void setUid(Integer uid) {
		this.uid = uid;
	}
	
	public String getTechnicalSkill() {
		return technicalSkill;
	}
	public void setTechnicalSkill(String technicalSkill) {
		this.technicalSkill = technicalSkill;
	}
	public String getBehavioralComp() {
		return behavioralComp;
	}
	public void setBehavioralComp(String behavioralComp) {
		this.behavioralComp = behavioralComp;
	}
	public String getFunctionalComp() {
		return functionalComp;
	}
	public void setFunctionalComp(String functionalComp) {
		this.functionalComp = functionalComp;
	}
	
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	
	public Integer getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public Integer getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public Date getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	
    
    // Getter setter
	// --------------------------------------------------------------------------------------------------------------
    
	
	//Contructor
	
	public PmsIldp() {
		// TODO Auto-generated constructor stub
	}
	
	public PmsIldp(Integer ildpId, Integer cycleId, Integer uid, String technicalSkill, String behavioralComp,
			String functionalComp,String comments, Integer createdBy, Date createdDate, Integer modifiedBy, Date modifiedDate) {
		this.ildpId = ildpId;
		if(cycleId != null)
		{
			this.cycle = new PmsCycle();
			this.cycle.setCycleId(cycleId);
		}
		
		this.uid = uid;
		this.technicalSkill = technicalSkill;
		this.behavioralComp = behavioralComp;
		this.functionalComp = functionalComp;
		this.comments = comments;
		this.createdBy = createdBy;
		this.createdDate = createdDate;
		this.modifiedBy = modifiedBy;
		this.modifiedDate = modifiedDate;
	}
	

    
	
}
