/**
* Filename: /src/main/java/com/infocepts/pms/repositories/PmsCompetencyClusterRepository.java
* @author  SRA
* @version 1.0
* @since   2018-08-01 
*/
package com.infocepts.pms.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import com.infocepts.pms.entities.PmsCompetencyCluster;

public interface PmsCompetencyClusterRepository extends CrudRepository<PmsCompetencyCluster,Integer>{

	@Override
	public List<PmsCompetencyCluster> findAll();	
		
	@Query("from PmsCompetencyCluster where column1 = :column1")
	public PmsCompetencyCluster findPmsCompetencyClusterById(@Param(value = "column1") Integer column1);
	
}
