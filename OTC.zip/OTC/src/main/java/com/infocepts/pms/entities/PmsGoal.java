/**
* Filename: /src/main/java/com/infocepts/pms/entities/PmsGoal.java
* @author  SRA
* @version 1.0
* @since   2018-08-01 
*/
package com.infocepts.pms.entities;


import java.util.Date;
import javax.persistence.*;
import javax.validation.constraints.NotNull;

import com.infocepts.otc.utilities.LoadConstant;
@Entity
@Table(catalog=LoadConstant.pms, schema="[dbo]", name="goal")

@SqlResultSetMappings({
        @SqlResultSetMapping(
                name = "goal_list",
                classes = {
                        @ConstructorResult(
                                targetClass = PmsGoal.class,
                                columns = {                           		
                                		
											@ColumnResult(name = "goalId"),
											@ColumnResult(name = "performanceId"),
											@ColumnResult(name = "goalClusterId"),   
											@ColumnResult(name = "goalName", type = String.class),  
											@ColumnResult(name = "kpi"),
	                                        @ColumnResult(name = "weightage", type = Integer.class),
	                                        @ColumnResult(name = "uom"),
	                                        @ColumnResult(name = "uomDate", type = Date.class),
	                                        @ColumnResult(name = "uomNumber", type = Integer.class),                                        
	                                        @ColumnResult(name = "uomPercentage", type = Integer.class),                                        
	                                        @ColumnResult(name = "target"),											
											@ColumnResult(name = "approvalStatus",type = Integer.class),
											@ColumnResult(name = "commentsRejection",type = String.class),
											@ColumnResult(name = "commentsSelfPitstop",type = String.class),
											@ColumnResult(name = "commentsManagerPitstop",type = String.class),
											@ColumnResult(name = "commentsReviewerPitstop",type = String.class),
											@ColumnResult(name = "commentsSelfAnnual",type = String.class),
											@ColumnResult(name = "commentsManagerAnnual",type = String.class),
											@ColumnResult(name = "commentsReviewerAnnual",type = String.class),
											@ColumnResult(name = "selfRating",type = String.class),
											@ColumnResult(name = "managersRating",type = String.class),	
											@ColumnResult(name = "createdBy"),
											@ColumnResult(name = "createdDate", type = Date.class),
											@ColumnResult(name = "modifiedBy"),
											@ColumnResult(name = "modifiedDate", type = Date.class),
											@ColumnResult(name = "clusterName",type = String.class),
											@ColumnResult(name = "docLinkSelfAnnual",type = String.class),
											@ColumnResult(name = "docLinkManagerAnnual",type = String.class)
											 
											
                                }
                        )
                }
        )
})
@NamedNativeQueries({
        @NamedNativeQuery(
                name    =   "getAllGoal",   
                query 	=   "Select g.*, gC.clusterName as clusterName "+
							" from " + LoadConstant.pms + ".[dbo].goal AS g" +
							" left join " + LoadConstant.pms + ".[dbo].[goalCluster] gC on gC.goalClusterId=g.goalClusterId ",
							resultClass=PmsGoal.class, resultSetMapping = "goal_list"
        ),
		@NamedNativeQuery(
                name    =   "getGoalByPerformanceId",   
                query 	=   "Select g.*, gC.clusterName as clusterName "+
							" from " + LoadConstant.pms + ".[dbo].goal AS g"+
							" left join " + LoadConstant.pms + ".[dbo].[goalCluster] gC on gC.goalClusterId=g.goalClusterId " +
							" left join " + LoadConstant.pms + ".[dbo].performance p on p.performanceId = g.performanceId "+
							" where g.performanceId = :performanceId",							 
							resultClass=PmsGoal.class, resultSetMapping = "goal_list"
        )    		
})
public class PmsGoal {

	// Entity Columns
    // --------------------------------------------------------------------------------
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Integer goalId; 
	
	/*********FK************************************************/
	@NotNull
	@ManyToOne 	
	@JoinColumn(name="performanceId")
	private PmsPerformance pmsPerformance;    
	
	@ManyToOne 	
	@JoinColumn(name="goalClusterId")
	private PmsGoalCluster pmsGoalCluster;  

	/*********Other Columns********************************/	
	@NotNull
	@Lob
    private String goalName;
        
	@NotNull
    @Lob
    private String kpi;
    
	@NotNull
    private Integer weightage;
  
    @NotNull
    private String uom;
    private Date uomDate;
    private Integer uomNumber;
    private Integer uomPercentage;
    
	@NotNull
    @Lob
    private String target;
		
	private Integer approvalStatus; // 0 - Pending Approval, 1 - Rejected, 2 - Approved
	
	@Lob
	private String commentsRejection;
	
	@Lob
	private String commentsSelfPitstop;
	@Lob
	private String commentsManagerPitstop;
	@Lob
	private String commentsReviewerPitstop;
	@Lob
	private String commentsSelfAnnual;
	@Lob
	private String commentsManagerAnnual;
	@Lob
	private String commentsReviewerAnnual;
	private String selfRating;
	private String managersRating;
	@Lob
	private String docLinkSelfAnnual;
	@Lob
	private String docLinkManagerAnnual;
	
	// Audit Trail columns 
    // --------------------------------------------------------------------------------	
	private Integer createdBy;    
    private Date createdDate;
    private Integer modifiedBy;
    private Date modifiedDate;
		
    // Transient Variables
    // --------------------------------------------------------------------------------
    @Transient
	private String clusterName;
    

    // Getter setter
	// --------------------------------------------------------------------------------

	public Integer getGoalId() {
		return goalId;
	}
	public void setGoalId(Integer goalId) {
		this.goalId = goalId;
	}
	public PmsPerformance getPmsPerformance() {
		return pmsPerformance;
	}
	public void setPmsPerformance(PmsPerformance pmsPerformance) {
		this.pmsPerformance = pmsPerformance;
	}
	public PmsGoalCluster getPmsGoalCluster() {
		return pmsGoalCluster;
	}
	public void setPmsGoalCluster(PmsGoalCluster pmsGoalCluster) {
		this.pmsGoalCluster = pmsGoalCluster;
	}
	public String getGoalName() {
		return goalName;
	}
	public void setGoalName(String goalName) {
		this.goalName = goalName;
	}
	public String getKpi() {
		return kpi;
	}
	public void setKpi(String kpi) {
		this.kpi = kpi;
	}
	public Integer getWeightage() {
		return weightage;
	}
	public void setWeightage(Integer weightage) {
		this.weightage = weightage;
	}
	public String getUom() {
		return uom;
	}
	public void setUom(String uom) {
		this.uom = uom;
	}
	public Date getUomDate() {
		return uomDate;
	}
	public void setUomDate(Date uomDate) {
		this.uomDate = uomDate;
	}
	public Integer getUomNumber() {
		return uomNumber;
	}
	public void setUomNumber(Integer uomNumber) {
		this.uomNumber = uomNumber;
	}
	public Integer getUomPercentage() {
		return uomPercentage;
	}
	public void setUomPercentage(Integer uomPercentage) {
		this.uomPercentage = uomPercentage;
	}
	public String getTarget() {
		return target;
	}
	public void setTarget(String target) {
		this.target = target;
	}
	public Integer getApprovalStatus() {
		return approvalStatus;
	}
	public void setApprovalStatus(Integer approvalStatus) {
		this.approvalStatus = approvalStatus;
	}	
	
	public String getCommentsRejection() {
		return commentsRejection;
	}
	public void setCommentsRejection(String commentsRejection) {
		this.commentsRejection = commentsRejection;
	}
	public String getCommentsSelfPitstop() {
		return commentsSelfPitstop;
	}
	public void setCommentsSelfPitstop(String commentsSelfPitstop) {
		this.commentsSelfPitstop = commentsSelfPitstop;
	}
	public String getCommentsManagerPitstop() {
		return commentsManagerPitstop;
	}
	public void setCommentsManagerPitstop(String commentsManagerPitstop) {
		this.commentsManagerPitstop = commentsManagerPitstop;
	}
	public String getCommentsReviewerPitstop() {
		return commentsReviewerPitstop;
	}
	public void setCommentsReviewerPitstop(String commentsReviewerPitstop) {
		this.commentsReviewerPitstop = commentsReviewerPitstop;
	}
	public String getCommentsSelfAnnual() {
		return commentsSelfAnnual;
	}
	public void setCommentsSelfAnnual(String commentsSelfAnnual) {
		this.commentsSelfAnnual = commentsSelfAnnual;
	}
	public String getCommentsManagerAnnual() {
		return commentsManagerAnnual;
	}
	public void setCommentsManagerAnnual(String commentsManagerAnnual) {
		this.commentsManagerAnnual = commentsManagerAnnual;
	}
	public String getCommentsReviewerAnnual() {
		return commentsReviewerAnnual;
	}
	public void setCommentsReviewerAnnual(String commentsReviewerAnnual) {
		this.commentsReviewerAnnual = commentsReviewerAnnual;
	}
	public String getSelfRating() {
		return selfRating;
	}
	public void setSelfRating(String selfRating) {
		this.selfRating = selfRating;
	}
	public String getManagersRating() {
		return managersRating;
	}
	public void setManagersRating(String managersRating) {
		this.managersRating = managersRating;
	}
	public Integer getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public Integer getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public Date getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
		
	public String getClusterName() {
		return clusterName;
	}
	public void setClusterName(String clusterName) {
		this.clusterName = clusterName;
	}	
	public String getDocLinkSelfAnnual() {
		return docLinkSelfAnnual;
	}
	public void setDocLinkSelfAnnual(String docLinkSelfAnnual) {
		this.docLinkSelfAnnual = docLinkSelfAnnual;
	}	
	public String getDocLinkManagerAnnual() {
		return docLinkManagerAnnual;
	}
	public void setDocLinkManagerAnnual(String docLinkManagerAnnual) {
		this.docLinkManagerAnnual = docLinkManagerAnnual;
	}
	// Constructor
	// ---------------------------------------------------------------------------------
	public PmsGoal() {
		//super();		
	}
	public PmsGoal(Integer goalId, Integer performanceId, Integer goalClusterId, String goalName,
			String kpi, Integer weightage, String uom, Date uomDate, Integer uomNumber, Integer uomPercentage,
			String target, Integer approvalStatus, String commentsRejection, String commentsSelfPitstop, String commentsManagerPitstop,
			String commentsReviewerPitstop, String commentsSelfAnnual, String commentsManagerAnnual,
			String commentsReviewerAnnual, String selfRating, String managersRating, Integer createdBy,
			Date createdDate, Integer modifiedBy, Date modifiedDate, String clusterName, String docLinkSelfAnnual, String docLinkManagerAnnual
			) {
		super();
		this.goalId = goalId;
		
		if(performanceId != null)
		{
			this.pmsPerformance = new PmsPerformance();
			this.pmsPerformance.setPerformanceId(performanceId);   
		}	
		
		if(goalClusterId != null)
		{
			this.pmsGoalCluster = new PmsGoalCluster();
			this.pmsGoalCluster.setGoalClusterId(goalClusterId);
		}			
		
		this.goalName = goalName;
		this.kpi = kpi;
		this.weightage = weightage;
		this.uom = uom;
		this.uomDate = uomDate;
		this.uomNumber = uomNumber;
		this.uomPercentage = uomPercentage;
		this.target = target;
		
		this.approvalStatus = approvalStatus;
		if(this.approvalStatus == null) this.approvalStatus = 0;
		
		this.commentsRejection = commentsRejection;
		this.commentsSelfPitstop = commentsSelfPitstop;
		this.commentsManagerPitstop = commentsManagerPitstop;
		this.commentsReviewerPitstop = commentsReviewerPitstop;
		this.commentsSelfAnnual = commentsSelfAnnual;
		this.commentsManagerAnnual = commentsManagerAnnual;
		this.commentsReviewerAnnual = commentsReviewerAnnual;
		this.selfRating = selfRating;
		this.managersRating = managersRating;
		this.createdBy = createdBy;
		this.createdDate = createdDate;
		this.modifiedBy = modifiedBy;
		this.modifiedDate = modifiedDate;
		this.clusterName = clusterName;
		this.docLinkSelfAnnual = docLinkSelfAnnual;
		this.docLinkManagerAnnual = docLinkManagerAnnual;
		
		
	}
	
}
