/**
* Filename: /src/main/java/com/infocepts/pms/repositories/PmsGoalClusterRepository.java
* @author  SRA
* @version 1.0
* @since   2018-11-01 
*/
package com.infocepts.pms.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import com.infocepts.pms.entities.PmsGoalMaster;

public interface PmsGoalMasterRepository extends CrudRepository<PmsGoalMaster,Integer>{

	@Override
	public List<PmsGoalMaster> findAll();	
		
	
	
}
