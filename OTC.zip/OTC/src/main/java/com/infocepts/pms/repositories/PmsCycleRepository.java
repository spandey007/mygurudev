/**
* Filename: /src/main/java/com/infocepts/otc/repositories/PmsCycleRepository.java
* @author  RKJ
* @version 1.0
* @since   2018-10-31 
*/
package com.infocepts.pms.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import com.infocepts.pms.entities.PmsCycle;

public interface PmsCycleRepository extends CrudRepository<PmsCycle,Integer>{

	@Override
	public List<PmsCycle> findAll();
	
}
