package com.infocepts.pms.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import com.infocepts.otc.utilities.LoadConstant;

@Entity
@Table(catalog=LoadConstant.pms, schema="[dbo]",name="departmentMapping")
public class PmsDepartmentMapping {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer departmentMappingId;
	private Integer type; // 
	private Integer departmentId;
	private Integer typeId;
	
	public Integer getdepartmentMappingId() {
		return departmentMappingId;
	}
	public void setdepartmentMappingId(Integer departmentMappingId) {
		this.departmentMappingId = departmentMappingId;
	}
	public Integer getType() {
		return type;
	}
	public void setType(Integer type) {
		this.type = type;
	}
	public Integer getdepartmentId() {
		return departmentId;
	}
	public void setdepartmentId(Integer departmentId) {
		this.departmentId = departmentId;
	}
	public Integer getTypeId() {
		return typeId;
	}
	public void setTypeId(Integer typeId) {
		this.typeId = typeId;
	}
	
	
}

/* Mapping details
 * 
 * 1: Competency Cluster
 * 2: Goal Cluster
 * 
 * 
 * 
 * 
 */


	