package com.infocepts.pms.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.infocepts.otc.utilities.LoadConstant;
import com.infocepts.pms.entities.PmsGradeMapping;


public interface PmsGradeMappingRepository extends CrudRepository<PmsGradeMapping,Integer>{

	@Override
	public List<PmsGradeMapping> findAll();
	
	@Query("from PmsGradeMapping where typeId = :typeId and type = :type")
	public List<PmsGradeMapping> findByTypeId(@Param("typeId") Integer typeId,@Param("type") Integer type);
	
	@Transactional
	@Modifying
	@Query(value = "DELETE FROM "+LoadConstant.pms+".dbo.GradeMapping WHERE typeId=:typeId and type = :type", nativeQuery = true)
	public void deleteGradeMapping(@Param("typeId") Integer typeId,@Param("type") Integer type);
	

	
}
